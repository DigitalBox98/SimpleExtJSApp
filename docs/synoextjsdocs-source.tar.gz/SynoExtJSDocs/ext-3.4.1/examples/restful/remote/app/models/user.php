<?php
/**
 * @class User
 */
class User extends Model {

}
