# API guides

Welcome to the API guides section.<br><br>

The below chapters include technical information on how to build DSM application or to use the Syno API.


## Information available  :

- [Basic application how to](#!/guide/basic)
- [Calling DSM API](#!/guide/api_call)
