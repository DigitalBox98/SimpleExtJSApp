# Basic application how to

This guide gives information on writing DSM Application 

## Usage 

A DSM application will require :<br>
- A config file to define the application shortcut, the icons and the JS file to use <br>
- A JS file (at least one) describing the application GUI & logic <br>

## Application screen

{@img dsmapp.png Alt application screen}


## Config file

In the file below the "simpleextjsapp.js" application is composed of :<br>
- An application part (AppInstance) <br>
- A window (AppWindow) <br>

    @example
	{
	    "simpleextjsapp.js": {
	        "SYNOCOMMUNITY.SimpleExtJSApp.AppInstance": {
	            "type": "app",
	            "title": "app:app_name",
	            "version": "0.1",
	            "icon": "images/simpleextjsapp-{0}.png",
	            "allowMultiInstance": false,
	            "allUsers": false,
	            "appWindow": "SYNOCOMMUNITY.SimpleExtJSApp.AppWindow",
	            "depend": ["SYNOCOMMUNITY.SimpleExtJSApp.AppWindow"]
	        },
	        "SYNOCOMMUNITY.SimpleExtJSApp.AppWindow": {
	            "type": "lib",
	            "title": "app:app_name",
	            "icon": "images/simpleextjsapp-{0}.png",
	            "texts": "texts"
	        }
	    }
	}
	
## Application JS file

The application will be created via the creation of a new class extending from "SYNO.SDS.AppInstance".

The window will be defined via a class extending from "SYNO.SDS.AppWindow" and will display a welcome message via the "syno_displayfield"

    @example
	// Namespace definition
	Ext.ns("SYNOCOMMUNITY.SimpleExtJSApp");

	// Application definition
	Ext.define("SYNOCOMMUNITY.SimpleExtJSApp.AppInstance", {
	    extend: "SYNO.SDS.AppInstance",
	    appWindowName: "SYNOCOMMUNITY.SimpleExtJSApp.AppWindow",
	    constructor: function() {
	        this.callParent(arguments)
	    }
	});

	// Window definition
	Ext.define("SYNOCOMMUNITY.SimpleExtJSApp.AppWindow", {
	    extend: "SYNO.SDS.AppWindow",
	    constructor: function(config) {
	        config = Ext.apply({
	            resizable: true,
	            maximizable: true,
	            minimizable: true,
	            width: 320,
	            height: 200,
                items: [{
                    xtype: 'syno_displayfield',
                    value: 'Welcome to DSM World !'
                    }
                ]
            }, config);
            this.callParent([config]);
        }
    });



