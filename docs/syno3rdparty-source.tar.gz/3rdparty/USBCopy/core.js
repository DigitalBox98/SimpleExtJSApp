/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.USBCopy.core.App
 * @extends SYNO.SDS.AppInstance
 * Core application class for USBCopy utility
 *
 */
 
Ext.define("SYNO.SDS.USBCopy.core.App", {
    extend: "SYNO.SDS.AppInstance",
    models: [],
    stores: [],
    controllers: [],
    config: {},
    constructor: function() {
        this.application = null;
        this._controllerObjs = {};
        this._storeObjs = {};
        this._modelObjs = {};
        this._startComponent = null;
        this.callParent(arguments);
        this._init()
    },
    _init: function() {
        this.application = this;
        var a = Ext.applyIf({
            application: this.application
        }, this.config);
        this.init();
        this._initModels(a);
        this._initStores(a);
        this._initControllers(a)
    },
    init: function() {},
    _initModels: function(a) {
        this.models.forEach(function(c) {
            var d = Ext.getClassByName(c);
            var b = c.slice(c.lastIndexOf(".") + 1);
            this._modelObjs[b] = d
        }, this)
    },
    _initStores: function(a) {
        this.stores.forEach(function(c) {
            var e = Ext.getClassByName(c);
            var d = c.slice(c.lastIndexOf(".") + 1);
            var b = new e(Ext.apply({}, a));
            this._storeObjs[d] = b;
            this.addManagedComponent(b)
        }, this)
    },
    _initControllers: function(a) {
        this.controllers.forEach(function(e) {
            var d = Ext.getClassByName(e);
            var c = e.slice(e.lastIndexOf(".") + 1);
            var b = new d(Ext.apply({}, a));
            this._controllerObjs[c] = b;
            this.addManagedComponent(b)
        }, this)
    },
    initInstance: function(d) {
        var b = this.window;
        var a = this.trayItem;
        d = d || {};
        d.windowState = Ext.applyIf({
            application: this.application
        }, d.windowState);
        this.callParent(arguments);
        if (!b && !a) {
            this._startComponent = this.window || this.trayItem.panel;
            for (var c in this._controllerObjs) {
                if (this._controllerObjs.hasOwnProperty(c)) {
                    this._controllerObjs[c].init()
                }
            }
            this.launch()
        }
    },
    launch: function() {},
    getApplication: function() {
        return this.application
    },
    app: function() {
        return this.getApplication()
    },
    getModel: function(a) {
        return this._modelObjs[a] || this.application._modelObjs[a]
    },
    getStore: function(a) {
        return this._storeObjs[a] || this.application._storeObjs[a]
    },
    getController: function(a) {
        return this._controllerObjs[a] || this.application._controllerObjs[a]
    },
    getComponentByItemId: function(e, d) {
        var b = null,
            a = e.split(" ");
        if (!d) {
            d = this._startComponent || this.application._startComponent
        }
        while (a.length !== 0) {
            var c = a.shift();
            if (!c) {
                continue
            }
            b = SYNO.SDS.USBCopy.core.App.prototype._getComponentByItemId.call(this, c, d);
            if (b === null) {
                return b
            }
            d = b
        }
        return b
    },
    _getComponentByItemId: function(d, c) {
        var b = Ext.isArray(c) ? c : [c],
            a;
        do {
            a = b.shift();
            if (a.getItemId() === d) {
                return a
            }
            if (a.items) {
                b = b.concat(a.items.items)
            }
            if (a.buttons) {
                b = b.concat(a.buttons)
            }
            if (a.menu && a.menu.items) {
                b = b.concat(a.menu.items.items)
            }
        } while (b.length !== 0);
        return null
    },
    componentQuery: function(b, a) {
        return this.getComponentByItemId(b, a)
    }
});
Ext.define("SYNO.SDS.USBCopy.core.Controller", {
    extend: "Ext.Component",
    views: [],
    models: [],
    stores: [],
    constructor: function(a) {
        this.application = null;
        this._viewClasses = {};
        this._modelObjs = {};
        this._storeObjs = {};
        this.callParent(arguments);
        this._init(a)
    },
    _init: function(a) {
        this._initViews(a);
        this._initModels(a);
        this._initStores(a)
    },
    _initViews: function() {
        this.views.forEach(function(a) {
            var b = Ext.getClassByName(a);
            var c = a.slice(a.lastIndexOf(".") + 1);
            this._viewClasses[c] = b
        }, this)
    },
    _initModels: SYNO.SDS.USBCopy.core.App.prototype._initModels,
    _initStores: SYNO.SDS.USBCopy.core.App.prototype._initStores,
    getApplication: SYNO.SDS.USBCopy.core.App.prototype.getApplication,
    app: SYNO.SDS.USBCopy.core.App.prototype.getApplication,
    getController: SYNO.SDS.USBCopy.core.App.prototype.getController,
    getModel: SYNO.SDS.USBCopy.core.App.prototype.getModel,
    getStore: SYNO.SDS.USBCopy.core.App.prototype.getStore,
    getView: function(a) {
        return this._viewClasses[a]
    },
    componentQuery: SYNO.SDS.USBCopy.core.App.prototype.getComponentByItemId,
    init: function() {},
    control: function(d) {
        for (var a in d) {
            if (d.hasOwnProperty(a)) {
                var e = d[a],
                    b = this.componentQuery(a);
                for (var c in e) {
                    if (e.hasOwnProperty(c)) {
                        var f = e[c];
                        b.addListener(c, f, this)
                    }
                }
            }
        }
    },
    createWidget: function(a, b) {
        b = Ext.applyIf({
            mainApplication: this.mainApplication || this.application
        }, b);
        var c = new a(b);
        this.addManagedComponent(c);
        return c
    },
    getMainApplication: function() {
        return this.mainApplication
    }
});
Ext.define("SYNO.SDS.USBCopy.core.Widget", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    viewport: "",
    views: [],
    models: [],
    stores: [],
    controllers: [],
    config: {},
    constructor: function(a) {
        this.application = null;
        this.mainApplication = null;
        this._controllerObjs = {};
        this._viewObjs = {};
        this._storeObjs = {};
        this._modelObjs = {};
        this._viewportObj = null;
        this._startComponent = null;
        a = a || {};
        this.config = Ext.apply({}, a);
        this.application = this;
        this.mainApplication = a.mainApplication || null;
        delete a.mainApplication;
        a.application = this.application;
        this.callParent([a])
    },
    _init: function(a) {
        this._initModels(a);
        this._initStores(a);
        this._initControllers(a);
        if (this.viewport) {
            var c = Ext.getClassByName(this.viewport);
            this._viewportObj = new c(a);
            this._startComponent = this._viewportObj
        }
        this.init();
        for (var b in this._controllerObjs) {
            if (this._controllerObjs.hasOwnProperty(b)) {
                this._controllerObjs[b].init()
            }
        }
    },
    _initControllers: SYNO.SDS.USBCopy.core.App.prototype._initControllers,
    getViewport: function() {
        return this._viewportObj
    }
});
Ext.define("SYNO.SDS.USBCopy.Component.FileExtensionsTreeNodeUI", {
    extend: "Ext.tree.TreeNodeUI",
    checkboxStatus: "checked",
    renderElements: function(f, m, l, o) {
        this.indentMarkup = f.parentNode ? f.parentNode.ui.getChildIndent() : "";
        var h = Ext.isBoolean(m.checked) || m.checked === "gray",
            k = Ext.isBoolean(m.hide_checkbox) && m.hide_checkbox === true,
            g = Ext.util.Format.htmlEncode,
            e = m.input,
            c, b = this.getHref(m.href),
            d = ['<li class="x-tree-node syno-extended-tree-node"><div ext:tree-node-id="', g(f.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', m.cls, '" unselectable="on">', m.hasRemoveButton ? ('<img alt="" src="' + this.emptyIcon + '" class= "syno-tree-node-remove" style="float: right" />') : "", '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', h ? ('<img alt="" src="' + this.emptyIcon + '"' + (k ? ' style="display: none;"' : "") + ' class="syno-tree-node-cb syno-ux-checkbox-icon syno-ux-cb-' + this.checkboxStatus + '" />') : "", '<img alt="" src="', m.icon || this.emptyIcon, '" class="syno-tree-node-icon', (m.icon ? " x-tree-node-inline-icon" : ""), (m.iconCls ? " " + m.iconCls : ""), '" unselectable="on" ', ((m.icon || m.iconCls) ? "" : 'style="display: none;"') + "/>", (m.icon || m.iconCls) ? "<span>&nbsp</span>" : "", '<a hidefocus="on" class="x-tree-node-anchor" href="', b, '" tabIndex="1" ', m.hrefTarget ? ' target="' + m.hrefTarget + '"' : "", '><span unselectable="on" style="text-overflow: ellipsis !important; white-space: nowrap !important; width: 275px !important; display: inline-block;line-height: 15px; padding-top: 0px; overflow-x: hidden; vertical-align: middle">', g(f.text), "</span></a>", "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        if (o !== true && f.nextSibling && (c = f.nextSibling.ui.getEl())) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", c, d)
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", l, d)
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1];
        var j = this.elNode.childNodes;
        var i = 0;
        if (m.hasRemoveButton) {
            this.rimgNode = j[i++]
        }
        this.indentNode = j[i++];
        this.ecNode = j[i++];
        if (h) {
            this.checkbox = j[i++]
        }
        this.iconNode = j[i++];
        if (m.icon || m.iconCls) {
            i++
        }
        this.anchor = j[i++];
        this.textNode = this.anchor.firstChild;
        if (e) {
            this.createInputField(e, m, this.elNode);
            i++
        }
        f.on("disabledchange", this.onDisabled, this)
    },
    setCheckboxViewByStatus: function(a) {
        if (this.checkboxStatus === a) {
            return
        }
        this.checkboxStatus = a;
        if (this.checkbox === undefined) {
            return
        }
        this.checkbox.classList.remove("syno-ux-cb-unchecked");
        this.checkbox.classList.remove("syno-ux-cb-checked");
        this.checkbox.classList.remove("syno-ux-cb-grayed");
        if (a === "unchecked") {
            this.checkbox.classList.add("syno-ux-cb-unchecked")
        } else {
            if (a === "checked") {
                this.checkbox.classList.add("syno-ux-cb-checked")
            } else {
                if (a === "grayed") {
                    this.checkbox.classList.add("syno-ux-cb-grayed")
                }
            }
        }
    },
    setChildsCheckboxViewByStatus: function(a) {
        for (var b = 0; b < this.node.childNodes.length; b++) {
            this.node.childNodes[b].ui.setCheckboxViewByStatus(a)
        }
    },
    getCheckedChildNumber: function() {
        var a = 0;
        for (var b = 0; b < this.node.childNodes.length; b++) {
            if (this.node.childNodes[b].ui.checkboxStatus === "checked") {
                a++
            }
        }
        return a
    },
    refreshNodeStatus: function(b) {
        if (b.attributes.nodeLevel !== "category") {
            return
        }
        if (b.childNodes.length === 0) {
            b.ui.setCheckboxViewByStatus("unchecked");
            return
        }
        var c = b.ui.getCheckedChildNumber();
        var a = b.childNodes.length - c;
        if (b.childNodes.length === c) {
            b.ui.setCheckboxViewByStatus("checked")
        } else {
            if (b.childNodes.length === a) {
                b.ui.setCheckboxViewByStatus("unchecked")
            } else {
                b.ui.setCheckboxViewByStatus("grayed")
            }
        }
    },
    setCheckboxStatus: function(a) {
        this.setCheckboxViewByStatus(a);
        if (this.node.attributes.nodeLevel === "category") {
            this.setChildsCheckboxViewByStatus(a)
        } else {
            this.refreshNodeStatus(this.node.parentNode)
        }
    },
    getCheckboxStatus: function() {
        return this.checkboxStatus
    },
    onCheckBoxClick: function(c, b) {
        var a = (this.checkboxStatus === "unchecked") ? "checked" : "unchecked";
        this.setCheckboxStatus(a)
    },
    onRemoveImgClick: function(c, b) {
        var a = this.node.parentNode;
        this.node.remove();
        this.refreshNodeStatus(a);
        if (a.attributes.nodeId === "customized" && !a.hasChildNodes()) {
            a.remove()
        }
    },
    onRemoveImgDown: function(b, a) {
        a.classList.remove("syno-tree-node-remove");
        a.classList.remove("syno-tree-node-remove-hover");
        a.classList.add("syno-tree-node-remove-click")
    },
    onRemoveImgOver: function(b, a) {
        a.classList.remove("syno-tree-node-remove");
        a.classList.remove("syno-tree-node-remove-click");
        a.classList.add("syno-tree-node-remove-hover")
    },
    onRemoveImgOut: function(b, a) {
        a.classList.remove("syno-tree-node-remove-click");
        a.classList.remove("syno-tree-node-remove-hover");
        a.classList.add("syno-tree-node-remove")
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        if (this.checkbox) {
            Ext.EventManager.on(this.checkbox, "click", this.onCheckBoxClick, this)
        }
        if (this.rimgNode) {
            Ext.EventManager.on(this.rimgNode, "click", this.onRemoveImgClick, this);
            Ext.EventManager.on(this.rimgNode, "mousedown", this.onRemoveImgDown, this);
            Ext.EventManager.on(this.rimgNode, "mouseover", this.onRemoveImgOver, this);
            Ext.EventManager.on(this.rimgNode, "mouseout", this.onRemoveImgOut, this)
        }
        return a
    }
});
Ext.define("SYNO.SDS.USBCopy.Component.FileChooser.Chooser", {
    extend: "SYNO.SDS.Utils.FileChooser.Chooser",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)]);
        this.noShareCallBack = a.noShareCallBack
    },
    fillConfig: function(b) {
        var a = {
            hideFavorites: true
        };
        return Ext.apply(a, b)
    },
    initTreeLoader: function(b) {
        var a = new SYNO.API.TreeLoader({
            api: "SYNO.Core.File",
            method: "list",
            version: 1,
            requestMethod: "POST",
            appWindow: b.owner,
            clearOnLoad: false,
            createNode: function(c, d) {
                c = SYNO.SDS.USBCopy.ParseTreeNode(c, d);
                if (!c.spath) {
                    c.spath = c.path
                }
                if (Ext.isFunction(b.treeFilter) && false === b.treeFilter(this, c)) {
                    c.cls = (c.cls || "") + (" node_display_none");
                    c.hideNode = true
                }
                if (Ext.isDefined(c.children) && Ext.isArray(c.children.files) && c.children.files.length > 0) {
                    c.expanded = true
                }
                return SYNO.API.TreeLoader.prototype.createNode.call(this, c)
            },
            processResponse: function(g, f, m, p) {
                var q = g.responseText;
                try {
                    var c = g.responseData || Ext.decode(q);
                    if ("fm_root" === f.id) {
                        c = c.data.shares
                    } else {
                        c = c.data.files
                    }
                    f.beginUpdate();
                    for (var h = 0, j = c.length; h < j; h++) {
                        var d = this.createNode(c[h], f);
                        if (d) {
                            var l = f.appendChild(d);
                            this.doNodeload(l)
                        }
                    }
                    f.endUpdate();
                    this.runCallback(m, p || f, [f])
                } catch (k) {
                    this.handleFailure(g)
                }
            },
            doNodeload: function(e) {
                if (!e.attributes.children) {
                    return
                }
                var d = e.attributes.children.files;
                e.beginUpdate();
                for (var c = 0; c < d.length; c++) {
                    var f = e.appendChild(this.createNode(d[c], e));
                    this.doNodeload(f)
                }
                e.endUpdate()
            },
            listeners: {
                scope: this,
                beforeload: function(d, c) {
                    if ("fm_root" === c.id) {
                        d.api = "SYNO.Core.Share";
                        d.baseParams = {
                            shareType: ["local", "usb", "dec", "c2"]
                        };
                        this.gotoComplete = false
                    } else {
                        d.api = "SYNO.Core.File";
                        d.baseParams = {
                            superuser: this.superuser,
                            filetype: "dir",
                            folder_path: c.id.substr(c.id.indexOf("/")),
                            additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type"],
                            status_filter: "valid",
                            goto_path: !this.gotoComplete ? this.gotoPath : ""
                        }
                    }
                },
                load: function(j, g) {
                    if (g.id !== "fm_root") {
                        return
                    }
                    var f;
                    for (var d = 0; d < g.childNodes.length; d++) {
                        f = g.childNodes[d];
                        if (!f.attributes.hideNode) {
                            this.tree.getNodeById(f.id).select();
                            break
                        }
                    }
                    if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
                        if (this.gotoPath.indexOf("/", 1) !== -1) {
                            var c = this.gotoPath.split("/")[1];
                            var e = this.tree.getNodeById("/" + c);
                            if (!e) {
                                this.gotoComplete = true;
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                                return
                            }
                            this.getEl().mask(_T("common", "loading"), "x-mask-loading");
                            e.reload(function() {
                                this.getEl().unmask();
                                this.gotoComplete = true;
                                var i = this.tree.getNodeById(this.gotoPath);
                                if (Ext.isDefined(i)) {
                                    i.select()
                                } else {
                                    if (Ext.isDefined(f)) {
                                        f.select()
                                    }
                                }
                            }, this)
                        } else {
                            this.gotoComplete = true;
                            var h = this.tree.getNodeById(this.gotoPath);
                            if (Ext.isDefined(h)) {
                                h.select();
                                if (!this.tree.rootVisible) {
                                    this.getEl().mask(_T("common", "loading"), "x-mask-loading");
                                    h.reload(function() {
                                        this.getEl().unmask()
                                    }, this)
                                }
                            } else {
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                            }
                        }
                    }
                }
            }
        });
        return a
    },
    onTreeRootExpand: function(a) {
        if ("fm_root" === a.id && a.childNodes) {
            var b, c = 0;
            for (b = 0; b < a.childNodes.length; b++) {
                if (!a.childNodes[b].attributes.hideNode) {
                    c++
                }
            }
            if (c === 0 && this.noShareCallBack) {
                this.noShareCallBack(this)
            }
        }
    }
});
