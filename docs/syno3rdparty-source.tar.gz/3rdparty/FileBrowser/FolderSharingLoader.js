/* Copyright (c) 2020 Synology Inc. All rights reserved. */

var debugJsFiles = ["../synoSDSjslib/js/mgr/TaskRunner.js?v={0}", "../synoSDSjslib/js/framework/FeatureTest.js?v={0}", "../synoSDSjslib/js/mgr/Gesture.js?v={0}", "../synoSDSjslib/js/mgr/GestureMgr.js?v={0}", "../synoSDSjslib/js/extension.js?v={0}", "../synoSDSjslib/js/webapi/Params.js?v={0}", "../synoSDSjslib/js/webapi/ErrCode.js?v={0}", "../synoSDSjslib/js/utils/CMS.js?v={0}", "../synoSDSjslib/js/framework/UserSettings.js?v={0}", "../synoSDSjslib/js/system/DateTime.js?v={0}", "../synoSDSjslib/js/system/Language.js?v={0}", "../synojslib/ext-3.4/ux/js/polyfill/setImmediate.js?v={0}", "../webman/3rdparty/FileBrowser/webfmutils.js?v={0}", "../webman/3rdparty/FileBrowser/modules/PathBar.js?v={0}", "../webman/3rdparty/FileBrowser/modules/FocusGridPlugin.js?v={0}", "../webman/3rdparty/FileBrowser/modules/GridFlexPlugin.js?v={0}", "../webman/3rdparty/FileBrowser/modules/SelectAllRowSelectionModel.js?v={0}", "../webman/3rdparty/Utils/lazyDataView.js?v={0}", "../synoSDSjslib/js/webapi/WebAPI.js?v={0}", "../webman/3rdparty/FileBrowser/thumbnailsView.js?v={0}", "../webman/3rdparty/FileBrowser/js/SDSjslib/Proxy.js?v={0}", "../webman/3rdparty/FileBrowser/folderSharing/js/folderSharingExtension.js?v={0}", "../webman/3rdparty/FileBrowser/folderSharing/js/folderSharingDownloadAction.js?v={0}", "../webman/3rdparty/FileBrowser/folderSharing/js/folderSharingCmp.js?v={0}", "../webman/3rdparty/FileBrowser/folderSharing/js/folderSharingToolbar.js?v={0}", "../webman/3rdparty/FileBrowser/folderSharing/js/folderSharingUI.js?v={0}"];
var jsFiles = ["../webman/3rdparty/FileBrowser/FolderSharingBase.js?v={0}", "../webman/3rdparty/FileBrowser/FolderSharing.js?v={0}"];
var count = 0;
var loadJS = function(d, e, c) {
    var a = document.createElement("script");
    a.type = "text/javascript";
    a.src = d;
    if (a.readyState) {
        a.onreadystatechange = function() {
            if (a.readyState == "loaded" || a.readyState == "complete") {
                a.onreadystatechange = null;
                e()
            }
        }
    } else {
        a.onload = function() {
            e()
        }
    }
    a.async = true;
    var b = document.getElementsByTagName("head")[0];
    b.appendChild(a)
};
var urlParam = Ext.urlDecode(window.location.search.substr(1)),
    enableDebug = urlParam.jsDebug,
    noCache = urlParam.noCache;
var folderSharingJSLoader = function(b, g, c) {
    var e = enableDebug ? debugJsFiles : jsFiles,
        d = e.length,
        a = noCache,
        f = e[count];
    if (count === d) {
        g()
    }
    if (!f) {
        return
    }
    loadJS(String.format(f, enableDebug ? b + Math.random() : (a ? b + Math.random() : b)), function() {
        count++;
        folderSharingJSLoader(b, g, c)
    })
};
window._S = function(a) {
    SYNO.SDS.Session = Ext.apply(SYNO.SDS.Session, {
        version: g_Version,
        lang: g_Lang,
        folderSharingURL: g_MD5,
        folderSharingPath: g_FolderPath,
        RELURL: "../webman/3rdparty/FileBrowser/"
    });
    return SYNO.SDS.Session[a]
};
var init = function() {
    SYNO.SDS.GestureMgr = new SYNO.SDS._GestureMgr();
    SYNO.API.currentManager = new SYNO.API._Manager();
    SYNO.API.currentManager.baseURL = "../webapi";
    if (window.g_UserSettings) {
        SYNO.SDS.initUserSettings = Ext.decode(window.g_UserSettings)
    }
    if (g_Session) {
        SYNO.SDS.Session = Ext.decode(g_Session)
    }
    SYNO.SDS.UserSettings = new SYNO.SDS._UserSettings();
    SYNO.API.currentManager.queryAPI("SYNO.FolderSharing.", function() {
        var a = new SYNO.FileStation.FolderSharingWindow();
        a.toggleMaximize();
        a.show()
    });
    SYNO.SDS.UIFeatures.IconSizeManager.addHDClsAndCSS()
};
Ext.onReady(function() {
    folderSharingJSLoader(g_Version, init)
});