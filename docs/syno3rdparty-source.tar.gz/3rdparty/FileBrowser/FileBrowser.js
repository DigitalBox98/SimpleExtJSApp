/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}
Ext.ns("SYNO.FileStation"), SYNO.FileStation.TreeScrollMgr = function() {
    var e = Ext.dd.DragDropMgr,
        t = {},
        i = null,
        o = {},
        n = function(e) {
            i = null, h()
        },
        s = function() {
            e.dragCurrent && e.refreshCache(e.dragCurrent.groups)
        },
        r = function(e) {
            var t = e.fleXdata.scrollPosition;
            return {
                hasVerticalScroll: !1 !== t[1][0],
                hasHorizontalScroll: !1 !== t[0][0],
                scrollTop: t[1][0],
                scrollLeft: t[0][0],
                maxVerticalScroll: t[1][1],
                maxHorizontalScroll: t[0][1]
            }
        },
        a = function(e, t, i) {
            var o = e.dom,
                n = !0 === t ? 0 : i,
                s = !0 === t ? i : 0,
                a = r(o),
                l = a.scrollLeft + n,
                h = a.scrollTop + s;
            l = Math.min(l, a.maxHorizontalScroll), h = Math.min(h, a.maxVerticalScroll), l = Math.max(l, 0), h = Math.max(h, 0), o.fleXcroll.setScrollPos(l, h)
        },
        l = function() {
            if (e.dragCurrent) {
                var t = SYNO.FileStation.TreeScrollMgr,
                    i = o.el.ddScrollConfig ? o.el.ddScrollConfig.increment : t.incrementm,
                    n = "up" == o.dir || "down" == o.dir;
                i = "up" == o.dir || "left" == o.dir ? -1 * i : i, t.animate ? o.el._hasFlexcroll ? a(o.el, n, i) : o.el.scroll(o.dir, i, !0, t.animDuration, s) : o.el._hasFlexcroll ? a(o.el, n, i) : o.el.scroll(o.dir, i) && s()
            }
        },
        h = function() {
            o.id && clearInterval(o.id), o.id = 0, o.el = null, o.dir = ""
        },
        c = function(t, i) {
            h(), o.el = t, o.dir = i;
            var n = t.ddScrollConfig ? t.ddScrollConfig.ddGroup : void 0,
                s = t.ddScrollConfig && t.ddScrollConfig.frequency ? t.ddScrollConfig.frequency : SYNO.FileStation.TreeScrollMgr.frequency;
            void 0 !== n && e.dragCurrent.ddGroup != n || (o.id = setInterval(l, s))
        },
        d = function(n, s) {
            if (!s && e.dragCurrent) {
                var r = SYNO.FileStation.TreeScrollMgr;
                i && i == e.dragCurrent || (i = e.dragCurrent, r.refreshCache());
                var a = Ext.lib.Event.getXY(n),
                    l = new Ext.lib.Point(a[0], a[1]);
                for (var d in t)
                    if (t.hasOwnProperty(d)) {
                        var u = t[d],
                            f = !0 === u._hasFlexcroll ? u._contentEl._region : u._region,
                            m = u.ddScrollConfig ? u.ddScrollConfig : r;
                        if (f && f.contains(l) && (u._hasFlexcroll || u.isScrollable())) {
                            if (f.bottom - l.y <= m.vthresh) return void(o.el != u && c(u, "down"));
                            if (f.right - l.x <= m.hthresh) return void(o.el != u && c(u, "left"));
                            if (l.y - f.top <= m.vthresh) return void(o.el != u && c(u, "up"));
                            if (l.x - f.left <= m.hthresh) return void(o.el != u && c(u, "right"))
                        }
                    } h()
            }
        };
    return e.fireEvents = e.fireEvents.createSequence(d, e), e.stopDrag = e.stopDrag.createSequence(n, e), {
        register: function(e) {
            if (Ext.isArray(e))
                for (var i = 0, o = e.length; i < o; i++) this.register(e[i]);
            else e = Ext.get(e), t[e.id] = e
        },
        unregister: function(e) {
            if (Ext.isArray(e))
                for (var i = 0, o = e.length; i < o; i++) this.unregister(e[i]);
            else e = Ext.get(e), delete t[e.id]
        },
        vthresh: 25,
        hthresh: 25,
        increment: 100,
        frequency: 500,
        animate: !0,
        animDuration: .4,
        ddGroup: void 0,
        refreshCache: function() {
            for (var e in t)
                if (t.hasOwnProperty(e)) {
                    if (!t[e].dom) return;
                    var i = t[e].dom.fleXcroll;
                    "object" == _typeof(t[e]) && (t[e]._region = t[e].getRegion()), i && (t[e]._hasFlexcroll = !0, t[e]._contentEl = t[e].child(".mcontentwrapper"), t[e]._contentEl._region = t[e]._contentEl.getRegion())
                }
        }
    }
}(), Ext.ns("SYNO.FileStation"), SYNO.FileStation.FavDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        SYNO.FileStation.FavDialog.superclass.constructor.call(this, t), this.defineBehaviors()
    },
    fillConfig: function() {
        return {
            owner: this.owner,
            width: 500,
            height: 180,
            shadow: !0,
            minWidth: 500,
            minHeight: 150,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            title: "",
            layout: "fit",
            closeAction: "closeHandler",
            items: [{
                xtype: "form",
                itemId: "form",
                labelWidth: 75,
                labelAlign: "top",
                trackResetOnLoad: !0,
                waitMsgTarget: !0,
                border: !1,
                items: [{
                    xtype: "syno_textfield",
                    itemId: "newname",
                    fieldLabel: _WFT("favorite", "enter_favorite"),
                    name: "newname",
                    width: 400,
                    enableKeyEvents: !0,
                    listeners: {
                        keyup: function(e, t) {
                            t.getKey() === Ext.EventObject.ENTER && this.saveNewName()
                        },
                        buffer: 100,
                        scope: this
                    }
                }],
                listeners: {
                    actionfailed: {
                        fn: this.callbackHandler,
                        scope: this
                    }
                }
            }],
            buttons: [{
                text: _WFT("common", "common_cancel"),
                scope: this,
                handler: this.closeHandler
            }, {
                btnStyle: "blue",
                text: _WFT("common", "common_submit"),
                scope: this,
                handler: this.saveNewName
            }],
            listeners: {
                afterlayout: {
                    fn: function() {
                        this.focusEl = this.get("form").form.findField("newname"), this.center()
                    },
                    scope: this,
                    single: !0
                }
            }
        }
    },
    defineBehaviors: function() {},
    callbackHandler: function() {
        this.hide()
    },
    closeHandler: function() {
        this.get("form").form.isDirty() ? this.getMsgBox().confirm(this.title, _WFT("common", "confirm_lostchange"), function(e) {
            "yes" == e && this.callbackHandler()
        }, this) : this.callbackHandler()
    },
    saveNewName: function() {
        var e = "";
        return this.get("form") && this.get("form").form.findField("newname") ? this.blEdit && !this.get("form").form.isDirty() ? void this.callbackHandler() : (e = Ext.util.Format.trim(this.get("form").form.findField("newname").getValue())) ? void this.onAction(e) : void this.setStatusError({
            text: _WFT("error", "error_empty_name")
        }) : void this.closeHandler()
    },
    onAction: function(e) {
        var t = this.getFavDir();
        this.setStatusBusy(_T("common", "saving")), this.addWebAPITask({
            single: !0,
            api: "SYNO.FileStation.Favorite",
            method: this.blRename ? "edit" : "add",
            version: 2,
            params: Ext.apply({
                name: e,
                path: t,
                index: -1
            }, this.getParams()),
            callback: function(e, t, i) {
                var o;
                this.clearStatusBusy(), e ? (this.fireEvent("callback", this), this.callbackHandler()) : (o = SYNO.webfm.utils.getWebAPIErr(e, t, i), this.getMsgBox().alert(this.title, o))
            },
            scope: this
        }).start(!0)
    },
    resetDialogForm: function() {
        this.get("form") && this.get("form").form.reset()
    },
    setName: function(e) {
        this.name = e
    },
    getName: function() {
        return this.name
    },
    setFavDir: function(e) {
        this.favDir = e
    },
    getFavDir: function() {
        return this.favDir
    },
    getParams: function() {
        return this.params
    },
    setParams: function(e) {
        this.params = e
    },
    setDefaultText: function() {
        var e = this.getName(),
            t = this.getFavDir();
        if (e) {
            var i = t.substr(1, t.indexOf("/", 1) - 1);
            i = i ? " - " + i : "", this.get("form").form.setValues({
                newname: this.blRename ? e : e + i
            })
        }
    },
    onAddFav: function() {
        this.blRename = !1, this.load()
    },
    onEditFav: function() {
        this.blRename = !0, this.load()
    },
    load: function() {
        this.setTitle(this.blRename ? _WFT("favorite", "rename_favorite") : _WFT("favorite", "add_favorite")), this.resetDialogForm(), this.setDefaultText(), this.clearStatus(), this.show()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation._Clipboard = Ext.extend(Ext.util.Observable, {
    constructor: function() {
        SYNO.FileStation._Clipboard.superclass.constructor.apply(this, arguments), this.data = null, this.addEvents("set", "get", "clean")
    },
    set: function(e, t, i) {
        return this.fireEvent("beforeset", this, this.data), this.data = {
            action: e,
            recs: t,
            params: SYNO.Util.copy(i)
        }, this.fireEvent("set", this, this.data), this.data
    },
    get: function() {
        return this.fireEvent("get", this, this.data), this.data
    },
    getFilenames: function() {
        var e = [];
        return Ext.each(this.data.recs, function(t) {
            e.push(t.get("filename"))
        }), e
    },
    clean: function() {
        this.data = null, this.fireEvent("clean", this)
    },
    isEmpty: function() {
        return Ext.isEmpty(this.data)
    }
}), SYNO.FileStation.Clipboard = new SYNO.FileStation._Clipboard, Ext.ns("SYNO.FileStation"), SYNO.FileStation.TreeDialog = function(e) {
    var t;
    e && (t = Ext.copyTo({}, e, ["createNode"]), delete e.createNode), Ext.apply(this, e || {});
    var i = this.initTreeArea(t),
        o = {
            owner: this.owner,
            width: 506,
            height: 564,
            shadow: !0,
            collapsible: !1,
            resizable: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            cls: "webfm-tree-dlg",
            layout: "fit",
            items: i,
            buttons: [{
                text: _WFT("common", "common_cancel"),
                scope: this,
                handler: this.closeHandler
            }, {
                btnStyle: "blue",
                text: _WFT("common", "common_submit"),
                scope: this,
                handler: this.saveSelections
            }],
            keys: [{
                key: 27,
                fn: this.closeHandler,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                },
                beforeshow: {
                    fn: function() {
                        this.initLayout(this.blShowForm)
                    },
                    scope: this
                }
            }
        };
    this.addEvents({
        beforesubmit: !0,
        callback: !0
    }), SYNO.FileStation.TreeDialog.superclass.constructor.call(this, o)
}, Ext.extend(SYNO.FileStation.TreeDialog, SYNO.SDS.ModalWindow, {
    writeStrategyForm: void 0,
    fdrName: null,
    blOverWrite: !1,
    fileStr: null,
    action: null,
    gUID: null,
    gGID: null,
    crtDialog: null,
    reloadTree: function() {
        for (var e = this.dirTree.getRootNode().childNodes || [], t = 0; t < e.length; t++) {
            e[t].reload()
        }
    },
    initTreeArea: function(e) {
        var t, i = Ext.apply({
            timeout: SYNO.webfm.Cfg.timeout,
            api: "SYNO.FileStation.List",
            method: "list_share",
            version: 2,
            baseParams: {
                sort_by: "name",
                additional: ["real_path", "owner", "perm", "mount_point_type"],
                onlywritable: !0,
                filetype: "dir",
                status_filter: "valid"
            },
            createNode: function(e, t) {
                return SYNO.webfm.utils.parseRemoteTreeNode(e, t), SYNO.API.TreeLoader.prototype.createNode.call(this, e, t)
            },
            processResponse: function(e, t, i, o) {
                var n, s = e.responseText;
                try {
                    var r = e.responseData || Ext.decode(s);
                    n = "fm_fav_root" === t.id ? ["data", "favorites"] : "fm_root" === t.id ? ["data", "shares"] : ["data", "files"], Ext.isArray(n) || (n = n.split(","));
                    for (var a in n) n.hasOwnProperty(a) && (r = r[n[a]]);
                    t.beginUpdate();
                    for (var l = 0, h = r.length; l < h; l++) {
                        var c = this.createNode(r[l], t);
                        if (c) {
                            var d = t.appendChild(c);
                            this.doNodeload(d)
                        }
                    }
                    t.endUpdate(), this.runCallback(i, o || t, [t])
                } catch (t) {
                    SYNO.Debug("exception: " + t + ", response: " + e), this.handleFailure(e)
                }
            },
            doNodeload: function(e) {
                if (e.attributes.children) {
                    if (e.childNodes.length < 1) {
                        var t = e.attributes.children;
                        e.beginUpdate();
                        for (var i = 0, o = t.length; i < o; i++) {
                            var n = e.appendChild(this.createNode(t[i], e));
                            this.doNodeload(n)
                        }
                        e.endUpdate()
                    }
                    return !0
                }
                return !1
            },
            listeners: {
                scope: this,
                beforeload: function(e, t) {
                    this.goto_path ? e.baseParams.goto_path = this.goto_path : delete e.baseParams.goto_path, this.bltreeloaded = !1,
                        function() {
                            if (!this.bltreeloadedmask && !this.bltreeloaded) {
                                if (this.isDestroyed) return;
                                this.bltreeloadedmask = !0, this.setStatusBusy({
                                    text: _T("common", "loading")
                                })
                            }
                        }.createDelegate(this).defer(1e3), SYNO.webfm.utils.getRemoteTreeParams(e, t)
                },
                load: function(e, t, i) {
                    if (!this.isDestroyed)
                        if (this.bltreeloaded = !0, this.bltreeloadedmask && this.clearStatusBusy(), "fm_fav_root" === t.id) {
                            var o = t.ui;
                            if (!o) return;
                            !t.childNodes || 0 >= t.childNodes.length ? o.hide() : o.show()
                        } else this.goto_path && (this.onGoToPathWithDir(this.goto_path), delete this.goto_path)
                },
                loadexception: function(e, t, i) {
                    this.isDestroyed || (this.bltreeloaded = !0, this.bltreeloadedmask && this.clearStatusBusy(), "fm_fav_root" === t.id && t.ui.hide())
                }
            }
        }, e);
        t = new SYNO.API.TreeLoader(i);
        var o = new SYNO.ux.TreePanel({
            animate: !1,
            loader: t,
            containerScroll: !0,
            border: !1,
            useArrows: !0,
            rootVisible: !1,
            autoScroll: !1,
            width: 466,
            height: 416,
            bodyStyle: "padding: 8px;",
            baseCls: "syno-webfm",
            updateScrollBarEventNames: ["afterlayout", "append", "insert", "remove", "expandnode", "collapsenode", "resize"],
            root: new Ext.tree.AsyncTreeNode({
                id: "fm_top_root",
                allowDrag: !1,
                allowDrop: !1,
                children: [{
                    cls: "root_node",
                    text: _WFT("favorite", "my_favorite"),
                    draggable: !1,
                    allowDrop: !0,
                    expanded: !0,
                    id: "fm_fav_root",
                    hidden: !0
                }, {
                    cls: "root_node",
                    text: _S("hostname"),
                    draggable: !1,
                    expanded: !0,
                    allowDrop: !1,
                    id: "fm_root",
                    listeners: {
                        expand: {
                            fn: function(e) {
                                var t = e.childNodes;
                                t && t.length > 0 && Ext.each(t, function(e) {
                                    if (!e.attributes.cls || -1 === e.attributes.cls.indexOf("node_display_none")) return this.dirTree.getSelectionModel().select(e), !1
                                }, this)
                            },
                            scope: this
                        }
                    }
                }]
            }),
            tbar: [new SYNO.ux.Button({
                text: _WFT("common", "refresh"),
                handler: function() {
                    this.reloadTree()
                },
                scope: this
            }), this.btnCreateFolder = new SYNO.ux.Button({
                text: _WFT("filetable", "filetable_create_folder"),
                tooltip: _WFT("filetable", "filetable_create_folder"),
                handler: this.createFolder,
                scope: this,
                disabled: !0
            })],
            listeners: {
                beforedestroy: {
                    fn: function() {
                        Ext.destroy(this.dirTree)
                    },
                    scope: this
                }
            }
        });
        o.mon(o.getSelectionModel(), "beforeselect", function(e, t, i) {
            return "fm_root" != t.id && "fm_top_root" !== t.parentNode.id && (this.btnCreateFolder.enable(), !0)
        }, this), this.blDynamicForm && o.mon(o.getSelectionModel(), "selectionchange", function(e, t) {
            if (t) {
                var i = 0;
                !0 === _S("is_admin") || (i = "fm_root" != t.parentNode.id ? SYNO.webfm.utils.getShareFtpRight(this.dirTree, t) : t.attributes.ftpright);
                var o = i & SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST || i & SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY;
                this.enableDisableWriteStrategyForm(o)
            }
        }, this), this.dirTree = o, this.blVFSFolder && this.setVFSRemoteProtocol(t);
        var n = new SYNO.ux.FormPanel({
            border: !1,
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            items: this.dirTree,
            layout: "form",
            baseCls: "syno-webfm",
            autoFlexcroll: !1,
            useGradient: !1,
            bbarCfg: {
                cls: "form-pannel-bbar"
            },
            bbar: [new Ext.form.Label({
                text: _WFT("filetable", "filetable_same_file") + ":",
                height: 20,
                tabIndex: 0
            }), new SYNO.ux.Radio({
                itemId: "skip",
                boxLabel: _WFT("filetable", "filetable_skip"),
                name: "writestrategy",
                inputValue: "skip",
                checked: !0
            }), new SYNO.ux.Radio({
                itemId: "overwrite",
                boxLabel: _WFT("filetable", "filetable_overwrite"),
                name: "writestrategy",
                inputValue: "overwrite"
            })],
            listeners: {
                actionfailed: {
                    fn: this.closeHandler,
                    scope: this
                }
            }
        });
        return this.writeStrategyForm = n, n
    },
    setVFSRemoteProtocol: function(e) {
        var t = this.getBaseURL({
            api: "SYNO.FileStation.VFS.Protocol",
            method: "list",
            version: 1
        });
        t = Ext.urlAppend(t, Ext.urlEncode({
            v: _S("fullversion")
        })), Ext.Ajax.request({
            url: t,
            method: "GET",
            scope: this,
            disableCaching: !1,
            callback: function(t, i, o) {
                if (o && o.responseText) {
                    var n = Ext.decode(o.responseText).data;
                    if (i) {
                        var s = 0,
                            r = n.protocols;
                        for (s = 0; s < r.length; s++) {
                            var a = r[s];
                            this.dirTree.root.appendChild(this.createVFSRoot(e, a.protocol, a.name))
                        }
                    }
                }
            }
        })
    },
    createVFSRoot: function(e, t, i) {
        var o = new SYNO.FileStation.MixedTreeLoader({
                api: "SYNO.FileStation.VirtualFolder",
                method: "list",
                version: 2,
                dataroot: ["data", "folders"],
                baseParams: {
                    type: t,
                    sort_by: "name",
                    additional: ["real_path", "owner", "time", "perm", "mount_point_type"]
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, i) {
                        SYNO.webfm.utils.getRemoteTreeParams(e, i, t)
                    },
                    load: function(e, t, i) {
                        !t.childNodes || 0 >= t.childNodes.length ? t.ui.hide() : t.ui.show()
                    },
                    loadexception: function(e, t, i) {
                        "fm_top_root" === t.parentNode.id && t.ui.hide()
                    }
                },
                createNode: function(t, i) {
                    var o = t.path;
                    return t.name = t.name + " (" + o.substring(o.indexOf("://") + 3) + ")", t.loader = e, SYNO.webfm.utils.parseRemoteTreeNode(t, i), SYNO.FileStation.MixedTreeLoader.prototype.createNode.call(this, t)
                }
            }),
            n = new Ext.tree.AsyncTreeNode({
                cls: "root_node",
                text: i,
                draggable: !1,
                expanded: !0,
                id: t,
                allowDrop: !1,
                hidden: !0,
                loader: o
            });
        return n.expand(), n
    },
    onCrtFdrHide: function() {
        var e = this.crtDialog.getFolderName(),
            t = this.dirTree.getSelectionModel(),
            i = t.getSelectedNode();
        if (i && e) {
            var o = i.attributes.path;
            SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: o,
                name: e,
                force_parent: !1
            }, function(t, n, s, r) {
                if (t) i.reload(function(t) {
                    var i = t.findChild("text", e);
                    i && i.select()
                }), this.webfm.setHighlightEntry(o + "/" + e), this.webfm.refreshTreeNode([o], !0);
                else {
                    var a = SYNO.webfm.utils.getWebAPIErr(t, n, r);
                    this.isDestroyed ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", _WFT("filetable", "filetable_create_folder"), a) : this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), a)
                }
            }, this)
        }
    },
    createFolder: function() {
        var e, t = this.dirTree.getSelectionModel(),
            i = t.getSelectedNode();
        if (i) {
            if (!SYNO.webfm.VFS.isVFSPath(i.attributes.path) && !0 !== _S("is_admin") && "true" !== _S("domainUser")) {
                var o = !1;
                if ("fm_root" != i.parentNode.id ? e = SYNO.webfm.utils.getShareRight(this.dirTree, i) : (e = i.attributes.right, o = !0), !SYNO.webfm.utils.checkShareRight(e, SYNO.webfm.utils.RW)) return this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_privilege_not_enough")), !1;
                if (!o) {
                    var n = {
                        right: i.attributes.right,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Create
                    };
                    if (!SYNO.webfm.utils.checkFileRight(n)) return this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_privilege_not_enough")), !1
                }
            }
            this.crtDialog && !this.crtDialog.isDestroyed || (this.crtDialog = new SYNO.FileStation.CrtFdrDialog({
                RELURL: this.RELURL,
                owner: this
            })), this.crtDialog.mon(this.crtDialog, "callback", this.onCrtFdrHide, this, {
                single: !0
            }), this.crtDialog.setParentDir(i.attributes.path), this.crtDialog.load()
        }
    },
    closeHandler: function() {
        this.hide(), this.fireEvent("callback")
    },
    saveSelections: function() {
        var e = "";
        if (!this.writeStrategyForm || !this.writeStrategyForm.getBottomToolbar()) return void this.closeHandler();
        var t = this.dirTree.getSelectionModel(),
            i = t.getSelectedNode();
        if (!i || !i.id) return void this.getMsgBox().alert(this.title, _WFT("filetable", "filetable_select_one"));
        this.fdrName = i.attributes.path, this.blShowForm && (e = this.writeStrategyForm.bottomToolbar.get("skip").getGroupValue(), this.blOverWrite = "overwrite" == e);
        var o, n = 0;
        if (this.hasListener("beforesubmit") && (!0 === _S("is_admin") || (n = "fm_root" != i.parentNode.id ? SYNO.webfm.utils.getShareFtpRight(this.dirTree, i) : i.attributes.ftpright), o = "fm_root" != i.parentNode.id ? {
                path: i.attributes.path || "",
                real_path: i.attributes.real_path,
                folderRight: i.attributes.right,
                uid: i.attributes.uid,
                gid: i.attributes.gid,
                shareRight: SYNO.webfm.utils.getShareRight(this.dirTree, i),
                ftpRight: n
            } : {
                path: i.attributes.path || "",
                real_path: i.attributes.real_path,
                shareRight: i.attributes.right,
                ftpRight: n
            }, !this.fireEvent("beforesubmit", o))) return void this.resetDialog();
        this.closeHandler()
    },
    resetDialog: function() {
        this.writeStrategyForm && this.writeStrategyForm.form.reset(), this.blOverWrite = !1, this.fdrName = null
    },
    getParameters: function() {
        var e = {};
        return e.fdrName = this.fdrName, e.blOverWrite = this.blOverWrite, e
    },
    initLayout: function(e) {
        this.reloadTree(), this.dirTree.getSelectionModel().clearSelections(), e ? this.writeStrategyForm.show() : this.writeStrategyForm.bbar.hide()
    },
    load: function(e, t, i, o, n) {
        this.goto_path = n, this.blShowForm = t, this.resetDialog(), this.gUID = i, this.gGID = o, this.title = e, this.setTitle(e + " - " + _WFT("filetable", "filetable_select_path")), this.show()
    },
    enableDisableWriteStrategyForm: function(e) {
        e ? (this.writeStrategyForm.bottomToolbar.get("skip").setValue(!0), this.writeStrategyForm.bottomToolbar.get("overwrite").disable(), this.writeStrategyForm.bottomToolbar.get("skip").disable()) : this.writeStrategyForm.bottomToolbar.get("overwrite").disabled && (this.writeStrategyForm.bottomToolbar.get("overwrite").enable(), this.writeStrategyForm.bottomToolbar.get("skip").enable())
    },
    onFindAvailableNode: function(e) {
        if (!e) return null;
        var t, i = this.dirTree.getNodeById(SYNO.webfm.utils.source.remote + e);
        if (!i) {
            if (-1 == (t = e.lastIndexOf("/")) || 0 === t) return e;
            i = this.onFindAvailableNode(e.substr(0, t))
        }
        return i
    },
    onGoToPathWithDir: function(e) {
        var t = this.onFindAvailableNode(e);
        t && Ext.isObject(t) && (t.attributes.path === e ? this.dirTree.getSelectionModel().select(t) : t.expand(!1, !1, function(t) {
            this.onGoToPathCallBack(t, e)
        }, this))
    },
    onGoToPathCallBack: function(e, t) {
        this.expandChildNodes(e, t);
        var i = this.dirTree.getNodeById(SYNO.webfm.utils.source.remote + t);
        i && this.dirTree.getSelectionModel().select(i)
    },
    expandChildNodes: function(e, t) {
        if (e.childNodes.length > 0)
            for (var i = e.childNodes, o = 0, n = i.length; o < n; o++) i[o].attributes.children && SYNO.webfm.utils.isSubNotEqualPath(i[o].attributes.path, t, SYNO.webfm.utils.isLocalSource(i[o].attributes.type) && Ext.isWindows ? "\\" : "/") && (i[o].expand(!1), this.expandChildNodes(i[o], t))
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.SelTreeDialog = function(e) {
    Ext.apply(this, e || {});
    var t = {
        bodyStyle: "padding-right: 20px; padding-left: 20px;"
    };
    SYNO.FileStation.SelTreeDialog.superclass.constructor.call(this, t)
}, Ext.extend(SYNO.FileStation.SelTreeDialog, SYNO.FileStation.TreeDialog, {
    autoScroll: !1,
    initTreeArea: function() {
        var e = new SYNO.API.TreeLoader({
                timeout: SYNO.webfm.Cfg.timeout,
                api: "SYNO.FileStation.List",
                method: "list_share",
                version: 2,
                dataroot: ["data", "shares"],
                baseParams: {
                    sort_by: "name",
                    additional: ["real_path", "owner", "perm", "mount_point_type", "indexed"],
                    filetype: "dir",
                    status_filter: "valid"
                },
                baseAttrs: {
                    uiProvider: Ext.tree.TriTreeNodeUI
                },
                createNode: function(e, t) {
                    return SYNO.webfm.utils.parseRemoteTreeNode(e, t), (SYNO.webfm.utils.isRecycleBinFolder(e.path) || SYNO.webfm.utils.isSnapshotFolder(e.path, !0)) && (e.disabled = !0), e.text = Ext.util.Format.htmlEncode(e.text), SYNO.API.TreeLoader.prototype.createNode.call(this, e, t)
                },
                processResponse: function(e, t, i, o) {
                    var n, s = e.responseText;
                    try {
                        var r = e.responseData || Ext.decode(s);
                        n = "fm_fav_root" === t.id ? ["data", "favorites"] : "fm_root" === t.id ? ["data", "shares"] : ["data", "files"], Ext.isArray(n) || (n = n.split(","));
                        for (var a in n) n.hasOwnProperty(a) && (r = r[n[a]]);
                        t.beginUpdate();
                        for (var l = 0, h = r.length; l < h; l++) {
                            var c = this.createNode(r[l], t);
                            c && t.appendChild(c)
                        }
                        t.endUpdate(), this.runCallback(i, o || t, [t])
                    } catch (t) {
                        this.handleFailure(e)
                    }
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, t, i) {
                        return SYNO.webfm.utils.getRemoteTreeParams(e, t), !(!0 === t.disabled)
                    },
                    load: function(e, t, i) {
                        if ("fm_fav_root" === t.id) {
                            var o = t.ui;
                            if (!o) return;
                            !t.childNodes || 0 >= t.childNodes.length ? o.hide() : o.show()
                        }
                    },
                    loadexception: function(e, t, i) {
                        "fm_fav_root" === t.id && t.ui.hide()
                    }
                }
            }),
            t = new SYNO.ux.TreePanel({
                animate: !1,
                loader: e,
                containerScroll: !0,
                enableDD: !1,
                border: !1,
                useArrows: !0,
                rootVisible: !1,
                cls: "webfm-selfolder-tree",
                bodyStyle: "padding-left:0px; padding-right: 12px;",
                root: new Ext.tree.AsyncTreeNode({
                    id: "fm_top_root",
                    allowDrag: !1,
                    allowDrop: !1,
                    children: [{
                        cls: "root_node",
                        text: _WFT("favorite", "my_favorite"),
                        draggable: !1,
                        allowDrop: !0,
                        expanded: !0,
                        id: "fm_fav_root",
                        hidden: !0
                    }, {
                        cls: "root_node",
                        text: _WFT("search", "all_shares"),
                        draggable: !1,
                        expanded: !0,
                        allowDrop: !1,
                        id: "fm_root",
                        checked: !0,
                        uiProvider: Ext.tree.TriTreeNodeUI,
                        listeners: {
                            expand: {
                                fn: function(e) {
                                    var t = e.childNodes;
                                    if (t && t.length > 0) {
                                        this.btnCreateFolder && this.btnCreateFolder.enable && this.btnCreateFolder.enable();
                                        var i = this.dirTree.getNodeById(SYNO.webfm.utils.source.remote + t[0].attributes.path);
                                        i && this.dirTree.getSelectionModel().select(i)
                                    }
                                },
                                scope: this
                            }
                        }
                    }]
                }),
                tbar: [new SYNO.ux.Button({
                    text: _WFT("common", "refresh"),
                    handler: this.initLayout,
                    scope: this
                })],
                listeners: {
                    beforedestroy: {
                        fn: function() {
                            Ext.destroy(this.dirTree)
                        },
                        scope: this
                    }
                },
                getChecked: function(e, t, i) {
                    t = t || this.root;
                    for (var o = i || [], n = t.firstChild; n;) {
                        switch (n.getUI().getCheckIndex(n)) {
                            case Ext.tree.TriTreeNodeUI.GRAYSTATE:
                                n.firstChild ? this.getChecked(e, n, o) : this.getMsgBox().alert(this.title, _WFT("common", "error_system"));
                                break;
                            case Ext.tree.TriTreeNodeUI.CHECKSTATE:
                                o.push(e ? "id" == e ? n.id : n.attributes[e] : n)
                        }
                        n = n.nextSibling
                    }
                    return o
                }
            });
        return this.dirTree = t, t
    },
    closeHandler: function() {
        this.hide()
    },
    saveSelections: function() {
        for (var e = [], t = this.dirTree.getRootNode().childNodes || [], i = 0; i < t.length; i++) {
            var o = t[i];
            this.dirTree.getChecked(void 0, o, e)
        }
        if (!e || 0 === e.length) return void this.getMsgBox().alert(this.title, _WFT("filetable", "filetable_select_one"));
        this.hasListener("beforesubmit") && !this.fireEvent("beforesubmit", this.dirTree, e) || (this.fireEvent("callback", this.dirTree, e), this.closeHandler())
    },
    initLayout: function() {
        this.reloadTree();
        for (var e = this.dirTree.getRootNode().childNodes || [], t = 0; t < e.length; t++) {
            e[t].getUI().clearCheck()
        }
    },
    load: function(e) {
        this.title = e, this.setTitle(e + " - " + _WFT("filetable", "filetable_select_path")), this.show()
    }
}), Ext.ns("SYNO.FileStation"), Ext.define("SYNO.FileStation.DateField", {
    extend: "SYNO.ux.DateTimeField",
    constructor: function(e) {
        this.callParent([e]), this.addEvents("menuShow", "menuHide")
    },
    onTriggerClick: function(e) {
        this.callParent(arguments), this.fireEvent("menuShow")
    },
    onMenuHide: function() {
        this.callParent(arguments), this.fireEvent("menuHide")
    }
}), Ext.reg("syno_file_datefield", SYNO.FileStation.DateField), SYNO.FileStation.SearchFormPanel = Ext.extend(SYNO.ux.FormPanel, {
    defLocRec: null,
    selPath: "",
    oldSelPath: "",
    selTree: null,
    dbidArr: [],
    showHideMap: {},
    constructor: function(e) {
        Ext.apply(this, e || {}), this.owner = e.owner;
        var t = this.fillConfig();
        SYNO.FileStation.SearchFormPanel.superclass.constructor.call(this, t), this.defineBehaviors(), this.defaultAnimation = ["888888", 1, {
            duration: .35
        }], this.keyNav = new Ext.KeyNav(this.el, {
            esc: function() {
                this.hide(), this.advHistoryPanel.closePanel(), this.webfm.fileSearch.el.focus()
            },
            scope: this
        }), this.advHistoryPanel = new SYNO.FileStation.AdvSearchHistoryPanel({
            webfm: this.webfm,
            owner: this.owner
        }), this.addManagedComponent(this.advHistoryPanel), this.searchType = "advance", this.mon(this.advHistoryPanel, "historyselect", this.onAdvHistorySelect, this), this.mon(this, "afterlayout", this.onAfterlayout, this, {
            single: !0
        })
    },
    onAfterlayout: function() {
        var e = SYNO.ux.AddTip(this.getComponent("enable_content_search").getEl(), _WFT("search", "index_help")),
            t = Ext.get(e);
        t.on("click", this.onOpenIndexHelp, this), t.setStyle("cursor", "pointer")
    },
    fillConfig: function() {
        var e = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "display"],
                data: [
                    ["any", _WFT("search", "search_any")],
                    ["dir", _WFT("search", "folder")],
                    ["fileonly", _WFT("search", "file")],
                    ["documents", _T("report", "reportUI_file_type_document")],
                    ["videos", _T("report", "reportUI_file_type_video")],
                    ["pictures", _T("report", "reportUI_file_type_image")],
                    ["Audio", _T("report", "reportUI_file_type_audio")],
                    ["webpages", _T("report", "reportUI_file_type_web")],
                    ["executablefiles", _T("report", "reportUI_file_type_exe")],
                    ["diskimagefiles", _T("report", "reportUI_file_type_iso")],
                    ["zippedfiles", _T("report", "reportUI_file_type_zip")],
                    ["file", _WFT("search", "extension")]
                ]
            }),
            t = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "display"],
                data: [
                    ["any", _WFT("search", "search_any")],
                    ["equal", _WFT("search", "size_equal")],
                    ["greater", _WFT("search", "size_greater")],
                    ["less", _WFT("search", "size_less")]
                ]
            }),
            i = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "display"],
                data: [
                    ["mtime", _WFT("filetable", "filetable_mtime")],
                    ["crtime", _WFT("filetable", "filetable_ctime")],
                    ["atime", _WFT("filetable", "filetable_atime")]
                ]
            }),
            o = [
                ["any", _WFT("search", "search_any")],
                ["owner", _WFT("filetable", "filetable_owner")]
            ];
        _S("diskless") || o.push(["group", _WFT("filetable", "filetable_group")]);
        var n = new Ext.data.SimpleStore({
            autoDestroy: !0,
            fields: ["value", "display"],
            data: o
        });
        this.groupStore = this.getGroupStore(), this.userStore = this.getUserStore(), this.shareStore = this.getShareStore(), this.localShareStore = this.getLocalShareStore(), this.addManagedComponent(this.groupStore), this.addManagedComponent(this.userStore), this.addManagedComponent(this.shareStore), this.addManagedComponent(this.localShareStore);
        var s = this;
        return {
            width: 360,
            height: 430,
            floating: !0,
            labelAlign: "left",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            border: !0,
            bodyStyle: "padding: 4px 24px 14px 24px; font-size: 12px;",
            autoFlexcroll: !0,
            defaults: {
                hideLabel: !0,
                anchor: "100%"
            },
            items: [{
                xtype: "syno_displayfield",
                name: "keyword_desc",
                tabIndex: -1,
                value: _WFT("search", "keyword") + _T("common", "colon"),
                flex: 1
            }, {
                xtype: "syno_textfilter",
                fieldLabel: _WFT("search", "keyword"),
                msgTarget: "qtip",
                validateOnBlur: !0,
                validationEvent: "blur",
                name: "keyword",
                emptyText: "",
                flex: 2,
                vaule: "",
                enableKeyEvents: !0,
                listeners: {
                    focus: {
                        fn: this.onShowHistory,
                        scope: this
                    },
                    keyup: {
                        fn: this.onShowHistory,
                        scope: this
                    },
                    blur: {
                        fn: this.onCloseHistory,
                        scope: this
                    }
                }
            }, {
                xtype: "syno_checkbox",
                itemId: "enable_content_search",
                height: 28,
                name: "enable_content_search",
                boxLabel: _WFT("search", "enable_content_search"),
                hidden: Ext.isEmpty(_D("supportfileindex"))
            }, {
                xtype: "syno_displayfield",
                tabIndex: -1,
                value: _WFT("property", "file_location") + _T("common", "colon"),
                flex: 1
            }, {
                xtype: "syno_combobox",
                fieldLabel: _WFT("property", "file_location"),
                name: "location",
                mode: "local",
                editable: !1,
                store: this.localShareStore,
                displayField: "text",
                valueField: "path",
                triggerAction: "all",
                lazyRender: !0,
                flex: 2,
                listeners: {
                    scope: this,
                    expand: function(e) {
                        var t = e.getStore(),
                            i = t.getCount();
                        if (!(i < 2)) {
                            var o = this.isSearchableSource();
                            !this.blcurdirnode && o ? (t.insert(i - 1, new Ext.data.Record({
                                type: "curlocation",
                                path: "curlocation",
                                text: _WFT("search", "recursive_folder")
                            })), t.insert(i - 1, new Ext.data.Record({
                                type: "justcurlocation",
                                path: "curlocation",
                                text: _WFT("search", "curfolder")
                            })), this.blcurdirnode = !0) : this.blcurdirnode && !o && i > 3 && (t.removeAt(i - 2), t.removeAt(i - 3), this.blcurdirnode = !1), this.inEl = !0
                        }
                    },
                    beforeselect: {
                        fn: this.showSelTreePanel,
                        scope: this
                    },
                    collapse: {
                        fn: function() {
                            this.inEl = !1
                        },
                        scope: this
                    },
                    select: {
                        fn: function(e, t, i) {
                            if ("location_selection" === t.get("type")) e.setValue(this.oldSelPath);
                            else if ("curlocation" === t.get("type")) this.isSearchableSource() && this.setLocation(this.webfm.getCurrentDir() + "(" + _WFT("search", "recursive_folder") + ")", this.webfm.getCurrentDir());
                            else if ("justcurlocation" === t.get("type")) this.isSearchableSource() && this.setLocation(this.webfm.getCurrentDir());
                            else if ("location_all" === t.get("type")) {
                                var o = "",
                                    n = [];
                                this.shareStore.each(function(e, t) {
                                    e.get("type") || (t > 0 && (o += ", "), o += e.get("path").substr(1), n.push(e.get("path")))
                                }), this.setLocation(o, n)
                            }
                        },
                        scope: this
                    }
                }
            }, {
                xtype: "syno_displayfield",
                tabIndex: -1,
                value: _WFT("filetable", "filetable_title_file_type") + _T("common", "colon")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [{
                    xtype: "syno_combobox",
                    fieldLabel: _WFT("filetable", "filetable_title_file_type"),
                    name: "extopt",
                    mode: "local",
                    editable: !1,
                    store: e,
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    lazyRender: !0,
                    value: "any",
                    listeners: {
                        expand: {
                            fn: function() {
                                this.inEl = !0
                            },
                            scope: this
                        },
                        collapse: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        },
                        select: {
                            fn: function(e, t, i) {
                                var o = t.get("value"),
                                    n = this.form.findField("exttext");
                                "file" === o ? (this.frameAnimation(n.el, this.defaultAnimation), n.enable()) : (n.reset(), n.disable())
                            },
                            scope: this
                        }
                    }
                }, {
                    xtype: "syno_textfield",
                    fieldLabel: _WFT("filetable", "file_extension"),
                    msgTarget: "qtip",
                    validateOnBlur: !0,
                    validationEvent: "blur",
                    name: "exttext",
                    maxlength: 253,
                    disabled: !0,
                    validator: function(e) {
                        var t = s.form.findField("extopt").getValue();
                        return !(e.length < 1 && "file" === t) || _JSLIBSTR("extlang", "fieldblank")
                    }
                }]
            }, {
                xtype: "syno_displayfield",
                tabIndex: -1,
                value: _T("time", "time_date") + _T("common", "colon")
            }, {
                xtype: "syno_combobox",
                fieldLabel: _WFT("adv_search", "date_option"),
                name: "datetype",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: i,
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                value: "mtime",
                listeners: {
                    expand: {
                        fn: function() {
                            this.inEl = !0
                        },
                        scope: this
                    },
                    collapse: {
                        fn: function() {
                            this.inEl = !1
                        },
                        scope: this
                    }
                }
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [{
                    xtype: "syno_file_datefield",
                    fieldLabel: _WFT("adv_search", "from_date"),
                    name: "searchdatefrom",
                    editable: !1,
                    format: SYNO.webfm.utils.GetDateFormat(),
                    emptyText: _T("log", "date_from"),
                    value: "",
                    listeners: {
                        select: {
                            fn: function(e, t) {
                                this.form.findField("searchdateto").setMinValue(t)
                            },
                            scope: this
                        },
                        menuShow: {
                            fn: function() {
                                this.inEl = !0
                            },
                            scope: this
                        },
                        menuHide: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        }
                    }
                }, {
                    xtype: "syno_file_datefield",
                    fieldLabel: _WFT("adv_search", "to_date"),
                    name: "searchdateto",
                    editable: !1,
                    format: SYNO.webfm.utils.GetDateFormat(),
                    emptyText: _T("log", "date_to"),
                    value: "",
                    listeners: {
                        select: {
                            fn: function(e, t) {
                                this.form.findField("searchdatefrom").setMaxValue(t)
                            },
                            scope: this
                        },
                        menuShow: {
                            fn: function() {
                                this.inEl = !0
                            },
                            scope: this
                        },
                        menuHide: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        }
                    }
                }]
            }, {
                xtype: "syno_displayfield",
                tabIndex: -1,
                value: _WFT("common", "common_filesize") + " (MB)" + _T("common", "colon")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [{
                    xtype: "syno_combobox",
                    fieldLabel: _WFT("adv_search", "size_in_mb"),
                    name: "filesizeopt",
                    editable: !1,
                    mode: "local",
                    store: t,
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    lazyRender: !0,
                    value: "any",
                    listeners: {
                        select: {
                            fn: function(e, t, i) {
                                this.enalbeDisableItem(t.get("value"), this.form.findField("filesize"))
                            },
                            scope: this
                        },
                        expand: {
                            fn: function() {
                                this.inEl = !0
                            },
                            scope: this
                        },
                        collapse: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        }
                    }
                }, {
                    xtype: "syno_numberfield",
                    name: "filesize",
                    minValue: 0,
                    disabled: !0,
                    validator: function(e) {
                        return !(e.length < 1 && s.isFieldDirty("filesizeopt")) || _JSLIBSTR("extlang", "fieldblank")
                    }
                }]
            }, {
                xtype: "syno_displayfield",
                tabIndex: -1,
                value: (_S("diskless") ? _WFT("filetable", "filetable_owner") : _WFT("filetable", "filetable_owner_group")) + _T("common", "colon")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [{
                    xtype: "syno_combobox",
                    fieldLabel: _S("diskless") ? _WFT("filetable", "filetable_owner") : _WFT("filetable", "filetable_owner_group"),
                    name: "ownerpot",
                    triggerAction: "all",
                    mode: "local",
                    editable: !1,
                    store: n,
                    displayField: "display",
                    valueField: "value",
                    lazyRender: !0,
                    value: "any",
                    listeners: {
                        select: {
                            fn: function(e, t, i) {
                                var o = t.get("value"),
                                    n = this.form.findField("ownertext");
                                this.enalbeDisableItem(o, this.form.findField("ownertext")) && ("owner" === o && this.userStore !== n.getStore() ? n.bindStore(this.userStore, !1) : "group" === o && this.groupStore !== n.getStore() && n.bindStore(this.groupStore, !1)), n.reset()
                            },
                            scope: this
                        },
                        expand: {
                            fn: function() {
                                this.inEl = !0
                            },
                            scope: this
                        },
                        collapse: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        }
                    }
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _WFT("adv_search", "owner_group_name"),
                    triggerAction: "all",
                    name: "ownertext",
                    editable: !0,
                    displayField: "name",
                    valueField: "name",
                    lazyRender: !0,
                    store: this.userStore,
                    mode: "remote",
                    resizable: !0,
                    pageSize: 50,
                    minListWidth: 200,
                    grow: !0,
                    listWidth: 312,
                    maxHeight: 360,
                    minChars: 1,
                    typeAhead: !0,
                    initList: function() {
                        this.list || (SYNO.ux.ComboBox.prototype.initList.apply(this, arguments), this.pageTb.hide())
                    },
                    disabled: !0,
                    validator: function(e) {
                        return !(e.length < 1 && s.isFieldDirty("ownerpot")) || _JSLIBSTR("extlang", "fieldblank")
                    },
                    listeners: {
                        expand: {
                            fn: function() {
                                var e = this.form.findField("ownertext");
                                e.getStore().totalLength > e.pageSize && (e.pageTb.show(), e.pageTb.first.hide(), e.pageTb.last.hide(), e.pageTb.refresh.hide()), this.inEl = !0
                            },
                            scope: this
                        },
                        collapse: {
                            fn: function() {
                                this.inEl = !1
                            },
                            scope: this
                        }
                    }
                }]
            }, {
                xtype: "toolbar",
                border: !1,
                itemId: "btns",
                toolbarCls: "search-panel-fbar-btnPanel",
                items: [{
                    xtype: "fstbtext",
                    itemId: "search-loading",
                    text: ""
                }, {
                    xtype: "fstbtext",
                    itemId: "msg",
                    height: 26,
                    style: "-webkit-text-size-adjust:none;font-size:11px;color:red;height:26px;overflow:hidden;",
                    text: ""
                }, {
                    xtype: "tbfill"
                }, {
                    xtype: "syno_button",
                    minWidth: 80,
                    itemId: "btn_reset",
                    style: " border-radius: 100px",
                    text: _T("common", "reset"),
                    handler: this.onReset,
                    scope: this
                }, {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    cls: "search-panel-blue-btn",
                    minWidth: 120,
                    text: _WFT("filetable", "filetable_search"),
                    itemId: "btn_search",
                    handler: this.onSearch,
                    scope: this
                }, {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    cls: "search-panel-blue-btn",
                    minWidth: 120,
                    text: _WFT("search", "stop"),
                    itemId: "btn_stop",
                    hidden: !0,
                    handler: this.onStop,
                    scope: this
                }]
            }, {
                xtype: "container",
                name: "focusTrap",
                tabIndex: 0,
                listeners: {
                    afterrender: {
                        fn: function(e) {
                            e.el.on("focus", function() {
                                this.form.findField("keyword").focus()
                            }, this)
                        },
                        scope: this
                    }
                }
            }],
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.setMsg(""), this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        var e = this.getComponent("btns").getComponent("btn_search");
                        this.webfm.fileSearch.disableAdvancedSearch ? e.disable() : e.enable(), this.doLayout()
                    },
                    single: !0
                },
                show: {
                    fn: function() {
                        var e = this.form.findField("ownertext"),
                            t = _S("is_admin") || this.webfm.enableListUserGrp;
                        e.mode = t ? "remote" : "local", e.setHideTrigger(!t), t ? (e.removeClass("search-combobox-border"), e.listEmptyText = _WFT("error", "error_invalid_user_group")) : (e.addClass("search-combobox-border"), e.listEmptyText = ""), this.doLayout()
                    },
                    single: !0
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    this.isVisible() && !this.advHistoryPanel.isVisible() && (this.btnSearch.hidden || this.btnSearch.disabled ? this.btnStop.hidden || this.btnStop.disabled || this.onStop() : this.onSearch())
                },
                scope: this
            }]
        }
    },
    onOpenIndexHelp: function() {
        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: "SYNO.Finder.Application:universalsearch_index.html"
        }, !1), this.hide()
    },
    showSearchIcon: function() {
        this.get("btns").get("search-loading").getEl().addClass("search-loading")
    },
    hideSearchIcon: function() {
        this.get("btns").get("search-loading").getEl().removeClass("search-loading")
    },
    setKeyWord: function(e) {
        var t = this.form.findField("keyword");
        t && Ext.isString(e) && !Ext.isEmpty(e) && Ext.isEmpty(t.getValue()) && t.setValue(e), this.form.findField("keyword_desc").focus("", 1)
    },
    frameAnimation: function(e, t) {
        e && e.isVisible() && Ext.Element.prototype.frame.apply(e, t)
    },
    defineBehaviors: function() {
        this.initSearchDS(), this.onListenTreeNodeClick(), this.onListenTreeNodeClickForToast();
        var e = this.get("btns");
        this.btnSearch = e.get("btn_search"), this.btnStop = e.get("btn_stop")
    },
    setMsg: function(e) {
        var t = this.get("btns"),
            i = t.get("msg");
        i.setText(e), "" !== e.trim() && this.frameAnimation(i.el, this.defaultAnimation)
    },
    onShowHideToast: function(e, t) {
        _S("is_admin") && (!1 === e && t && !this.showHideMap[t] ? (this.toast_box = this.findAppWindow().getToastBox(_WFT("search", "non_index_hint"), !0, {
            text: _T("common", "action"),
            fn: this.onOpenIndexSetting,
            scope: this
        }, {
            delay: 5e3,
            offsetY: 108
        }), this.showHideMap[t] = !0) : this.toast_box && !0 === e && this.toast_box.destroy())
    },
    onOpenIndexSetting: function() {
        SYNO.SDS.AppLaunch("SYNO.Finder.Application", {
            fn: "preference"
        })
    },
    onReset: function() {
        this.form.items.each(function(e) {
            e.isDirty() && this.frameAnimation(e.el, this.defaultAnimation)
        }, this), this.setMsg(""), this.onShowHideToast(!0), this.form.reset(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null), this.form.findField("exttext").disable(), this.form.findField("filesize").disable(), this.form.findField("ownertext").disable(), this.isSearchableSource() ? this.setLocation(this.webfm.getCurrentDir() + "(" + _WFT("search", "recursive_folder") + ")", this.webfm.getCurrentDir()) : this.shareStore.getCount() > 0 && this.setLocation(this.shareStore.getAt(0).get("path") + "(" + _WFT("search", "recursive_folder") + ")", this.shareStore.getAt(0).get("path")), this.onListenTreeNodeClick()
    },
    onListenTreeNodeClick: function() {
        this.listenNode || (this.mon(this.webfm, "onNodeClick", this.onTreeNodeClick, this), this.listenNode = !0)
    },
    onListenTreeNodeClickForToast: function() {
        this.mon(this.webfm, "onNodeClick", this.onTreeNodeClickForToast, this)
    },
    unListenTreeNodeClick: function() {
        !0 === this.listenNode && (this.mun(this.webfm, "onNodeClick", this.onTreeNodeClick, this), this.listenNode = !1)
    },
    unListenTreeNodeClickForToast: function() {
        this.mun(this.webfm, "onNodeClick", this.onTreeNodeClickForToast, this)
    },
    onTreeNodeClick: function(e) {
        if (this.webfm.fileSearch.enable(), this.webfm.getCurrentSource().substr(0, 5) === SYNO.webfm.utils.source.local || this.webfm.getCurrentSource() === SYNO.webfm.utils.source.remoter || SYNO.webfm.VFS.isVFSPath(this.webfm.getCurrentDir())) return this.webfm.fileSearch.hide(), void this.webfm.fileFilter.show();
        this.webfm.fileFilter.hide(), this.webfm.fileSearch.show(), "fm_search_root" !== e.id && !0 !== e.attributes.disabledsearch && this.setLocation(e.attributes.path + "(" + _WFT("search", "recursive_folder") + ")", e.attributes.path)
    },
    onTreeNodeClickForToast: function(e) {
        "fm_search_root" !== e.id && this.onShowHideToast(!0)
    },
    onLoadShareDone: function(e, t, i) {
        this.blcurdirnode = !1, this.localShareStore.removeAll(), t.length < 1 || (this.localShareStore.add(new Ext.data.Record({
            type: "location_all",
            path: "location_all",
            text: _WFT("search", "location_all")
        })), this.localShareStore.add(new Ext.data.Record({
            type: "location_selection",
            path: "location_selection",
            text: _T("common", "customize")
        })), this.isSearchableSource() ? this.setLocation(this.webfm.getCurrentDir() + "(" + _WFT("search", "recursive_folder") + ")", this.webfm.getCurrentDir()) : this.setLocation(t[0].get("path") + "(" + _WFT("search", "recursive_folder") + ")", t[0].get("path")))
    },
    exceptionLoadShare: function(e) {
        e ? e.errno && this.owner.getMsgBox().alert(_WFT("filetable", "filetable_search"), _WFT("error", "error_system_busy")) : this.owner.getMsgBox().alert(_WFT("filetable", "filetable_search"), _WFT("error", "error_system_busy"))
    },
    enalbeDisableItem: function(e, t) {
        return "any" !== e ? (this.frameAnimation(t.el, this.defaultAnimation), t.enable(), 1) : (t.reset(), t.disable(), 0)
    },
    getUserStore: function() {
        return new SYNO.API.Store({
            appWindow: this.owner,
            api: "SYNO.FileStation.UserGrp",
            method: "list_user",
            version: 1,
            baseParams: {
                type: "all"
            },
            reader: new Ext.data.JsonReader({
                root: "users",
                totalProperty: "total",
                id: "name"
            }, [{
                name: "name",
                mapping: "name"
            }]),
            remoteSort: !0,
            pruneModifiedRecords: !0,
            listeners: {
                beforeload: function(e, t) {
                    var i = t.params,
                        o = e.paramNames;
                    return Ext.isNumber(i[o.limit])
                }
            }
        })
    },
    getGroupStore: function() {
        return new SYNO.API.Store({
            appWindow: this.owner,
            api: "SYNO.FileStation.UserGrp",
            method: "list_group",
            version: 1,
            remoteSort: !1,
            baseParams: {
                type: "all",
                name_only: !0
            },
            reader: new Ext.data.JsonReader({
                root: "groups",
                totalProperty: "total",
                id: "name"
            }, [{
                name: "name",
                mapping: "name"
            }]),
            pruneModifiedRecords: !0,
            listeners: {
                beforeload: function(e, t) {
                    var i = t.params,
                        o = e.paramNames;
                    return Ext.isNumber(i[o.limit])
                }
            }
        })
    },
    onCheckPrivilege: function(e, t) {
        if (!0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
        var i = !0;
        return Ext.each(t, function(t) {
            var o = "fm_root" != t.parentNode.id ? SYNO.webfm.utils.getShareRight(e, t) : t.attributes.right;
            if (!SYNO.webfm.utils.checkShareRight(o, SYNO.webfm.utils.RW | SYNO.webfm.utils.RO)) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_search"), _WFT("error", "error_privilege_not_enough")), i = !1, !0;
            var n = 0;
            return !0 === _S("is_admin") || (n = "fm_root" != t.parentNode.id ? SYNO.webfm.utils.getShareFtpRight(e, t) : t.attributes.ftpright), i = n & SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST, i ? (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_search"), _WFT("error", "error_privilege_not_enough")), i = !1, !0) : void 0
        }, this), i
    },
    showSelTreePanel: function(e, t, i) {
        if ("location_selection" === t.get("type")) {
            this.oldSelPath = e.getValue(), this.selTree && !this.selTree.isDestroyed || (this.selTree = new SYNO.FileStation.SelTreeDialog({
                RELURL: this.RELURL,
                owner: this.owner
            }), this.selTree.mon(this.selTree, "beforesubmit", this.onCheckPrivilege, this), this.selTree.mon(this.selTree, "callback", this.onSelPanelHide, this));
            var o = this.selTree,
                n = _WFT("filetable", "filetable_search");
            o.load(n), this.getEl().setStyle("z-index", o.getEl().getStyle("z-index") - 1)
        }
    },
    onSelPanelHide: function(e, t) {
        var i = "",
            o = [];
        this.blHasIndexFolder = !1, Ext.each(t, function(e, t) {
            e.indexed && (this.blHasIndexFolder = !0), -1 == o.indexOf(e.attributes.path) && (t > 0 && (i += ", "), i += e.attributes.path.substr(1), o.push(e.attributes.path))
        }, this), this.setLocation(i + "(" + _WFT("search", "recursive_folder") + ")", o)
    },
    getShareStore: function() {
        return new Ext.data.Store({
            autoDestroy: !0,
            autoLoad: !0,
            proxy: new SYNO.API.Proxy({
                timeout: SYNO.webfm.Cfg.timeout,
                api: "SYNO.FileStation.List",
                method: "list_share",
                version: 2,
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    }
                }
            }),
            remoteSort: !0,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: {
                sort_by: "name",
                additional: ["indexed"]
            },
            reader: new Ext.data.JsonReader({
                root: "shares",
                id: "path"
            }, [{
                name: "path"
            }, {
                name: "type"
            }, {
                name: "text",
                mapping: "name",
                convert: function(e, t) {
                    return Ext.util.Format.htmlEncode(e)
                }
            }]),
            listeners: {
                load: {
                    fn: this.onLoadShareDone,
                    scope: this
                },
                exception: {
                    fn: this.exceptionLoadShare,
                    scope: this
                }
            }
        })
    },
    getLocalShareStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["path", "type", "text"],
            listeners: {
                exception: {
                    fn: this.exceptionLoadShare,
                    scope: this
                }
            }
        })
    },
    isSubUnSearchableDir: function(e) {
        var t = ["#recycle", "#snapshot"],
            i = !1;
        return !(Ext.isEmpty(e) || Ext.isArray(e) || !e.exec) && (Ext.iterate(t, function(t, o) {
            var n = new RegExp("/" + t + "$"),
                s = new RegExp("/" + t + "/");
            return !(i = !Ext.isEmpty(e.exec(n)) || !Ext.isEmpty(e.exec(s)))
        }), i)
    },
    getLocation: function() {
        return this.searchLocation || ""
    },
    setLocation: function(e, t) {
        var i = this.form.findField("location"),
            o = this.getComponent("btns").getComponent("btn_search");
        if (this.webfm.fileSearch.disableAdvancedSearch) return void o.disable();
        if (!this.isSubUnSearchableDir(t) && !i.disabled && !Ext.isEmpty(e)) {
            var n = "/" === e.substr(0, 1) ? 1 : 0;
            i.setValue(e.substr(n)), t = t || e, Ext.isArray(t) || (t = [t]);
            for (var s in t) t.hasOwnProperty(s) && (this.blHasIndexFolder || (this.blHasIndexFolder = SYNO.webfm.utils.IsFolderIndexed(t[s])));
            this.form.findField("enable_content_search").setValue(this.blHasIndexFolder), this.blHasIndexFolder = !1, this.selPath = t
        }
    },
    onShowHistory: function(e, t, i) {
        this.advHistoryPanel.isVisible() || t && t.keyCode == t.ENTER || this.advHistoryPanel.openPanel(e.getEl(), e, [23, 1])
    },
    onCloseHistory: function() {
        this.advHistoryPanel.isVisible() && Ext.defer(function() {
            this.advHistoryPanel.closePanel()
        }, 300, this)
    },
    onAdvHistorySelect: function(e) {
        var t, i, o, n = "";
        t = e.get("pattern"), i = e.get("folder_path"), o = e.get("recursive"), this.form.findField("keyword").setValue(t), i.forEach(function(e) {
            n += e + ", "
        }), n = n.substr(0, n.length - 2), o && (n += "(" + _WFT("search", "recursive_folder") + ")"), this.setLocation(n, i)
    },
    onHistorySearch: function(e) {
        this.onStop(), this.form.findField("keyword").setValue(e), this.searchType = "simple", this.onSearch()
    },
    hideHistoryPanel: function() {
        this.webfm.historyPanel.closePanel(), this.advHistoryPanel.closePanel()
    },
    onSearch: function(e, t) {
        if (!this.validateForm()) return void this.setMsg(_WFT("search", "least_one"));
        var i = this.form.findField("location"),
            o = i.findRecord(i.valueField, i.getValue()),
            n = {
                folder_path: o ? i.getValue() : this.selPath
            };
        o = i.getStore().getAt(i.selectedIndex), Ext.apply(n, {
            recursive: !(o && "justcurlocation" === o.get("type"))
        });
        var s;
        this.isFieldDirty("keyword") && (s = this.form.findField("keyword").getValue() || "", Ext.isEmpty(s) || Ext.apply(n, {
            pattern: s
        }));
        var r, a = "";
        if (this.isFieldDirty("extopt") && (r = this.form.findField("extopt").getValue(), !Ext.isEmpty(r))) switch (r) {
            case "fileonly":
                Ext.apply(n, {
                    filetype: "file"
                });
                break;
            case "dir":
                Ext.apply(n, {
                    filetype: "dir"
                });
                break;
            case "documents":
                a = SYNO.webfm.utils.DocumentFileTypes;
                break;
            case "videos":
                a = SYNO.webfm.utils.VideoFileTypes;
                break;
            case "pictures":
                a = SYNO.webfm.utils.ImageFileTypes;
                break;
            case "Audio":
                a = SYNO.webfm.utils.AudioFileTypes;
                break;
            case "webpages":
                a = SYNO.webfm.utils.WebPageFileTypes;
                break;
            case "executablefiles":
                a = "exe";
                break;
            case "diskimagefiles":
                a = SYNO.webfm.utils.DiscFileTypes;
                break;
            case "zippedfiles":
                a = SYNO.webfm.utils.ZippedFileTypes;
                break;
            case "file":
                this.isFieldDirty("exttext") && (a = this.form.findField("exttext").getValue())
        }
        if (Ext.isEmpty(a) || Ext.apply(n, {
                extension: a
            }), this.isFieldDirty("filesizeopt") && this.isFieldDirty("filesize") && (r = this.form.findField("filesizeopt").getValue(), !Ext.isEmpty(r))) {
            var l = 1048576 * this.form.findField("filesize").getValue();
            switch (r) {
                case "equal":
                    var h = (l >> 2) / 5;
                    h = h > 0 ? h : 1, Ext.apply(n, {
                        size_from: Math.floor(l > h ? l - h : 0)
                    }), Ext.apply(n, {
                        size_to: Math.ceil(l + h)
                    });
                    break;
                case "greater":
                    Ext.apply(n, {
                        size_from: l
                    });
                    break;
                case "less":
                    Ext.apply(n, {
                        size_to: l
                    })
            }
        }
        if (this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto")) {
            var c = this.form.findField("datetype").getValue();
            this.form.findField("searchdatefrom").value && (n[c + "_from"] = Date.parseDate(this.form.findField("searchdatefrom").value, SYNO.webfm.utils.GetDateFormat()).valueOf() / 1e3), this.form.findField("searchdateto").value && (n[c + "_to"] = Date.parseDate(this.form.findField("searchdateto").value, SYNO.webfm.utils.GetDateFormat()).valueOf() / 1e3 + 86400)
        }
        if (this.isFieldDirty("ownerpot") && this.isFieldDirty("ownertext") && (r = this.form.findField("ownerpot").getValue(), !Ext.isEmpty(r))) switch (r) {
            case "owner":
                Ext.apply(n, {
                    owner: this.form.findField("ownertext").getValue()
                });
                break;
            case "group":
                Ext.apply(n, {
                    group: this.form.findField("ownertext").getValue()
                })
        }
        n.search_content = this.form.findField("enable_content_search").getValue(), n.search_type = this.searchType, this.searchType = "advance", this.setMsg(""), this.onSendSearch(n)
    },
    onStop: function(e, t) {
        this.owner.removeTask("sendsearch");
        var i = this.searchtaskid;
        i && (this.owner.removeTask(i), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Search",
            method: "stop",
            version: 2,
            params: {
                taskid: i
            },
            callback: this.onStopDone,
            scope: this,
            single: !0
        })), this.onStopStatus()
    },
    onStopDone: function(e, t, i) {
        if (!e) {
            var o = SYNO.webfm.utils.getWebAPIErr(e, t, i);
            this.showMsg(_WFT("filetable", "filetable_search"), o)
        }
    },
    isFieldDirty: function(e) {
        return this.form.findField(e).isDirty()
    },
    validateForm: function() {
        return !!this.form.isValid() && (this.isFieldDirty("ownertext") || this.isFieldDirty("filesize") || this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto") || this.isFieldDirty("extopt") || this.isFieldDirty("exttext") || this.isFieldDirty("keyword"))
    },
    onCleanSearch: function(e) {
        if (this.dbidArr.length > 0) {
            for (var t = [], i = 0; i < this.dbidArr.length; i++) t.push(this.dbidArr[i].id);
            SYNO.API.currentManager.requestAjaxAPI("SYNO.FileStation.Search", "clean", 2, {
                async: e,
                timeout: e ? 30 : 10
            }, {
                taskid: t
            }), this.dbidArr = []
        }
    },
    onSendSearch: function(e) {
        this.onCleanSearch(!0), this.onShowHideToast(!0), this.owner.addWebAPITask({
            id: "sendsearch",
            api: "SYNO.FileStation.Search",
            method: "start",
            version: 2,
            params: e,
            callback: this.onSendSearchDone,
            scope: this,
            single: !0
        }).start(!0), this.onBeginStatus(), this.getSearchStore().params = e
    },
    onSendSearchDone: function(e, t, i) {
        if (e)
            if (t.taskid) {
                this.searchtaskid = t.taskid, this.dsStart = this.webfm.paging.cursor, this.updateRecords(!0), t.taskid != this.dbidArr[this.dbidArr.length - 1] && this.dbidArr.push({
                    id: t.taskid
                });
                var o = this.form.findField("enable_content_search").getValue();
                if (o && t.has_not_index_share && this.onShowHideToast(!1, i.folder_path), this.isVisible()) {
                    var n = this.webfm.activeView,
                        s = n === this.webfm.grid ? n.view.focusEl : n.dataView;
                    s.focus(), this.hide(), this.hideHistoryPanel()
                }
            } else this.onUpdateError(t, i), this.onFailStatus();
        else {
            var r = SYNO.webfm.utils.getWebAPIErr(e, t, i);
            this.showMsg(_WFT("filetable", "filetable_search"), r), this.onFailStatus()
        }
        this.onBeginSearchingStatus()
    },
    getUpdateRecordParams: function() {
        return {
            additional: ["real_path", "size", "owner", "time", "perm", "type"],
            taskid: this.searchtaskid,
            offset: this.dsStart,
            limit: this.webfm.paging.pageSize,
            filetype: this.webfm.showContent
        }
    },
    onBeforeStartUpdateRecords: function(e) {
        this.updateTask === e && (e.reqConfig.params = this.getUpdateRecordParams())
    },
    updateRecords: function(e) {
        if (this.updateTask && !0 === this.updateTask.running && this.updateTask.stop(), this.searchtaskid) {
            if (!this.updateTask || this.updateTask.removed) {
                this.updateTask = this.owner.addWebAPITask({
                    id: this.searchtaskid,
                    interval: 2e3,
                    api: "SYNO.FileStation.Search",
                    method: "list",
                    version: 2,
                    params: this.getUpdateRecordParams(),
                    callback: function(e, t, i) {
                        e && !0 === t.finished && this.updateTask.stop(), e ? this.onSearchDone(e, t, i) : (this.updateTask.stop(), this.onUpdateError(t, i), this.onFailStatus())
                    },
                    scope: this
                });
                var t = this.owner.getTaskRunner();
                this.mon(t, "beforestart", this.onBeforeStartUpdateRecords, this)
            }
            this.updateTask.start(e || !1)
        }
    },
    onSearchDone: function(e, t, i) {
        t.files && (Ext.isEmpty(t.files) ? this.checkSearchPage() && !this.isViewMasked() && this.maskView(_WFT("common", "searching"), "x-mask-loading") : this.onSearchUpdated(t)), t.finished && (this.onFinishStatus(), this.webfm.setDragToDesktop.call(this.webfm), (!t.files || t.files.length < 1) && this.checkSearchPage() && this.maskView(_WFT("search", "no_search_result"))), this.getSearchStore().search_taskid = this.searchtaskid
    },
    onUpdateError: function(e, t) {
        this.getSearchStore().removeAll();
        var i = SYNO.webfm.utils.getWebAPIErr(!1, e, t);
        this.maskView(i)
    },
    onSearchUpdated: function(e) {
        var t = this.getSearchGrid().getStore(),
            i = this.webfm.paging,
            o = !1,
            n = e.files;
        if (e.total != t.getTotalCount()) o = !0;
        else
            for (var s = 0; s < n.length; s++) {
                var r = t.getById(n[s].file_id),
                    a = t.getAt(s);
                if (!r || !a || n[s].file_id != a.get("file_id")) {
                    o = !0;
                    break
                }
            }
        var l = this.checkSearchPage();
        l && this.isViewMasked() && this.unmaskView(), l && o && (i.unbind(t), t.loadData(e, !1), i.bind(t), i.onLoad(t, n, {
            params: {
                offset: this.dsStart
            }
        }))
    },
    checkSearchPage: function() {
        return this.webfm.activeDS.storetype === SYNO.webfm.utils.source.remotes
    },
    isOwnerDestroyed: function() {
        return this.owner && this.owner.isDestroyed
    },
    showMsg: function(e, t) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().alert(e, t)
    },
    hideMsg: function() {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide()
    },
    getSearchStore: function() {
        return this.webfm.remoteSearchDS
    },
    getSearchGrid: function() {
        return this.webfm.grid
    },
    maskView: function(e, t) {
        return this.webfm.maskView(e, t)
    },
    unmaskView: function() {
        return this.webfm.unmaskView()
    },
    isViewMasked: function() {
        return this.webfm.isViewMasked()
    },
    initSearchDS: function(e) {
        var t = this.webfm,
            i = new Ext.data.Store({
                blSearhDone: !0,
                storetype: SYNO.webfm.utils.source.remotes,
                proxy: new SYNO.API.Proxy({
                    timeout: SYNO.webfm.Cfg.timeout,
                    api: "SYNO.FileStation.Search",
                    method: "list",
                    version: 2,
                    listeners: {
                        scope: this,
                        beforeload: function(e, t) {
                            var i = e.activeRequest.read;
                            i && Ext.Ajax.abort(i)
                        }
                    }
                }),
                reader: new Ext.data.JsonReader({
                    root: "files",
                    id: "path"
                }, t.remoteDS.reader.recordType),
                remoteSort: !0,
                pruneModifiedRecords: !0,
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                sortInfo: {
                    field: "name",
                    direction: "ASC"
                },
                baseParams: {
                    additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type"]
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = t.params,
                            o = e.fields.get(e.sortInfo.field),
                            n = o ? o.mapping || o.name : "name";
                        return n = n.split(".", 3), i.sort_by = n[2] || n[1] || n[0], this.checkSearchParams(i)
                    },
                    load: function(e, t, i) {
                        this.checkSearchPage() && this.unmaskView();
                        var o = this.getSearchGrid().getStore();
                        if (o.getTotalCount() <= this.dsStart && this.dsStart > 0) {
                            var n = Math.ceil((e.getTotalCount() - this.webfm.displayNum) / this.webfm.displayNum);
                            return void o.load({
                                params: {
                                    offset: n * this.webfm.displayNum,
                                    limit: this.webfm.displayNum
                                }
                            })
                        }
                    },
                    exception: function(e, t, i, o, n, s) {
                        this.onUpdateError(n, o.params)
                    }
                }
            });
        t.remoteSearchDS = i
    },
    checkSearchParams: function(e) {
        if (!this.searchtaskid) return !1;
        if (e.taskid = this.searchtaskid, e.limit = this.webfm.paging.pageSize, this.getSearchStore().blSearhDone) {
            var t = this.webfm.fileSearch.getValue();
            t ? e[this.webfm.fileSearch.queryParam] = t : delete e[this.webfm.fileSearch.queryParam], !0 !== this.getSearchStore().blSearchSorted && delete e.sort_by
        }
        return !0
    },
    onShowHideBtn: function(e) {
        e ? (this.btnSearch.hide(), this.btnStop.show()) : (this.btnSearch.show(), this.btnStop.hide())
    },
    onEnableDisableBtn: function(e) {
        e ? (this.btnSearch.enable(), this.btnStop.enable()) : (this.btnSearch.disable(), this.btnStop.disable())
    },
    onGridSortable: function(e) {
        this.webfm.setSortColumnModel(e)
    },
    onBeginStatus: function() {
        this.onEnableDisableBtn(!1), this.onShowHideBtn(!0), this.getSearchStore().blSearhDone = !1, this.webfm.dirTree.selectSearchNode(), this.getSearchStore().blSearchSorted = !1, this.getSearchStore().removeAll(), this.checkSearchPage() && (this.maskView(_WFT("common", "searching"), "x-mask-loading"), this.onGridSortable(!1)), this.webfm.paging.onLoad(this.getSearchStore(), null, {}), this.webfm.onChangeDisplayTypeMenu("all"), this.webfm.showContent = "all", this.searchtaskid = null, this.showSearchIcon(), this.webfm.showLoading()
    },
    onBeginSearchingStatus: function() {
        this.onEnableDisableBtn(!0), this.searchLocation = Ext.util.Format.htmlEncode(this.form.findField("location").getValue());
        var e = _WFT("search", "search_results") + ": " + this.searchLocation;
        this.webfm.pathBar.updatePathButton(0, e, e, "", !0)
    },
    onFailStatus: function() {
        this.onEnableDisableBtn(!0), this.onShowHideBtn(!1), this.getSearchStore().removeAll(), this.checkSearchPage() && this.onGridSortable(!0), this.onFinalStatus()
    },
    onFinishStatus: function() {
        this.onShowHideBtn(!1), this.checkSearchPage() && this.onGridSortable(!0), this.onFinalStatus()
    },
    onStopStatus: function() {
        this.onEnableDisableBtn(!0), this.onShowHideBtn(!1), this.checkSearchPage() && (this.unmaskView(), this.onGridSortable(!0)), this.onFinalStatus()
    },
    onDestroy: function() {
        this.onCleanSearch(!1), this.toast_box && this.toast_box.destroy()
    },
    onFinalStatus: function() {
        this.webfm.enableDisableFilterBtn(!0), this.getSearchStore().blSearhDone = !0, this.hideSearchIcon(), this.webfm.hideLoading()
    },
    isSearchableSource: function() {
        return !this.isSubUnSearchableDir(this.webfm.getCurrentDir()) && SYNO.webfm.utils.isRemoteSource(this.webfm.getCurrentSource()) && !SYNO.webfm.VFS.isVFSPath(this.webfm.getCurrentDir())
    }
}), Promise.prototype.mycatch = function(e) {
    return this.then(void 0, e)
}, Ext.define("SYNO.FileStation.SearchHistoryPanel", {
    extend: "SYNO.ux.Panel",
    limit_param: 10,
    search_type: "simple",
    constructor: function(e) {
        this.history_view = this.createHistoryView(), this.clear_btn = new SYNO.ux.Button({
            xtype: "syno_button",
            text: _WFT("search", "clear_history"),
            cls: "webfm-search-clear-history",
            handler: this.onClearHistory,
            scope: this
        });
        var t = {
            renderTo: Ext.getBody(),
            width: 189,
            autoHeight: !0,
            floating: !0,
            border: !1,
            hidden: !0,
            shadow: !1,
            cls: "webfm-search-history-panel",
            bodyStyle: "padding: 4px; font-size: 24px; background-color: #FFF;",
            autoFlexcroll: !1,
            defaults: {
                hideLabel: !0,
                anchor: "100%"
            },
            items: [this.history_view, this.clear_btn]
        };
        Ext.apply(t, e || {}), this.callParent([t]), this.bindKeyNavHandler(), this.addEvents("historyselect", "historyready")
    },
    createStore: function() {
        return this.store = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.Search.History",
                method: "get",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "history"
            }, [{
                name: "pattern"
            }, {
                name: "folder_path"
            }, {
                name: "recursive"
            }, {
                name: "timestamp"
            }]),
            baseParams: {
                offset: 0,
                limit: this.limit_param,
                search_type: this.search_type
            },
            listeners: {
                load: {
                    fn: this.showPanel,
                    scope: this
                }
            }
        }), this.store
    },
    createTemplate: function() {
        return new Ext.XTemplate('<div class="webfm-search-history-view syno-ux-combobox-list x-combo-list"><tpl for="."><div class="x-combo-list-item"><div class="webfm-search-history-pattern simple"ext:qtip="{[this.getPatternTip(values.pattern)]}">{pattern:htmlEncode}</div></div></tpl></div>', {
            getPatternTip: function(e) {
                var t = Ext.util.Format.htmlEncode(e);
                return Ext.util.Format.htmlEncode(t)
            }
        })
    },
    createHistoryView: function() {
        var e = {
            store: this.createStore(),
            tpl: this.createTemplate(),
            singleSelect: !0,
            itemSelector: "div.x-combo-list-item",
            overClass: "x-combo-selected",
            selectedClass: "x-combo-selected",
            listeners: {
                click: this.onSelect,
                mouseenter: function(e, t) {
                    this.history_view.clearSelections(), this.cur_index = t
                },
                scope: this
            }
        };
        return new Ext.DataView(e)
    },
    onSelect: function(e, t) {
        var i = this.store.getAt(t);
        i && this.fireEvent("historyselect", i.get("pattern")), this.closePanel()
    },
    onFilter: function(e) {
        e = e.trim(), this.store.filterBy(function(t) {
            return t.get("pattern").includes(e)
        }), 0 === this.store.getCount() ? this.hide() : this.isVisible() || this.showPanel(), this.cur_index = -1
    },
    onMouseDown: function(e) {
        this.isDestroyed || !this.isVisible() || this.inEl || e.within(this.getEl()) || e.within(this.alignEl) || this.closePanel()
    },
    onKeyUpHandle: function(e, t, i) {
        t.keyCode !== t.UP && t.keyCode !== t.DOWN && t.keyCode !== t.ENTER && (this.isVisible() || this.showPanel(), this.onFilter(e.getValue()))
    },
    onClearHistory: function() {
        this.sendWebAPI({
            api: "SYNO.FileStation.Search.History",
            method: "delete",
            version: 1,
            params: {
                search_type: this.search_type
            },
            scope: this
        }), this.closePanel()
    },
    openPanel: function(e, t, i) {
        this.alignEl = e, this.parentEl = t, this.position = i || [0, 0], this.mon(this.parentEl, "keyup", this.onKeyUpHandle, this), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.store.reload()
    },
    showPanel: function() {
        if (0 !== this.store.getCount() && this.alignEl) {
            this.getEl().alignTo(this.alignEl, "tr-br?", this.position);
            var e = this.webfm.owner.getEl().getStyle("z-index");
            e = parseInt(e, 10), this.getEl().setStyle("z-index", e + 1), this.show(), this.cur_index = -1, this.keyNav.enable(), this.onFilter(this.parentEl.getValue())
        }
    },
    clearHoverSelection: function() {
        if (this.clear_btn.removeClass("x-btn-over"), !(0 > this.cur_index)) {
            var e = this.history_view.getNode(this.cur_index);
            e && e.classList.remove("x-combo-selected")
        }
    },
    onUpHandler: function(e) {
        if (this.isVisible()) {
            if (this.clearHoverSelection(), 0 === this.cur_index) return this.cur_index = this.store.getCount(), void this.clear_btn.addClass("x-btn-over");
            this.history_view.select(--this.cur_index, !1)
        }
    },
    onDownHandler: function(e) {
        if (this.isVisible()) {
            if (this.clearHoverSelection(), this.store.getCount() - 1 === this.cur_index) return this.cur_index++, void this.clear_btn.addClass("x-btn-over");
            this.store.getCount() == this.cur_index && (this.cur_index = -1), this.history_view.select(++this.cur_index, !1)
        }
    },
    onEnterHandler: function(e) {
        if (!this.isVisible()) return !0;
        0 > this.cur_index || this.store.getCount() == this.cur_index ? this.onClearHistory() : this.onSelect(this, this.cur_index)
    },
    bindKeyNavHandler: function() {
        this.keyNav || (this.keyNav = new Ext.KeyNav(this.webfm.owner.getEl(), {
            up: this.onUpHandler,
            down: this.onDownHandler,
            enter: this.onEnterHandler,
            esc: this.closePanel,
            scope: this
        }), this.keyNav.disable(), this.addManagedComponent(this.keyNav))
    },
    closePanel: function() {
        this.mun(this.parentEl, "keyup", this.onKeyUpHandle, this), this.mun(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.keyNav.disable(), this.hide()
    }
}), Ext.define("SYNO.FileStation.AdvSearchHistoryPanel", {
    extend: "SYNO.FileStation.SearchHistoryPanel",
    limit_param: 5,
    search_type: "advance",
    constructor: function(e) {
        var t = {
            width: 328
        };
        Ext.apply(t, e || {}), this.callParent([t]);
        var i = new Ext.form.Label({
            text: "",
            renderTo: document.body,
            hidden: !0
        });
        this.metric = Ext.util.TextMetrics.createInstance(i.el)
    },
    createTemplate: function() {
        var e = this;
        return new Ext.XTemplate('<div class="webfm-search-history-view syno-ux-combobox-list x-combo-list"><tpl for="."><div class="x-combo-list-item"><div class="webfm-search-history-pattern advance"ext:qtip="{[this.getPatternTip(values.pattern)]}">{pattern:htmlEncode}</div><div class="webfm-search-history-path"ext:qtip="{[this.getPathTip(values.folder_path)]}">{[this.getPath(values.folder_path)]}</div></div></tpl></div>', {
            getPatternTip: function(e) {
                var t = Ext.util.Format.htmlEncode(e);
                return Ext.util.Format.htmlEncode(t)
            },
            getPath: function(t) {
                var i = "",
                    o = "",
                    n = 0;
                if (t.forEach(function(e) {
                        i += e + ", "
                    }), i = i.substr(0, i.length - 2), e.metric.getWidth(i) < 140) return Ext.util.Format.htmlEncode(i);
                for (; e.metric.getWidth(o) < 135 && n < i.length;) o = i[i.length - n - 1] + o, n++;
                return Ext.util.Format.htmlEncode("..." + o)
            },
            getPathTip: function(e) {
                var t = "";
                e.forEach(function(e) {
                    t += e + ", "
                });
                var i = Ext.util.Format.htmlEncode(t.substr(0, t.length - 2));
                return Ext.util.Format.htmlEncode(i)
            }
        })
    },
    onSelect: function(e, t) {
        var i = this.store.getAt(t);
        i && this.fireEvent("historyselect", i), this.closePanel()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.CompressDialog = function(e) {
    Ext.apply(this, e || {});
    var t = this.initArchiveOption(),
        i = {
            owner: this.owner,
            width: 495,
            height: 480,
            shadow: !0,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            resizable: !1,
            title: _WFT("filetable", "filetable_add_archive"),
            layout: "fit",
            items: t,
            footerStyle: "padding: 0 4px 0 0",
            buttons: [{
                text: _WFT("common", "common_cancel"),
                scope: this,
                handler: this.closeHandler
            }, {
                btnStyle: "blue",
                text: _WFT("common", "common_submit"),
                scope: this,
                handler: this.onCompress
            }],
            keys: [{
                key: 27,
                fn: this.closeHandler,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                },
                beforeshow: {
                    fn: function() {
                        if (this.archiveOptionForm) {
                            "zip" === this.archiveOptionForm.form.findField("compressformat").getValue() && this.setCodepageValue()
                        }
                    },
                    scope: this
                }
            }
        };
    this.addEvents({
        callback: !0
    }), SYNO.FileStation.CompressDialog.superclass.constructor.call(this, i)
}, Ext.extend(SYNO.FileStation.CompressDialog, SYNO.SDS.ModalWindow, {
    archiveOptionForm: void 0,
    codepage: void 0,
    initArchiveOption: function() {
        var e = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "mode"],
                data: [
                    ["zip", "Zip"],
                    ["7z", "7z"]
                ]
            }),
            t = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "level"],
                data: [
                    ["store", _WFT("filetable", "filetable_compression_level_store")],
                    ["fastest", _WFT("filetable", "filetable_compression_level_fastest")],
                    ["normal", _WFT("filetable", "filetable_compression_level_normal")],
                    ["best", _WFT("filetable", "filetable_compression_level_best")]
                ]
            }),
            i = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "mode"],
                data: [
                    ["replace", _WFT("filetable", "filetable_replace_file")],
                    ["update", _WFT("filetable", "filetable_update_file")],
                    ["freshen", _WFT("filetable", "filetable_freshen_file")],
                    ["synchroize", _WFT("filetable", "filetable_synchroize_file")]
                ]
            }),
            o = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: SYNO.webfm.utils.getSupportedLanguage()
            }),
            n = {
                labelAlign: "left",
                trackResetOnLoad: !0,
                waitMsgTarget: !0,
                labelWidth: 180,
                border: !1,
                items: [{
                    xtype: "syno_fieldset",
                    title: _WFT("filetable", "filetable_archive_option"),
                    synodefaults: {
                        width: 200
                    },
                    items: [{
                        xtype: "syno_textfield",
                        fieldLabel: _WFT("filetable", "filetable_archive_name"),
                        name: "archivename",
                        allowBlank: !1,
                        width: 254,
                        blankText: _WFT("compress", "compress_error_empty_name"),
                        validateOnBlur: !0,
                        scope: this,
                        validator: function(e) {
                            return SYNO.webfm.utils.checkFileLen(e) ? !SYNO.webfm.utils.isNameCharIllegal(e) || _WFT("error", "error_reserved_name") : _WFT("compress", "compress_error_long_name")
                        },
                        maxlength: 255
                    }, {
                        xtype: "syno_combobox",
                        fieldLabel: _WFT("filetable", "filetable_compression_level"),
                        name: "compresslevel",
                        store: t,
                        width: 254,
                        valueField: "value",
                        displayField: "level",
                        triggerAction: "all",
                        value: "normal",
                        editable: !1,
                        mode: "local"
                    }, {
                        xtype: "syno_combobox",
                        fieldLabel: _WFT("filetable", "filetable_compression_format"),
                        name: "compressformat",
                        store: e,
                        width: 254,
                        valueField: "value",
                        displayField: "mode",
                        triggerAction: "all",
                        value: "zip",
                        editable: !1,
                        mode: "local",
                        listeners: {
                            select: function(e, t, i, o) {
                                var n = this.archiveOptionForm.form.findField("codepage");
                                0 === i ? n.show() : n.hide()
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_combobox",
                        fieldLabel: _WFT("filetable", "filetable_update_mode"),
                        name: "compressmode",
                        store: i,
                        width: 254,
                        valueField: "value",
                        displayField: "mode",
                        triggerAction: "all",
                        value: "replace",
                        editable: !1,
                        mode: "local"
                    }, {
                        xtype: "syno_combobox",
                        fieldLabel: _WFT("common", "lang_codepage"),
                        name: "codepage",
                        store: o,
                        width: 254,
                        valueField: "value",
                        displayField: "display",
                        triggerAction: "all",
                        editable: !1,
                        mode: "local"
                    }]
                }, {
                    xtype: "syno_fieldset",
                    title: _WFT("filetable", "filetable_encryption"),
                    synodefaults: {
                        width: 200
                    },
                    items: [{
                        xtype: "syno_textfield",
                        fieldLabel: _WFT("filetable", "filetable_enter_pw"),
                        name: "enterpw",
                        textType: "password",
                        readOnly: !1,
                        width: 254,
                        maxlength: 128
                    }, {
                        xtype: "syno_textfield",
                        fieldLabel: _WFT("filetable", "filetable_reenter_pw"),
                        name: "reenterpw",
                        textType: "password",
                        readOnly: !1,
                        width: 254,
                        scope: this,
                        validateOnBlur: !0,
                        validator: function(e) {
                            return this.scope.archiveOptionForm.form.findField("enterpw").getValue() == e || _WFT("error", "error_repswd")
                        },
                        maxlength: 128
                    }]
                }],
                listeners: {
                    actionfailed: {
                        fn: this.closeHandler,
                        scope: this
                    },
                    afterrender: {
                        fn: this.setCodepageValue,
                        scope: this
                    }
                }
            },
            s = new SYNO.ux.FormPanel(n);
        return this.archiveOptionForm = s, s
    },
    setCodepageValue: function() {
        if (this.archiveOptionForm.form.findField("codepage").show(), this.codepage) return void this.archiveOptionForm.form.findField("codepage").setValue(this.codepage);
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.DSM.Info",
            method: "getinfo",
            version: 2,
            callback: function(e, t, i) {
                this.codepage = e ? t.codepage : "utf8", this.archiveOptionForm.form.findField("codepage").setValue(this.codepage), this.clearStatusBusy()
            },
            scope: this
        })
    },
    load: function(e, t, i) {
        var o = 4 > i.length ? i : i.slice(0, i.length - 4);
        SYNO.webfm.utils.checkFileLen(i, 4) && this.archiveOptionForm.form.findField("archivename").setValue(o), this.rec = e, this.targetDir = t, this.show()
    },
    closeHandler: function() {
        this.archiveOptionForm.form.reset(), this.hide(), this.fireEvent("callback")
    },
    validateForm: function(e, t, i) {
        return !!this.archiveOptionForm.form.isValid() && (t == i || "" !== i || (this.archiveOptionForm.form.findField("reenterpw").markInvalid(_WFT("error", "error_repswd")), !1))
    },
    onCompress: function(e, t) {
        t.cancel = !1;
        var i = this.archiveOptionForm.form,
            o = i.findField("archivename").getValue(),
            n = i.findField("compresslevel").getValue(),
            s = i.findField("compressmode").getValue(),
            r = i.findField("compressformat").getValue(),
            a = i.findField("enterpw").getValue(),
            l = i.findField("reenterpw").getValue(),
            h = i.findField("codepage").getValue();
        if (!this.validateForm(o, a, l)) return void(t.cancel = !0);
        var c = r.length + 1;
        if (c > o.length) o += "." + r;
        else {
            o.slice(o.length - c, o.length) !== "." + r && (o += "." + r)
        }
        this.hide(), this.fireEvent("callback", this.rec, this.targetDir, o, n, s, a, r, h), this.archiveOptionForm.form.reset()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.ExtractDialog = function(e) {
    Ext.apply(this, e || {});
    var t = this.initFileTab(),
        i = this.initPropertyTab();
    this.tabPanel = new SYNO.ux.TabPanel({
        deferredRender: !1,
        activeTab: 0,
        enableTabScroll: !0,
        plain: !0,
        items: [{
            title: _WFT("extract", "filelist"),
            layout: "fit",
            items: [t]
        }, {
            title: _WFT("common", "options"),
            layout: "fit",
            items: [i]
        }]
    });
    var o = {
        owner: this.owner,
        width: 650,
        height: 605,
        shadow: !0,
        minWidth: 200,
        minHeight: 200,
        collapsible: !1,
        autoScroll: !1,
        constrainHeader: !0,
        plain: !0,
        title: _WFT("filetable", "filetable_extract"),
        layout: "fit",
        items: this.tabPanel,
        buttons: [new SYNO.ux.Button({
            text: _WFT("common", "close"),
            scope: this,
            handler: function() {
                this.closeHandler()
            }
        }), this.btnExtract = new SYNO.ux.Button({
            btnStyle: "blue",
            text: _WFT("extract", "btn_extract_selected"),
            scope: this,
            handler: function() {
                this.onExtract(!1)
            }
        }), this.btnExtractAll = new SYNO.ux.Button({
            btnStyle: "blue",
            text: _WFT("extract", "btn_extract_all"),
            scope: this,
            handler: function() {
                this.onExtract(!0)
            }
        })],
        listeners: {
            afterlayout: {
                fn: this.center,
                scope: this,
                single: !0
            },
            hide: {
                scope: this,
                fn: function() {
                    this.dsFileList.removeAll()
                }
            },
            beforeshow: {
                fn: function() {
                    this.SetDefaultDest(this.fileID), this.InitUIElement(this.blMultiFile, this.zipPath)
                },
                scope: this
            }
        }
    };
    SYNO.FileStation.ExtractDialog.superclass.constructor.call(this, o), this.addEvents("extract:true")
}, Ext.extend(SYNO.FileStation.ExtractDialog, SYNO.SDS.ModalWindow, {
    userGrid: void 0,
    propertyform: void 0,
    userRec: null,
    groupRec: null,
    gExtractValArr: null,
    gZipPath: null,
    gDest: null,
    gUID: null,
    gGID: null,
    gIsLoading: !1,
    gZipFiles: null,
    pfiles: null,
    TreeDialog: null,
    initTToolbar: function() {
        var e = new Ext.Toolbar,
            t = new SYNO.ux.Button({
                text: _WFT("common", "common_refresh"),
                tooltip: _WFT("common", "common_refresh"),
                listeners: {
                    click: {
                        fn: function() {
                            this.dsFileList.removeAll(), this.dsFileList.reload()
                        },
                        scope: this
                    }
                }
            });
        e.add(t);
        var i = new SYNO.ux.Button({
            text: _WFT("common", "all"),
            tooltip: _WFT("common", "all"),
            listeners: {
                click: {
                    fn: function() {
                        this.fileGrid.getSelectionModel().selectAll()
                    },
                    scope: this
                }
            }
        });
        e.add(i);
        var o = new SYNO.ux.Button({
            text: _WFT("common", "none"),
            tooltip: _WFT("common", "none"),
            listeners: {
                click: {
                    fn: function() {
                        this.fileGrid.getSelectionModel().clearSelections()
                    },
                    scope: this
                }
            }
        });
        return e.add(o), e
    },
    initBToolbar: function(e) {
        var t = new Ext.Toolbar({
                height: 33
            }),
            i = new SYNO.ux.Button({
                text: _WFT("extract", "dest_folder"),
                tooltip: _WFT("extract", "dest_folder"),
                listeners: {
                    click: {
                        fn: function() {
                            this.onChooseDest()
                        },
                        scope: this
                    }
                }
            });
        t.add(i), t.addSeparator(), this.btnDest = i;
        var o = new Ext.Toolbar.TextItem("");
        t.add(o), t.addSeparator(), this.txtDest = o;
        var n = new SYNO.ux.PagingToolbar({
            store: e,
            pageSize: 100,
            displayInfo: !0
        });
        return new Ext.Panel({
            xtype: "syno_panel",
            cls: "webfm-extract-panel",
            border: !1,
            items: [t, n]
        })
    },
    initFileTab: function() {
        var e = new Ext.data.Store({
                autoDestroy: !0,
                remoteSort: !0,
                pruneModifiedRecords: !0,
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.FileStation.Extract",
                    method: "list",
                    version: 2
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    id: "name"
                }, [{
                    name: "name"
                }, {
                    name: "path"
                }, {
                    name: "size"
                }, {
                    name: "pack_size"
                }, {
                    name: "mtime"
                }, {
                    name: "is_dir"
                }, {
                    name: "fileID",
                    mapping: "item_id"
                }]),
                sortInfo: {
                    field: "name",
                    direction: "ASC"
                },
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    action: "list"
                },
                listeners: {
                    beforeload: {
                        fn: function(e, t) {
                            this.gIsLoading = !0, this.btnExtractAll.disable(), t.params.codepage = this.propertyform.form.findField("codepage").getValue(), t.params.password = this.propertyform.form.findField("pass").getValue()
                        },
                        scope: this
                    },
                    load: {
                        fn: function() {
                            this.gIsLoading = !1, this.btnExtractAll.enable(), this.btnExtract.disable(), this.onGridSelectionChanged()
                        },
                        scope: this
                    },
                    exception: {
                        fn: function(e, t, i, o, n) {
                            var s, r = _WFT("filetable", "filetable_extract");
                            n && 1403 == n.code ? (s = _WFT("extract", "extract_enter_pass"), this.getMsgBox().prompt(r, s, function(e, t) {
                                "ok" == e && (this.propertyform.form.setValues({
                                    pass: t
                                }), this.dsFileList.reload())
                            }, this, void 0, void 0, !0)) : (s = SYNO.webfm.utils.getWebAPIErrStr(!1, n, o), this.getMsgBox().alert(r, s), this.closeHandler())
                        },
                        scope: this
                    }
                }
            }),
            t = function(e, t, i, o, n, s) {
                return i.get("is_dir") ? "" : Ext.util.Format.fileSize(e)
            },
            i = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x",
            o = new Ext.grid.ColumnModel({
                defaults: {
                    sortable: !0
                },
                columns: [{
                    id: "filename",
                    header: _WFT("common", "common_filename"),
                    dataIndex: "name",
                    renderer: function(e, t, o, n, s, r) {
                        var a = Ext.util.Format.htmlEncode(e);
                        t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
                        var l = e.substr(e.lastIndexOf(".") + 1).toLowerCase(),
                            h = "misc.png";
                        return o.data.is_dir ? h = "folder.png" : -1 !== SYNO.webfm.utils.icon_type.indexOf(l) && (h = l + ".png"), String.format('<img style="padding-right:6px" width="16" height="16" src="webman/modules/FileBrowser/images/' + i + "/files_ext/{0}?v=" + _S("version") + '" align="absmiddle" />&nbsp;{1}', h, a)
                    }
                }, {
                    id: "size",
                    header: _WFT("common", "common_filesize"),
                    dataIndex: "size",
                    width: 80,
                    align: "right",
                    renderer: t
                }, {
                    id: "pack_size",
                    header: _WFT("extract", "pack_size"),
                    dataIndex: "pack_size",
                    width: 80,
                    align: "right",
                    renderer: t
                }, {
                    id: "mtime",
                    header: _WFT("filetable", "filetable_mtime"),
                    dataIndex: "mtime",
                    width: 150,
                    align: "right"
                }]
            });
        o.defaultSortable = !0;
        var n = this.initTToolbar(),
            s = this.initBToolbar(e);
        this.delayTask = new Ext.util.DelayedTask(this.onGridSelectionChanged, this);
        var r = new SYNO.ux.GridPanel({
            enableHdMenu: !1,
            ds: e,
            cm: o,
            loadMask: !0,
            autoExpandColumn: "filename",
            enableColumnMove: !1,
            enableColumnHide: !1,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: {
                        fn: function() {
                            this.delayTask.delay(100)
                        },
                        scope: this
                    }
                }
            }),
            viewConfig: {
                forceFit: !0
            },
            enableColLock: !1,
            stripeRows: !0,
            bbar: s,
            tbar: n,
            listeners: {
                render: {
                    fn: function() {
                        r.getGridEl().addClass("without-dirty-red-grid")
                    }
                },
                celldblclick: {
                    fn: function(e, t, i) {
                        var o = "",
                            n = r.getStore().getAt(t);
                        !1 !== n.get("is_dir") && (o = n.get("fileID"), this.onChangeDir(o))
                    },
                    scope: this
                },
                rowclick: {
                    fn: function(e, t, i) {
                        i && t && !i.hasModifier() && e.getSelectionModel().selectRow(t)
                    }
                }
            }
        });
        return this.dsFileList = e, this.fileGrid = r, r
    },
    initPropertyTab: function() {
        var e = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: SYNO.webfm.utils.getSupportedLanguage()
            }),
            t = {
                labelWidth: 200,
                url: "webapi/entry.cgi",
                trackResetOnLoad: !0,
                waitMsgTarget: !0,
                border: !1,
                autoScroll: !0,
                items: [{
                    xtype: "syno_fieldset",
                    title: _WFT("common", "password"),
                    synodefaults: {
                        width: 300
                    },
                    items: {
                        xtype: "syno_textfield",
                        textType: "password",
                        width: 210,
                        fieldLabel: _WFT("common", "password"),
                        name: "pass",
                        readOnly: !1
                    }
                }, {
                    xtype: "syno_fieldset",
                    title: _WFT("filetable", "filetable_overwrite"),
                    itemId: "filetable_overwrite",
                    items: {
                        xtype: "radiogroup",
                        itemId: "dup_mode",
                        columns: 1,
                        vertical: !0,
                        hideLabel: !0,
                        items: [{
                            xtype: "syno_radio",
                            boxLabel: _WFT("extract", "skip_exist"),
                            inputValue: "skip",
                            name: "dup_mode",
                            checked: !0
                        }, {
                            xtype: "syno_radio",
                            boxLabel: _WFT("filetable", "filetable_overwrite"),
                            name: "dup_mode",
                            inputValue: "overwrite",
                            checked: !1
                        }]
                    }
                }, {
                    xtype: "syno_fieldset",
                    title: _WFT("extract", "file_path"),
                    itemId: "file_path",
                    items: {
                        xtype: "radiogroup",
                        itemId: "path_mode",
                        columns: 1,
                        vertical: !0,
                        hideLabel: !0,
                        items: [{
                            xtype: "syno_radio",
                            boxLabel: _WFT("extract", "extract_full_path"),
                            inputValue: "full",
                            name: "path_mode",
                            checked: !0
                        }, {
                            xtype: "syno_radio",
                            boxLabel: _WFT("extract", "extract_no_path"),
                            name: "path_mode",
                            inputValue: "none",
                            checked: !1
                        }]
                    }
                }, {
                    xtype: "syno_fieldset",
                    title: _WFT("common", "lang_codepage"),
                    synodefaults: {
                        width: 300
                    },
                    items: [{
                        xtype: "syno_combobox",
                        width: 200,
                        fieldLabel: _WFT("common", "lang_codepage"),
                        hiddenName: "codepage",
                        store: e,
                        displayField: "display",
                        valueField: "value",
                        triggerAction: "all",
                        editable: !1,
                        mode: "local",
                        listeners: {
                            select: {
                                fn: function() {
                                    "none" !== this.tabPanel.getTabEl(0).style.display && (this.dsFileList.removeAll(), this.dsFileList.reload())
                                },
                                scope: this
                            }
                        }
                    }]
                }, {
                    xtype: "syno_fieldset",
                    itemId: "dest_field",
                    title: _WFT("extract", "dest_folder"),
                    viewConfig: {
                        forceFit: !0
                    },
                    items: [{
                        xtype: "syno_button",
                        itemId: "btnDestField",
                        text: _WFT("extract", "dest_folder"),
                        scope: this,
                        handler: this.onChooseDest
                    }, {
                        xtype: "syno_displayfield",
                        itemId: "txtDestField",
                        hideLabel: !0,
                        htmlEncode: !1,
                        name: "extract_dest",
                        value: ""
                    }]
                }],
                listeners: {
                    actionfailed: {
                        fn: function(e, t) {
                            var i = _WFT("filetable", "filetable_extract"),
                                o = _WFT("error", "error_error_system");
                            this.owner.getMsgBox().alert(i, o), this.closeHandler()
                        },
                        scope: this
                    }
                }
            },
            i = new SYNO.ux.FormPanel(t);
        return this.dest_field = i.get("dest_field"), this.btnDestField = this.dest_field.getComponent("btnDestField"), this.txtDestField = this.dest_field.getComponent("txtDestField"), this.propertyform = i, i
    },
    onGridSelectionChanged: function() {
        var e = this.fileGrid.getSelectionModel(),
            t = e.getCount();
        0 === t ? this.btnExtract.disable() : this.gIsLoading || 1 == t && ".." == e.getSelected().get("name") ? this.btnExtract.disable() : this.btnExtract.enable()
    },
    onChooseDest: function() {
        this.TreeDialog && !this.TreeDialog.isDestroyed || (this.TreeDialog = new SYNO.FileStation.TreeDialog({
            RELURL: this.RELURL,
            blDynamicForm: !1,
            blVFSFolder: !1,
            owner: this,
            webfm: this.webfm
        }), this.TreeDialog.mon(this.TreeDialog, "beforesubmit", this.onCheckDestPrivilege, this), this.TreeDialog.mon(this.TreeDialog, "callback", this.onTreeDialogHide, this)), this.TreeDialog.load(_WFT("filetable", "filetable_extract"), !1, this.gUID, this.gGID, this.gDest)
    },
    onCheckDestPrivilege: function(e) {
        var t = this.TreeDialog;
        if (t) {
            if (!0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
            if (!SYNO.webfm.utils.checkShareRight(e.shareRight, SYNO.webfm.utils.RW)) return t.getMsgBox().alert(_WFT("filetable", "filetable_extract"), _WFT("error", "error_privilege_not_enough")), !1;
            if (Ext.isDefined(e.folderRight)) {
                var i = {
                    right: e.folderRight,
                    needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Extract
                };
                if (!SYNO.webfm.utils.checkFileRight(i)) return t.getMsgBox().alert(_WFT("filetable", "filetable_extract"), _WFT("error", "error_privilege_not_enough")), !1
            }
            return !0
        }
    },
    onTreeDialogHide: function() {
        var e = this.TreeDialog;
        if (e) {
            var t = e.getParameters();
            t.fdrName && this.UpdateTargetPath(t.fdrName)
        }
    },
    onChangeDir: function(e) {
        this.dsFileList.baseParams.item_id = e, this.dsFileList.load({
            params: {
                start: 0,
                limit: 100
            }
        })
    },
    LoadFileList: function(e) {
        this.gZipPath = e, this.dsFileList.baseParams.file_path = e, this.dsFileList.baseParams.item_id = -1, this.dsFileList.load({
            params: {
                start: 0,
                limit: 100
            }
        }), this.propertyform.load({
            params: {
                api: "SYNO.DSM.Info",
                method: "getinfo",
                version: 2
            },
            waitMsg: _WFT("common", "loading")
        })
    },
    InitGlobalVal: function() {
        this.gZipPath = null, this.gExtractValArr = null, this.gDest = null
    },
    InitUIElement: function(e, t) {
        this.btnExtract.disable(), e ? (this.dest_field.show(), this.tabPanel.hideTabStripItem(0), this.btnExtractAll.enable(), this.propertyform.load({
            params: {
                api: "SYNO.DSM.Info",
                method: "getinfo",
                version: 2
            },
            waitMsg: _WFT("common", "loading")
        }), this.tabPanel.setActiveTab(1)) : (this.dest_field.hide(), this.tabPanel.unhideTabStripItem(0), this.btnExtractAll.disable(), this.LoadFileList(t), this.tabPanel.setActiveTab(0)), this.fileGrid.getColumnModel().setHidden(1, this.zipPath && "bz2" === SYNO.webfm.utils.getExt(this.zipPath))
    },
    load: function(e, t, i, o, n) {
        if ("" !== t && "" !== e) {
            var s = 605,
                r = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl().getHeight() : Ext.lib.Dom.getViewHeight();
            r < s && (s = r), this.setSize(this.width, s), this.gUID = i, this.gGID = o, this.InitGlobalVal(), this.fileID = e, this.blMultiFile = n, this.zipPath = t, this.show().center()
        }
    },
    SetPathFiles: function(e) {
        this.pFiles = e
    },
    GetPathFiles: function() {
        return this.pFiles
    },
    SetMultiZipFile: function(e) {
        this.gZipFiles = e
    },
    GetMultiZipFile: function() {
        return this.gZipFiles
    },
    SetDefaultDest: function(e) {
        var t, i = e,
            o = "";
        if (-1 == (t = i.lastIndexOf("/"))) return !1;
        o = i.substr(0, t), this.UpdateTargetPath(o)
    },
    UpdateTargetPath: function(e) {
        this.gDest = e, this.txtDest.getEl().update("<b>" + Ext.util.Format.htmlEncode(e) + "</b>"), this.txtDestField.setRawValue("<b>" + Ext.util.Format.htmlEncode(e) + "</b>")
    },
    closeHandler: function() {
        this.delayTask.cancel(), this.propertyform.form.reset(), this.hide()
    },
    onExtract: function(e) {
        this.SaveOptions(e) && this.fireEvent("extract")
    },
    SaveOptions: function(e) {
        var t = this.fileGrid.getSelectionModel(),
            i = "",
            o = [];
        e || (i = t.getSelections(), o = SYNO.webfm.utils.ParseArr(i, "fileID"));
        var n = this.propertyform.get("filetable_overwrite").get("dup_mode").getValue().inputValue,
            s = this.propertyform.form.findField("pass").getValue(),
            r = this.propertyform.get("file_path").get("path_mode").getValue().inputValue,
            a = this.propertyform.form.findField("codepage").getValue();
        return Ext.isEmpty(this.gDest) ? (this.getMsgBox().alert(_WFT("filetable", "filetable_extract"), _WFT("filetable", "filetable_select_path")), !1) : (this.gExtractValArr = {
            zipPath: this.gZipPath,
            dest: this.gDest,
            all: e,
            files: o,
            mode: n,
            pass: s,
            pathMode: r,
            codepage: a
        }, !0)
    },
    getOptions: function() {
        return this.gExtractValArr
    }
}), Ext.define("SYNO.FileStation.Utils.SharingManager.EditSharingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    params: null,
    oriValue: null,
    deleteWhenCancel: null,
    fakePwd: "1234567890",
    webapi: {
        set: {
            api: "SYNO.Core.Sharing",
            method: "set",
            version: 1
        }
    },
    constructor: function(e) {
        this.formPanel = this.createFormPanel(e), this.params = {}, Ext.apply(this.params, e.params), delete e.params;
        var t = {
            cls: "syno-webfm-edit-sharing-dialog",
            width: 700,
            height: 500,
            resizable: !1,
            collapsible: !1,
            layout: "fit",
            title: _T("sharing", "sharing_links"),
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCloseBtn
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                scope: this,
                handler: this.onSaveBtn
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            },
            items: [this.formPanel]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    getBtnBar: function() {
        return this.sharingCopyBtn = new SYNO.SDS.Utils.ClipBoardButton({
            tooltip: _WFT("sharing", "copy_url"),
            iconCls: "webfm-sharing-btn-icon copy-btn-icon",
            btnStyle: "grey",
            clipCfg: {
                clipTarget: "webfm-sharing-links-text-area"
            },
            listeners: {
                clipsucceed: function(e) {
                    SYNO.webfm.utils.showMessage(this, _WFT("sharing", "copy_to_clipboard"))
                },
                scope: this
            }
        }), this.sharingMailBtn = new SYNO.ux.Button({
            tooltip: _WFT("sharing", "mail_file_link"),
            iconCls: "webfm-sharing-btn-icon mail-btn-icon",
            listeners: {
                click: this.onBuildInMail,
                scope: this
            }
        }), this.sharingQRCodeBtn = new SYNO.ux.Button({
            tooltip: _T("sharing", "get_qrcode"),
            iconCls: "webfm-sharing-btn-icon qrcode-btn-icon",
            listeners: {
                click: this.onQRCodeBtn,
                scope: this
            }
        }), new SYNO.ux.Toolbar({
            style: {
                "padding-left": "208px",
                "padding-bottom": "30px",
                border: "0px"
            },
            items: [this.sharingCopyBtn, this.sharingMailBtn, this.sharingQRCodeBtn]
        })
    },
    getLinkSettingFieldSet: function(e) {
        return {
            xtype: "syno_fieldset",
            title: _WFT("file_sharing", "link_settings"),
            itemId: "link_setting_fieldset",
            collapsible: !0,
            collapsed: !1,
            bwrapStyle: {
                padding: "12px 8px 8px 8px"
            },
            items: [this.getSharingLinkTextAreaConfig(e), this.getBtnBar(), this.getSecurityFieldConfigs(e)]
        }
    },
    getSharingLinkTextAreaConfig: function(e) {
        return {
            xtype: "container",
            layout: "hbox",
            style: {
                margin: "0 0 6px 0"
            },
            items: [{
                xtype: "syno_displayfield",
                width: 200,
                value: _WFT("sharing", "links_to_share") + ":"
            }, {
                xtype: "syno_textarea",
                id: "webfm-sharing-links-text-area",
                margins: "0 0 0 8",
                name: "url",
                width: 476,
                height: this.paths && 1 < this.paths.length ? 68 : 28,
                readOnly: !0,
                autoFlexcroll: !0,
                selectOnFocus: !0
            }]
        }
    },
    getUserStore: function(e) {
        return new SYNO.API.JsonStore({
            autoDestroy: !0,
            api: "SYNO.Core.ACL",
            method: "list_owners",
            version: 1,
            root: "owners",
            appWindow: e.owner,
            idProperty: "value",
            fields: ["name", "type", {
                name: "value",
                convert: function(e, t) {
                    return t.name + ":" + t.type
                }
            }],
            remoteSort: !0,
            pruneModifiedRecords: !0,
            baseParams: {
                type: "all"
            }
        })
    },
    getSecurityFieldConfigs: function(e) {
        var t = this.getUserStore(e),
            i = new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item acl-icon-combo-item acl-combo-item-{type}" id="{[Ext.id()]}" aria-label="{name:htmlEncode}" role="option">{name}</div>', "</tpl>"),
            o = new Ext.XTemplate('<div class="acl-icon-combo-item acl-combo-item-{type} sharing-combo-item-{type}" id="{[Ext.id()]}" aria-label="{name:htmlEncode}" role="option">{name}</div>'),
            n = _S("is_admin") || e.enableListUserGrp;
        return this.protectUserGroup = new SYNO.ux.SuperBoxSelect({
            name: "protect_users_groups",
            itemId: "protect_users_groups",
            width: 448,
            tabIndex: -1,
            valueField: "value",
            displayField: "name",
            displayFieldTpl: o,
            tpl: i,
            triggerAction: "all",
            mode: n ? "remote" : "local",
            queryParam: "prefix",
            minChars: 2,
            allowQueryAll: n,
            listEmptyText: n ? _T("error", "error_invalid_user_group") : "",
            pageSize: 50,
            disabled: !0,
            editable: !0,
            allowBlank: !1,
            blankText: _T("sharing", "dsm_user_alert"),
            grow: !0,
            typeAhead: !0,
            allowAddNewData: !0,
            addNewDataOnBlur: !0,
            store: t,
            fieldLabel: _T("helptoc", "personal_account"),
            listeners: {
                listInitialized: function() {
                    this.mon(t, "load", this.onUserStoreLoad, this)
                },
                scope: this
            }
        }), this.protectPassword = new SYNO.ux.TextField({
            name: "protect_password",
            itemId: "protect_password",
            width: 448,
            tabIndex: -1,
            hidden: !0,
            disabled: !0,
            allowBlank: !1,
            enableKeyEvents: !0,
            textType: "password",
            fieldLabel: _T("sharing", "enter_password"),
            listeners: {
                scope: this,
                focus: this.onProtectPasswordFocus,
                keyup: function() {
                    this.protectPassword.validate()
                }
            }
        }), this.secureFieldSet = new SYNO.ux.FieldSet({
            itemId: "secure_fieldset",
            disabled: !0,
            bwrapCfg: {
                padding: 0
            },
            labelWidth: 203,
            bodyStyle: {
                "padding-left": "28px",
                "margin-bottom": "8px"
            },
            items: [{
                xtype: "syno_combobox",
                name: "protect_type",
                itemId: "protect_rule",
                fieldLabel: _WFT("sharing", "protect_rule"),
                width: 448,
                tabIndex: -1,
                value: "user",
                valueField: "protected_type",
                displayField: "display",
                store: {
                    xtype: "jsonstore",
                    fields: ["protected_type", "display"],
                    data: [{
                        protected_type: "user",
                        display: _WFT("sharing", "protected_type_internal")
                    }, {
                        protected_type: "password",
                        display: _WFT("sharing", "protected_type_public")
                    }]
                },
                listeners: {
                    select: function(e, t) {
                        "user" === t.get("protected_type") ? (this.protectPassword.hide(), this.protectUserGroup.show(), this.protectUserGroup.enable(), this.protectPassword.disable()) : (this.protectUserGroup.hide(), this.protectPassword.show(), this.protectPassword.enable(), this.protectUserGroup.disable())
                    },
                    scope: this
                }
            }, this.protectUserGroup, this.protectPassword]
        }), [{
            xtype: "syno_checkbox",
            name: "protect_type_enable",
            boxLabel: _T("sharing", "restrict_sharing"),
            tabIndex: -1,
            listeners: {
                scope: this,
                check: function(e, t) {
                    t ? (this.secureFieldSet.enable(), "user" === this.secureFieldSet.get("protect_rule").getValue() ? (this.protectUserGroup.enable(), this.protectPassword.disable()) : "password" === this.secureFieldSet.get("protect_rule").getValue() && (this.protectPassword.enable(), this.protectUserGroup.disable())) : (this.secureFieldSet.disable(), this.protectUserGroup.disable(), this.protectPassword.disable(), this.protectUserGroup.validate(), this.protectPassword.validate())
                }
            }
        }, this.secureFieldSet]
    },
    getAdvanceFieldSet: function(e) {
        var t = new Date,
            i = new Date(t.getTime() + 864e5),
            o = {
                editable: !1,
                isAllDay: !1,
                allowBlank: !1,
                width: 380,
                disabled: !0,
                style: {
                    "margin-left": "8px"
                },
                validator: this.isValidTime.createDelegate(this)
            };
        this.startDateTimeField = new SYNO.ux.DateTimeField(Ext.apply(o, {
            name: "start_at",
            value: t,
            listeners: {
                change: function() {
                    this.expireDateTimeField.setMinValue(this.startDateTimeField.getValue())
                },
                scope: this
            }
        })), this.expireDateTimeField = new SYNO.ux.DateTimeField(Ext.apply(o, {
            name: "expire_at",
            minValue: t,
            value: i,
            listeners: {
                change: function() {
                    this.startDateTimeField.validate()
                },
                scope: this
            }
        }));
        var n = {
            width: 268,
            margins: "0 0 0 28"
        };
        return this.startCheckbox = new SYNO.ux.Checkbox(Ext.apply(n, {
            boxLabel: _WFT("sharing", "setup_start_time"),
            name: "start_at_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.startDateTimeField.enable() : this.startDateTimeField.disable(), this.startDateTimeField.validate()
                },
                scope: this
            }
        })), this.expireCheckbox = new SYNO.ux.Checkbox(Ext.apply(n, {
            boxLabel: _WFT("sharing", "setup_stop_time"),
            name: "expire_at_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.expireDateTimeField.enable() : this.expireDateTimeField.disable(), this.expireDateTimeField.validate()
                },
                scope: this
            }
        })), this.limitTimesTextField = new SYNO.ux.NumberField({
            name: "expire_times",
            itemId: "expire_times",
            width: 380,
            indent: 1,
            value: 99,
            minValue: 0,
            maxlength: 4,
            vtype: "number",
            disabled: !0,
            style: {
                "margin-left": "8px"
            }
        }), this.limitTimesCheckbox = new SYNO.ux.Checkbox(Ext.apply(n, {
            boxLabel: _WFT("sharing", "number_allowed_access"),
            name: "expire_times_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.limitTimesTextField.enable() : this.limitTimesTextField.disable()
                },
                scope: this
            }
        })), this.advanceFieldSet = new SYNO.ux.FieldSet({
            title: _WFT("sharing", "adv_opt"),
            itemId: "advance_fieldset",
            collapsible: !0,
            collapsed: !0,
            bwrapStyle: {
                padding: "12px 8px 8px 8px"
            },
            items: [{
                xtype: "syno_displayfield",
                fieldLabel: _WFT("sharing", "validity_period"),
                labelSeparator: ""
            }, {
                xtype: "container",
                itemId: "start_setting",
                layout: "hbox",
                style: {
                    "margin-bottom": "6px"
                },
                items: [this.startCheckbox, this.startDateTimeField]
            }, {
                xtype: "container",
                itemId: "expire_setting",
                layout: "hbox",
                style: {
                    "margin-bottom": "6px"
                },
                items: [this.expireCheckbox, this.expireDateTimeField]
            }, {
                xtype: "syno_displayfield",
                fieldLabel: _WFT("sharing", "number_allowed_access"),
                labelSeparator: ""
            }, {
                xtype: "container",
                layout: "hbox",
                style: {
                    "margin-bottom": "6px"
                },
                items: [this.limitTimesCheckbox, this.limitTimesTextField]
            }]
        }), this.advanceFieldSet
    },
    getFormItemConfigs: function(e) {
        return [].concat(this.getLinkSettingFieldSet(e)).concat(this.getAdvanceFieldSet(e))
    },
    createFormPanel: function(e) {
        return new SYNO.ux.FormPanel({
            border: !1,
            updateFormForScrollbar: !0,
            items: this.getFormItemConfigs(e)
        })
    },
    setValues: function(e) {
        if (e.start_at ? (e.start_at instanceof Date || (e.start_at = Date.parseDate(e.start_at, "Y-m-d H:i:s")), this.startCheckbox.setValue(!0)) : e.start_at = new Date, e.expire_at) e.expire_at instanceof Date || (e.expire_at = Date.parseDate(e.expire_at, "Y-m-d H:i:s")), this.expireCheckbox.setValue(!0);
        else {
            var t = new Date;
            e.expire_at = new Date(t.getTime() + 864e5)
        }
        e.expire_times ? this.limitTimesCheckbox.setValue(!0) : e.expire_times = 99, e.protect_type && "none" !== e.protect_type && (e.protect_type_enable = !0), "password" === e.protect_type ? (e.protect_password = this.fakePwd, this.protectPassword.show(), this.protectPassword.enable(), this.protectUserGroup.hide()) : "user" === e.protect_type ? (this.protectUserGroup.show(), this.protectUserGroup.enable(), this.protectPassword.hide()) : e.protect_type = "user";
        var i = this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups");
        i.enable(), (e.protect_users || e.protect_groups) && (e.protect_users_groups = [], e.protect_users && Ext.each(e.protect_users, function(t) {
            e.protect_users_groups.push(t + ":user"), i.addNewItem({
                name: Ext.util.Format.htmlEncode(t),
                type: "user",
                value: t + ":user"
            })
        }), e.protect_groups && Ext.each(e.protect_groups, function(t) {
            e.protect_users_groups.push(t + ":group"), i.addNewItem({
                name: Ext.util.Format.htmlEncode(t),
                type: "group",
                value: t + ":group"
            })
        })), i.disable(), this.isProtectPasswordEdited = !1, this.params.app = void 0 !== this.params.app ? this.params.app : {}, this.params.project_name = void 0 !== this.params.project_name ? this.params.project_name : "", this.params.sharing_id = e.hash, Ext.apply(this.params.app, e.app), this.params.redirect_type = void 0 !== this.params.redirect_type ? this.params.redirect_type : e.redirect_type, this.params.redirect_uri = void 0 !== this.params.redirect_uri ? this.params.redirect_uri : e.redirect_uri, this.params.auto_gc = void 0 !== this.params.auto_gc ? this.params.auto_gc : e.auto_gc, this.params.enable_match_ip = void 0 !== this.params.enable_match_ip ? this.params.enable_match_ip : e.enable_match_ip, this.params.enabled = void 0 !== this.params.enabled ? this.params.enabled : e.enabled, this.params.url = e.url, this.params.qrcode = e.qrcode, this.params.path = e.path, e.url = Ext.isArray(e.url) ? e.url.join("\n") : e.url, this.formPanel.getForm().setValues(e), this.oriValue = this.getValues()
    },
    getValues: function() {
        var e, t = this.formPanel.getForm().getValues();
        return this.startCheckbox.getValue() ? t.start_at = this.startDateTimeField.getValue().format("Y-m-d H:i:s") : t.start_at = "", this.expireCheckbox.getValue() ? t.expire_at = this.expireDateTimeField.getValue().format("Y-m-d H:i:s") : t.expire_at = "", this.limitTimesCheckbox.getValue() ? t.expire_times = this.limitTimesTextField.getValue() : t.expire_times = 0, "true" !== t.protect_type_enable && (t.protect_type = "none"), t.protect_users_groups && (Ext.isArray(t.protect_users_groups) || (t.protect_users_groups = [t.protect_users_groups]), t.protect_users = [], t.protect_groups = [], Ext.each(t.protect_users_groups, function(i) {
            (e = i.match(/(.*):user$/)) ? t.protect_users.push(e[1]): (e = i.match(/(.*):group$/)) && t.protect_groups.push(e[1])
        })), t.protect_password && (this.fakePwd !== t.protect_password || this.isProtectPasswordEdited) || delete t.protect_password, "password" !== t.protect_type || t.protect_password || delete t.protect_type, t.redirect_uri || delete t.redirect_uri, Ext.apply(t, this.params), t
    },
    getFinalValues: function() {
        return this.oriValue
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    isValidTime: function() {
        var e = this.startDateTimeField.getValue(),
            t = this.expireDateTimeField.getValue(),
            i = new Date;
        return this.expireCheckbox.getValue() && t <= i ? _WFT("error", "exp_before_today") : !(this.startCheckbox.getValue() && this.expireCheckbox.getValue() && e >= t) || String.format(_T("sharing", "time_set_error"), _T("sharing", "start_at_time"), _T("sharing", "expire_at_time"))
    },
    isUsersGroup: function(e) {
        return !!e && !("guest" !== e && "users" !== e && !e.match(/^users@.*/i) && !e.match(/.*\\Domain Users$/i))
    },
    handleErrors: function(e) {
        switch (SYNO.Debug.error(e), this.setStatusError(_T("common", "error_system")), e.code) {
            case 1009:
                this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups").markInvalid(_T("sharing", "error_entry_user"));
                break;
            case 1010:
                this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_password").markInvalid(_T("sharing", "error_entry_passwd"))
        }
    },
    onUserComboNewItem: function(e, t) {
        if (t && !this.isUsersGroup(t)) {
            var i = "@" === t[0] ? "group" : "user",
                o = "@" === t[0] ? t.substr(1, t.length) : t;
            e.addNewItem({
                name: Ext.util.Format.htmlEncode(o),
                type: i,
                value: o + ":" + i
            }, !0)
        }
    },
    onUserStoreLoad: function(e, t, i) {
        var o = this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups"),
            n = o.pageTb;
        Ext.each(t, function(t) {
            this.isUsersGroup(t.data.name) && e.remove(t)
        }, this), !0 === this.disableLastPage && n.getPageData().activePage === this.lastPage - 1 && (n.setBtnText(n.btn4, ""), n.next.disable(), n.last.disable()), e.getCount() <= 0 && (this.disableLastPage = !0, this.lastPage = n.getPageData().activePage, 1 < this.lastPage && n.jumpPageByOffset(-1))
    },
    onAfterRender: function() {
        var e = this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups");
        _S("is_admin") || this.mon(e, "newitem", this.onUserComboNewItem, this)
    },
    onProtectPasswordFocus: function(e) {
        e.setValue(null), this.isProtectPasswordEdited = !0
    },
    onBuildInMail: function() {
        SYNO.webfm.utils.buildSharingQRCodeMail(this.getValues().url, this.getValues().qrcode)
    },
    onSaveBtn: function() {
        if (this.isValid()) {
            var e = this.getValues();
            if (SYNO.ux.Utils.checkObjectConsistency(e, this.oriValue)) return void this.close();
            this.setStatusBusy(), this.sendWebAPI(Ext.apply({
                params: e,
                scope: this,
                callback: function(t, i, o, n) {
                    this.clearStatusBusy(), t ? (this.oriValue = e, this.close()) : this.handleErrors(i)
                }
            }, this.webapi.set))
        }
    },
    onCloseBtn: function() {
        var e = this.getValues();
        this.deleteWhenCancel ? this.sendWebAPI({
            api: "SYNO.Core.Sharing",
            method: "delete",
            version: 1,
            params: {
                sharing_id: e.sharing_id
            },
            scope: this,
            callback: function(e, t, i, o) {
                e || (SYNO.Debug.error(t), this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"))), this.close()
            }
        }) : this.close()
    },
    onQRCodeBtn: function() {
        var e = this.getValues();
        new SYNO.FileStation.Utils.QRCodeDialog({
            owner: this,
            path: Ext.isArray(e.path) ? e.path : [e.path],
            qrcode: Ext.isArray(e.qrcode) ? e.qrcode : [e.qrcode]
        }).open()
    }
}), Ext.define("SYNO.FileStation.EditSharingDialog", {
    extend: "SYNO.FileStation.Utils.SharingManager.EditSharingDialog",
    constructor: function(e) {
        this.urls = [], this.files = [], this.linkIDs = [], this.filenames = [], this.linkQRCodes = [], Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t]), this.addEvents("onEditDone")
    },
    fillConfig: function(e) {
        var t = _WFT("sharing", "share_public_user");
        e.paths && Ext.isArray(e.paths) && (t += " (" + e.paths.length + " " + _JSLIBSTR("uicommon", e.paths.length > 1 ? "items" : "item") + ")");
        var i = {
            title: t,
            width: 740,
            height: 480
        };
        return Ext.apply(i, e || {}), i
    },
    getFormItemConfigs: function() {
        var e = this.callParent(arguments);
        return e[0].items.splice(0, 0, this.getPathFieldConfig()), e
    },
    getPathFieldConfig: function() {
        return this.filePathDisplayField = new SYNO.ux.DisplayField({
            xtype: "syno_displayfield",
            width: 394,
            margins: "0 0 0 8",
            htmlEncode: !0
        }), {
            xtype: "container",
            layout: "hbox",
            align: "stretch",
            style: {
                "margin-bottom": "2px"
            },
            items: [{
                xtype: "syno_displayfield",
                width: 200,
                value: _WFT("common", "file_path") + ":"
            }, this.filePathDisplayField, {
                xtype: "syno_displayfield",
                width: 80,
                tabIndex: 0,
                style: {
                    "text-align": "right"
                },
                htmlEncode: !1,
                html: this.paths && 1 < this.paths.length ? "<a class=pathlink>" + _WFT("sharing", "view_all") + "</a>" : "",
                listeners: {
                    afterrender: function(e, t) {
                        e.getEl().on("click", function() {
                            if ("A" === arguments[0].target.nodeName) {
                                var e = this.getValues();
                                this.viewAllPanel = new SYNO.FileStation.Utils.ViewAllDialog({
                                    owner: this,
                                    path: Ext.isArray(e.path) ? e.path : [e.path],
                                    url: Ext.isArray(e.url) ? e.url : [e.url]
                                }), this.viewAllPanel.open()
                            }
                        }, this)
                    },
                    scope: this
                }
            }]
        }
    },
    getUserStore: function(e) {
        return new SYNO.API.JsonStore({
            autoDestroy: !0,
            api: "SYNO.FileStation.UserGrp",
            method: "list_all",
            version: 1,
            root: "owners",
            appWindow: e.owner,
            idProperty: "value",
            fields: ["name", "type", {
                name: "value",
                convert: function(e, t) {
                    return t.name + ":" + t.type
                }
            }],
            remoteSort: !0,
            pruneModifiedRecords: !0,
            baseParams: {
                type: "all"
            }
        })
    },
    onAfterRender: function() {
        this.callParent(arguments), this.onUpdateForm()
    },
    onUpdateForm: function() {
        var e = {
            path: this.files,
            url: this.urls,
            qrcode: this.linkQRCodes
        };
        Ext.isEmpty(this.link_info) ? this.setValues(e) : (Ext.apply(this.link_info, e), this.setValues(this.link_info));
        var t = this.files[0],
            i = '<div style="text-overflow: ellipsis; overflow: hidden" ext:qtip="' + t + '">' + t + "</div>";
        this.filePathDisplayField.update(i)
    },
    onPrepareParam: function() {
        var e = [],
            t = [],
            i = this.getValues();
        return i.id = this.linkIDs, Ext.isEmpty(i.protect_password) || (i.password = i.protect_password, delete i.protect_password), Ext.isEmpty(i.expire_at) || (i.date_expired = i.expire_at, delete i.expire_at), Ext.isEmpty(i.start_at) || (i.date_available = i.start_at, delete i.start_at),
            Ext.isEmpty(i.protect_users) ? delete i.protect_users : (Ext.isEmpty(this.link_info) || Ext.isEmpty(this.link_info.protect_users) ? e = i.protect_users : i.protect_users.forEach(function(t) {
                -1 === this.link_info.protect_users.indexOf(t) && e.push(t)
            }, this), i.new_protect_users = e), Ext.isEmpty(i.protect_groups) ? delete i.protect_groups : (Ext.isEmpty(this.link_info) || Ext.isEmpty(this.link_info.protect_groups) ? t = i.protect_groups : i.protect_groups.forEach(function(e) {
                -1 === this.link_info.protect_groups.indexOf(e) && t.push(e)
            }, this), i.new_protect_groups = t), delete i.app, delete i.plugins, delete i.auto_gc, delete i.enabled, delete i.qrcode, delete i.sharing_id, delete i.project_name, delete i.redirect_type, delete i.enable_match_ip, delete i.protect_users_groups, i
    },
    onSaveBtn: function() {
        if (!this.isValid()) return void this.getMsgBox().alert("", _T("common", "forminvalid"));
        var e = this.onPrepareParam();
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "edit",
            version: 3,
            params: e,
            scope: this,
            encryption: ["password"],
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("onEditDone", this), this.webfm.FileAction.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, "sharing"), this.close()) : this.onShowError(_WFT("error", "error_error_system"))
            }
        })
    },
    onCloseBtn: function() {
        this.close()
    },
    onShowError: function(e) {
        var t = _WFT("common", "share");
        this.getMsgBox().alert(t, e, function(e) {
            this.close()
        }, this)
    },
    copyUrlToClipBoard: function() {
        var e = this.formPanel.getForm().findField("url").el.dom;
        e.select && e.select();
        try {
            this.copySuccess = !!document.execCommand && document.execCommand("copy"), e.selectionStart = e.selectionEnd = -1
        } catch (e) {
            SYNO.Debug(e)
        }
    }
}), Ext.define("SYNO.FileStation.SharingDialog", {
    extend: "SYNO.FileStation.EditSharingDialog",
    constructor: function(e) {
        this.callParent(arguments)
    },
    getFormItemConfigs: function() {
        this.validSharedLinks = [];
        var e = this.callParent(arguments);
        return 1 === this.paths.length && this.getLinksByPathAndCreateLink(this.paths[0].get("file_id")), 1 <= this.validSharedLinks.length && e[0].items.splice(0, 0, this.getLinkBtnBarConfig()), e
    },
    getLinkBtnBarConfig: function() {
        var e = [];
        return this.createNewLinkBtn = new SYNO.ux.Button({
            text: _WFT("sharing", "create_new_link"),
            height: 28,
            listeners: {
                click: function() {
                    this.onCreateLinks(this.files), SYNO.webfm.utils.showMessage(this, _WFT("sharing", "link_be_updated")), this.otherLinksBtn.show()
                },
                scope: this
            }
        }), e.push(this.createNewLinkBtn), this.otherLinksBtn = new SYNO.ux.Button({
            text: _WFT("sharing", "other_link"),
            height: 28,
            hidden: 1 >= this.validSharedLinks.length,
            listeners: {
                click: function() {
                    this.getLinksByPathAndCreateLink(this.paths[0].get("file_id")), this.pastLinkPanel = new SYNO.FileStation.Utils.PastLinkDialog({
                        owner: this,
                        links: this.validSharedLinks
                    }), this.pastLinkPanel.open()
                },
                scope: this
            }
        }), e.push(this.otherLinksBtn), new SYNO.ux.Toolbar({
            items: e,
            height: 44,
            style: {
                border: "0",
                padding: "0"
            }
        })
    },
    onSetFiles: function() {
        var e = 0;
        Ext.isArray(this.paths) && this.paths.forEach(function(t) {
            this.files[e] = t.get("file_id"), this.filenames[e] = t.get("filename"), e++
        }, this)
    },
    onAfterRender: function() {
        this.onSetFiles(), this.callParent(arguments), (1 < this.files.length || 0 === this.validSharedLinks.length) && this.onCreateLinks(this.files)
    },
    getLinksByPathAndCreateLink: function(e) {
        var t = {
                check_link_history: !0,
                path: e,
                sort_by: "id",
                sort_direction: "dec",
                filter_type: "SYNO.SDS.App.FileStation3.Instance"
            },
            i = [];
        this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "list",
            version: 3,
            async: !1,
            timeout: 10,
            params: t,
            callback: function(e, t, o) {
                if (e && Ext.isArray(t.links)) {
                    var n, s = t.links.length;
                    if (0 === s) return;
                    n = 1 === s ? t : {
                        links: [t.links[0]],
                        hasFolder: !1
                    }, this.setLinksInfo(n);
                    var r = n.links[0];
                    this.link_info = {
                        start_at: r.date_available,
                        expire_at: r.date_expired,
                        expire_times: r.expire_times,
                        protect_type: r.protect_type,
                        protect_users: r.protect_users
                    }, Ext.each(t.links, function(e) {
                        i.push(e)
                    })
                } else {
                    var a = SYNO.webfm.utils.getWebAPIErr(e, t, o);
                    this.onShowError(a)
                }
            },
            scope: this
        }), this.validSharedLinks = i, this.justCreate = !1
    },
    onCreateLinks: function(e) {
        var t = {
            path: e
        };
        this.setStatusBusy({
            text: _WFT("sharing", "creating_new_link")
        }), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "create",
            version: 3,
            params: t,
            scope: this,
            callback: this.onCreateCallback
        }), this.justCreate = !0
    },
    onCreateCallback: function(e, t, i) {
        if (this.clearStatusBusy(), e && Ext.isArray(t.links)) this.formPanel.getForm().reset(), delete this.link_info, this.setLinksInfo(t), this.onUpdateForm();
        else {
            var o = SYNO.webfm.utils.getWebAPIErr(e, t, i);
            this.onShowError(o)
        }
    },
    setLinksInfo: function(e) {
        this.urls = [], this.linkIDs = [], this.linkQRCodes = [], this.hasFolder = e.has_folder;
        var t, i = e.links,
            o = i.length,
            n = 0;
        for (n = 0; n < o; n++) t = i[n], this.urls.push(t.error ? "" : t.url), this.linkIDs.push(t.error ? "" : t.id), this.linkQRCodes.push(t.error ? "" : t.qrcode)
    },
    onCloseBtn: function() {
        this.justCreate ? (this.setStatusBusy(), this.onDeleteLinks()) : this.close()
    },
    onDeleteLinks: function() {
        this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "delete",
            version: 3,
            params: {
                id: this.linkIDs
            },
            scope: this,
            callback: function(e, t) {
                this.clearStatusBusy(), e ? this.close() : this.onShowError(_WFT("error", "error_error_system"))
            }
        })
    }
}), Ext.define("SYNO.FileStation.Utils.BaseDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = {
            resizale: !1,
            collapsible: !1,
            layout: "fit",
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    onBuildInMail: function(e) {
        SYNO.webfm.utils.buildSharingQRCodeMail(e.url, e.qrcode)
    },
    onQRCodeBtn: function(e) {
        new SYNO.FileStation.Utils.QRCodeDialog({
            owner: this,
            path: [e.path],
            qrcode: [e.qrcode]
        }).open()
    }
}), Ext.define("SYNO.FileStation.Utils.PastLinkDialog", {
    extend: "SYNO.FileStation.Utils.BaseDialog",
    constructor: function(e) {
        this.panel = this.createFormPanel(e);
        var t = {
            width: 580,
            height: 400,
            resizable: !1,
            cls: "syno-webfm-sharing-past-link-panel",
            title: _WFT("sharing", "links_shared_so_far"),
            items: [this.panel]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    createFormPanel: function(e) {
        var t = [],
            i = e.links,
            o = this;
        return Ext.each(i, function(e) {
            var i = o.createSingleLinkPanel(e);
            t.push(i)
        }), new SYNO.ux.FormPanel({
            layout: {
                type: "vbox"
            },
            bwrapCfg: {
                padding: "0"
            },
            bodyStyle: {
                padding: "0"
            },
            items: t
        })
    },
    createSingleLinkPanel: function(e) {
        var t = Ext.id(),
            i = this.getLinkInfoString(e);
        return {
            xtype: "container",
            layout: "vbox",
            style: {
                "padding-bottom": "16px"
            },
            items: [{
                xtype: "container",
                layout: "hbox",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-webfm-sharing-link",
                    width: 120,
                    value: _WFT("sharing", "link") + ":"
                }, this.createToolBar(t, e)]
            }, {
                xtype: "container",
                layout: "hbox",
                hidden: !i,
                style: {
                    "margin-top": "6px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    width: 120
                }, {
                    xtype: "syno_displayfield",
                    width: 412,
                    margins: "0 0 0 8",
                    height: this.isTwoLine ? 56 : 28,
                    html: i
                }]
            }]
        }
    },
    createToolBar: function(e, t) {
        var i = new SYNO.ux.TextField({
            id: e,
            cls: "syno-webfm-sharing-past-link-field",
            width: 304,
            height: 28,
            style: {
                "margin-right": "6px"
            },
            readOnly: !0,
            selectOnFocus: !0,
            value: t.url,
            listeners: {
                render: function(e) {
                    new Ext.ToolTip({
                        target: e.el.dom,
                        html: t.url
                    })
                }
            }
        });
        return this.clipBtn = new SYNO.SDS.Utils.ClipBoardButton({
            tooltip: _WFT("sharing", "copy_url"),
            iconCls: "webfm-sharing-btn-icon copy-btn-icon",
            btnStyle: "grey",
            clipCfg: {
                clipTarget: e
            },
            listeners: {
                clipsucceed: function(e) {
                    SYNO.webfm.utils.showMessage(this, _WFT("sharing", "copy_to_clipboard"))
                },
                scope: this
            }
        }), this.sharingMailBtn = new SYNO.ux.Button({
            tooltip: _WFT("sharing", "mail_file_link"),
            iconCls: "webfm-sharing-btn-icon mail-btn-icon",
            listeners: {
                click: function() {
                    this.onBuildInMail(t)
                },
                scope: this
            }
        }), this.sharingQRCodeBtn = new SYNO.ux.Button({
            tooltip: _T("sharing", "get_qrcode"),
            iconCls: "webfm-sharing-btn-icon qrcode-btn-icon",
            listeners: {
                click: function() {
                    this.onQRCodeBtn(t)
                },
                scope: this
            }
        }), new SYNO.ux.Toolbar({
            style: {
                border: "0px",
                padding: "0px 0px 0px 8px",
                margin: "0px"
            },
            items: [i, this.clipBtn, this.sharingMailBtn, this.sharingQRCodeBtn]
        })
    },
    getLinkInfoString: function(e) {
        var t = "",
            i = 0;
        return (e.date_available || e.date_expired) && (t += e.date_available + " - " + e.date_expired, e.date_available && i++, e.date_expired && i++), "password" !== e.protect_type && "user" !== e.protect_type || (1 === i ? t += " | " : 2 === i && (t += " |<br>"), "password" === e.protect_type ? t += _WFT("sharing", "password_protected") : t += _WFT("sharing", "login_needed"), i++), 0 < e.expire_times && (1 === i || 3 === i ? t += " | " : 2 === i && (t += " |<br>"), t += String.format(_WFT("sharing", "times_left"), e.expire_times), i++), this.isTwoLine = i > 2, t
    }
}), Ext.define("SYNO.FileStation.Utils.ViewAllDialog", {
    extend: "SYNO.FileStation.Utils.BaseDialog",
    constructor: function(e) {
        this.panel = this.createFormPanel(e);
        var t = {
            width: 550,
            height: 400,
            resizale: !1,
            cls: "syno-webfm-sharing-viewall-panel",
            title: _WFT("sharing", "paths_and_links"),
            items: [this.panel]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    createFormPanel: function(e) {
        var t = [],
            i = e.path,
            o = e.url,
            n = this;
        return Ext.each(i, function(e, i) {
            var s = n.createSingleLinkPanel(e, o[i]);
            t.push(s)
        }), new SYNO.ux.FormPanel({
            layout: {
                type: "vbox"
            },
            cls: "syno-webfm-sharing-viewall-formpanel",
            items: t
        })
    },
    createSingleLinkPanel: function(e, t) {
        var i = Ext.id();
        this.clipBtn = new SYNO.SDS.Utils.ClipBoardButton({
            tooltip: _WFT("sharing", "copy_url"),
            iconCls: "webfm-sharing-btn-icon copy-btn-icon",
            btnStyle: "grey",
            clipCfg: {
                clipTarget: i
            },
            listeners: {
                clipsucceed: function(e) {
                    SYNO.webfm.utils.showMessage(this, _WFT("sharing", "copy_to_clipboard"))
                },
                scope: this
            }
        });
        var o = new SYNO.ux.Toolbar({
                style: {
                    border: "0px"
                },
                items: [{
                    xtype: "syno_textfield",
                    cls: "syno-webfm-sharing-past-link-field",
                    id: i,
                    width: 334,
                    height: 28,
                    style: {
                        "margin-right": "6px"
                    },
                    readOnly: !0,
                    selectOnFocus: !0,
                    value: t,
                    listeners: {
                        render: function(e) {
                            new Ext.ToolTip({
                                target: e.el.dom,
                                html: t
                            })
                        }
                    }
                }, this.clipBtn]
            }),
            n = '<div style="text-overflow: ellipsis; overflow: hidden" ext:qtip="' + e + '">' + e + "</div>";
        return {
            xtype: "container",
            layout: "vbox",
            style: {
                "padding-bottom": "16px"
            },
            items: [{
                xtype: "container",
                layout: "hbox",
                items: [{
                    xtype: "syno_displayfield",
                    width: 120,
                    value: _T("common", "file_path") + ":"
                }, {
                    xtype: "syno_displayfield",
                    width: 300,
                    height: 28,
                    margins: "0 0 0 8",
                    html: n
                }]
            }, {
                xtype: "container",
                layout: "hbox",
                items: [{
                    xtype: "syno_displayfield",
                    width: 120,
                    value: _WFT("sharing", "links_to_share") + ":"
                }, o]
            }]
        }
    }
}), Ext.define("SYNO.FileStation.Utils.QRCodeDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.panel = this.createPanel(e);
        var t = {
            width: 300,
            height: 380,
            cls: "syno-webfm-sharing-qrcode-panel",
            resizable: !1,
            collapsible: !1,
            layout: "fit",
            title: _WFT("sharing", "qrcode_links"),
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }],
            items: [this.panel]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    createPanel: function(e) {
        return new SYNO.ux.Panel({
            layout: {
                type: "hbox",
                align: "center",
                pack: "center"
            },
            items: [this.createQRComp(e.path, e.qrcode)]
        })
    },
    createQRComp: function(e, t) {
        var i = 1,
            o = [],
            n = t.length > e.length ? t.length : e.length;
        Ext.each(e, function(e) {
            var t = e.replace(/^.*[\/]/, "");
            o.push(t)
        });
        var s = new SYNO.ux.DisplayField({
                width: 200,
                itemId: "filename",
                cls: "webfm-sharing-qrcode-filename",
                html: '<div style="text-overflow:ellipsis; overflow:hidden; white-space:nowrap" ext:qtip="' + o[i - 1] + '">' + o[i - 1] + "</div>"
            }),
            r = new SYNO.ux.DisplayField({
                width: 200,
                height: 24,
                itemId: "page",
                style: {
                    "text-align": "center",
                    color: "#505A64"
                },
                html: this.getPageInfoHTML(i, n)
            });
        this.QRCodeBox = new Ext.Container({
            itemId: "qrcode",
            cls: "webfm-sharing-qrcode-box",
            style: {
                "text-align": "center"
            },
            margins: "24 27 0 27",
            width: 130,
            height: 130,
            html: this.getQRCodeHtml(t[i - 1])
        });
        var a = new SYNO.ux.Button({
            text: _WFT("sharing", "download_all_qrcode"),
            margins: "24 0 0 0",
            height: 28,
            listeners: {
                click: function() {
                    var e, i = /^(data:image\/png;base64)/;
                    if (1 === n) {
                        e = t[0].replace(i, "");
                        var s = this.dataURItoBlob(e);
                        saveAs(s, this.getDownloadFileName(o[0]))
                    } else {
                        for (var r = new JSZip, a = 0; a < n; a++) {
                            e = t[a].replace(i, "");
                            r.folder("qrcode").file(this.getDownloadFileName(o[a]), e, {
                                base64: !0
                            })
                        }
                        r.generateAsync({
                            type: "blob"
                        }).then(function(e) {
                            saveAs(e, "QRCode.zip")
                        })
                    }
                },
                scope: this
            }
        });
        return new Ext.Container({
            layout: {
                type: "vbox",
                align: "center"
            },
            items: [{
                xtype: "container",
                layout: {
                    type: "hbox",
                    align: "center"
                },
                items: [{
                    xtype: "syno_button",
                    cls: "webfm-sharing-qrcode-prev",
                    width: 48,
                    height: 84,
                    hidden: 1 === n,
                    margins: "47 0 0 0",
                    listeners: {
                        click: function() {
                            i > 1 ? i-- : i = n;
                            var e = '<div style="text-overflow:ellipsis; overflow:hidden; white-space:nowrap" ext:qtip="' + o[i - 1] + '">' + o[i - 1] + "</div>";
                            s.update(e), r.update(this.getPageInfoHTML(i, n)), this.QRCodeBox.update(this.getQRCodeHtml(t[i - 1]))
                        },
                        scope: this
                    }
                }, this.QRCodeBox, {
                    xtype: "syno_button",
                    cls: "webfm-sharing-qrcode-next",
                    width: 48,
                    height: 84,
                    hidden: 1 === n,
                    margins: "47 0 0 0",
                    listeners: {
                        click: function() {
                            i < n ? i++ : i = 1;
                            var e = '<div style="text-overflow:ellipsis; overflow:hidden; white-space:nowrap" ext:qtip="' + o[i - 1] + '">' + o[i - 1] + "</div>";
                            s.update(e), r.update(this.getPageInfoHTML(i, n)), this.QRCodeBox.update(this.getQRCodeHtml(t[i - 1]))
                        },
                        scope: this
                    }
                }]
            }, s, r, a]
        })
    },
    getPageInfoHTML: function(e, t) {
        return 1 === t ? "<span></span>" : '<span style="font-weight: 900">' + e + "</span> / " + t
    },
    getQRCodeHtml: function(e) {
        return '<img src="' + e + '">'
    },
    dataURItoBlob: function(e) {
        for (var t = atob(e.split(",")[1]), i = e.split(",")[1].split(":")[0].split(";")[0], o = new ArrayBuffer(t.length), n = new Uint8Array(o), s = 0; s < t.length; s++) n[s] = t.charCodeAt(s);
        return new Blob([o], {
            type: i
        })
    },
    getDownloadFileName: function(e) {
        var t, i = 0;
        for (t = 0; t < e.length && !((i += e.charCodeAt(t) < 256 ? 1 : 2) >= 240); ++t);
        return e.substr(0, t).split(".").join("-") + "-QRcode.png"
    }
}), Ext.ns("SYNO.FileStation"), Ext.define("SYNO.FileStation.RenameDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.checkName = !0, Ext.apply(this, e || {});
        var t = this.init(),
            i = {
                owner: this.owner,
                width: 500,
                height: 180,
                shadow: !0,
                collapsible: !1,
                resizable: !1,
                autoScroll: !1,
                constrainHeader: !0,
                closeAction: "closeHandler",
                plain: !0,
                title: _WFT("filetable", "filetable_rename"),
                layout: "fit",
                items: t,
                buttons: [{
                    text: _WFT("common", "common_cancel"),
                    scope: this,
                    handler: this.closeHandler
                }, {
                    btnStyle: "blue",
                    text: _WFT("common", "common_submit"),
                    scope: this,
                    handler: this.saveNewName
                }],
                listeners: {
                    afterlayout: {
                        fn: this.onAfterLayout,
                        scope: this,
                        single: !0
                    }
                }
            };
        this.addEvents({
            check: !0,
            callback: !0
        }), this.callParent([i])
    },
    init: function() {
        var e = {
                labelWidth: 75,
                labelAlign: "top",
                trackResetOnLoad: !0,
                waitMsgTarget: !0,
                border: !1,
                bodyStyle: "padding: 0 4px",
                autoFlexcroll: !1,
                items: [{
                    xtype: "syno_textfield",
                    itemId: "newname",
                    fieldLabel: _WFT("filetable", "filetable_enter_newname"),
                    name: "newname",
                    maxlength: 255,
                    anchor: "100%",
                    enableKeyEvents: !0,
                    listeners: {
                        keypress: function(e, t) {
                            t.getKey() === Ext.EventObject.ENTER && this.saveNewName()
                        },
                        buffer: 100,
                        scope: this
                    }
                }],
                listeners: {
                    actionfailed: this.onActionFailed,
                    scope: this
                }
            },
            t = new SYNO.ux.FormPanel(e);
        return this.RenameForm = t, t
    },
    onAfterLayout: function() {
        this.focusEl = this.RenameForm.form.findField("newname"), this.center()
    },
    onActionFailed: function() {
        this.closeHandler()
    },
    onShow: function() {
        this.el.center(this.owner.el), this.callParent(arguments)
    },
    callbackHandler: function() {
        this.hide(), this.fireEvent("callback")
    },
    closeHandler: function() {
        this.RenameForm.form.isDirty() ? this.getMsgBox().confirm(_WFT("filetable", "filetable_rename"), _WFT("common", "confirm_lostchange"), function(e) {
            "yes" == e && this.callbackHandler()
        }, this) : this.callbackHandler()
    },
    setCheckRecs: function(e) {
        this.check_recs = e
    },
    getCheckRecs: function() {
        return this.check_recs
    },
    saveNewName: function() {
        var e = "";
        if (!this.RenameForm || !this.RenameForm.form.findField("newname")) return void this.closeHandler();
        if (!this.RenameForm.form.isDirty()) return void this.closeHandler();
        if (e = this.RenameForm.form.findField("newname").getValue(), !(e = Ext.util.Format.trim(e))) return void this.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_empty_name"));
        if (this.checkName) {
            if (!SYNO.webfm.utils.checkFileLen(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_long_path"));
            if (SYNO.webfm.utils.isNameReserved(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_reserved_name"));
            if (SYNO.webfm.utils.isNameCharIllegal(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_reserved_name"));
            if (this.getCheckRecs() && !1 === SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this, "rename", this.getCheckRecs(), {
                    arg1: e,
                    fn: this.onSaveName.bind(this, e)
                })) return
        }
        this.onSaveName(e)
    },
    onSaveName: function(e) {
        this.newName = e, this.callbackHandler()
    },
    resetDialogForm: function() {
        this.RenameForm && this.RenameForm.form.reset()
    },
    getNewName: function() {
        return this.newName
    },
    resetNewName: function() {
        this.newName = null
    },
    setParentDir: function(e) {
        this.parentDir = e
    },
    getParentDir: function() {
        return this.parentDir
    },
    setOldName: function(e) {
        this.oldName = e
    },
    getOldName: function() {
        return this.oldName
    },
    setCurrentDir: function(e) {
        this.currentDir = e
    },
    getCurrentDir: function() {
        return this.currentDir
    },
    setCheckName: function(e) {
        SYNO.webfm.utils.isLocalSource(e) ? this.checkName = !1 : this.checkName = !0
    },
    setDefaultText: function() {
        var e = this.getOldName();
        e && this.RenameForm && this.RenameForm.form.findField("newname") && this.RenameForm.form.setValues({
            newname: e
        })
    },
    setIsDir: function(e) {
        this.isDir = e
    },
    getIsDir: function(e) {
        return this.isDir
    },
    setSelection: function(e, t, i) {
        if (e.createTextRange) {
            var o = i - t,
                n = e.createTextRange();
            n.collapse(!0), n.moveStart("character", t), n.moveEnd("character", o), n.select()
        } else e.setSelectionRange && e.setSelectionRange(t, i);
        e.focus()
    },
    setFileNameSelection: function() {
        var e = this.RenameForm.form.findField("newname").getEl().dom,
            t = this.getOldName(),
            i = t.lastIndexOf(".");
        e && (!0 === this.getIsDir() ? this.setSelection(e, 0, t.length) : -1 !== i ? this.setSelection(e, 0, i) : this.setSelection(e, 0, t.length))
    },
    load: function() {
        this.resetDialogForm(), this.resetNewName(), this.setDefaultText(), this.show(), this.setFileNameSelection()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.MountTypeConfig = Ext.extend(Object, {
    type: void 0,
    constructor: function(e) {
        var t = {
            iso: {
                title_list: _WFT("mount", "virtual_device"),
                header_source: _WFT("mount", "image_file"),
                hideProtocol: !0
            },
            remote: {
                title_list: _WFT("mount", "remote_volume"),
                header_source: _WFT("mount", "server_ip"),
                hideProtocol: !1
            }
        };
        if (this.type = e, !(this.type in t)) throw Error("unknown mount type");
        Ext.apply(this, t[this.type])
    }
}), SYNO.FileStation.MountGrid = Ext.extend(SYNO.ux.GridPanel, {
    type: void 0,
    typeConfig: null,
    constructor: function(e) {
        Ext.copyTo(this, e, "owner,type,typeConfig,RELURL,itemId"), this.createStore(), this.createActions();
        var t = [this.getAction("unmount")];
        if ("iso" === e.type) t.push(this.getAction("remount"));
        else {
            if ("remote" !== e.type) throw Error("unknown type");
            t.push(this.getAction("reconnect"))
        }
        var i = new Ext.Toolbar({
                defaultType: "syno_button",
                items: t
            }),
            o = Ext.apply({
                title: this.typeConfig.title_list,
                store: this.getStore(),
                colModel: this.createColumnModel(),
                autoExpandColumn: "mount_point",
                stripeRows: !0,
                keys: this.getHotKeyMap(),
                selModel: new Ext.grid.RowSelectionModel({
                    singleSelect: !1
                }),
                tbar: i,
                listeners: {
                    activate: this.onActivate,
                    rowcontextmenu: this.onRowCtxMenu,
                    containercontextmenu: this.showCtxMenu,
                    scope: this
                }
            }, e);
        SYNO.FileStation.MountGrid.superclass.constructor.call(this, o)
    },
    initEvents: function() {
        SYNO.FileStation.MountGrid.superclass.initEvents.apply(this, arguments), this.mon(this.getSelectionModel(), "selectionchange", this.checkState, this, {
            buffer: 50
        })
    },
    onActivate: function() {
        this.getStore().fireEvent("datachanged", this.getStore())
    },
    createStore: function() {
        return this.store = new Ext.data.JsonStore({
            root: "items",
            id: "name",
            fields: ["type", "source", "mount_point", "actor", "date", "auto_mount"],
            autoDestroy: !0
        }), this.store
    },
    createColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: _WFT("mount", "protocol"),
            dataIndex: "type",
            width: 80,
            hidden: this.typeConfig.hideProtocol
        }, {
            header: this.typeConfig.header_source,
            dataIndex: "source",
            width: this.typeConfig.hideProtocol ? 280 : 200
        }, {
            id: "mount_point",
            header: _WFT("mount", "mount_point"),
            dataIndex: "mount_point",
            width: 200
        }, {
            header: _WFT("mount", "actor"),
            dataIndex: "actor",
            width: 100
        }, {
            header: _WFT("mount", "mount_date"),
            dataIndex: "date",
            width: 80,
            renderer: function(e) {
                return e ? SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e), {
                    type: "datetimesec"
                }) : ""
            }
        }, {
            header: _WFT("mount", "auto_mount"),
            dataIndex: "auto_mount",
            renderer: function(e) {
                return e ? "yes" === e ? _T("common", "yes") : "no" === e ? _T("common", "no") : "fail" === e ? _T("usbbackup", "usbbkp_error") : "" : ""
            },
            width: 80
        }])
    },
    actions: null,
    createActions: function() {
        var e = function(e, t, i, o) {
            return new Ext.Action(Ext.apply({
                text: e,
                scope: i,
                handler: t
            }, o))
        };
        return this.actions = {
            unmount: e(_WFT("mount", "umount"), this.beforeUnMount, this),
            remount: e(_WFT("common", "remount"), this.onRemount, this),
            reconnect: e(_WFT("common", "reconnect"), this.onReconnect, this)
        }, this.actions
    },
    getAction: function(e) {
        return e in this.actions ? this.actions[e] : void SYNO.Debug("no this action: " + e)
    },
    enableAction: function(e, t) {
        var i = this.getAction(e);
        i && i[t ? "enable" : "disable"]()
    },
    initCtxMenu: function() {
        if (!this.gridCtxMenu) {
            var e = [this.getAction("unmount")];
            "iso" === this.type ? e.push(this.getAction("remount")) : "remote" === this.type && e.push(this.getAction("reconnect")), this.gridCtxMenu = new SYNO.ux.Menu({
                items: e
            }), this.checkState()
        }
    },
    getCtxMenu: function() {
        return this.gridCtxMenu || this.initCtxMenu(), this.gridCtxMenu
    },
    onRowCtxMenu: function(e, t, i) {
        var o = this.getSelectionModel();
        o.isSelected(t) || o.selectRow(t), this.showCtxMenu(e, i)
    },
    showCtxMenu: function(e, t) {
        this.getCtxMenu().showAt(t.getXY())
    },
    checkState: function() {
        var e = this.getSelectionModel().getCount();
        this.enableAction("unmount", 0 < e), this.enableAction("remount", 0 < e), this.enableAction("reconnect", 0 < e)
    },
    loadData: function(e) {
        this.getStore().loadData({
            success: !0,
            items: e
        }), this.checkState()
    },
    onRemount: function() {
        var e = this.ownerCt.getActiveTab().getItemId();
        this.owner.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Mount.List",
            method: "remount",
            version: 1,
            params: {
                mount_type: e
            },
            scope: this,
            callback: function(e, t, i, o) {
                if (this.owner.clearStatusBusy(), !e) return this.owner.getMsgBox().alert(this.title, SYNO.webfm.utils.getWebAPIErr(e, t, o)), void SYNO.SDS.FocusMgr.focusActiveWindow.defer(100);
                this.owner.webfm.reloadTree(), this.owner.loadData(t), SYNO.SDS.FocusMgr.focusActiveWindow.defer(100)
            }
        })
    },
    onReconnect: function() {
        var e = [];
        Ext.each(this.getSelectionModel().getSelections(), function(t) {
            e.push(t.get("mount_point"))
        }), this.owner.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Mount.List",
            method: "reconnect",
            version: 1,
            params: {
                mount_point: e
            },
            scope: this,
            callback: function(e, t, i, o) {
                if (this.owner.clearStatusBusy(), !e) return this.owner.getMsgBox().alert(this.title, SYNO.webfm.utils.getWebAPIErr(e, t, o)), void SYNO.SDS.FocusMgr.focusActiveWindow.defer(100);
                this.owner.webfm.reloadTree(), this.owner.loadData(t), SYNO.SDS.FocusMgr.focusActiveWindow.defer(100)
            }
        })
    },
    listeners: {
        scope: this,
        afterrender: {
            fn: function(e) {
                e.getEl().on("keyup", function(t) {
                    var i = e.getCmdCode();
                    Ext.isArray(i) ? e.cmdKeyDown = e.cmdKeyDown && -1 === i.indexOf(t.getKey()) : e.cmdKeyDown = e.cmdKeyDown && i !== t.getKey()
                }, this)
            }
        }
    },
    onSelectAllRowAction: function() {
        Ext.isMac && !this.cmdKeyDown || this.getSelectionModel().selectAll()
    },
    getCmdCode: function() {
        return SYNO.webfm.utils.getCmdCode()
    },
    getHotKeyMap: function() {
        if (Ext.isMac) {
            var e = this.getCmdCode();
            this.keys = [{
                key: e,
                fn: function() {
                    this.cmdKeyDown = !0
                },
                scope: this
            }, {
                key: Ext.EventObject.A,
                fn: this.onSelectAllRowAction,
                stopEvent: !0,
                scope: this
            }]
        } else this.keys = [{
            key: Ext.EventObject.A,
            ctrl: !0,
            fn: this.onSelectAllRowAction,
            scope: this
        }];
        return this.keys
    },
    beforeUnMount: function() {
        var e = [];
        Ext.each(this.getSelectionModel().getSelections(), function(t) {
            e.push(t.get("mount_point"))
        }), this.owner.getMsgBox().confirm(this.title, String.format(_WFT("mount", "umount_confirm") + "<br>" + e.join(", "), this.title), function(e) {
            "yes" === e && this.onUnMount()
        }, this)
    },
    onUnMount: function() {
        var e = [],
            t = this.getSelectionModel().getSelections();
        Ext.each(t, function(t) {
            e.push(t.get("mount_point"))
        }), this.owner.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Mount.List",
            method: "unmount",
            version: 1,
            params: {
                mount_point: e
            },
            scope: this,
            callback: function(i, o, n, s) {
                if (!i) return this.owner.clearStatusBusy(), this.owner.getMsgBox().alert(this.title, SYNO.webfm.utils.getWebAPIErr(i, o, s)), void SYNO.SDS.FocusMgr.focusActiveWindow.defer(100);
                this.onUnmountDone(o, e, t), this.owner.webfm.reloadTree(), this.owner.loadData(o)
            }
        })
    },
    onUnmountDone: function(e, t, i) {
        var o, n, s, r = [],
            a = [],
            l = 0,
            h = !1;
        for (l = 0; l < e.UseDefPathList.length; l++) "yes" == e.UseDefPathList[l].UseDefPath && (h = !0, s = new Ext.data.Record({
            file_id: "",
            path: "",
            isdir: !0
        }), o = SYNO.webfm.utils.getParentDirArr(t[l]), n = o[0].indexOf("/", 1), r.push(o[0].substr(n)), s.set("file_id", t[l].substr(n)), s.set("path", i[l].get("mount_point")), a.push(s));
        if (h) {
            var c = {
                    pFiles: SYNO.webfm.utils.ParseArr(a, "file_id"),
                    srcIdArr: SYNO.webfm.utils.getParentDirArr(a)
                },
                d = SYNO.webfm.utils.ParsePairArr(a, "file_id", r).sort(function(e, t) {
                    return e.file < t.file
                }).map(function(e) {
                    return e.file
                });
            this.owner.sendWebAPI({
                api: "SYNO.FileStation.Delete",
                method: "start",
                version: 2,
                params: {
                    path: d,
                    accurate_progress: !0,
                    recursive: !1
                },
                scope: this,
                callback: function(e, t, i, o) {
                    this.owner.module.onDeleteSendDone(e, t, c, o), this.owner.clearStatusBusy()
                }
            })
        } else this.owner.clearStatusBusy()
    }
}), SYNO.FileStation.MountListDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    isoTypeConfig: null,
    remoteTypeConfig: null,
    constructor: function(e) {
        Ext.copyTo(this, e, "webfm,owner,RELURL"), this.isoTypeConfig = new SYNO.FileStation.MountTypeConfig("iso"), this.remoteTypeConfig = new SYNO.FileStation.MountTypeConfig("remote");
        var t = Ext.apply({
            title: _WFT("mount", "mount_list"),
            width: 740,
            height: 400,
            layout: "fit",
            buttons: [{
                text: _WFT("common", "close"),
                scope: this,
                handler: this.close
            }],
            items: [{
                xtype: "syno_tabpanel",
                activeTab: 0,
                plain: !0,
                itemId: "tabpanel",
                items: [new SYNO.FileStation.MountGrid({
                    owner: this,
                    type: "iso",
                    typeConfig: this.isoTypeConfig,
                    RELURL: this.RELURL,
                    itemId: "iso"
                }), new SYNO.FileStation.MountGrid({
                    owner: this,
                    type: "remote",
                    typeConfig: this.remoteTypeConfig,
                    RELURL: this.RELURL,
                    itemId: "remote"
                })]
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                },
                beforeshow: {
                    fn: function() {
                        this.load()
                    },
                    scope: this
                }
            }
        }, e);
        SYNO.FileStation.MountListDialog.superclass.constructor.call(this, t)
    },
    getTab: function(e) {
        return this.getComponent("tabpanel").getComponent(e)
    },
    load: function() {
        this.el.isMasked() || this.el.mask(_WFT("common", "loading"), "x-mask-loading"), this.sendWebAPI({
            api: "SYNO.FileStation.Mount.List",
            version: 1,
            method: "get",
            scope: this,
            callback: function(e, t, i, o) {
                if (this.el.unmask(), !e) return this.getMsgBox().alert(this.title, SYNO.webfm.utils.getWebAPIErrStr(e, t, o), this.close, this), !1;
                this.loadData(t)
            }
        })
    },
    loadData: function(e) {
        var t = 0;
        return !(!e || !e.mountConfig) && (e.mountConfig.enable_iso_mount ? (this.getTab("iso").loadData(e.isoList), this.webfm.btnMountISO && this.webfm.btnMountISO.show(), this.webfm.gridCtxMenu.items.get("gc_mount_iso") && this.webfm.gridCtxMenu.items.get("gc_mount_iso").show()) : (this.getComponent("tabpanel").hideTabStripItem("iso"), this.getComponent("tabpanel").setActiveTab("remote"), this.webfm.btnMountISO && this.webfm.btnMountISO.hide(), this.webfm.gridCtxMenu.items.get("gc_mount_iso") && this.webfm.gridCtxMenu.items.get("gc_mount_iso").hide(), t++), e.mountConfig.enable_remote_mount ? (this.getTab("remote").loadData(e.remoteList), this.webfm.btnMountRemote && (_S("is_admin") || this.webfm.dirTree.getNodeById("remote/home") ? this.webfm.btnMountRemote.show() : this.webfm.btnMountRemote.hide())) : (this.getComponent("tabpanel").hideTabStripItem("remote"), this.webfm.btnMountRemote && this.webfm.btnMountRemote.hide(), t++), 2 === t ? (this.getMsgBox().alert(this.title, _WFT("error", "error_privilege_not_enough"), this.close, this), "yes" === _D("supportmount") && this.webfm.btnToolsMenu.menu.hideMountItem()) : "yes" === _D("supportmount") && this.webfm.btnToolsMenu.menu.showMountItem(), !0)
    }
}), SYNO.FileStation.MountConfig = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.FileStation.MountConfig.superclass.constructor.call(this, t), this.mon(this, "afterlayout", function() {
            "yes" === _D("supportmount") && SYNO.ux.AddTip(this.getForm().findField("rf_allow").getEl(), Ext.util.Format.htmlEncode(_WFT("mount", "config_remote_info")))
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        var t = {
            border: !1,
            trackResetOnLoad: !0,
            items: []
        };
        return "yes" === _D("supportmount") && t.items.push({
            xtype: "syno_fieldset",
            title: _WFT("mount", "remote_volume"),
            items: [{
                xtype: "syno_displayfield",
                value: String.format(_WFT("mount", "config_desc"), _WFT("mount", "remote_volume"))
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "everyone"),
                name: "rf_allow",
                inputValue: "everyone"
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "admin"),
                name: "rf_allow",
                inputValue: "admin"
            }]
        }, {
            xtype: "syno_fieldset",
            title: _WFT("mount", "virtual_device"),
            items: [{
                xtype: "syno_displayfield",
                value: String.format(_WFT("mount", "config_desc"), _WFT("mount", "virtual_device"))
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "everyone"),
                name: "vd_allow",
                inputValue: "everyone"
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "admin"),
                name: "vd_allow",
                inputValue: "admin"
            }]
        }), _S("is_admin") && t.items.push({
            xtype: "syno_fieldset",
            title: _WFT("vfs", "remote_connection_server"),
            items: [{
                xtype: "syno_displayfield",
                value: _WFT("vfs", "config_desc")
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "everyone"),
                name: "vfs_allow",
                inputValue: "all"
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("mount", "admin"),
                name: "vfs_allow",
                inputValue: "admin"
            }, {
                xtype: "syno_radio",
                indent: 1,
                boxLabel: _WFT("common", "specific_user_group"),
                name: "vfs_allow",
                inputValue: "custom",
                handler: this.onCheckChanged,
                scope: this
            }, {
                xtype: "syno_button",
                indent: 1,
                text: _WFT("common", "specific_user_group"),
                ref: "../customUserSettingsBtn",
                disabled: !0,
                scope: this,
                handler: this.onClickCustomUserSettingsBtn
            }]
        }), Ext.apply(t, e || {}), t
    },
    onCheckChanged: function(e, t) {
        this.customUserSettingsBtn.setDisabled(!1 === t)
    },
    onClickCustomUserSettingsBtn: function() {
        new SYNO.FileStation.ProtocolUserConfigDialog({
            owner: this.findWindow()
        }).show()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.MountISODialog = Ext.extend(SYNO.SDS.ModalWindow, {
    mntPointUserSet: !1,
    title: null,
    currSubDir: null,
    subDirName: null,
    constructor: function(e) {
        Ext.apply(this, e || {}), this.mntPointUserSet = !1, this.currSubDir = null, this.subDirName = null, this.title = _WFT("filetable", "filetable_mount_iso");
        var t = this.initFileTab(),
            i = {
                owner: this.owner,
                width: 600,
                height: 300,
                shadow: !0,
                minWidth: 600,
                minHeight: 280,
                collapsible: !1,
                autoScroll: !1,
                constrainHeader: !0,
                plain: !0,
                title: _WFT("filetable", "filetable_mount_iso"),
                layout: "fit",
                items: t,
                buttons: [this.btnMountISO = new SYNO.ux.Button({
                    text: _WFT("common", "close"),
                    scope: this,
                    handler: this.close
                }), new SYNO.ux.Button({
                    btnStyle: "blue",
                    text: _WFT("mount", "btn_mount"),
                    scope: this,
                    handler: this.onMountISO
                })],
                listeners: {
                    afterlayout: {
                        fn: this.center,
                        scope: this,
                        single: !0
                    },
                    beforeshow: {
                        fn: function() {
                            this.SetDefaultDest(this.fileID)
                        },
                        scope: this
                    },
                    resize: {
                        fn: this.onMyResize,
                        scope: this
                    }
                }
            };
        SYNO.FileStation.MountISODialog.superclass.constructor.call(this, i), this.addEvents("mountiso:true")
    },
    onMyResize: function() {
        this.getLayout().layout && this.doLayout()
    },
    afterRender: function() {
        SYNO.FileStation.MountISODialog.superclass.afterRender.call(this, arguments);
        var e = SYNO.webfm.utils.getParentDirArr(this.rec[0].get("path")),
            t = e[0];
        this.webfm.getCurrDirSubFdr(this, SYNO.webfm.utils.getImageName(this.rec[0].get("filename")), t)
    },
    initFileTab: function() {
        var e = {
                labelWidth: 200,
                trackResetOnLoad: !0,
                border: !1,
                autoScroll: !0,
                items: [{
                    fieldLabel: _WFT("mount", "image_file"),
                    xtype: "hidden",
                    itemId: "source",
                    name: "source",
                    value: "",
                    width: 200
                }, {
                    xtype: "syno_compositefield",
                    flex: 1,
                    fieldLabel: _WFT("mount", "mount_point"),
                    items: [{
                        xtype: "syno_textfield",
                        flex: 1,
                        itemId: "mount_point",
                        name: "mount_point",
                        allowBlank: !1,
                        readOnly: !0,
                        validationEvent: !1
                    }, {
                        xtype: "syno_button",
                        text: _WFT("mount", "browse"),
                        margins: "0 100px 0 0",
                        scope: this,
                        handler: this.onChooseDest
                    }]
                }, {
                    xtype: "syno_checkbox",
                    name: "auto_mount",
                    boxLabel: _WFT("mount", "auto_mount")
                }, {
                    xtype: "syno_displayfield",
                    style: "margin-top: 10px;",
                    htmlEncode: !1,
                    value: '<font class="red-status">' + _WFT("mount", "ro_folder") + "</font>"
                }]
            },
            t = new SYNO.ux.FormPanel(e);
        return this.panel = t, t
    },
    getCurrDirSubFdrCallBack: function(e) {
        this.currSubDir = e, this.SetDefPath();
        var t = this.webfm.getCurrentDir(),
            i = SYNO.webfm.utils.getParentDirArr(this.rec[0].get("path"));
        SYNO.webfm.utils.source.remotes === this.webfm.getCurrentSource() && (t = i[0]), this.UpdateTargetPath(t + "/" + this.subDirName)
    },
    SetDefPath: function() {
        var e = 0,
            t = !1,
            i = SYNO.webfm.utils.getImageName(this.rec[0].get("filename")),
            o = !1;
        for (this.subDirName = i, e = 0; e < this.currSubDir.length; e++)
            if (this.currSubDir[e].name !== i) {
                var n = this.currSubDir[e].name.exec(/^(.+)\((\d+)\)$/);
                n ? n[1] === i && (o = !0, this.subDirName = i + "(" + (parseInt(n[2], 10) + 1).toString() + ")") : !1 === o && (this.subDirName = i + "(2)")
            } else t = !0;
        !1 === t ? this.subDirName = i : this.subDirName === i && (this.subDirName = i + "(2)")
    },
    onChooseDest: function() {
        this.TreeDialog && !this.TreeDialog.isDestroyed || (this.TreeDialog = new SYNO.FileStation.TreeDialog({
            RELURL: this.RELURL,
            blDynamicForm: !1,
            blVFSFolder: !1,
            owner: this,
            webfm: this.webfm,
            createNode: function(e, t) {
                return SYNO.webfm.utils.parseRemoteTreeNode(e, t), "remotefail" == e.mountType && (e.cls = (e.cls || "") + " node_display_none"), SYNO.API.TreeLoader.prototype.createNode.call(this, e, t)
            }
        }), this.TreeDialog.mon(this.TreeDialog, "beforesubmit", this.onCheckDestPrivilege, this), this.TreeDialog.mon(this.TreeDialog, "callback", this.onTreeDialogHide, this)), this.TreeDialog.load(_WFT("filetable", "filetable_mount_iso"), !1, this.gUID, this.gGID)
    },
    onCheckDestPrivilege: function(e) {
        var t = this.TreeDialog;
        if (t) {
            if (!0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
            if (!SYNO.webfm.utils.checkShareRight(e.shareRight, SYNO.webfm.utils.RW)) return t.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("error", "error_privilege_not_enough")), !1;
            if (Ext.isDefined(e.folderRight)) {
                var i = {
                    right: e.folderRight,
                    needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Mount
                };
                if (!SYNO.webfm.utils.checkFileRight(i)) return t.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("error", "error_privilege_not_enough")), !1
            }
            return !0
        }
    },
    onTreeDialogHide: function() {
        var e = this.TreeDialog;
        if (e) {
            var t = e.getParameters();
            t.fdrName && (this.UpdateTargetPath(t.fdrName), this.mntPointUserSet = !0)
        }
    },
    SetDefaultDest: function(e) {
        if (-1 == e.lastIndexOf("/")) return !1;
        this.panel.getForm().findField("source").setValue(e)
    },
    UpdateTargetPath: function(e) {
        this.panel.getForm().findField("mount_point").setValue(e)
    },
    load: function(e, t, i, o, n) {
        "" !== t && "" !== e && "" !== i && (this.fileID = e, this.isoPath = t, this.gUID = o, this.gGID = n, this.filename = i, this.show().center())
    },
    onMountISO: function() {
        if (!this.panel.getForm().isValid()) return !1;
        this.fireEvent("mountiso")
    },
    getSubDirName: function() {
        return this.subDirName
    },
    getMntPointUserSet: function() {
        return this.mntPointUserSet
    },
    getSource: function() {
        return this.panel.getForm().findField("source").getValue()
    },
    getMntPoint: function() {
        return this.panel.getForm().findField("mount_point").getValue()
    },
    getAutoMnt: function() {
        return this.panel.getForm().findField("auto_mount").getValue()
    },
    getFileID: function() {
        return this.fileID
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.MountRemoteDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    mount_name: "",
    title: null,
    subDirName: "",
    currSubDir: null,
    mntPointUserSet: !1,
    constructor: function(e) {
        Ext.apply(this, e || {}), this.mntPointUserSet = !1, this.mount_name = "", this.subDirName = "", this.currSubDir = null, this.title = _WFT("filetable", "filetable_mount_remote_volume");
        var t = this.initFileTab(),
            i = {
                owner: this.owner,
                width: 600,
                height: 350,
                shadow: !0,
                minWidth: 450,
                minHeight: 280,
                collapsible: !1,
                autoScroll: !1,
                constrainHeader: !0,
                plain: !0,
                title: _WFT("filetable", "filetable_mount_remote_volume"),
                layout: "fit",
                items: t,
                buttons: [new SYNO.ux.Button({
                    text: _WFT("common", "close"),
                    scope: this,
                    handler: this.close
                }), this.btnMountRemote = new SYNO.ux.Button({
                    btnStyle: "blue",
                    text: _WFT("mount", "btn_mount"),
                    scope: this,
                    handler: this.onMountRemote
                })],
                listeners: {
                    afterlayout: {
                        fn: this.center,
                        scope: this,
                        single: !0
                    }
                }
            };
        SYNO.FileStation.MountRemoteDialog.superclass.constructor.call(this, i)
    },
    initFileTab: function() {},
    getCurrDirSubFdrCallBack: function(e) {
        this.currSubDir = e, this.SetDefPath(), this.UpdateTargetPath(this.webfm.getCurrentDir() + "/" + this.subDirName)
    },
    SetDefPath: function() {
        var e = 0,
            t = !1,
            i = !1,
            o = SYNO.webfm.utils.source.remote + this.webfm.getCurrentDir();
        if (this.subDirName = this.mount_name, SYNO.webfm.utils.source.remote == this.webfm.getCurrentSource() && Ext.isDefined(this.webfm.dirTree.getNodeById(o)) && "remotefail" != this.webfm.dirTree.getNodeById(o).attributes.mountType && !SYNO.webfm.VFS.isVFSPath(this.webfm.getCurrentDir()) && (!1 !== SYNO.SDS.Session.is_admin || "/home" == this.webfm.getCurrentDir()) && !0 !== this.mntPointUserSet && "" !== this.mount_name && this.currSubDir) {
            for (e = 0; e < this.currSubDir.length; e++)
                if (this.currSubDir[e].name !== this.mount_name) {
                    var n = this.currSubDir[e].name.match(/^(.+)\((\d+)\)$/);
                    n ? n[1] === this.mount_name && (i = !0, this.subDirName = this.mount_name + "(" + (parseInt(n[2], 10) + 1).toString() + ")") : !1 === i && (this.subDirName = this.mount_name + "(2)")
                } else t = !0;
            !1 === t ? this.subDirName = this.mount_name : this.subDirName === this.mount_name && (this.subDirName = this.mount_name + "(2)")
        }
    },
    findLastSubDir: function(e) {
        var t = e.lastIndexOf("\\"),
            i = e.lastIndexOf("/"),
            o = e.split("\\"),
            n = e.split("/"),
            s = "";
        return s = t === i && -1 == t ? e : t > i ? e.substr(t + 1) : e.substr(i + 1), "" === s && (s = t > i ? o[o.length - 2] : n[n.length - 2]), s
    },
    onChooseDest: function() {
        this.TreeDialog && !this.TreeDialog.isDestroyed || (this.TreeDialog = new SYNO.FileStation.TreeDialog({
            RELURL: this.RELURL,
            blDynamicForm: !1,
            blVFSFolder: !1,
            owner: this,
            webfm: this.webfm,
            createNode: function(e, t) {
                return SYNO.webfm.utils.parseRemoteTreeNode(e, t), _S("is_admin") || "fm_root" !== e.id && "remote/home" !== e.id && "remote/home/" !== e.id.substr(0, 12) && (e.cls = (e.cls || "") + " node_display_none"), "remotefail" == e.mountType && (e.cls = (e.cls || "") + " node_display_none"), SYNO.API.TreeLoader.prototype.createNode.call(this, e, t)
            }
        }), this.TreeDialog.mon(this.TreeDialog, "beforesubmit", this.onCheckDestPrivilege, this), this.TreeDialog.mon(this.TreeDialog, "callback", this.onTreeDialogHide, this)), this.TreeDialog.load(_WFT("filetable", "filetable_mount_remote_volume"), !1, this.gUID, this.gGID)
    },
    onCheckDestPrivilege: function(e) {
        var t = this.TreeDialog;
        if (t) {
            if (!0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
            if (!SYNO.webfm.utils.checkShareRight(e.shareRight, SYNO.webfm.utils.RW)) return t.getMsgBox().alert(_WFT("filetable", "filetable_mount_remote_volume"), _WFT("error", "error_privilege_not_enough")), !1;
            if (Ext.isDefined(e.folderRight)) {
                var i = {
                    right: e.folderRight,
                    needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Mount
                };
                if (!SYNO.webfm.utils.checkFileRight(i)) return t.getMsgBox().alert(_WFT("filetable", "filetable_mount_remote_volume"), _WFT("error", "error_privilege_not_enough")), !1
            }
            return !0
        }
    },
    onTreeDialogHide: function() {
        var e = this.TreeDialog;
        if (e) {
            var t = e.getParameters();
            t.fdrName && (this.UpdateTargetPath(t.fdrName), this.mntPointUserSet = !0)
        }
    },
    UpdateTargetPath: function(e) {
        this.panel.getForm().findField("mount_point").setValue(e)
    },
    load: function(e, t) {
        this.gUID = e, this.gGID = t, this.show().center()
    },
    getSubDirName: function() {
        return this.subDirName
    },
    getMntPointUserSet: function() {
        return this.mntPointUserSet
    },
    getMountType: function() {
        return this.panel.getForm().findField("protocol").getValue()
    },
    getServerIP: function() {
        return this.panel.getForm().findField("server_ip").getValue()
    },
    getMntPoint: function() {
        return this.panel.getForm().findField("mount_point").getValue()
    },
    getAutoMnt: function() {
        return this.panel.getForm().findField("auto_mount").getValue()
    }
}), SYNO.FileStation.MountRemoteDialog.MountCIFS = Ext.extend(SYNO.FileStation.MountRemoteDialog, {
    constructor: function(e) {
        SYNO.FileStation.MountRemoteDialog.MountCIFS.superclass.constructor.call(this, e), this.addEvents("mountremote:true"), this.mon(this, "afterlayout", function() {
            SYNO.ux.AddTip(this.panel.getForm().findField("server_ip").getEl(), Ext.util.Format.htmlEncode(String.format(_WFT("mount", "example"), "\\\\192.168.1.1\\Share")))
        }, this, {
            single: !0
        })
    },
    initFileTab: function() {
        var e = this,
            t = {
                labelWidth: 200,
                trackResetOnLoad: !0,
                border: !1,
                autoScroll: !0,
                height: 350,
                items: [{
                    fieldLabel: _WFT("mount", "protocol"),
                    xtype: "syno_displayfield",
                    itemId: "protocol",
                    name: "protocol",
                    value: "CIFS",
                    width: 200
                }, {
                    fieldLabel: _WFT("mount", "server_ip"),
                    xtype: "syno_textfield",
                    width: 200,
                    maxlength: 255,
                    itemId: "server_ip",
                    name: "server_ip",
                    validationEvent: "keyup",
                    validator: function(t) {
                        var i, o, n = new RegExp("^(\\/\\/|\\\\\\\\)([^\\/\\\\]*)[\\/\\\\]?(.*)"),
                            s = new RegExp("^(localhost|" + _S("hostname") + "|" + _S("hostname") + "\\.local|" + _S("external_ip") + "|127\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})$", "i"),
                            r = SYNO.webfm.utils.source.remote + e.webfm.getCurrentDir();
                        if (o = t.match(n), Ext.isEmpty(o)) return _WFT("mount", "bad_remote_folder");
                        if (i = o[2], !Ext.isEmpty(i.match(s))) return _WFT("mount", "invalid_local_host");
                        if ("" !== o[3]) {
                            if (e.mount_name = e.findLastSubDir(o[3]), e.subDirName = e.mount_name, SYNO.webfm.utils.source.remote != e.webfm.getCurrentSource() || !Ext.isDefined(e.webfm.dirTree.getNodeById(r)) || "remotefail" == e.webfm.dirTree.getNodeById(r).attributes.mountType || SYNO.webfm.VFS.isVFSPath(e.webfm.getCurrentDir())) return !0;
                            if (!1 === SYNO.SDS.Session.is_admin && "/home" != e.webfm.getCurrentDir() || !0 === e.mntPointUserSet) return !0;
                            e.SetDefPath(), e.UpdateTargetPath(e.webfm.getCurrentDir() + "/" + e.subDirName)
                        }
                        return !0
                    }
                }, {
                    xtype: "syno_textfield",
                    fieldLabel: _WFT("mount", "acc_name"),
                    width: 200,
                    itemId: "acc_name",
                    name: "acc_name"
                }, {
                    xtype: "syno_textfield",
                    textType: "password",
                    fieldLabel: _WFT("mount", "passwd"),
                    width: 200,
                    itemId: "passwd",
                    name: "passwd"
                }, {
                    xtype: "syno_compositefield",
                    width: 330,
                    fieldLabel: _WFT("mount", "mount_point"),
                    items: [{
                        xtype: "syno_textfield",
                        width: 200,
                        itemId: "mount_point",
                        name: "mount_point",
                        allowBlank: !1,
                        readOnly: !0,
                        validationEvent: !1
                    }, {
                        xtype: "syno_button",
                        text: _WFT("mount", "browse"),
                        scope: this,
                        handler: this.onChooseDest
                    }]
                }, {
                    xtype: "syno_checkbox",
                    name: "auto_mount",
                    boxLabel: _WFT("mount", "auto_mount")
                }]
            },
            i = new SYNO.ux.FormPanel(t);
        return this.panel = i, i
    },
    onMountRemote: function() {
        if (!this.panel.getForm().isValid()) return !1;
        this.fireEvent("mountremote")
    },
    getAccount: function() {
        return this.panel.getForm().findField("acc_name").getValue()
    },
    getPasswd: function() {
        return this.panel.getForm().findField("passwd").getValue()
    }
}), SYNO.FileStation.MountRemoteDialog.MountNFS = Ext.extend(SYNO.FileStation.MountRemoteDialog, {
    constructor: function(e) {
        SYNO.FileStation.MountRemoteDialog.MountNFS.superclass.constructor.call(this, e), this.addEvents("mountnfs:true"), this.mon(this, "afterlayout", function() {
            SYNO.ux.AddTip(this.panel.getForm().findField("server_ip").getEl(), Ext.util.Format.htmlEncode(String.format(_WFT("mount", "example"), "192.168.1.1:/volume1/share")))
        }, this, {
            single: !0
        })
    },
    initFileTab: function() {
        var e = this,
            t = {
                labelWidth: 200,
                trackResetOnLoad: !0,
                border: !1,
                autoScroll: !0,
                height: 350,
                items: [{
                    fieldLabel: _WFT("mount", "protocol"),
                    xtype: "syno_displayfield",
                    itemId: "protocol",
                    name: "protocol",
                    value: "NFS",
                    width: 200
                }, {
                    fieldLabel: _WFT("mount", "server_ip"),
                    xtype: "syno_textfield",
                    width: 200,
                    maxlength: 255,
                    itemId: "server_ip",
                    name: "server_ip",
                    validationEvent: "keyup",
                    validator: function(t) {
                        var i, o, n = new RegExp("^([^\\/\\\\]*):\\/([^\\\\]*)$"),
                            s = new RegExp("^(localhost|" + _S("hostname") + "|" + _S("hostname") + "\\.local|" + _S("external_ip") + "|127\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3})$", "i"),
                            r = SYNO.webfm.utils.source.remote + e.webfm.getCurrentDir();
                        if (o = t.match(n), Ext.isEmpty(o)) return _WFT("mount", "bad_remote_folder");
                        if (i = o[1], !Ext.isEmpty(i.match(s))) return _WFT("mount", "invalid_local_host");
                        if ("" !== o[2]) {
                            if (e.mount_name = e.findLastSubDir(o[2]), e.subDirName = e.mount_name, SYNO.webfm.utils.source.remote != e.webfm.getCurrentSource() || !Ext.isDefined(e.webfm.dirTree.getNodeById(r)) || "remotefail" == e.webfm.dirTree.getNodeById(r).attributes.mountType || SYNO.webfm.VFS.isVFSPath(e.webfm.getCurrentDir())) return !0;
                            if (!1 === SYNO.SDS.Session.is_admin && "/home" != e.webfm.getCurrentDir() || !0 === e.mntPointUserSet) return !0;
                            e.SetDefPath(), e.UpdateTargetPath(e.webfm.getCurrentDir() + "/" + e.subDirName)
                        }
                        return !0
                    }
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _WFT("mount", "nfs_version"),
                    itemId: "nfs_version",
                    name: "nfs_version",
                    hidden: !1,
                    value: "3",
                    valueField: "value",
                    displayField: "name",
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["value", "name"],
                        data: [
                            ["3", _WFT("mount", "nfs_v3")],
                            ["4", _WFT("mount", "nfs_v4")]
                        ]
                    }),
                    listeners: {
                        select: {
                            fn: function(t, i, o) {
                                var n = e.panel.getForm().findField("nfs_protocol");
                                0 === o ? n.disabled && (n.enable(), n.setValue(n.preValue)) : n.disabled || (n.preValue = n.getValue() || "tcp", n.setValue("tcp"), n.disable())
                            },
                            scope: e
                        }
                    }
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _WFT("mount", "nfs_protocol"),
                    itemId: "nfs_protocol",
                    name: "nfs_protocol",
                    hidden: !1,
                    value: "tcp",
                    valueField: "value",
                    displayField: "name",
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["value", "name"],
                        data: [
                            ["tcp", _WFT("mount", "tcp")],
                            ["udp", _WFT("mount", "udp")]
                        ]
                    })
                }, {
                    xtype: "syno_compositefield",
                    width: 330,
                    fieldLabel: _WFT("mount", "mount_point"),
                    items: [{
                        xtype: "syno_textfield",
                        width: 200,
                        itemId: "mount_point",
                        name: "mount_point",
                        allowBlank: !1,
                        readOnly: !0,
                        validationEvent: !1
                    }, {
                        xtype: "syno_button",
                        text: _WFT("mount", "browse"),
                        scope: this,
                        handler: this.onChooseDest
                    }]
                }, {
                    xtype: "syno_checkbox",
                    name: "enable_adv_opt",
                    boxLabel: _WFT("mount", "adv_opt"),
                    hidden: !0
                }, {
                    xtype: "hidden",
                    indent: 1,
                    fieldLabel: _WFT("mount", "params"),
                    width: 200,
                    itemId: "adv_opt",
                    name: "adv_opt"
                }, {
                    xtype: "syno_checkbox",
                    name: "auto_mount",
                    boxLabel: _WFT("mount", "auto_mount")
                }]
            },
            i = new SYNO.ux.FormPanel(t);
        return this.panel = i, i
    },
    onMountRemote: function() {
        if (!this.panel.getForm().isValid()) return !1;
        this.fireEvent("mountnfs")
    },
    getNFSVersion: function() {
        return this.panel.getForm().findField("nfs_version").getValue()
    },
    getProtocol: function() {
        return this.panel.getForm().findField("nfs_protocol").getValue()
    }
}), Ext.ns("SYNO.FileStation"), Ext.define("SYNO.FileStation.RemoteConnection.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            editMode: !1,
            keys: [{
                key: Ext.EventObject.ENTER,
                fn: function() {
                    this.owner && Ext.isFunction(this.owner.applyHandler) && this.owner.applyHandler()
                },
                scope: this
            }],
            height: 300,
            labelWidth: 230,
            trackResetOnLoad: !0,
            border: !1,
            autoFlexcroll: !0,
            defaults: {
                width: 300
            },
            items: [{
                xtype: "syno_textfield",
                fieldLabel: _WFT("vfs", "ip_fqdn"),
                itemId: "hostname",
                name: "hostname",
                allowBlank: !1,
                hidden: !0,
                enableKeyEvents: !0,
                validator: function(e) {
                    return !(!e || -1 !== e.indexOf("/") || -1 !== e.indexOf("://"))
                },
                listeners: {
                    keyup: function(e, t) {
                        if (this.editMode && t.keyCode !== Ext.EventObject.ENTER) {
                            var i = this.getComponent("account"),
                                o = this.getComponent("password");
                            i && !i.isDirty() && i.setValue(""), o && !o.isDirty() && o.setValue("")
                        }
                    },
                    scope: this
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("common", "port"),
                itemId: "port",
                name: "port",
                vtype: "port",
                hidden: !0,
                allowBlank: !1
            }, {
                xtype: "syno_textfield",
                fieldLabel: _WFT("mount", "uri_path"),
                itemId: "uri_path",
                name: "uri_path",
                allowBlank: !0,
                hidden: !0
            }, {
                xtype: "syno_textfield",
                fieldLabel: _WFT("mount", "acc_name"),
                itemId: "account",
                hidden: !0,
                name: "account"
            }, {
                xtype: "syno_textfield",
                fieldLabel: _WFT("mount", "passwd"),
                itemId: "password",
                name: "password",
                hidden: !0,
                textType: "password"
            }, {
                xtype: "syno_combobox",
                fieldLabel: _WFT("common", "lang_codepage"),
                itemId: "codepage",
                name: "codepage",
                hidden: !0,
                value: "UTF-8",
                valueField: "value",
                displayField: "name",
                store: new Ext.data.ArrayStore({
                    fields: ["value", "name"],
                    data: SYNO.webfm.utils.GetIconvCodepageList()
                })
            }, {
                xtype: "syno_textfield",
                fieldLabel: _WFT("vfs", "server_alias"),
                itemId: "alias",
                name: "alias",
                hidden: !0,
                minlength: 1,
                maxlength: 255
            }, {
                xtype: "syno_checkbox",
                boxLabel: _WFT("vfs", "dav_use_ssl"),
                itemId: "use_ssl",
                name: "use_ssl",
                hidden: !0,
                width: 500,
                listeners: {
                    check: function(e) {
                        var t = SYNO.FileStation.RemoteConnection.Utils.getProtocolInfo("dav"),
                            i = SYNO.FileStation.RemoteConnection.Utils.getProtocolInfo("davs"),
                            o = parseInt(this.getComponent("port").getValue(), 10);
                        t && i && (e.getValue() && o === t.defaultPort ? this.getComponent("port").setValue(i.defaultPort) : e.getValue() || o !== i.defaultPort || this.getComponent("port").setValue(t.defaultPort))
                    },
                    scope: this
                }
            }, {
                xtype: "syno_checkbox",
                boxLabel: _WFT("vfs", "ftp_use_one_connection"),
                itemId: "use_one_connection",
                name: "use_one_connection",
                hidden: !0
            }]
        };
        return Ext.apply(t, e), t
    },
    getServerID: function() {
        return this.server_id
    },
    getFieldOriginalValue: function(e) {
        return this.getForm().findField(e).originalValue
    },
    getFieldValue: function(e, t) {
        var i = this.getForm().findField(e);
        if (!t || i.isDirty()) return i.getValue()
    },
    setFieldValue: function(e, t) {
        this.getForm().findField(e).setValue(t)
    },
    cleanDirtyFlag: function() {
        this.getForm().setValues(this.getForm().getValues())
    },
    isFormDirty: function() {
        return this.getForm().isDirty()
    },
    isFormValid: function() {
        return this.getForm().isValid()
    },
    load: function(e) {
        this.server_id = e, SYNO.API.currentManager.requestAPI("SYNO.FileStation.VFS.Profile", "get", "1", {
            id: e
        }, function(t, i, o, n) {
            if (this.fireEvent("loadcomplete"), this.applyMode(SYNO.webfm.VFS.getSchemaFromPath(e), !0), !t) return void this.findWindow().getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, i, n));
            i.password = "12345678", i.use_one_connection = 1 === i.max_connection, this.getForm().setValues(i)
        }, this)
    },
    applyMode: function(e, t) {
        var i = this.getForm().findField("hostname"),
            o = this.getForm().findField("port"),
            n = this.getForm().findField("uri_path"),
            s = this.getForm().findField("account"),
            r = this.getForm().findField("password"),
            a = this.getForm().findField("codepage"),
            l = this.getForm().findField("alias"),
            h = this.getForm().findField("use_ssl"),
            c = this.getForm().findField("use_one_connection");
        switch (t || o.setValue(SYNO.FileStation.RemoteConnection.Utils.getProtocolInfo(e).defaultPort), l.setDisabled(!1).setVisible(!0), this.protocol = e, e) {
            case "ftp":
            case "sftp":
                i.setDisabled(!1).setVisible(!0), o.setDisabled(!1).setVisible(!0), n.setDisabled(!0).setVisible(!1), s.setDisabled(!1).setVisible(!0), r.setDisabled(!1).setVisible(!0), a.setDisabled(!1).setVisible(!0), h.setDisabled(!0).setVisible(!1), c.setDisabled(!1).setVisible(!0);
                break;
            case "dav":
            case "davs":
                i.setDisabled(!1).setVisible(!0), o.setDisabled(!1).setVisible(!0), n.setDisabled(!1).setVisible(!0), s.setDisabled(!1).setVisible(!0), r.setDisabled(!1).setVisible(!0), a.setDisabled(!1).setVisible(!0), h.setDisabled(!!this.editMode).setVisible(!this.editMode), c.setDisabled(!0).setVisible(!1);
                break;
            default:
                i.setDisabled(!0).setVisible(!1), o.setDisabled(!0).setVisible(!1), n.setDisabled(!0).setVisible(!1), s.setDisabled(!0).setVisible(!1), r.setDisabled(!0).setVisible(!1), a.setDisabled(!0).setVisible(!1), h.setDisabled(!0).setVisible(!1), c.setDisabled(!0).setVisible(!1)
        }
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.ProfileGrid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            autoScroll: !0,
            store: this.getStore(),
            colModel: this.getColumnModel(),
            selModel: this.getSelectionModel(),
            tbar: this.getToolbar(),
            listeners: {
                rowdblclick: this.onEditBtnClicked,
                rowcontextmenu: this.onRowCtxMenu,
                containercontextmenu: this.showCtxMenu,
                scope: this
            }
        };
        return Ext.apply(t, e), t
    },
    getStore: function() {
        return Ext.isDefined(this.protocolStore) || (this.protocolStore = new Ext.data.Store({
            autoLoad: !0,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.VFS.Profile",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "profiles"
            }, [{
                name: "protocol",
                mapping: "protocol_name"
            }, {
                name: "protocol_value",
                mapping: "protocol"
            }, {
                name: "uri"
            }, {
                name: "hostname"
            }, {
                name: "port"
            }, {
                name: "alias"
            }, {
                name: "account"
            }, {
                name: "codepage"
            }, {
                name: "connect_status"
            }]),
            remoteSort: !0,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "alias",
                direction: "ASC"
            },
            listeners: {
                scope: this,
                beforeload: function() {
                    return this.getEl() && this.getEl().mask(_WFT("common", "loading"), "x-mask-loading"), !0
                },
                load: function(e) {
                    this.getEl() && this.getEl().unmask(), e.filterBy(function(e, t) {
                        switch (e.get("protocol_value")) {
                            case "sharing":
                                return !1;
                            default:
                                return !0
                        }
                    }), this.checkButtonState()
                },
                exception: function(e, t, i, o, n, s) {
                    this.getEl() && this.getEl().unmask(), this.findWindow().getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, n, o))
                }
            }
        })), this.protocolStore
    },
    getColumnModel: function() {
        return Ext.isDefined(this.protocolColumnModel) || (this.protocolColumnModel = new Ext.grid.ColumnModel({
            defaults: {
                sortable: !0
            },
            columns: [{
                header: _WFT("vfs", "server_alias"),
                dataIndex: "alias",
                width: 160
            }, {
                header: _WFT("mount", "protocol"),
                dataIndex: "protocol",
                width: 130
            }, {
                header: _WFT("vfs", "uri"),
                dataIndex: "uri",
                width: 250
            }, {
                header: _WFT("vfs", "ip_fqdn"),
                dataIndex: "hostname",
                width: 180,
                hidden: !0
            }, {
                header: _T("common", "port"),
                dataIndex: "port",
                width: 80,
                hidden: !0
            }, {
                header: _WFT("mount", "acc_name"),
                dataIndex: "account",
                width: 120,
                renderer: function(e, t, i, o, n, s) {
                    return "" === e ? "(" + _WFT("vfs", "acc_anonymous") + ")" : e
                }
            }, {
                header: _WFT("common", "lang_codepage"),
                dataIndex: "codepage",
                width: 120
            }, {
                header: _WFT("vfs", "connect_status"),
                dataIndex: "connect_status",
                width: 160,
                renderer: function(e, t, i, o, n, s) {
                    return 1 === e ? _WFT("vfs", "server_connected") : _WFT("vfs", "server_disconnected")
                }
            }]
        })), this.protocolColumnModel
    },
    getSelectionModel: function() {
        return Ext.isDefined(this.protocolSelectionModel) || (this.protocolSelectionModel = new Ext.grid.RowSelectionModel({
            listeners: {
                selectionchange: {
                    fn: this.checkButtonState.createDelegate(this, [this.getToolbar()])
                }
            }
        })), this.protocolSelectionModel
    },
    getToolbar: function() {
        return Ext.isDefined(this.protocolToolbar) || (this.protocolToolbar = new Ext.Toolbar({
            defaultType: "syno_button",
            items: [{
                text: _WFT("vfs", "connect"),
                itemId: "connectBtn",
                disabled: !0,
                handler: this.onConnectBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "disconnect"),
                itemId: "diconnectBtn",
                disabled: !0,
                handler: this.onDisconnectBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "edit_profile"),
                itemId: "editBtn",
                disabled: !0,
                handler: this.onEditBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "remove_profile"),
                itemId: "removeBtn",
                disabled: !0,
                handler: this.onRemoveBtnClicked,
                scope: this
            }]
        })), this.protocolToolbar
    },
    checkButtonState: function(e) {
        var t;
        e = e || this.getToolbar();
        var i = e.getComponent("removeBtn"),
            o = e.getComponent("diconnectBtn"),
            n = e.getComponent("editBtn"),
            s = e.getComponent("connectBtn"),
            r = this.getSelectionModel().getCount(),
            a = this.getSelectionModel().getSelections();
        if (o.setDisabled(!0), s.setDisabled(!0), 0 < r) {
            for (i.setDisabled(!1), n.setDisabled(1 !== r), s.setDisabled(1 !== r), t = 0; t < a.length; t++)
                if (1 === a[t].get("connect_status")) {
                    o.setDisabled(!1);
                    break
                }
        } else i.setDisabled(!0), n.setDisabled(!0)
    },
    onDisconnectBtnClicked: function() {
        var e, t = this.getSelectionModel().getSelections(),
            i = [];
        for (e = 0; e < t.length; e++) i.push(t[e].id);
        SYNO.FileStation.RemoteConnection.Utils.deleteServer(i, !0, this.findWindow(), function(e, t, i, o) {
            e && !t.has_fail && (this.getStore().reload(), this.findWindow().webfm.FileAction.fireEvent("refreshTreeNode", [""], null, null, !0))
        }, this)
    },
    onRemoveBtnClicked: function() {
        var e = this.getSelectionModel().getSelections();
        this.findWindow().getMsgBox().confirmDelete("", _WFT("vfs", "confirm_remove_profile"), function(t) {
            if ("yes" === t) {
                var i, o = [];
                for (i = 0; i < e.length; i++) o.push(e[i].id);
                SYNO.FileStation.RemoteConnection.Utils.deleteServer(o, !1, this.findWindow(), function(e, t, i, o) {
                    var n, s, r = {};
                    for (this.getStore().reload(), n = 0; n < i.compound.length; n++) s = SYNO.webfm.VFS.getSchemaFromPath(i.compound[n].id), Ext.isDefined(r[s]) || (this.findWindow().webfm.FileAction.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, s), r[s] = !0);
                    if (!e || t.has_fail) {
                        var a = SYNO.API.Util.GetFirstError(t);
                        this.findWindow().getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, a))
                    }
                }, this)
            }
        }, this)
    },
    onEditBtnClicked: function() {
        var e = this.getSelectionModel().getSelected().id,
            t = new SYNO.FileStation.RemoteConnection.EditDialog({
                owner: this.findWindow(),
                title: _WFT("vfs", "edit_profile")
            });
        this.mon(t, "editcomplete", function() {
            this.getStore().reload()
        }, this), t.load(e)
    },
    initCtxMenu: function() {
        return this.gridCtxMenu || (this.gridCtxMenu = new SYNO.ux.Menu({
            items: [{
                text: _WFT("vfs", "connect"),
                itemId: "connectBtn",
                disabled: !0,
                handler: this.onConnectBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "disconnect"),
                itemId: "diconnectBtn",
                disabled: !0,
                handler: this.onDisconnectBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "edit_profile"),
                itemId: "editBtn",
                disabled: !0,
                handler: this.onEditBtnClicked,
                scope: this
            }, {
                text: _WFT("vfs", "remove_profile"),
                itemId: "removeBtn",
                disabled: !0,
                handler: this.onRemoveBtnClicked,
                scope: this
            }]
        })), this.checkButtonState(this.gridCtxMenu), this.gridCtxMenu
    },
    onRowCtxMenu: function(e, t, i) {
        var o = this.getSelectionModel();
        o.isSelected(t) || o.selectRow(t), this.showCtxMenu(e, i)
    },
    showCtxMenu: function(e, t) {
        this.initCtxMenu().showAt(t.getXY())
    },
    connectByProfileID: function(e) {
        SYNO.FileStation.RemoteConnection.Utils.createServer(!1, {
            profile_id: e
        }, !0, this.findWindow(), function() {
            this.getStore().reload(), this.findWindow().webfm.FileAction.fireEvent("refreshTreeNode", [""], null, null, !0)
        }, this)
    },
    onConnectBtnClicked: function() {
        var e = this.getSelectionModel().getSelected();
        e && this.connectByProfileID(e.id)
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.EditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t]), this.addEvents({
            editcomplete: !0
        })
    },
    fillConfig: function(e) {
        var t = {
            width: 600,
            height: 375,
            shadow: !0,
            minWidth: 350,
            minHeight: 375,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            layout: "fit",
            items: this.getConnectionFormPanel(e),
            buttons: [this.btnOK = new SYNO.ux.Button({
                text: _WFT("common", "cancel"),
                scope: this,
                handler: this.close
            }), new SYNO.ux.Button({
                btnStyle: "blue",
                text: _T("common", "ok"),
                scope: this,
                handler: this.applyHandler
            })]
        };
        return Ext.apply(t, e), t
    },
    getConnectionFormPanel: function() {
        return Ext.isDefined(this.connectionFormPanel) || (this.connectionFormPanel = new SYNO.FileStation.RemoteConnection.FormPanel({
            editMode: !0,
            owner: this
        })), this.connectionFormPanel
    },
    onRender: function() {
        this.callParent(arguments), this.mon(this.getConnectionFormPanel(), {
            loadcomplete: function() {
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    load: function(e) {
        this.getConnectionFormPanel().load(e), this.show().center()
    },
    editProfile: function(e) {
        var t, i = this.getConnectionFormPanel();
        return !!i.isFormValid() && (i.isFormDirty() ? (t = {
            id: i.getServerID(),
            hostname: i.getFieldValue("hostname").trim(),
            port: i.getFieldValue("port"),
            alias: i.getFieldValue("alias") || i.getFieldValue("hostname").trim(),
            account: i.getFieldValue("account"),
            codepage: i.getFieldValue("codepage"),
            uri_path: i.getFieldValue("uri_path"),
            max_connection: i.getFieldValue("use_one_connection") ? 1 : 0
        }, i.getFieldValue("password", !0) && (t.password = i.getFieldValue("password", !0)), void SYNO.FileStation.RemoteConnection.Utils.editServer(!1, t, this.findWindow(), function(e, t, i, o) {
            this.fireEvent("editcomplete"), this.close()
        }, this)) : void this.close())
    },
    applyHandler: function() {
        this.editProfile(!1)
    }
}), Ext.ns("SYNO.FileStation.RemoteConnection"), SYNO.FileStation.RemoteConnection.Utils = {}, Ext.apply(SYNO.FileStation.RemoteConnection.Utils, {
    createServer: function(e, t, i, o, n, s) {
        var r;
        r = i ? {
            profile_id: t.profile_id
        } : {
            protocol: t.protocol,
            client_id: t.client_id,
            hostname: t.hostname ? t.hostname.trim() : "",
            port: t.port,
            alias: t.alias || (t.hostname ? t.hostname.trim() : ""),
            account: t.account,
            password: t.password,
            codepage: t.codepage,
            uri_path: t.uri_path,
            access_token: t.access_token,
            refresh_token: t.refresh_token,
            expires_in: t.expires_in,
            max_connection: t.max_connection
        };
        var a = [{
            api: "SYNO.FileStation.VFS.Connection",
            method: "create",
            version: 1,
            params: Ext.apply(r, {
                force: !!e
            })
        }];
        i || a.push({
            api: "SYNO.FileStation.VFS.Profile",
            method: "create",
            version: 1,
            params: r
        }), o.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), SYNO.API.Request({
            timeout: 36e5,
            params: {},
            compound: {
                stopwhenerror: !0,
                params: a
            },
            encryption: ["password", "access_token", "refresh_token"],
            scope: this,
            callback: function(e, r, a, l) {
                if (o.clearStatusBusy(), e && !r.has_fail) o.webfm.FileAction.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, a.compound[0].protocol), n.apply(s, [e, r, a, l]);
                else {
                    var h = SYNO.API.Util.GetFirstError(r),
                        c = [2107, 2112, 2115];
                    if (h && -1 !== c.indexOf(h.code)) {
                        var d = function() {
                            SYNO.FileStation.RemoteConnection.Utils.createServer(!0, t, i, o, n, s)
                        };
                        SYNO.webfm.utils.handleRemoteConnectionException(r, {
                            id: a.compound[0].profile_id
                        }, o, d, Ext.emptyFn, this, !0)
                    } else o.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, h))
                }
            }
        })
    },
    editServer: function(e, t, i, o, n) {
        i.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        });
        var s = {
                id: t.id,
                hostname: t.hostname ? t.hostname.trim() : "",
                port: t.port,
                alias: t.alias || (t.hostname ? t.hostname.trim() : ""),
                account: t.account,
                password: t.password,
                codepage: t.codepage,
                uri_path: t.uri_path,
                max_connection: t.max_connection
            },
            r = [{
                timeout: 36e5,
                api: "SYNO.FileStation.VFS.Connection",
                method: "set",
                version: 1,
                params: Ext.apply(s, {
                    force: !!e
                })
            }, {
                api: "SYNO.FileStation.VFS.Profile",
                method: "set",
                version: 1,
                params: s
            }];
        SYNO.API.Request({
            params: {},
            compound: {
                stopwhenerror: !0,
                params: r
            },
            encryption: ["password", "access_token", "refresh_token"],
            scope: this,
            callback: function(e, s, r, a) {
                if (i.clearStatusBusy(), !e || s.has_fail) {
                    var l = SYNO.API.Util.GetFirstError(s),
                        h = [2107, 2112, 2115];
                    return void(l && -1 !== h.indexOf(l.code) ? SYNO.webfm.utils.handleRemoteConnectionException(s, {
                        id: r.compound[0].id
                    }, i, function() {
                        this.editServer(!0, t, i, o, n)
                    }, Ext.emptyFn, this) : i.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, l)))
                }
                var c = i.findAppWindow().panelObj;
                c.FileAction.fireEvent("refreshVFSTreeNode", function() {
                    c.onRefreshTreeDone(c.getCurrentDir(), c.getCurrentSource())
                }, this, SYNO.webfm.VFS.getSchemaFromPath(r.compound[0].id)), o.apply(n, [e, s, r, a])
            }
        })
    },
    deleteServer: function(e, t, i, o, n) {
        var s, r = [];
        for (s = 0; s < e.length; s++) r.push({
            api: "SYNO.FileStation.VFS.Connection",
            method: "delete",
            version: 1,
            params: {
                id: e[s]
            }
        }), t || r.push({
            api: "SYNO.FileStation.VFS.Profile",
            method: "delete",
            version: 1,
            params: {
                id: e[s]
            }
        });
        i.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), SYNO.API.Request({
            timeout: 36e5,
            params: {},
            compound: {
                stopwhenerror: !1,
                params: r
            },
            scope: this,
            callback: function(e, t, s, r) {
                i.clearStatusBusy(), o.apply(n, [e, t, s, r])
            }
        })
    },
    ProtocolInfo: [],
    getProtocolInfo: function(e) {
        for (var t = 0; t < this.ProtocolInfo.length; t++)
            if (e === this.ProtocolInfo[t].protocol) return Ext.apply({}, this.ProtocolInfo[t]);
        return null
    },
    isCloudServer: function(e) {
        return -1 !== ["google", "dropbox", "baidu", "onedrive", "box"].indexOf(e)
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.ChooseType", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        this.protocolStore = new Ext.data.Store({
            autoLoad: !1,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.VFS.Protocol",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "protocols"
            }, [{
                name: "protocol",
                mapping: "protocol"
            }, {
                name: "name",
                mapping: "name"
            }, {
                name: "defaultPort",
                mapping: "default_port"
            }, {
                name: "is_cloud",
                convert: function(e, t) {
                    return SYNO.FileStation.RemoteConnection.Utils.isCloudServer(t.protocol) ? 1 : 0
                }
            }]),
            listeners: {
                load: function(e, t, i) {
                    e.multiSort([{
                        field: "is_cloud",
                        direction: "DESC"
                    }, {
                        field: "name",
                        direction: "ASC"
                    }]), e.filterBy(function(e, t) {
                        switch (e.get("protocol")) {
                            case "davs":
                                return !1;
                            case "dav":
                                return e.set("name", _WFT("vfs", "dav_davs_name")), !0;
                            case "sharing":
                                return !1;
                            default:
                                return !0
                        }
                    });
                    for (var o = 0; o < t.length; o++) SYNO.FileStation.RemoteConnection.Utils.ProtocolInfo.push(t[o].data);
                    this.getChooseConnectionDataView().select(0), this.fireEvent("loadcomplete")
                },
                exception: function() {
                    this.fireEvent("loadcomplete")
                },
                scope: this
            }
        });
        var t = {
            headline: _WFT("vfs", "wizard_choose_type_headline"),
            layout: "fit",
            height: 296,
            items: [this.getChooseConnectionPanelCt()]
        };
        return Ext.apply(t, e), t
    },
    getChooseConnectionPanelCt: function() {
        return Ext.isDefined(this.chooseConnectionPanelCt) || (this.chooseConnectionPanelCt = new SYNO.ux.Panel({
            layout: "fit",
            height: 400,
            autoFlexcroll: !0,
            items: this.getChooseConnectionDataView()
        })), this.chooseConnectionPanelCt
    },
    getChooseConnectionDataView: function() {
        return Ext.isDefined(this.chooseConnectionDataView) || (this.chooseConnectionDataView = new SYNO.ux.FleXcroll.DataView({
            useARIA: !0,
            store: this.protocolStore,
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="webfm-remote-server-provider-template" id="{name}" role="option" aria-label="{name}">', '<div class="icon-wrapper">', '<div class="icon-ct-{protocol}"></div>', "</div>", '<div class="title-wrapper">', "<strong>{name}</strong>", "</div>", "</div>", "</tpl>"),
            singleSelect: !0,
            itemSelector: "div.webfm-remote-server-provider-template",
            cls: "webfm-remote-server-dataview",
            overClass: "provider-over",
            chooseTypePanel: this,
            listeners: {
                scope: this,
                dblclick: function() {
                    if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert("", _JSLIBSTR("uicommon", "error_demo"));
                    this.owner.goNext(this.getNext())
                }
            },
            hasNodeSelected: function() {
                return this.selected.elements.length > 0
            },
            toggleSelectedItem: function() {
                if (this.hasNodeSelected()) {
                    var e = this.chooseTypePanel;
                    e.owner.goNext(e.getNext())
                }
            },
            onKeySpace: function() {
                this.toggleSelectedItem()
            },
            onKeyEnter: function() {
                this.toggleSelectedItem()
            },
            getTemplateTarget: function() {
                var e = this;
                return e.scrollBar = e.scrollBar || e.el.createChild({
                    tag: "div",
                    style: "width:100%;display:inline-block;"
                }), e.scrollBar
            }
        })), this.chooseConnectionDataView
    },
    load: function() {
        this.protocolStore.reload()
    },
    getNext: function() {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert("", _JSLIBSTR("uicommon", "error_demo"));
        if (1 !== this.getChooseConnectionDataView().getSelectionCount()) return !1;
        var e = this.getChooseConnectionDataView().getSelectedRecords()[0].get("protocol");
        return this.owner.setServerType(e), SYNO.FileStation.RemoteConnection.Utils.isCloudServer(e) ? (SYNO.webfm.utils.startOAuth(e, function(t) {
            t.protocol = e, SYNO.FileStation.RemoteConnection.Utils.createServer(!1, t, !1, this.owner, function(e, t, i, o) {
                if (e && !t.has_fail) {
                    var n = t.result[0].data,
                        s = SYNO.FileStation.RemoteConnection.Utils.getProtocolInfo(i.compound[0].protocol);
                    n.cloud_name = s ? s.name : "", this.owner.CloudSummaryPanel.load(n), this.owner.setActiveStep("cloud_summary"), this.owner.syncView()
                }
            }, this)
        }, this), !1) : "vfs_setting"
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.VFSSetting", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            headline: _WFT("vfs", "wizard_vfs_setting_headline"),
            layout: "fit",
            height: 312,
            items: [this.formPanel = new SYNO.FileStation.RemoteConnection.FormPanel({
                owner: this
            })],
            listeners: {
                beforeshow: function() {
                    this.formPanel.applyMode(this.owner.getServerType())
                },
                scope: this
            }
        };
        return Ext.apply(t, e), t
    },
    applyHandler: function() {
        this.getNext()
    },
    activate: function() {
        this.formPanel.applyMode(this.owner.getServerType())
    },
    getNext: function() {
        if (!this.formPanel.isFormValid()) return !1;
        var e = this.formPanel.getForm().getValues();
        return e.protocol = this.owner.getServerType(), "dav" !== e.protocol || "true" !== e.use_ssl && !0 !== e.use_ssl || (e.protocol = "davs"), e.max_connection = "true" === e.use_one_connection ? 1 : 0, SYNO.FileStation.RemoteConnection.Utils.createServer(!1, e, !1, this.owner, function(e, t, i, o) {
            this.owner.close()
        }, this), !1
    },
    getBack: function() {
        return "choose_type"
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.CloudSummary", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            headline: _WFT("vfs", "wizard_cloud_summary_headline"),
            layout: "fit",
            height: 200,
            items: [this.formPanel = new SYNO.ux.FormPanel({
                items: [{
                    xtype: "syno_displayfield",
                    value: _WFT("vfs", "wizard_cloud_summary_greeting")
                }, {
                    xtype: "syno_displayfield",
                    name: "cloud_name",
                    fieldLabel: _WFT("vfs", "cloud_name")
                }, {
                    xtype: "syno_displayfield",
                    name: "email",
                    fieldLabel: _WFT("mount", "acc_name")
                }]
            })]
        };
        return Ext.apply(t, e), t
    },
    load: function(e) {
        this.formPanel.getForm().setValues(e)
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.Wizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = [this.chooseTypePanel = new SYNO.FileStation.RemoteConnection.ChooseType({
                itemId: "choose_type"
            }), this.VFSSettingPanel = new SYNO.FileStation.RemoteConnection.VFSSetting({
                itemId: "vfs_setting",
                nextId: null
            }), this.CloudSummaryPanel = new SYNO.FileStation.RemoteConnection.CloudSummary({
                itemId: "cloud_summary",
                nextId: null
            })],
            i = {
                title: _WFT("vfs", "wizard_title"),
                cls: "webfm-remote-server-setup-wizard",
                showHelp: !1,
                width: 658,
                height: 470,
                steps: t,
                listeners: {
                    beforeclose: this.onBeforeClose,
                    scope: this
                }
            };
        return Ext.apply(i, e), i
    },
    onOpen: function() {
        this.setActiveStep("choose_type"), SYNO.FileStation.RemoteConnection.Wizard.superclass.onOpen.apply(this, arguments)
    },
    onRender: function() {
        SYNO.FileStation.RemoteConnection.Wizard.superclass.onRender.apply(this, arguments), this.mon(this.chooseTypePanel, {
            loadcomplete: function() {
                this.syncView(), this.clearStatusBusy()
            },
            scope: this
        })
    },
    setServerType: function(e) {
        this.serverType = e
    },
    getServerType: function() {
        return this.serverType
    },
    load: function() {
        this.chooseTypePanel.load(), this.show().center()
    },
    onBeforeClose: function() {
        SYNO.webfm.utils.doClosePopup()
    }
}), Ext.define("SYNO.FileStation.RemoteConnection.ServerListDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            width: 810,
            height: 470,
            shadow: !0,
            minWidth: 550,
            minHeight: 350,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            title: _WFT("vfs", "server_list"),
            layout: "fit",
            items: [this.serverListGridPanel = new SYNO.FileStation.RemoteConnection.ProfileGrid({
                owner: this,
                title: _WFT("vfs", "server_list")
            })],
            buttons: [new SYNO.ux.Button({
                text: _WFT("common", "close"),
                scope: this,
                handler: this.close
            })]
        };
        return Ext.apply(t, e), t
    },
    load: function() {
        this.show().center()
    },
    applyHandler: function() {
        this.serverListGridPanel.applyHandler()
    }
}), Ext.namespace("SYNO.FileStation"), Ext.define("SYNO.FileStation.ProtocolUserGrid", {
    extend: "SYNO.ux.GridPanel",
    pageSize: 100,
    DEFAULT_ROLES: [
        ["local:user", _T("share", "share_local_user")],
        ["local:group", _T("share", "share_local_group")]
    ],
    LDAP_ROLES: [
        ["ldap:user", _T("share", "ldap_user")],
        ["ldap:group", _T("share", "ldap_group")]
    ],
    DOMAIN_ROLES: [
        ["domain:user", _T("share", "share_domain_user")],
        ["domain:group", _T("share", "share_domain_group")]
    ],
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            title: _WFT("vfs", "user_and_protocol"),
            enableHdMenu: !1,
            colModel: this.getColModel(),
            plugins: [this.getColumnEnabled()],
            tbar: this.getToolbar(),
            bbar: new SYNO.ux.PagingToolbar({
                pageSize: this.pageSize,
                store: this.getUserStore(),
                displayInfo: !0
            }),
            store: this.getUserStore()
        };
        return Ext.apply(t, e), t
    },
    getColModel: function() {
        return Ext.isDefined(this.columnModel) || (this.columnModel = new Ext.grid.ColumnModel({
            defaults: {
                align: "center",
                sortable: !1
            },
            columns: [this.getColumnEnabled(), {
                header: _T("common", "name"),
                dataIndex: "name",
                align: "left",
                width: 160
            }]
        })), this.columnModel
    },
    getColumnEnabled: function() {
        return Ext.isDefined(this.columnEnabled) || (this.columnEnabled = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enabled",
            disableSelectAll: !0,
            width: 120,
            isIgnore: function(e, t) {
                return !t.get("is_modifiable")
            },
            renderer: function(e, t, i) {
                return i.get("is_modifiable") ? SYNO.ux.EnableColumn.prototype.renderer.call(this, e, t, i) : SYNO.ux.EnableColumn.prototype.disableRenderer.call(this, i.get("enabled"), t, i)
            }
        })), this.columnEnabled
    },
    getToolbar: function() {
        return Ext.isDefined(this.protocolUserToolbar) || (this.protocolUserToolbar = new Ext.Toolbar({
            items: [this.getRoleComboBox(), "->", this.getDomainListLabel(), this.getDomainListComboBox(), this.getUsernameFilter()]
        })), this.protocolUserToolbar
    },
    getRoleComboBox: function() {
        return Ext.isDefined(this.roleComboBox) || (this.roleComboBox = new SYNO.ux.ComboBox({
            valueField: "role",
            displayField: "display",
            store: this.getRoleStore(),
            mode: "local",
            editable: !1,
            forceSelection: !0,
            width: 200,
            listeners: {
                scope: this,
                select: function(e, t, i) {
                    this.setDomainFilterVisible(0 === t.get("role").indexOf("domain")), this.getUserStore().load({
                        params: {
                            offset: 0
                        }
                    })
                }
            }
        })), this.roleComboBox
    },
    getDomainListLabel: function() {
        return Ext.isDefined(this.domainListLabel) || (this.domainListLabel = new SYNO.ux.DisplayField({
            value: _T("helptoc", "directory_service_domain") + ":",
            hidden: !0
        })), this.domainListLabel
    },
    getDomainListComboBox: function() {
        return Ext.isDefined(this.domainListComboBox) || (this.domainListComboBox = new SYNO.ux.ComboBox({
            valueField: "value",
            displayField: "domain",
            store: {
                xtype: "arraystore",
                autoDestroy: !0,
                fields: ["domain", "value", "comment"]
            },
            hidden: !0,
            mode: "local",
            editable: !1,
            value: "",
            forceSelection: !0,
            tpl: '<tpl for="."><div ext:qtip="{comment}" class="x-combo-list-item">{domain}</div></tpl>',
            listeners: {
                scope: this,
                select: function() {
                    this.getUserStore().load({
                        params: {
                            offset: 0
                        }
                    })
                }
            }
        })), this.domainListComboBox
    },
    getUsernameFilter: function() {
        return Ext.isDefined(this.usernameFilter) || (this.usernameFilter = new SYNO.ux.TextFilter({
            iconStyle: "filter",
            emptyText: _WFT("filetable", "filetable_search"),
            store: this.getUserStore(),
            queryParam: "substr",
            pageSize: this.pageSize
        })), this.usernameFilter
    },
    getUserStore: function() {
        return Ext.isDefined(this.userStore) || (this.userStore = new Ext.data.Store({
            autoLoad: !1,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.VFS.User",
                method: "get",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "usergrp_settings"
            }, [{
                name: "name"
            }, {
                name: "enabled"
            }, {
                name: "uid"
            }, {
                name: "gid"
            }, {
                name: "is_modifiable"
            }]),
            baseParams: {
                content: "user_settings",
                offset: 0,
                limit: this.pageSize
            },
            paramNames: {
                start: "offset",
                limit: "limit"
            },
            listeners: {
                scope: this,
                exception: function(e, t, i, o, n, s) {
                    this.findWindow().clearStatusBusy(), this.findWindow().getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, n, o))
                },
                beforeload: function(e, t) {
                    if (!this.isChanged()) {
                        var i = this.getRoleComboBox().getValue().split(":");
                        return t.params.type = i[0], t.params.usergroup = i[1], "user" === i[1] ? t.params.content = "user_settings" : "group" === i[1] && (t.params.content = "group_settings"), "domain" === t.params.type ? t.params.domain = this.getDomainListComboBox().getValue() : delete t.params.domain, this.findWindow().setStatusBusy({
                            text: _T("common", "loading")
                        }), !0
                    }
                    return this.findWindow().getMsgBox().confirm(this.title, _WFT("vfs", "save_chg_before_reload"), function(e) {
                        var i = this.getUserStore();
                        "yes" === e ? this.submitChanges(t) : (i.rejectChanges(), i.load(t))
                    }, this), !1
                },
                load: function() {
                    this.findWindow().clearStatusBusy()
                }
            }
        })), this.userStore
    },
    getRoleStore: function() {
        return Ext.isDefined(this.roleStore) || (this.roleStore = new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["role", "display"]
        }), this.roleStore.loadData(this.DEFAULT_ROLES)), this.roleStore
    },
    setDomainFilterVisible: function(e) {
        this.getDomainListLabel().setVisible(e), this.getDomainListComboBox().setVisible(e)
    },
    loadRoles: function(e) {
        var t = SYNO.API.Util.GetValByAPI(e, "SYNO.Core.Directory.LDAP", "get", "enable_client"),
            i = SYNO.API.Util.GetValByAPI(e, "SYNO.Core.Directory.Domain", "get", "enable_domain"),
            o = SYNO.API.Util.GetValByAPI(e, "SYNO.Core.Directory.Domain", "test_dc", "test_join_success"),
            n = "yes" === this._D("supportdomain") ? SYNO.API.Util.GetValByAPI(e, "SYNO.Core.Directory.Domain", "get_domain_list", "domain_list") : [],
            s = [];
        t && this.getRoleStore().loadData(this.LDAP_ROLES, !0), i && o && (this.getRoleStore().loadData(this.DOMAIN_ROLES, !0), n.forEach(function(e) {
            "object" === _typeof(e) ? s.push(e) : s.push([e, e, e])
        }), this.getDomainListComboBox().getStore().loadData(s), this.getDomainListComboBox().getValue() || this.getDomainListComboBox().setValue(s[0][1]), 1 === SYNO.API.Util.GetValByAPI(e, "SYNO.Core.Directory.Domain", "get", "manage_mode") ? this.getDomainListLabel().setValue(_T("directory_service", "organizational_unit") + ": ") : this.getDomainListLabel().setValue(_T("helptoc", "directory_service_domain") + ": ")), this.roleComboBox.setValue("local:user"), this.getUserStore().load()
    },
    isChanged: function() {
        return 0 !== this.getUserStore().getModifiedRecords().length
    },
    getSubmitParams: function() {
        var e = this.getUserStore().getModifiedRecords(),
            t = [],
            i = {
                settings: {}
            };
        if (0 === e.length) return null;
        for (var o = 0; o < e.length; o++) t.push({
            uid: e[o].get("uid"),
            gid: e[o].get("gid"),
            enabled: e[o].get("enabled")
        });
        return Ext.isEmpty(t[0].uid) ? i.settings.group_settings = t : i.settings.user_settings = t, i
    },
    submitChanges: function(e, t) {
        var i = this.getSubmitParams();
        if (!i) return void(!0 === t && this.findWindow().close());
        this.findWindow().setStatusBusy({
            text: _T("common", "loading")
        }), this.sendWebAPI({
            api: "SYNO.FileStation.VFS.User",
            method: "set",
            version: 1,
            params: i,
            load_options: e,
            scope: this,
            callback: function(e, i, o, n) {
                var s = this.getUserStore();
                this.findWindow().clearStatusBusy(), e ? (s.commitChanges(), Ext.isDefined(n.load_options) ? s.load(n.load_options) : !0 === t && this.findWindow().close()) : this.findWindow().getMsgBox().alert(SYNO.webfm.utils.getWebAPIErr(!1, i))
            }
        })
    }
}), Ext.define("SYNO.FileStation.ProtocolUserConfigDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            width: 800,
            height: 600,
            title: _WFT("common", "specific_user_group"),
            shadow: !0,
            minWidth: 700,
            minHeight: 500,
            collapsible: !1,
            layout: "fit",
            items: this.protocolUserGrid = new SYNO.FileStation.ProtocolUserGrid({}),
            buttons: [this.btnOK = new SYNO.ux.Button({
                text: _WFT("common", "cancel"),
                scope: this,
                handler: this.close
            }), new SYNO.ux.Button({
                btnStyle: "blue",
                text: _T("common", "ok"),
                scope: this,
                handler: this.applyHandler
            })],
            listeners: {
                afterrender: function() {
                    var e = [{
                        api: "SYNO.Core.Directory.LDAP",
                        method: "get",
                        version: 1
                    }, {
                        api: "SYNO.Core.Directory.Domain",
                        method: "get",
                        version: 1
                    }, {
                        api: "SYNO.Core.Directory.Domain",
                        method: "test_dc",
                        version: 1
                    }];
                    if ("yes" === this._D("supportdomain")) {
                        var t = {
                            api: "SYNO.Core.Directory.Domain",
                            method: "get_domain_list",
                            version: 1
                        };
                        this._S("version") > 4959 && (t.version = 2), e.push(t)
                    }
                    this.setStatusBusy({
                        text: _T("common", "loading")
                    }), this.sendWebAPI({
                        params: {},
                        compound: {
                            stopwhenerror: !1,
                            params: e
                        },
                        scope: this,
                        callback: function(e, t, i, o) {
                            this.clearStatusBusy(), this.protocolUserGrid.loadRoles(t)
                        }
                    })
                },
                scope: this
            }
        };
        return Ext.apply(t, e || {}), t
    },
    applyHandler: function() {
        this.protocolUserGrid.submitChanges(void 0, !0)
    }
}), Ext.ns("SYNO.FileStation"), Ext.define("SYNO.FileStation.Utils.SharingManager.EditRequestDialog", {
    extend: "SYNO.SDS.ModalWindow",
    params: null,
    oriValue: null,
    deleteWhenCancel: null,
    fakePwd: "1234567890",
    webapi: {
        set: {
            api: "SYNO.Core.Sharing",
            method: "set",
            version: 1
        }
    },
    constructor: function(e) {
        this.formPanel = this.createFormPanel(e), this.params = {}, Ext.apply(this.params, e.params), delete e.params;
        var t = {
            cls: "syno-webfm-edit-sharing-dialog",
            width: 700,
            height: 500,
            resizable: !1,
            collapsible: !1,
            layout: "fit",
            title: _T("sharing", "sharing_links"),
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCloseBtn
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                scope: this,
                handler: this.onSaveBtn
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            },
            items: [this.formPanel]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    getBtnBar: function() {
        return this.sharingCopyBtn = new SYNO.SDS.Utils.ClipBoardButton({
            tooltip: _WFT("sharing", "copy_url"),
            iconCls: "webfm-sharing-btn-icon copy-btn-icon",
            btnStyle: "grey",
            clipCfg: {
                clipTarget: "webfm-sharing-links-text-area"
            },
            listeners: {
                clipsucceed: function(e) {
                    SYNO.webfm.utils.showMessage(this, _WFT("sharing", "copy_to_clipboard"))
                },
                scope: this
            }
        }), this.sharingMailBtn = new SYNO.ux.Button({
            tooltip: _WFT("sharing", "mail_file_link"),
            iconCls: "webfm-sharing-btn-icon mail-btn-icon",
            listeners: {
                click: this.onBuildInMail,
                scope: this
            }
        }), this.sharingQRCodeBtn = new SYNO.ux.Button({
            tooltip: _T("sharing", "get_qrcode"),
            iconCls: "webfm-sharing-btn-icon qrcode-btn-icon",
            listeners: {
                click: this.onQRCodeBtn,
                scope: this
            }
        }), {
            xtype: "container",
            layout: "hbox",
            style: {
                "margin-bottom": "24px"
            },
            items: [{
                xtype: "syno_displayfield",
                width: 208
            }, {
                xtype: "syno_toolbar",
                style: {
                    padding: 0,
                    border: 0
                },
                items: [this.sharingCopyBtn, this.sharingMailBtn, this.sharingQRCodeBtn]
            }]
        }
    },
    getSharingLinkTextAreaConfig: function(e) {
        return {
            xtype: "container",
            layout: "hbox",
            cls: "syno-webfm-sharing-form-items",
            items: [{
                xtype: "syno_displayfield",
                width: 200,
                value: _WFT("sharing", "links_to_share") + ":"
            }, {
                xtype: "syno_textarea",
                id: "webfm-sharing-links-text-area",
                name: "url",
                width: 476,
                height: 28,
                cls: "syno-webfm-sharing-field",
                readOnly: !0,
                autoFlexcroll: !0,
                selectOnFocus: !0
            }]
        }
    },
    getValidPeriodConfigs: function(e) {
        var t = new Date,
            i = {
                editable: !1,
                isAllDay: !1,
                allowBlank: !1,
                width: 380,
                cls: "syno-webfm-sharing-field",
                disabled: !0,
                validator: this.isValidTime.createDelegate(this)
            };
        this.startDateTimeField = new SYNO.ux.DateTimeField(Ext.apply(i, {
            name: "start_at",
            listeners: {
                change: function() {
                    this.expireDateTimeField.setMinValue(this.startDateTimeField.getValue())
                },
                scope: this
            }
        })), this.expireDateTimeField = new SYNO.ux.DateTimeField(Ext.apply(i, {
            name: "expire_at",
            minValue: t,
            listeners: {
                change: function() {
                    this.startDateTimeField.validate()
                },
                scope: this
            }
        }));
        var o = {
            width: 268,
            margins: "0 0 0 28"
        };
        return this.startCheckbox = new SYNO.ux.Checkbox(Ext.apply(o, {
            boxLabel: _WFT("sharing", "setup_start_time"),
            name: "start_at_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.startDateTimeField.enable() : this.startDateTimeField.disable(), this.startDateTimeField.validate()
                },
                scope: this
            }
        })), this.expireCheckbox = new SYNO.ux.Checkbox(Ext.apply(o, {
            boxLabel: _WFT("sharing", "setup_stop_time"),
            name: "expire_at_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.expireDateTimeField.enable() : this.expireDateTimeField.disable(), this.expireDateTimeField.validate()
                },
                scope: this
            }
        })), this.limitTimesTextField = new SYNO.ux.NumberField({
            name: "expire_times",
            itemId: "expire_times",
            width: 380,
            indent: 1,
            value: 99,
            minValue: 0,
            maxlength: 4,
            vtype: "number",
            disabled: !0,
            cls: "syno-webfm-sharing-field"
        }), this.limitTimesCheckbox = new SYNO.ux.Checkbox(Ext.apply(o, {
            boxLabel: _WFT("sharing", "expire_times"),
            name: "expire_times_enable",
            listeners: {
                check: function(e, t) {
                    t ? this.limitTimesTextField.enable() : this.limitTimesTextField.disable()
                },
                scope: this
            }
        })), [{
            xtype: "container",
            style: {
                "margin-bottom": "10px"
            },
            items: [{
                xtype: "syno_displayfield",
                value: _WFT("sharing", "validity_period"),
                cls: "syno-webfm-sharing-form-items"
            }, {
                xtype: "container",
                itemId: "start_setting",
                layout: "hbox",
                cls: "syno-webfm-sharing-form-items",
                items: [this.startCheckbox, this.startDateTimeField]
            }, {
                xtype: "container",
                itemId: "expire_setting",
                layout: "hbox",
                cls: "syno-webfm-sharing-form-items",
                items: [this.expireCheckbox, this.expireDateTimeField]
            }]
        }, {
            xtype: "container",
            style: {
                "margin-bottom": "36px"
            },
            items: [{
                xtype: "syno_displayfield",
                value: _WFT("sharing", "number_allowed_access"),
                cls: "syno-webfm-sharing-form-items"
            }, {
                xtype: "container",
                layout: "hbox",
                items: [this.limitTimesCheckbox, this.limitTimesTextField]
            }]
        }]
    },
    getLinkSettingFieldSet: function(e) {
        return {
            xtype: "syno_fieldset",
            title: _WFT("file_sharing", "link_settings"),
            itemId: "link_setting_fieldset",
            bwrapStyle: {
                padding: "12px 8px 8px 8px"
            },
            collapsible: !0,
            collapsed: !1,
            items: [this.getPathFieldConfig(e), this.getSharingLinkTextAreaConfig(e), this.getBtnBar(e), this.getSecurityFieldConfigs(e), this.getValidPeriodConfigs(e)]
        }
    },
    getCustomMsgFieldSet: function(e) {
        var t = {
            xtype: "syno_displayfield",
            value: _WFT("file_sharing", "customized_message_desc")
        };
        return this.customMsgFieldSet = new SYNO.ux.FieldSet({
            title: _WFT("file_sharing", "customized_message"),
            itemId: "custom_msg_fieldset",
            bwrapStyle: {
                padding: "12px 8px 8px 8px"
            },
            collapsible: !0,
            collapsed: !0,
            items: [t, this.getRequestNameFieldConfig(), this.getRequestInfoFieldConfig()]
        }), this.customMsgFieldSet
    },
    getFormItemConfigs: function(e) {
        return [].concat(this.getLinkSettingFieldSet(e)).concat(this.getCustomMsgFieldSet(e))
    },
    getRequestNameFieldConfig: function() {
        return {
            xtype: "container",
            layout: "hbox",
            cls: "syno-webfm-sharing-form-items",
            items: [{
                xtype: "syno_displayfield",
                value: _WFT("sharing", "request_name") + ":",
                width: 200
            }, {
                xtype: "syno_textfield",
                cls: "syno-webfm-sharing-field",
                name: "request_name",
                itemId: "request_name",
                width: 492
            }]
        }
    },
    getRequestInfoFieldConfig: function() {
        return {
            xtype: "container",
            layout: "hbox",
            style: {
                "margin-bottom": "8px"
            },
            items: [{
                xtype: "syno_displayfield",
                value: _WFT("sharing", "request_info") + ":",
                width: 200
            }, {
                xtype: "syno_textarea",
                cls: "syno-webfm-sharing-field",
                name: "request_info",
                itemId: "request_info",
                height: 70,
                width: 492
            }]
        }
    },
    createFormPanel: function(e) {
        return new SYNO.ux.FormPanel({
            border: !1,
            updateFormForScrollbar: !0,
            items: this.getFormItemConfigs(e)
        })
    },
    setValues: function(e) {
        var t = new Date,
            i = new Date(t);
        i.setDate(i.getDate() + 1), e.start_at ? (e.start_at instanceof Date || (e.start_at = Date.parseDate(e.start_at, "Y-m-d H:i:s")), this.startCheckbox.setValue(!0)) : e.start_at = t, e.expire_at ? (e.expire_at instanceof Date || (e.expire_at = Date.parseDate(e.expire_at, "Y-m-d H:i:s")), this.expireCheckbox.setValue(!0)) : e.expire_at = i, e.expire_times ? this.limitTimesCheckbox.setValue(!0) : e.expire_times = 99, e.protect_type && "none" !== e.protect_type && (e.protect_type_enable = !0, e.protect_password = this.fakePwd), this.isProtectPasswordEdited = !1, this.params.app = void 0 !== this.params.app ? this.params.app : {}, this.params.project_name = void 0 !== this.params.project_name ? this.params.project_name : "", this.params.sharing_id = e.hash, Ext.apply(this.params.app, e.app), this.params.redirect_type = void 0 !== this.params.redirect_type ? this.params.redirect_type : e.redirect_type, this.params.redirect_uri = void 0 !== this.params.redirect_uri ? this.params.redirect_uri : e.redirect_uri, this.params.auto_gc = void 0 !== this.params.auto_gc ? this.params.auto_gc : e.auto_gc, this.params.enable_match_ip = void 0 !== this.params.enable_match_ip ? this.params.enable_match_ip : e.enable_match_ip, this.params.enabled = void 0 !== this.params.enabled ? this.params.enabled : e.enabled, this.params.url = e.url, this.params.qrcode = e.qrcode, this.params.path = e.path, e.url = Ext.isArray(e.url) ? e.url.join("\n") : e.url, this.formPanel.getForm().setValues(e), this.oriValue = this.getValues()
    },
    getValues: function() {
        var e, t = this.formPanel.getForm().getValues();
        return this.startCheckbox.getValue() ? t.start_at = this.startDateTimeField.getValue().format("Y-m-d H:i:s") : t.start_at = "", this.expireCheckbox.getValue() ? t.expire_at = this.expireDateTimeField.getValue().format("Y-m-d H:i:s") : t.expire_at = "", this.limitTimesCheckbox.getValue() ? t.expire_times = this.limitTimesTextField.getValue() : t.expire_times = 0, "true" !== t.protect_type_enable && (t.protect_type = "none"), t.protect_users_groups && (Ext.isArray(t.protect_users_groups) || (t.protect_users_groups = [t.protect_users_groups]), t.protect_users = [], t.protect_groups = [], Ext.each(t.protect_users_groups, function(i) {
            (e = i.match(/(.*):user$/)) ? t.protect_users.push(e[1]): (e = i.match(/(.*):group$/)) && t.protect_groups.push(e[1])
        })), t.protect_password && (this.fakePwd !== t.protect_password || this.isProtectPasswordEdited) || delete t.protect_password, "password" !== t.protect_type || t.protect_password || delete t.protect_type, t.redirect_uri || delete t.redirect_uri, Ext.apply(t, this.params), t
    },
    getFinalValues: function() {
        return this.oriValue
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    isValidTime: function() {
        var e = this.startDateTimeField.getValue(),
            t = this.expireDateTimeField.getValue(),
            i = new Date;
        return this.expireCheckbox.getValue() && t <= i ? _WFT("error", "exp_before_today") : !(this.startCheckbox.getValue() && this.expireCheckbox.getValue() && e >= t) || String.format(_T("sharing", "time_set_error"), _T("sharing", "start_at_time"), _T("sharing", "expire_at_time"))
    },
    isUsersGroup: function(e) {
        return !!e && !("guest" !== e && "users" !== e && !e.match(/^users@.*/i) && !e.match(/.*\\Domain Users$/i))
    },
    handleErrors: function(e) {
        switch (SYNO.Debug.error(e), this.setStatusError(_T("common", "error_system")), e.code) {
            case 1009:
                this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups").markInvalid(_T("sharing", "error_entry_user"));
                break;
            case 1010:
                this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_password").markInvalid(_T("sharing", "error_entry_passwd"))
        }
    },
    onUserComboNewItem: function(e, t) {
        if (t && !this.isUsersGroup(t)) {
            var i = "@" === t[0] ? "group" : "user",
                o = "@" === t[0] ? t.substr(1, t.length) : t;
            e.addNewItem({
                name: Ext.util.Format.htmlEncode(o),
                type: i,
                value: o + ":" + i
            }, !0)
        }
    },
    onUserStoreLoad: function(e, t, i) {
        var o = this.formPanel.getComponent("link_setting_fieldset").getComponent("secure_fieldset").getComponent("protect_users_groups"),
            n = o.pageTb;
        Ext.each(t, function(t) {
            this.isUsersGroup(t.data.name) && e.remove(t)
        }, this), !0 === this.disableLastPage && n.getPageData().activePage === this.lastPage - 1 && (n.setBtnText(n.btn4, ""), n.next.disable(), n.last.disable()), e.getCount() <= 0 && (this.disableLastPage = !0, this.lastPage = n.getPageData().activePage, 1 < this.lastPage && n.jumpPageByOffset(-1))
    },
    onAfterRender: function() {},
    onProtectPasswordFocus: function(e) {
        e.setValue(null), this.isProtectPasswordEdited = !0
    },
    onBuildInMail: function() {
        SYNO.webfm.utils.buildSharingQRCodeMail(this.getValues().url, this.getValues().qrcode)
    },
    onSaveBtn: function() {
        if (this.isValid()) {
            var e = this.getValues();
            if (SYNO.ux.Utils.checkObjectConsistency(e, this.oriValue)) return void this.close();
            this.setStatusBusy(), this.sendWebAPI(Ext.apply({
                params: e,
                scope: this,
                callback: function(t, i, o, n) {
                    this.clearStatusBusy(), t ? (this.oriValue = e, this.close()) : this.handleErrors(i)
                }
            }, this.webapi.set))
        }
    },
    onCloseBtn: function() {
        this.close()
    }
}), Ext.define("SYNO.FileStation.EditFileRequestDialog", {
    extend: "SYNO.FileStation.Utils.SharingManager.EditRequestDialog",
    constructor: function(e) {
        this.urls = [], this.files = [], this.linkIDs = [], this.filenames = [], Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t]), this.addEvents("onEditDone")
    },
    fillConfig: function(e) {
        var t = {
            title: _WFT("sharing", "file_request"),
            width: 740,
            height: 480
        };
        return Ext.apply(t, e || {}), t
    },
    getFormItemConfigs: function() {
        return this.callParent(arguments)
    },
    getPathFieldConfig: function() {
        return this.filePathDisplayField = new SYNO.ux.DisplayField({
            name: "path",
            width: 334,
            cls: "syno-webfm-sharing-field",
            htmlEncode: !0
        }), {
            xtype: "container",
            layout: "hbox",
            align: "stretch",
            cls: "syno-webfm-sharing-form-items",
            items: [{
                xtype: "syno_displayfield",
                width: 200,
                value: _WFT("common", "file_path") + ":"
            }, this.filePathDisplayField]
        }
    },
    getSecurityFieldConfigs: function() {
        return this.passwordField = new SYNO.ux.TextField({
            xtype: "syno_textfield",
            name: "protect_password",
            itemId: "protect_password",
            disabled: !0,
            width: 380,
            cls: "syno-webfm-sharing-field",
            textType: "password",
            allowBlank: !1,
            listeners: {
                scope: this,
                focus: this.onProtectPasswordFocus
            }
        }), {
            xtype: "container",
            style: {
                "margin-bottom": "24px"
            },
            items: [{
                xtype: "container",
                cls: "syno-webfm-sharing-form-items",
                items: [{
                    xtype: "syno_checkbox",
                    name: "protect_type_enable",
                    boxLabel: _WFT("sharing", "enable_password"),
                    listeners: {
                        scope: this,
                        check: function(e, t) {
                            this.passwordField.setDisabled(!t)
                        }
                    }
                }]
            }, {
                xtype: "container",
                layout: "hbox",
                items: [{
                    xtype: "syno_displayfield",
                    value: _WFT("sharing", "enter_password") + ":",
                    width: 296,
                    style: {
                        "padding-left": "28px"
                    }
                }, this.passwordField]
            }]
        }
    },
    onAfterRender: function() {
        this.onUpdateForm()
    },
    onUpdateForm: function() {
        var e = {
            path: this.files,
            url: this.urls,
            qrcode: this.linkQRCodes
        };
        Ext.isEmpty(this.link_info) ? (e.request_name = this.request_name, e.request_info = this.request_info, this.setValues(e)) : (Ext.apply(this.link_info, e), this.setValues(this.link_info));
        var t = this.files[0],
            i = '<div style="text-overflow: ellipsis; overflow: hidden" ext:qtip="' + t + '">' + t + "</div>";
        this.filePathDisplayField.update(i)
    },
    getValues: function() {
        var e = this.formPanel.getForm().getValues();
        return e = Ext.copyTo(e, SYNO.FileStation.EditFileRequestDialog.superclass.getValues.call(this), ["expire_at", "start_at", "expire_times"]), "true" !== e.protect_type_enable ? e.protect_type = "none" : e.protect_type = "password", e.protect_password && (this.fakePwd !== e.protect_password || this.isProtectPasswordEdited) || delete e.protect_password, "password" !== e.protect_type || e.protect_password || delete e.protect_type, Ext.apply(e, this.params), e
    },
    onPrepareParam: function() {
        var e = this.getValues();
        return e.id = this.linkIDs, Ext.isEmpty(e.protect_password) || (e.password = e.protect_password, delete e.protect_password), Ext.isEmpty(e.expire_at) || (e.date_expired = e.expire_at, delete e.expire_at), Ext.isEmpty(e.start_at) || (e.date_available = e.start_at, delete e.start_at), e.file_request = !0, e
    },
    onSaveBtn: function() {
        if (!this.isValid()) return void this.getMsgBox().alert("", _T("common", "forminvalid"));
        this.copyUrlToClipBoard();
        var e = this.getValues();
        if (SYNO.ux.Utils.checkObjectConsistency(e, this.oriValue)) return void this.close();
        var t = this.onPrepareParam();
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "edit",
            version: 3,
            params: t,
            scope: this,
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("onEditDone", this), this.close()) : this.onShowError(_WFT("error", "error_error_system"))
            }
        })
    },
    onCloseBtn: function() {
        this.close()
    },
    onShowError: function(e) {
        var t = _WFT("common", "share");
        this.getMsgBox().alert(t, e, function(e) {
            this.close()
        }, this)
    },
    copyUrlToClipBoard: function() {
        var e = this.formPanel.getForm().findField("url").el.dom;
        e.select && e.select(), this.copySuccess = !!document.execCommand && document.execCommand("copy"), e.selectionStart = e.selectionEnd = -1
    },
    onQRCodeBtn: function() {
        var e = this.getValues();
        new SYNO.FileStation.Utils.QRCodeDialog({
            owner: this,
            path: Ext.isArray(e.path) ? e.path : [e.path],
            qrcode: Ext.isArray(e.qrcode) ? e.qrcode : [e.qrcode]
        }).open()
    }
}), Ext.define("SYNO.FileStation.FileRequestDialog", {
    extend: "SYNO.FileStation.EditFileRequestDialog",
    constructor: function(e) {
        this.callParent(arguments)
    },
    onSetFiles: function() {
        var e = 0;
        Ext.isArray(this.paths) && this.paths.forEach(function(t) {
            this.files[e] = t.get("file_id"), this.filenames[e] = t.get("filename"), e++
        }, this)
    },
    getFormItemConfigs: function() {
        this.validSharedLinks = [];
        var e = this.callParent(arguments);
        return this.getLinksByPathAndCreateLink(this.paths[0].get("file_id")), 1 <= this.validSharedLinks.length && e[0].items.splice(0, 0, this.getLinkBtnBarConfig()), e
    },
    getLinksByPathAndCreateLink: function(e) {
        var t = {
                check_link_history: !0,
                path: e,
                sort_by: "id",
                sort_direction: "dec",
                filter_type: "SYNO.SDS.App.SharingUpload.Application"
            },
            i = [];
        this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "list",
            version: 3,
            async: !1,
            timeout: 10,
            params: t,
            callback: function(e, t, o) {
                if (e && Ext.isArray(t.links)) {
                    var n, s = t.links.length;
                    if (0 === s) return;
                    n = 1 === s ? t : {
                        links: [t.links[0]]
                    }, this.setLinksInfo(n);
                    var r = n.links[0];
                    this.link_info = {
                        start_at: r.date_available,
                        expire_at: r.date_expired,
                        expire_times: r.expire_times,
                        protect_type: r.protect_type,
                        protect_users: r.protect_users,
                        request_name: r.request_name,
                        request_info: r.request_info
                    }, Ext.each(t.links, function(e) {
                        i.push(e)
                    })
                } else {
                    var a = SYNO.webfm.utils.getWebAPIErr(e, t, o);
                    this.onShowError(a)
                }
            },
            scope: this
        }), this.validSharedLinks = i, this.justCreate = !1
    },
    getLinkBtnBarConfig: function() {
        var e = [];
        return this.createNewLinkBtn = new SYNO.ux.Button({
            text: _WFT("sharing", "create_new_link"),
            height: 28,
            listeners: {
                click: function() {
                    this.onCreateLinks(this.files), SYNO.webfm.utils.showMessage(this, _WFT("sharing", "link_be_updated")), this.otherLinksBtn.show()
                },
                scope: this
            }
        }), e.push(this.createNewLinkBtn), this.otherLinksBtn = new SYNO.ux.Button({
            text: _WFT("sharing", "other_link"),
            height: 28,
            hidden: 1 >= this.validSharedLinks.length,
            listeners: {
                click: function() {
                    this.pastLinkPanel = new SYNO.FileStation.Utils.PastLinkDialog({
                        owner: this,
                        links: this.validSharedLinks
                    }), this.pastLinkPanel.open()
                },
                scope: this
            }
        }), e.push(this.otherLinksBtn), {
            xtype: "container",
            layout: "hbox",
            style: {
                "margin-bottom": "16px"
            },
            items: [{
                xtype: "syno_toolbar",
                items: e,
                style: {
                    border: "0",
                    padding: "0"
                }
            }]
        }
    },
    onCreateLinks: function(e) {
        var t = {
            path: e,
            request_name: _S("user"),
            request_info: _WFT("sharing", "default_request_info"),
            file_request: !0
        };
        this.setStatusBusy({
            text: _WFT("sharing", "creating_new_link")
        }), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "create",
            version: 3,
            params: t,
            scope: this,
            callback: this.onCreateCallback
        }), this.justCreate = !0
    },
    onCreateCallback: function(e, t, i) {
        if (this.clearStatusBusy(), e && Ext.isArray(t.links)) this.formPanel.getForm().reset(), delete this.link_info, this.setLinksInfo(t), this.onUpdateForm();
        else {
            var o = SYNO.webfm.utils.getWebAPIErr(e, t, i);
            this.onShowError(o)
        }
    },
    onAfterRender: function() {
        this.onSetFiles(), this.callParent(arguments), 0 === this.validSharedLinks.length && this.onCreateLinks(this.files)
    },
    setLinksInfo: function(e) {
        this.urls = [], this.linkIDs = [], this.linkQRCodes = [];
        var t, i = e.links,
            o = i.length,
            n = 0;
        for (n = 0; n < o; n++) t = i[n], this.urls.push(t.error ? "" : t.url), this.linkIDs.push(t.error ? "" : t.id), this.linkQRCodes.push(t.error ? "" : t.qrcode), this.request_name = t.request_name, this.request_info = t.request_info
    },
    onCloseBtn: function() {
        this.justCreate ? (this.setStatusBusy(), this.onDeleteLinks()) : this.close()
    },
    onDeleteLinks: function() {
        this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "delete",
            version: 3,
            params: {
                id: this.linkIDs
            },
            scope: this,
            callback: function(e, t) {
                this.clearStatusBusy(), e ? this.close() : this.onShowError(_WFT("error", "error_error_system"))
            }
        })
    }
}), Ext.ns("SYNO.FileStation"), Ext.define("SYNO.FileStation.SharingSummaryWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = {
            owner: this.owner,
            width: 650,
            height: 360,
            resizable: !1,
            shadow: !0,
            collapsible: !1,
            title: _WFT("sharing", "sharing_links"),
            layout: "fit",
            trackResetOnLoad: !0,
            forceSelection: !0,
            waitMsgTarget: !0,
            border: !1,
            items: this.initPanel(),
            footerStyle: "padding: 12px 4px 0 0",
            buttons: [{
                itemId: "close_button",
                text: _WFT("common", "close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }]
        };
        SYNO.FileStation.SharingSummaryWindow.superclass.constructor.call(this, t), this.mon(this, "afterlayout", function() {
            SYNO.ux.AddTip(this.get("textarea").get("share_link_message").getEl(), _WFT("sharing", "mailto_desc"))
        }, this, {
            single: !0
        })
    },
    initPanel: function() {
        var e = {
            itemId: "textarea",
            border: !1,
            items: [{
                xtype: "syno_displayfield",
                width: "auto",
                itemId: "share_link_message",
                htmlEncode: !1,
                value: String.format(_WFT("sharing", "full_instruction"), "<a class='pathlink'>" + _WFT("common", "buildin_mail") + "</a>", "<a class='pathlink'>" + _WFT("common", "mail") + "</a>"),
                listeners: {
                    render: function(e) {
                        this.mon(e.el.child("a:nth-child(1)"), "click", this.onBuildInMail, this), this.mon(e.el.child("a:nth-child(2)"), "click", this.onMail, this)
                    },
                    scope: this,
                    single: !0,
                    buffer: 80
                }
            }, {
                xtype: "syno_textarea",
                name: "urls",
                itemId: "urls",
                layout: "fit",
                hideLabel: !0,
                anchor: "100% 80%",
                value: this.content,
                cls: "selectabletext allowDefCtxMenu",
                selectOnFocus: !0
            }]
        };
        return new SYNO.ux.FormPanel(e)
    },
    onMail: function() {
        SYNO.webfm.utils.onMailTo(this.mailBody)
    },
    onBuildInMail: function() {
        var e = this.mailBody.split("%0A%0A"),
            t = e.reduce(function(e, t) {
                return e + "<div>" + t + "</div>"
            }, "");
        SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", {
            content: t
        })
    },
    load: function() {
        this.focusEl = this.get("textarea").get("urls"), this.show().center()
    }
}), Ext.define("SYNO.FileStation.SharingManager.SharingPanel", {
    extend: "SYNO.SDS.Utils.SharingManager.SharingPanel",
    pageSize: 50,
    constructor: function(e) {
        this.filterType = "all", Ext.apply(this, e || {});
        var t = this.fillConfig();
        this.callParent([t])
    },
    fillConfig: function() {
        return {
            title: _WFT("sharing", "sharing_all"),
            colModel: this.createColModel(),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: function(e, t) {
                        var i = e.getSelections();
                        0 === i.length ? this.setActionDisable([!0, !0, !0]) : 1 === i.length ? this.setActionDisable([!1, !1, !1]) : this.setActionDisable([!0, !1, !1])
                    },
                    scope: this
                }
            }),
            listeners: {
                afterrender: function() {
                    this.store.load()
                },
                dblclick: this.onDblClick,
                scope: this
            }
        }
    },
    createColModel: function() {
        return SYNO.FileStation.SharingManager.Common.createColModel(this)
    },
    createStore: function() {
        return SYNO.FileStation.SharingManager.Common.createStore("list", this)
    },
    setActionDisable: function(e) {
        this.editAction.setDisabled(e[0]), this.delAction.setDisabled(e[1]), this.summaryAction.setDisabled(e[2])
    },
    createActionGroup: function() {
        return this.editAction = new Ext.Action({
            text: _WFT("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.onEditBtn,
            disabled: !0
        }), this.delAction = new Ext.Action({
            text: _WFT("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.onDeleteBtn,
            disabled: !0
        }), this.summaryAction = new Ext.Action({
            text: _WFT("sharing", "summarize"),
            itemId: "summarize",
            scope: this,
            handler: this.onSummarize,
            disabled: !0
        }), this.cleanAction = new Ext.Action({
            text: _WFT("sharing", "clean_badlinks"),
            itemId: "clean_broken",
            scope: this,
            handler: this.onCleanBrokenBtn
        }), this.filterAction = SYNO.FileStation.SharingManager.Common.createFilterBox(this), new SYNO.ux.Utils.ActionGroup([this.editAction, this.delAction, this.summaryAction, this.cleanAction, "->", this.filterAction])
    },
    preparePDFViewerParam: function(e) {
        var t = e.data;
        return t.app = e.json.app, t.hash = e.get("id"), t.redirect_type = "none", t
    },
    onFilterType: function(e, t, i) {
        this.filterType = t.get("value"), this.getStore().baseParams.filter_type = SYNO.FileStation.SharingManager.Common.getFilterTypeStr(this.filterType), this.refreshPagingTool()
    },
    onEditBtn: function() {
        this.openEditSharingDialog()
    },
    onDblClick: function() {
        this.openEditSharingDialog()
    },
    openEditSharingDialog: function() {
        var e = this.getSelectionModel().getSelected();
        if (!Ext.isEmpty(e)) {
            if ("broken" == e.get("status")) return void this.owner.getMsgBox().alert(_WFT("common", "alt_edit"), _WFT("error", "edit_bklink"));
            var t, i = {
                owner: this.owner,
                webfm: this.webfm,
                link_info: e.data,
                linkIDs: [e.get("id")],
                files: [e.get("path")],
                urls: [e.get("url")],
                linkQRCodes: [e.get("qrcode")],
                enableListUserGrp: this.webfm.enableListUserGrp
            };
            if ("SYNO.SDS.App.SharingUpload.Application" === e.get("project_name")) t = new SYNO.FileStation.EditFileRequestDialog(i);
            else if ("SYNO.SDS.PDFViewer.Application" == e.get("project_name")) {
                if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.PDFViewer.Application")) return;
                t = new SYNO.SDS.PDFViewer.Settings.EditSharingDialog({
                    owner: this.owner,
                    params: {
                        project_name: "SYNO.SDS.PDFViewer.Application"
                    }
                }), t.setValues(this.preparePDFViewerParam(e))
            } else t = new SYNO.FileStation.EditSharingDialog(i);
            this.mon(t, "close", this.onEditDone, this), t.show().center()
        }
    },
    onEditDone: function() {
        this.refreshPagingTool()
    },
    onDeleteBtn: function() {
        var e = _WFT("common", "delete"),
            t = _WFT("sharing", "delete_confirm"),
            i = this.getSelectionModel().getSelections();
        0 !== i.length && this.owner.getMsgBox().confirmDelete(e, t, function(e) {
            "yes" == e && this.onDelete(i)
        }, this)
    },
    onDelete: function(e) {
        var t = [];
        e.forEach(function(e) {
            t.push(e.get("id"))
        }), this.owner.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "delete",
            version: 3,
            single: !0,
            params: {
                id: t
            },
            callback: function(e, t, i) {
                this.owner.clearStatusBusy(), e ? (this.owner.webfm.FileAction.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, "sharing"), this.refreshPagingTool()) : this.owner.getMsgBox().alert("", _WFT("common", "delete"))
            },
            scope: this
        })
    },
    onSummarize: function() {
        var e = this.getSelectionModel().getSelections();
        if (0 !== e.length) {
            var t = this.getSummary(e);
            new SYNO.FileStation.SharingSummaryWindow({
                content: t,
                mailBody: this.urls.join("%0A%0A"),
                owner: this.owner
            }).load()
        }
    },
    getSummary: function(e) {
        var t, i, o, n, s, r = "",
            a = "",
            l = 0;
        for (this.urls = [], n = 0; n < e.length; n++) i = e[n].get("status"), t = e[n].get("name"), o = !Ext.isEmpty(e[n].get("expire_at")), "valid" == i ? (this.urls[l] = e[n].get("url"), r += t + ":\n" + this.urls[l], l++, o && (s = e[n].get("expire_at"), r += "\n" + _WFT("sharing", "exp_date") + ": " + SYNO.webfm.utils.DateTimeFormatter(Date.parseDate(s, "Y-m-d H:i:s"), {
            type: "datetimesec"
        })), r += "\n\n") : "inactive" == i ? (this.urls[l] = e[n].get("url"), r += t + ":\n" + this.urls[l], l++, o && (s = e[n].get("start_at"), r += "\n" + _WFT("sharing", "avail_date") + ": " + SYNO.webfm.utils.DateTimeFormatter(Date.parseDate(s, "Y-m-d H:i:s"), {
            type: "datetimesec"
        })), r += "\n\n") : "broken" == i ? a += t + ":\n" + _WFT("sharing", "summary_broken") + "\n\n" : "expired" == i && (a += t + ":\n" + _WFT("sharing", "summary_expired") + "\n\n");
        return r += a
    },
    onCleanBrokenBtn: function() {
        var e = _WFT("sharing", "clean_badlinks"),
            t = _WFT("sharing", "clean_confirm");
        this.owner.getMsgBox().confirmDelete(e, t, function(e) {
            "yes" == e && this.onClean()
        }, this)
    },
    onClean: function() {
        var e = _WFT("sharing", "clean_badlinks");
        this.owner.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.FileStation.Sharing",
            method: "clear_invalid",
            version: 2,
            callback: function(t, i, o) {
                if (this.owner.clearStatusBusy(), t) {
                    var n = _WFT("sharing", "cleaned");
                    this.onLoadFirstPage(), this.owner.getMsgBox().alert(e, n)
                } else this.errorHandler(e, t, i, o)
            },
            scope: this
        })
    },
    onLoadFirstPage: function() {
        var e = this.store.getSortState();
        this.store.load({
            params: {
                offset: 0,
                limit: this.pageSize,
                sort_by: e ? e.field : "",
                sort_direction: e ? e.direction : ""
            }
        })
    },
    errorHandler: function(e, t, i, o) {
        var n = SYNO.webfm.utils.getWebAPIErr(t, i, o);
        e = e || _WFT("common", "share"), this.owner.getMsgBox().alert(e, n), this.refreshPagingTool()
    }
}), Ext.define("SYNO.FileStation.SharingManager.ShareWithMePanel", {
    extend: "SYNO.SDS.Utils.SharingManager.ShareWithMePanel",
    pageSize: 50,
    constructor: function(e) {
        this.filterType = "all", Ext.apply(this, e || {});
        var t = this.fillConfig();
        this.callParent([t])
    },
    createColModel: function() {
        return SYNO.FileStation.SharingManager.Common.createColModel(this)
    },
    createStore: function() {
        return SYNO.FileStation.SharingManager.Common.createStore("list_share_me", this)
    },
    fillConfig: function() {
        return this.viewBtn = new SYNO.ux.Button({
            text: _WFT("acl_editor", "view"),
            handler: this.onViewClick,
            scope: this,
            disabled: !0
        }), this.filter_box = SYNO.FileStation.SharingManager.Common.createFilterBox(this), {
            title: _WFT("sharing", "share_with_me"),
            height: 300,
            colModel: this.createColModel(),
            selModel: new Ext.grid.RowSelectionModel({
                listeners: {
                    selectionchange: function(e, t) {
                        1 === e.getSelections().length ? this.viewBtn.setDisabled(!1) : this.viewBtn.setDisabled(!0)
                    },
                    scope: this
                }
            }),
            listeners: {
                afterrender: function() {
                    this.store.load()
                },
                scope: this
            },
            tbar: [this.viewBtn, "->", this.filter_box]
        }
    },
    onFilterType: function(e, t, i) {
        this.filterType = t.get("value"), this.getStore().baseParams.filter_type = SYNO.FileStation.SharingManager.Common.getFilterTypeStr(this.filterType), this.refreshPagingTool()
    },
    onViewClick: function() {
        this.onShowSharingEntryDialog()
    }
}), Ext.define("SYNO.FileStation.SharingManager.Manger", {
    extend: "SYNO.SDS.Utils.SharingManager.Manager",
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            title: _WFT("sharing", "sharing_manager"),
            height: 405
        };
        return Ext.apply(t, e || {}), t
    },
    createTabPanel: function(e) {
        return new SYNO.ux.TabPanel({
            activeTab: 0,
            items: [new SYNO.FileStation.SharingManager.SharingPanel({
                owner: this,
                webfm: this.webfm,
                RELURL: this.RELURL,
                params: e.params
            }), new SYNO.FileStation.SharingManager.ShareWithMePanel({
                owner: this,
                RELURL: this.RELURL,
                params: e.params
            })]
        })
    }
}), Ext.define("SYNO.FileStation.SharingManager.Common", {
    statics: {
        getTypeArray: function() {
            var e = [
                ["all", _WFT("sharing", "sharing_all")],
                ["SYNO.SDS.App.FileStation3.Instance", _WFT("sharing", "sharing_links")],
                ["SYNO.SDS.App.SharingUpload.Application", _WFT("sharing", "request_link")]
            ];
            return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.PDFViewer.Application") && e.push(["SYNO.SDS.PDFViewer.Application", _WFT("sharing", "document_link")]), e
        },
        getFilterTypeStr: function(e) {
            var t = "";
            if ("all" === e) {
                var i = 0,
                    o = SYNO.FileStation.SharingManager.Common.getTypeArray();
                for (i = 1; i < o.length; i++) t += o[i][0] + ",";
                t = t.substr(0, t.length - 1)
            } else t = e;
            return t
        },
        createFilterBox: function(e) {
            var t = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: SYNO.FileStation.SharingManager.Common.getTypeArray()
            });
            return new SYNO.ux.ComboBox({
                hideLabel: !0,
                mode: "local",
                store: t,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                value: "all",
                listeners: {
                    select: {
                        fn: e.onFilterType,
                        scope: e
                    }
                }
            })
        },
        createColModel: function(e) {
            var t = _S("is_admin"),
                i = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x";
            return new Ext.grid.ColumnModel([{
                header: _WFT("common", "user"),
                dataIndex: "link_owner",
                sortable: !0,
                width: 80,
                hidden: !t,
                renderer: function(e, t, i, o, n, s) {
                    var r;
                    return e ? r = e : (r = _WFT("sharing", "user_non_exist"), t.attr = 'ext:qtip="' + r + '"'), r
                }
            }, {
                header: _WFT("acl_editor", "type"),
                dataIndex: "project_name",
                sortable: !0,
                width: 80,
                renderer: function(e, t, i, o, n, s) {
                    var r = "";
                    "SYNO.SDS.App.FileStation3.Instance" === e ? r = _WFT("sharing", "sharing_links") : "SYNO.SDS.App.SharingUpload.Application" === e ? r = _WFT("sharing", "request_link") : "SYNO.SDS.PDFViewer.Application" === e && (r = _WFT("sharing", "document_link"));
                    var a = Ext.util.Format.htmlEncode(r);
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"', r
                }
            }, {
                header: _WFT("common", "file_name"),
                dataIndex: "name",
                width: 120,
                sortable: !0,
                renderer: function(e, t, o, n, s, r) {
                    var a = Ext.util.Format.htmlEncode(e);
                    t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
                    var l = e.substr(e.lastIndexOf(".") + 1).toLowerCase(),
                        h = "misc.png";
                    return o.get("isFolder") ? h = "folder.png" : -1 !== SYNO.webfm.utils.icon_type.indexOf(l) && (h = l + ".png"), String.format('<div class="webfm-file-type-icon" style="background-size: 16px 16px; background-image:url(/webman/modules/FileBrowser/images/' + i + "/files_ext/{0}?v=" + _S("version") + ')"/>&nbsp;{1}</div>', h, a)
                }
            }, {
                header: _WFT("common", "file_path"),
                dataIndex: "path",
                sortable: !0,
                width: 250,
                renderer: function(e, t, i, o, n, s) {
                    var r = Ext.util.Format.htmlEncode(e);
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(r) + '"', r
                }
            }, {
                header: _WFT("sharing", "exp_date"),
                dataIndex: "expire_at",
                sortable: !0,
                width: 120,
                renderer: function(e, t, i, o, n, s) {
                    if (!Ext.isEmpty(e)) {
                        var r = e.split(" ");
                        e = r[0] + "T" + r[1]
                    }
                    return Ext.isEmpty(e) ? "" : SYNO.webfm.utils.DateTimeFormatter(new Date(e), {
                        type: "datetimesec"
                    })
                }.createDelegate(e)
            }, {
                header: _WFT("common", "status"),
                dataIndex: "status",
                sortable: !0,
                width: 70,
                renderer: function(e, t, i, o, n, s) {
                    return "broken" == e ? _WFT("sharing", "broken") : "expired" == e ? _WFT("sharing", "expired") : "inactive" == e ? _WFT("sharing", "inactive") : _WFT("sharing", "status_ok")
                }
            }])
        },
        createStore: function(e, t) {
            return new Ext.data.Store({
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.FileStation.Sharing",
                    method: e,
                    version: 3
                }),
                reader: new Ext.data.JsonReader({
                    root: "links"
                }, [{
                    name: "id"
                }, {
                    name: "url"
                }, {
                    name: "link_owner"
                }, {
                    name: "path"
                }, {
                    name: "name"
                }, {
                    name: "expire_at",
                    mapping: "date_expired"
                }, {
                    name: "start_at",
                    mapping: "date_available"
                }, {
                    name: "expire_times"
                }, {
                    name: "protect_users"
                }, {
                    name: "protect_groups"
                }, {
                    name: "status"
                }, {
                    name: "protect_type"
                }, {
                    name: "qrcode"
                }, {
                    name: "isFolder"
                }, {
                    name: "enable_upload"
                }, {
                    name: "request_name"
                }, {
                    name: "request_info"
                }, {
                    name: "limit_size"
                }, {
                    name: "project_name"
                }]),
                baseParams: {
                    offset: 0,
                    limit: t.pageSize,
                    filter_type: SYNO.FileStation.SharingManager.Common.getFilterTypeStr(t.filterType)
                },
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                remoteSort: !0,
                listeners: {
                    beforeload: function() {
                        t.getEl() && t.getEl().mask(_WFT("common", "loading"), "x-mask-loading")
                    },
                    load: function() {
                        t.getEl() && t.getEl().unmask()
                    },
                    exception: function() {
                        t.getEl() && t.getEl().unmask()
                    },
                    scope: t
                }
            })
        }
    }
}), Ext.ns("SYNO.FileStation.Comp"), Ext.apply(SYNO.FileStation.Comp, {
    cViewMenu: function(e, t, i) {
        var o = _WFT("acl_editor", "view");
        return new e({
            itemId: "gc_view",
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-view-icon" : "",
            hidden: !0,
            menuExternable: !0,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0
            })
        })
    },
    cFavBtn: function(e, t, i) {
        var o = _WFT("favorite", "my_favorite");
        return new e({
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-favorite-icon" : "",
            listeners: {
                click: {
                    fn: i.onAddFav,
                    scope: i
                }
            }
        })
    },
    cDSMDeskShortcutBtn: function(e, t, i, o) {
        return new e({
            itemId: "gc_dsmshortcut",
            text: o,
            tooltip: o,
            disableClearLastDom: !0,
            iconCls: t ? "webfm-create_shortcut-icon" : "",
            disabled: _S("ha_safemode"),
            listeners: {
                click: {
                    fn: i.onAddShortCut,
                    scope: i
                }
            }
        })
    },
    cAddFavMenuBtn: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item;
        return new e({
            itemId: "gc_fav_menu",
            iconCls: t ? "webfm-favorite-icon" : "",
            tooltip: _WFT("shortcut", "make_to"),
            text: _WFT("shortcut", "make_to"),
            hideOnClick: !1,
            disabled: _S("ha_safemode"),
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cFavBtn(n, !0, i), o.cDSMDeskShortcutBtn(n, !0, i, _WFT("shortcut", "dsm_dekstop"))]
            })
        })
    },
    cUpFolder: function(e, t, i) {
        return new e({
            icon: t ? i.RELURL + "images/site/last_folder.gif" : "",
            listeners: {
                click: {
                    fn: function() {
                        this.onChangeDir(this.upDirPath)
                    },
                    scope: i
                }
            }
        })
    },
    cUploadLocal: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_upload"),
            tooltip: _WFT("filetable", "filetable_upload"),
            iconCls: t ? "webfm-upload-icon" : "",
            listeners: {
                click: {
                    fn: i.onBrowserUploadAction,
                    scope: i
                }
            }
        })
    },
    cUploadSkip: function(e, t, i) {
        return new e({
            itemId: "upload_skip",
            iconCls: t ? "webfm-upload-icon" : "",
            noStopEvent: Ext.isGecko,
            text: _WFT("filetable", "filetable_upload") + " - " + _WFT("filetable", "filetable_skip"),
            handler: i.onUploadItemClick,
            scope: i
        })
    },
    cUploadOvwr: function(e, t, i) {
        return new e({
            itemId: "upload_overwrite",
            iconCls: t ? "webfm-upload-icon" : "",
            noStopEvent: Ext.isGecko,
            text: _WFT("filetable", "filetable_upload") + " - " + _WFT("filetable", "filetable_overwrite"),
            handler: i.onUploadItemClick,
            scope: i
        })
    },
    cReloadDS: function(e, t, i) {
        return new e({
            text: _WFT("common", "common_refresh"),
            tooltip: _WFT("common", "common_refresh"),
            icon: t ? i.RELURL + "images/button/toolbar_refresh.png" : "",
            listeners: {
                click: {
                    fn: function() {
                        this.activeDS.reload()
                    },
                    scope: i
                }
            }
        })
    },
    cReloadTree: function(e, t, i) {
        return new e({
            text: _WFT("common", "common_refresh"),
            tooltip: _WFT("common", "common_refresh"),
            icon: t ? i.RELURL + "images/button/toolbar_refresh.png" : "",
            listeners: {
                click: {
                    fn: function() {
                        this.reloadTree()
                    },
                    scope: i
                }
            }
        })
    },
    cNewFolder: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_create_folder"),
            tooltip: _WFT("filetable", "filetable_create_folder"),
            iconCls: t ? "webfm-create_new_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onCreateFolder,
                    scope: i
                }
            }
        })
    },
    cNewShareFolder: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_create_sharefolder"),
            tooltip: _WFT("filetable", "filetable_create_sharefolder"),
            iconCls: t ? "webfm-create_new_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onCreateShareFolder,
                    scope: i
                }
            }
        })
    },
    cToolsMenu: function(e) {
        return new SYNO.ux.Button({
            text: _WFT("filetable", "tools"),
            menu: e,
            hidden: !(_S("is_admin") && "yes" === _D("supportmount"))
        })
    },
    cMountList: function(e, t, i) {
        return new e({
            hidden: !0,
            text: _WFT("mount", "mount_list"),
            tooltip: _WFT("mount", "mount_list"),
            iconCls: t ? "webfm-connection_list-icon" : "",
            listeners: {
                click: {
                    fn: i.onMountList,
                    scope: i
                }
            }
        })
    },
    cSettings: function(e, t, i) {
        return new e({
            text: _WFT("mount", "setting"),
            tooltip: _WFT("mount", "setting"),
            icon: t ? i.RELURL + "images/button/mount_config.png" : "",
            disabled: _S("ha_safemode"),
            listeners: {
                click: {
                    fn: i.onSettings,
                    scope: i
                }
            }
        })
    },
    cDownloadMenu: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item,
            s = _WFT("filetable", "filetable_download");
        return new e({
            itemId: "gc_download_menu",
            text: s,
            tooltip: s,
            iconCls: t ? "webfm-download-icon" : "",
            hideOnClick: !1,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cDownload(n, !0, i, _WFT("filetable", "filetable_download_directly")), o.cDownloadOverwrite(n, !0, i), o.cDownloadSkip(n, !0, i)]
            })
        })
    },
    cMultiDownloadMenu: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item,
            s = _WFT("filetable", "filetable_download");
        return new e({
            itemId: "gc_multidownload_menu",
            text: s,
            tooltip: s,
            iconCls: t ? "webfm-download-icon" : "",
            hideOnClick: !1,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cMultiDownload(n, !0, i), o.cDownload(n, !0, i, _WFT("filetable", "filetable_download_zip"))]
            })
        })
    },
    cDownload: function(e, t, i, o) {
        return o = o || _WFT("filetable", "filetable_download"), new e({
            itemId: "gc_download",
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-download-icon" : "",
            listeners: {
                click: {
                    fn: i.onDownloadAction,
                    scope: i
                }
            }
        })
    },
    cDownloadSkip: function(e, t, i, o) {
        var n = _WFT("filetable", "filetable_download_queue") + " - " + _WFT("filetable", "filetable_skip");
        return new e({
            text: n,
            tooltip: n,
            iconCls: t ? "webfm-download-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onJavaDownloadAction(e, !1)
                    },
                    scope: i
                }
            }
        })
    },
    cDownloadOverwrite: function(e, t, i, o) {
        var n = _WFT("filetable", "filetable_download_queue") + " - " + _WFT("filetable", "filetable_overwrite");
        return new e({
            text: n,
            tooltip: n,
            iconCls: t ? "webfm-download-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onJavaDownloadAction(e, !0)
                    },
                    scope: i
                }
            }
        })
    },
    cMultiDownload: function(e, t, i, o) {
        var n = _WFT("filetable", "filetable_standard_download");
        return new e({
            text: n,
            tooltip: n,
            iconCls: t ? "webfm-download-icon" : "",
            listeners: {
                click: {
                    fn: i.onMultiDownload,
                    scope: i
                }
            }
        })
    },
    cOpenWin: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_openwin"),
            tooltip: _WFT("filetable", "filetable_openwin"),
            iconCls: t ? "webfm-open_in_new_window-icon" : "",
            listeners: {
                click: {
                    fn: i.onOpenWinAction,
                    scope: i
                }
            }
        })
    },
    cExtractMenuBtn: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item,
            s = _WFT("filetable", "filetable_extract"),
            r = new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cExtract(n, !0, i), o.cExtractHere(n, !0, i), o.cExtractFolderName(n, !0, i)]
            });
        return r.render(), new e({
            hideOnClick: !1,
            itemId: "gc_extract_menu",
            iconCls: t ? "webfm-extract-icon" : "",
            tooltip: s,
            text: s,
            menu: r
        })
    },
    cExtract: function(e, t, i) {
        return new e({
            itemId: "gc_extract",
            text: _WFT("filetable", "filetable_extract") + "...",
            tooltip: _WFT("filetable", "filetable_extract") + "...",
            iconCls: t ? "webfm-extract-icon" : "",
            listeners: {
                click: {
                    fn: i.onExtractClick,
                    scope: i
                }
            }
        })
    },
    cExtractHere: function(e, t, i) {
        return new e({
            itemId: "gc_extract_here",
            text: _WFT("filetable", "filetable_extract_here"),
            tooltip: _WFT("filetable", "filetable_extract_here"),
            iconCls: t ? "webfm-extract-icon" : "",
            listeners: {
                click: {
                    fn: i.onExtractHereClick,
                    scope: i
                }
            }
        })
    },
    cExtractFolderName: function(e, t, i) {
        return new e({
            itemId: "gc_extract_folder",
            text: _WFT("filetable", "filetable_extract_to"),
            tooltip: _WFT("filetable", "filetable_extract_to"),
            iconCls: t ? "webfm-extract-icon" : "",
            listeners: {
                click: {
                    fn: function() {
                        this.onExtractFolderNameClick()
                    },
                    scope: i
                }
            }
        })
    },
    cCompressAdv: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_add_archive"),
            tooltip: _WFT("filetable", "filetable_add_archive"),
            iconCls: t ? "webfm-compress-icon" : "",
            listeners: {
                click: {
                    fn: i.onCompressAdvItemsClick,
                    scope: i
                }
            }
        })
    },
    cCompress: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_compress_to"),
            tooltip: _WFT("filetable", "filetable_compress_to"),
            iconCls: t ? "webfm-compress-icon" : "",
            listeners: {
                click: {
                    fn: i.onCompressItemsClick,
                    scope: i
                }
            }
        })
    },
    cMountRemote: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item;
        return new e({
            hidden: !0,
            text: _WFT("filetable", "filetable_mount_remote_volume"),
            tooltip: _WFT("filetable", "filetable_mount_remote_volume"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            hideOnClick: !1,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cMountRemoteCIFS(n, !0, i), o.cMountRemoteNFS(n, !0, i)]
            })
        })
    },
    cMountRemoteCIFS: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_mount_cifs"),
            tooltip: _WFT("filetable", "filetable_mount_cifs"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onMountRemoteCIFSClick,
                    scope: i
                }
            }
        })
    },
    cMountRemoteNFS: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_mount_nfs"),
            tooltip: _WFT("filetable", "filetable_mount_nfs"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onMountRemoteNFSClick,
                    scope: i
                }
            }
        })
    },
    cRemoteConnect: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item;
        return new e({
            hidden: !0,
            text: _WFT("vfs", "remote_connect"),
            tooltip: _WFT("vfs", "remote_connect"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            hideOnClick: !1,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cRemoteConnectSetup(n, !0, i), o.cRemoteConnectServerList(n, !0, i)]
            })
        })
    },
    cRemoteConnectSetup: function(e, t, i) {
        return new e({
            text: _WFT("vfs", "setup_server"),
            tooltip: _WFT("vfs", "setup_server"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onRemoteConnectClick,
                    scope: i
                }
            }
        })
    },
    cRemoteConnectServerList: function(e, t, i) {
        return new e({
            text: _WFT("vfs", "server_list"),
            tooltip: _WFT("vfs", "server_list"),
            iconCls: t ? "webfm-mount_remote_folder-icon" : "",
            listeners: {
                click: {
                    fn: i.onRemoteConnectServerListClick,
                    scope: i
                }
            }
        })
    },
    cMountISO: function(e, t, i) {
        return new e({
            hidden: !0,
            text: _WFT("filetable", "filetable_mount_iso"),
            tooltip: _WFT("filetable", "filetable_mount_iso"),
            iconCls: t ? "webfm-mount_virtual_drive-icon" : "",
            listeners: {
                click: {
                    fn: i.onMountISOClick,
                    scope: i
                }
            }
        })
    },
    cUmount: function(e, t, i) {
        return new e({
            hidden: !0,
            text: _WFT("mount", "umount"),
            tooltip: _WFT("mount", "umount"),
            iconCls: t ? "webfm-unmount_eject-icon" : "",
            listeners: {
                click: {
                    fn: i.onUmountClick,
                    scope: i
                }
            }
        })
    },
    cSnapshotHistory: function(e, t) {
        return new e({
            text: _T("disk_info", "disk_view_history"),
            tooltip: _T("disk_info", "disk_view_history"),
            iconCls: "webfm-browse_previous_versions-icon",
            itemId: "gc_snapshot_history",
            listeners: {
                click: {
                    fn: t.onViewHistoryAction,
                    scope: t
                }
            }
        })
    },
    cCut: function(e, t, i) {
        var o = _WFT("filetable", "filetable_cut");
        return new e({
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-cut-icon" : "",
            disableClearLastDom: !0,
            listeners: {
                click: {
                    fn: i.onCutAction,
                    scope: i
                }
            }
        })
    },
    cCopy: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_copy"),
            tooltip: _WFT("filetable", "filetable_copy"),
            disableClearLastDom: !0,
            iconCls: t ? "webfm-copy-icon" : "",
            listeners: {
                click: {
                    fn: i.onCopyAction,
                    scope: i
                }
            }
        })
    },
    cMVCPToMenu: function(e, t, i) {
        var o = SYNO.FileStation.Comp,
            n = Ext.menu.Item,
            s = _WFT("filetable", "filetable_copy_to") + "/" + _WFT("filetable", "filetable_move_to") + " ...";
        return new e({
            itemId: "mvcpto",
            text: s,
            tooltip: s,
            iconCls: t ? "webfm-copy_to_move_to-icon" : "",
            hideOnClick: !1,
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                ignoreParentClicks: !0,
                items: [o.cCopyTo(n, !0, i, !0), o.cCopyTo(n, !0, i, !1), o.cMoveTo(n, !0, i, !0), o.cMoveTo(n, !0, i, !1)]
            }),
            setMoveDisabled: function(e) {
                var t = this.menu.items;
                t.get("moveto_ovwr").setDisabled(e), t.get("moveto_skip").setDisabled(e)
            },
            setOvwrVisible: function(e) {
                var t = this.menu.items;
                t.get("moveto_ovwr").setVisible(e), t.get("copyto_ovwr").setVisible(e);
                var i = _WFT("filetable", "filetable_move_to") + " ...",
                    o = _WFT("filetable", "filetable_copy_to") + " ...";
                e && (i += " - " + _WFT("filetable", "filetable_skip"), o += " - " + _WFT("filetable", "filetable_skip")), t.get("moveto_skip").setText(i), t.get("copyto_skip").setText(o)
            }
        })
    },
    cCopyTo: function(e, t, i, o) {
        var n = _WFT("filetable", "filetable_copy_to") + " ... - " + (o ? _WFT("filetable", "filetable_overwrite") : _WFT("filetable", "filetable_skip"));
        return new e({
            itemId: o ? "copyto_ovwr" : "copyto_skip",
            text: n,
            tooltip: n,
            iconCls: t ? "webfm-copy_to_move_to-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onCopyAction(e, o)
                    },
                    scope: i
                }
            }
        })
    },
    cMoveTo: function(e, t, i, o) {
        var n = _WFT("filetable", "filetable_move_to") + " ... - " + (o ? _WFT("filetable", "filetable_overwrite") : _WFT("filetable", "filetable_skip"));
        return new e({
            itemId: o ? "moveto_ovwr" : "moveto_skip",
            text: n,
            tooltip: n,
            iconCls: t ? "webfm-copy_to_move_to-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onCutAction(e, o)
                    },
                    scope: i
                }
            }
        })
    },
    cPasteSkip: function(e, t, i) {
        var o = _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_skip");
        return new e({
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-paste-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onPasteAction(e, !1)
                    },
                    scope: i
                }
            }
        })
    },
    cPasteOvwr: function(e, t, i) {
        var o = _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_overwrite");
        return new e({
            text: o,
            tooltip: o,
            iconCls: t ? "webfm-paste-icon" : "",
            listeners: {
                click: {
                    fn: function(e) {
                        this.onPasteAction(e, !0)
                    },
                    scope: i
                }
            }
        })
    },
    cDelete: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_delete"),
            tooltip: _WFT("filetable", "filetable_delete"),
            iconCls: t ? "webfm-delete-icon" : "",
            listeners: {
                click: {
                    fn: i.onDeleteAction,
                    scope: i
                }
            }
        })
    },
    cRename: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_rename"),
            tooltip: _WFT("filetable", "filetable_rename"),
            iconCls: t ? "webfm-rename-icon" : "",
            listeners: {
                click: {
                    fn: i.onRenameAction,
                    scope: i
                }
            }
        })
    },
    cProperty: function(e, t, i) {
        return new e({
            text: _WFT("filetable", "filetable_properties"),
            tooltip: _WFT("filetable", "filetable_properties"),
            iconCls: t ? "webfm-properties-icon" : "",
            listeners: {
                click: {
                    fn: i.onPropertyClick,
                    buffer: 100,
                    scope: i
                }
            }
        })
    },
    cSharing: function(e, t, i) {
        return new e({
            text: _WFT("common", "share"),
            tooltip: _WFT("common", "share"),
            iconCls: t ? "webfm-share_file_links-icon" : "",
            listeners: {
                click: {
                    fn: i.onShareClick,
                    buffer: 100,
                    scope: i
                }
            }
        })
    },
    cSharingManager: function(e, t, i) {
        return new e({
            text: _WFT("sharing", "sharing_manager"),
            tooltip: _WFT("sharing", "sharing_manager"),
            iconCls: t ? "webfm-share_file_links-icon" : "",
            listeners: {
                click: {
                    fn: i.onSharingManager,
                    buffer: 100,
                    scope: i
                }
            }
        })
    },
    cFileRequest: function(e, t, i) {
        return new e({
            text: _WFT("sharing", "file_request"),
            tooltip: _WFT("sharing", "file_request"),
            iconCls: t ? "webfm-filerequest_upload-icon" : "",
            listeners: {
                click: {
                    fn: i.onFileRequestClick,
                    buffer: 100,
                    scope: i
                }
            }
        })
    },
    cCmbDisplayType: function(e) {
        var t = new Ext.data.SimpleStore({
            autoDestroy: !0,
            fields: ["value", "display"],
            data: [
                ["all", _WFT("filetable", "filetable_all_files")],
                ["file", _WFT("filetable", "filetable_file_only")],
                ["dir", _WFT("filetable", "filetable_dir_only")]
            ]
        });
        return new Ext.form.ComboBox({
            name: "display_type",
            hiddenName: "display_type",
            hiddenId: Ext.id(),
            store: t,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: "all",
            editable: !1,
            width: 120,
            mode: "local",
            listeners: {
                select: {
                    fn: function(e, t, i) {
                        this.onChangeDisplayType(e.getValue())
                    },
                    scope: e
                }
            }
        })
    },
    cBtnDisplayType: function(e) {
        return new SYNO.ux.Button({
            hidden: !0,
            text: _WFT("filetable", "filetable_file_dispaly"),
            menu: new SYNO.ux.Menu({
                cls: "syno-webfm",
                items: [{
                    itemId: "all",
                    text: _WFT("filetable", "filetable_all_files"),
                    iconCls: "syno-sds-fs-tbar-sel-display",
                    listeners: {
                        click: {
                            fn: function() {
                                this.onChangeDisplayType("all")
                            },
                            scope: e
                        }
                    }
                }, {
                    itemId: "file",
                    text: _WFT("filetable", "filetable_file_only"),
                    listeners: {
                        click: {
                            fn: function() {
                                this.onChangeDisplayType("file")
                            },
                            scope: e
                        }
                    }
                }, {
                    itemId: "dir",
                    text: _WFT("filetable", "filetable_dir_only"),
                    listeners: {
                        click: {
                            fn: function() {
                                this.onChangeDisplayType("dir")
                            },
                            scope: e
                        }
                    }
                }]
            })
        })
    },
    cActionMenu: function(e) {
        return new SYNO.ux.Button({
            text: _WFT("common", "start"),
            menu: e
        })
    },
    cFileFilter: function(e) {
        return new SYNO.FileStation.Comp.AdvancedSearchField({
            emptyText: _WFT("filetable", "filetable_search"),
            store: e.activeDS,
            queryAction: "list",
            queryDelay: 500,
            enumAction: "list",
            width: 188,
            pageSize: e.displayNum,
            owner: e
        })
    },
    cRemoteFileFilter: function(e) {
        return new SYNO.FileStation.Comp.FileFilterField({
            emptyText: _WFT("common", "filter_label_text"),
            store: e.activeDS,
            queryAction: "list",
            enumAction: "list",
            queryParam: "pattern",
            width: 188,
            hidden: !0,
            pageSize: e.displayNum,
            owner: e
        })
    },
    cUploadRemote: function(e, t, i) {
        return new e({
            iconCls: t ? "webfm-upload-icon" : "",
            text: _WFT("filetable", "filetable_upload"),
            menu: {
                owner: this,
                cls: "syno-webfm syno-ux-menu",
                defaultOffsets: [0, 1],
                items: [SYNO.FileStation.Comp.cUploadSkip(Ext.menu.Item, !0, i), SYNO.FileStation.Comp.cUploadOvwr(Ext.menu.Item, !0, i)],
                listeners: {
                    afterrender: {
                        fn: this.UploadMenuRegistEvent,
                        scope: i
                    }
                }
            }
        })
    },
    UploadMenuRegistEvent: function(e) {
        var t = e.get("upload_overwrite");
        e.mon(e, "beforeshow", function() {
            if (!0 === _S("demo_mode")) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo")), SYNO.FileStation.FlashUploader.setLowZindex(), !1;
            this.onCheckVFSAction("upload", null, this.getCurrentDir()) || SYNO.FileStation.FlashUploader.setLowZindex(), this.onCheckPrivilege("upload", null, !1, !1) || SYNO.FileStation.FlashUploader.setLowZindex(), this.checkFtpModifyRight(this.dirTree.getSelectionModel().getSelectedNode()) ? t.disable() : t.enable()
        }, this), e.mon(e, "show", function(t) {
            if (1 != AppletProgram.blJavaPermission && !SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() && this.onCheckPrivilege("upload", null, !1, !1) && this.onCheckVFSAction("upload", null, this.getUploadPath(t))) {
                var i = this.checkFtpModifyRight(this.dirTree.getSelectionModel().getSelectedNode()),
                    o = i ? e.getHeight() / 2 : e.getHeight();
                if (null === SYNO.FileStation.FlashUploader.swiffy) {
                    var n = this.getUploadInstance(),
                        s = !!n;
                    SYNO.FileStation.FlashUploader.init(this.RELURL, e, n, o, s, this)
                } else SYNO.FileStation.FlashUploader.reinit(t), SYNO.FileStation.FlashUploader.setHighZindex(), SYNO.FileStation.FlashUploader.swiffyReposition(o);
                SYNO.FileStation.FlashUploader.setParameters(this.getUploadPath(t), this.session)
            }
        }, this), e.mon(e, "hide", function() {
            if (1 == AppletProgram.blJavaPermission || SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload()) return void(null !== SYNO.FileStation.FlashUploader.swiffy && (SYNO.FileStation.FlashUploader.setLowZindex(), SYNO.FileStation.FlashUploader.swiffy = null));
            null !== SYNO.FileStation.FlashUploader.swiffy && SYNO.FileStation.FlashUploader.setLowZindex()
        }, this)
    },
    cHistoryBtn: function(e, t, i) {
        return new e({
            itemId: "next" === i ? "next" : "back",
            tooltip: "next" === i ? _WFT("common", "history_next") : _WFT("common", "history_back"),
            iconCls: "next" === i ? "syno-sds-fs-tbar-next" : "syno-sds-fs-tbar-back",
            cls: "next" === i ? "syno-sds-fs-tbar-next-wrap" : "syno-sds-fs-tbar-back-wrap",
            disabled: !0,
            tabIndex: -1,
            historyDirection: "next" === i ? 1 : -1,
            historyMenu: "next" === i ? t.historyNextMenu : t.historyBackMenu,
            listeners: {
                afterrender: {
                    fn: function(e) {
                        var t = !1,
                            i = null;
                        e.mon(e.el, "contextmenu", function(t, i) {
                            e.disabled || e.historyMenu.showMenuWithButton(e.el)
                        }, this), e.mon(e.el, "mousedown", function(o, n) {
                            if (!e.disabled && 0 === o.button) {
                                var s = Ext.QuickTips.getQuickTip();
                                s.showTimer && clearTimeout(s.showTimer), s.hide(), 0 === o.button && (t = !1, i = setTimeout(function() {
                                    t = !0, e.historyMenu.showMenuWithButton(e.el)
                                }, 600))
                            }
                        }, this), e.mon(e.el, "mouseup", function(o) {
                            if (!e.disabled && 0 === o.button) {
                                var n = this.historyIndex + e.historyDirection;
                                t || (i && (clearTimeout(i), i = null), this.changeDirWithHistoryIndex(n))
                            }
                        }, this)
                    },
                    scope: t
                }
            }
        })
    },
    cSort: function(e, t, i) {
        var o = t.activeDS,
            n = i && i.type_group ? i.type_group : "webfm_sort_type",
            s = i && i.dir_group ? i.dir_group : "webfm_sort_dir",
            r = function(e) {
                var t = e.sortInfo.field,
                    i = e.sortInfo.direction,
                    o = this.menu.getComponent(t) || this.menu.getComponent("filename"),
                    n = this.menu.getComponent(i);
                o && o.setChecked(!0), n && n.setChecked(!0), this.sortType = t, this.sortDir = i
            },
            a = function(e, i) {
                var o = t.activeDS;
                0 !== o.data.length && (t.getCurrentSource() === SYNO.webfm.utils.source.remotes && t.remoteSearchDS.blSearhDone && (t.remoteSearchDS.blSearchSorted = !0), e.group === n ? l.sortType = e.itemId : l.sortDir = e.itemId, o.sort(l.sortType, l.sortDir))
            },
            l = new e({
                text: _T("filebrowser", "sort"),
                tooltip: _T("filebrowser", "sort"),
                itemId: i && i.itemId ? i.itemId : "",
                iconCls: i && i.iconCls ? i.iconCls : "",
                bindEvent: function(e) {
                    this.mun(e, "datachanged", r, this), this.mon(e, "datachanged", r, this)
                },
                menu: {
                    ignoreParentClicks: !0,
                    defaults: {
                        checked: !1
                    },
                    defaultOffsets: [0, 1],
                    cls: "syno-webfm-sort-menu syno-ux-searchfield-menu",
                    items: [{
                        group: n,
                        text: _WFT("common", "common_filename"),
                        itemId: "filename"
                    }, {
                        group: n,
                        text: _WFT("common", "common_filesize"),
                        itemId: "filesize"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_title_file_type"),
                        itemId: "type"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_mtime"),
                        itemId: "mt"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_ctime"),
                        itemId: "ct"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_atime"),
                        itemId: "at"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_privilege"),
                        itemId: "privilege"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_owner"),
                        itemId: "owner"
                    }, {
                        group: n,
                        text: _WFT("filetable", "filetable_group"),
                        itemId: "group"
                    }, "-", {
                        group: s,
                        itemId: "ASC",
                        text: _WFT("common", "order_asc")
                    }, {
                        group: s,
                        itemId: "DESC",
                        text: _WFT("common", "order_desc")
                    }],
                    listeners: {
                        scope: this,
                        itemclick: a
                    }
                }
            });
        return l.bindEvent(o), l
    },
    cViewMode: function(e, t, i) {
        var o = "webfm-viewmode-btn-thumb-small",
            n = "webfm-viewmode-btn-thumb-medium",
            s = "webfm-viewmode-btn-thumb-large",
            r = "webfm-viewmode-btn-list",
            a = "webfm-viewmode-btn-column",
            l = "syno-sds-webfm-tbar-viewmode-btn ";
        return new e({
            width: 47,
            cls: "syno-sds-webfm-tbar-viewmode-btn-no-margin",
            iconCls: "syno-sds-webfm-tbar-viewmode-btn " + r,
            webfm: t,
            tabIndex: -1,
            handler: function() {
                var e = this.iconCls;
                Ext.isIE9m || e != l + r ? Ext.isIE9m && e == l + r || !Ext.isIE9m && e == l + a ? (this.setIconClass(l + o), t.changeView("thumbnailView"), t.changeThumbSize(SYNO.webfm.utils.ThumbSize.SMALL)) : e == l + o ? (this.setIconClass(l + n), t.changeThumbSize(SYNO.webfm.utils.ThumbSize.MEDIUM)) : e == l + n ? (this.setIconClass(l + s), t.changeThumbSize(SYNO.webfm.utils.ThumbSize.LARGE)) : e == l + s && (this.setIconClass(l + r), t.changeView("fileGrid")) : (this.setIconClass(l + a), t.changeView("columnView"))
            },
            menu: {
                cls: "syno-sds-webfm-tbar-viewmode-menu",
                defaultOffsets: [0, 1],
                items: [{
                    text: _WFT("common", "list_view"),
                    iconCls: r,
                    itemId: "fileGrid",
                    handler: function() {
                        this.changeView("fileGrid"), this.btnViewMode.setIconClass(l + r)
                    },
                    scope: t
                }].concat(Ext.isIE9m ? [] : [{
                    text: _WFT("common", "column_view"),
                    iconCls: a,
                    itemId: "columnView",
                    handler: function() {
                        this.changeView("columnView"), this.btnViewMode.setIconClass(l + a)
                    },
                    scope: t
                }]).concat([{
                    text: _WFT("common", "thumb_small"),
                    iconCls: o,
                    itemId: "thumbnailView" + SYNO.webfm.utils.ThumbSize.SMALL,
                    handler: function() {
                        this.changeView("thumbnailView"), this.changeThumbSize(SYNO.webfm.utils.ThumbSize.SMALL), this.btnViewMode.setIconClass(l + o)
                    },
                    scope: t
                }, {
                    text: _WFT("common", "thumb_medium"),
                    iconCls: n,
                    itemId: "thumbnailView" + SYNO.webfm.utils.ThumbSize.MEDIUM,
                    handler: function() {
                        this.changeView("thumbnailView"), this.changeThumbSize(SYNO.webfm.utils.ThumbSize.MEDIUM), this.btnViewMode.setIconClass(l + n)
                    },
                    scope: t
                }, {
                    text: _WFT("common", "thumb_large"),
                    iconCls: s,
                    itemId: "thumbnailView" + SYNO.webfm.utils.ThumbSize.LARGE,
                    handler: function() {
                        this.changeView("thumbnailView"), this.changeThumbSize(SYNO.webfm.utils.ThumbSize.LARGE), this.btnViewMode.setIconClass(l + s)
                    },
                    scope: t
                }])
            },
            resetViewMode: function() {
                this.setIconClass(l + r), t.changeView("fileGrid")
            }
        })
    }
}), Ext.define("SYNO.FileStation.Comp.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    constructor: function(e) {
        this.callParent([e]), this.on("afterrender", function() {
            this.el.addKeyListener(Ext.EventObject.ENTER, this.onFocusResult, this), this.mon(this.inputWrap, "mousedown", this.onShowHistory, this), this.mon(this.inputWrap, "keyup", this.onShowHistory, this), this.mon(this, "blur", this.onBlurHandler, this), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this)
        }, this)
    },
    onShowHistory: function(e, t) {
        !0 !== this.disabled && (this.historyPanel || (this.historyPanel = this.owner.historyPanel, this.mon(this.historyPanel, "historyselect", this.onHistorySelect, this)), this.historyPanel.isVisible() || ("mousedown" === e.type && this.resetOldKeyword(), e && e.keyCode == e.ENTER || this.historyPanel.openPanel(this.container, this, [-1, 1])))
    },
    onHistorySelect: function(e) {
        this.setValue(e), this.oldKeyword = e, this.owner.searchPanel.onHistorySearch(e)
    },
    onFocusResult: function() {
        this.owner.grid.getAriaEl().focus()
    },
    onBlurHandler: function() {
        this.historyPanel.isVisible() && Ext.defer(function() {
            this.historyPanel.closePanel()
        }, 300, this)
    },
    onMouseDown: function(e) {
        var t = this,
            i = t.searchPanel;
        !i || i.isDestroyed || !i.isVisible() || i.inEl || e.within(i.getEl()) || i.selTree && i.selTree.isVisible() || e.within(this.searchtrigger) || e.within(t.searchPanel.advHistoryPanel.getEl()) || i.hide()
    },
    onTriggerClick: function() {
        if (this.getValue()) {
            if (this.resetOldKeyword(), !this.owner.searchPanel.getSearchStore().blSearhDone) return this.owner.searchPanel.onStop(), void this.setValue("");
            this.owner.changeDirWithHistoryIndex(this.owner.historyIndex - 1)
        }
        this.callParent(arguments)
    },
    filter: function() {
        var e = this.getValue().trim();
        if (Ext.isEmpty(e) && !Ext.isEmpty(this.oldKeyword)) return this.resetOldKeyword(), void this.owner.changeDirWithHistoryIndex(this.owner.historyIndex - 1);
        e !== this.oldKeyword && (this.oldKeyword = e, this.owner.searchPanel.onHistorySearch(e))
    },
    resetOldKeyword: function() {
        this.oldKeyword = ""
    },
    onSearchTriggerClick: function() {
        var e = this;
        if (!0 !== e.disabled) {
            if (e.searchPanel || (e.searchPanel = e.owner.searchPanel), e.searchPanel.isVisible()) return void e.searchPanel.hide();
            e.searchPanel.getEl().alignTo(this.container, "tr-br?", [0, 1]);
            var t = e.searchPanel.webfm.owner.getEl().getStyle("z-index");
            t = parseInt(t, 10), e.searchPanel.getEl().setStyle("z-index", t + 1), e.searchPanel.show(), e.searchPanel.setKeyWord(e.getValue())
        }
    }
}), SYNO.FileStation.Comp.FileFilterField = Ext.extend(SYNO.ux.SearchField, {
    onMouseDown: function(e) {
        var t = this,
            i = t.searchPanel;
        !i || i.isDestroyed || !i.isVisible() || i.inEl || e.within(i.getEl()) || i.selTree && i.selTree.isVisible() || e.within(this.searchtrigger) || e.within(t.searchPanel.advHistoryPanel.getEl()) || i.hide()
    },
    onSearchTriggerClick: function() {
        var e = this;
        if (!0 !== e.disabled) {
            if (e.searchPanel || (e.searchPanel = e.owner.searchPanel, e.mon(Ext.getDoc(), "mousedown", e.onMouseDown, e)), e.searchPanel.isVisible()) return void e.searchPanel.hide();
            e.searchPanel.getEl().alignTo(this.container, "tr-br?", [0, 1]), e.searchPanel.show(), e.searchPanel.setKeyWord(e.getValue())
        }
    }
}), Ext.define("SYNO.FileStation.Comp.TextItem", {
    extend: "Ext.Toolbar.TextItem",
    onRender: function(e, t) {
        this.autoEl = {
            cls: "xtb-text",
            html: this.text || "",
            "ext:qtip": this.text || ""
        }, SYNO.FileStation.Comp.TextItem.superclass.onRender.call(this, e, t)
    },
    afterRender: function() {
        this.callParent(arguments), this.el.setARIA({
            role: "log",
            live: "assertive"
        })
    },
    setText: function(e) {
        SYNO.FileStation.Comp.TextItem.superclass.setText.call(this, e), this.rendered && this.el.set({
            "ext:qtip": e,
            tabindex: "" === e ? -1 : 0
        })
    }
}), Ext.reg("fstbtext", SYNO.FileStation.Comp.TextItem), Ext.ns("SYNO.FileStation.Comp"), SYNO.FileStation.Comp.WinToolbar = function(e) {
    var t = SYNO.FileStation.Comp,
        i = function() {
            var e = SYNO.FileStation.Comp,
                t = new SYNO.ux.Menu({
                    itemId: "rToolbarCtx",
                    cls: "syno-webfm",
                    defaultOffsets: [0, 1],
                    items: [{
                        itemId: "gc_extern_last",
                        hidden: !0
                    }],
                    listeners: {
                        beforeshow: {
                            fn: this.onUpdateBtnStatus,
                            scope: this
                        },
                        show: {
                            fn: function() {
                                SYNO.webfm.utils.ShowHideMenu(this.items), this.doLayout()
                            },
                            scope: t
                        }
                    }
                });
            return this.toolbarMenu = t, t.add(e.cViewMenu(Ext.menu.Item, !0, this)), this.btnDownloadMenu = e.cDownloadMenu(Ext.menu.Item, !0, this), t.add(this.btnDownloadMenu), this.btnDownloadMenu.hide(), this.btnMultiDownloadMenu = e.cMultiDownloadMenu(Ext.menu.Item, !0, this), t.add(this.btnMultiDownloadMenu), this.btnDownloadMenu.hide(), this.btnDownload = e.cDownload(Ext.menu.Item, !0, this), t.add(this.btnDownload), t.addSeparator(), this.btnOpenWin = e.cOpenWin(Ext.menu.Item, !0, this), t.addItem(this.btnOpenWin), t.add(new Ext.menu.Separator({
                xtype: "tbseparator",
                itemId: "sep_extract"
            })), t.add(this.btnExtractMenu = e.cExtractMenuBtn(Ext.menu.Item, !0, this)), this.btnCompressAdv = e.cCompressAdv(Ext.menu.Item, !0, this), t.add(this.btnCompressAdv), this.btnCompress = e.cCompress(Ext.menu.Item, !0, this), t.add(this.btnCompress), t.add(new Ext.menu.Separator({
                xtype: "tbseparator",
                itemId: "sep_archive"
            })), t.add(this.btnMVCPToMenu = e.cMVCPToMenu(Ext.menu.Item, !0, this)), this.btnCut = e.cCut(Ext.menu.Item, !0, this), t.add(this.btnCut), this.btnCopy = e.cCopy(Ext.menu.Item, !0, this), t.add(this.btnCopy), this.btnPasteOvwr = e.cPasteOvwr(Ext.menu.Item, !0, this), t.add(this.btnPasteOvwr), this.btnPasteSkip = e.cPasteSkip(Ext.menu.Item, !0, this), t.add(this.btnPasteSkip), this.btnDelete = e.cDelete(Ext.menu.Item, !0, this), t.add(this.btnDelete), this.btnRename = e.cRename(Ext.menu.Item, !0, this), t.add(this.btnRename), t.addSeparator(), t.add(this.btnFavSubMenu = e.cAddFavMenuBtn(Ext.menu.Item, !0, this)), t.add(this.btnDSMShortcut = e.cDSMDeskShortcutBtn(Ext.menu.Item, !0, this, _WFT("shortcut", "make_to_dsm_dekstop"))), t.addItem(this.sepFav = new Ext.menu.Separator), t.add(this.btnProperty = e.cProperty(Ext.menu.Item, !0, this)), t.add(this.btnShare = e.cSharing(Ext.menu.Item, !0, this)), t.add(this.btnFileRequest = e.cFileRequest(Ext.menu.Item, !0, this)), t
        },
        o = function() {
            var e = SYNO.FileStation.Comp,
                t = new SYNO.ux.Menu({
                    cls: "syno-webfm",
                    defaultOffsets: [0, 1],
                    listeners: {
                        beforeshow: {
                            fn: function() {
                                this.onUpdateBtnStatus(), t.showMountItem()
                            },
                            scope: this
                        }
                    }
                });
            this.btnRemoteConnect = e.cRemoteConnect(Ext.menu.Item, !0, this), t.add(this.btnRemoteConnect);
            var i = function(e) {
                this.btnRemoteConnect.setVisible(e)
            };
            if (t.showRemoteConnectItem = i.createDelegate(this, [!0]), t.hideRemoteConnectItem = i.createDelegate(this, [!1]), t.showMountItem = Ext.emptyFn, t.hideMountItem = Ext.emptyFn, "yes" === _D("supportmount")) {
                this.btnMountRemote = e.cMountRemote(Ext.menu.Item, !0, this), t.add(this.btnMountRemote), this.btnMountISO = e.cMountISO(Ext.menu.Item, !0, this), t.add(this.btnMountISO), this.btnUmount = e.cUmount(Ext.menu.Item, !0, this), t.add(this.btnUmount), this.btnMountList = e.cMountList(Ext.menu.Item, !0, this), t.add(this.btnMountList), t.add(new Ext.menu.Separator({
                    itemId: "sep_mount",
                    hidden: !0
                }));
                var o = function(e) {
                    _S("is_admin") || this.dirTree.getNodeById("remote/home") ? this.btnMountRemote.setVisible(e) : this.btnMountRemote.setVisible(!1), this.btnMountISO.setVisible(e), this.btnUmount.setVisible(e), this.btnMountList.setVisible(e), t.get("sep_mount").setVisible(e), e && "yes" === _D("supportmount") && this.mountConfig && (this.mountConfig.enable_remote_mount || this.mountConfig.enable_iso_mount ? this.btnUmount && this.btnUmount.show() : this.btnUmount && this.btnUmount.hide(), this.mountConfig.enable_remote_mount ? _S("is_admin") || this.dirTree.getNodeById("remote/home") ? this.btnMountRemote && this.btnMountRemote.show() : this.btnMountRemote.hide() : this.btnMountRemote && this.btnMountRemote.hide(), this.mountConfig.enable_iso_mount ? this.btnMountISO && this.btnMountISO.show() : this.btnMountISO && this.btnMountISO.hide(), this.mountConfig.enable_remote_mount || this.mountConfig.enable_iso_mount ? this.btnMountList.show() : this.btnMountList.hide()), SYNO.webfm.utils.ShowHideMenu(t.items)
                };
                t.showMountItem = o.createDelegate(this, [!0]), t.hideMountItem = o.createDelegate(this, [!1])
            }
            return this.btnSharingManager = e.cSharingManager(Ext.menu.Item, !0, this), t.add(this.btnSharingManager), t
        },
        n = function() {
            var e = new Ext.Toolbar({
                    cls: "syno-sds-fs-btbar",
                    style: {
                        padding: "0px 2px 4px 2px"
                    }
                }),
                n = SYNO.SDS.ActionPrivilege.isUserHasPrivilege("SYNO.SDS.AdminCenter.Share.Main");
            return !_S("is_admin") && !n || _S("diskless") || _S("standalone") ? (this.btnNewFolder = t.cNewFolder(SYNO.ux.Button, !1, this), e.add(this.btnNewFolder), _S("demo_mode") && this.btnNewFolder.hide()) : (this.btnNewFolder = t.cNewFolder(Ext.menu.Item, !0, this), this.btnNewShareFolder = t.cNewShareFolder(Ext.menu.Item, !0, this), this.menuCreateFolder = new SYNO.ux.Button({
                text: _WFT("common", "create"),
                menu: new SYNO.ux.Menu({
                    cls: "syno-webfm",
                    defaultOffsets: [0, 1],
                    items: [this.btnNewFolder, this.btnNewShareFolder]
                })
            }), e.add(this.menuCreateFolder), (_S("demo_mode") || _S("ha_safemode")) && this.menuCreateFolder.hide()), this.displayType = t.cBtnDisplayType(this), e.add(this.displayType), this.btnLocalUpload = t.cUploadLocal(SYNO.ux.Button, !1, this), _S("ha_safemode") || e.add(this.btnLocalUpload), this.btnRemoteUpload = t.cUploadRemote(SYNO.ux.Button, !1, this), _S("ha_safemode") || e.add(this.btnRemoteUpload), this.btntoolbarMenu = t.cActionMenu(i.call(this)), e.add(this.btntoolbarMenu), this.btnToolsMenu = t.cToolsMenu(o.call(this)), _S("ha_safemode") || e.add(this.btnToolsMenu), this.btnSettings = t.cSettings(SYNO.ux.Button, !1, this), e.add(this.btnSettings), e.addFill(), this.btnViewMode = t.cViewMode(SYNO.ux.SplitButton, this), e.addItem(this.btnViewMode), this.btnSort = t.cSort(SYNO.ux.Button, this), this.btnSort.setText(""), this.btnSort.addClass("webfm-sort-btn"), e.addItem(this.btnSort), e
        },
        s = function() {
            this.fileSearch = t.cFileFilter(this), this.fileFilter = t.cRemoteFileFilter(this), this.btnRefreshTree = new SYNO.ux.Button({
                tooltip: _WFT("common", "common_refresh"),
                iconCls: "syno-sds-fs-tbar-refresh",
                listeners: {
                    click: {
                        fn: this.reloadTree,
                        scope: this
                    }
                }
            }), this.pathBar = new SYNO.FileStation.PathBar({
                webfm: this,
                btnRefresh: this.btnRefreshTree,
                btnGoToDir: this.btnGoToDir,
                pathEditable: !0
            }), this.pathBar.tbPanel.mon(this.pathBar, "updatepath", this.updateFavBtn, this), this.btnHisBack = t.cHistoryBtn(SYNO.ux.Button, this, "back"), this.btnHisNext = t.cHistoryBtn(SYNO.ux.Button, this, "next"), this.btnAddFav = new SYNO.ux.Button({
                itemId: "addfav",
                iconCls: "sds-window-tbar-fav sds-window-tbar-addfav",
                ctCls: "sds-window-tbar-nomargin-btn",
                tabIndex: -1,
                scope: this,
                tooltip: _WFT("favorite", "add_favorite"),
                handler: function() {
                    var e = this.dirTree.getNodeById(this.getCurrentSource() + this.getCurrentDir());
                    if (e) {
                        var t = SYNO.webfm.utils.transNodeToRecs(e);
                        this.FileAction.AddFav(t)
                    }
                }
            }), this.btnDelFav = new SYNO.ux.Button({
                itemId: "delfav",
                iconCls: "sds-window-tbar-fav sds-window-tbar-delfav",
                ctCls: "sds-window-tbar-nomargin-btn",
                scope: this,
                hidden: !0,
                tabIndex: -1,
                tooltip: _WFT("favorite", "del_favorite"),
                handler: function() {
                    var e = this.dirTree.getNodeById("fm_fav_root");
                    e && e.childNodes.forEach(function(e) {
                        if (this.getCurrentDir() === e.attributes.path) return this.FileAction.DelFav(e.attributes.path, e.attributes.text), !1
                    }, this)
                }
            });
            var e = new Ext.Toolbar({
                cls: "syno-sds-fs-ttbar",
                itemId: "topToolbar",
                items: [this.btnHisBack, this.btnHisNext, this.btnRefreshTree, this.pathBar.mainPanel, this.btnAddFav, this.btnDelFav, this.fileSearch, this.fileFilter],
                listeners: {
                    resize: {
                        fn: function() {
                            var t = 0;
                            e.items.each(function(e) {
                                var i = "addfav" === e.itemId || "delfav" === e.itemId;
                                !0 !== e.hidden && !1 === i && (t += e.getOuterSize().width)
                            }), t -= this.pathBar.tbPanel.getWidth();
                            var i = e.getWidth() - e.getResizeEl().getPadding("lr"),
                                o = i - t + 1;
                            o > 0 && this.pathBar.setWidth(o)
                        },
                        scope: this
                    },
                    afterlayout: {
                        fn: function() {
                            this.pathBar.tbPanel.getEl().setStyle("overflow", "hidden")
                        },
                        scope: this,
                        single: !0
                    }
                }
            });
            return e
        };
    return function() {
        var t = s.call(e),
            i = n.call(e);
        return new Ext.Container({
            cls: "syno-sds-fs-tbar",
            layout: {
                type: "vbox",
                pack: "start",
                align: "stretch"
            },
            height: 72,
            defaults: {
                flex: 1
            },
            items: [t, i],
            getTopToolBar: function() {
                return t
            },
            getBottomToolbar: function() {
                return i
            }
        })
    }.call(e)
}, Ext.ns("SYNO.FileStation.Action"), SYNO.FileStation.Action.Basic = Ext.extend(Ext.Component, {
    constructor: function(e, t, i) {
        this.initVaribles(e, i);
        var o = t ? t.id : e.bkTaskCfg.taskid;
        if (t || (t = e.bkTaskCfg && !e.bkTaskCfg.api ? SYNO.SDS.BackgroundTaskMgr.addTask({
                id: o,
                title: this.genBkTitle(this.actionStr, this.fileStr),
                query: {
                    url: e.bkTaskCfg.url,
                    params: {
                        action: "readprogress",
                        taskid: o
                    }
                },
                cancel: {
                    url: e.bkTaskCfg.url,
                    params: {
                        action: "cancelprogress",
                        taskid: o
                    }
                }
            }) : SYNO.SDS.BackgroundTaskMgr.addWebAPITask({
                id: o,
                title: this.genBkTitle(this.actionStr, this.fileStr),
                interval: [{
                    time: 0,
                    interval: 1e3
                }, {
                    time: 3e3,
                    interval: 3e3
                }, {
                    time: 6e4,
                    interval: 6e3
                }, {
                    time: 12e4,
                    interval: 1e4
                }],
                query: {
                    api: e.bkTaskCfg.api,
                    method: "status",
                    version: e.bkTaskCfg.version || 1,
                    params: {
                        taskid: o
                    }
                },
                cancel: {
                    api: e.bkTaskCfg.api,
                    method: "stop",
                    version: e.bkTaskCfg.version || 1,
                    params: {
                        taskid: o
                    }
                }
            })), t.addCallback(this.onTaskCallBack, this), !this.blMsgMinimized && !this.isOwnerDestroyed()) {
            var n = (e.msgCfg.msg ? e.msgCfg.msg : this.actingText) + "...";
            this.taskMsg = n, this.showProgress(this.actionText, n, this.onCancelCallBack.createDelegate(this, [t]), !0, e.msgCfg.progress, e.msgCfg)
        }
        this.bkTask = t
    },
    initVaribles: function(e, t) {
        Ext.apply(this, e.actionCfg || {}), this.webfm = e.webfm, this.owner = e.owner || this.webfm.owner, this.blMsgMinimized = !0 === this.blMsgMinimized || !(!e.msgCfg || !e.msgCfg.blMsgMinimized) && e.msgCfg.blMsgMinimized, this.actionStr = e.actionStr, this.actingStr = e.actingStr, this.actionText = SYNO.webfm.utils.getLangText(this.actionStr), this.actingText = SYNO.webfm.utils.getLangText(this.actingStr), this.extra = t, this.blTaskFinished = !1
    },
    genBkTitle: function(e, t) {
        return ["{0}: {1}", "filebrowser:" + e.key, t]
    },
    onCancelCallBack: function(e) {
        e.cancel()
    },
    onCancelTask: function(e, t, i) {
        if (e.errno && e.errno.section && e.errno.key) {
            var o = e.errno,
                n = _WFT(o.section, o.key);
            this.isOwnerDestroyed() || !this.isOwnerVisible() ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", this.actionText, n) : this.getMsgBox().alert(this.actionText, n)
        }
    },
    onFinishTask: function(e, t, i, o) {
        t && t.errors ? this.showWebAPIErr(t, i, o) : t.result && "fail" == t.result || -1 === e ? this.showErrItems(t, i, o) : this.onCompleteTask(t, i, o)
    },
    onCompleteTask: function(e, t, i) {},
    onProgressTask: function(e, t, i, o) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible() && t && e && 0 < e) {
            var n = Ext.util.Format.htmlEncode(SYNO.webfm.utils.parseFullPathToFileName(t.processing_path || t.pfile || "")),
                s = (100 * e).toFixed(2),
                r = "" === n ? this.taskMsg : n,
                a = s + "&#37;",
                l = "",
                h = "",
                c = {},
                d = 0;
            Ext.isNumber(t.total) && 0 < t.total && (Ext.isNumber(t.processed_num) ? h = (t.processed_num || 0) + "/" + t.total : Ext.isNumber(t.processed_size) && (h = Ext.util.Format.fileSize(t.processed_size || 0) + "/" + Ext.util.Format.fileSize(t.total)), d += "" === h ? 0 : 20), 0 !== d && (c.heightIncrease = d), l = r + this.additionalInfo2Html(h), this.getMsgBox(c).updateProgress(e, a, l, !0)
        }
    },
    additionalInfo2Html: function(e) {
        var t = "";
        return "" !== e && (t += "<div>" + e + "</div>"), "" === t ? t : '<div class="syno-webfm-progress-additional-info">' + t + "</div>"
    },
    onTaskCallBack: function(e, t, i, o, n, s, r) {
        if (!n) return void this.hideProgress();
        "fail" === t ? (this.hideProgress(), this.blTaskFinished = !0) : "cancel" === t ? (this.onCancelTask(n, s, r), this.blTaskFinished = !0) : i ? (this.onFinishTask(o, n, s, r), this.blTaskFinished = !0) : (this.progressParam = {
            progress: o,
            obj: n,
            param: s,
            opts: r
        }, this.onProgressTask(o, n, s, r))
    },
    showProgress: function(e, t, i, o, n, s) {
        var r = {};
        o && (r.ok = _WFT("common", "hide")), i && (r.cancel = _WFT("common", "common_cancel"));
        var a = {
                title: e,
                msg: t,
                width: 300,
                progress: n,
                progressText: n ? "<span>0&#37;</span>" : "",
                cls: "syno-webfm-progress",
                closable: !1,
                buttons: r,
                cancelCb: i || null,
                fn: function(e, t, i, o) {
                    "ok" === e || "close" === o ? this.onMinimizeMsgBox() : "cancel" === e && i.cancelCb()
                }.createDelegate(this),
                hideDlg: !0,
                scope: this
            },
            l = {
                owner: this.owner || this.webfm.owner
            };
        Ext.copyTo(l, s || {}, "sinkable,draggable"), Ext.defer(function() {
            this.blTaskFinished || (this.progressParam && this.progressParam.opts && !1 === this.progressParam.opts.cancelable && (delete r.cancel, a.cancelCb = null), this.getMsgBox(l).show(a), this.progressParam && this.onProgressTask(this.progressParam.progress, this.progressParam.obj, this.progressParam.param, this.progressParam.opts))
        }, 3e3, this)
    },
    onMinimizeMsgBox: function() {
        var e = this.getMsgBox().getDialog();
        if (e.mon(e, "hide", function() {
                e.doClose()
            }), _S("standalone")) e.hide(this.webfm.monitorPanel.el), this.webfm.monitorPanel.activeTabPanel("background");
        else {
            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0].getBKTray().taskButton.el;
            e.hide(t)
        }
        this.blMsgMinimized = !0, this.sendFileTaskNotify(), this.getMsgBox().hide()
    },
    sendFileTaskNotify: function() {
        this.webfm.owner.sendFileTaskNotify(!0, this.bkTask.id)
    },
    hideProgress: function() {
        this.blMsgMinimized || this.isOwnerDestroyed() || this.getMsgBox().hide()
    },
    showWebAPIErr: function(e, t, i) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible()) {
            var o = SYNO.webfm.utils.getWebAPIErr(!1, e, t);
            this.getMsgBox().alert(this.actionText, o)
        }
    },
    showErrItems: function(e) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible()) {
            var t = "",
                i = 0;
            e.errno && (t += _WFT(e.errno.section, e.errno.key) + "<br>");
            var o, n, s;
            if (e.errItems && 0 < e.errItems.length) {
                for (s = e.errItems.length > 15 ? 15 : e.errItems.length, t += _WFT("error", "error_files"), i = 0; i < s; i++) o = e.errItems[i].name, n = o.lastIndexOf("/"), n = -1 == n ? 1 : n + 1, o = o.substr(n), o.length > 40 && (o = o.substr(0, 37) + "..."), t += "<br>" + Ext.util.Format.htmlEncode(o), e.errItems[i].section && (t += "<br>" + _WFT(e.errItems[i].section, e.errItems[i].key));
                s < e.errItems.length && (t += "<br>...")
            }
            "" === t && (t = _WFT("common", "error_system")), this.getMsgBox().alert(this.actionText, t)
        }
    },
    isOwnerVisible: function() {
        return this.owner && this.owner.isVisible() || this.msgBox && this.msgBox.isVisible()
    },
    isOwnerDestroyed: function() {
        return this.owner && this.owner.isDestroyed || this.msgBox && !this.msgBox.isVisible()
    },
    getMsgBox: function(e) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            var t = e && e.owner || this.owner;
            t = t.isDestroyed ? null : t, this.msgBox = new SYNO.SDS.MessageBoxV5({
                owner: t,
                preventDelay: !!e && (e.preventDelay || !1),
                draggable: !!e && (e.draggable || !1)
            })
        }
        if (e && e.heightIncrease) {
            this.msgBox.setHeight(this.msgBox.getFrameHeight() + 66 + e.heightIncrease)
        }
        return this.msgBox.getWrapper(e)
    },
    callFileBrowsers: function(e, t) {
        var i = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
        Ext.each(i, function(i) {
            var o = i.window.getPanelInstance();
            o.activeView.getView().trackResetOnLoad = !1, Ext.getClassByName("SYNO.FileStation.WindowPanel.superclass." + e).apply(o, t)
        })
    },
    setHighlightEntry: function() {
        this.callFileBrowsers("setHighlightEntry", arguments)
    },
    refreshTreeNode: function() {
        this.callFileBrowsers("refreshTreeNode", arguments)
    },
    refreshSearhGrid: function(e) {
        this.callFileBrowsers("refreshSearhGrid", arguments)
    },
    focusActiveView: function() {
        var e = Ext.get(document.activeElement),
            t = this.getMsgBox().getDialog().el;
        (e === t || e.up("#" + t.id)) && this.callFileBrowsers("focusActiveView", arguments), t.isVisible() || this.getMsgBox().hide()
    }
}), Ext.ns("SYNO.FileStation.LocalAction"), SYNO.FileStation.LocalAction.Basic = Ext.extend(SYNO.FileStation.Action.Basic, {
    constructor: function(e, t) {
        this.initVaribles(e), this.localGrid = SYNO.FileStation.instance().getFileTaskInstance();
        var i = this.localGrid.getStore();
        this.pollingTask = this.addTask({
            interval: 600,
            run: function() {
                var e = i.getById(t);
                if (e) {
                    switch (e.get("status")) {
                        case "NOT_STARTED":
                            break;
                        case "PROCESSING":
                            this.onProgressTask(e.get("progress"), e.get("statusText"), e.data);
                            break;
                        case "FAIL":
                            this.refreshTreeNode(this.srcIdArr, !0), this.hideProgress(), this.blTaskFinished = !0, this.pollingTask.stop();
                            var o = e.get("statusQtip");
                            this.blMsgMinimized || this.isOwnerDestroyed() || !this.isOwnerVisible() ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", this.actionText, o) : this.getMsgBox().alert(this.actionText, o);
                            break;
                        case "SUCCESS":
                            this.onCompleteTask(t), this.blTaskFinished = !0;
                            break;
                        default:
                            this.hideProgress(), this.blTaskFinished = !0, this.pollingTask.stop()
                    }
                } else {
                    var n = AppletProgram.action({
                        action: "gettask",
                        id: t
                    });
                    n ? "SUCCESS" === n.status && this.onCompleteTask(t) : (this.refreshTreeNode(this.srcIdArr, !0), this.hideProgress(), this.pollingTask.stop())
                }
            },
            scope: this
        });
        var o = (e.msgCfg.msg ? e.msgCfg.msg : this.actingText) + "...";
        this.showProgress(this.actionText, o, this.removeTask.createDelegate(this, [t]), !0, e.msgCfg.progress), this.pollingTask.start(!0)
    },
    removeTask: function(e) {
        var t = this.localGrid.getStore().getById(e);
        this.localGrid.removeOneTask(t)
    },
    initVaribles: function(e) {
        Ext.apply(this, e.actionCfg || {}), this.webfm = e.webfm, this.owner = e.owner || this.webfm.owner, this.blMsgMinimized = !0 === this.blMsgMinimized || !(!e.msgCfg || !e.msgCfg.blMsgMinimized) && e.msgCfg.blMsgMinimized, this.actionStr = e.actionStr, this.actingStr = e.actingStr, this.actionText = SYNO.webfm.utils.getLangText(this.actionStr), this.actingText = SYNO.webfm.utils.getLangText(this.actingStr), this.blTaskFinished = !1
    },
    onProgressTask: function(e, t, i) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible() && e && 0 < e) {
            var o, n, s = e / 100;
            e = e.toFixed(2), n = e + "&#37;", Ext.isNumber(i.total) && 0 < i.total && (Ext.isNumber(i.processed_num) ? n = e + "&#37;&nbsp;(" + (i.processed_num || 0) + "/" + i.total + ")" : Ext.isNumber(i.processed_size) && (n = e + "&#37;&nbsp;(" + Ext.util.Format.fileSize(i.processed_size || 0) + "/" + Ext.util.Format.fileSize(i.total) + ")")), n = '<div style="float:left;">' + n + "</div>", o = t, this.getMsgBox().updateProgress(s, n, o)
        }
    },
    onCompleteTask: function(e) {
        this.focusActiveView(), this.hideProgress(), this.pollingTask.stop(), this.removeTask(e)
    },
    sendFileTaskNotify: Ext.emptyFn,
    onMinimzieMsgBox: function() {
        var e = this.getMsgBox().getDialog();
        if (e.mon(e, "hide", function() {
                e.doClose()
            }), _S("standalone")) e.hide(this.webfm.monitorPanel.el), this.webfm.monitorPanel.activeTabPanel("local");
        else {
            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0].getBKTray().taskButton.el;
            e.hide(t)
        }
        this.blMsgMinimized = !0
    }
}), Ext.ns("SYNO.FileStation.Action"), SYNO.FileStation.Action.MVCP = Ext.extend(SYNO.FileStation.Action.Basic, {
    onProgressTask: function(e, t, i, o) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible() && t && e && (0 < e || 0 < parseInt(t.found_file_num, 10) || 0 < parseInt(t.found_dir_num, 10))) {
            var n = this.getRemainTimeStr(t),
                s = Ext.util.Format.fileSize(t.transfer_rate.toFixed(2)) + "/s",
                r = Ext.util.Format.htmlEncode(SYNO.webfm.utils.parseFullPathToFileName(t.processing_path || t.pfile || "")),
                a = (100 * e).toFixed(2),
                l = "" === r ? this.taskMsg : r,
                h = "0&#37;",
                c = "",
                d = "",
                u = "",
                f = {},
                m = 0;
            "NOT_STARTED" === t.status ? (u = _T("background_task", "task_waiting"), m = 20) : 0 < e ? (h = a + "&#37;", Ext.isNumber(t.total) && 0 < t.total && (Ext.isNumber(t.processed_num) ? d = (t.processed_num || 0) + "/" + t.total : Ext.isNumber(t.processed_size) && (d = Ext.util.Format.fileSize(t.processed_size || 0) + "/" + Ext.util.Format.fileSize(t.total))), m = 38) : (l = _WFT("common", "calculating"), u = String.format(_WFT("common", "count_file_dir_size"), t.found_file_num, t.found_dir_num, Ext.util.Format.fileSize(t.found_file_size)), m = 20), 0 !== m && (f.heightIncrease = m), c = l + this.additionalInfo2Html(u, d, s, n), this.getMsgBox(f).updateProgress(e, h, c, !0)
        }
    },
    getRemainTimeStr: function(e) {
        if (!e) return _T("common", "unknown");
        var t, i, o, n, s;
        return t = (e.total - e.processed_size) / e.transfer_rate, i = t / 86400, i > 1 ? s = _WFT("common", "time_greater_day") : (s = "", o = parseInt(t / 3600, 10), n = parseInt(t / 60 - 60 * o, 10), s += o >= 1 ? o + " " + _T("status", "status_hour") + ", " : "", "" === (s += n >= 1 ? n + " " + _T("status", "status_minute") : "") && (s = _WFT("common", "time_less_min"))), s
    },
    additionalInfo2Html: function(e, t, i, o) {
        var n = "";
        return "" !== e ? n += "<div>" + e + "</div>" : (n += "" === t ? "<div>" + i + "</div>" : "<div>" + t + "&nbsp;(" + i + ")</div>", n += "<div>" + _WFT("common", "time_remain") + ": " + o + "</div>"), "" === n ? n : '<div class="syno-webfm-progress-additional-info">' + n + "</div>"
    },
    onCancelTask: function(e, t, i) {
        SYNO.FileStation.Action.MVCP.superclass.onCancelTask.call(this, e), this.refreshTreeNode(this.srcIdArr.concat(this.destId), !0), this.extra && Ext.isDefined(this.extra.search_taskid) && this.refreshSearhGrid(this.extra.search_taskid)
    },
    onCompleteTask: function(e, t, i) {
        this.focusActiveView(), this.hideProgress(), this.refreshTreeNode(this.srcIdArr.concat(this.destId), !0), this.extra && Ext.isDefined(this.extra.search_taskid) && this.refreshSearhGrid(this.extra.search_taskid)
    }
}), SYNO.FileStation.LocalAction.MVCP = Ext.extend(SYNO.FileStation.LocalAction.Basic, {
    onCancelTask: function(e) {
        SYNO.FileStation.LocalAction.MVCP.superclass.onCancelTask.call(this, e), this.refreshTreeNode(this.srcIdArr.concat(this.destId), !0, SYNO.webfm.utils.source.local)
    },
    onCompleteTask: function(e) {
        this.refreshTreeNode(this.srcIdArr.concat(this.destId), !0, SYNO.webfm.utils.source.local), SYNO.FileStation.LocalAction.MVCP.superclass.onCompleteTask.apply(this, arguments)
    }
}), Ext.ns("SYNO.FileStation.Action"), Ext.define("SYNO.FileStation.Action.Delete", {
    extend: "SYNO.FileStation.Action.Basic",
    showWebAPIErr: function(e, t, i) {
        this.refreshTreeNode(this.srcIdArr, !0, void 0, void 0, !1), SYNO.FileStation.Action.Delete.superclass.showWebAPIErr.call(this, e)
    },
    setTrackResetOnLoad: function(e) {
        this.webfm.activeView.view ? this.webfm.activeView.view.trackResetOnLoad = e : this.webfm.activeView.dataView && (this.webfm.activeView.dataView.trackResetOnLoad = e)
    },
    bindEvents: function() {
        this.setTrackResetOnLoad(!1), this.webfm.activeDS.on("load", this.focusNextRecord, this)
    },
    unbindEvents: function() {
        this.setTrackResetOnLoad(!0), this.webfm.activeDS.un("load", this.focusNextRecord, this)
    },
    focusNextRecord: function() {
        this.webfm.enableViewMask();
        var e = this.webfm.activeView.getSelectionModel().getSelections(),
            t = -1;
        e.length > 0 && (t = this.webfm.activeDS.indexOf(e[0])), this.focusIndex >= 0 && -1 === t && (this.webfm.activeView.getSelectionModel().selectRow(this.focusIndex), this.webfm.activeView.focusItem(this.focusIndex)), this.unbindEvents()
    },
    onCompleteTask: function(e, t, i) {
        this.focusActiveView(), this.hideProgress(), this.bindEvents(), this.refreshTreeNode(this.srcIdArr, e.has_dir, void 0, void 0, !1), this.extra && Ext.isDefined(this.extra.search_taskid) && this.refreshSearhGrid(this.extra.search_taskid)
    },
    onProgressTask: function(e, t, i, o) {
        if (!this.blMsgMinimized && !this.isOwnerDestroyed() && this.isOwnerVisible() && t && e && (0 < e || 0 < parseInt(t.found_file_num, 10) || 0 < parseInt(t.found_dir_num, 10))) {
            var n = Ext.util.Format.htmlEncode(SYNO.webfm.utils.parseFullPathToFileName(t.processing_path || t.pfile || "")),
                s = (100 * e).toFixed(2),
                r = "" === n ? this.taskMsg : n,
                a = "0&#37;",
                l = "",
                h = "",
                c = "",
                d = {},
                u = 0;
            0 < e ? (a = s + "&#37;", Ext.isNumber(t.total) && 0 < t.total && (Ext.isNumber(t.processed_num) ? h = (t.processed_num || 0) + "/" + t.total : Ext.isNumber(t.processed_size) && (h = Ext.util.Format.fileSize(t.processed_size || 0) + "/" + Ext.util.Format.fileSize(t.total)), u = "" === h ? 0 : 20)) : (c = String.format(_WFT("common", "count_file_dir_size"), t.found_file_num, t.found_dir_num, Ext.util.Format.fileSize(t.found_file_size)), u = 20), 0 !== u && (d.heightIncrease = u), l = r + this.additionalInfo2Html(c, h), this.getMsgBox(d).updateProgress(e, a, l, !0)
        }
    },
    additionalInfo2Html: function(e, t) {
        var i = "";
        return i += "" !== e ? "<div>" + e + "</div>" : "" === t ? "" : "<div>" + t + "</div>", "" === i ? i : '<div class="syno-webfm-progress-additional-info">' + i + "</div>"
    }
}), SYNO.FileStation.LocalAction.Delete = Ext.extend(SYNO.FileStation.LocalAction.Basic, {
    setTrackResetOnLoad: function(e) {
        this.webfm.activeView.view ? this.webfm.activeView.view.trackResetOnLoad = e : this.webfm.activeView.thumbnailView && (this.webfm.activeView.thumbnailView.trackResetOnLoad = e)
    },
    bindEvents: function() {
        this.setTrackResetOnLoad(!1), this.webfm.activeDS.on("load", this.focusNextRecord, this)
    },
    unbindEvents: function() {
        this.setTrackResetOnLoad(!0), this.webfm.activeDS.un("load", this.focusNextRecord, this)
    },
    focusNextRecord: function() {
        this.webfm.enableViewMask();
        var e = this.webfm.activeView.getSelectionModel().getSelections(),
            t = -1;
        e.length > 0 && (t = this.webfm.activeDS.indexOf(e[0])), this.focusIndex >= 0 && -1 === t && (this.webfm.activeView.getSelectionModel().selectRow(this.focusIndex), this.webfm.activeView.focusItem(this.focusIndex)), this.unbindEvents()
    },
    onCompleteTask: function(e) {
        this.bindEvents(), this.refreshTreeNode(this.srcIdArr, !0, void 0, void 0, !1), SYNO.FileStation.LocalAction.Delete.superclass.onCompleteTask.apply(this, arguments)
    }
}), Ext.ns("SYNO.FileStation.Action"), SYNO.FileStation.Action.Extract = Ext.extend(SYNO.FileStation.Action.Basic, {
    blMultiExtract: !1,
    blCancel: !1,
    gZipArr: [],
    gZipIndex: 0,
    gDestArr: [],
    initVaribles: function(e) {
        SYNO.FileStation.Action.Extract.superclass.initVaribles.call(this, e), this.cfg = e, this.url = e.bkTaskCfg.url, this.gZipArr = this.gZipArr ? this.gZipArr : [], this.gDestArr = this.gDestArr ? this.gDestArr : []
    },
    getCurZipFile: function() {
        return this.blMultiExtract && this.gZipArr && this.gZipArr.length > 0 ? this.gZipArr[this.gZipIndex] : this.file_path
    },
    getCurZipName: function() {
        return SYNO.webfm.utils.parseFullPathToFileName(this.getCurZipFile())
    },
    resetExtractAction: function() {
        this.gZipArr = [], this.gDestArr = [], this.gZipIndex = 0
    },
    genBkTitle: function(e, t) {
        return ["{0}: {1}", "filebrowser:" + e.key, this.getCurZipName() + t]
    },
    onCancelCallBack: function(e, t, i) {
        this.blCancel = !0, this.resetExtractAction(), SYNO.FileStation.Action.Extract.superclass.onCancelCallBack.apply(this, arguments)
    },
    onFinishTask: function(e, t, i, o) {
        if (t.errors && 1403 == t.errors[0].code) {
            this.hideProgress(), this.blMsgMinimized = !1;
            var n = this.getCurZipFile(),
                s = this.actionText + " " + Ext.util.Format.htmlEncode(SYNO.webfm.utils.parseFullPathToFileName(n));
            this.getMsgBox().show({
                title: s,
                msg: _WFT("extract", "extract_enter_pass"),
                buttons: Ext.MessageBox.OKCANCEL,
                fn: function(e, t) {
                    if ("ok" == e) {
                        var i = this.ajaxParams,
                            o = i;
                        o.file_path = n, o.dest_folder_path = this.gDestArr.length > 1 ? this.gDestArr[this.gZipIndex] : i.dest_folder_path,
                            o.dest_folder_path = o.dest_folder_path, o.password = t, SYNO.API.currentManager.requestAPI("SYNO.FileStation.Extract", "start", "2", o, this.onExtractSendDone, this), this.ajaxParams = o
                    }
                },
                width: 310,
                minWidth: 250,
                scope: this,
                prompt: !0,
                password: !0
            })
        } else t.errors ? (this.showWebAPIErr(t, i, o), this.refreshTreeNode([this.destId], !0)) : this.onCompleteTask(t, i, o)
    },
    onCompleteTask: function(e, t, i) {
        if (this.refreshTreeNode([this.destId], !0), this.blMultiExtract && !this.blCancel && ++this.gZipIndex < this.gZipArr.length && this.gZipArr[this.gZipIndex]) {
            var o = this.ajaxParams,
                n = o;
            return n.file_path = this.gZipArr[this.gZipIndex], n.dest_folder_path = this.gDestArr.length > 1 ? this.gDestArr[this.gZipIndex] : o.dest_folder_path, n.dest_folder_path = n.dest_folder_path, this.hideProgress(), SYNO.API.currentManager.requestAPI("SYNO.FileStation.Extract", "start", "2", n, this.onExtractSendDone, this), void(this.ajaxParams = n)
        }
        this.focusActiveView(), this.hideProgress()
    },
    onExtractSendDone: function(e, t, i) {
        if (e && t && t.taskid) this.cfg.bkTaskCfg.taskid = t.taskid, SYNO.FileStation.Action.Extract.superclass.constructor.call(this, this.cfg);
        else {
            var o = SYNO.webfm.utils.getWebAPIErrStr(e, t, i);
            this.blMsgMinimized || this.isOwnerDestroyed() || !this.isOwnerVisible() ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", this.actionText, o) : this.getMsgBox().alert(this.actionText, o)
        }
    }
}), Ext.ns("SYNO.FileStation.Action"), SYNO.FileStation.Action.Compress = Ext.extend(SYNO.FileStation.Action.Basic, {
    onCompleteTask: function(e) {
        this.focusActiveView(), this.hideProgress(), this.setHighlightEntry(this.fileid), this.refreshTreeNode(this.srcIdArr, !0)
    }
}), Ext.define("SYNO.FileStation.SharingCustomDialog", {
    extend: "SYNO.SDS.ModalWindow",
    enableLogoCustomize: !1,
    enableBgCustomize: !1,
    logoType: "default",
    logoPath: "",
    logoFullPath: "",
    bgType: "default",
    bgPath: "",
    bgFullPath: "",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t]), this.recvMessageFn = this.onRecvMessageCallback.createDelegate(this)
    },
    fillConfig: function(e) {
        return Ext.apply(this, e || {}), {
            owner: this.owner,
            width: 667,
            height: "auto",
            footerStyle: "padding: 12px 0 0 0",
            collapsible: !1,
            resizable: !1,
            title: _WFT("sharing", "sharing_page_style"),
            buttons: [{
                text: _WFT("common", "preview"),
                handler: this.onPreview,
                scope: this
            }, {
                text: _WFT("common", "cancel"),
                handler: this.onCancel,
                scope: this
            }, {
                btnStyle: "blue",
                text: _WFT("common", "ok"),
                handler: this.onConfirm,
                scope: this
            }],
            listeners: {
                close: this.onClose,
                scope: this
            },
            items: this.createPanel()
        }
    },
    createPanel: function() {
        var e = {
            bodyStyle: "padding: 0",
            useGradient: !1,
            cls: "syno-admincenter-loginstyle-panel",
            autoHeight: !0,
            autoFlexcroll: !0,
            fileUpload: !0,
            useDefaultBtn: !1,
            trackResetOnLoad: !0,
            items: [this.getBackgroundField(), this.getLogoField(), this.getFooterMsgField(), this.getFooterEnableHtmlField()],
            listeners: {
                afterlayout: {
                    fn: this.onInitForm,
                    scope: this,
                    single: !0
                }
            }
        };
        return this.panel = new SYNO.ux.FormPanel(e), this.panel
    },
    onInitForm: function() {
        this.onBindEventListener(), this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Core.Theme.FileSharingLogin",
            method: "get",
            version: 1,
            params: {},
            callback: function(e, t) {
                this.clearStatusBusy(), e ? this.setFormData(t) : this.onErrorHandle(t)
            },
            scope: this
        })
    },
    setFormData: function(e) {
        var t = "",
            i = {
                api: "SYNO.Core.Theme.Image",
                method: "get",
                version: 1,
                params: {}
            };
        this.originalData = e, this.panel.form.setValues(e), this.enableLogoCustomize = e.enable_logo_customize, this.enableLogoCustomize && (i.params.type = "fbsharing_login_logo", t = SYNO.API.GetBaseURL(i), t = Ext.urlAppend(t, Ext.urlEncode({
            seq: e.logo_seq
        }))), this.onSetLogoImage(t), t = "", this.enableBgCustomize = e.enable_background_customize, this.enableBgCustomize && (i.params.type = "fbsharing_login_background", t = SYNO.API.GetBaseURL(i), t = Ext.urlAppend(t, Ext.urlEncode({
            seq: e.background_seq
        }))), this.onSetBackgroundImage(t)
    },
    onBindEventListener: function() {
        var e = this.getEl().child(".login-background-field").child(".thumb-container"),
            t = this.getEl().child(".login-logo-field").child(".thumb-container");
        e.on("click", this.onBackgroundClick, this), t.on("click", this.onLogoClick, this)
    },
    onBackgroundClick: function() {
        this.bgSelector ? this.bgSelector.show() : (this.bgSelector = new SYNO.SDS.Utils.ImageSelector({
            owner: this
        }, "fbsharing_login", "background"), this.bgSelector.mon(this.bgSelector, "choose", this.onBackgroundSelectDone, this), this.bgSelector.open())
    },
    onLogoClick: function() {
        this.logoSelector ? this.logoSelector.show() : (this.logoSelector = new SYNO.SDS.Utils.ImageSelector({
            owner: this
        }, "fbsharing_login", "logo"), this.logoSelector.mon(this.logoSelector, "choose", this.onLogoSelectDone, this), this.logoSelector.open())
    },
    onBackgroundSelectDone: function(e) {
        e && (this.onSetBackgroundImage(e.get("url")), this.bgType = e.get("apply_type"), "default" === this.bgType ? this.panel.form.findField("background_position").setValue("fill") : this.panel.form.findField("background_position").setValue("center"), this.bgFullPath = e.get("path"), this.bgPath = "fromDS" == this.bgType ? e.get("path") : e.get("path").split("/").pop(), this.bgSelector.hide())
    },
    onLogoSelectDone: function(e) {
        e && (this.onSetLogoImage(e.get("url")), this.logoType = e.get("apply_type"), this.logoFullPath = e.get("path"), this.logoPath = "fromDS" == this.logoType ? e.get("path") : e.get("path").split("/").pop(), this.logoSelector.hide())
    },
    getBackgroundField: function() {
        var e = new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: [
                [_T("dsmoption", "login_background_position_center"), "center"],
                [_T("dsmoption", "login_background_position_fill"), "fill"],
                [_T("dsmoption", "login_background_position_fit"), "fit"],
                [_T("dsmoption", "login_background_position_stretch"), "stretch"],
                [_T("dsmoption", "login_background_position_tile"), "tile"]
            ]
        });
        return {
            fieldLabel: _T("dsmoption", "login_background"),
            layout: "column",
            border: !1,
            cls: "login-background-field",
            items: [{
                xtype: "container",
                cls: "thumb-container",
                overCls: "thumb-container-over",
                items: [{
                    itemId: "background_addImage",
                    xtype: "container",
                    cls: "add-image",
                    overCls: "add-image-over",
                    items: [{
                        xtype: "container",
                        cls: "add-image-icon"
                    }]
                }, {
                    itemId: "background_thumbnail",
                    xtype: "box",
                    cls: "thumb-image",
                    overCls: "thumb-image-over",
                    autoEl: {
                        tag: "img"
                    }
                }]
            }, {
                xtype: "container",
                cls: "option-container",
                items: [{
                    name: "background_position",
                    xtype: "syno_combobox",
                    hideLabel: !0,
                    forceSelection: !0,
                    allowBlank: !1,
                    displayField: "display",
                    valueField: "value",
                    width: 272,
                    store: e,
                    disabled: !0
                }, {
                    xtype: "syno_colorfield",
                    itemId: "background_color",
                    name: "background_color",
                    value: "#FFFFFF",
                    width: 272,
                    hideLabel: !0,
                    disabled: !0
                }, {
                    xtype: "syno_button",
                    text: _T("dsmoption", "login_remove"),
                    handler: this.onSetBackgroundImage.createDelegate(this, [""]),
                    scope: this
                }]
            }]
        }
    },
    getLogoField: function() {
        var e = new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: [
                [_WFT("sharing", "right_up"), "rightup"],
                [_WFT("sharing", "left_up"), "leftup"],
                [_WFT("sharing", "right_bottom"), "rightbottom"],
                [_WFT("sharing", "left_bottom"), "leftbottom"]
            ]
        });
        return {
            fieldLabel: _T("dsmoption", "login_logo"),
            layout: "column",
            border: !1,
            cls: "login-logo-field",
            items: [{
                xtype: "container",
                cls: "thumb-container",
                overCls: "thumb-container-over",
                items: [{
                    itemId: "logo_addImage",
                    xtype: "container",
                    cls: "add-image",
                    overCls: "add-image-over",
                    items: [{
                        xtype: "container",
                        cls: "add-image-icon"
                    }]
                }, {
                    itemId: "logo_thumbnail",
                    xtype: "box",
                    cls: "thumb-image",
                    overCls: "thumb-image-over",
                    autoEl: {
                        tag: "img"
                    }
                }]
            }, {
                xtype: "container",
                cls: "option-container",
                items: [{
                    name: "logo_position",
                    xtype: "syno_combobox",
                    hideLabel: !0,
                    forceSelection: !0,
                    allowBlank: !1,
                    displayField: "display",
                    valueField: "value",
                    width: 272,
                    store: e,
                    disabled: !0
                }, {
                    xtype: "syno_button",
                    cls: "thumb-remove-btn",
                    text: _T("dsmoption", "login_remove"),
                    handler: this.onSetLogoImage.createDelegate(this, [""]),
                    scope: this
                }]
            }]
        }
    },
    getFooterMsgField: function() {
        return this.footerMsgField || (this.footerMsgField = new SYNO.ux.TextArea({
            fieldLabel: _T("dsmsetting", "footer_msg"),
            name: "footer_msg",
            itemCls: "login-footer-msg-field",
            maxLength: 512,
            width: 438,
            height: 68,
            allowBlank: !0
        })), this.footerMsgField
    },
    getFooterEnableHtmlField: function() {
        return this.footerEnableHtmlCheckbox || (this.footerEnableHtmlCheckbox = new SYNO.ux.Checkbox({
            boxLabel: _T("dsmsetting", "footer_enable_html"),
            name: "enable_footer_html",
            checked: !1,
            hideLabel: !1
        })), this.footerEnableHtmlCheckbox
    },
    onSetBackgroundImage: function(e, t) {
        var i = this.getEl().child(".login-background-field").child(".thumb-image"),
            o = this.getEl().child(".login-background-field").child(".add-image"),
            n = this.panel.form.findField("background_position"),
            s = this.panel.form.findField("background_color");
        this.enableBgCustomize && t || (Ext.isEmpty(e) ? (i.hide(), o.show(), n.disable(), s.disable(), this.enableBgCustomize = !1) : (i.dom.src = e, i.show(), o.hide(), n.enable(), s.enable(), this.enableBgCustomize = !0), t && (this.enableBgCustomize = !1))
    },
    onSetLogoImage: function(e) {
        var t = this.getEl().child(".login-logo-field").child(".thumb-image"),
            i = this.getEl().child(".login-logo-field").child(".add-image"),
            o = this.panel.form.findField("logo_position");
        Ext.isEmpty(e) ? (t.hide(), i.show(), o.disable(), this.enableLogoCustomize = !1) : (t.dom.src = e, t.show(), i.hide(), o.enable(), this.enableLogoCustomize = !0)
    },
    prepareConfirmParam: function() {
        var e = {},
            t = this.panel.form.findField("background_position"),
            i = this.panel.form.findField("background_color"),
            o = this.panel.form.findField("logo_position"),
            n = this.panel.form.findField("footer_msg"),
            s = this.panel.form.findField("enable_footer_html");
        return e.logo_position = o.getValue(), e.enable_logo_customize = this.enableLogoCustomize, this.enableLogoCustomize && this.logoType && this.logoPath && (e.logo_type = this.logoType, e.logo_path = this.logoPath), e.background_position = t.getValue(), e.background_color = i.getValue(), e.enable_background_customize = this.enableBgCustomize, this.enableBgCustomize && this.bgType && this.bgPath && (e.background_type = this.bgType, e.background_path = this.bgPath), e.footer_msg = n.getValue(), e.enable_footer_html = s.getValue(), e
    },
    checkFormValid: function() {
        return this.panel.form.isValid()
    },
    checkFormDirty: function() {
        return !!this.panel.form.isDirty() || !(!this.bgPath && !this.logoPath && this.enableLogoCustomize == this.originalData.enable_logo_customize && this.enableBgCustomize == this.originalData.enable_background_customize)
    },
    onClose: function() {
        this.onRemoveMessageEvent()
    },
    onConfirm: function() {
        if (!this.checkFormValid()) return void this.getMsgBox().alert("", _WFT("common", "forminvalid"));
        if (!this.checkFormDirty()) return this.onCloseSelector(), void this.close();
        var e = this.prepareConfirmParam();
        this.sendWebAPI({
            api: "SYNO.Core.Theme.FileSharingLogin",
            method: "set",
            version: 1,
            params: e,
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.onCloseSelector(), this.close()) : this.onErrorHandle(t)
            },
            scope: this
        })
    },
    onErrorHandle: function(e) {
        this.getMsgBox().alert("", _WFT("error", "error_error_system"))
    },
    getFullPath: function(e, t, i) {
        var o = "";
        return Ext.isEmpty(e) ? o : (o = e, "history" === t ? o = "/usr/syno/etc/fbsharing_login_image/" + e : "default" === t && i && (o = "/usr/syno/synoman/webman/resources/images/1x/default_login_background/" + e), o)
    },
    getHexPath: function(e) {
        var t = "";
        return Ext.isEmpty(e) || (t = SYNO.SDS.Utils.bin2hex(e)), t
    },
    onPreview: function() {
        var e, t, i, o, n, s = window.location.protocol + "//" + window.location.host,
            r = s + "/sharing/";
        if (!this.checkFormValid()) return void this.getMsgBox().alert("", _WFT("common", "forminvalid"));
        o = this.panel.form.findField("background_position").getValue(), n = this.panel.form.findField("background_color").getValue(), i = this.panel.form.findField("logo_position").getValue(), e = SYNO.SDS.Utils.bin2hex(this.getFullPath(this.bgPath, this.bgType, !0)), t = SYNO.SDS.Utils.bin2hex(this.getFullPath(this.logoPath, this.logoType, !1));
        var a = {
            preview: !0,
            sharing_preview_project_name: "SYNO.SDS.App.FileStation3.Instance",
            sharing_preview_status: "user",
            sharing_preview_params: Ext.encode({
                preview_modified: !Ext.isIE9m && this.checkFormDirty(),
                enable_logo: this.enableLogoCustomize,
                enable_background: this.enableBgCustomize,
                background_path: e,
                background_position: this.enableBgCustomize ? o : "",
                background_color: this.enableBgCustomize ? n : "#FFFFFF",
                logo_path: t,
                logo_position: this.enableLogoCustomize ? i : "",
                enable_footer_html: this.footerEnableHtmlCheckbox.getValue(),
                SynoToken: _S("SynoToken")
            })
        };
        r = Ext.urlAppend(r, Ext.urlEncode(a)), this.onAddMessageEvent(), this.previewWindow = window.open(r, "preview_window")
    },
    onAddMessageEvent: function() {
        !Ext.isIE9m && window.addEventListener && window.addEventListener("message", this.recvMessageFn)
    },
    onRecvMessageCallback: function(e) {
        var t = window.location.protocol + "//" + window.location.host,
            i = {};
        if (t === e.origin || "message" === e.type) {
            if ("save" === e.data.action) return this.setStatusBusy(), void this.onConfirm();
            try {
                i = JSON.parse(e.data)
            } catch (e) {
                return
            }
            "fbsharing" === i.name && "getFooterMsg" === i.method && this.previewWindow.postMessage(this.footerMsgField.getValue(), t)
        }
    },
    onRemoveMessageEvent: function() {
        !Ext.isIE9m && window.removeEventListener && window.removeEventListener("message", this.recvMessageFn)
    },
    onCloseSelector: function() {
        this.bgSelector && this.bgSelector.close(), this.logoSelector && this.logoSelector.close()
    },
    onCancel: function() {
        this.onCloseSelector(), this.close()
    }
}), SYNO.FileStation.WebCache = Ext.extend(Object, {
    constructor: function(e) {
        this.data = e || new Ext.util.MixedCollection(!1, function(e) {
            return e.uid || e.gid
        })
    },
    destroy: function() {
        delete this.data
    },
    getData: function() {
        return this.data.clone()
    },
    getCount: function() {
        return this.data.getCount()
    },
    get: function(e) {
        return this.data.get(e)
    },
    addData: function(e, t) {
        this.data.add(e, t)
    },
    addAllData: function(e) {
        this.data.addAll(e)
    },
    removeKey: function(e) {
        this.data.removeKey(e)
    },
    clear: function() {
        this.data.clear()
    }
}), SYNO.FileStation.SharingConfigGrid = Ext.extend(SYNO.ux.GridPanel, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.FileStation.SharingConfigGrid.superclass.constructor.call(this, t)
    },
    fillConfig: function(e) {
        this.enableColumn = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enabled",
            width: 50,
            align: "center",
            menuDisabled: !0,
            enableFastSelectAll: !0,
            isIgnore: function(e, t) {
                return t.get("is_admin")
            },
            renderer: function(e, t, i) {
                return i.get("is_admin") ? SYNO.ux.EnableColumn.prototype.disableRenderer.call(this, !0, t, i) : SYNO.ux.EnableColumn.prototype.renderer.call(this, e, t, i)
            }
        }), this.columnModel = new Ext.grid.ColumnModel([this.enableColumn, {
            header: _T("user", "user_account"),
            dataIndex: "name",
            width: 100,
            menuDisabled: !0
        }]), this.pageSize = 100, this.userStore = this.getUserStore(), this.groupStore = this.getGroupStore();
        var t = {
            header: !1,
            cm: this.columnModel,
            ds: this.userStore,
            loadMask: !0,
            tbar: {
                items: [this.getUserGroupCombobox(), "->", this.getTextFilter()]
            },
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                scrollDelay: !1,
                forceFit: !0
            }),
            bbar: this.paging = new SYNO.ux.PagingToolbar({
                store: this.userStore,
                displayInfo: !0,
                pageSize: this.pageSize,
                showRefreshBtn: !0,
                doRefresh: function() {
                    this.store.rejectChanges(), SYNO.ux.PagingToolbar.prototype.doRefresh.call(this)
                },
                paramNames: {
                    start: "offset"
                }
            }),
            plugins: [this.enableColumn]
        };
        return Ext.apply(t, e), t
    },
    getUserStore: function() {
        var e = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.UserGrp",
                method: "list_user",
                version: 1
            }),
            baseParams: {
                type: "all",
                offset: 0,
                limit: this.pageSize
            },
            reader: new Ext.data.JsonReader({
                root: "users",
                totalProperty: "total",
                id: "name"
            }, ["enabled", "name", "uid", "is_admin"]),
            remoteSort: !0,
            listeners: {
                load: {
                    fn: function(e, t, i) {
                        var o = 0,
                            n = null;
                        for (o = 0; o < t.length; o++) n = this.privilege.user.get(t[o].get("uid")), n && !0 === n.enabled || t[o].get("is_admin") ? t[o].set("enabled", !0) : t[o].set("enabled", !1);
                        e.commitChanges()
                    },
                    scope: this
                },
                beforeload: {
                    fn: function(e, t) {
                        if (this.query !== t.query) return this.query = t.query, void this.privilege.user.clear();
                        var i = e.getModifiedRecords();
                        this.privilege.user && this.privilege.user.addAllData(Ext.pluck(i, "data"))
                    },
                    scope: this
                }
            }
        });
        return this.addManagedComponent(e), e
    },
    getGroupStore: function() {
        var e = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.UserGrp",
                method: "list_group",
                version: 1
            }),
            baseParams: {
                type: "all",
                offset: 0,
                limit: this.pageSize
            },
            reader: new Ext.data.JsonReader({
                root: "groups",
                totalProperty: "total",
                id: "name"
            }, ["enabled", "name", "gid"]),
            remoteSort: !0,
            listeners: {
                load: {
                    fn: function(e, t, i) {
                        var o = 0,
                            n = null;
                        for (o = 0; o < t.length; o++) n = this.privilege.group.get(t[o].get("gid")), n && !0 === n.enabled ? t[o].set("enabled", !0) : t[o].set("enabled", !1);
                        e.commitChanges()
                    },
                    scope: this
                },
                beforeload: {
                    fn: function(e, t) {
                        if (this.query !== t.query) return this.query = t.query, void this.privilege.group.clear();
                        var i = e.getModifiedRecords();
                        this.privilege.group && this.privilege.group.addAllData(Ext.pluck(i, "data"))
                    },
                    scope: this
                }
            }
        });
        return this.addManagedComponent(e), e
    },
    getUserGroupCombobox: function() {
        return this.userGroupComboStore = new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["value", "display"],
            data: [
                ["user", _T("common", "user")],
                ["group", _T("group", "group_group")]
            ]
        }), this.userGroupCombobox = new SYNO.ux.ComboBox({
            itemId: "selector",
            width: 150,
            store: this.userGroupComboStore,
            displayField: "display",
            valueField: "value",
            value: "user",
            mode: "local",
            editable: !1,
            forceSelection: !0,
            listeners: {
                select: function(e, t, i) {
                    this.reconfigure(0 === i ? this.userStore : this.groupStore, this.columnModel), this.paging.bindStore(this.getStore()), this.textFilter.store = this.getStore(), this.store.reload()
                },
                scope: this
            }
        }), this.userGroupCombobox
    },
    getTextFilter: function() {
        return this.textFilter = new SYNO.ux.TextFilter({
            itemId: "search",
            queryParam: "query",
            emptyText: _T("group", "search_group"),
            store: this.userStore,
            pageSize: this.pageSize
        }), this.textFilter
    },
    load: function() {
        this.paging.doRefresh()
    },
    setPrivilege: function(e, t) {
        this.privilege = {}, this.privilege.user = new SYNO.FileStation.WebCache(e), this.privilege.group = new SYNO.FileStation.WebCache(t)
    },
    getPrivilege: function(e) {
        return this.privilege.user.addAllData(Ext.pluck(this.userStore.getModifiedRecords(), "data")), this.privilege.group.addAllData(Ext.pluck(this.groupStore.getModifiedRecords(), "data")), this.privilege
    }
}), SYNO.FileStation.SharingConfig = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.FileStation.SharingConfig.superclass.constructor.call(this, t), this.mon(this, "afterlayout", function() {
            SYNO.SDS.Utils.AddTip(this.getComponent("security_fieldset").getComponent("disable_html_checkbox").getEl(), _WFT("security", "disable_html_info"))
        }, this, {
            single: !0
        }), this.privilege = {
            sharing_user: new SYNO.FileStation.WebCache,
            sharing_group: new SYNO.FileStation.WebCache,
            file_request_user: new SYNO.FileStation.WebCache,
            file_request_group: new SYNO.FileStation.WebCache
        }
    },
    fillConfig: function(e) {
        var t = {
            border: !1,
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_fieldset",
                title: _T("helptoc", "sharing"),
                items: [{
                    xtype: "syno_displayfield",
                    value: _WFT("sharing", "config_desc")
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("mount", "everyone"),
                    name: "sharing_allow",
                    inputValue: "everyone"
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("mount", "admin"),
                    name: "sharing_allow",
                    inputValue: "admin"
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("common", "specific_user_group"),
                    name: "sharing_allow",
                    inputValue: "per_user",
                    handler: this.onCheckChanged.createDelegate(this)
                }, {
                    xtype: "hidden",
                    name: "enabled_sharing_privilege",
                    ref: "../sharingEnabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "disabled_sharing_privilege",
                    ref: "../sharingDisabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "enabled_sharing_group_privilege",
                    ref: "../sharingGroupEnabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "disabled_sharing_group_privilege",
                    ref: "../sharingGroupDisabledHiddenField",
                    value: ""
                }, {
                    xtype: "syno_button",
                    indent: 1,
                    text: _WFT("common", "specific_user_group"),
                    ref: "../setSharingPriviledgeBtn",
                    disabled: !0,
                    scope: this,
                    handler: this.onClickSetSharingPriviledge
                }]
            }, {
                xtype: "syno_fieldset",
                title: _WFT("sharing", "request_link"),
                items: [{
                    xtype: "syno_displayfield",
                    value: _WFT("sharing", "file_request_allow_desc")
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("mount", "everyone"),
                    name: "file_request_allow",
                    inputValue: "everyone"
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("mount", "admin"),
                    name: "file_request_allow",
                    inputValue: "admin"
                }, {
                    xtype: "syno_radio",
                    indent: 1,
                    boxLabel: _WFT("common", "specific_user_group"),
                    name: "file_request_allow",
                    inputValue: "per_user",
                    handler: this.onFileRequestCheckChanged.createDelegate(this)
                }, {
                    xtype: "hidden",
                    name: "enabled_file_request_privilege",
                    ref: "../fileRequestEnabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "disabled_file_request_privilege",
                    ref: "../fileRequestDisabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "enabled_file_request_group_privilege",
                    ref: "../fileRequestGroupEnabledHiddenField",
                    value: ""
                }, {
                    xtype: "hidden",
                    name: "disabled_file_request_group_privilege",
                    ref: "../fileRequestGroupDisabledHiddenField",
                    value: ""
                }, {
                    xtype: "syno_button",
                    indent: 1,
                    text: _WFT("common", "specific_user_group"),
                    ref: "../setFileRequestPriviledgeBtn",
                    disabled: !0,
                    scope: this,
                    handler: this.onClickSetFileRequestPriviledge
                }]
            }, {
                xtype: "syno_fieldset",
                itemId: "limit_fieldset",
                title: _WFT("sharing", "limit_setting_title"),
                items: [{
                    xtype: "syno_displayfield",
                    value: _WFT("sharing", "limit_setting_desc")
                }, {
                    xtype: "syno_numberfield",
                    name: "sharing_default_limit",
                    itemId: "sharing_default_limit",
                    fieldLabel: _T("common", "default"),
                    value: 1e3,
                    allowBlank: !1,
                    allowNegative: !1,
                    validationEvent: "keyup",
                    validateOnBlur: !0,
                    maxLength: 9
                }, {
                    xtype: "syno_button",
                    text: _T("sharewizard", "access_user"),
                    scope: this,
                    handler: this.onClickSetLimitation
                }, {
                    xtype: "hidden",
                    name: "link_limit",
                    ref: "../limitHiddenField",
                    value: ""
                }]
            }, {
                xtype: "syno_fieldset",
                itemId: "security_fieldset",
                title: _T("dsmsetting", "session_legend"),
                items: [{
                    xtype: "syno_checkbox",
                    itemId: "disable_html_checkbox",
                    name: "sharing_disable_html",
                    boxLabel: _WFT("security", "disable_html")
                }, {
                    xtype: "syno_checkbox",
                    itemId: "gofileme_protocol",
                    name: "sharing_gofile_protocol",
                    boxLabel: _WFT("sharing", "sharing_gofile_desc")
                }, {
                    xtype: "syno_displayfield",
                    value: _WFT("sharing", "sharing_gofile_note"),
                    indent: 1
                }]
            }, {
                xtype: "syno_fieldset",
                itemId: "custom_fieldset",
                title: _WFT("sharing", "custom_title"),
                items: [{
                    xtype: "syno_checkbox",
                    itemId: "enable_sharing_custom_setting",
                    name: "enable_sharing_custom_setting",
                    boxLabel: _WFT("sharing", "enable_custom_setting"),
                    listeners: {
                        check: function(e, t, i) {
                            this.getComponent("custom_fieldset").getComponent("custom_btn").setDisabled(!t)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_button",
                    itemId: "custom_btn",
                    name: "custom_btn",
                    text: _WFT("sharing", "custom_settings"),
                    handler: this.onSetCustomSettings,
                    disabled: !0,
                    scope: this
                }]
            }]
        };
        return Ext.apply(t, e || {}), t
    },
    onSetCustomSettings: function() {
        new SYNO.FileStation.SharingCustomDialog({
            owner: this.owner
        }).show()
    },
    onCheckChanged: function(e, t) {
        this.setSharingPriviledgeBtn.setDisabled(!0 !== t)
    },
    onFileRequestCheckChanged: function(e, t) {
        this.setFileRequestPriviledgeBtn.setDisabled(!0 !== t)
    },
    openSharingPrivilege: function(e) {
        var t = this,
            i = new SYNO.FileStation.SharingConfigGrid({
                owner: this,
                RELURL: this.RELURL
            }),
            o = new SYNO.SDS.ModalWindow({
                owner: t.owner,
                resizable: !0,
                minimizable: !1,
                maximizable: !1,
                closable: !0,
                layout: "fit",
                width: 600,
                height: 400,
                title: _WFT("common", "specific_user_group"),
                items: [i],
                buttons: [{
                    text: _T("common", "cancel"),
                    handler: function() {
                        o.close()
                    }
                }, {
                    btnStyle: "blue",
                    text: _T("common", "apply"),
                    handler: function() {
                        e ? t.onApplyFileRequestPriviledge(i) : t.onApplySharingPriviledge(i), o.close()
                    }
                }]
            });
        o.show(null, function() {
            e ? i.setPrivilege(this.privilege.file_request_user.getData(), this.privilege.file_request_group.getData()) : i.setPrivilege(this.privilege.sharing_user.getData(), this.privilege.sharing_group.getData()), i.load()
        }, this)
    },
    onApplySharingPriviledge: function(e) {
        var t = e.getPrivilege();
        this.privilege.sharing_user = t.user, this.privilege.sharing_group = t.group, this.setSharingHiddenField()
    },
    setSharingHiddenField: function() {
        var e = this.getPrivilege("sharing_user");
        this.sharingEnabledHiddenField.setValue(e.enable), this.sharingDisabledHiddenField.setValue(e.disable), e = this.getPrivilege("sharing_group"), this.sharingGroupEnabledHiddenField.setValue(e.enable), this.sharingGroupDisabledHiddenField.setValue(e.disable)
    },
    onApplyFileRequestPriviledge: function(e) {
        var t = e.getPrivilege();
        this.privilege.file_request_user = t.user, this.privilege.file_request_group = t.group, this.setFileRequestHiddenField()
    },
    setFileRequestHiddenField: function() {
        var e = this.getPrivilege("file_request_user");
        this.fileRequestEnabledHiddenField.setValue(e.enable), this.fileRequestDisabledHiddenField.setValue(e.disable), e = this.getPrivilege("file_request_group"), this.fileRequestGroupEnabledHiddenField.setValue(e.enable), this.fileRequestGroupDisabledHiddenField.setValue(e.disable)
    },
    onApplyLimitation: function() {
        this.limitHiddenField.setValue(Ext.encode(this.getLinkLimitation()))
    },
    onClickSetSharingPriviledge: function() {
        this.openSharingPrivilege(!1)
    },
    onClickSetFileRequestPriviledge: function() {
        this.openSharingPrivilege(!0)
    },
    onClickSetLimitation: function() {
        var e = this.getComponent("limit_fieldset").getComponent("sharing_default_limit").getValue();
        new SYNO.FileStation.SharingLimitSettingDialog({
            owner: this.owner,
            defaultLimit: e,
            settings: this.sharing_limit_setting || {},
            callback: this.onApplyLimitation.createDelegate(this)
        }).show()
    },
    setLinkLimitation: function(e) {
        this.sharing_limit_setting ? this.sharing_limit_setting.clear() : this.sharing_limit_setting = new SYNO.FileStation.WebCache, this.sharing_limit_setting.addAllData(e)
    },
    getLinkLimitation: function() {
        var e = [];
        return this.sharing_limit_setting ? (this.sharing_limit_setting.getData().each(function(t) {
            e.push(t)
        }, this), e) : e
    },
    setPrivilege: function(e, t) {
        this.privilege[e] && (this.privilege[e].clear(), this.privilege[e].addAllData(t))
    },
    getPrivilege: function(e) {
        if (!this.privilege[e]) return {
            enable: "",
            disable: ""
        };
        var t = this.privilege[e].getData(),
            i = [],
            o = [];
        return t.getCount() > 0 && Ext.each(t.items, function(e) {
            e.enabled ? i.push(e.uid || e.gid) : o.push(e.uid || e.gid)
        }, this), {
            enable: i.join(","),
            disable: o.join(",")
        }
    },
    setDefaultValues: function(e) {
        this.setLinkLimitation(e.link_limit || []), e.sharing_privilege && this.setPrivilege("sharing_user", e.sharing_privilege.items || []), e.sharing_group_privilege && this.setPrivilege("sharing_group", e.sharing_group_privilege.items || []), e.file_request_privilege && this.setPrivilege("file_request_user", e.file_request_privilege.items || []), e.file_request_group_privilege && this.setPrivilege("file_request_group", e.file_request_group_privilege.items || []), this.form.setValues({
            enabled_sharing_privilege: this.getPrivilege("sharing_user").enable,
            enabled_sharing_group_privilege: this.getPrivilege("sharing_group").enable,
            enabled_file_request_privilege: this.getPrivilege("file_request_user").enable,
            enabled_file_request_group_privilege: this.getPrivilege("file_request_group").enable,
            sharing_default_limit: e.sharing_default_limit,
            link_limit: Ext.encode(this.getLinkLimitation())
        })
    }
}), Ext.define("SYNO.FileStation.SharingLimitSettingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.panel = this.createPanel();
        var t = {
            width: 600,
            height: 440,
            resizable: !1,
            cls: "webfm-sharing-limit-dialog",
            layout: "fit",
            title: _T("sharewizard", "access_user"),
            items: this.panel,
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.onCloseClick
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onApplyHandler
            }]
        };
        this.callParent([Ext.apply(t, e)])
    },
    createPanel: function() {
        this.columnModel = this.createColModel(), this.store = this.createStore();
        var e = {
            header: !1,
            cm: this.columnModel,
            ds: this.store,
            loadMask: !0,
            enableHdMenu: !1,
            enableColumnMove: !1,
            clicksToEdit: 1,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            tbar: {
                items: ["->", new SYNO.ux.TextFilter({
                    itemId: "search",
                    iconStyle: "search",
                    queryParam: "substr",
                    emptyText: _WFT("filetable", "filetable_search"),
                    store: this.store,
                    pageSize: 50
                })]
            },
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                scrollDelay: !1,
                forceFit: !0
            }),
            bbar: new SYNO.ux.PagingToolbar({
                store: this.store,
                displayInfo: !0,
                pageSize: 50,
                showRefreshBtn: !0,
                doRefresh: function() {
                    this.store.rejectChanges(), SYNO.ux.PagingToolbar.prototype.doRefresh.call(this)
                }
            })
        };
        return new SYNO.ux.EditorGridPanel(e)
    },
    createColModel: function() {
        var e = new SYNO.ux.NumberField({
            allowBlank: !1,
            allowNegative: !1,
            validationEvent: "keyup",
            validateOnBlur: !0,
            maxValue: 2147483647
        });
        return new Ext.grid.ColumnModel([{
            header: _T("user", "user_account"),
            dataIndex: "name",
            sortable: !1,
            width: 270
        }, {
            header: _WFT("sharing", "link_limit"),
            dataIndex: "limit",
            width: 250,
            sortable: !1,
            editable: !0,
            editor: e
        }])
    },
    createStore: function() {
        var e = this;
        return new SYNO.API.JsonStore({
            autoLoad: !0,
            autoDestroy: !0,
            appWindow: !1,
            api: "SYNO.Core.User",
            method: "list",
            version: 1,
            root: "users",
            remoteSort: !0,
            fields: ["uid", "name", {
                name: "limit",
                mapping: function(t) {
                    var i = t.uid;
                    return Ext.isEmpty(e.settings.get(i)) ? e.defaultLimit : e.settings.get(i).limit
                }
            }],
            baseParams: {
                offset: 0,
                limit: 50,
                type: "all",
                additional: ["uid"]
            },
            listeners: {
                scope: this,
                beforeload: this.onBeforeStoreLoad,
                load: this.onStoreLoad
            }
        })
    },
    onBeforeStoreLoad: function() {},
    onStoreLoad: function() {},
    onApplyHandler: function() {
        var e = this.store.getModifiedRecords();
        this.settings.addAllData(Ext.pluck(e, "data")), this.callback(), this.close()
    },
    onCloseClick: function() {
        this.close()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.BasicTabPanel = Ext.extend(SYNO.ux.TabPanel, {
    constructor: function(e) {
        var t = {
            plain: !0,
            height: 300,
            deferredRender: !1,
            autoWidth: !0,
            listeners: {
                scope: this,
                activate: this.onActivate,
                tabchange: this.onTabchange,
                beforetabchange: this.onBeforeTabChange,
                beforeshow: {
                    scope: this,
                    fn: this.onBeforeshow,
                    single: !0
                }
            }
        };
        Ext.apply(t, e || {}), this.addEvents(["applyfail", "loadfail", "requestfail", "applysuccess"]), SYNO.FileStation.BasicTabPanel.superclass.constructor.call(this, t);
        var i = this.getAllForms();
        Ext.each(i, function(e, t, i) {
            e.items.each(function(e, t, i) {
                e.isFormField && e.clearInvalid && e.mon(e, "disable", e.clearInvalid, e)
            })
        }, this), this.defineBehaviors()
    },
    defineBehaviors: function() {
        this.checkTabDirty = !0, this.ERR_STR_FN = _T, this.ERR_STR_STRUCT = SYNO_WebManager_Strings
    },
    applyHandler: function(e, t) {
        this.applyAllForm()
    },
    cancelHandler: function(e, t) {},
    resetHandler: function() {
        this.resetAllForm(), this.resetAllGrid()
    },
    loadAllForm: function(e) {
        var t = Ext.applyIf({
            method: "get"
        }, e);
        if (!1 === this.onBeforeRequest(t)) return !1;
        this.sendAjaxRequest(t)
    },
    getValues: function(e) {
        var t = {};
        return SYNO.API.Form.Traverse(e, function(e, i, o) {
            var n;
            try {
                n = Ext.decode(o), (Ext.isArray(n) || Ext.isObject(n)) && (o = n)
            } catch (e) {}
            t[i] = o
        }), t
    },
    applyAllForm: function(e) {
        var t = {};
        if (this.checkTabDirty && !this.isAnyTabDirty()) return this.owner.mun(this.owner, "beforeclose", this.onBeforeDeactivate, this), this.owner.close(), !0;
        var i = Ext.applyIf({
            method: "set",
            params: {}
        }, e);
        return !1 !== this.onBeforeRequest(i) && (_S("is_admin") ? (this.items.each(function(e, i, o) {
            if (e.getForm) {
                var n = e.getForm(),
                    s = this.getValues(n.el.dom);
                Ext.apply(t, s)
            }
        }, this), this.processBandwidthApplyData(t), Ext.apply(i.params, t), void this.sendAjaxRequest(i)) : (this.owner.setStatusOK(), this.owner.mun(this.owner, "beforeclose", this.onBeforeDeactivate, this), void this.owner.close()))
    },
    resetAllForm: function() {
        var e = this.getAllForms();
        Ext.each(e, function(e, t, i) {
            e.reset()
        }, this)
    },
    resetAllGrid: function() {
        var e = this.getAllGrids();
        Ext.each(e, function(e, t, i) {
            e.getStore().rejectChanges()
        }, this)
    },
    isAnyTabDirty: function() {
        var e = this.getAllForms(),
            t = this.getAllGrids(),
            i = !1;
        return Ext.each(e, function(e, t, o) {
            if (e.isDirty()) return i = !0, !1
        }, this), Ext.each(t, function(e, t, o) {
            if (0 < e.getStore().getModifiedRecords().length) return i = !0, !1
        }, this), i
    },
    onBeforeDeactivate: function() {
        if (this.checkTabDirty) {
            if (this.isAnyTabDirty()) return this.owner.getMsgBox().confirm(this.owner.title, _T("common", "confirm_lostchange"), function(e) {
                "yes" === e ? this.applyHandler() : "leftCustom" === e && (this.resetHandler(), this.owner.close())
            }, this, {
                yes: {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    text: _T("common", "save")
                },
                cancel: !0,
                leftCustom: {
                    xtype: "syno_button",
                    text: _T("common", "dont_save"),
                    extraStyle: "syno-ux-button-dontsave"
                }
            }), !1
        } else this.resetHandler();
        return !0
    },
    getAllGrids: function() {
        var e = [];
        return this.items.each(function(t, i, o) {
            t instanceof Ext.grid.GridPanel && e.push(t)
        }, this), e
    },
    getAllForms: function() {
        var e = [];
        return this.items.each(function(t, i, o) {
            if (t.getForm) {
                var n = t.getForm();
                e.push(n)
            }
        }, this), e
    },
    sendAjaxRequest: function(e) {
        "get" === e.method ? this.owner.setStatusBusy() : this.owner.setStatusBusy({
            text: _T("common", "saving")
        }), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Settings",
            method: e.method,
            params: e.params,
            version: 1,
            scope: this,
            callback: function(e, t, i, o) {
                this.owner.clearStatusBusy(), e ? this.onRequestSuccess(t, o) : this.onRequestFailure(t, o)
            }
        })
    },
    onBeforeRequest: function(e) {
        var t = this.getAllForms(),
            i = e.method,
            o = !0;
        return "get" === i || (Ext.each(t, function(e, t, i) {
            if (!e.isValid()) return o = !1, this.owner.setStatusError({
                text: _T("common", "forminvalid"),
                clear: !0
            }), this.setActiveByForm(e, t), !1
        }, this), !!o)
    },
    onRequestSuccess: function(e, t) {
        if (!this.isDestroyed) {
            var i = t.params.method;
            if ("set" === i) return this.fireEvent("applysuccess", this, i), this.owner.setStatusOK(), this.owner.mun(this.owner, "beforeclose", this.onBeforeDeactivate, this), void this.owner.close();
            this.processBandwidthLoadData(e), this.items.each(function(t, i, o) {
                if (t.getForm) {
                    t.getForm().setValues(e)
                }
            }, this)
        }
    },
    onRequestFailure: function(e, t) {
        if (!this.isDestroyed) {
            var i = SYNO.webfm.utils.getWebAPIErr(!1, e, t);
            this.owner.getMsgBox().alert("", i, function(e) {
                this.fireEvent("applyfail", this, e, i)
            }, this)
        }
    },
    processBandwidthLoadData: function(e) {
        "bandwidth_enable" === e.bandwidth_enable ? e.FileStation_policy = "enabled" : "bandwidth_schedule" === e.bandwidth_enable ? e.FileStation_policy = "scheduled" : e.FileStation_policy = "disabled", e.schedule_plan && (e.FileStation_schedule_plan = e.schedule_plan), delete e.bandwidth_enable, delete e.schedule_plan
    },
    processBandwidthApplyData: function(e) {
        "enabled" === e.FileStation_policy ? e.bandwidth_enable = "bandwidth_enable" : "scheduled" === e.FileStation_policy ? e.bandwidth_enable = "bandwidth_schedule" : e.bandwidth_enable = "bandwidth_disable", e.FileStation_schedule_plan && (e.schedule_plan = e.FileStation_schedule_plan), delete e.FileStation_schedule_plan, delete e.FileStation_policy
    },
    onBeforeTabChange: function(e, t, i) {
        if (!0 === t.disabled) return !1;
        var o = e.getFooterToolbar();
        return !o || (t instanceof Ext.form.FormPanel ? o.show() : o.hide(), !0)
    },
    setActiveByForm: function(e, t) {
        var i = this.getAllForms();
        Ext.isNumber(t) && this.items.getCount() === i.length ? this.setActiveTab(t) : this.items.forEach(function(t, i, o) {
            if (t.getForm && t.getForm() === e) return this.setActiveTab(i), !1
        }, this)
    },
    addDeactivateCheck: function(e) {
        e.mon(e, "beforeclose", this.onBeforeDeactivate, this)
    },
    onActivate: function() {},
    onBeforeshow: function() {},
    onTabchange: function() {
        this.owner.clearStatus()
    }
}), Ext.ns("SYNO.FileStation.SettingDialog"), SYNO.FileStation.SettingTabpanel = Ext.extend(SYNO.FileStation.BasicTabPanel, {
    defineBehaviors: function() {
        SYNO.FileStation.SettingTabpanel.superclass.defineBehaviors.apply(this, arguments), this.mon(this, "applyfail", this.onApplyRequestFail, this), this.mon(this, "applysuccess", this.onApplyRequestSuccess)
    },
    onBeforeRequest: function(e) {
        if ("set" == e.method) {
            this.isMountFormDirty = this.getComponent("mount_config_form").getForm().isDirty();
            if (this.getComponent("general").getForm().findField("enable_drag_to_desktop").isDirty()) {
                var t = this.getComponent("general").getForm().findField("enable_drag_to_desktop").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enabledragtodesktop", t), Ext.isChrome && SYNO.SDS.DragToDesktop[t ? "init" : "destroy"]()
            }
            if (this.getComponent("general").getForm().findField("enable_auto_overwrite").isDirty()) {
                var i = this.getComponent("general").getForm().findField("enable_auto_overwrite").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite", i)
            }
            if (this.getComponent("general").getForm().findField("enable_7z_extract").isDirty()) {
                var o = this.getComponent("general").getForm().findField("enable_7z_extract").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable7zextract", o)
            }
            var n = this.getComponent("general").getForm().findField("codepage"),
                s = n.getValue();
            n.isDirty() && SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "codepage", s);
            if (this.getComponent("security_config_form").getForm().findField("disable_html").isDirty()) {
                var r = this.getComponent("security_config_form").getForm().findField("disable_html").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "disablehtml", r)
            }
            if (this.getComponent("general").getForm().findField("enable_cross_browser_dd").isDirty()) {
                var a = this.getComponent("general").getForm().findField("enable_cross_browser_dd").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable_cross_browser_dd", a)
            }
            if (this.getComponent("general").getForm().findField("enable_smart_mvcp").isDirty()) {
                var l = this.getComponent("general").getForm().findField("enable_smart_mvcp").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp", l)
            }
            if (this.getComponent("general").getForm().findField("smart_mvcp_overwrite").isDirty()) {
                var h = this.getComponent("general").getForm().findField("smart_mvcp_overwrite").getValue();
                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "smartmvcpoverwrite", h)
            }
        }
        return SYNO.FileStation.SettingTabpanel.superclass.onBeforeRequest.apply(this, arguments)
    },
    onApplyRequestSuccess: function() {
        this.isMountFormDirty && this.owner.webfm.reloadTree()
    },
    onRequestSuccess: function(e, t) {
        SYNO.FileStation.SettingTabpanel.superclass.onRequestSuccess.apply(this, arguments), this.isDestroyed || (Ext.getCmp(this.getComponent("general").logBtnId).setDisabled(!e.transfer_log_enable), this.getComponent("sharing_config_form").setDefaultValues(e)), _S("is_admin") && !this.isDestroyed && (this.findWindow().setStatusBusy({
            text: _T("common", "loading")
        }), this.sendWebAPI({
            api: "SYNO.FileStation.VFS.User",
            method: "get",
            version: 1,
            params: {
                content: "user_enabled_type"
            },
            scope: this,
            callback: function(e, t, i, o) {
                if (this.findWindow().clearStatusBusy(), !e) return void this.findWindow().getMsgBox().alert(SYNO.webfm.utils.getWebAPIErr(!1, t));
                this.getComponent("mount_config_form").getForm().setValues({
                    vfs_allow: t.user_enabled_type
                })
            }
        }))
    },
    onApplyRequestFail: function(e, t, i) {
        _S("standalone") || i !== _WFT("mount", "config_remote_warning") || "ok" === t && (SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
            fn: "SYNO.SDS.AdminCenter.User.Main",
            userHomeDialog: !0
        }), this.findWindow().clearStatusBusy())
    }
}), SYNO.FileStation.GenSetting = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.FileStation.GenSetting.superclass.constructor.call(this, t), this.mon(this, "afterlayout", function() {
            new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_smart_mvcp", ["smart_mvcp_desc", "smart_mvcp_radio"])
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        var t = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite"),
            i = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp"),
            o = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable_cross_browser_dd"),
            n = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "smartmvcpoverwrite"),
            s = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enabledragtodesktop"),
            r = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable7zextract"),
            a = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "codepage") || e.owner.webfm.systemCodepage,
            l = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: SYNO.webfm.utils.getSupportedLanguage()
            }),
            h = Ext.isIE || Ext.isIEQuirks || Ext.isIE6 || Ext.isIE7 || Ext.isIE8 || Ext.isIE9 || Ext.isIE9m || Ext.isIE9p || Ext.isIE10 || Ext.isIE10p || Ext.isIE10Touch || Ext.isIE11 || Ext.isIE12,
            c = {
                border: !1,
                trackResetOnLoad: !0,
                height: 530,
                labelWidth: 180,
                items: [{
                    xtype: "syno_fieldset",
                    title: _T("log", "log_filebrowser_xfer"),
                    defaults: {
                        hidden: !_S("is_admin")
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        value: _T("service", "service_file_transfer_log_desc")
                    }, {
                        xtype: "syno_checkbox",
                        name: "transfer_log_enable",
                        boxLabel: _T("service", "service_file_browser_log"),
                        listeners: {
                            check: {
                                scope: this,
                                fn: function(e, t) {
                                    var i = this.getForm();
                                    t && "yes" === _D("usbstation") && "false" === i.findField("runpgsql").getValue() && (i.findField("transfer_log_enable").setValue(!1), this.findAppWindow().getMsgBox().confirm(_T("helptoc", "settings"), _T("metadata", "metadata_warning_required"), _S("standalone") ? Ext.emptyFn : function(e) {
                                        "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                            fn: "SYNO.SDS.AdminCenter.SystemDatabase.Main"
                                        })
                                    }, this))
                                }
                            }
                        }
                    }, {
                        xtype: "syno_button",
                        id: this.logBtnId = Ext.id(),
                        tabIndex: -1,
                        indent: 1,
                        text: _T("log", "log_subtitle"),
                        hidden: _S("standalone"),
                        handler: function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.LogCenter.BuiltIn", {
                                logType: "fileTransfer",
                                protocol: "dsmfmxfer"
                            })
                        }
                    }, {
                        xtype: "syno_checkbox",
                        name: "enable_auto_overwrite",
                        hidden: !1,
                        boxLabel: _WFT("filetable", "upload_copy_auto_overwrite"),
                        checked: t
                    }, {
                        xtype: "syno_checkbox",
                        name: "enable_cross_browser_dd",
                        disabled: h,
                        hidden: !1,
                        boxLabel: _WFT("filetable", "enable_cross_browser_dd"),
                        checked: o
                    }, {
                        xtype: "syno_checkbox",
                        itemId: "enable_smart_mvcp",
                        name: "enable_smart_mvcp",
                        hidden: !1,
                        boxLabel: _WFT("filetable", "mvcp_enable_smart_label"),
                        checked: i,
                        listeners: {
                            check: function(e, t) {
                                var i = this.getForm().findField("smart_mvcp_overwrite"),
                                    o = this.getForm().findField("smart_mvcp_skip");
                                !t || i.getValue() || o.getValue() || i.setValue(!0)
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_displayfield",
                        name: "smart_mvcp_desc",
                        value: _WFT("filetable", "mvcp_enable_desc"),
                        indent: 1
                    }, {
                        xtype: "syno_radio",
                        itemId: "smart_mvcp_overwrite",
                        name: "smart_mvcp_radio",
                        hidden: !1,
                        boxLabel: _WFT("filetable", "filetable_overwrite"),
                        checked: i && n,
                        indent: 1
                    }, {
                        xtype: "syno_radio",
                        itemId: "smart_mvcp_skip",
                        name: "smart_mvcp_radio",
                        hidden: !1,
                        boxLabel: _WFT("filetable", "filetable_skip"),
                        checked: i && !n,
                        indent: 1
                    }, {
                        xtype: "syno_checkbox",
                        name: "enable_drag_to_desktop",
                        hidden: !0,
                        boxLabel: _WFT("filetable", "drag_file_to_local_desktop"),
                        checked: s
                    }, {
                        xtype: "syno_checkbox",
                        hidden: !0,
                        name: "enable_7z_extract",
                        boxLabel: _T("extract", "7z_extract"),
                        checked: r
                    }, {
                        xtype: "syno_checkbox",
                        name: "use_unix_default_perm",
                        boxLabel: _T("common", "apply_default_umask"),
                        checked: !1
                    }, {
                        xtype: "syno_checkbox",
                        name: "enable_list_usergrp",
                        boxLabel: _WFT("filetable", "enable_list_usergrp"),
                        checked: !1
                    }, {
                        xtype: "hidden",
                        name: "runpgsql"
                    }]
                }, {
                    xtype: "syno_fieldset",
                    title: _WFT("common", "lang_codepage"),
                    items: [{
                        xtype: "syno_displayfield",
                        value: _WFT("compress", "download_compress_codepage_desc")
                    }, {
                        width: 200,
                        xtype: "syno_combobox",
                        fieldLabel: _WFT("common", "lang_codepage"),
                        hiddenName: "codepage",
                        store: l,
                        displayField: "display",
                        valueField: "value",
                        triggerAction: "all",
                        editable: !1,
                        value: a,
                        mode: "local"
                    }]
                }]
            };
        return Ext.apply(c, e || {}), c
    }
}), Ext.define("SYNO.FileStation.SecurityConfig", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(this, "afterlayout", function() {
            SYNO.ux.AddTip(this.getComponent("security_fieldset").getComponent("disable_html_checkbox").getEl(), _WFT("security", "disable_html_info"))
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        var t = !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "disablehtml"),
            i = {
                border: !1,
                trackResetOnLoad: !0,
                height: 430,
                labelWidth: 180,
                items: {
                    xtype: "syno_fieldset",
                    itemId: "security_fieldset",
                    title: _T("dsmsetting", "session_legend"),
                    items: [{
                        xtype: "syno_checkbox",
                        itemId: "disable_html_checkbox",
                        name: "disable_html",
                        boxLabel: _WFT("security", "disable_html"),
                        checked: t
                    }, {
                        xtype: "syno_displayfield",
                        value: _WFT("security", "disable_html_desc"),
                        indent: 1
                    }]
                }
            };
        return SYNO.LayoutConfig.fill(Ext.apply(i, e || {})), i
    }
}), SYNO.FileStation.BandwidthConfig = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.FileStation.BandwidthConfig.superclass.constructor.call(this, t), this.defineBehaviors()
    },
    getScheduleForm: function() {
        return this.getForm()
    },
    fillConfig: function(e) {
        var t = SYNO.SDS.BandwidthControl.SchedulePanelConfig(this, "FileStation"),
            i = {
                border: !1,
                trackResetOnLoad: !0,
                height: 430,
                labelWidth: 180,
                items: {
                    xtype: "syno_fieldset",
                    title: _T("bandwidth", "bandwidth_tab_title"),
                    items: t.items,
                    listeners: t.listeners
                }
            };
        return SYNO.LayoutConfig.fill(Ext.apply(i, e || {})), i
    },
    defineBehaviors: function() {}
}), SYNO.FileStation.SettingDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    constructor: function(e) {
        Ext.copyTo(this, e, "owner,webfm,RELURL");
        var t = this.fillConfig(e);
        SYNO.FileStation.SettingDialog.superclass.constructor.call(this, t), this.defineBehaviors()
    },
    defineBehaviors: function() {
        ("yes" !== _D("supportmount") && !0 !== this.webfm.supportVFS || !0 !== _S("is_admin")) && this.getTabPanel().hideTabStripItem("mount_config_form"), !0 !== _S("is_admin") && (this.getTabPanel().hideTabStripItem("sharing_config_form"), this.getTabPanel().hideTabStripItem("bandwidth_config_form")), this.getTabPanel().addDeactivateCheck(this)
    },
    fillConfig: function(e) {
        var t = {
            owner: this.owner,
            width: 820,
            height: 580,
            minWidth: 200,
            minHeight: 200,
            constrainHeader: !0,
            title: _WFT("mount", "setting"),
            layout: "fit",
            items: [this.getTabPanel()],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                btnStyle: "blue",
                text: _T("common", "apply"),
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : void 0,
                handler: this.onApplyHandler
            }],
            keys: [{
                key: 27,
                scope: this,
                handler: this.close
            }],
            listeners: {
                scope: this,
                beforeshow: {
                    fn: this.onBeforeShow,
                    scope: this,
                    single: !0
                }
            }
        };
        return Ext.apply(t, e), t
    },
    onApplyHandler: function() {
        return _S("demo_mode") ? void this.getMsgBox().alert(_WFT("common", "options"), _JSLIBSTR("uicommon", "error_demo")) : _S("is_admin") && this.getTabPanel().getComponent("mount_config_form").getForm().isDirty() ? (this.setStatusBusy({
            text: _T("common", "saving")
        }), void this.sendWebAPI({
            api: "SYNO.FileStation.VFS.User",
            method: "set",
            timeout: 6e5,
            version: 1,
            params: {
                settings: {
                    user_enabled_type: this.getTabPanel().getComponent("mount_config_form").getForm().findField("vfs_allow").getGroupValue()
                }
            },
            scope: this,
            callback: function(e, t, i, o) {
                if (this.clearStatusBusy(), !e) return void this.getMsgBox().alert(_WFT("common", "options"), SYNO.webfm.utils.getWebAPIErr(!1, t));
                this.getTabPanel().applyHandler()
            }
        })) : void this.getTabPanel().applyHandler()
    },
    onBeforeShow: function() {
        this.getTabPanel().loadAllForm()
    },
    getTabPanel: function() {
        if (!this.tabPanel) {
            var e = new SYNO.FileStation.GenSetting({
                    owner: this,
                    itemId: "general",
                    title: _T("common", "general")
                }),
                t = new SYNO.FileStation.MountConfig({
                    owner: this,
                    itemId: "mount_config_form",
                    title: "yes" === _D("supportmount") ? _WFT("vfs", "mount_connections") : _WFT("vfs", "remote_connect")
                }),
                i = new SYNO.FileStation.SharingConfig({
                    owner: this,
                    itemId: "sharing_config_form",
                    title: _WFT("sharing", "sharing"),
                    RELURL: this.RELURL
                }),
                o = new SYNO.FileStation.BandwidthConfig({
                    owner: this,
                    itemId: "bandwidth_config_form",
                    title: _T("bandwidth", "bandwidth_tab_title")
                }),
                n = new SYNO.FileStation.SecurityConfig({
                    owner: this,
                    itemId: "security_config_form",
                    title: _T("dsmsetting", "session_legend")
                }),
                s = {
                    owner: this,
                    height: 550,
                    layoutOnTabChange: !0,
                    activeTab: 0,
                    items: [e, t, i, o, n]
                };
            this.tabPanel = new SYNO.FileStation.SettingTabpanel(s)
        }
        return this.tabPanel
    }
}), Ext.namespace("SYNO.FileStation"), Ext.define("SYNO.FileStation.MVCPAskDialogDataView", {
    extend: "SYNO.ux.FleXcroll.DataView",
    constructor: function() {
        this.addEvents("refresh"), this.callParent(arguments)
    },
    refresh: function() {
        var e = this.callParent(arguments);
        return this.fireEvent("refresh", this), e
    }
}), Ext.define("SYNO.FileStation.MVCPAskDialog", {
    extend: "SYNO.SDS.ModalWindow",
    MVCP_TYPE: {
        OVERWRITE: 0,
        SKIP: 1,
        RENAME: 2
    },
    constructor: function(e) {
        this.fileIndex = 0, this.RELURL = "modules/FileBrowser/", this.overwriteArray = [];
        var t = this.fillConfig(e);
        this.callParent([t]), this.addEvents({
            onAskDone: !0
        })
    },
    fillConfig: function(e) {
        Ext.apply(this, e || {});
        var t = String.format(_WFT("filetable", "filetable_mvcp_replace"), _WFT("filetable", this.action));
        return {
            owner: this.owner,
            width: 480,
            height: this.showRenameOption ? 570 : 500,
            shadow: !0,
            collapsible: !1,
            autoScroll: !1,
            resizable: !1,
            constrainHeader: !0,
            plain: !0,
            title: t,
            layout: "fit",
            items: this.initPanel(),
            buttons: [new SYNO.ux.Button({
                text: _WFT("common", "cancel"),
                scope: this,
                handler: this.close
            })]
        }
    },
    createDataview: function() {
        var e = new Ext.XTemplate(['<tpl for=".">', '<div class="webfm-mvcp-dialog-template" style="height=100px">', '<div class="webfm-mvcp-dialog-rec-title"> {action} </div>', '<div class="webfm-mvcp-dialog-rec-desc webfm-mvcp-dialog-template-padding"> {desc} </div>', '<tpl if="is_rename == false">', '<table class="webfm-mvcp-dialog-template-padding"><tbody>', "<tr>", "<td>", '<div style="height:64px;width:64px;margin-right:5px">', '<img src="{img_src}" style="width:64px; height:64px;"></img>', "</div>", "</td>", "<td>", "<div>", '<div class="webfm-mvcp-dialog-text-overflow" style="line-height:16px;font-weight:bold;"> {filename} </div>', '<div class="webfm-mvcp-dialog-text-overflow" style="line-height:16px;"> Path: {path} </div>', "<div class={sizecss}> Size: {filesize} </div>", '<div style="line-height:16px;"> Date modified: {mt}</div>', "</div>", "</td>", "</tr>", "</tbody></table>", "</tpl>", "</div>", "</tpl>"].join("")),
            t = this.getDataViewStoreData(0),
            i = new Ext.data.JsonStore({
                fields: ["action", "desc", "filename", "path", "filesize", "img_src", "mt", "sizecss", "is_rename"],
                data: t
            }),
            o = new SYNO.FileStation.MVCPAskDialogDataView({
                autoFlexcroll: !1,
                store: i,
                tpl: e,
                singleSelect: !0,
                itemSelector: "div.webfm-mvcp-dialog-template",
                overClass: "webfm-mvcp-dialog-template-over",
                listeners: {
                    click: this.onSelect,
                    refresh: this.onDataViewRefresh,
                    scope: this
                }
            });
        return this.store = i, this.dataview = o, o
    },
    initPanel: function() {
        var e = this.conflictSrcFiles.length - 1,
            t = {
                trackResetOnLoad: !0,
                border: !1,
                autoScroll: !0,
                items: [{
                    xtype: "syno_displayfield",
                    cls: "webfm-mvcp-dialog-title",
                    htmlEncode: !1,
                    value: _WFT("filetable", "filetable_mvcp_dialog_desc")
                }, this.createDataview(), {
                    xtype: "syno_checkbox",
                    itemId: "apply_same_checkbox",
                    ctCls: "webfm-mvcp-dialog-checkbox",
                    boxLabel: String.format(_WFT("filetable", "mvcp_apply_label"), e),
                    hidden: 0 === e
                }]
            };
        return this.panel = new SYNO.ux.FormPanel(t), this.panel
    },
    getDataViewStoreData: function(e) {
        var t, i, o, n = [],
            s = this.conflictSrcFiles[e],
            r = this.conflictDestFiles[e];
        if (t = this.fillRecData(s), t.action = String.format(_WFT("filetable", "filetable_mvcp_replace"), _WFT("filetable", this.action)), t.desc = _WFT("filetable", "filetable_replace_desc"), n.push(t), i = this.fillRecData(r), i.action = _WFT("filetable", "filetable_skip"), i.desc = _WFT("filetable", "filetable_skip_desc"), n.push(i), this.showRenameOption) {
            var a = r.numeric_filename,
                l = a.search(/ \([\d]*\)(.[^.]*)?$/),
                h = a.substr(0, l),
                c = a.substr(l + 1),
                d = String.format(['<span class="webfm-mvcp-dialog-rename-filename normal-font">', '<span class="webfm-mvcp-dialog-rename-filename-head">"{0}</span>', '<span class="webfm-mvcp-dialog-rename-filename-tail">&nbsp;{1}"</span>', "</span>"].join(""), h, c);
            o = {
                is_rename: !0,
                action: String.format(_WFT("filetable", "keep_both_file"), _WFT("filetable", this.action)),
                desc: String.format(_WFT("filetable", "filetable_rename_desc_" + ("filetable_move" === this.action ? "move" : "copy")), d)
            }, n.push(o)
        }
        return n
    },
    onDataViewRefresh: function() {
        if (this.showRenameOption) {
            var e = this.dataview.getTemplateTarget().child(".webfm-mvcp-dialog-rename-filename");
            if (e) {
                var t = e.child(".webfm-mvcp-dialog-rename-filename-head"),
                    i = e.child(".webfm-mvcp-dialog-rename-filename-tail");
                if (t && i) {
                    var o = parseInt(e.getStyle("max-width"), 10),
                        n = t.getWidth(),
                        s = i.getWidth();
                    n + s >= o && (i.dom.innerHTML = i.dom.innerHTML.substr(6), s = i.getWidth(), n + s < o && (i.dom.innerHTML = "&nbsp;" + i.dom.innerHTML, s = i.getWidth()), t.setStyle("max-width", String.format("{0}px", Math.max(o - s, 80))))
                }
            }
        }
    },
    fillRecData: function(e) {
        var t, i, o, n, s, r;
        return t = Ext.copyTo({}, e, "filename, path, filesize, isdir, mt"), e && e.filename && (s = e.filename.substr(e.filename.lastIndexOf(".") + 1).toLowerCase()), r = "misc.png", t.sizecss = "webfm-mvcp-dialog-file", e && e.isdir ? (r = "folder.png", t.sizecss = "webfm-mvcp-dialog-folder") : -1 !== SYNO.webfm.utils.icon_type.indexOf(s) && (r = s + ".png"), i = "webman/" + this.RELURL + "images/1x/files_ext_256/" + r + "?v=" + _S("version"), o = Ext.util.Format.fileSize(e.filesize), n = SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt), {
            type: "datetimesec"
        }), t.filesize = o, t.mt = n, t.img_src = i, t.filename = Ext.util.Format.htmlEncode(t.filename), t.path = Ext.util.Format.htmlEncode(t.path), t
    },
    updatePanel: function() {
        var e = this.panel.getComponent("apply_same_checkbox"),
            t = this.conflictSrcFiles.length - this.fileIndex - 1;
        0 === t ? e.boxlabelEl.update(_WFT("filetable", "mvcp_apply_all_label")) : e.boxlabelEl.update(String.format(_WFT("filetable", "mvcp_apply_label"), t)), this.store.loadData(this.getDataViewStoreData(this.fileIndex), !1), this.doLayout()
    },
    onSelect: function(e, t, i, o) {
        this.onConfirm(t)
    },
    updateOverwirteArray: function(e) {
        var t = 0,
            i = this.panel.getComponent("apply_same_checkbox");
        if (this.overwriteArray.push({
                path: this.conflictSrcFiles[this.fileIndex].path,
                blOverwrite: e !== this.MVCP_TYPE.SKIP,
                blRename: e === this.MVCP_TYPE.RENAME
            }), this.fileIndex++, i.getValue()) {
            for (t = this.fileIndex; t < this.conflictSrcFiles.length; t++) this.overwriteArray.push({
                path: this.conflictSrcFiles[t].path,
                blOverwrite: e !== this.MVCP_TYPE.SKIP,
                blRename: e === this.MVCP_TYPE.RENAME
            });
            this.fileIndex = t
        }
    },
    onConfirm: function(e) {
        this.updateOverwirteArray(e), this.fileIndex === this.conflictSrcFiles.length ? (this.fireEvent("onAskDone", this.overwriteArray), this.close()) : this.updatePanel()
    }
}), Ext.define("SYNO.FileStation.DragDropHintDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t]), this.addEvents({
            onAskDone: !0
        }), this.mon(this, "afterlayout", function() {
            new SYNO.ux.Utils.EnableCheckGroup(this.panel.getForm(), "enable_smart_mvcp", ["smart_mvcp_desc", "smart_mvcp_radio"])
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        return Ext.apply(this, e || {}), {
            owner: this.owner,
            resizable: !1,
            minimizable: !1,
            maximizable: !1,
            closable: !0,
            width: 600,
            height: 300,
            shadow: !0,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            title: _WFT("filetable", "mvcp_enable_title"),
            layout: "fit",
            items: this.initPanel(),
            buttons: [new SYNO.ux.Button({
                text: _WFT("common", "skip"),
                scope: this,
                handler: this.onBeforeClose
            }), new SYNO.ux.Button({
                text: _WFT("common", "commit"),
                btnStyle: "blue",
                scope: this,
                handler: this.onConfirm
            })]
        }
    },
    initPanel: function() {
        var e = {
            trackResetOnLoad: !0,
            border: !1,
            autoScroll: !0,
            items: [{
                xtype: "syno_checkbox",
                itemId: "enable_smart_mvcp",
                name: "enable_smart_mvcp",
                hidden: !1,
                boxLabel: _WFT("filetable", "mvcp_enable_smart_label"),
                checked: !1,
                listeners: {
                    check: function(e, t) {
                        var i = this.panel.getForm().findField("smart_mvcp_overwrite"),
                            o = this.panel.getForm().findField("smart_mvcp_skip");
                        !t || i.getValue() || o.getValue() || i.setValue(!0)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                name: "smart_mvcp_desc",
                value: _WFT("filetable", "mvcp_enable_desc"),
                indent: 1
            }, {
                xtype: "syno_radio",
                itemId: "smart_mvcp_overwrite",
                name: "smart_mvcp_radio",
                hidden: !1,
                boxLabel: _WFT("filetable", "filetable_overwrite"),
                indent: 1
            }, {
                xtype: "syno_radio",
                itemId: "smart_mvcp_skip",
                name: "smart_mvcp_radio",
                hidden: !1,
                boxLabel: _WFT("filetable", "filetable_skip"),
                indent: 1
            }, {
                xtype: "syno_displayfield",
                value: _WFT("filetable", "mvcp_hint_desc")
            }]
        };
        return this.panel = new SYNO.ux.FormPanel(e), this.panel
    },
    onConfirm: function() {
        this.blEnableSmartMVCP = this.panel.getForm().findField("enable_smart_mvcp").getValue();
        var e = this.panel.getForm().findField("smart_mvcp_overwrite").getValue() && this.blEnableSmartMVCP;
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp", this.blEnableSmartMVCP), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "smartmvcpoverwrite", e), this.close()
    },
    onBeforeClose: function() {
        this.blEnableSmartMVCP = !1, this.close()
    },
    onClose: function() {
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd", !1), this.fireEvent("onAskDone", this.blEnableSmartMVCP)
    }
}), SYNO.webfm.utils.Download = Ext.extend(Ext.util.Observable, {
    constructor: function(e) {
        Ext.apply(this, e || {}), SYNO.webfm.utils.Download.superclass.constructor.call(this), this.DownloadCGI = "fbdownload"
    },
    DirectDownload: function(e, t, i, o) {
        Ext.isArray(t) || (t = [t]);
        var n, s, r = SYNO.webfm.utils.replaceDLNameSpecChars(e);
        if (Ext.isDefined(o) ? ((r.length <= o.length || -1 === r.toLowerCase().indexOf("." + o, r.length - o.length - 1)) && (r += "." + o), n = "fbgdrivedownload", s = String.format(n + '/{0}?dlink="{1}"', encodeURIComponent(r), SYNO.webfm.utils.bin2hex(t[0])), s += "&noCache=" + (new Date).getTime() + "&mode=download&stdhtml=false&format=" + o) : (n = "fbdownload", s = String.format(n + '/{0}?dlink="{1}"', encodeURIComponent(r), SYNO.webfm.utils.bin2hex(t[0])), s += "&noCache=" + (new Date).getTime() + "&mode=download&stdhtml=false"), s = Ext.urlAppend(s), i.get("isdir") || "exe" !== i.get("type").toLowerCase() || (s += "&f=.exe"), (Ext.isIE || Ext.isModernIE) && s.length >= 2048 - (window.location.protocol + "//" + window.location.hostname + ":" + window.location.port).length) return void this.Download(t, e);
        SYNO.SDS.Utils.IFrame.request(s, this.DownloadCallBack, this)
    },
    Download: function(e, t) {
        var i = SYNO.SDS.Session.SynoToken ? "?SynoToken=" + SYNO.SDS.Session.SynoToken : "",
            o = this.DownloadCGI + "/" + encodeURIComponent(SYNO.webfm.utils.replaceDLNameSpecChars(t)) + i;
        Ext.isArray(e) || (e = [e]), SYNO.SDS.Utils.IFrame.request(o, this.DownloadCallBack, this, {
            api: "SYNO.FileStation.Download",
            method: "download",
            version: 2,
            mode: "download",
            stdhtml: !1,
            path: Ext.encode(e),
            dlname: Ext.encode(t)
        })
    },
    DownloadCallBack: function(e, t, i, o) {
        if (!1 === i && "timeout" !== e) return !(!0 !== SYNO.API.CheckResponse(i, o) && !this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), SYNO.webfm.utils.getWebAPIErr(!1, o))) || void 0
    }
});
var SYNOFileStationFileAction = function e(t) {
    Ext.apply(this, t || {}), e.superclass.constructor.call(this), this.UploadCGI = SYNO.API.currentManager.getBaseURL("SYNO.FileStation.FormUpload", "start", 2), this.downloadAction = new SYNO.webfm.utils.Download(t), this.addEvents({
        setHighlightEntry: !0,
        refreshTreeNode: !0
    })
};
Ext.extend(SYNOFileStationFileAction, Ext.util.Observable, {
    genErrItems: function(e) {
        var t = "",
            i = "",
            o = 0;
        e.errno && (t += _WFT(e.errno.section, e.errno.key) + "<br>");
        var n, s, r;
        if (e.errItems && 0 < e.errItems.length) {
            for (r = e.errItems.length > 15 ? 15 : e.errItems.length, t += _WFT("error", "error_files"), o = 0; o < r; o++) n = e.errItems[o].name, s = n.lastIndexOf("/"), s = -1 == s ? 1 : s + 1, n = n.substr(s), n.length > 40 && (n = n.substr(0, 37) + "..."), t += "<br>" + Ext.util.Format.htmlEncode(n), t += "<br>" + _WFT(e.errItems[o].section, e.errItems[o].key);
            r < e.errItems.length && (t += "<br>...")
        }
        return i = t.replace(/<br>/gi, " "), {
            text: i,
            qtip: t
        }
    },
    showErrItems: function(e, t, i, o) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide();
        var n = "",
            s = 0;
        i.errno && (n += SYNO.webfm.utils.getWebAPIErrStr(t, i, o) + "<br>");
        var r, a;
        if (i.errItems && 0 < i.errItems.length) {
            for (a = i.errItems.length > 15 ? 15 : i.errItems.length, n += _WFT("error", "error_files") + _WFT("common", "colon"), s = 0; s < a; s++) r = i.errItems[s].name, r.length > 50 && (r = r.substr(0, 47) + "..."), n += "<br>" + Ext.util.Format.htmlEncode(r), n += "&nbsp;(" + SYNO.webfm.utils.getWebAPIErrStr(t, i.errItems[s], o) + ")";
            a < i.errItems.length && (n += "<br>...")
        }
        "" !== n && this.showMsg(e, n)
    },
    showErrStatus: function(e) {
        var t = "",
            i = 0;
        e.errno && (t += _WFT(e.errno.section, e.errno.key) + "<br>");
        var o, n, s;
        if (e.errItems && 0 < e.errItems.length) {
            for (s = e.errItems.length > 15 ? 15 : e.errItems.length, t += _WFT("error", "error_files"), i = 0; i < s; i++) o = e.errItems[i].name, n = o.lastIndexOf("/"), n = -1 == n ? 1 : n + 1, o = o.substr(n), o.length > 40 && (o = o.substr(0, 37) + "..."), t += "<br>" + Ext.util.Format.htmlEncode(o), t += "<br>" + _WFT(e.errItems[i].section, e.errItems[i].key);
            s < e.errItems.length && (t += "<br>...")
        }
        return t
    },
    MVCP: function(e, t, i, o, n) {
        if (n = n || this.webfm.getCurrentSource(), "copy" == t || "move" == t) {
            var s = function() {
                SYNO.FileStation.Clipboard.set(t, e, {
                    source: n,
                    uid: i,
                    gid: o
                })
            };
            SYNO.webfm.utils.isLocalSource(n) ? s.call(this) : SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, t, e, {
                fn: s,
                scope: this
            })
        }
    },
    MVCPTo: function(e, t, i, o, n, s, r) {
        SYNO.webfm.utils.isLocalSource(s) ? this.doMVCPTo(e, t, i, o, n, s, r) : SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, t, e, {
            fn: function() {
                this.doMVCPTo(e, t, i, o, n, s, r)
            },
            scope: this
        })
    },
    doMVCPTo: function(e, t, i, o, n, s, r) {
        if ("copy" == t || "move" == t) {
            var a = SYNO.webfm.utils.isLocalSource(s),
                l = [];
            if (a) return e.forEach(function(e) {
                l.push(e.data)
            }), void AppletProgram.showFileDialog(this.webfm, {
                action: t,
                files: l,
                overwrite: r
            });
            this.MVCPTreeDialog && !this.MVCPTreeDialog.isDestroyed || (this.MVCPTreeDialog = new SYNO.FileStation.TreeDialog({
                RELURL: this.RELURL,
                blDynamicForm: !0,
                blVFSFolder: !0,
                owner: this.owner,
                webfm: this.webfm
            }));
            var h = this.MVCPTreeDialog,
                c = {
                    that: this,
                    rec: e,
                    action: t,
                    uid: i,
                    gid: o,
                    win: h
                };
            h.mon(h, "beforesubmit", this.onBeforeMVCPToSubmit, c), h.mon(h, "callback", this.onMVCPHide, {
                that: this,
                act: t,
                scope: c,
                rec: e,
                win: h,
                webfm: this.webfm
            }, {
                single: !0
            });
            var d = n.text;
            h.load(d, !0, i, o)
        }
    },
    onBeforeMVCPToSubmit: function(e) {
        var t = new Ext.data.Record({
                isdir: !0,
                file_id: e.path,
                real_path: e.real_path,
                right: e.folderRight
            }),
            i = this.that;
        return i.onBeforeMVCPSubmit.call(i, {
            recs: this.rec,
            action: this.action
        }, t, SYNO.webfm.utils.isLocalSource(i.webfm.getCurrentSource()), this.win)
    },
    onMVCPHide: function() {
        var e = this.that,
            t = this.act,
            i = this.rec,
            o = {},
            n = this.win;
        if (n.mun(n, "beforesubmit", e.onBeforeMVCPToSubmit, this.scope), o = n.getParameters(), !o.fdrName || !t) return void e.resetCTNode();
        e.onMVCPSend(t, i, o.fdrName, o.blOverWrite, e.webfm.getCurrentSource()), e.resetCTNode()
    },
    onBeforeMVCPSubmit: function(e, t, i, o) {
        var n = e.recs,
            s = e.action;
        o = o || this.webfm.owner;
        var r = i && Ext.isWindows ? "\\" : "/",
            a = t.get("isdir") ? t.get("real_path") : SYNO.webfm.utils.getParentDirArr(t.get("real_path"), r)[0],
            l = "copy" == s ? _WFT("filetable", "filetable_copy") : _WFT("filetable", "filetable_move");
        if (o) {
            var h;
            for (h = 0; h < n.length; h++) {
                var c = n[h].get("real_path");
                if (SYNO.webfm.utils.isConflictTargetPath(c, a, r)) return o.getMsgBox().alert(l, _WFT("error", "error_select_conflict")), !1
            }
            if (i || !0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
            if (SYNO.webfm.VFS.isVFSPath(t.get("file_id"))) return !0;
            var d = SYNO.webfm.utils.getShareRightBySPath(this.webfm.dirTree, t.get("file_id"));
            if (!SYNO.webfm.utils.checkShareRight(d, SYNO.webfm.utils.RW)) return o.getMsgBox().alert(l, _WFT("error", "error_privilege_not_enough")), !1;
            if (SYNO.webfm.utils.isShareByPath(t.get("file_id"))) return !0;
            var u, f, m = 0;
            for (h = 0; h < n.length; h++)
                if (n = n[h], !0 === n.get("isdir")) {
                    if (0 === m) m = 2;
                    else if (1 === m) {
                        m = 3;
                        break
                    }
                } else if (0 === m) m = 1;
            else if (2 === m) {
                m = 3;
                break
            }
            switch (m) {
                case 1:
                    f = SYNO.webfm.utils.ReqPrivilege.DestFolder.Copy;
                    break;
                case 2:
                    f = SYNO.webfm.utils.ReqPrivilege.DestFolder.CopyDir;
                    break;
                default:
                    f = SYNO.webfm.utils.ReqPrivilege.DestFolder.Copy | SYNO.webfm.utils.ReqPrivilege.DestFolder.CopyDir
            }
            return !(Ext.isDefined(t.get("right")) && (u = {
                right: t.get("right"),
                needRight: f
            }, !SYNO.webfm.utils.checkFileRight(u))) || (o.getMsgBox().alert(l, _WFT("error", "error_privilege_not_enough")), !1)
        }
    },
    onDDMVCP: function(e, t, i, o, n) {
        var s = n.srcsource;
        if (SYNO.webfm.utils.isLocalSource(s)) this.onDoDDMVCP(e, t, i, o, n);
        else {
            var r;
            r = Ext.isArray(e) ? e : SYNO.webfm.utils.transNodeToRecs(n.srcnode), SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, t, r, {
                arg1: o,
                fn: function() {
                    this.onDoDDMVCP(e, t, i, o, n)
                },
                scope: this
            })
        }
    },
    onDoDDMVCP: function(e, t, i, o, n) {
        var s, r = [],
            a = n.srcsource,
            l = SYNO.webfm.utils.isLocalSource(a);
        if (Ext.isEmpty(a) && Ext.isArray(e) && e[0] && e[0].store && (a = e[0].store.storetype), e instanceof Array) {
            s = SYNO.webfm.utils.ParseArr(e, "file_id");
            r = SYNO.webfm.utils.ParseArr(e, "file_id").sort(function(e, t) {
                return e < t
            })
        } else r = [e], s = [e];
        var h = [];
        "copy" !== t && (h = SYNO.webfm.utils.getParentDirArr(e, l && Ext.isWindows ? "\\" : "/"));
        var c = {
            srcIdArr: h,
            destId: o,
            pFiles: s,
            action: t,
            source: a
        };
        if (l) {
            var d = AppletProgram.action({
                files: r,
                destpath: o,
                overwrite: i,
                action: t
            });
            AppletProgram.checkResponse(d, this.webfm) && this.addLocalTask(t, {
                bkTaskCfg: {
                    taskid: d.taskid
                },
                actionCfg: c
            }, d.taskid)
        } else {
            var u = {
                    path: r,
                    dest_folder_path: o,
                    overwrite: i,
                    remove_src: "move" === t,
                    accurate_progress: !0
                },
                f = !0;
            Ext.isArray(e) && (f = !1, e.forEach(function(e) {
                if (e.get("isdir")) return f = !0, !1
            })), ("copy" === t && a === SYNO.webfm.utils.source.remotes && !0 === n.blsame || "move" === t && Ext.isDefined(n.search_taskid)) && Ext.apply(u, {
                search_taskid: n.search_taskid
            }), SYNO.API.currentManager.requestAPI("SYNO.FileStation.CopyMove", "start", "3", u, function(e, t, i, o) {
                this.onMVCPSendDone(e, t, Ext.apply(c, {
                    bldir: f
                }), i)
            }, this)
        }
    },
    getTreeDirInfo: function(e) {
        var t, i = {};
        if (!Ext.isEmpty(e)) return t = e.attributes, i.filename = t.name || t.text, i.file_id = t.path, i.path = t.path, i.mt = t.mt, i.real_path = t.real_path, i.isdir = !0, i.filesize = 0, i
    },
    onBeforeSmartDDMVCP: function(e, t, i, o) {
        var n = this.getDefaultSmartMVCPOption(),
            s = o.srcsource,
            r = SYNO.webfm.utils.isLocalSource(s);
        if (Ext.isEmpty(s) && Ext.isArray(e) && e[0] && e[0].store && (s = e[0].store.storetype), "upload" === t || "copymove" === t && !r)
            if ("copymove" !== t || r) this.onSmartDDMVCPToRemote(e, t, n, i, o, s);
            else {
                var a;
                a = Ext.isArray(e) ? e : SYNO.webfm.utils.transNodeToRecs(o.srcnode), SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, SYNO.webfm.SmartDDMVCPMgr.getAction(), a, {
                    arg1: i,
                    fn: function() {
                        this.onSmartDDMVCPToRemote(e, t, n, i, o, s)
                    },
                    scope: this
                })
            }
        else("download" === t || "copymove" === t && r) && this.onSmartDDMVCPToLocal(e, t, n, i, o, s)
    },
    onSmartDDMVCPToRemote: function(e, t, i, o, n, s) {
        var r, a, l, h = this.webfm,
            c = SYNO.webfm.SmartDDMVCPMgr.getAction(),
            d = [],
            u = [],
            f = [],
            m = [],
            p = [];
        Ext.isArray(e) ? (e.forEach(function(e) {
            m.push(e.data), f.push(e)
        }), f.sort(function(e, t) {
            return e.get("file_id") < t.get("file_id")
        }), r = SYNO.webfm.utils.ParseArr(e, "file_id"), l = SYNO.webfm.utils.ParseArr(e, "filename"), a = SYNO.webfm.utils.ParseArr(f, "file_id"), Ext.each(a, function(e) {
            u.push(e)
        }), Ext.each(l, function(e) {
            p.push(e)
        })) : (u = [e], r = u, m = [this.getTreeDirInfo(n.srcnode)], f = u, p = [m[0].filename]), "copy" !== c && (d = SYNO.webfm.utils.getParentDirArr(e, "/"));
        var g = {
                path: u,
                filename: p,
                dest_folder_path: o,
                additional: ["size", "time"]
            },
            b = !0;
        Ext.isArray(e) && (b = !1, e.forEach(function(e) {
            if (e.get("isdir")) return b = !0, !1
        }));
        var S = {
                srcIdArr: d,
                destId: o,
                pFiles: r,
                action: t,
                source: s,
                fileInfo: m
            },
            _ = {
                path: u,
                dest_folder_path: o,
                overwrite: i,
                remove_src: "move" === c,
                accurate_progress: !0
            };
        ("copy" === c && s === SYNO.webfm.utils.source.remotes && !0 === n.blsame || "move" === c && Ext.isDefined(n.search_taskid)) && Ext.apply(_, {
            search_taskid: n.search_taskid
        }), h.owner.setStatusBusy(), SYNO.API.currentManager.requestAPI("SYNO.FileStation.CheckExist", "check", "2", g, function(e, i, o, n) {
            if (h.owner.clearStatusBusy(), e && i)
                if (0 === i.total) this.doSmartDDMVCPRemote(f, t, S, _, b);
                else {
                    var s = this.convertConflictFiles(i.files),
                        r = new SYNO.FileStation.MVCPAskDialog({
                            owner: this.webfm.owner,
                            action: "move" === c ? "filetable_move" : "filetable_copy",
                            conflictDestFiles: s,
                            conflictSrcFiles: this.getConflictFiles(S.fileInfo, p, s),
                            showRenameOption: "copymove" === t
                        });
                    r.on("onAskDone", function(e) {
                        _.overwrite = this.getSmartOverwriteParams(u, e), _.rename = this.getSmartRenameParams(u, e), this.doSmartDDMVCPRemote(f, t, S, _, b)
                    }, this), r.show().center()
                }
            else {
                var a = SYNO.webfm.utils.getWebAPIErr(e, i, S);
                h.owner.getMsgBox().alert("", a)
            }
        }, this)
    },
    doSmartDDMVCPRemote: function(e, t, i, o, n) {
        "upload" === t ? this.directlyUpload(o.dest_folder_path, e, o.overwrite) : "copymove" === t && SYNO.API.currentManager.requestAPI("SYNO.FileStation.CopyMove", "start", "3", o, function(e, t, o, s) {
            this.onMVCPSendDone(e, t, Ext.apply(i, {
                bldir: n
            }), o)
        }, this)
    },
    onSmartDDMVCPToLocal: function(e, t, i, o, n, s) {
        var r, a, l, h = this.webfm,
            c = SYNO.webfm.utils.isLocalSource(s),
            d = [],
            u = [],
            f = [],
            m = [],
            p = SYNO.webfm.SmartDDMVCPMgr.getAction();
        Ext.isArray(e) ? (e.forEach(function(e) {
            u.push(e.data), f.push(e)
        }), f.sort(function(e, t) {
            return e.get("file_id") < t.get("file_id")
        }), a = SYNO.webfm.utils.ParseArr(e, "file_id"), m = SYNO.webfm.utils.ParseArr(e, "filename"), l = SYNO.webfm.utils.ParseArr(f, "file_id"), r = l) : (r = [e], a = r, u = [this.getTreeDirInfo(n.srcnode)], f = u, m = [u[0].filename]), "copy" !== p && (d = SYNO.webfm.utils.getParentDirArr(e, c && Ext.isWindows ? "\\" : "/"));
        var g = {
            srcIdArr: d,
            destId: o,
            pFiles: a,
            action: p,
            source: s,
            fileInfo: u
        };
        h.owner.setStatusBusy();
        var b = AppletProgram.action({
            files: r,
            filename: m,
            destpath: o,
            action: "checkdir"
        });
        if (h.owner.clearStatusBusy(), AppletProgram.checkResponse(b, this.webfm)) {
            var S = {
                files: r,
                destpath: o,
                overwrite: i,
                action: p
            };
            if (0 === b.total) this.doSmartDDMVCPLocal(f, t, g, S, n);
            else {
                var _ = new SYNO.FileStation.MVCPAskDialog({
                    owner: this.webfm.owner,
                    action: "move" === p ? "filetable_move" : "filetable_copy",
                    conflictDestFiles: b.files,
                    conflictSrcFiles: this.getConflictFiles(g.fileInfo, m, b.files),
                    showRenameOption: !1
                });
                _.on("onAskDone", function(e) {
                    S.overwrite = this.getSmartOverwriteParams(r, e), this.doSmartDDMVCPLocal(f, t, g, S, n)
                }, this), _.show().center()
            }
        }
    },
    doSmartDDMVCPLocal: function(e, t, i, o, n) {
        if ("download" === t) {
            var s = [];
            e.forEach(function(e) {
                s.push(e.data || e)
            }), this.onJavaDownload(i.action, o.destpath, s, o.overwrite)
        } else if ("copymove" === t) {
            var r = AppletProgram.action(o);
            AppletProgram.checkResponse(r, this.webfm) && this.addLocalTask(i.action, {
                bkTaskCfg: {
                    taskid: r.taskid
                },
                actionCfg: i
            }, r.taskid)
        }
    },
    convertConflictFiles: function(e) {
        var t = [];
        return e.forEach(function(e) {
            var i = {};
            i.filename = e.name, i.numeric_filename = e.numeric_name, i.path = e.path + "/" + e.name, i.numeric_path = e.path + "/" + e.numeric_name, i.filesize = e.additional.size, i.isdir = e.isdir, i.mt = e.additional.time.mtime, t.push(i)
        }), t
    },
    getConflictFiles: function(e, t, i) {
        var o = 0,
            n = 0,
            s = [];
        for (o = 0; o < i.length; o++) n = t.indexOf(i[o].filename), s.push(e[n]);
        return s
    },
    getSmartOverwriteParams: function(e, t) {
        var i = this.getDefaultSmartMVCPOption(),
            o = [],
            n = 0;
        for (n = 0; n < e.length; n++) o[n] = i;
        for (n = 0; n < t.length; n++) {
            o[e.indexOf(t[n].path)] = t[n].blOverwrite
        }
        return o
    },
    getSmartRenameParams: function(e, t) {
        var i = [],
            o = 0;
        for (o = 0; o < e.length; o++) i[o] = !1;
        for (o = 0; o < t.length; o++) {
            i[e.indexOf(t[o].path)] = t[o].blRename
        }
        return i
    },
    getDefaultSmartMVCPOption: function() {
        return !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "smartmvcpoverwrite")
    },
    Paste: function(e, t, i, o) {
        this.resetCTNode();
        var n = SYNO.FileStation.Clipboard.get();
        i = i || this.webfm.getCurrentSource();
        var s, r = SYNO.webfm.utils.isLocalSource(i),
            a = SYNO.webfm.utils.isLocalSource(n.params.source),
            l = n.recs,
            h = o || n.action,
            c = e.get("isdir") ? e.get("file_id") : SYNO.webfm.utils.getParentDirArr(e.get("file_id"), r && Ext.isWindows ? "\\" : "/")[0];
        if (!r && a) {
            if (!0 === _S("demo_mode")) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo")), !1;
            if (!this.webfm.onCheckVFSAction("upload", e)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
            if ("move" === h) return void this.owner.getMsgBox().confirm(_WFT("filetable", "filetable_upload"), _WFT("upload", "upload_move_confirm"), function(o) {
                "yes" == o && this.Paste.call(this, e, t, i, "copy")
            }, this);
            var d = this.webfm.dirTree.getNodeById(SYNO.webfm.utils.remote + c);
            if (d && !this.webfm.checkUploadRight(d)) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
            this.directlyUpload(c, l, t)
        } else if (r && !a) {
            if (!this.webfm.onCheckVFSAction("download", l)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
            if (!this.webfm.onCheckPrivilege("download", l, !1, !1)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
            s = [], l.forEach(function(e) {
                s.push(e.data)
            }), this.onJavaDownload(h, c, s, t)
        } else {
            if (!this.webfm.onCheckVFSAction(n.action, n.recs, e)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
            if (!this.onBeforeMVCPSubmit(n, e, r)) return;
            this.onMVCPSend(h, l, c, t, i)
        }
        "move" === h && SYNO.FileStation.Clipboard.clean()
    },
    onJavaMVCP: function(e, t, i, o) {
        var n = [];
        Ext.each(i, function(e) {
            n.push(new Ext.data.Record(e))
        });
        for (var s = Ext.isWindows ? "\\" : "/", r = "copy" == e ? _WFT("filetable", "filetable_copy") : _WFT("filetable", "filetable_move"), a = 0; a < n.length; a++) {
            var l = n[a].get("real_path");
            if (SYNO.webfm.utils.isConflictTargetPath(l, t, s)) return void this.owner.getMsgBox().alert(r, _WFT("error", "error_select_conflict"))
        }
        this.onMVCPSend(e, n, t, o)
    },
    onMVCPSend: function(e, t, i, o, n) {
        !n || SYNO.webfm.utils.isLocalSource(n) ? this.onDoMVCPSend(e, t, i, o, n) : SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, e, t, {
            arg1: i,
            fn: function() {
                this.onDoMVCPSend(e, t, i, o, n)
            },
            scope: this
        })
    },
    onDoMVCPSend: function(e, t, i, o, n) {
        var s, r = [],
            a = !n || SYNO.webfm.utils.isLocalSource(n);
        "copy" !== e && (r = SYNO.webfm.utils.getParentDirArr(t, a && Ext.isWindows ? "\\" : "/"));
        var l = {
            srcIdArr: r,
            pFiles: SYNO.webfm.utils.ParseArr(t, "file_id"),
            destId: i,
            action: e,
            source: n
        };
        s = SYNO.webfm.utils.ParseArr(t, "file_id").sort(function(e, t) {
            return e < t
        });
        var h = {};
        if (a) {
            h = {
                overwrite: o,
                action: e,
                destpath: i,
                files: s
            };
            var c = AppletProgram.action(h);
            AppletProgram.checkResponse(c, this.webfm) && this.addLocalTask(e, {
                bkTaskCfg: {
                    taskid: c.taskid
                },
                actionCfg: l
            }, c.taskid)
        } else {
            var d = !1;
            if (t.forEach(function(e) {
                    if (e.get("isdir")) return d = !0, !1
                }), h = {
                    overwrite: o,
                    dest_folder_path: i,
                    path: s,
                    remove_src: "move" === e,
                    accurate_progress: !0
                }, this.webfm.getCurrentSource() === SYNO.webfm.utils.source.remotes || this.webfm.cutSource === SYNO.webfm.utils.source.remotes || this.webfm.copySource === SYNO.webfm.utils.source.remotes) {
                var u = this.webfm.remoteSearchDS.search_taskid;
                u && Ext.apply(h, {
                    search_taskid: u
                }), this.webfm.cutSource = "", this.webfm.copySource = ""
            }
            SYNO.API.currentManager.requestAPI("SYNO.FileStation.CopyMove", "start", "3", h, function(e, t, i, o) {
                this.onMVCPSendDone(e, t, Ext.apply(l, {
                    bldir: d
                }), i)
            }, this)
        }
    },
    onMVCPSendDone: function(e, t, i, o) {
        var n = i.srcIdArr,
            s = i.destId,
            r = i.pFiles;
        if (e && t && t.taskid) this.addBkWebAPITask(!1 === o.remove_src ? "copy" : "move", {
            bkTaskCfg: {
                taskid: t.taskid
            },
            actionCfg: {
                fileStr: SYNO.webfm.utils.ParseArrToFileName(r),
                srcIdArr: n,
                destId: s
            },
            extra: {
                bldir: i.bldir,
                search_taskid: o.search_taskid
            }
        });
        else {
            var a = !1 === o.remove_src ? _WFT("filetable", "filetable_copy") : _WFT("filetable", "filetable_move");
            this.showMsg(a, SYNO.webfm.utils.getWebAPIErr(e, t, o)), this.webfm.refreshTreeNode(n.concat(s), !0)
        }
    },
    Create: function(e, t) {
        this.CrtFdrDialog && !this.CrtFdrDialog.isDestroyed || (this.CrtFdrDialog = new SYNO.FileStation.CrtFdrDialog({
            RELURL: this.RELURL,
            owner: this.owner
        }), this.CrtFdrDialog.mon(this.CrtFdrDialog, "callback", function() {
            this.onCreateHide(t)
        }, this));
        var i = this.CrtFdrDialog;
        i.setCheckName(t || this.webfm.getCurrentSource()), i.setParentDir(e), i.load()
    },
    onCreateHide: function(e) {
        var t = this.CrtFdrDialog,
            i = t.getFolderName(),
            o = t.getParentDir();
        if (e = e || this.webfm.getCurrentSource(), i && o) {
            var n = o + "/" + i,
                s = {
                    fileid: n,
                    srcIdArr: [o],
                    source: e
                };
            if (this.webfm.isViewMasked() || this.webfm.maskView(_WFT("common", "loading"), "x-mask-loading"), SYNO.webfm.utils.isRemoteSource(e)) SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: o,
                name: i,
                force_parent: !1
            }, function(e, t, i, o) {
                this.onCreateDone(o, e, t, s)
            }, this);
            else {
                var r = AppletProgram.action({
                    files: i,
                    dest: o,
                    action: "createfolder"
                });
                this.onCreateDone(null, r.success, r.errno, s)
            }
        }
    },
    onCreateDone: function(e, t, i, o) {
        var n = o.fileid,
            s = o.srcIdArr;
        if (this.webfm.isViewMasked() && this.webfm.unmaskView(), t) !1 !== o.refresh && this.fireEvent("refreshTreeNode", s, !0, o.source), this.fireEvent("setHighlightEntry", n);
        else {
            var r;
            r = i && i.section && i.key ? _WFT(i.section, i.key) : SYNO.webfm.utils.getWebAPIErr(t, i, e), this.showMsg(_WFT("filetable", "filetable_create_folder"), r)
        }
    },
    compressDialog: function(e, t, i) {
        this.CompressDialog && !this.CompressDialog.isDestroyed || (this.CompressDialog = new SYNO.FileStation.CompressDialog({
            owner: this.owner
        }), this.CompressDialog.mon(this.CompressDialog, "callback", this.Compress, this)), this.CompressDialog.load(e, t, i)
    },
    Compress: function(e, t, i, o, n, s, r, a) {
        var l;
        if (e && 0 !== e.length) {
            if (!SYNO.webfm.utils.checkFileLen(i)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _WFT("compress", "compress_error_long_name"));
            l = t + "/" + i;
            var h = SYNO.webfm.utils.ParseArr(e, "file_id"),
                c = {
                    path: h,
                    dest_file_path: l,
                    level: o || "normal",
                    mode: n || "replace",
                    format: r || "zip",
                    password: s,
                    codepage: a
                },
                d = {
                    fileid: l,
                    srcIdArr: [t],
                    zipname: i
                };
            SYNO.API.currentManager.requestAPI("SYNO.FileStation.Compress", "start", "3", c, function(e, t, i, o) {
                this.onCompressSendDone(e, t, i, d)
            }, this)
        }
    },
    onCompressSendDone: function(e, t, i, o) {
        var n = o.srcIdArr,
            s = o.fileid;
        if (e && t && t.taskid) this.addBkWebAPITask("compress", {
            bkTaskCfg: {
                taskid: t.taskid
            },
            actionCfg: {
                fileStr: o.zipname,
                fileid: s,
                srcIdArr: n
            },
            webfm: this.webfm
        });
        else {
            var r = _WFT("filetable", "filetable_compress"),
                a = SYNO.webfm.utils.getWebAPIErrStr(e, t, i);
            this.showMsg(r, a)
        }
    },
    onJavaDownload: function(e, t, i, o) {
        if ("move" === e && _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _JSLIBSTR("uicommon", "error_demo"));
        var n = this.webfm.getDownloadInstance(),
            s = n.getAvailableTaskNumber(1),
            r = 1 - s;
        if (0 < r) {
            var a = String.format(_WFT("filetable", "filetable_download_select_max"), n.getMaxTaskNumber()) + "<br>";
            a += 1 == r ? _WFT("filetable", "filetable_download_unselect") : String.format(_WFT("filetable", "filetable_download_unselect_files", r)), this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), a)
        }
        if (!(s <= 0)) {
            1 != s && (i = i.slice(0, s));
            var l = {
                    action: "downloadprogress",
                    blcopy: "move" !== e,
                    dir: t,
                    files: i,
                    overwrite: o,
                    blupload: !1
                },
                h = AppletProgram.action(l);
            AppletProgram.checkResponse(h)
        }
    },
    DirectDownload: function(e, t, i) {
        var o = e.get("filename"),
            n = e.get("file_id");
        this.downloadAction.DirectDownload(o, n, e, i)
    },
    Download: function(e, t) {
        this.downloadAction.Download(e, t)
    },
    onMultiDownload: function(e) {
        SYNO.FileStation.MultiDownloadMgr || (SYNO.FileStation.MultiDownloadMgr = new SYNO.FileStation.BlobDownloadMgr({
            instantStart: !0,
            webfm: this.webfm
        })), SYNO.FileStation.MultiDownloadMgr.addDownloadTask(e)
    },
    BrowserUpload: function(e, t, i) {
        var o = new SYNO.FileStation.UploadDialog({
            webfm: this.webfm,
            owner: this.owner,
            UploadCGI: this.UploadCGI
        });
        o.setParameters(e), o.load(t)
    },
    directlyUpload: function(e, t, i) {
        t instanceof Array ? t[0] instanceof Object && (t = SYNO.webfm.utils.ParseArr(t, "file_id")) : t = [t];
        var o = this.webfm.getUploadInstance(),
            n = t.length,
            s = o.getAvailableTaskNumber(n),
            r = n - s;
        if (0 < r) {
            var a = _WFT("filetable", "filetable_select_max");
            a = a.replace("_MAXNO_", o.getMaxTaskNumber()) + "<br>", 1 == r ? a += _WFT("common", "common_unselect_file") : (a += _WFT("common", "common_unselect_files"), a = a.replace("_NFILES_", r)), this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), a)
        }
        if (!(s <= 0)) {
            n != s && (t = t.slice(0, s));
            var l = {
                    action: "uploadprogress",
                    remoteDir: e,
                    localPaths: t,
                    overwrite: i
                },
                h = AppletProgram.action(l);
            AppletProgram.checkResponse(h)
        }
    },
    onBeforeLocalUploadSubmit: function(e) {
        var t = this.UploadTreeDialog;
        if (t) {
            if (!0 === _S("is_admin") || "true" == _S("domainUser")) return !0;
            if (!SYNO.webfm.utils.checkShareRight(e.shareRight, SYNO.webfm.utils.RW)) return t.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
            if (Ext.isDefined(e.folderRight)) {
                var i = {
                    right: e.folderRight,
                    needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Upload
                };
                if (!SYNO.webfm.utils.checkFileRight(i)) return t.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1
            }
            return !0
        }
    },
    onLocalUploadDialogHide: function() {
        var e = this.win;
        if (e) {
            var t = this.that,
                i = {};
            i = e.getParameters(), i.fdrName && this.recs && t.directlyUpload(i.fdrName, this.recs, i.blOverWrite)
        }
    },
    localUpload: function(e, t, i) {
        this.UploadTreeDialog && !this.UploadTreeDialog.isDestroyed || (this.UploadTreeDialog = new SYNO.FileStation.TreeDialog({
            RELURL: this.RELURL,
            blDynamicForm: !0,
            blVFSFolder: !0,
            owner: this.owner,
            webfm: this.webfm
        }), this.UploadTreeDialog.mon(this.UploadTreeDialog, "beforesubmit", this.onBeforeLocalUploadSubmit, this));
        var o = this.UploadTreeDialog,
            n = {
                uid: t,
                gid: i,
                that: this,
                win: o
            };
        o.mon(o, "callback", this.onLocalUploadDialogHide, {
            that: this,
            recs: e,
            scope: n,
            win: o
        }, {
            single: !0
        }), o.load(_WFT("filetable", "filetable_upload"), !0, t, i)
    },
    Rename: function(e, t, i) {
        i = i || this.webfm.getCurrentSource(), SYNO.webfm.utils.isLocalSource(i) ? this.doRename(e, t, i) : SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, "rename", e, {
            fn: function() {
                this.doRename(e, t, i)
            },
            scope: this
        })
    },
    doRename: function(e, t, i) {
        i = i || this.webfm.getCurrentSource(), this.RenameDialog && !this.RenameDialog.isDestroyed || (this.RenameDialog = new SYNO.FileStation.RenameDialog({
            webfm: this.webfm,
            owner: this.owner
        }));
        var o = SYNO.webfm.utils.getPathSeparator(i),
            n = this.RenameDialog;
        !1 === SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, "rename", e) ? n.setCheckRecs(e) : n.setCheckRecs(null), n.mon(n, "callback", this.onRenameHide, {
            that: this,
            srcIdArr: SYNO.webfm.utils.getParentDirArr(e, o),
            isdir: e[0].get("isdir"),
            win: n,
            source: i
        }, {
            single: !0
        }), n.setIsDir(e[0].get("isdir")), n.setOldName(e[0].get("filename")), n.setCheckName(i), t || (t = SYNO.webfm.utils.getParentDirArr(e[0].get("path"), o)[0]), n.setCurrentDir(t), n.load()
    },
    resetCTNode: function() {
        this.webfm.currCTNode = null, this.webfm.currCTNodeTmp = null, this.webfm.currCTAction = null
    },
    onRenameHide: function() {
        var e = this.that,
            t = this.isdir,
            i = this.win,
            o = i.getOldName(),
            n = i.getNewName(),
            s = i.getCurrentDir();
        if (!o || !n) return void e.resetCTNode();
        if (e.webfm.isViewMasked() || e.webfm.maskView(_WFT("common", "loading"), "x-mask-loading"), SYNO.webfm.utils.isLocalSource(this.source)) {
            var r = AppletProgram.action({
                    oldname: o,
                    newname: n,
                    fileID: s,
                    action: "rename"
                }),
                a = [];
            a[0] = s;
            var l = {
                fileid: r.newName,
                srcIdArr: a,
                isdir: t,
                source: e.webfm.getCurrentSource()
            };
            e.onRenameDone(null, r.success, r.errno, l)
        } else {
            var h = {
                    fileid: s + "/" + n,
                    srcIdArr: this.srcIdArr,
                    isdir: t,
                    source: e.webfm.getCurrentSource()
                },
                c = {
                    path: [s + "/" + o],
                    name: [n]
                };
            if (e.webfm.getCurrentSource() === SYNO.webfm.utils.source.remotes) {
                var d = e.webfm.remoteSearchDS.search_taskid;
                d && Ext.apply(c, {
                    search_taskid: d
                })
            }
            e.webfm.sendWebAPI({
                api: "SYNO.FileStation.Rename",
                version: 2,
                method: "rename",
                params: c,
                scope: e,
                callback: function(e, t, i, o) {
                    this.onRenameDone(o, e, t, h)
                }
            })
        }
        e.resetCTNode()
    },
    onRenameDone: function(e, t, i, o) {
        var n, s = o.fileid,
            r = o.srcIdArr;
        this.webfm.isViewMasked() && this.webfm.unmaskView(), t ? (this.fireEvent("refreshTreeNode", r, o.isdir, o.source), this.fireEvent("setHighlightEntry", s), e && Ext.isDefined(e.params.search_taskid) && this.webfm.refreshSearhGrid(Ext.decode(e.params.search_taskid))) : (n = i && i.section && i.key ? _WFT(i.section, i.key) : SYNO.webfm.utils.getWebAPIErr(t, i, e), this.showMsg(_WFT("filetable", "filetable_rename"), n))
    },
    ViewSnapshotHistory: function(e, t) {
        new SYNO.SDS.Snapshot.HistoryWindow({
            owner: t
        }, e).show()
    },
    findNextFocusIndex: function(e) {
        var t = 0;
        return Ext.isEmpty(e) ? t : (Ext.isArray(e) || (e = [e]), Ext.each(e, function(e) {
            var i = this.webfm.activeDS.indexOf(e);
            t = i > t ? i : t
        }, this), t >= this.webfm.activeDS.getTotalCount() - 1 ? t - e.length : t - e.length + 1)
    },
    Delete: function(e, t, i) {
        i = i || this.webfm.getCurrentSource();
        var o = SYNO.webfm.utils.isLocalSource(i),
            n = o ? _WFT("filetable", "filetable_local_delete_confirm") : _WFT("filetable", "filetable_delete_confirm");
        (o || !0 === SYNO.webfm.Plugin.checkActionByPlugin(this.webfm, this.owner, "delete", e, {
            warning_fn: function(o) {
                this.owner.getMsgBox().confirmDelete(_WFT("filetable", "filetable_delete"), Ext.isEmpty(o) ? n : o.join("<br>"), function(o) {
                    "yes" == o && this.doDelete(e, t, i)
                }, this)
            },
            scope: this
        })) && this.owner.getMsgBox().confirmDelete(_WFT("filetable", "filetable_delete"), n, function(o) {
            "yes" == o && this.doDelete(e, t, i)
        }, this)
    },
    doDelete: function(e, t, i) {
        var o, n;
        if (!e || 0 === e.length) return void this.resetCTNode();
        var s = SYNO.webfm.utils.ParsePairArr(e, "path", t).sort(function(e, t) {
                return e.file < t.file
            }).map(function(e) {
                return e.file
            }),
            r = 0;
        r = this.findNextFocusIndex(e);
        var a = {
                pFiles: SYNO.webfm.utils.ParseArr(e, "file_id"),
                focusIndex: r
            },
            l = {};
        if (SYNO.webfm.utils.isLocalSource(i)) o = AppletProgram.action({
            action: "delete",
            files: s
        }), AppletProgram.checkResponse(o, this.webfm) && (n = SYNO.webfm.utils.getPathSeparator(i), this.addLocalTask("delete", {
            bkTaskCfg: {
                taskid: o.taskid
            },
            actionCfg: {
                fileStr: SYNO.webfm.utils.ParseArrToFileName(SYNO.webfm.utils.ParseArr(e, "file_id"), n),
                srcIdArr: SYNO.webfm.utils.getParentDirArr(e, n),
                focusIndex: r,
                source: i
            }
        }, o.taskid));
        else {
            if (Ext.apply(a, {
                    srcIdArr: SYNO.webfm.utils.getParentDirArr(e)
                }), l = {
                    path: s,
                    accurate_progress: !0
                }, this.webfm.getCurrentSource() === SYNO.webfm.utils.source.remotes) {
                var h = this.webfm.remoteSearchDS.search_taskid;
                h && Ext.apply(l, {
                    search_taskid: h
                })
            }
            this.owner.sendWebAPI({
                api: "SYNO.FileStation.Delete",
                method: "start",
                version: 2,
                params: l,
                scope: this,
                callback: function(e, t, i, o) {
                    this.onDeleteSendDone(e, t, a, o)
                }
            })
        }
        this.resetCTNode()
    },
    onDeleteSendDone: function(e, t, i, o) {
        var n = i.srcIdArr,
            s = i.pFiles,
            r = !!i.mountRemoteFailed;
        e && t && t.taskid ? this.addBkWebAPITask("delete", {
            bkTaskCfg: {
                taskid: t.taskid,
                blMsgMinimized: r,
                focusIndex: i.focusIndex
            },
            actionCfg: {
                fileStr: SYNO.webfm.utils.ParseArrToFileName(s),
                srcIdArr: n,
                focusIndex: i.focusIndex
            },
            extra: {
                search_taskid: o.params.search_taskid ? Ext.decode(o.params.search_taskid) : ""
            }
        }) : (this.showMsg(_WFT("filetable", "filetable_delete"), SYNO.webfm.utils.getWebAPIErr(e, t, o)), this.fireEvent("refreshTreeNode", n, !0))
    },
    MountList: function() {
        this.MountListDialog && !this.MountListDialog.isDestroyed || (this.MountListDialog = new SYNO.FileStation.MountListDialog({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm,
            module: this
        })), this.MountListDialog.show()
    },
    onSettings: function() {
        this.SettingDialog && !this.SettingDialog.isDestroyed || (this.SettingDialog = new SYNO.FileStation.SettingDialog({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm
        })), this.SettingDialog.mon(this.SettingDialog, "close", this.webfm.onSettingClose, this.webfm), this.SettingDialog.show()
    },
    Eject: function(e) {
        var t = this.webfm.deviceObj.dev_id,
            i = this.webfm.deviceObj.dev_type;
        if (t && i) this.onEject(t, i, e);
        else {
            this.showMsg(_T("tree", "node_device"), _T("common", "error_system"));
            var o = SYNO.webfm.utils.getParentDirArr(e);
            this.fireEvent("refreshTreeNode", o, !0)
        }
    },
    onEject: function(e, t, i) {
        var o, n = _T("tree", "node_device"),
            s = SYNO.webfm.utils.getParentDirArr(i);
        if ("usbDisk" == t || "sdCard" == t) n = "usbDisk" == t ? _T("tree", "leaf_usbdisk") : _T("tree", "leaf_sdcard"), o = !0;
        else {
            if ("eSataDisk" != t) return this.showMsg(_T("tree", "node_device"), _T("common", "error_system")), void SYNO.SDS.StatusNotifier.fireEvent("externaldeviceactivity", "ejectdevice");
            n = _T("tree", "leaf_esata"), o = !1
        }
        this.owner.sendWebAPI({
            api: !0 === o ? "SYNO.Core.ExternalDevice.Storage.USB" : "SYNO.Core.ExternalDevice.Storage.eSATA",
            version: 1,
            method: "eject",
            params: {
                dev_id: e
            },
            callback: function(e) {
                !0 !== e && this.showMsg(n, _T("common", "error_system")), this.fireEvent("refreshTreeNode", s, !0)
            },
            scope: this
        })
    },
    Umount: function(e, t) {
        var i, o, n, s, r, a = [];
        if (!e || 1 !== e.length) return void this.resetCTNode();
        i = e[0].get("file_id"), o = e[0].get("mountType"), n = e[0].get("isMountPoint");
        var l = this.findNextFocusIndex(e),
            h = {
                srcIdArr: SYNO.webfm.utils.getParentDirArr(e),
                pFiles: SYNO.webfm.utils.ParseArr(e, "file_id"),
                focusIndex: l
            };
        for (r = 0; r < e.length; r++) s = e[r].get("file_id"), a.push(s.substr(0, s.lastIndexOf("/")));
        var c = SYNO.webfm.utils.ParsePairArr(e, "path", a).sort(function(e, t) {
            return e.file < t.file
        }).map(function(e) {
            return e.file
        });
        this.webfm.el.isMasked() || this.webfm.el.mask(_WFT("common", "loading"), "x-mask-loading"), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Mount",
            version: 1,
            method: "unmount",
            scope: this,
            params: {
                mount_type: o,
                is_mount_point: n || !0,
                mount_point: i
            },
            callback: function(e, t, i, o) {
                this.onUmountDone(o, e, t, h), e && t.UseDefPath && "yes" === t.UseDefPath && this.owner.sendWebAPI({
                    api: "SYNO.FileStation.Delete",
                    method: "start",
                    version: 2,
                    params: {
                        path: c,
                        accurate_progress: !1,
                        recursive: !1
                    },
                    scope: this,
                    callback: function(e, t, i, o) {
                        this.onDeleteSendDone(e, t, h, o)
                    }
                })
            }
        }), this.resetCTNode()
    },
    onUmountDone: function(e, t, i, o) {
        var n = o.srcIdArr;
        this.webfm.el.isMasked() && this.webfm.el.unmask(), t ? ("yes" !== i.UseDefPath && this.fireEvent("refreshTreeNode", n, !0), this.fireEvent("refreshRTreeNode", n, n[0], !0), this.fireEvent("refreshVTreeNode", n, n[0], !0)) : this.showMsg(_WFT("mount", "umount"), SYNO.webfm.utils.getWebAPIErrStr(t, i, e))
    },
    RemoteConnect: function(e) {
        this.RemoteConnectionWizard && !this.RemoteConnectionWizard.isDestroyed || (this.RemoteConnectionWizard = new SYNO.FileStation.RemoteConnection.Wizard({
            owner: e,
            webfm: this.webfm
        })), this.RemoteConnectionWizard.setStatusBusy({
            text: _WFT("common", "common_plz_wait")
        }), this.RemoteConnectionWizard.load()
    },
    RemoteConnectServerList: function(e) {
        this.RemoteConnectionServerListDialog && !this.RemoteConnectionServerListDialog.isDestroyed || (this.RemoteConnectionServerListDialog = new SYNO.FileStation.RemoteConnection.ServerListDialog({
            owner: e,
            webfm: this.webfm
        })), this.RemoteConnectionServerListDialog.load()
    },
    RemoveProtocol: function(e) {
        SYNO.FileStation.RemoteConnection.Utils.deleteServer([e], !1, this.owner, function(t, i, o, n) {
            if (this.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, SYNO.webfm.VFS.getSchemaFromPath(e)), !t || i.has_fail) {
                var s = SYNO.API.Util.GetFirstError(i);
                this.owner.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, s))
            }
        }, this)
    },
    DisconnectProtocol: function(e) {
        SYNO.FileStation.RemoteConnection.Utils.deleteServer([e], !0, this.owner, function(t, i, o, n) {
            if (this.fireEvent("refreshVFSTreeNode", Ext.emptyFn, this, SYNO.webfm.VFS.getSchemaFromPath(e)), !t || i.has_fail) {
                var s = SYNO.API.Util.GetFirstError(i);
                this.owner.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErr(!1, s))
            }
        }, this)
    },
    MountRemoteCIFS: function(e, t) {
        var i;
        !this.MountRemoteCIFSDialog || this.MountRemoteCIFSDialog.isDestroyed ? (this.MountRemoteCIFSDialog = new SYNO.FileStation.MountRemoteDialog.MountCIFS({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm
        }), i = this.MountRemoteCIFSDialog, i.mon(i, "mountremote", function() {
            this.onMountRemote(i)
        }, this)) : i = this.MountRemoteCIFSDialog, i.load(e, t)
    },
    MountRemoteNFS: function(e, t) {
        var i;
        !this.MountRemoteNFSDialog || this.MountRemoteNFSDialog.isDestroyed ? (this.MountRemoteNFSDialog = new SYNO.FileStation.MountRemoteDialog.MountNFS({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm
        }), i = this.MountRemoteNFSDialog, i.mon(i, "mountnfs", function() {
            this.onMountRemote(i)
        }, this)) : i = this.MountRemoteNFSDialog, i.load(e, t)
    },
    onMountRemote: function(e) {
        var t, i, o, n, s, r, a = e.getMountType(),
            l = e.getMntPointUserSet();
        if (e) {
            o = e.getMntPoint(), i = {
                mount_type: e.getMountType(),
                server_ip: e.getServerIP(),
                mount_point: o,
                user_set: l,
                auto_mount: e.getAutoMnt()
            }, "CIFS" === a ? Ext.apply(i, {
                account: e.getAccount(),
                passwd: e.getPasswd()
            }) : "NFS" === a && Ext.apply(i, {
                nfs_version: e.getNFSVersion(),
                protocol: e.getProtocol()
            }), r = {
                srcIdArr: SYNO.webfm.utils.getParentDirArr(o),
                fileid: o,
                source: SYNO.webfm.utils.source.remote,
                refresh: !1
            }, t = {
                srcIdArr: SYNO.webfm.utils.getParentDirArr(o),
                userSet: l,
                file_id: o
            }, !1 === l && (n = e.getSubDirName(), s = this.webfm.getCurrentDir());
            var h = this,
                c = function(e, t) {
                    h.owner.addWebAPITask({
                        single: !0,
                        api: "SYNO.FileStation.Mount",
                        version: 1,
                        method: "mount_remote",
                        params: e,
                        callback: function(e, i, o, n) {
                            h.onMountRemoteDone(n, e, i, t, a)
                        },
                        scope: h
                    }).start(!0)
                };
            e.el.isMasked() || e.el.mask(_WFT("common", "loading"), "x-mask-loading"), !1 === l ? SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: s,
                name: n,
                force_parent: !1
            }, function(e, o, n, s) {
                if (e) c(i, t);
                else if (SYNO.webfm.utils.getWebAPIErr(e, o, n), o && Ext.isArray(o.errors) && 414 === o.errors[0].code) return this.webfm.isViewMasked() && this.webfm.unmaskView(), i.user_set = !0, t.userSet = !0, t.errDirExist = !0, void c(i, t);
                this.onCreateDone(s, e, o, r)
            }, this) : c(i, t), this.resetCTNode()
        }
    },
    onMountRemoteDone: function(e, t, i, o, n) {
        var s, r, a, l = o.srcIdArr,
            h = [],
            c = {},
            d = "CIFS" === n ? this.MountRemoteCIFSDialog : this.MountRemoteNFSDialog;
        for (d.el.isMasked() && d.el.unmask(), r = new Ext.data.Record({
                file_id: o.file_id,
                path: o.file_id,
                isdir: !0
            }), r = [r], Ext.apply(c, {
                pFiles: SYNO.webfm.utils.ParseArr(r, "file_id"),
                srcIdArr: l,
                mountRemoteFailed: !0
            }), a = 0; a < r.length; a++) s = r[a].get("file_id"), h.push(s.substr(0, s.lastIndexOf("/")));
        var u = SYNO.webfm.utils.ParsePairArr(r, "path", h).sort(function(e, t) {
            return e.file < t.file
        }).map(function(e) {
            return e.file
        });
        t ? ("" === l[0] ? this.webfm.reloadTree() : (this.fireEvent("refreshTreeNode", l, !0), this.webfm.dirTree.getNodeById("fm_rf_root") && this.webfm.dirTree.getNodeById("fm_rf_root").reload()), d.close()) : (o.userSet || this.owner.sendWebAPI({
            api: "SYNO.FileStation.Delete",
            method: "start",
            version: 2,
            params: {
                path: u,
                accurate_progress: !1,
                recursive: !1
            },
            scope: this,
            callback: function(e, t, i, o) {
                this.onDeleteSendDone(e, t, c, o)
            }
        }), o.errDirExist && i && 441 === i.code && this.webfm.getCurrDirSubFdr(d, d.getSubDirName()), d.getMsgBox().alert(_WFT("filetable", "filetable_mount_remote_volume"), SYNO.webfm.utils.getWebAPIErrStr(t, i, e)))
    },
    MountISO: function(e, t, i) {
        var o, n = "",
            s = "",
            r = "";
        !this.MountISODialog || this.MountISODialog.isDestroyed ? (this.MountISODialog = new SYNO.FileStation.MountISODialog({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm,
            rec: e
        }), o = this.MountISODialog, o.mon(o, "mountiso", function() {
            this.onMountISO(o)
        }, this)) : o = this.MountISODialog, s = e[0].get("file_id"), n = e[0].get("real_path"), r = e[0].get("filename"), o.load(s, n, r, t, i)
    },
    onMountISO: function(e) {
        var t, i, o, n, s, r, a, l, h = e.getMntPointUserSet();
        if (e && (s = e.getSource(), r = e.getMntPoint(), a = e.getAutoMnt(), l = e.getFileID(), "" !== s && "" !== r && "" !== a && "" !== l)) {
            n = {
                srcIdArr: SYNO.webfm.utils.getParentDirArr(r),
                fileid: r,
                source: SYNO.webfm.utils.source.remote,
                refresh: !1
            }, t = {
                fileid: r,
                srcIdArr: SYNO.webfm.utils.getParentDirArr(r),
                userSet: h
            }, !1 === h && (i = e.getSubDirName(), o = this.webfm.getCurrentDir(), SYNO.webfm.utils.source.remotes === this.webfm.getCurrentSource() && (o = SYNO.webfm.utils.getParentDirArr(r)[0]));
            var c = this.owner.addWebAPITask({
                api: "SYNO.FileStation.Mount",
                version: 1,
                method: "mount_iso",
                params: {
                    source: s,
                    mount_point: r,
                    auto_mount: a,
                    user_set: h
                },
                callback: function(e, i, o, n) {
                    this.onMountISODone(n, e, i, t)
                },
                scope: this,
                single: !0
            });
            e.el.isMasked() || e.el.mask(_WFT("common", "loading"), "x-mask-loading"), !1 === h ? SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: o,
                name: i,
                force_parent: !1
            }, function(e, t, i, o) {
                this.onCreateDone(o, e, t, n), e && c.start(!0)
            }, this) : c.start(!0), this.resetCTNode()
        }
    },
    onMountISODone: function(e, t, i, o) {
        var n, s, r, a = o.fileid,
            l = o.srcIdArr,
            h = {},
            c = [];
        for (this.MountISODialog.el.isMasked() && this.MountISODialog.el.unmask(), s = new Ext.data.Record({
                file_id: a,
                path: a,
                isdir: !0
            }), s = [s], Ext.apply(h, {
                pFiles: SYNO.webfm.utils.ParseArr(s, "file_id"),
                srcIdArr: l,
                mountRemoteFailed: !0
            }), r = 0; r < s.length; r++) n = s[r].get("file_id"), c.push(n.substr(0, n.lastIndexOf("/")));
        var d = SYNO.webfm.utils.ParsePairArr(s, "path", c).sort(function(e, t) {
            return e.file < t.file
        }).map(function(e) {
            return e.file
        });
        if (t) "" === l[0] ? this.webfm.reloadTree() : (this.fireEvent("refreshTreeNode", l, !0), this.webfm.dirTree.getNodeById("fm_vd_root") && this.webfm.dirTree.getNodeById("fm_vd_root").reload()), this.fireEvent("setHighlightEntry", a), this.MountISODialog.close();
        else {
            o.userSet || this.owner.sendWebAPI({
                api: "SYNO.FileStation.Delete",
                method: "start",
                version: 2,
                params: {
                    path: d,
                    accurate_progress: !1,
                    recursive: !1
                },
                scope: this,
                callback: function(e, t, i, o) {
                    this.onDeleteSendDone(e, t, h, o)
                }
            });
            var u = SYNO.webfm.utils.getWebAPIErrStr(t, i);
            this.MountISODialog.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), u)
        }
    },
    Extract: function(e, t, i) {
        var o, n = "",
            s = [],
            r = [];
        !this.ExtractDialog || this.ExtractDialog.isDestroyed ? (this.ExtractDialog = new SYNO.FileStation.ExtractDialog({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this.webfm
        }), o = this.ExtractDialog, o.mon(o, "extract", function() {
            this.onStartExtract(o)
        }, this)) : o = this.ExtractDialog, n = e[0].get("file_id"), r = SYNO.webfm.utils.ParseArr(e, "file_id"), s = SYNO.webfm.utils.ParseArr(e, "file_id"), s.length > 1 ? (o.SetMultiZipFile(s), o.SetPathFiles(r), o.load(n, null, t, i, !0)) : (o.SetPathFiles(r), o.load(n, s[0], t, i, !1))
    },
    onStartExtract: function(e) {
        var t, i = {};
        if (e && (i = e.getOptions())) {
            var o = i.all && !i.zipPath;
            o && (t = e.GetMultiZipFile());
            var n = {
                overwrite: "overwrite" === i.mode,
                password: i.pass,
                file_path: o ? t[0] : i.zipPath,
                keep_dir: "full" === i.pathMode,
                dest_folder_path: i.dest,
                codepage: i.codepage
            };
            i.all || (n.item_id = i.files);
            var s = {
                destId: i.dest,
                blMultiExtract: o,
                gZipArr: t,
                file_path: o ? t[0] : n.file_path,
                dest: i.dest,
                pFiles: e.GetPathFiles(),
                owner: e
            };
            n.file_path = n.file_path, n.dest_folder_path = n.dest_folder_path, SYNO.API.currentManager.requestAPI("SYNO.FileStation.Extract", "start", "2", n, function(e, t, i) {
                this.onExtractSendDone(e, t, i, s)
            }, this)
        }
    },
    onExtractSendDone: function(e, t, i, o) {
        var n = o.pFiles;
        if (e && t && t.taskid) this.addBkWebAPITask("extract", {
            owner: o.owner,
            bkTaskCfg: {
                taskid: t.taskid
            },
            actionCfg: {
                fileStr: n.length > 1 ? " (" + SYNO.webfm.utils.ParseArrToFileName(n) + ")" : "",
                ajaxParams: i,
                destId: o.destId,
                blMultiExtract: o.blMultiExtract,
                gZipArr: o.gZipArr,
                gDestArr: o.gDestArr,
                file_path: o.file_path
            }
        });
        else {
            var s = _WFT("filetable", "filetable_extract"),
                r = SYNO.webfm.utils.getWebAPIErrStr(e, t, i);
            this.showMsg(s, r)
        }
    },
    ExtractNoDialog: function(e, t) {
        var i, o, n = "",
            s = "",
            r = "",
            a = [],
            l = [];
        for (o = 0; o < e.length; o++) {
            if (n = e[o].get("file_id"), s = e[o].get("file_id"), !n || n.length < 1 || !s || s.length < 1) return;
            a.push(n), i = r = e[o].get("file_id").substr(0, s.lastIndexOf("/")), t && (r += "/" + SYNO.webfm.utils.getZipName(e[o].get("filename")), l.push(r))
        }
        var h = a.length > 0 ? a : [],
            c = l.length > 0 ? l : [],
            d = SYNO.webfm.utils.ParseArr(e, "file_id"),
            u = !1;
        a.length > 1 && (u = !0);
        var f = {
            overwrite: !1,
            file_path: h[0],
            dest_folder_path: c.length ? c[0] : r,
            keep_dir: !0,
            create_subfolder: t
        };
        f.file_path = f.file_path, f.dest_folder_path = f.dest_folder_path;
        var m = {
            destId: i,
            blMultiExtract: u,
            gZipArr: h,
            gDestArr: c,
            file_path: f.file_path,
            pFiles: d
        };
        SYNO.API.currentManager.requestAPI("SYNO.FileStation.Extract", "start", "2", f, function(e, t, i) {
            this.onExtractSendDone(e, t, i, m)
        }, this)
    },
    Share: function(e) {
        this.SharingDialog = new SYNO.FileStation.SharingDialog({
            owner: this.owner,
            webfm: this.webfm,
            paths: e,
            enableListUserGrp: this.webfm.enableListUserGrp
        }), this.SharingDialog.show()
    },
    FileRequest: function(e) {
        this.FileRequestDialog = new SYNO.FileStation.FileRequestDialog({
            owner: this.owner,
            webfm: this.webfm,
            paths: e
        }), this.FileRequestDialog.show()
    },
    Property: function(e, t, i) {
        var o = {},
            n = SYNO.webfm.utils.IsShareForceRO(this.webfm.dirTree, e[0].get("path"));
        if (this.webfm.getCurrentSource() === SYNO.webfm.utils.source.remotes) {
            var s = this.webfm.remoteSearchDS.search_taskid;
            s && Ext.apply(o, {
                search_taskid: s
            })
        }
        var r = -1 !== e[0].data.real_path.indexOf("Gluster"),
            a = new SYNO.FileStation.PropertyDialog({
                owner: this.owner,
                savePropertyExtParams: o,
                rec: e,
                userId: t,
                privilegeType: this.getFilesPrivilegeType(e, i),
                source: i || this.webfm.getCurrentSource(),
                isShareForceRO: n,
                hideAdvPermPanel: r
            });
        a.mon(a, "callback", this.onPropertySendDone, this, {
            single: !0
        }), a.load()
    },
    getFilesPrivilegeType: function(e, t) {
        function i(e) {
            var t = e,
                i = t.indexOf("/", 1);
            if (SYNO.webfm.VFS.isVFSPath(e)) return s.posix;
            i > 0 && (t = t.substr(0, i));
            var o = n.dirTree.getNodeById(SYNO.webfm.utils.source.remote + t);
            return null === o ? s.none : o.attributes.isACLPrivilege ? s.acl : s.posix
        }
        var o, n = this.webfm,
            s = SYNO.SDS.Share.PropertyDialogEnum.privilegeType;
        if (_S("diskless") || SYNO.webfm.utils.isLocalSource(t || this.webfm.getCurrentSource())) return s.none;
        var r = i(e[0].get("file_id"));
        if (r === s.acl) return e.length > 1 ? s.none : s.acl;
        if (r === s.posix) {
            if (this.webfm.getCurrentSource() === SYNO.webfm.utils.source.remote) return s.posix;
            for (o = 0; o < e.length; ++o)
                if (i(e[o].get("file_id")) !== s.posix) return s.none;
            return s.posix
        }
        return s.none
    },
    onPropertySendDone: function(e, t, i) {
        var o, n = _WFT("property", "error_save_property");
        if (!0 !== e.is_acl)
            if (t)
                if (i.running) {
                    o = Ext.apply({
                        srcIdArr: e.nodeIdArr
                    }, e.params);
                    var s = this.owner.addWebAPITask({
                        id: i.taskid,
                        interval: 1e3,
                        api: "SYNO.FileStation.Property",
                        method: "status",
                        version: 1,
                        params: {
                            taskid: i.taskid
                        },
                        callback: function(e, t, i, n) {
                            e && !0 === t.finished && s.stop(), this.onPropertyDone(n, e, t, o)
                        },
                        scope: this
                    });
                    this.showWait(_WFT("filetable", "filetable_properties"), _WFT("common", "saving"), this.onPropertyCancel.createDelegate(this, [i, o, s])), s.start(!1)
                } else this.fireEvent("refreshTreeNode", void 0, !0);
        else i && (n = _WFT(i.section, i.key)), this.showMsg(_WFT("filetable", "filetable_properties"), n);
        else if (t) {
            if (Ext.isDefined(i.task_id)) {
                o = Ext.apply({
                    srcIdArr: e.nodeIdArr
                }, e.params);
                var r = this.owner.pollReg({
                    webapi: {
                        api: "SYNO.Core.ACL",
                        method: "status",
                        version: 1,
                        params: {
                            task_id: i.task_id
                        }
                    },
                    interval: 3,
                    immediate: !0,
                    status_callback: function(e, t, i) {
                        e && !0 !== t.finished || this.owner.pollUnreg(r), this.onPropertyDone(i, e, t, o)
                    },
                    scope: this
                });
                this.showWait(_WFT("filetable", "filetable_properties"), _WFT("common", "saving"), this.onPropertyCancelACL.createDelegate(this, [i, o, r]))
            }
        } else Ext.isDefined(i.code) && (n = SYNO.API.getErrorString(i.code)), this.showMsg(_WFT("filetable", "filetable_properties"), n)
    },
    onPropertyCancelACL: function(e, t, i) {
        this.owner.pollUnreg(i), this.owner.sendWebAPI({
            api: "SYNO.Core.ACL",
            version: 1,
            method: "stop",
            params: {
                task_id: e.task_id
            },
            callback: function(e, i, o) {
                this.onPropertyDone(o, e, i, t)
            },
            scope: this
        })
    },
    onPropertyCancel: function(e, t, i) {
        i.stop(), this.owner.sendWebAPI({
            api: "SYNO.FileStation.Property",
            method: "stop",
            version: 1,
            params: {
                taskid: e.taskid
            },
            callback: function(e, i, o, n) {
                this.onPropertyDone(n, e, i, t)
            },
            scope: this
        })
    },
    onPropertyDone: function(e, t, i, o) {
        var n, s, r, a = o.srcIdArr;
        if (!t || i && i.result && "fail" == i.result) i.hasOwnProperty("code") ? this.showMsg("", SYNO.API.Errors.core[i.code] || _T("error", "error_error_system")) : i.errno || i.errItems ? this.showErrItems(_WFT("filetable", "filetable_properties"), t, i, e) : this.showMsg(_WFT("filetable", "filetable_properties"), _WFT("property", "error_save_property"));
        else if (i && !i.finished) {
            if (i.applyPath || i.applypath) return s = i.applyPath || i.applypath, s.length > 58 && (r = s.substr(s.lastIndexOf("/"), 55), r = "..." + r, r.length <= 58 && (r = s.substr(0, 58 - r.length) + r), s = r), n = _WFT("common", "saving") + "<br>" + s, void this.updateWait(n)
        } else this.hideWait(), this.fireEvent("refreshTreeNode", a, !0), Ext.isDefined(o.search_taskid) && this.webfm.refreshSearhGrid(Ext.decode(o.search_taskid));
        e && e.task_id && this.owner.sendWebAPI({
            api: "SYNO.Core.ACL",
            version: 1,
            method: "stop",
            params: {
                task_id: e.task_id
            },
            scope: this
        })
    },
    SaveFav: function() {
        var e = [],
            t = [];
        Ext.each(this.webfm.dirTree.getNodeById("fm_fav_root").childNodes, function(i) {
            var o = i.attributes;
            t.push(o.name), e.push(o.path)
        }, this), this.resetCTNode(), this.showProgress(_WFT("favorite", "my_favorite"), _WFT("common", "saving"), null), this.owner.addWebAPITask({
            single: !0,
            api: "SYNO.FileStation.Favorite",
            method: "replace_all",
            version: 2,
            params: {
                path: e,
                name: t
            },
            callback: function(e, t, i) {
                var o;
                this.hideProgress(), e || (o = SYNO.webfm.utils.getWebAPIErr(e, t, i), this.owner.getMsgBox().alert(_WFT("favorite", "my_favorite"), o), this.webfm.refreshFavTreeNode())
            },
            scope: this
        }).start(!0)
    },
    AddFav: function(e, t) {
        if (e && !(e.length > 1) && e[0].get("isdir")) {
            var i = this.webfm.dirTree.getNodeById("fm_fav_root");
            if (i.childNodes && i.childNodes.length > 255) return void this.owner.getMsgBox().alert(_WFT("favorite", "add_favorite"), _WFT("favorite", "over_limit"));
            this.FavDialog && !this.FavDialog.isDestroyed || (this.FavDialog = new SYNO.FileStation.FavDialog({
                owner: this.owner,
                RELURL: this.RELURL
            }));
            var o = this.FavDialog;
            o.mon(o, "hide", function() {
                this.resetCTNode()
            }, this, {
                single: !0
            }), o.mon(o, "callback", function() {
                this.webfm.refreshFavTreeNode()
            }, this, {
                single: !0
            });
            var n = t || {};
            o.setName(e[0].get("filename")), o.setFavDir(e[0].get("file_id")), o.setParams(n), o.onAddFav()
        }
    },
    RenameFav: function(e, t) {
        if (e && t) {
            this.FavDialog && !this.FavDialog.isDestroyed || (this.FavDialog = new SYNO.FileStation.FavDialog({
                owner: this.owner,
                RELURL: this.RELURL
            }));
            var i = this.FavDialog;
            i.mon(i, "hide", function() {
                this.resetCTNode()
            }, this, {
                single: !0
            }), i.mon(i, "callback", function() {
                this.webfm.refreshFavTreeNode()
            }, this, {
                single: !0
            }), i.setName(t), i.setFavDir(e), i.onEditFav()
        }
    },
    DelFav: function(e, t) {
        this.resetCTNode(), e && t && this.owner.getMsgBox().confirm(_WFT("favorite", "del_favorite"), _WFT("favorite", "del_favorite_confirm"), function(t) {
            "yes" == t && (this.showProgress(_WFT("favorite", "del_favorite"), _WFT("filetable", "filetable_deleting"), null), this.owner.addWebAPITask({
                single: !0,
                api: "SYNO.FileStation.Favorite",
                method: "delete",
                version: 2,
                params: {
                    path: e
                },
                callback: function(e, t, i) {
                    if (this.hideProgress(), e) this.webfm.refreshFavTreeNode();
                    else {
                        var o = SYNO.webfm.utils.getWebAPIErr(e, t, i);
                        this.owner.getMsgBox().alert(_WFT("favorite", "del_favorite"), o)
                    }
                },
                scope: this
            }).start(!0))
        }, this)
    },
    CleanFav: function() {
        this.resetCTNode(), this.showProgress(_WFT("favorite", "clean_favorite"), _WFT("favorite", "cleaning"), null), this.owner.addWebAPITask({
            single: !0,
            api: "SYNO.FileStation.Favorite",
            method: "clear_broken",
            version: 2,
            callback: function(e, t, i) {
                if (this.hideProgress(), e) this.webfm.refreshFavTreeNode();
                else {
                    var o = SYNO.webfm.utils.getWebAPIErr(e, t, i);
                    this.owner.getMsgBox().alert(_WFT("favorite", "clean_favorite"), o)
                }
            },
            scope: this
        }).start(!0)
    },
    showWait: function(e, t, i) {
        var o = null;
        i && (o = {
            ok: _WFT("common", "common_cancel")
        }), this.owner.getMsgBox().show({
            title: e,
            msg: t,
            width: 420,
            wait: !0,
            closable: !1,
            buttons: o,
            fn: i || null,
            hideDlg: !0,
            scope: this
        })
    },
    updateWait: function(e) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().updateText(e)
    },
    hideWait: function() {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide()
    },
    showProgress: function(e, t, i) {
        var o = null;
        i && (o = {
            ok: _WFT("common", "common_cancel")
        }), this.owner.getMsgBox().show({
            title: e,
            msg: t,
            width: 300,
            progress: !0,
            closable: !1,
            buttons: o,
            fn: i || null,
            hideDlg: !0,
            scope: this
        })
    },
    updateProgress: function(e, t) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().updateProgress(e, t)
    },
    hideProgress: function() {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide()
    },
    addLocalTask: function(e, t, i) {
        var o, n, s, r = null;
        "copy" === e || "move" === e ? (r = _WFT("common", "calculating"), "copy" === e ? (o = {
            section: "filetable",
            key: "filetable_copy"
        }, n = {
            section: "filetable",
            key: "filetable_copying"
        }) : (o = {
            section: "filetable",
            key: "filetable_move"
        }, n = {
            section: "filetable",
            key: "filetable_moving"
        }), s = "MVCP") : "delete" === e && (o = {
            section: "filetable",
            key: "filetable_delete"
        }, n = {
            section: "filetable",
            key: "filetable_deleting"
        }, s = "Delete");
        var a = {
            owner: t.owner || !1,
            msgCfg: {
                progress: !0,
                msg: r,
                sinkable: !0,
                draggable: !0
            },
            actionStr: o,
            actingStr: n,
            actionCfg: {
                action: e,
                starttime: (new Date).getTime() / 1e3
            },
            webfm: this.webfm
        };
        Ext.apply(a.bkTaskCfg, t.bkTaskCfg || {}), Ext.apply(a.msgCfg, t.msgCfg || {}), Ext.apply(a.actionCfg, t.actionCfg || {}), new(Ext.getClassByName(String.format("SYNO.FileStation.LocalAction.{0}", s)))(a, i)
    },
    addBkWebAPITask: function(e, t, i) {
        var o, n, s, r, a, l = !0,
            h = null;
        "copy" === e || "move" === e ? (o = "SYNO.FileStation.CopyMove", n = "3", h = _T("background_task", "task_waiting"), "copy" === e ? (s = {
            section: "filetable",
            key: "filetable_copy"
        }, r = {
            section: "filetable",
            key: "filetable_copying"
        }) : (s = {
            section: "filetable",
            key: "filetable_move"
        }, r = {
            section: "filetable",
            key: "filetable_moving"
        }), a = "MVCP") : "delete" === e ? (o = "SYNO.FileStation.Delete", n = "1", h = _WFT("common", "calculating"), s = {
            section: "filetable",
            key: "filetable_delete"
        }, r = {
            section: "filetable",
            key: "filetable_deleting"
        }, a = "Delete") : "extract" === e ? (o = "SYNO.FileStation.Extract", n = "2", s = {
            section: "filetable",
            key: "filetable_extract"
        }, r = {
            section: "extract",
            key: "extracting"
        }, a = "Extract") : "compress" === e && (o = "SYNO.FileStation.Compress", n = "3", l = !0, s = {
            section: "filetable",
            key: "filetable_compress"
        }, r = {
            section: "filetable",
            key: "filetable_compressing"
        }, a = "Compress");
        var c = {
            owner: t.owner || !1,
            bkTaskCfg: {
                api: o,
                version: n
            },
            msgCfg: {
                progress: l,
                msg: h,
                sinkable: !0,
                draggable: !0,
                blMsgMinimized: t.bkTaskCfg.blMsgMinimized
            },
            actionStr: s,
            actingStr: r,
            actionCfg: {
                action: e,
                starttime: (new Date).getTime() / 1e3
            },
            webfm: this.webfm
        };
        Ext.apply(c.bkTaskCfg, t.bkTaskCfg || {}), Ext.apply(c.msgCfg, t.msgCfg || {}), Ext.apply(c.actionCfg, t.actionCfg || {}), new(Ext.getClassByName(String.format("SYNO.FileStation.Action.{0}", a)))(c, i, t.extra)
    },
    isOwnerDestroyed: function() {
        return this.owner && this.owner.isDestroyed
    },
    showMsg: function(e, t) {
        this.isOwnerDestroyed() || !this.owner.isVisible() ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", e, t) : this.MountRemoteCIFSDialog && !this.MountRemoteCIFSDialog.isDestroyed ? this.MountRemoteCIFSDialog.getMsgBox().alert(e, t) : this.MountRemoteNFSDialog && !this.MountRemoteNFSDialog.isDestroyed ? this.MountRemoteNFSDialog.getMsgBox().alert(e, t) : this.MountISODialog && !this.MountISODialog.isDestroyed ? this.MountISODialog.getMsgBox().alert(e, t) : this.owner.getMsgBox().alert(e, t)
    }
}), SYNO.FileStation.PasteConfirmDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    constructor: function(e, t, i) {
        this.callback = t.cb;
        var o, n = t.filenames,
            s = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite");
        if (1 == n.length) {
            var r = n[0];
            r = r.substring(r.lastIndexOf(Ext.isWindows ? "\\" : "/") + 1), o = String.format(_WFT("filetable", "paste_one_file"), Ext.util.Format.ellipsis(r, 50))
        } else o = String.format(_WFT("filetable", "paste_files"), n.length);
        i && "" !== i && (o += "<br>(" + i + ")");
        var a = {
            owner: e.owner,
            resizable: !1,
            minimizable: !1,
            maximizable: !1,
            stateful: !1,
            buttonAlign: "left",
            width: 500,
            height: i && "" !== i ? 320 : 280,
            footer: !0,
            cls: "x-window-dlg",
            title: _WFT("filetable", "filetable_paste"),
            items: [this.panel = new SYNO.ux.FormPanel({
                items: [{
                    xtype: "syno_displayfield",
                    value: o
                }, {
                    xtype: "syno_checkbox",
                    itemId: "option",
                    checked: s,
                    boxLabel: _WFT("filetable", "upload_copy_auto_overwrite")
                }]
            })],
            fbar: new Ext.Toolbar({
                defaultType: "syno_button",
                items: [{
                    text: _WFT("filetable", "filetable_skip"),
                    scope: this,
                    handler: function() {
                        this.onAction(!1)
                    }
                }, "->", {
                    text: _WFT("common", "cancel"),
                    scope: this,
                    handler: function() {
                        this.close()
                    }
                }, {
                    text: _WFT("filetable", "filetable_overwrite"),
                    scope: this,
                    btnStyle: "blue",
                    handler: function() {
                        this.onAction(!0)
                    }
                }],
                enableOverflow: !1
            }),
            keys: [{
                key: 27,
                fn: this.close,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                }
            }
        };
        SYNO.FileStation.PasteConfirmDialog.superclass.constructor.call(this, a)
    },
    onAction: function(e) {
        var t = this.panel.getComponent("option").getValue();
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite", t), this.action(e), this.close()
    },
    action: function(e) {
        this.callback.fn.apply(this.callback.scope, [e])
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.MainPanel = function(e) {
    var t = {
        layout: "border",
        border: !1,
        defaluts: {
            split: !0,
            fit: !0
        },
        viewConfig: {
            forceFit: !0
        },
        listeners: {
            afterrender: {
                fn: function() {
                    this.mon(this.dirTree, "flexcrollInitDone", this.registerScrollEl, this)
                }
            },
            afterlayout: {
                fn: function(e) {
                    this.saveInitPath(), SYNO.webfm.SmartDDMVCPMgr.bindHotKey(this), !0 === this.blJava && AppletProgram.updateFileStation(this)
                },
                scope: this,
                single: !0
            },
            beforedestroy: {
                fn: this.unregisterScrollEl,
                scope: this
            }
        }
    };
    Ext.apply(t, e), this.addEvents({
        onNodeClick: !0
    }), SYNO.FileStation.MainPanel.superclass.constructor.call(this, t)
}, Ext.extend(SYNO.FileStation.MainPanel, Ext.Panel, {
    initDefVal: function() {
        this.historyPath = [], this.historyIndex = -1, this.historyCnt = 0, this.historyBackMenu = this.createHistoryMenu(), this.historyNextMenu = this.createHistoryMenu(), this.showContent = "all", this.displayNum = !Ext.isIE || Ext.isModernIE ? 1e3 : 250, this.maxUploadTask = 1e3, this.blAfterLayout = !1, this.currentSource = "remote", this.ajaxCounter = 0, this.dragDropDownloadURL = null
    },
    initJava: function() {
        this.blJava && AppletProgram.setJava(this.RELURL)
    },
    updateLocalEnv: function(e) {
        this.owner && this.owner.isDestroyed || (1 === e ? this.updateLocalEnvDefer() : (this.blJava = !1, this.updateUploader()))
    },
    registerOwner: function(e) {
        this.owner = e, this.getUserGroups()
    },
    registerFileAction: function() {
        this.FileAction = new SYNOFileStationFileAction({
            RELURL: this.RELURL,
            owner: this.owner,
            webfm: this
        }), this.mon(this.FileAction, "refreshTreeNode", this.refreshTreeNode, this), this.mon(this.FileAction, "setHighlightEntry", this.setHighlightEntry, this), this.mon(this.FileAction, "refreshVTreeNode", this.refreshVTreeNode, this), this.mon(this.FileAction, "refreshRTreeNode", this.refreshRTreeNode, this), this.mon(this.FileAction, "refreshVFSTreeNode", this.refreshVFSTreeNode, this), this.mon(SYNO.SDS.StatusNotifier, "filechanged", this.refreshTreeNode, this)
    },
    registerScrollEl: function() {
        var e = this.dirTree.body;
        e.ddScrollConfig = {
            vthresh: 50,
            hthresh: -1,
            frequency: 100,
            increment: 10
        }, SYNO.FileStation.TreeScrollMgr.register(e)
    },
    unregisterScrollEl: function() {
        SYNO.FileStation.TreeScrollMgr.unregister(this.dirTree.body)
    },
    initButtons: function() {
        var e = SYNO.FileStation.Comp;
        this.btnUpBrowserAction = e.cUploadLocal(Ext.Action, !0, this), this.btnUpSubMenuAction = e.cUploadRemote(Ext.Action, !0, this), this.btnTreeUpBrowserAction = e.cUploadLocal(Ext.Action, !0, this), this.btnTreeUpSubMenuAction = e.cUploadRemote(Ext.Action, !0, this), this.btnTreeDownSubMenuAction = e.cDownloadMenu(Ext.Action, !0, this), this.btnTreeMVCPToSubMenuAction = e.cMVCPToMenu(Ext.Action, !0, this)
    },
    initNavArea: function(e) {
        Ext.apply(e, {
            RELURL: this.RELURL,
            webfm: this
        }), this.copymoveCtxMenu = new SYNO.FileStation.CopyMoveCtxMenu(e), this.treeCtxMenu = new SYNO.FileStation.TreeCtxMenu(e), this.gridCtxMenu = new SYNO.FileStation.GridCtxMenu(e), this.addManagedComponent(this.copymoveCtxMenu), this.addManagedComponent(this.treeCtxMenu), this.addManagedComponent(this.gridCtxMenu)
    },
    getCurrentSource: function() {
        return this.currentSource
    },
    setCurrentSource: function(e) {
        this.currentSource = e
    },
    getCurrentDir: function() {
        return this.currentDir
    },
    setCurrentDir: function(e) {
        this.currentDir = e
    },
    getCurrDirSubFdr: function(e, t, i) {
        if (t && "" !== t) {
            var o = this.getCurrentDir();
            SYNO.webfm.utils.source.remotes !== this.getCurrentSource() || Ext.isEmpty(i) || (o = i), e.setStatusBusy(_T("common", "loading")), SYNO.API.currentManager.requestAPI("SYNO.FileStation.List", "list", 2, {
                action: "list",
                offset: 0,
                limit: 1e3,
                pattern: t,
                sort_by: "name",
                sort_direction: "ASC",
                filetype: "dir",
                folder_path: o,
                check_dir: !0
            }, function(t, i, o) {
                var n;
                e.clearStatusBusy(), t && i ? void 0 !== e.getCurrDirSubFdrCallBack && e.getCurrDirSubFdrCallBack(i.files) : n = _WFT("error", "error_error_system"), n && (n = SYNO.webfm.utils.getWebAPIErr(t, i, o), e.getMsgBox().alert(e.title, n))
            }, this)
        }
    },
    getUserGroups: function() {
        this.owner.sendWebAPI({
            api: "SYNO.FileStation.Info",
            method: "get",
            version: 1,
            params: {},
            callback: function(e, t, i) {
                this.isDestroyed || (e ? this.onGetUserGrpDone(e, t, i) : this.owner.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErrStr(!1, t)))
            },
            scope: this
        })
    },
    onGetUserGrpDone: function(e, t, i) {
        this.ajaxCounter++, this.userId = t.uid, this.userGroup = t.items, this.mountConfig = t.support_virtual, this.supportSharing = t.support_sharing, this.supportFileRequest = t.support_file_request, this.supportVFS = t.support_vfs, this.enableListUserGrp = t.enable_list_usergrp, this.systemCodepage = t.system_codepage, this.supportSharing ? this.btnToolsMenu && this.btnToolsMenu.show() : this.onHideSharingBtns(), this.supportVFS && this.btnToolsMenu && (this.btnToolsMenu.show(), this.btnToolsMenu.menu.showRemoteConnectItem()), "yes" === _D("supportmount") && this.mountConfig && (this.mountConfig.enable_remote_mount || this.mountConfig.enable_iso_mount ? (this.btnToolsMenu && this.btnToolsMenu.show(), this.btnToolsMenu.menu.showMountItem(), this.btnUmount && this.btnUmount.show()) : (this.btnToolsMenu.menu.hideMountItem(), this.btnUmount && this.btnUmount.hide(), this.gridCtxMenu.items.get("gc_umount") && this.gridCtxMenu.remove("gc_umount"), this.treeCtxMenu.items.get("gc_umount") && this.treeCtxMenu.remove("gc_umount")), this.mountConfig.enable_remote_mount ? _S("is_admin") || this.dirTree.getNodeById("remote/home") ? this.btnMountRemote && this.btnMountRemote.show() : this.btnMountRemote.hide() : this.btnMountRemote && this.btnMountRemote.hide(), this.mountConfig.enable_iso_mount ? (this.btnMountISO && this.btnMountISO.show(), this.gridCtxMenu.items.get("gc_mount_iso") && this.gridCtxMenu.items.get("gc_mount_iso").show()) : (this.btnMountISO && this.btnMountISO.hide(), this.gridCtxMenu.items.get("gc_mount_iso") && this.gridCtxMenu.remove("gc_mount_iso")), SYNO.webfm.utils.ShowHideMenu(this.btnToolsMenu.menu.items)), 2 == this.ajaxCounter && this.initJava()
    },
    getExtractFormat: function() {
        return !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable7zextract") ? ".7z" : ".zip"
    },
    getSuggestDLNameWithOne: function(e, t) {
        var i = this.getExtractFormat();
        return t ? e + i : e
    },
    getSuggestDLName: function(e) {
        var t = this.getExtractFormat();
        if (1 == e.length) return this.getSuggestDLNameWithOne(e[0].get("filename"), e[0].get("isdir"));
        var i = e[0].get("file_id");
        i = i.substr(0, i.lastIndexOf("/"));
        var o = i.lastIndexOf("/");
        return -1 != o && (i = i.substr(o + 1)), i + t
    },
    getSuggestZipName: function(e) {
        var t, i, o = this.getExtractFormat();
        return 1 == e.length ? e[0].get("isdir") ? e[0].get("filename") + o : (i = e[0].get("filename"), t = i.lastIndexOf("."), t > 0 && (i = i.substr(0, t)), i + o) : (i = this.getCurrentDir(), t = i.lastIndexOf("/"), -1 != t && (i = i.substr(t + 1)), i + ".zip")
    },
    updateHybridShares: function() {
        SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.C2FS.Application") && (this.sendWebAPI({
            api: "SYNO.C2FS.Share",
            async: !1,
            timeout: 10,
            version: 1,
            method: "list",
            scope: this,
            callback: function(e, t) {
                if (!e) return !1;
                this.hybridShares = {};
                for (var i in t) t.hasOwnProperty(i) && (this.hybridShares[i] = "disconnected" !== t[i].status[0])
            }
        }), this.dirTree && this.dirTree.remoteLoader && this.dirTree.remoteLoader.updateHybridShares())
    },
    onOpenWinAction: function() {
        var e, t, i = this.activeView.getSelectionModel(),
            o = [],
            n = [];
        if (_S("demo_mode")) return void this.owner.getMsgBox().alert(_JSLIBSTR("uicommon", "error_demo"), _JSLIBSTR("uicommon", "error_demo"));
        if (!i.hasSelection()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_openwin"), _WFT("filetable", "filetable_select_one"));
        e = i.getSelections();
        var s, r;
        if (SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) {
            for (t = 0; t < e.length; t++) o[t] = e[t].id;
            s = {
                files: o,
                action: "openfile"
            }, r = AppletProgram.action(s), AppletProgram.checkResponse(r, this)
        } else {
            for (t = 0; t < e.length; t++) e[t].get("isdir") || n.push(e[t]);
            if (!this.onCheckVFSAction("download", n)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_openwin"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("download", n, !1, !1)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_openwin"), _WFT("error", "error_privilege_not_enough"));
            var a, l, h, c, d = SYNO.webfm.utils.getTicketID({
                api: "SYNO.FileStation.Download",
                methods: ["download"]
            });
            for (t = 0; t < n.length; t++) {
                if (a = n[t].get("filename"), l = n[t].get("file_id"), SYNO.webfm.VFS.isGDrivePath(l) && n[t].data.description && n[t].data.description.alternateLink) c = n[t].data.description.alternateLink;
                else if (SYNO.webfm.VFS.isOneDrivePath(l) && n[t].data.description && n[t].data.description.link) c = n[t].data.description.link;
                else {
                    h = SYNO.webfm.utils.replaceDLNameSpecChars(a);
                    c = String.format('fbdownload/{0}?tid="{1}"&mode=open&dlink="{2}"&stdhtml=true', encodeURIComponent(h), encodeURIComponent(d), SYNO.webfm.utils.bin2hex(l)), c = Ext.urlAppend(c), n[t].get("isdir") || "exe" !== n[t].get("type").toLowerCase() || (c += "&f=.exe")
                }
                window.open(c, "_blank")
            }
        }
    },
    checkFtpModifyRight: function(e) {
        return this.checkNoFtpRight(e, [SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST, SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY])
    },
    checkFTPDownloadRight: function(e) {
        return this.checkNoFtpRight(e, [SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST, SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD])
    },
    checkNoFtpRight: function(e, t) {
        var i = 0;
        return !(!0 === _S("is_admin") || !e || "fm_search_root" == e.attributes.id) && (i = "fm_root" != e.parentNode.id ? SYNO.webfm.utils.getShareFtpRight(this.dirTree, e) : e.attributes.ftpright, Ext.isArray(t) || (t = [t]), this.checkFtpRight(i, t))
    },
    checkFTPDownloadRightByPath: function(e) {
        return this.checkNoFtpRightByPath(e, [SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST, SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD])
    },
    checkNoFtpRightByPath: function(e, t) {
        var i = 0;
        return !0 === _S("is_admin") || (i = SYNO.webfm.utils.getShareFtpRightByPath(this.dirTree, e)), Ext.isArray(t) || (t = [t]), this.checkFtpRight(i, t)
    },
    checkFtpRight: function(e, t) {
        var i = !1;
        return Ext.each(t, function(t) {
            if (i |= e & t) return !1
        }), i
    },
    checkUploadRight: function(e) {
        if (!e || !0 === _S("is_admin") || "true" === _S("domainUser")) return !0;
        var t, i = null,
            o = {},
            n = !1;
        return "fm_root" != e.parentNode.id ? (o = {
            folderRight: e.attributes.right,
            uid: e.attributes.uid,
            gid: e.attributes.gid
        }, i = SYNO.webfm.utils.getShareRight(this.dirTree, e)) : (i = e.attributes.right, n = !0), !!SYNO.webfm.utils.checkShareRight(i, SYNO.webfm.utils.RW) && !(!n && (t = {
            right: o.folderRight,
            needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Upload
        }, !SYNO.webfm.utils.checkFileRight(t)))
    },
    onCreateFolder: function() {
        return this.onCheckVFSAction("create", this.getCurrentDir()) ? this.onCheckPrivilege("create", null, !1, !1) ? void this.FileAction.Create(this.getCurrentDir()) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_privilege_not_enough")) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "not_support"))
    },
    onLocalUpload: function() {
        var e, t;
        if (e = this.activeView.getSelectionModel(), !e.hasSelection()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("filetable", "filetable_select_one"));
        t = e.getSelections(), this.FileAction.localUpload(t, this.userId, this.userGroup)
    },
    getUploadPath: function(e) {
        var t, i = e && e.parentMenu ? e.parentMenu.parentMenu ? e.parentMenu.parentMenu.itemId : e.parentMenu.itemId : void 0;
        if ("rTreeCtx" === i) {
            if (!this.currCTNodeTmp) return;
            this.currCTNode = this.currCTNodeTmp, this.currCTAction = e.itemId, t = this.currCTNode.attributes.path
        } else if ("rGridCtx" === i) {
            var o = this.activeView.getSelectionModel();
            if (o.hasSelection()) {
                var n = o.getSelections();
                t = n[0].get("file_id"), (n.length > 1 || !n[0].get("isdir")) && (t = t.substr(0, t.lastIndexOf("/")))
            } else t = this.getCurrentDir()
        } else t = this.getCurrentDir();
        return t
    },
    onDisableUpButton: function(e) {
        this.btnRemoteUpload.setDisabled(e), this.btnLocalUpload.setDisabled(e), this.blUploadSubMenu ? (this.btnTreeUpSubMenuAction.setHidden(e), this.btnUpSubMenuAction.setHidden(e)) : (this.btnUpBrowserAction.setHidden(e), this.btnTreeUpBrowserAction.setHidden(e))
    },
    onShowUpSubMenu: function(e) {
        this.btnRemoteUpload.setVisible(e), this.btnUpSubMenuAction.setHidden(!e), this.btnLocalUpload.setVisible(!e), this.btnUpBrowserAction.setHidden(e), this.btnTreeUpBrowserAction.setHidden(e), this.btnTreeUpSubMenuAction.setHidden(!e), this.blUploadSubMenu = e
    },
    onShowDownSubMenu: function(e) {
        this.btnDownload.setVisible(!e), this.btnDownloadMenu.setVisible(e), this.btnMultiDownloadMenu.setVisible(!e);
        var t = this.gridCtxMenu.items,
            i = t.get("gc_download"),
            o = t.get("gc_download_menu"),
            n = t.get("gc_multidownload_menu");
        i.setVisible(!e), o.setVisible(e), n.setVisible(!e), this.btnTreeDownSubMenuAction.setHidden(e), this.treeCtxMenu.items.get("gc_download").setVisible(!e)
    },
    onBrowserUploadAction: function(e, t) {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
        if (this.getCurrentSource().substr(0, 5) === SYNO.webfm.utils.source.local) this.onLocalUpload();
        else {
            var i, o, n;
            if (!this.onCheckVFSAction("upload", null, this.getUploadPath(e))) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("upload", null, !1, !1)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough"));
            i = this.dirTree.getSelectionModel(), o = i.getSelectedNode(), n = this.checkFtpModifyRight(o), this.FileAction.BrowserUpload(this.getUploadPath(e), n)
        }
    },
    onUploadItemClick: function(e, t) {
        var i = !1;
        switch (e.itemId) {
            case "upload_overwrite":
                i = !0;
                break;
            case "upload_skip":
                break;
            default:
                return
        }
        this.onUploadAction(i, this.getUploadPath(e))
    },
    onUploadAction: function(e, t) {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
        if (this.getCurrentSource().substr(0, 6) === SYNO.webfm.utils.source.remote) {
            if (!this.onCheckVFSAction("upload", null, t)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("upload", null, !1, !1)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough"));
            1 == AppletProgram.blJavaPermission && AppletProgram.showFileDialog(this, {
                action: "upload",
                path: t,
                overwrite: e
            })
        } else this.onLocalUpload()
    },
    onBeforeDownloadAction: function(e) {
        var t, i = this.activeView.getSelectionModel();
        return i.hasSelection() ? (t = i.getSelections(), this.onCheckVFSAction("download", t) ? !1 === e || this.onCheckPrivilege("download", t, !1, !1) ? t : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough")) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"))) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("filetable", "filetable_select_one"))
    },
    onDownloadAction: function(e, t) {
        var i, o, n = e && e.parentMenu ? e.parentMenu.parentMenu ? e.parentMenu.parentMenu.itemId : e.parentMenu.itemId : void 0,
            s = [],
            r = [];
        if ("rTreeCtx" === n) {
            if (!this.currCTNodeTmp) return;
            s = this.getRecByTreeNode(e);
            var a = s[0].get("file_id");
            if (o = s[0].get("filename") + ".zip", r.push(a), !this.onCheckVFSAction("download", s)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("download", s, !1, !0)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"))
        } else {
            if (Ext.isEmpty(s = this.onBeforeDownloadAction())) return;
            if (1 == s.length && !s[0].get("isdir")) return void this.FileAction.DirectDownload(s[0], t);
            for (i = 0; i < s.length; i++) r.push(s[i].get("file_id"));
            o = this.getSuggestDLName(s)
        }
        this.FileAction.Download(r, o)
    },
    onMultiDownload: function(e, t) {
        var i = this.onBeforeDownloadAction();
        Ext.isEmpty(i) || this.FileAction.onMultiDownload(i)
    },
    onJavaDownloadAction: function(e, t) {
        var i = [],
            o = [];
        if ("rTreeCtx" === (e && e.parentMenu ? e.parentMenu.parentMenu ? e.parentMenu.parentMenu.itemId : e.parentMenu.itemId : void 0)) {
            if (!this.currCTNodeTmp) return;
            if (o = this.getRecByTreeNode(e), !this.onCheckVFSAction("download", o)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("download", o, !1, !0)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"))
        } else if (Ext.isEmpty(o = this.onBeforeDownloadAction())) return;
        o.forEach(function(e) {
            i.push(e.data)
        }), AppletProgram.showFileDialog(this, {
            action: "download",
            files: i,
            overwrite: t
        })
    },
    getRecByTreeNode: function(e) {
        return this.currCTNode = this.currCTNodeTmp, this.currCTAction = e.itemId, this.getRecByTreeNodeAttr(this.currCTNode.attributes)
    },
    getRecByTreeNodeAttr: function(e) {
        var t = [],
            i = e.type,
            o = SYNO.webfm.utils.isLocalSource(i),
            n = o && Ext.isWindows ? "\\" : "/",
            s = e.path || "",
            r = e.real_path,
            a = SYNO.webfm.utils.getBaseName(s, n),
            l = e.uid,
            h = e.gid,
            c = e.right,
            d = e.isMountPoint,
            u = e.mountType;
        return t[0] = new Ext.data.Record({
            uid: l,
            gid: h,
            isdir: !0,
            fileprivilege: c,
            file_id: s,
            path: s,
            real_path: r,
            type: "",
            filename: a,
            isMountPoint: d,
            mountType: u
        }), t
    },
    onSelectAllRow: function() {
        var e = this,
            t = e.viewPanel.getEl(),
            i = this.activeDS;
        if (i.storetype === SYNO.webfm.utils.source.remotes) return void(i.blSearhDone ? e.activeView.getSelectionModel().selectAllRow() : this.findAppWindow().getToastBox.call(this.activeView, _WFT("search", "not_done"), !1, !1, {
            delay: 2500,
            offsetY: 32
        }));
        i.getTotalCount() !== i.getCount() && t.mask(), e.activeView.getSelectionModel().selectAllRow({
            callback: function() {
                e.isSelectAll = !0, e.paging.doRefresh(), t.unmask(), e.isSelectAll = !1
            },
            scope: e.paging
        })
    },
    onEnterPress: function(e, t) {
        var i, o, n = this.activeView,
            s = n.getSelectionModel();
        1 === s.getCount() && t.within(this.activeView.getContentTarget()) && (i = s.getSelected(), o = this.activeDS.indexOf(i), this.dblclick(n, o, null, t))
    },
    onSelectAllRowAction: function() {
        Ext.isMac && !this.cmdKeyDown || this.onSelectAllRow()
    },
    onRenameAction: function() {
        var e = this.activeView.getSelectionModel();
        if (!e.hasSelection()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("filetable", "filetable_select_one"));
        if (1 < e.getCount()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("filetable", "filetable_select_only_one"));
        var t = e.getSelections();
        return !0 === _S("demo_mode") ? void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _JSLIBSTR("uicommon", "error_demo")) : this.onCheckPrivilege("rename", t, !1, !1) ? this.onCheckVFSAction("rename", t) ? void this.FileAction.Rename(t) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "not_support")) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_privilege_not_enough"))
    },
    onViewHistoryAction: function() {
        var e = this.activeView.getSelectionModel();
        if (!e.hasSelection()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("filetable", "filetable_select_one"));
        if (1 < e.getCount()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("filetable", "filetable_select_only_one"));
        var t = e.getSelections();
        this.FileAction.ViewSnapshotHistory(t[0], this.owner)
    },
    onHistoryBack: function() {
        if (!(this.historyIndex <= 0)) {
            var e = this.historyIndex - 1;
            this.changeDirWithHistoryIndex(e)
        }
    },
    changeDirWithHistoryIndex: function(e) {
        this.historyIndex = e;
        var t = this.historyPath[this.historyIndex],
            i = !1;
        t.source !== this.getCurrentSource() && (this.switchSource(t.source), i = !0), (i || t.directory !== this.getCurrentDir()) && this.onChangeDir(t.directory, !0), this.historyBtnCheck(), this.updateAllHistoryMenu()
    },
    createHistoryMenu: function() {
        return new SYNO.ux.Menu({
            items: [],
            cls: "webfm-history-menu",
            noicon: !0,
            maxHeight: 290,
            listeners: {
                scope: this,
                click: function(e, t) {
                    this.changeDirWithHistoryIndex(t.historyIndex)
                }
            },
            showMenuWithButton: function(e) {
                var t = e.getXY();
                0 !== this.items.length && this.showAt([t[0] - 4, t[1] + e.getHeight() + 2])
            }
        })
    },
    updateAllHistoryMenu: function() {
        this.updateHistoryMenu({
            historyMenu: this.historyBackMenu,
            direction: -1,
            end: -1
        }), this.updateHistoryMenu({
            historyMenu: this.historyNextMenu,
            direction: 1,
            end: this.historyPath.length
        })
    },
    updateHistoryMenu: function(e) {
        var t, i;
        for (e.historyMenu.removeAll(), t = this.historyIndex + e.direction; t != e.end; t += e.direction) i = this.historyPath[t].directory, "remotesfm_search_root" === i && (i = _WFT("search", "search_results")), e.historyMenu.addItem({
            htmlEncode: !0,
            historyIndex: t,
            text: i
        })
    },
    onDeleteAction: function(e, t) {
        var i = this.activeView.getSelectionModel();
        if (!i.hasSelection()) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _WFT("filetable", "filetable_select_one"));
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _JSLIBSTR("uicommon", "error_demo"));
        var o, n = i.getSelections(),
            s = [],
            r = this.getCurrentSource();
        if (!SYNO.webfm.utils.isLocalSource(r)) {
            if (!this.onCheckVFSAction("delete", n)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _WFT("error", "not_support"));
            if (!this.onCheckPrivilege("delete", n, !1, !1)) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _WFT("error", "error_privilege_not_enough"))
        }
        t.stopEvent();
        var a, l = SYNO.webfm.utils.getPathSeparator(this.getCurrentSource());
        for (a = 0; a < n.length; a++) o = n[a].get("file_id"), s.push(o.substr(0, o.lastIndexOf(l)));
        this.FileAction.Delete(n, s, r)
    },
    getPasteRec: function(e) {
        var t, i = e && e.parentMenu ? e.parentMenu.parentMenu ? e.parentMenu.parentMenu.itemId : e.parentMenu.itemId : void 0,
            o = this.activeView.getSelectionModel();
        if (e === SYNO.webfm.utils.hotKey || "rToolbarCtx" === i || this.gridCtxMenu.blContainerMenu || !o.hasSelection() || o.getSelections().length > 1) {
            var n = this.dirTree.getNodeById(this.getCurrentSource() + this.getCurrentDir());
            if (!n) return;
            var s = n.attributes;
            t = new Ext.data.Record({
                uid: s.uid,
                gid: s.gid,
                isdir: !0,
                right: s.right,
                ftpright: s.ftpright,
                file_id: s.path,
                path: s.path,
                real_path: s.real_path
            })
        } else t = o.getSelected();
        return t
    },
    onPasteAction: function(e, t, i) {
        var o, n = _WFT("filetable", "filetable_paste"),
            s = this.getPasteRec(e);
        if (!s) return void this.owner.getMsgBox().alert(n, _WFT("filetable", "filetable_select_one"));
        if (!SYNO.FileStation.Clipboard.isEmpty()) {
            if (o = SYNO.FileStation.Clipboard.get(), !this.onCheckVFSAction(o.action, o.recs, s)) return void this.owner.getMsgBox().alert(n, _WFT("error", "not_support"));
            if (i && !t) {
                new SYNO.FileStation.PasteConfirmDialog({
                    owner: this.owner
                }, {
                    filenames: SYNO.FileStation.Clipboard.getFilenames(),
                    cb: {
                        fn: function(e) {
                            this.FileAction.Paste(s, e)
                        },
                        scope: this
                    }
                }, "").show()
            } else this.FileAction.Paste(s, t)
        }
    },
    onShortCutPasteAction: function(e, t, i) {
        Ext.isMac && !this.cmdKeyDown || this.onPasteAction(e, t, i)
    },
    onCutAction: function(e) {
        this.copySource = "", this.cutSource = this.currentSource, this.onMVCPAction(e, "move")
    },
    onShortCutCutAction: function(e) {
        Ext.isMac && !this.cmdKeyDown || (this.copySource = "", this.cutSource = this.currentSource, this.onMVCPAction(e, "move"))
    },
    onCopyAction: function(e) {
        this.cutSource = "", this.copySource = this.currentSource, this.onMVCPAction(e, "copy")
    },
    onShortCutCopyAction: function(e) {
        Ext.isMac && !this.cmdKeyDown || (this.cutSource = "", this.copySource = this.currentSource, this.onMVCPAction(e, "copy"))
    },
    onSharingManager: function() {
        this.SharingManager = new SYNO.FileStation.SharingManager.Manger({
            RELURL: this.RELURL,
            webfm: this,
            owner: this.owner
        }), this.SharingManager.open()
    },
    onMVCPAction: function(e, t) {
        if ("copy" == t || "move" == t) {
            var i, o, n, s = e.text;
            if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(s, _JSLIBSTR("uicommon", "error_demo"));
            if ("rTreeCtx" === (e && e.parentMenu ? e.parentMenu.parentMenu ? e.parentMenu.parentMenu.itemId : e.parentMenu.itemId : void 0)) {
                if (!this.currCTNodeTmp) return;
                i = this.getRecByTreeNode(e), o = this.currCTNode.attributes.type
            } else {
                var r = this.activeView.getSelectionModel();
                if (!r.hasSelection()) return void this.owner.getMsgBox().alert(s, _WFT("filetable", "filetable_select_one"));
                i = r.getSelections(), o = this.getCurrentSource(), r = this.dirTree.getSelectionModel(), n = r.getSelectedNode()
            }
            var a = SYNO.webfm.utils.isLocalSource(o);
            if (!this.onCheckVFSAction(t, i)) return void this.owner.getMsgBox().alert(s, _WFT("error", "not_support"));
            if (!a && (!this.onCheckPrivilege(t, i, !1, !1) || this.checkFTPDownloadRight(n) || "move" === t && this.checkFtpModifyRight(n))) return void this.owner.getMsgBox().alert(s, _WFT("error", "error_privilege_not_enough"));
            switch (e.itemId) {
                case "moveto_ovwr":
                case "copyto_ovwr":
                    this.FileAction.MVCPTo(i, t, this.userId, this.userGroup, e, o, !0);
                    break;
                case "moveto_skip":
                case "copyto_skip":
                    this.FileAction.MVCPTo(i, t, this.userId, this.userGroup, e, o, !1);
                    break;
                default:
                    this.FileAction.MVCP(i, t, this.userId, this.userGroup)
            }
        }
    },
    setHighlightEntry: function(e) {
        this.highlightId = e
    },
    enableViewMask: function() {
        Ext.iterate(this.dataView, function(e, t) {
            this.dataView[e].loadingText = _WFT("common", "loading")
        }, this), this.grid.loadMask.enable()
    },
    disableViewMask: function() {
        Ext.iterate(this.dataView, function(e, t) {
            this.dataView[e].loadingText = ""
        }, this), this.grid.loadMask.disable()
    },
    refreshGrid: function(e) {
        return this.isSelectAll || !1 === e || (this.grid.getSelectionModel().clearAllSelections(), Ext.iterate(this.dataView, function(e, t) {
            this.dataView[e].getSelectionModel().clearAllSelections()
        }, this)), !1 === e ? (this.disableViewMask(), this.activeDS.reload()) : (this.activeDS.removeAll(), this.activeDS.reload()), this.activeDS.getTotalCount()
    },
    refreshGridByPath: function(e, t) {
        if ((SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) || SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) && e === this.getCurrentDir()) return this.refreshGrid(t)
    },
    refreshTreeByPath: function(e, t) {
        var i = SYNO.webfm.utils.source,
            o = this.dirTree;
        SYNO.webfm.utils.isLocalSource(t) ? (this.refreshTreeByNode(o.getNodeById(i.local + e)), this.refreshTreeByNode(o.getNodeById(i.localh + e))) : (this.refreshTreeByNode(o.getNodeById(i.remote + e)), this.refreshTreeByNode(o.getNodeById(i.remoter + e)));
        var n = o.getNodeById("fm_fav_root");
        if (n) {
            var s = !1;
            Ext.each(n.childNodes, function(t) {
                if (e === t.attributes.path.substr(0, e.length)) return this.refreshTreeByNode(n), s = !0, !1
            }, this), s || Ext.each(n.childNodes, function(t) {
                var n = o.getNodeById(i.remotefav + t.attributes.name + e);
                this.refreshTreeByNode(n)
            }, this)
        }
    },
    refreshTreeByNode: function(e) {
        e && e.isLoaded() && (e.isExpanded() ? (this.expandedNodes = null, this.count = null, this.saveExpandStatus(e, 1), e.reload(function() {
            this.resumeExpandStatus(1)
        }, this)) : e.attributes.loader.load(e))
    },
    saveExpandStatus: function(e, t) {
        this.expandedNodes || (this.expandedNodes = []), this.expandedNodes[t] || (this.expandedNodes[t] = []);
        var i, o = this.expandedNodes[t];
        if (e.hasChildNodes()) {
            for (i = 0; i < e.childNodes.length && (e.childNodes[i].expanded && (o[o.length] = e.childNodes[i].id, t < 2 && this.saveExpandStatus(e.childNodes[i], t + 1)), 10 != o.length); i++);
            0 === this.expandedNodes[t].length && (this.expandedNodes = this.expandedNodes.slice(0, -1))
        }
    },
    resumeExpandStatus: function(e) {
        var t, i;
        if (this.expandedNodes) {
            if (this.expandedNodes.length - 1 < e) {
                var o = this.getCurrentDir();
                for (this.expandedNodes = null, this.count = null; !Ext.isEmpty(o);) {
                    if (i = this.dirTree.getNodeById(this.getCurrentSource() + o)) return void this.dirTree.getSelectionModel().select(i);
                    o = o.substr(0, o.lastIndexOf("/"))
                }
                return void this.reloadTree(!0)
            }
            var n = this.expandedNodes[e].length;
            for (t = 0; t < n; t++) i = this.dirTree.getNodeById(this.expandedNodes[e][t]), i ? i.expand(!1, !1, function() {
                this.expandCounter(e)
            }, this) : this.expandCounter(e)
        }
    },
    expandCounter: function(e) {
        this.count || (this.count = []), this.count[e] || (this.count[e] = 0), ++this.count[e] == this.expandedNodes[e].length && this.resumeExpandStatus(e + 1)
    },
    refreshTreeNode: function(e, t, i, o, n) {
        var s;
        if (e && Ext.isArray(e))
            for (s = 0; s < e.length; s++) {
                if ("" === e[s]) return void this.reloadTree(o);
                t && this.refreshTreeByPath(e[s], i || SYNO.webfm.utils.source.remote), this.refreshGridByPath(e[s], n)
            }
    },
    refreshVTreeNode: function(e, t) {
        var i = this.dirTree.getNodeById("fm_vd_root");
        i && i.reload(e, t)
    },
    refreshRTreeNode: function(e, t) {
        var i = this.dirTree.getNodeById("fm_rf_root");
        i && i.reload(e, t)
    },
    refreshVFSTreeNode: function(e, t, i) {
        var o = this.dirTree.getNodeById(i);
        o ? o.reload(e, t) : this.dirTree.createVFSNodeOnline(i)
    },
    refreshFavTreeNode: function(e, t) {
        var i = this.dirTree.getNodeById("fm_fav_root");
        i && i.reload(e, t)
    },
    refreshSearhGrid: function(e) {
        this.getCurrentSource() === SYNO.webfm.utils.source.remotes && this.grid.getStore().search_taskid === e && this.grid.getStore().reload()
    },
    focusActiveView: function() {
        this.activeView.getAriaEl().focus()
    },
    updateFavBtn: function() {
        var e = this.toolbar.getComponent("topToolbar"),
            t = e.getComponent("addfav"),
            i = e.getComponent("delfav"),
            o = this.dirTree.getNodeById("fm_root"),
            n = SYNO.webfm.utils.isLocalSource(this.getCurrentSource()),
            s = 1 >= o.childNodes.length || n || this.getCurrentSource() === SYNO.webfm.utils.source.remotes || SYNO.webfm.VFS.isVFSPath(this.getCurrentDir());
        if (s) return this.pathBar.tbPanel.el.addClass("with-right-border"), t.hide(), i.hide(), void e.syncSize();
        this.pathBar.tbPanel.el.removeClass("with-right-border");
        var r = !0;
        if (!s) {
            var a = this.dirTree.getNodeById("fm_fav_root");
            a && a.childNodes.forEach(function(e) {
                if (this.getCurrentDir() === e.attributes.path) return r = !1, !1
            }, this)
        }
        t.setVisible(r), i.setVisible(!r), e.syncSize()
    },
    saveInitPath: function() {
        var e = "",
            t = 0,
            i = 0,
            o = window.location.href;
        return this.initPath = null, -1 != (t = o.indexOf("?")) && (e = o.substr(t + 1), -1 != (t = e.indexOf("target=")) && (t += 7, -1 == (i = e.indexOf("&", t)) ? this.initPath = e.substr(t) : this.initPath = e.substr(t, i), void(this.initPath = decodeURIComponent(this.initPath))))
    },
    onRefreshTreeDone: function(e, t) {
        this.onGoToPathWithDirBySource(!0, e, void 0, t, function(e) {
            if (!e) {
                var t = this.dirTree.getSelectionModel(),
                    i = this.dirTree.getNodeById("fm_root");
                i.childNodes && 0 < i.childNodes.length && t.select(i.childNodes[0])
            }
        }.createDelegate(this))
    },
    createRefreshTreeDoneCallback: function(e, t, i) {
        return t !== i || SYNO.webfm.utils.isLocalSource(i) ? Ext.emptyFn : function() {
            this.onRefreshTreeDone(e, i)
        }
    },
    reloadTree: function(e) {
        this.blExpanded = !1;
        var t = !0 === e ? "" : this.getCurrentDir(),
            i = !0 === e ? "" : this.getCurrentSource();
        !0 === e && this.dirTree.unselectCurrentNode(), this.updateHybridShares();
        var o = this.dirTree.getNodeById("fm_top_root"),
            n = o.childNodes;
        this.owner.sendWebAPI({
            api: "SYNO.FileStation.VFS.Protocol",
            method: "list",
            version: 1,
            callback: function(e, t) {
                if (e) {
                    var i = {};
                    Ext.each(n, function(e) {
                        i[e.id] = e
                    });
                    var s = 0,
                        r = this.dirTree;
                    for (s = 0; s < t.protocols.length; s++) {
                        var a = t.protocols[s],
                            l = a.protocol;
                        !1 === a.has_server || l in i || o.appendChild(r.createVFSRoot(r.remoteLoader, l, r.protocolMap[l]))
                    }
                } else this.owner.getMsgBox().alert("", SYNO.webfm.utils.getWebAPIErrStr(!1, t))
            },
            scope: this
        });
        for (var s = 0; s < n.length; s++) {
            var r = n[s];
            switch (r.id) {
                case "fm_local_root":
                    1 == AppletProgram.blJavaPermission && this.dirLocalTree && this.dirLocalTree.rendered && this.dirLocalTree.getNodeById("fm_local_root").reload();
                    break;
                case "fm_vd_root":
                    this.refreshVTreeNode(this.createRefreshTreeDoneCallback(t, SYNO.webfm.utils.source.remotev, i), this);
                    break;
                case "fm_rf_root":
                    this.refreshRTreeNode(this.createRefreshTreeDoneCallback(t, SYNO.webfm.utils.source.remoter, i), this);
                    break;
                case "fm_fav_root":
                    this.refreshFavTreeNode(this.createRefreshTreeDoneCallback(t, SYNO.webfm.utils.isFavSource(i) ? i : SYNO.webfm.utils.source.remotefav, i), this);
                    break;
                case "fm_search_root":
                    break;
                default:
                    r.reload(this.createRefreshTreeDoneCallback(t, SYNO.webfm.utils.source.remote, i), this)
            }
        }
        this.getCurrentSource() !== SYNO.webfm.utils.source.remote && this.switchSource(SYNO.webfm.utils.source.remote)
    },
    initLocalDS: function() {
        this.localDS = new Ext.data.Store({
            storetype: SYNO.webfm.utils.source.local,
            proxy: new AppletProxy(this),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "file_id"
            }, ["file_id", "filename", "filesize", "mt", "ct", "at", "privilege", "fileprivilege", "isacl", "owner", "group", "icon", "type", "path", "real_path", "isdir", "uid", "gid", "is_compressed", "is_image", "ppath", "mountType", "is_snapshot", "is_btrfs_subvol", "snapshot_desc", "has_snapshot"]),
            remoteSort: !0,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: {
                action: "list",
                sort_by: "name"
            },
            pruneModifiedRecords: !0,
            listeners: {
                beforeload: {
                    scope: this.fileSearch,
                    fn: this.fileSearch.onBeforeLoad
                },
                load: {
                    fn: this.loadLocalDS,
                    scope: this
                },
                exception: {
                    fn: this.exceptionLocalDS,
                    scope: this
                }
            }
        }), this.addManagedComponent(this.localDS)
    },
    nodeContextMenu: function(e, t, i, o) {
        o.preventDefault(), e.isSelected(i) || e.select(i, !1), this.gridCtxMenu.blContainerMenu = !1, this.onUpdateBtnStatus(!1, e.getSelectedRecords()), this.gridCtxMenu.showAt(o.getXY()), o.stopPropagation()
    },
    gridRowContextMenu: function(e, t, i) {
        i.preventDefault();
        var o = e.getSelectionModel();
        o.isSelected(t) || o.selectRow(t), this.gridCtxMenu.blContainerMenu = !1, this.onUpdateBtnStatus(!1, o.getSelections()), this.gridCtxMenu.showAt(i.getXY())
    },
    containerContextmenu: function(e, t, i) {
        if (i.preventDefault(), t.getStore().storetype !== SYNO.webfm.utils.source.remotes) {
            if (!SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) {
                if (1 >= this.dirTree.getNodeById("fm_root").childNodes.length) return
            }
            this.gridCtxMenu.blContainerMenu = !0, this.onUpdateBtnStatus(!1, e), this.gridCtxMenu.showAt(i.getXY())
        }
    },
    dataViewContainerContextmenu: function(e, t) {
        this.containerContextmenu(e.getSelectedRecords(), e, t), t.stopPropagation()
    },
    gridContainerContextmenu: function(e, t) {
        this.containerContextmenu(e.getSelectionModel().getSelections(), e, t)
    },
    onFindAvailableNode: function(e, t) {
        var i;
        if (!e) return null;
        var o;
        if (-1 === e.indexOf("/") && -1 !== (o = e.indexOf("fm_"))) {
            var n = e.substr(o);
            "fm_search_root" === n && (i = this.dirTree.getNodeById(n))
        } else i = t ? this.dirTree.getNodeById(t + e) : this.dirTree.getNodeById(this.getCurrentSource() + e) || this.dirTree.getNodeById(SYNO.webfm.utils.source.remote + e);
        if (!i) {
            if (-1 == (o = e.lastIndexOf("/")) || 0 === o) return e;
            i = this.onFindAvailableNode(e.substr(0, o), t)
        }
        return i
    },
    onGoToPathWithFile: function(e) {
        var t = e.substr(0, e.lastIndexOf("/"));
        this.onGoToPathWithDir(t, e)
    },
    onGoToPathWithDirBySource: function(e, t, i, o, n) {
        var s = this.onFindAvailableNode(t, o);
        if (!s || !Ext.isObject(s)) return e || this.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "error_dest_no_path")), void(n && n(!1));
        s.attributes.path === t ? (i && this.setHighlightEntry(i), this.onChangeDir(t), this.dirTree.getSelectionModel().select(s), n && n(!0)) : (this.goto_path = t, s.expand(!1, !1, function(s) {
            var r = this.onGoToPathCallBack(e, s, t, i, o);
            n && n(r)
        }, this))
    },
    onGoToPathWithDir: function(e, t) {
        this.onGoToPathWithDirBySource(!1, e, t)
    },
    expandChildNodes: function(e, t) {
        if (e.childNodes.length > 0)
            for (var i = e.childNodes, o = 0, n = i.length; o < n; o++) i[o].attributes.children && SYNO.webfm.utils.isSubNotEqualPath(i[o].attributes.path, t, SYNO.webfm.utils.isLocalSource(i[o].attributes.type) && Ext.isWindows ? "\\" : "/") && (i[o].expand(!1), this.expandChildNodes(i[o], t))
    },
    onGoToPathCallBack: function(e, t, i, o, n) {
        var s = !1;
        this.expandChildNodes(t, i), o && this.setHighlightEntry(o);
        var r = this.dirTree.getNodeById((n || SYNO.webfm.utils.source.remote) + i);
        return r ? (this.onChangeDir(i), this.dirTree.getSelectionModel().select(r), s = !0) : e || this.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "error_dest_no_path")), s
    },
    onOpenContainingFolder: function() {
        if (this.getCurrentSource() === SYNO.webfm.utils.source.remotes) {
            var e = this.activeView.getSelectionModel(),
                t = e.getSelected(),
                i = function() {
                    var e = t.get("file_id");
                    this.onGoToPathWithFile(e)
                };
            SYNO.webfm.Plugin.checkActionByPlugin(this, this.owner, "open", [t], {
                fn: i,
                scope: this
            })
        }
    },
    nodedblclick: function(e, t, i, o) {
        this.dblclick(e, t, i, o), this.enableHotKeyByFocusDataView(e)
    },
    gridCelldblclick: function(e, t, i, o) {
        this.dblclick(e, t, i, o), this.enableHotKeyByFocusGrid(e)
    },
    dblclick: function(e, t, i, o) {
        var n, s, r, a = "",
            l = this.activeDS.getAt(t),
            h = [];
        if (SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) || this.getCurrentSource() === SYNO.webfm.utils.source.remotes) {
            if (!1 === l.get("isdir") && _S("ha_safemode")) return void this.onDownloadAction(void 0, o);
            var c = function() {
                if (!1 === l.get("isdir")) {
                    if (!0 === this.onExternDbClick(l)) return;
                    if (!this.onCheckVFSAction("download", l)) return;
                    return void this.onDownloadAction(void 0, o)
                }
                if (!0 !== this.onExternDbClick(l))
                    if (this.getCurrentSource() === SYNO.webfm.utils.source.remotes) !0 === l.get("isdir") ? this.onGoToPathWithDir(l.get("file_id")) : this.onGoToPathWithFile(l.get("file_id"));
                    else {
                        if (!this.onCheckVFSAction("navigate", l)) return void this.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "not_support"));
                        if (!this.onCheckPrivilege("navigate", l, !1, !1)) return void this.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "error_privilege_not_enough"));
                        a = l.get("file_id"), n = this.dirTree.getNodeById(this.getCurrentSource() + a), n && this.dirTree.getSelectionModel().select(n)
                    }
            };
            SYNO.webfm.Plugin.checkActionByPlugin(this, this.owner, "open", [l], {
                fn: c,
                scope: this
            })
        } else if (SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) {
            if (h[0] = l.get("file_id"), !1 === l.get("isdir")) return s = {
                files: h,
                action: "openfile"
            }, r = AppletProgram.action(s), void AppletProgram.checkResponse(r, this);
            a = l.get("file_id"), n = this.dirLocalTree.getNodeById(this.getCurrentSource() + a), n && this.dirLocalTree.getSelectionModel().select(n)
        }
        this.onChangeDir(a)
    },
    enableHotKeyByFocusGrid: function(e) {
        e.getView().focusEl.focus()
    },
    enableHotKeyByFocusDataView: function(e) {
        e.getEl().focus()
    },
    onSettingClose: function() {
        this.setDragToDesktop()
    },
    beforeClose: function() {
        this.tid && this.owner.sendWebAPI({
            api: "SYNO.FileStation.List",
            timeout: SYNO.webfm.Cfg.timeout,
            method: "list",
            version: 2,
            params: {
                folder_path: this.getCurrentDir(),
                tid_delete: this.tid
            },
            callback: function() {},
            scope: this
        })
    },
    initDS: function() {
        this.remoteDS = new Ext.data.Store({
            storetype: SYNO.webfm.utils.source.remote,
            proxy: new SYNO.API.Proxy({
                timeout: SYNO.webfm.Cfg.timeout,
                api: "SYNO.FileStation.List",
                method: "list",
                version: 2,
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    },
                    load: function(e, t, i, o) {
                        t && t.tid && (this.tid = t.tid)
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "file_id",
                mapping: "path"
            }, {
                name: "path"
            }, {
                name: "filename",
                mapping: "name"
            }, {
                name: "filesize",
                mapping: "additional.size"
            }, {
                name: "mt",
                mapping: "additional.time.mtime"
            }, {
                name: "ct",
                mapping: "additional.time.crtime"
            }, {
                name: "at",
                mapping: "additional.time.atime"
            }, {
                name: "privilege",
                mapping: "additional.perm.posix"
            }, {
                name: "fileprivilege",
                convert: function(e, t) {
                    var i, o = t.additional.perm.acl;
                    return o.append && (i |= SYNO.webfm.utils.Mode_Append), o.del && (i |= SYNO.webfm.utils.Mode_Del), o.exec && (i |= SYNO.webfm.utils.Mode_Exec), o.read && (i |= SYNO.webfm.utils.Mode_Read), o.write && (i |= SYNO.webfm.utils.Mode_Write), i
                }
            }, {
                name: "isacl",
                mapping: "additional.perm.is_acl_mode"
            }, {
                name: "icon"
            }, {
                name: "type",
                mapping: "additional.type"
            }, {
                name: "real_path",
                mapping: "additional.real_path"
            }, {
                name: "isdir"
            }, {
                name: "owner",
                mapping: "additional.owner.user"
            }, {
                name: "group",
                mapping: "additional.owner.group"
            }, {
                name: "uid",
                mapping: "additional.owner.uid"
            }, {
                name: "gid",
                mapping: "additional.owner.gid"
            }, {
                name: "ppath"
            }, {
                name: "mountType",
                mapping: "additional.mount_point_type"
            }, {
                name: "is_snapshot"
            }, {
                name: "is_btrfs_subvol"
            }, {
                name: "snapshot_desc"
            }, {
                name: "has_snapshot"
            }, {
                name: "description",
                mapping: "additional.description"
            }]),
            remoteSort: !0,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: {
                sort_by: "name",
                check_dir: !0,
                additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type", "description", "indexed"]
            },
            pruneModifiedRecords: !0,
            listeners: {
                scope: this,
                beforeload: function(e, t) {
                    var i = t.params,
                        o = this;
                    this.tidFunc && (clearTimeout(this.tidFunc), this.tidFunc = void 0), this.tidFunc = setTimeout(function() {
                        o.updateTid(o, i)
                    }, 500);
                    var n = e.fields.get(e.sortInfo.field),
                        s = n ? n.mapping || n.name : "name";
                    return s = s.split(".", 3), i.sort_by = s[2] || s[1] || s[0], i
                },
                load: this.loadRemoteDS,
                exception: this.exceptionRemoteDS
            }
        }), this.addManagedComponent(this.remoteDS), this.activeDS = this.remoteDS
    },
    updateTid: function(e, t) {
        SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable_cross_browser_dd") ? e.tid ? t.tid_old = e.tid : t.tid_old = "" + Math.random() : e.tid && (t.tid_delete = e.tid, delete e.tid, delete t.tid_old), (Ext.isDefined(t.tid_old) || Ext.isDefined(t.tid_delete)) && e.owner.sendWebAPI({
            api: "SYNO.FileStation.List",
            timeout: SYNO.webfm.Cfg.timeout,
            method: "list",
            version: 2,
            params: t,
            callback: function(t, i) {
                i && i.tid && (e.tid = i.tid)
            },
            scope: e
        })
    },
    setSortColumnModel: function(e) {
        this.setSortCM(this.cmNoppath, e), this.setSortCM(this.cmWithppath, e)
    },
    setSortCM: function(e, t) {
        var i = e.columns;
        i[0].sortable !== t && (Ext.each(i, function(e) {
            e.sortable = t
        }, this), e.setConfig(i, !1))
    },
    onHeaderMouseDown: function() {
        this.getCurrentSource() === SYNO.webfm.utils.source.remotes && this.remoteSearchDS.blSearhDone && (this.remoteSearchDS.blSearchSorted = !0)
    },
    getExternIcon: function(e, t) {
        var i, o;
        if (!Ext.isEmpty(this.externCodeIcon) && (Ext.each(this.externCodeIcon, function(n) {
                if (Ext.isString(n.data.getIconFn)) try {
                    var s = Ext.getClassByName(n.data.getIconFn);
                    if (o = s(n, e, t)) {
                        if (Ext.isEmpty(o) || !1 === o) return;
                        if (Ext.isObject(o)) i = {}, i.url = o.url ? n.baseURL + "/" + o.url : "", i.css = o.css || "";
                        else {
                            if (!Ext.isString(o)) return;
                            i = {}, i.url = o, i.css = ""
                        }
                        return !1
                    }
                } catch (e) {
                    SYNO.Debug("Fail to render icon" + e)
                }
            }, this), !Ext.isEmpty(i))) return i
    },
    changeView: function(e) {
        var t, i = this,
            o = i.activeView.getSelectionModel().getSelections();
        i.viewPanel.getLayout().setActiveItem(e), "thumbnailView" === e ? (i.activeView = i.dataViewPanel.thumbnail, t = i.dataViewPagingtoolbar.thumbnail) : "columnView" === e ? (i.activeView = i.dataViewPanel.column, t = i.dataViewPagingtoolbar.column) : (i.activeView = i.grid, t = i.paging), i.activeView.getSelectionModel().selectRecords(o), _S("standalone") && this.appInstance.setUserSettings("activeViewItemId", e), t.setButtonsVisible(t.getPageData().total > this.displayNum)
    },
    getCurrentViewItemId: function() {
        return this.activeView.itemId
    },
    getCurrentViewSize: function() {
        return this.activeViewSize
    },
    initPanel: function(e) {
        var t = this,
            i = [],
            o = new SYNO.FileStation.TypeAndSearchPlugin;
        if (SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload()) {
            var n = [],
                s = [];
            t.btnUpSubMenuAction.each(function(e) {
                var t = e.menu.get("upload_skip");
                t && n.push(t), (t = e.menu.get("upload_overwrite")) && s.push(t)
            }), t.btnTreeUpSubMenuAction.each(function(e) {
                var t = e.menu.get("upload_skip");
                t && n.push(t), (t = e.menu.get("upload_overwrite")) && s.push(t)
            }), n.push(this.btnRemoteUpload.menu.get("upload_skip")), s.push(this.btnRemoteUpload.menu.get("upload_overwrite")), t.html5UploadMgr = new SYNO.FileStation.Action.Uploader.HTML5UploaderMgr({
                owner: t,
                instantStart: !0,
                url: SYNO.API.currentManager.getBaseURL("SYNO.FileStation.Upload", "upload", 2),
                btncfg: {
                    skipbtncfg: n,
                    ovwrbtncfg: s
                }
            }), i.push(t.html5UploadMgr)
        }
        i.push(o);
        var r = [t.initFileGrid(), t.initDataView("thumbnail")];
        return Ext.isIE9m || r.push(t.initDataView("column")), t.viewPanel = t.viewPanel || new Ext.Container(Ext.apply({
            owner: t,
            layout: "card",
            deferredRender: !0,
            items: r,
            activeItem: 0,
            plugins: i,
            searchAndFocus: t.searchAndFocus.createDelegate(t)
        }, e)), t.activeView = t.grid, t.addManagedComponent(o), t.viewPanel
    },
    showLoading: function() {
        this.paging.showLoading(), Ext.iterate(this.dataView, function(e, t) {
            this.dataViewPagingtoolbar[e].showLoading()
        }, this)
    },
    hideLoading: function() {
        this.paging.hideLoading(), Ext.iterate(this.dataView, function(e, t) {
            this.dataViewPagingtoolbar[e].hideLoading()
        }, this)
    },
    createPagingToolbar: function() {
        var e = this.dirTree,
            t = new SYNO.ux.PagingToolbar({
                store: this.activeDS,
                pageSize: this.displayNum,
                displayInfo: !0,
                showRefreshBtn: !0,
                hidden: !1,
                listeners: {
                    scope: this,
                    beforechange: {
                        fn: function(e, t) {
                            if (this.getCurrentSource() === SYNO.webfm.utils.source.remotes) return this.remoteSearchDS.blSearhDone;
                            if (e.cursor === t[e.getParams().offset]) {
                                var i = [];
                                i.push(this.getCurrentDir()), this.refreshTreeNode(i, !0, this.getCurrentSource())
                            }
                            return !0
                        },
                        scope: this
                    },
                    change: {
                        fn: function(e, t) {
                            this.setPagingToolbar(t.total, e.ownerContainer, e)
                        },
                        scope: this
                    }
                },
                hideLoading: function() {
                    this.loading.hide(), this.refresh.show(), this.dirTree.searchNode.ui && this.dirTree.searchNode.ui.removeClass("search-loading")
                },
                showLoading: function() {
                    this.loading.show(), this.refresh.hide(), this.dirTree.searchNode.ui && this.dirTree.searchNode.ui.addClass("search-loading")
                }
            });
        return t.dirTree = e, t
    },
    changeThumbSize: function(e) {
        _S("standalone") && this.appInstance.setUserSettings("activeViewSize", e), this.activeViewSize = e, this.dataView.thumbnail.changeThumbSize(e)
    },
    initDataView: function(e) {
        var t = this,
            i = [],
            o = {
                store: t.activeDS,
                owner: t,
                RELURL: t.RELURL,
                ddGroup: "SDSShortCut",
                plugins: [SYNO.FileStation.FocusComponentPluginInstance, new SYNO.SDS.Utils.DataView.DragSelector],
                keys: this.getHotKeyMap(),
                ddText: _WFT("common", "ddtext_files_selected"),
                getDragDropText: function() {
                    var e = this.getSelectionCount ? this.getSelectionCount() : 1;
                    return String.format(this.ddText, e, 1 == e ? "" : "s")
                },
                listeners: {
                    render: {
                        fn: function(e) {
                            e.dragZone = new SYNO.webfm.utils.DataViewDragZone(e, {
                                ddGroup: e.ddGroup,
                                onGetShortCutRecs: this.onGetShortCutRecs.createDelegate(this),
                                onBeforeDrag: function(e, i) {
                                    return SYNO.webfm.SmartDDMVCPMgr.initDragData(t, e.selections), SYNO.webfm.utils.DataViewDragZone.prototype.onBeforeDrag.apply(this, arguments)
                                }
                            }), e.dddrop = new SYNO.webfm.utils.DataViewDropTarget(e, {
                                ddGroup: e.ddGroup,
                                ddText: e.ddText
                            }, this)
                        },
                        scope: this
                    },
                    contextmenu: {
                        fn: this.nodeContextMenu,
                        scope: this
                    },
                    containercontextmenu: {
                        fn: this.dataViewContainerContextmenu,
                        scope: this
                    },
                    afterrender: {
                        fn: function(e) {
                            e.getEl().on("keyup", function(e) {
                                var t = this.getCmdCode();
                                Ext.isArray(t) ? this.cmdKeyDown = this.cmdKeyDown && -1 === t.indexOf(e.getKey()) : this.cmdKeyDown = this.cmdKeyDown && t !== e.getKey()
                            }, this)
                        },
                        scope: this,
                        single: !0
                    },
                    dblclick: {
                        fn: this.nodedblclick,
                        scope: this
                    }
                }
            };
        if (t.dataView = t.dataView || {}, "thumbnail" === e) t.dataView[e] = new SYNO.FileStation.ThumbnailsView(o);
        else {
            if ("column" !== e) throw "init data view error";
            t.dataView[e] = new SYNO.FileStation.ColumnView(o)
        }
        return t.dataViewPagingtoolbar = t.dataViewPagingtoolbar || {}, t.dataViewPagingtoolbar[e] = t.dataViewPagingtoolbar[e] || t.createPagingToolbar(), t.dataViewPanel = t.dataViewPanel || {}, t.dataViewPanel[e] = new Ext.Panel({
            cls: "webfm-" + e + "-view-panel",
            itemId: e + "View",
            layout: "fit",
            items: t.dataView[e],
            bbar: t.dataViewPagingtoolbar[e],
            dataView: t.dataView[e],
            plugins: i,
            padding: "column" === e ? "0 12px 0 16px" : void 0,
            getView: function() {
                return this.dataView
            },
            getViewEl: function() {
                return this.dataView.getEl()
            },
            scrollToItem: function(e) {
                var t = this.dataView.getNode(e);
                t && fleXenv.scrollTo(t)
            },
            focusItem: function(e) {
                this.dataView.focusNode(e)
            },
            owner: this,
            getStore: function() {
                return this.dataView.getStore()
            },
            getSelectionModel: function() {
                return this.dataView.getSelectionModel()
            },
            listeners: {
                activate: {
                    fn: function(e) {
                        e.doLayout(), e.dataView.onUpdate(), e.dataView.updateScrollbar()
                    }
                },
                afterrender: {
                    fn: function(e) {
                        this.mon(e.getEl(), "contextmenu", function(t) {
                            this.dataViewContainerContextmenu(e.dataView, t)
                        }, this)
                    },
                    scope: this
                }
            }
        }), t.dataViewPagingtoolbar[e].ownerContainer = t.dataViewPanel[e], t.dataView[e].setSearchStategy(SYNO.SDS.Utils.DataView.ConstantSearchStrategy.createDelegate(t.dataView[e])), t.dataViewPanel[e].mon(t.dataView[e], "afterUpdateScrollbar", this.onAfterDataViewUpdateScrollbar.createDelegate(this, [t.dataView[e]]), this), t.dataViewPanel[e]
    },
    initFileGrid: function(e, t) {
        var i = function(e, t, i) {
                return i.get("isdir") ? "" : Ext.util.Format.fileSize(e)
            },
            o = function(e, t, i) {
                return e && "remotefail" !== i.get("mountType") ? SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e), {
                    type: "datetimesec"
                }) : ""
            },
            n = window.location.pathname,
            s = "";
        s = _S("standalone") && n ? ("/index.cgi" === n ? "/" : n) + "webman/modules/FileBrowser/" : "/webman/modules/FileBrowser/";
        var r = [{
            id: "filename",
            header: _WFT("common", "common_filename"),
            dataIndex: "filename",
            width: 160,
            renderer: function(e, t, i, o, n, r) {
                Ext.isEmpty(i.data.icon) && (i.data.icon = SYNO.webfm.utils.getThumbName(i.data));
                var a = Ext.util.Format.htmlEncode(e);
                Ext.isIE && !Ext.isModernIE || (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"');
                var l, h = i.get("icon"),
                    c = SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(s + "images/{1}/files_ext/" + h, "Desktop", !0),
                    d = '<div class="{0} webfm-file-type-icon" style="background:url({1}) no-repeat; background-size: 16px 16px;"/>&nbsp;{2}</div>';
                if ("remotefail" === i.get("mountType")) h = "remotefailmountpoint.png";
                else if (SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) && (l = this.getExternIcon(i))) return String.format(d, l.css, l.url || c, a);
                return String.format(d, "", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(s + "images/{1}/files_ext/" + h, "Desktop", !0), a)
            }.createDelegate(this)
        }, {
            header: _WFT("common", "common_filesize"),
            dataIndex: "filesize",
            width: 80,
            align: "left",
            renderer: i
        }, {
            header: _WFT("filetable", "filetable_title_file_type"),
            dataIndex: "type",
            width: 100,
            align: "left",
            renderer: function(e, t, i, o, n, s) {
                return !0 === i.get("isdir") ? _WFT("filetable", "filetable_folder") : e ? SYNO.webfm.utils.isLocalSource(this.getCurrentSource()) && e.toLowerCase() !== SYNO.webfm.utils.getExt(i.data.filename) ? Ext.util.Format.htmlEncode(e.toUpperCase()) : Ext.util.Format.htmlEncode(e.toUpperCase()) + " " + _WFT("filetable", "filetable_file") : _WFT("filetable", "filetable_file")
            }.createDelegate(this)
        }, {
            header: _WFT("filetable", "filetable_mtime"),
            dataIndex: "mt",
            width: 150,
            align: "left",
            renderer: o
        }, {
            header: _WFT("filetable", "filetable_ctime"),
            dataIndex: "ct",
            width: 150,
            align: "left",
            renderer: o,
            hidden: !0
        }, {
            header: _WFT("filetable", "filetable_atime"),
            dataIndex: "at",
            width: 150,
            align: "left",
            renderer: o,
            hidden: !0
        }, {
            header: _WFT("filetable", "filetable_privilege"),
            dataIndex: "privilege",
            width: 80,
            align: "left",
            hidden: !0,
            renderer: function(e, t, i, o, n, s) {
                if (SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) return "";
                var r = i.data.privilege,
                    a = "",
                    l = "",
                    h = "",
                    c = 0,
                    d = 0,
                    u = 0,
                    f = parseInt(r, 10);
                return f >= 100 && (c = Math.floor(f / 100), f -= 100 * c), f >= 10 && (d = Math.floor(f / 10), f -= 10 * d), u = f, a += 4 & c ? "r" : "-", a += 2 & c ? "w" : "-", a += 1 & c ? "x" : "-", l += 4 & d ? "r" : "-", l += 2 & d ? "w" : "-", l += 1 & d ? "x" : "-", h += 4 & u ? "r" : "-", h += 2 & u ? "w" : "-", h += 1 & u ? "x" : "-", a + l + h
            }.createDelegate(this)
        }];
        _S("diskless") || r.push({
            header: _WFT("filetable", "filetable_owner"),
            dataIndex: "owner",
            width: 80,
            align: "left",
            hidden: !0,
            renderer: function(e, t, i, o, n, s) {
                return "remotefail" === i.get("mountType") ? "" : "" === e ? i.get("uid") : e
            }.createDelegate(this)
        }, {
            header: _WFT("filetable", "filetable_group"),
            dataIndex: "group",
            width: 80,
            align: "left",
            renderer: function(e, t, i, o, n, s) {
                return "remotefail" === i.get("mountType") ? "" : "" === e ? i.get("gid") : e
            }.createDelegate(this),
            hidden: !0
        }), this.cmNoppath = new Ext.grid.ColumnModel({
            defaults: {
                sortable: !0
            },
            columns: r
        });
        var a = SYNO.Util.copy(r);
        a.push({
            header: _WFT("extract", "file_path"),
            dataIndex: "ppath",
            width: 80,
            renderer: function(e, t, i, o, n, s) {
                e = SYNO.webfm.utils.getParentDirArr(i.data.path);
                var r = Ext.util.Format.htmlEncode(e);
                return Ext.isIE && !Ext.isModernIE || (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(r) + '"'), r
            }
        }), this.cmWithppath = new Ext.grid.ColumnModel({
            defaults: {
                sortable: !0
            },
            columns: a
        }), this.paging = this.paging || this.createPagingToolbar();
        var l = [];
        l.push(SYNO.FileStation.FocusGridPluginInstance);
        var h = this,
            c = new SYNO.FileStation.SelectAllRowSelectionModel,
            d = new SYNO.ux.GridPanel({
                itemId: "fileGrid",
                sm: c,
                owner: this,
                region: "center",
                cls: "webfm-listview-grid-panel",
                view: new SYNO.ux.FleXcroll.grid.BufferView({
                    rowHeight: 28,
                    borderHeight: 1,
                    cacheSize: 30,
                    scrollDelay: !1,
                    forceFit: !0,
                    disableTextSelect: !0,
                    onLoad: function() {
                        var e = this;
                        e.updateScroller(e.trackResetOnLoad), e.trackResetOnLoad = !0
                    },
                    focusItem: function(e) {
                        this.focusRow(e)
                    },
                    scrollToItem: function(e) {
                        var t = this.getRow(e);
                        fleXenv.scrollTo(t)
                    },
                    onCreateDragZone: function() {
                        var e = this.grid;
                        this.dragZone = new Ext.grid.GridDragZone(e, {
                            ddGroup: e.ddGroup,
                            onBeforeDrag: function(e, t) {
                                return SYNO.webfm.SmartDDMVCPMgr.initDragData(h, e.selections), Ext.grid.GridDragZone.prototype.onBeforeDrag.apply(this, arguments)
                            },
                            getDragData: function(e) {
                                var t, i = Ext.lib.Event.getTarget(e),
                                    o = this.view.findRowIndex(i);
                                if (!1 !== o) {
                                    var n = this.grid.selModel;
                                    return n.isSelected(o) && !e.hasModifier() || n.handleMouseDown(this.grid, o, e), t = n.getSelections(), {
                                        grid: this.grid,
                                        ddel: this.ddel,
                                        rowIndex: o,
                                        selections: t,
                                        SDSShortCut: h.onGetShortCutRecs(t),
                                        _fromFile: !0,
                                        ddText: _T("desktop", "add_shortcut")
                                    }
                                }
                                return !1
                            },
                            validateTarget: function(e, t, i) {
                                var o = e.getEl();
                                if (SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(!0), Ext.fly(o).findParentNode("div.syno-sds-aceeditor-main-panel") || Ext.fly(o).findParentNode("div.sds-audioplayer-mini-player-window") || Ext.fly(o).findParentNode("div.syno-sds-filestation-available-drop-target")) return !0;
                                var n = t.getTarget("li.launch-icon");
                                if (SYNO.SDS.Desktop.getEl().id === t.getTarget().id || n && Ext.fly(n).findParentNode(".sds-desktop-shortcut")) {
                                    var s, r = this.dragData;
                                    for (s = 0; s < r.selections.length; s++)
                                        if (SYNO.webfm.VFS.isVFSPath(r.selections[s].id)) return !1;
                                    return !(r && r.grid && SYNO.webfm.utils.isLocalSource(r.grid.getStore().storetype))
                                }
                                n = t.getTarget();
                                var a, l;
                                return n && (Ext.fly(n).is("div.syno-sds-fs-grid-scroller") || Ext.fly(n).is("div.syno-sds-fs-thumbnailsView") || Ext.fly(n).is("div.syno-sds-fs-columnView") || (l = Ext.fly(n).findParentNode("div.syno-sds-fs-grid-scroller")) || (l = Ext.fly(n).findParentNode("div.syno-sds-fs-thumbnailsView")) || (l = Ext.fly(n).findParentNode("div.syno-sds-fs-columnView")) || (l = Ext.fly(n).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))) ? (l = l || n, l = Ext.fly(l).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE), a = SYNO.SDS.WindowMgr.get(l.id), a && a.toFront(), SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(!1), !0) : (l = l || n, l && (l = Ext.fly(l).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE)) && (a = SYNO.SDS.WindowMgr.get(l.id)) && a.toFront(), !1)
                            }
                        })
                    }
                }),
                title: t ? "&nbsp;" : null,
                ds: this.activeDS,
                cm: this.cmNoppath,
                loadMask: !0,
                autoExpandMin: 160,
                autoExpandColumn: "filename",
                monitorWindowResize: !0,
                enableColumnMove: !0,
                enableDragDrop: !0,
                ddGroup: "SDSShortCut",
                ddText: _WFT("common", "ddtext_files_selected"),
                enableColLock: !1,
                columnLines: !0,
                stripeRows: !0,
                bbar: this.paging,
                tbar: e,
                stateful: !0,
                stateEvents: ["columnmove", "columnresize", "sortchange"],
                saveState: function() {
                    var e = this.grid.getState();
                    this.appInstance.setUserSettings("gridstates", e)
                }.createDelegate(this),
                plugins: l,
                getViewEl: function() {
                    return this.getView().scroller
                },
                focusItem: function(e) {
                    this.getView().focusItem(e)
                },
                scrollToItem: function(e) {
                    this.getView().scrollToItem(e)
                },
                listeners: {
                    scope: this,
                    render: {
                        fn: function(e) {
                            var t = e.getView().scroller.dom;
                            e.dddrop = new SYNO.webfm.utils.GridDropTarget(t, {
                                ddGroup: "SDSShortCut"
                            }, this), e.getView().scroller.addClass("syno-sds-fs-grid-scroller"), this.grid.getGridEl().addClass("without-dirty-red-grid")
                        },
                        scope: this
                    },
                    beforerender: {
                        fn: function(e) {
                            var t = this.appInstance.getUserSettings("gridstates");
                            t && e.applyState(t)
                        },
                        scope: this
                    },
                    celldblclick: {
                        fn: this.gridCelldblclick,
                        scope: this
                    },
                    rowcontextmenu: {
                        fn: this.gridRowContextMenu,
                        scope: this
                    },
                    containercontextmenu: {
                        fn: this.gridContainerContextmenu,
                        scope: this
                    },
                    rowclick: {
                        fn: function(e, t, i) {
                            i && t >= 0 && !i.hasModifier() && e.getSelectionModel().selectRow(t)
                        }
                    },
                    containerclick: {
                        fn: function(e, t) {
                            t.target.classList.contains("vscrollerbar") || e.getSelectionModel().clearAllSelections()
                        }
                    },
                    afterrender: {
                        fn: function(e) {
                            e.getEl().on("keyup", function(e) {
                                var t = this.getCmdCode();
                                Ext.isArray(t) ? this.cmdKeyDown = this.cmdKeyDown && -1 === t.indexOf(e.getKey()) : this.cmdKeyDown = this.cmdKeyDown && t !== e.getKey()
                            }, this)
                        }
                    },
                    headermousedown: this.onHeaderMouseDown,
                    activate: {
                        fn: function() {
                            this.grid.doLayout(), this.grid.updateScrollbar && this.grid.updateScrollbar(this.grid.getView().scroller.dom), this.grid.getView().update && this.grid.getView().update()
                        },
                        scope: this
                    }
                },
                keys: this.getHotKeyMap()
            });
        return this.grid = d, this.paging.ownerContainer = this.grid, this.grid.mon(this.grid, "afterUpdateScrollbar", this.onAfterGridUpdateScrollbar, this), d
    },
    getCmdCode: function() {
        return SYNO.webfm.utils.getCmdCode()
    },
    getHotKeyMap: function() {
        if (Ext.isMac) {
            return [{
                key: this.getCmdCode(),
                fn: function() {
                    this.cmdKeyDown = !0
                },
                scope: this
            }, {
                key: Ext.EventObject.DELETE,
                fn: this.onDeleteAction,
                scope: this
            }, {
                key: Ext.EventObject.C,
                fn: this.onShortCutCopyAction,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.X,
                fn: this.onShortCutCutAction,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.V,
                fn: function() {
                    this.onShortCutPasteAction(SYNO.webfm.utils.hotKey, !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite"), !0)
                },
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.F2,
                fn: this.onRenameAction,
                scope: this
            }, {
                key: Ext.EventObject.A,
                fn: this.onSelectAllRowAction,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.ENTER,
                fn: this.onEnterPress,
                scope: this
            }]
        }
        return [{
            key: Ext.EventObject.BACKSPACE,
            fn: this.onHistoryBack,
            scope: this
        }, {
            key: Ext.EventObject.DELETE,
            fn: this.onDeleteAction,
            scope: this
        }, {
            key: Ext.EventObject.C,
            ctrl: !0,
            fn: this.onShortCutCopyAction,
            scope: this
        }, {
            key: Ext.EventObject.X,
            ctrl: !0,
            fn: this.onShortCutCutAction,
            scope: this
        }, {
            key: Ext.EventObject.V,
            ctrl: !0,
            fn: function() {
                this.onShortCutPasteAction(SYNO.webfm.utils.hotKey, !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite"), !0)
            },
            scope: this
        }, {
            key: Ext.EventObject.F2,
            fn: this.onRenameAction,
            scope: this
        }, {
            key: Ext.EventObject.A,
            ctrl: !0,
            fn: this.onSelectAllRowAction,
            scope: this
        }, {
            key: Ext.EventObject.ENTER,
            fn: this.onEnterPress,
            scope: this
        }]
    },
    getViewEl: function() {
        return this.activeView.getViewEl()
    },
    searchAndFocus: function(e, t) {
        var i = this,
            o = i.activeView,
            n = o.getStore(),
            s = o.getSelectionModel(),
            r = s.getSelected(),
            a = 0,
            l = -1;
        return a = t ? n.indexOf(r) : n.indexOf(r) + 1, a > n.getCount() - 1 && (a = 0), !((l = n.find("filename", e, a, !1, !1)) < 0 && (0 !== a && (l = n.find("filename", e, 0, !1, !1)), l < 0)) && (s.selectRow(l), o.focusItem(l), !0)
    },
    highlightItem: function(e) {
        var t, i;
        if (e.highlightId) {
            var o = e.highlightId;
            if (t = this.activeView.getSelectionModel(), !e) return;
            i = e.indexOfId(o), t && -1 != i && (t.selectRow(i), this.activeView.scrollToItem(i)), this.highlightId = null
        }
    },
    onAfterGridUpdateScrollbar: function() {
        this.highlightItem(this.grid.getStore())
    },
    onAfterDataViewUpdateScrollbar: function(e) {
        this.highlightItem(e.getStore())
    },
    loadDS: function(e, t, i) {
        e.highlightId = this.highlightId, this.unmaskView(), this.updateCutIcon()
    },
    exceptionDS: function(e, t) {
        this.isViewMasked() && this.unmaskView();
        var i = [2102, 2107, 2112, 2115];
        if (e && -1 !== i.indexOf(e.code)) SYNO.webfm.utils.handleRemoteConnectionException(e, {
            id: SYNO.webfm.VFS.getBaseURI(t.folder_path)
        }, this.findWindow(), function() {
            this.remoteDS.reload()
        }, function() {
            this.maskView(SYNO.webfm.utils.getWebAPIErrStr(!1, e))
        }, this);
        else if (1102 === e.code) {
            if (this.maskView(SYNO.webfm.utils.getExceedMaxFolderMsg(), "webfm-mask-view"), _S("is_admin")) {
                var o = this.viewPanel.getEl().child(".webfm-mask-view").child(".pathlink");
                this.mon(o, "click", function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                        fn: "SYNO.SDS.AdminCenter.FileService.Main"
                    })
                })
            }
        } else this.maskView(SYNO.webfm.utils.getWebAPIErr(!1, e, t))
    },
    loadRemoteDS: function(e, t, i) {
        this.loadDS(e, t, i), this.ajaxCounter++, 2 == this.ajaxCounter && this.initJava(), this.updateRemoteMountIcon(), this.setDragToDesktop()
    },
    setPagingToolbar: function(e, t, i) {
        i.setButtonsVisible(e > this.displayNum), 0 !== e && e % this.displayNum == 0 && 0 === i.store.getCount() && i.movePrevious(), t.doLayout()
    },
    exceptionRemoteDS: function(e, t, i, o, n, s) {
        this.exceptionDS(n, o.params, o)
    },
    loadLocalDS: function(e, t, i) {
        this.loadDS(e, t, i)
    },
    exceptionLocalDS: function(e, t, i, o, n) {
        var s = this,
            r = s.viewPanel.getEl();
        r.isMasked() && r.unmask();
        var a = _WFT("error", "error_error_system");
        n.errno && (a = _WFT(n.errno.section, n.errno.key)), r.mask(a)
    },
    onPropertyClick: function() {
        var e = this.activeView.getSelectionModel();
        if (e.hasSelection()) {
            var t = e.getSelections();
            this.FileAction.Property(t, this.userId)
        }
    },
    onShareClick: function() {
        var e = this.activeView.getSelectionModel();
        if (e.hasSelection()) {
            var t = e.getSelections();
            this.FileAction.Share(t)
        }
    },
    onFileRequestClick: function() {
        var e = this.activeView.getSelectionModel();
        if (e.hasSelection()) {
            var t = e.getSelections();
            this.FileAction.FileRequest(t)
        }
    },
    checkCompressPrivilege: function(e) {
        return this.onCheckVFSAction("compress", e) ? !!this.onCheckPrivilege("compress", e, !1, !1) || (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _WFT("error", "error_privilege_not_enough")), !1) : (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _WFT("error", "not_support")), !1)
    },
    onCompressItemsClick: function() {
        var e, t = this.activeView.getSelectionModel();
        return t.hasSelection() ? !0 === _S("demo_mode") ? void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _JSLIBSTR("uicommon", "error_demo")) : (e = t.getSelections(), void(this.checkCompressPrivilege(e) && this.FileAction.Compress(e, this.getCurrentDir(), this.getSuggestZipName(e)))) : null
    },
    onCompressAdvItemsClick: function() {
        var e, t = this.activeView.getSelectionModel();
        return t.hasSelection() ? !0 === _S("demo_mode") ? void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _JSLIBSTR("uicommon", "error_demo")) : (e = t.getSelections(), void(this.checkCompressPrivilege(e) && this.FileAction.compressDialog(e, this.getCurrentDir(), this.getSuggestZipName(e)))) : null
    },
    getExtractRec: function(e) {
        var t = this.activeView.getSelectionModel();
        if (!t.hasSelection()) return null;
        var i = t.getSelections();
        return this.onCheckPrivilege("extract", i, e, !1) ? i : (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_extract"), _WFT("error", "error_privilege_not_enough")), null)
    },
    onMountList: function() {
        this.FileAction.MountList()
    },
    onSettings: function() {
        this.FileAction.onSettings()
    },
    onMountRemoteCIFSClick: function() {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_remote_volume"), _JSLIBSTR("uicommon", "error_demo"));
        this.FileAction.MountRemoteCIFS(this.userId, this.userGroup)
    },
    onMountRemoteNFSClick: function() {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_remote_volume"), _JSLIBSTR("uicommon", "error_demo"));
        this.FileAction.MountRemoteNFS(this.userId, this.userGroup)
    },
    onRemoteConnectClick: function() {
        this.FileAction.RemoteConnect(this.owner)
    },
    onRemoteConnectServerListClick: function() {
        if (!0 === _S("demo_mode")) return void this.owner.getMsgBox().alert("", _JSLIBSTR("uicommon", "error_demo"));
        this.FileAction.RemoteConnectServerList(this.owner)
    },
    onMountISOClick: function() {
        var e, t = this.activeView.getSelectionModel();
        return !0 === _S("demo_mode") ? void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _JSLIBSTR("uicommon", "error_demo")) : t.hasSelection() ? (e = t.getSelections(), 1 !== e.length || -1 === SYNO.webfm.utils.image_type.indexOf(e[0].get("type").toLowerCase()) ? void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("mount", "err_virtual_no_selected")) : this.onCheckVFSAction("mount", e) ? this.onCheckPrivilege("mount", e, !1, !1) ? void this.FileAction.MountISO(e, this.userId, this.userGroup) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("error", "error_privilege_not_enough")) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("error", "not_support"))) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_mount_iso"), _WFT("mount", "err_virtual_no_selected"))
    },
    onUmountClick: function() {
        var e, t, i = this.activeView.getSelectionModel();
        return !0 === _S("demo_mode") ? void this.owner.getMsgBox().alert(_WFT("mount", "umount"), _JSLIBSTR("uicommon", "error_demo")) : i.hasSelection() && (e = i.getSelections(), 1 === e.length) ? (t = e[0].get("file_id"), this.onCheckVFSAction("umount", e) ? this.onCheckPrivilege("umount", e, !1, !1) ? void this.FileAction.Umount(e, [t]) : void this.owner.getMsgBox().alert(_WFT("mount", "umount"), _WFT("error", "error_privilege_not_enough")) : void this.owner.getMsgBox().alert(_WFT("mount", "umount"), _WFT("error", "not_support"))) : void 0
    },
    onExtractClick: function() {
        if (_S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _JSLIBSTR("uicommon", "error_demo"));
        var e = this.getExtractRec(0);
        e && this.FileAction.Extract(e, this.userId, this.userGroup)
    },
    onExtractHereClick: function() {
        if (_S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _JSLIBSTR("uicommon", "error_demo"));
        var e = this.getExtractRec(1);
        e && this.FileAction.ExtractNoDialog(e, !1)
    },
    onExtractFolderNameClick: function() {
        if (_S("demo_mode")) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_compress"), _JSLIBSTR("uicommon", "error_demo"));
        var e = this.getExtractRec(2);
        e && this.FileAction.ExtractNoDialog(e, !0)
    },
    onAddFav: function() {
        var e = this.activeView.getSelectionModel();
        if (!e.hasSelection()) return null;
        var t = e.getSelections();
        this.FileAction.AddFav(t)
    },
    onChangeDisplayType: function(e) {
        this.showContent != e && (this.showContent = e, this.activeDS.baseParams.filetype = this.showContent, this.activeDS.load({
            params: {
                offset: 0,
                limit: this.displayNum
            }
        }))
    },
    isViewMasked: function() {
        return this.viewPanel.getEl().isMasked()
    },
    setViewTabbable: function(e) {
        var t = this.grid,
            i = {
                tabIndex: e ? 0 : -1
            };
        t.view.focusEl.set(i), t.view.setHeaderFocusTabbable(e), t.getBottomToolbar().setTabbable(e), Ext.iterate(this.dataView, function(t, o) {
            this.dataView[t].getEl().set(i), this.dataViewPagingtoolbar[t].setTabbable(e)
        }, this)
    },
    maskView: function(e, t) {
        this.viewPanel.getEl().mask(e, t), this.setViewTabbable(!1)
    },
    unmaskView: function() {
        this.viewPanel.getEl().unmask(), this.setViewTabbable(!0)
    },
    expandTreeToDir: function(e, t, i) {
        if (t.length > 1) {
            this.enableDisableToolbarBtn(!0), this.fileSearch.disableAdvancedSearch = !1;
            var o = t[0];
            if (this.blExpanded || !o && !this.initPath) return;
            this.blExpanded = !0, i && (this.unmaskView(), this.onChangeDir(this.initPath ? this.initPath : o.attributes.path))
        } else this.enableDisableToolbarBtn(!1), this.fileSearch.disableAdvancedSearch = !0, this.activeDS.removeAll(), this.maskView(_WFT("error", "error_no_shared_folder"));
        this.onUpdateBtnStatus(), t.length <= 1 && !_S("diskless") && !0 === _S("is_admin") && !_S("ha_safemode") && (_S("standalone") ? this.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "alert_noshare")) : this.owner.getMsgBox().show({
            title: _T("tree", "leaf_filebrowser"),
            msg: _T("filebrowser", "prompt_noshare"),
            width: 300,
            buttons: Ext.MessageBox.OKCANCEL,
            fn: function(e) {
                "ok" == e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Share.Main",
                    dlg: "create"
                })
            }
        }))
    },
    switchSource: function(e) {
        var t;
        if ((t = this.getCurrentSource()) !== e && (this.setCurrentSource(e), e.substr(0, 5) !== SYNO.webfm.utils.source.local || !SYNO.webfm.utils.isLocalSource(t))) {
            e !== SYNO.webfm.utils.source.remotes && this.fileSearch.setValue("");
            var i = this.grid.getStore();
            if (this.setSortColumnModel(!0), this.enableDisableFilterBtn(!0), this.paging.hideLoading(), this.unmaskView(), e.substr(0, 6) === SYNO.webfm.utils.source.remote) {
                var o;
                this.appWindow.getPanelInstance().btnViewMode.setDisabled(!1), e === SYNO.webfm.utils.source.remotes ? (this.setSortColumnModel(this.remoteSearchDS.blSearhDone), o = this.remoteSearchDS, this.remoteSearchDS.blSearhDone ? this.remoteSearchDS.reload() : (0 === o.getCount() && this.maskView(_WFT("common", "searching"), "x-mask-loading"), this.paging.showLoading()), this.grid.reconfigure(o, this.cmWithppath)) : (o = this.remoteDS, this.grid.reconfigure(o, this.cmNoppath)), Ext.iterate(this.dataView, function(e, t) {
                    this.dataView[e].bindStore(o), this.dataViewPagingtoolbar[e].unbind(i), this.dataViewPagingtoolbar[e].bind(o)
                }, this), this.paging.unbind(i), this.paging.bind(o), t.substr(0, 5) === SYNO.webfm.utils.source.local && this.onShowUpSubMenu(!0), this.btnMountISO && this.btnMountISO.enable(), SYNO.webfm.utils.isRemoteSource(e) && e !== SYNO.webfm.utils.source.remotev ? (this.btnNewFolder.enable(), this.onDisableUpButton(!1)) : (this.btnNewFolder.disable(), this.onDisableUpButton(!0)), this.activeDS = o
            } else this.appWindow.getPanelInstance().btnViewMode.resetViewMode(), this.appWindow.getPanelInstance().btnViewMode.setDisabled(!0), this.grid.reconfigure(this.localDS, this.cmNoppath), this.paging.unbind(i), this.paging.bind(this.localDS), this.btnMountISO && this.btnMountISO.disable(), this.btnNewFolder.enable(), this.onShowUpSubMenu(!1), this.activeDS = this.localDS;
            this.gridCtxMenu.get("gc_sort").bindEvent(this.activeDS), this.btnSort.bindEvent(this.activeDS), this.fileSearch.store = this.activeDS
        }
    },
    isPathEqualLastHistory: function(e) {
        var t = this.historyIndex;
        return !(t < 0 || this.historyCnt < t) && (e === this.historyPath[t].directory && this.historyPath[t].source === this.getCurrentSource())
    },
    historySet: function(e) {
        if (!this.isPathEqualLastHistory(e)) {
            var t = ++this.historyIndex;
            this.historyPath = this.historyPath.slice(0, t), this.historyPath[t] = {
                directory: e,
                source: this.getCurrentSource()
            }, this.historyCnt = this.historyIndex, this.historyBtnCheck(), this.updateAllHistoryMenu()
        }
    },
    historyBtnCheck: function() {
        var e = this.historyIndex;
        e === this.historyCnt ? this.btnHisNext.disable() : this.btnHisNext.enable(), 0 === e ? this.btnHisBack.disable() : this.btnHisBack.enable()
    },
    onChangeDir: function(e, t) {
        if (e && "fm_root" != e && "fm_local_root" != e && "fm_vd_root" !== e && "fm_rf_root" !== e && "fm_fav_root" !== e) {
            SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.C2FS.Application") && SYNO.webfm.utils.isInHybridShareFolder(e, this.hybridShares) && this.updateHybridShares(), this.activeView.getSelectionModel().clearAllSelections(!0), !0 !== t && this.historySet(e);
            var i = this.getCurrentDir();
            this.setCurrentDir(e), this.getCurrentSource() !== SYNO.webfm.utils.source.remotes && this.fileSearch.setValue(""), this.fileFilter.setValue("");
            var o;
            if (this.getCurrentSource() === SYNO.webfm.utils.source.remotes && "remotesfm_search_root" === e) {
                var n = [],
                    s = _WFT("search", "search_results") + ": " + this.searchPanel.getLocation();
                return n[0] = new this.pathButtonInfo(s, s, e), this.pathBar.addPathButtons(n), this.pathBar.tbPanel.el.addClass("with-right-border"), void((o = this.dirTree.getNodeById("fm_search_root")) && this.dirTree.getSelectionModel().select(o))
            }
            this.getCurrentSource() === SYNO.webfm.utils.source.remotes && this.switchSource(SYNO.webfm.utils.source.remote), this.activeDS.removeAll(), this.activeDS.baseParams.filetype = this.showContent, this.activeDS.baseParams.folder_path = e;
            var r;
            !Ext.isWindows || SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) ? (SYNO.webfm.utils.isParentDir(i, e) && (this.highlightId = i), this.updateCurrentPathLink(e), r = e.lastIndexOf("/")) : (SYNO.webfm.utils.isWinParentDir(i, e) && (this.highlightId = i), this.updateWinCurrentPathLink(e), r = 2 == e.lastIndexOf("\\") ? 3 : e.lastIndexOf("\\")), this.activeDS.load({
                params: {
                    offset: 0,
                    limit: this.displayNum
                }
            });
            var a, l; - 1 != r && (a = e.substr(0, r));
            var h = this.getCurrentSource().substr(0, 6) === SYNO.webfm.utils.source.remote ? this.dirTree : this.dirLocalTree;
            l = h.getNodeById(this.getCurrentSource() + a), l && l.expand(), o = h.getNodeById(this.getCurrentSource() + e), o ? (h.getSelectionModel().select(o), this.changeToolbarMode(o), this.showHideCols(i, o)) : l && l.reload(function() {
                (o = h.getNodeById(this.getCurrentSource() + e)) && (h.getSelectionModel().select(o), this.changeToolbarMode(o), this.showHideCols(i, o))
            }.createDelegate(this)), SYNO.webfm.utils.isInRecycleBinFolder(this.getCurrentDir()) && this.onDisableUpButton(!0), this.grid.view.focusEl.set({
                "aria-label": e
            }), Ext.iterate(this.dataView, function(t, i) {
                this.dataView[t].el.set({
                    "aria-label": e
                })
            }, this)
        }
    },
    showHideCols: function(e, t) {
        if (this.activeView === this.grid) return SYNO.webfm.utils.isSnapshotTopFolder(t.attributes.path, t.attributes.is_snapshot) ? void this.grid.addClass("file-name-only") : void(e && SYNO.webfm.utils.isSnapshotTopFolder(e, !0) && this.grid.removeClass("file-name-only"))
    },
    changeToolbarMode: function(e) {
        var t = !0,
            i = !0;
        e && e.attributes && (e.attributes.is_snapshot && (t = !1, i = !1), this.onCheckVFSAction("create", e) || (t = !1), this.btnNewFolder.setDisabled(!t), this.onCheckVFSAction("upload", e) || (i = !1), SYNO.webfm.utils.isInRecycleBinFolder(this.getCurrentDir()) || this.btnRemoteUpload.setDisabled(!i))
    },
    isDiffVolume: function() {
        if (null === this.currVolume) return !0;
        var e = this.dirTree.getSelectionModel(),
            t = e.getSelectedNode();
        if (!t) return !1;
        if ("fm_root" == t.id) return !1;
        var i = t.attributes.real_path,
            o = i.indexOf("/", 1);
        if (-1 == o) return !1;
        var n = i.substring(1, o);
        return n != this.currVolume && (this.currVolume = n, !0)
    },
    onRemoveAllExternMenu: function() {
        this.onRemoveExternMenu(this.gridCtxMenu), this.onRemoveExternMenu(this.toolbarMenu)
    },
    setShowHide: function(e, t) {
        e.setVisible(!e.disabled && t)
    },
    onUpdateBtnStatus: function(e, t) {
        t = t || this.activeView.getSelectionModel().getSelections();
        var i, o, n, s = this.gridCtxMenu.items,
            r = SYNO.webfm.utils.isLocalSource(this.getCurrentSource()),
            a = this.getCurrentSource() === SYNO.webfm.utils.source.remotes,
            l = [],
            h = !1,
            c = !0,
            d = !0,
            u = !0,
            f = !0;
        this.enableDisableActionBtn(!1), this.enableDisableContextBtn(!1), this.onLocalShowHideContextBtn(!0), this.onLocalShowHideActionBtn(!0), this.onSearchShowHideContextBtn(!0), this.onSearchShowHideActionBtn(!0), a ? (this.onSearchShowHideContextBtn(!1), this.onSearchShowHideActionBtn(!1)) : r && (this.onLocalShowHideContextBtn(!1), this.onLocalShowHideActionBtn(!1));
        var m = t.length;
        if (1 === m && "remotefail" === t[0].get("mountType")) return void this.enableDisableContextBtn(!1);
        i = t && t[0] ? t[0].get("path") : this.getCurrentDir(), s.get("gc_createfolder").setDisabled(!1), i && SYNO.webfm.VFS.isVFSPath(i) && (h = !0, o = SYNO.webfm.VFS.getBaseURI(i), (n = this.dirTree.getNodeById("remote" + o)) && n.attributes.api && (l = n.attributes.api)), this.onHideSharingBtns(!this.supportSharing || h), this.onHideShowFileRequestBtns(!this.supportFileRequest || h);
        var p, g, b = !1,
            S = !1,
            _ = !1;
        for (g = 0; g < t.length; g++)
            if (t[g].get("is_snapshot")) {
                S = !0;
                break
            } _ = 1 === t.length && SYNO.webfm.utils.isSnapshotTopFolder(t[0].get("path"), t[0].get("is_snapshot")), r || SYNO.webfm.utils.source.remotes === this.getCurrentSource() || (b = SYNO.webfm.utils.source.remotev === this.getCurrentSource()) || (n = this.dirTree.getNodeById(this.getCurrentSource() + this.getCurrentDir())) && (b = n.attributes.type === SYNO.webfm.utils.source.remotev || "iso" === n.attributes.mountType || S);
        var w = this.blUploadSubMenu ? this.btnUpSubMenuAction : this.btnUpBrowserAction;
        r ? (this.btnUpBrowserAction.show(), this.btnUpBrowserAction.setText(_WFT("filetable", "filetable_upload")), this.btnUpBrowserAction.enable(), this.btnOpenWin.setText(_WFT("filetable", "openfile")), this.gridCtxMenu.items.get("gc_openwin").setText(_WFT("filetable", "openfile"))) : (p = this.getCurrentDir(), 1 === t.length && t[0].get("isdir") ? p = t[0].get("filename") : p && (p = p.substr(p.lastIndexOf("/") + 1)), w.setText(String.format(_WFT("filetable", "upload_ddtext") + " ", Ext.util.Format.ellipsis(p, 36))), this.btnOpenWin.setText(_WFT("filetable", "filetable_openwin")), this.gridCtxMenu.items.get("gc_openwin").setText(_WFT("filetable", "filetable_openwin")), w.show(), w.setDisabled(b || h && !this.onCheckVFSAction("upload", i, null, l))), this.onRemoveAllExternMenu();
        var x = !1;
        if (0 === t.length && SYNO.webfm.utils.isInRecycleBinFolder(this.getCurrentDir())) w.hide();
        else if (t.length > 0) {
            var v = !0,
                y = !0,
                F = !0,
                T = !0,
                N = !0,
                E = !0,
                C = !0,
                D = !1,
                O = !1,
                k = !1,
                P = !1,
                Y = !1;
            if (x = 1 === m && !0 === t[0].get("isdir"), Ext.each(t, function(e) {
                    if (Y = Y || SYNO.webfm.utils.isInRecycleBinFolder(e.get("path")), !0 === e.get("isdir") ? (D = !0, k = SYNO.webfm.utils.isRecycleBinFolder(e.get("path")), P = SYNO.webfm.utils.isWebFolder(e.get("path"))) : O = !0, D && k) return !1
                }), (D || h && !this.onCheckVFSAction("download", i, null, l)) && (F = !1), (r || k || Y || S || h) && (T = !1), (r || k || Y || S || b || h || O || P || 1 !== t.length) && (C = !1), (m > 1 || S || b || h && !this.onCheckVFSAction("rename", i, null, l)) && (y = !1), this.btnRename.setDisabled(!y), s.get("gc_rename").setDisabled(!y), (!r && !x || k || Y) && w.hide(), this.btnOpenWin.setDisabled(!F), this.btnShare.setDisabled(!T), this.btnFileRequest.setDisabled(!C), s.get("gc_openwin").setDisabled(!F), F ? (s.get("gc_openwin").show(), this.btnOpenWin.show()) : (s.get("gc_openwin").hide(), this.btnOpenWin.hide()), s.get("gc_share") && (s.get("gc_share").setDisabled(!T), T ? this.supportSharing && (s.get("gc_share").show(), this.btnShare.show()) : (s.get("gc_share").hide(), this.btnShare.hide())), s.get("gc_filerequest") && (s.get("gc_filerequest").setDisabled(!C), C ? this.supportFileRequest && (s.get("gc_filerequest").show(), this.btnFileRequest.show()) : (s.get("gc_filerequest").hide(), this.btnFileRequest.hide())), !r) {
                for (!0 !== e && this.onUpdateExternMenu(t, h), g = 0; g < m; g++)
                    if (!SYNO.webfm.utils.isCompressFile(t[g].get("filename"), t[g].get("type"))) {
                        v = !1;
                        break
                    } h && (v = !1, N = !1, E = !1), 1 === m && -1 !== SYNO.webfm.utils.image_type.indexOf(t[0].get("type").toLowerCase()) || (N = !1), (1 !== m || "iso" !== t[0].get("mountType") && "remote" !== t[0].get("mountType") && "remotefail" !== t[0].get("mountType")) && (E = !1);
                var M = this.getSuggestZipName(t);
                if (40 < M.length && (M = M.slice(0, 37) + " ... .zip"), this.gridCtxMenu.items.get("gc_compress").setText(_WFT("filetable", "filetable_compress_to") + " " + M), this.btnCompress.setText(_WFT("filetable", "filetable_compress_to") + " " + M), v) {
                    var I = s.get("gc_extract_menu").menu.items,
                        A = this.btnExtractMenu.menu.items;
                    m > 1 ? (A.get("gc_extract_folder").setText(_WFT("filetable", "filetable_extract_separate_folder")), I.get("gc_extract_folder").setText(_WFT("filetable", "filetable_extract_separate_folder"))) : (p = SYNO.webfm.utils.getZipName(t[0].get("filename")), 40 < p.length && (p = M.slice(0, 37) + " ... "), A.get("gc_extract_folder").setText(_WFT("filetable", "filetable_extract_to") + " " + p + "/"), I.get("gc_extract_folder").setText(_WFT("filetable", "filetable_extract_to") + " " + p + "/"))
                }
                this.btnExtractMenu.setDisabled(!v), s.get("gc_extract_menu").setDisabled(!v), v ? (this.btnExtractMenu.show(), s.get("gc_extract_menu").show()) : (this.btnExtractMenu.hide(), s.get("gc_extract_menu").hide()), "yes" === _D("supportmount") && (N ? (this.btnMountISO && this.btnMountISO.enable(), this.gridCtxMenu.items.get("gc_mount_iso") && this.gridCtxMenu.items.get("gc_mount_iso").show()) : (this.btnMountISO && this.btnMountISO.disable(), this.gridCtxMenu.items.get("gc_mount_iso") && this.gridCtxMenu.items.get("gc_mount_iso").hide()), E ? (this.btnUmount && this.btnUmount.enable(), this.gridCtxMenu.items.get("gc_umount") && this.gridCtxMenu.items.get("gc_umount").show()) : (this.btnUmount && this.btnUmount.disable(), this.gridCtxMenu.items.get("gc_umount") && this.gridCtxMenu.items.get("gc_umount").hide()));
                var W = !0,
                    R = !1;
                Ext.each(t, function(e) {
                    return W = !this.checkFTPDownloadRightByPath(e.get("file_id"))
                }, this), h && !this.onCheckVFSAction("download", i, null, l) && (W = !1), _ || (W ? (R = !D && 1 < t.length && SYNO.webfm.utils.isSupportMultiDownload(), this.btnDownloadMenu.enable(), this.btnDownload.enable(), this.onShowHideMultiDownload(R), 1 != AppletProgram.blJavaPermission && (s.get("gc_download").setVisible(!R), s.get("gc_multidownload_menu").setVisible(R)), s.get("gc_download_menu").enable(), s.get("gc_download").enable(), s.get("gc_multidownload_menu").enable()) : 1 != AppletProgram.blJavaPermission && (s.get("gc_download").setVisible(!0), s.get("gc_multidownload_menu").setVisible(!1))), h || r || (this.btnFavSubMenu.setVisible(x), this.btnDSMShortcut.setVisible(!x && !_S("standalone")), this.btnFavSubMenu.menu.items.get("gc_dsmshortcut").setVisible(!_S("standalone")), this.sepFav.setVisible(!_S("standalone") || _S("standalone") && x), s.get("gc_fav_menu").setVisible(x), s.get("gc_dsmshortcut").setVisible(!x && !_S("standalone")), s.get("gc_fav_menu").menu.items.get("gc_dsmshortcut").setVisible(!_S("standalone")), s.get("gc_sep_fav").setVisible(!_S("standalone") || _S("standalone") && x), this.btnCompressAdv.show(), this.btnCompress.show(), s.get("gc_compress_adv").show(), s.get("gc_compress").show(), b || (this.btnCompressAdv.enable(), this.btnCompress.enable(), s.get("gc_compress_adv").enable(), s.get("gc_compress").enable()))
            }
            this.btnProperty.enable(), s.get("gc_property").enable(), (_ || h && !this.onCheckVFSAction("move", i, null, l)) && (c = !1), (_ || h && !this.onCheckVFSAction("copy", i, null, l)) && (d = !1), this.btnMVCPToMenu.setDisabled(!c && !d), s.get("mvcpto").setDisabled(!c && !d), this.btnCopy.setDisabled(!d), s.get("gc_copy").setDisabled(!d), this.btnMVCPToMenu.setOvwrVisible(r), s.get("mvcpto").setOvwrVisible(r), this.btnMVCPToMenu.setMoveDisabled(b || !c), s.get("mvcpto").setMoveDisabled(b || !c), b || (h && !this.onCheckVFSAction("move", i, null, l) && (u = !1), u && (this.btnCut.enable(), s.get("gc_cut").enable()), h && !this.onCheckVFSAction("delete", i, null, l) && (f = !1), f && (this.btnDelete.enable(), s.get("gc_delete").enable())), this.grid.getStore().storetype === SYNO.webfm.utils.source.remotes && (this.onSearchShowHideContextBtn(!1), this.onSearchShowHideActionBtn(!1), "yes" === _D("supportmount") && s.get("gc_sep_archive").setVisible(E || N), x || (this.btnUpSubMenuAction.setHidden(!0), this.btnUpBrowserAction.setHidden(!0)))
        }
        var B = !SYNO.FileStation.Clipboard.isEmpty(),
            V = SYNO.FileStation.Clipboard.get();
        this.getCurrentSource() === SYNO.webfm.utils.source.remotes && (B &= x), h && V && !this.onCheckVFSAction(V.action, V.recs, i, null, l) && (B = !1), n = this.dirTree.getSelectionModel().getSelectedNode();
        var L, U = this.checkFtpModifyRight(n);
        U ? (this.btnPasteOvwr.setText(_WFT("filetable", "filetable_paste")), s.get("gc_paste_ovwr").setText(_WFT("filetable", "filetable_paste"))) : (L = _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_overwrite"), this.btnPasteOvwr.setText(L), s.get("gc_paste_ovwr").setText(L)), this.btnPasteOvwr.setVisible(B), this.btnPasteSkip.setVisible(B && !U), s.get("gc_paste_ovwr").setVisible(B), s.get("gc_paste_skip").setVisible(B && !U), this.btnPasteOvwr.setDisabled(b), this.btnPasteSkip.setDisabled(b), s.get("gc_paste_ovwr").setDisabled(b), s.get("gc_paste_skip").setDisabled(b), s.get("gc_sort").setVisible(0 === t.length), s.get("gc_snapshot_history").setVisible(1 === t.length && t[0].get("has_snapshot"));
        var H = !0;
        (S || h && !this.onCheckVFSAction("create", this.getCurrentDir(), null, l) || "remotes" === this.getCurrentSource()) && (H = !1), s.get("gc_createfolder").setDisabled(!H)
    },
    enableDisableFilterBtn: function(e) {
        e ? (this.fileSearch.enable(), this.displayType.enable()) : (this.displayType.disable(), this.fileSearch.disable(), this.fileSearch.setValue(""))
    },
    enableDisableToolbarBtn: function(e) {
        e ? (this.btntoolbarMenu.enable(), this.onDisableUpButton(!1), this.btnNewFolder.enable(), this.btnMountRemote && this.btnMountRemote.enable()) : (this.btntoolbarMenu.disable(), this.onDisableUpButton(!0), this.btnNewFolder.disable(), this.btnMountRemote && this.btnMountRemote.disable()), this.enableDisableFilterBtn(e)
    },
    enableDisableActionBtn: function(e) {
        e ? (this.btnOpenWin.enable(), this.btnShare.enable(), this.btnFileRequest.enable(), this.btnDownload.enable(), this.btnDownloadMenu.enable(), this.btnExtractMenu.enable(), this.btnCut.enable(), this.btnCopy.enable(), this.btnDelete.enable(), this.btnRename.enable(), this.btnProperty.enable(), this.btnCompressAdv.enable(), this.btnCompress.enable(), this.btnUmount && this.btnUmount.enable()) : (this.btnOpenWin.disable(), this.btnShare.disable(), this.btnFileRequest.disable(), this.btnDownload.disable(), this.btnDownloadMenu.disable(), this.btnExtractMenu.disable(), this.btnCut.disable(), this.btnCopy.disable(), this.btnDelete.disable(), this.btnRename.disable(), this.btnProperty.disable(), this.btnCompressAdv.disable(), this.btnCompress.disable(), this.btnUmount && this.btnUmount.disable()), this.btnMVCPToMenu.setDisabled(!e), this.btnMountISO && this.btnMountISO.setDisabled(!e), this.btnPasteOvwr.hide(), this.btnPasteSkip.hide(), this.btnFavSubMenu.setVisible(e), this.btnDSMShortcut.setVisible(e), this.sepFav.setVisible(e)
    },
    enableDisableContextBtn: function(e) {
        (this.blUploadSubMenu ? this.btnUpSubMenuAction : this.btnUpBrowserAction).setHidden(!e);
        var t = this.gridCtxMenu.items,
            i = t.get("gc_download"),
            o = t.get("gc_download_menu"),
            n = t.get("gc_multidownload_menu"),
            s = t.get("gc_extract_menu"),
            r = t.get("gc_cut"),
            a = t.get("gc_copy"),
            l = t.get("gc_delete"),
            h = t.get("gc_rename"),
            c = t.get("gc_property"),
            d = t.get("gc_openwin"),
            u = t.get("gc_share"),
            f = t.get("gc_filerequest"),
            m = t.get("gc_compress_adv"),
            p = t.get("gc_compress"),
            g = t.get("gc_mount_iso"),
            b = t.get("gc_umount");
        e ? (i.enable(), o.enable(), n.enable(), s.enable(), r.enable(), a.enable(), l.enable(), h.enable(), c.enable(), d.enable(), u && u.enable(), f && f.enable(), m.enable(), p.enable(), g && g.show(), b && b.show()) : (i.disable(), o.disable(), n.disable(), s.disable(), r.disable(), a.disable(), l.disable(), h.disable(), c.disable(), d.disable(), u && u.disable(), f && f.disable(), m.disable(), p.disable(), g && g.hide(), b && b.hide()), t.get("mvcpto").setDisabled(!e), t.get("gc_paste_ovwr").setVisible(!1), t.get("gc_paste_skip").setVisible(!1), t.get("gc_fav_menu").setVisible(e), t.get("gc_dsmshortcut").setVisible(e), t.get("gc_sep_fav").setVisible(e)
    },
    onCommonShowHideActionBtn: function(e) {
        this.toolbarMenu.get("sep_extract").setVisible(e), this.setShowHide(this.btnExtractMenu, e), this.btnCompressAdv.setVisible(e), this.btnCompress.setVisible(e), this.toolbarMenu.get("sep_archive").setVisible(e)
    },
    onCommonShowHideContextBtn: function(e) {
        var t = this.gridCtxMenu.items;
        this.setShowHide(t.get("gc_extract_menu"), e), t.get("gc_compress_adv").setVisible(e), t.get("gc_compress").setVisible(e), t.get("gc_sep_archive").setVisible(e)
    },
    onLocalShowHideActionBtn: function(e) {
        this.onCommonShowHideActionBtn(e), this.onShowHideMultiDownload(!e), this.btnCompressAdv.setVisible(e), this.btnCompress.setVisible(e), this.setShowHide(this.btnShare, e)
    },
    onShowHideMultiDownload: function(e) {
        1 === AppletProgram.blJavaPermission ? (this.btnDownloadMenu.setVisible(!e), this.btnDownload.hide(), this.btnMultiDownloadMenu.hide()) : (this.btnDownload.setVisible(!e), this.btnMultiDownloadMenu.setVisible(e), this.btnDownloadMenu.hide())
    },
    onLocalShowHideContextBtn: function(e) {
        this.onCommonShowHideContextBtn(e);
        var t = this.gridCtxMenu.items;
        1 === AppletProgram.blJavaPermission ? (t.get("gc_download_menu").setVisible(e), t.get("gc_multidownload_menu").hide(), t.get("gc_download").hide()) : (t.get("gc_download").setVisible(e), t.get("gc_multidownload_menu").setVisible(e), t.get("gc_download_menu").hide()), t.get("gc_compress_adv").setVisible(e), t.get("gc_compress").setVisible(e), t.get("gc_share") && this.setShowHide(t.get("gc_share"), e)
    },
    onSearchShowHideActionBtn: function(e) {
        this.onCommonShowHideActionBtn(e)
    },
    onSearchShowHideContextBtn: function(e) {
        this.onCommonShowHideContextBtn(e), this.gridCtxMenu.items.get("gc_open").setVisible(!e)
    },
    onHideSharingBtns: function(e) {
        var t = this.gridCtxMenu.items.get("gc_share");
        t && (e ? t.hide() : t.show()), this.btnShare && (e ? this.btnShare.hide() : this.btnShare.show())
    },
    onHideShowFileRequestBtns: function(e) {
        var t = this.gridCtxMenu.items.get("gc_filerequest");
        t && (e ? t.hide() : t.show()), this.btnFileRequest && (e ? this.btnFileRequest.hide() : this.btnFileRequest.show())
    },
    onAddShortCut: function(e) {
        var t, i = this;
        t = this.activeView.getSelectionModel().getSelections(), 0 !== t.length && Ext.each(t, function(e) {
            var t = {
                className: "SYNO.SDS.App.FileStation3.Instance",
                absoluteIcon: "webman/modules/FileBrowser/" + i.getDeskShortIcon(e),
                moduleTitle: e.get("filename"),
                isModule: !0,
                param: {
                    openfile: e.get("file_id")
                }
            };
            SYNO.SDS.Desktop.addLaunchItem(t, -1, {
                saveState: !0
            })
        })
    },
    getDeskShortIcon: function(e) {
        var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle"),
            i = "classical" === t,
            o = i ? 48 : 64;
        return e.get("isdir") && "isomountpoint.png" !== e.get("icon") && "remotefailmountpoint.png" !== e.get("icon") && "remotemountpoint.png" !== e.get("icon") ? "images/{1}/files_ext_" + o + "/" + e.get("icon") : e.get("isdir") ? "images/{1}/files_ext_" + o + "/folder.png" : "images/{1}/files_ext_" + o + "/" + e.get("icon")
    },
    onGetShortCutRecs: function(e) {
        var t, i, o = [];
        return e.forEach(function(e) {
            t = e.get("filename"), i = {
                isdir: e.get("isdir"),
                type: e.get("type").toLowerCase(),
                file_id: e.get("file_id"),
                filename: t
            }, Ext.apply(i, e.get("isdir") ? {
                opendir: e.get("file_id")
            } : {
                openfile: e.get("file_id")
            }), t = Ext.util.Format.htmlEncode(t), o.push({
                config: {
                    className: "SYNO.SDS.App.FileStation3.Instance",
                    title: t,
                    desc: Ext.util.Format.htmlEncode(e.get("file_id")),
                    icon: this.getDeskShortIcon(e),
                    param: i,
                    removable: !0
                },
                pos: -1,
                skipRegister: !1
            })
        }, this), o
    },
    onCheckSnapshotAction: function(e, t) {
        var i, o = ["rename", "move", "delete"],
            n = !1;
        for (i = 0; i < o.length; i++)
            if (e === o[i]) {
                n = !0;
                break
            } if (!1 === n) return !1;
        for (i = 0; i < t.length; i++)
            if (!0 === t[i].get("is_snapshot")) return !0;
        return !1
    },
    onCheckVFSAction: function(e, t, i, o, n) {
        function s(e) {
            var t, i;
            return SYNO.webfm.VFS.isVFSPath(e) ? (t = SYNO.webfm.VFS.getBaseURI(e), i = h.dirTree.getNodeById(SYNO.webfm.utils.source.remote + t), i && i.attributes && i.attributes.api ? i.attributes.api : null) : null
        }

        function r(e, t) {
            return !(e && e.blVFS && e.api && Ext.isArray(e.api)) || -1 !== e.api.indexOf(t)
        }

        function a(e, t) {
            var i = "";
            Ext.isFunction(e.get) ? i = e.get("path") : e.attributes && e.attributes.path ? i = e.attributes.path : Ext.isString(e) && (i = e), Ext.isEmpty(i) || (Ext.isEmpty(t.api) && (t.api = s(i)), SYNO.webfm.VFS.isVFSPath(i) && (t.blVFS = !0), SYNO.webfm.VFS.isRootFolder(i) && (t.blServerRoot = !0), SYNO.webfm.VFS.isGDriveRootPath(i) && (t.blGDriveRoot = !0), SYNO.webfm.VFS.isGDriveDefaultFolder(i) && (t.blGDriveDefaultFolder = !0), SYNO.webfm.VFS.isGDriveStarsPath(i) && (t.blGDriveStarred = !0), SYNO.webfm.VFS.isGDriveStarsFirstLevelPath(i) && (t.blGDriveStarredFirstLevel = !0), SYNO.webfm.VFS.isSharingPath(i) && (t.blSharingVFS = !0))
        }

        function l(e, t, i) {
            var o;
            if (Ext.apply(t, {
                    api: Ext.isEmpty(i) ? null : i,
                    blVFS: !1,
                    blServerRoot: !1,
                    blGDriveRoot: !1,
                    blGDriveDefaultFolder: !1,
                    blGDriveStarred: !1,
                    blGDriveStarredFirstLevel: !1,
                    blSharingVFS: !1
                }), !Ext.isEmpty(e))
                if (Ext.isArray(e))
                    for (o = 0; o < e.length; o++) a(e[o], t);
                else a(e, t)
        }
        var h = this,
            c = {},
            d = {};
        if (l(t, c, o), l(i, d, n), !c.blVFS && !d.blVFS) return !0;
        switch (e) {
            case "create":
                if (c.blGDriveRoot || d.blGDriveRoot || c.blGDriveStarred || d.blGDriveStarred || c.blSharingVFS || d.blSharingVFS || !r(c, "SYNO.FileStation.CreateFolder") || !r(d, "SYNO.FileStation.CreateFolder")) return !1;
                break;
            case "delete":
                if (c.blServerRoot || c.blGDriveDefaultFolder || d.blServerRoot || d.blGDriveDefaultFolder || c.blSharingVFS || d.blSharingVFS || !r(c, "SYNO.FileStation.Delete") || !r(d, "SYNO.FileStation.Delete")) return !1;
                break;
            case "upload":
                if (c.blGDriveRoot || c.blGDriveStarred || d.blGDriveRoot || d.blGDriveStarred || c.blSharingVFS || d.blSharingVFS || !r(c, "SYNO.FileStation.Upload") || !r(d, "SYNO.FileStation.Upload")) return !1;
                break;
            case "download":
                if (c.blServerRoot || d.blServerRoot || !r(c, "SYNO.FileStation.Download") || !r(d, "SYNO.FileStation.Download")) return !1;
                break;
            case "copy":
                if (c.blServerRoot || d.blGDriveRoot || d.blGDriveStarred || d.blSharingVFS || !r(c, "SYNO.FileStation.CopyMove") || !r(d, "SYNO.FileStation.CopyMove")) return !1;
                break;
            case "move":
                if (c.blServerRoot || c.blGDriveDefaultFolder || c.blGDriveStarredFirstLevel || d.blGDriveRoot || d.blGDriveStarred || c.blSharingVFS || d.blSharingVFS || !r(c, "SYNO.FileStation.CopyMove") || !r(d, "SYNO.FileStation.CopyMove")) return !1;
                break;
            case "rename":
                if (c.blServerRoot || c.blGDriveDefaultFolder || c.blGDriveStarredFirstLevel || d.blServerRoot || d.blGDriveDefaultFolder || d.blGDriveStarredFirstLevel || c.blSharingVFS || d.blSharingVFS || !r(c, "SYNO.FileStation.Rename") || !r(d, "SYNO.FileStation.Rename")) return !1;
                break;
            case "navigate":
                return !0;
            case "extract":
            case "compress":
            case "mount":
            case "umount":
                return !1
        }
        return !0
    },
    onCheckAdminPrivilege: function(e, t, i, o) {
        var n, s, r = null;
        if (o) {
            if (!this.currCTNode || !this.currCTNode.parentNode) return !1;
            s = this.currCTNode.parentNode, this.currCTNode.parentNode && "fm_root" !== this.currCTNode.parentNode.id && "fm_fav_root" !== this.currCTNode.parentNode.id && "fm_vd_root" !== this.currCTNode.parentNode.id && "fm_rf_root" !== this.currCTNode.parentNode.id || (s = this.currCTNode)
        } else n = this.dirTree.getSelectionModel(), s = n.getSelectedNode();
        if (!s) return !0;
        switch (r = "fm_root" != s.parentNode.id ? SYNO.webfm.utils.getShareRight(this.dirTree, s) : s.attributes.right, e) {
            case "move":
            case "rename":
            case "delete":
            case "create":
            case "upload":
                if (!SYNO.webfm.utils.checkShareRight(r, SYNO.webfm.utils.RW)) return !1
        }
        return !0
    },
    onCheckPrivilege: function(e, t, i, o) {
        var n, s, r, a = null,
            l = {},
            h = !1,
            c = [];
        if (!0 === this.onCheckSnapshotAction(e, t)) return !1;
        if ("true" === _S("domainUser")) return !0;
        if (this.getCurrentSource() === SYNO.webfm.utils.source.remotes || SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) return !0;
        if (o) {
            if (!this.currCTNode || !this.currCTNode.parentNode) return !1;
            s = this.currCTNode.parentNode, this.currCTNode.parentNode && "fm_root" !== this.currCTNode.parentNode.id && "fm_fav_root" !== this.currCTNode.parentNode.id && "fm_vd_root" !== this.currCTNode.parentNode.id && "fm_rf_root" !== this.currCTNode.parentNode.id || (s = this.currCTNode)
        } else n = this.dirTree.getSelectionModel(), s = n.getSelectedNode();
        if (s && s.attributes && s.attributes.path && SYNO.webfm.VFS.isVFSPath(s.attributes.path) || t && t[0] && SYNO.webfm.VFS.isVFSPath(t[0].get("path"))) return !0;
        if (!0 === _S("is_admin")) return this.onCheckAdminPrivilege(e, t, i, o);
        if (!s) return !0;
        "fm_root" != s.parentNode.id ? (l = {
            folderRight: s.attributes.right,
            uid: s.attributes.uid,
            gid: s.attributes.gid
        }, a = SYNO.webfm.utils.getShareRight(this.dirTree, s)) : (a = s.attributes.right, h = !0);
        var d, u, f, m;
        switch (e) {
            case "create":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (!h && !o && (u = {
                        right: l.folderRight,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Create
                    }, !SYNO.webfm.utils.checkFileRight(u))) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.DestFolder.Create, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "mount":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.SrcFile.ISO, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return !1
                }
                break;
            case "umount":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                break;
            case "delete":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.SrcFile.Delete, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "upload":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (!h && (u = {
                        right: l.folderRight,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Upload
                    }, !SYNO.webfm.utils.checkFileRight(u))) return !1;
                break;
            case "download":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RO | SYNO.webfm.utils.RW)) return !1;
                if (this.checkFTPDownloadRight(s)) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], u = {
                        right: f.get("fileprivilege"),
                        needRight: f.get("isdir") ? SYNO.webfm.utils.ReqPrivilege.SrcFolder.Download : SYNO.webfm.utils.ReqPrivilege.SrcFile.Download
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "navigate":
                if (t && (u = {
                        right: t.get("fileprivilege"),
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Navigate
                    }, !SYNO.webfm.utils.checkFileRight(u))) return !1;
                break;
            case "extract":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RO | SYNO.webfm.utils.RW)) return !1;
                if (!h && 0 !== i && (1 == i ? u = {
                        right: l.folderRight,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Extract
                    } : 2 == i && (u = {
                        right: l.folderRight,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.ExtractDir
                    }), !SYNO.webfm.utils.checkFileRight(u))) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], u = {
                        curUID: this.userId,
                        curGID: this.userGroup,
                        uid: f.get("uid"),
                        gid: f.get("gid"),
                        right: f.get("fileprivilege"),
                        needRight: SYNO.webfm.utils.ReqPrivilege.SrcFile.Extract
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c), !1
                }
                break;
            case "copy":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RO | SYNO.webfm.utils.RW)) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.SrcFile.Copy, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "move":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.SrcFile.Move, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "rename":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RW)) return !1;
                if (!h && (d = SYNO.webfm.utils.ReqPrivilege.DestFolder.Move, !0 === t[0].get("isdir") && (d = SYNO.webfm.utils.ReqPrivilege.DestFolder.MoveDir), u = {
                        right: l.folderRight,
                        needRight: d
                    }, !SYNO.webfm.utils.checkFileRight(u))) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], d = SYNO.webfm.utils.ReqPrivilege.SrcFile.Move, u = {
                        right: f.get("fileprivilege"),
                        needRight: d
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
                break;
            case "compress":
                if (!SYNO.webfm.utils.checkShareRight(a, SYNO.webfm.utils.RO | SYNO.webfm.utils.RW)) return !1;
                if (!h && (u = {
                        right: l.folderRight,
                        needRight: SYNO.webfm.utils.ReqPrivilege.DestFolder.Compress
                    }, !SYNO.webfm.utils.checkFileRight(u))) return !1;
                if (t) {
                    for (c = [], m = 0; m < t.length; m++) f = t[m], u = {
                        right: f.get("fileprivilege"),
                        needRight: f.get("isdir") ? SYNO.webfm.utils.ReqPrivilege.SrcFolder.Compress : SYNO.webfm.utils.ReqPrivilege.SrcFile.Compress
                    }, SYNO.webfm.utils.checkFileRight(u) && c.push(f);
                    if (c.length != t.length) return o || (r = this.activeView.getSelectionModel(), r.clearSelections(), r.selectRecords(c)), !1
                }
        }
        return !0
    },
    initUploader: function() {
        this.updateUploader()
    },
    updateUploader: function() {
        SYNO.FileStation.FlashUploader.blFlash || 1 === AppletProgram.blJavaPermission || SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() ? this.onShowUpSubMenu(!0) : this.onShowUpSubMenu(!1), 1 === AppletProgram.blJavaPermission ? this.onShowDownSubMenu(!0) : this.onShowDownSubMenu(!1), this.updateUploaderDefer()
    },
    updateUploaderDefer: function() {
        if (!this.isDestroyed) {
            var e = this.getUploadInstance();
            if (e && this.rendered) {
                this.onShowDownSubMenu(!1);
                var t = SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload();
                t ? (e.setHTML5Uploader(), e.setMaxTaskNumber(this.maxUploadTask), this.onShowUpSubMenu(!0), this.html5UploadMgr.onAddBtnClick(this.viewPanel)) : (SYNO.FileStation.FormUploader || (SYNO.FileStation.FormUploader = new SYNO.FileStation.Action.FormUpload({
                    params: {
                        url: SYNO.API.currentManager.getBaseURL("SYNO.FileStation.FormUpload", "start", 2),
                        monitorGrid: e
                    }
                })), e.setFormUploader(), e.setMaxTaskNumber(20), this.onShowUpSubMenu(!1))
            } else this.updateUploaderDefer.createDelegate(this, []).defer(80)
        }
    },
    isOwnerDestroyed: function() {
        return !(this.owner && !this.owner.isDestroyed)
    },
    showMsg: function(e, t) {
        this.isOwnerDestroyed() ? SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", e, t) : this.owner.getMsgBox().alert(e, t)
    },
    isExternalDevice: function(e) {
        var t, i, o, n, s = !1,
            r = this.deviceObj.ExternalDeviceList;
        if (!e || !r || -1 !== e.indexOf("/", 1)) return !1;
        for (t = e.lastIndexOf("/"), i = e.substring(t + 1), o = 0; o < r.length; o++)
            if (r[o].partitions) {
                for (n = 0; n < r[o].partitions.length; n++)
                    if (r[o].partitions[n].share_name == i) {
                        this.deviceObj.dev_id = r[o].dev_id, this.deviceObj.dev_type = r[o].dev_type, s = !0;
                        break
                    } if (s) break
            } return s || (this.deviceObj.device_name = null, this.deviceObj.device_type = null), s
    },
    updateRemoteMountIcon: function() {
        if (!SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) {
            var e, t, i = SYNO.webfm.utils.source;
            this.isViewMasked() || this.getCurrentSource() !== i.remoter && this.getCurrentSource() !== i.remote || (e = this.dirTree, t = this.getCurrentDir(), SYNO.webfm.utils.updateRemoteMountIconByNode(e.getNodeById(i.remote + t)), SYNO.webfm.utils.updateRemoteMountIconByNode(e.getNodeById(i.remoter + t)))
        }
    },
    getAbsoluteUrl: function() {
        if (this.absoluteUrl) return this.absoluteUrl;
        var e = document.createElement("a");
        return e.href = "./", this.absoluteUrl = e.href, e = null, this.absoluteUrl
    },
    setGridDragToDesktop: function() {
        var e = 0,
            t = this.grid.getEl().select("div.x-grid3-row"),
            i = t ? t.elements : [],
            o = i.length,
            n = null;
        for (e = 0; e < o; e++) n = Ext.fly(i[e]), n.set({
            draggable: !0
        })
    },
    setDataViewDragToDesktop: function(e) {
        var t = 0,
            i = e.getEl().select(e.itemSelector),
            o = i ? i.elements : [],
            n = o.length,
            s = null;
        for (t = 0; t < n; t++) s = Ext.fly(o[t]), s.set({
            draggable: !0
        })
    },
    setDragToDesktop: function() {
        Ext.isIE || Ext.isIEQuirks || Ext.isIE6 || Ext.isIE7 || Ext.isIE8 || Ext.isIE9 || Ext.isIE9m || Ext.isIE9p || Ext.isIE10 || Ext.isIE10p || Ext.isIE10Touch || Ext.isIE11 || Ext.isIE12 || (SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enable_cross_browser_dd") ? this.isEnableDragToDesktop() || SYNO.SDS.DragToDesktop.init() : this.isEnableDragToDesktop() && SYNO.SDS.DragToDesktop.destroy(), this.viewPanel.getEl().dragEnable || (this.viewPanel.getEl().un("dragstart", this.onStartDrag, this), this.viewPanel.getEl().on("dragstart", this.onStartDrag, this), this.viewPanel.getEl().dragEnable = !0), this.viewPanel.getEl().drogEnable || (this.viewPanel.getEl().un("dragenter", this.onDragEnter, this), this.viewPanel.getEl().un("dragover", this.onDragOver, this), this.viewPanel.getEl().un("dragend", this.onEndDrag, this), this.viewPanel.getEl().un("drop", this.onDrop, this), this.viewPanel.getEl().on("dragenter", this.onDragEnter, this), this.viewPanel.getEl().on("dragover", this.onDragOver, this), this.viewPanel.getEl().on("dragend", this.onEndDrag, this), this.viewPanel.getEl().on("drop", this.onDrop, this), this.viewPanel.getEl().drogEnable = !0), this.currentDir && -1 !== this.currentDir.indexOf("fm_search_root") && (this.viewPanel.getEl().un("dragenter", this.onDragEnter, this), this.viewPanel.getEl().un("dragover", this.onDragOver, this), this.viewPanel.getEl().un("dragend", this.onEndDrag, this), this.viewPanel.getEl().un("drop", this.onDrop, this), this.viewPanel.getEl().drogEnable = !1), Ext.iterate(this.dataView, function(e, t) {
            this.setDataViewDragToDesktop(this.dataView[e])
        }, this), this.setGridDragToDesktop())
    },
    isEnableDragToDesktop: function() {
        return Ext.isObject(SYNO.SDS.DragToDesktop) && SYNO.SDS.DragToDesktop.isEnable()
    },
    onDragEnter: function(e) {
        e.browserEvent.dataTransfer.dropEffect = "copy", e.browserEvent.preventDefault()
    },
    onDragOver: function(e) {
        e.browserEvent.dataTransfer.dropEffect = "copy", e.browserEvent.preventDefault()
    },
    onStartDrag: function(e) {
        var t = e.browserEvent,
            i = this.getDownloadURL();
        if (i && this.tid) {
            var o = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
            Ext.each(o, function(e) {
                if (e.window && e.window.panelObj && e.window.panelObj.viewPanel) {
                    var t = e.window.panelObj;
                    t.viewPanel.getEl().un("dragenter", t.onDragEnter, t), t.viewPanel.getEl().un("dragover", t.onDragOver, t), t.viewPanel.getEl().un("drop", t.onDrop, t)
                }
            });
            var n = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x";
            this.dragDropDownloadURL = i.url, SYNO.FileStation.dragIcon = document.createElement("img"), SYNO.FileStation.dragIcon.src = "webman/modules/FileBrowser/images/" + n + "/files_ext/txt.png", void 0 !== t.dataTransfer.setDragImage && t.dataTransfer.setDragImage(SYNO.FileStation.dragIcon, -10, 20), t.effectAllowed = "all", t.dataTransfer.setData("url", encodeURI(i.url)), t.dataTransfer.setData("text", String.format("{0}:{1}:{2}:{3}", i.metaType, encodeURIComponent(i.filename), this.tid, encodeURIComponent(i.url)))
        }
    },
    onDrop: function(e) {
        if (e.browserEvent.preventDefault(), !SYNO.webfm.utils.isLocalSource(this.getCurrentSource())) {
            var t, i = e.browserEvent.dataTransfer.getData("text"),
                o = e.browserEvent.dataTransfer.getData("url"),
                n = "application/octet-stream",
                s = "",
                r = "";
            try {
                e.browserEvent.dataTransfer.clearData("url"), e.browserEvent.dataTransfer.clearData("text")
            } catch (e) {}
            if (i && (t = i.split(":"), !(t.length < 4))) {
                if (n = t[0], s = decodeURIComponent(t[1]), r = t[2], o = o ? decodeURI(o) : decodeURIComponent(t[3]), o += "&tid=" + r, "http:" === o.substring(0, 5) && "https:" === window.location.protocol) return void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("upload", "upload_error_cross_protocol"));
                var a = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite");
                if (this.activeView && this.activeView.getStore() && 0 <= this.activeView.getStore().findExact("filename", s) && !1 === a) {
                    var l = new SYNO.FileStation.DropConfirmDialog({
                        owner: this.owner
                    }, {
                        cb: {
                            fn: function(e, t) {
                                l.close(), t.overwrite && this.onTransferFile(o, n, s, t.overwrite)
                            },
                            scope: this,
                            files: [s]
                        },
                        filenames: [s]
                    }, "");
                    return void l.show()
                }
                this.onTransferFile(o, n, s, a)
            }
        }
    },
    onTransferFile: function(e, t, i, o) {
        var n = this;
        n.total = 1e6, n.loaded = 0, n.curr = 0, n.counter = 0;
        var s = new XMLHttpRequest,
            r = e.split("?");
        s.open("POST", r[0], !0), Ext.isGecko || Ext.isGecko2 || Ext.isGecko3 ? s.responseType = "arraybuffer" : s.responseType = "blob";
        var a = function(e, t, i) {
            if (s) {
                var o = _WFT("upload", "upload_error_data");
                SYNO.Debug("call terminateXhr"), setTimeout(function() {
                    SYNO.Debug("call xhr.abort()"), s && (s.onprogress = void 0, s.abort(), (Ext.isGecko || Ext.isGecko2 || Ext.isGecko3) && (s.response && (s.response = null), s.responseText && (s.responseText = null), s.responseXML && (s.responseXML = null), s.mozResponseArrayBuffer && (s.mozResponseArrayBuffer = null)), s = null)
                }, 1e3), s.synoTerminate || (s.synoTerminate = !0, n.owner.getMsgBox().hide(), e || (t ? o = _WFT("upload", "upload_error_big_file") : i && (o += "(" + i + ")"), n.owner.getMsgBox().alert(o, o)))
            }
        };
        s.onprogress = function(e) {
            try {
                if (!e || !e.lengthComputable) return n.curr >= 0 && n.curr < .4 ? n.loaded += 5e3 : n.curr >= .4 && n.curr < .7 ? n.loaded += 2e3 : n.curr >= .7 && n.curr < .8 ? n.loaded += 1e3 : n.curr >= .8 && n.curr < .9 ? n.loaded += 500 : n.curr >= .9 && n.curr < .95 ? n.loaded += 100 : n.curr >= .95 && n.curr < .97 ? n.loaded += 1 : n.curr, n.curr = n.loaded / n.total, n.owner.getMsgBox().updateProgress(n.curr), SYNO.Debug("eb.lengthComputable is unknow"), void(Ext.isSafari && e.position && e.position > 1073741824 && a(!1, !0));
                if (Ext.isSafari && e.total > 1073741824) return void a(!1, !0);
                n.owner.getMsgBox().updateProgress(e.loaded / e.total)
            } catch (e) {
                return a(), void SYNO.Debug("eb.lengthComputable is unknow")
            }
        }, s.onerror = function(e) {
            a(), SYNO.Debug("progress onerror")
        }, s.ontimeout = function() {
            a(), SYNO.Debug("progress ontimeout")
        }, s.onload = function(e) {
            var r = [],
                l = {},
                h = {};
            if (4 != s.readyState || 200 != s.status) return SYNO.Debug("response error, state=" + s.readyState + ",status=" + s.status), void a(!1, !1, s.status);
            n.owner.getMsgBox().updateProgress(1);
            try {
                h.blob = new Blob([s.response], {
                    type: t
                })
            } catch (e) {
                return SYNO.Debug("new blob error"), void a(!1, !0)
            }
            setTimeout(a, 1e3, !0, !1), l.name = i, l.filename = i, l.params = {}, l.status = "NOT_STARTED", l.file = h.blob, l.size = h.blob.size, r.push(l), n.blForceHtmlUpload = !0, (Ext.isGecko || Ext.isGecko2 || Ext.isGecko3) && (n.html5UploadMgr.uploader.html5uploader.opts.chunkmode = !0);
            var c = function e() {
                SYNO.Debug("call synoOnAllComplete"), n.html5UploadMgr.uploader.html5uploader.mun(n.html5UploadMgr.uploader.html5uploader, "onAllComplete", e), r = [], l && l.file && (l.file = null), l = null, h && h.blob && (h.blob = null), h = null
            };
            n.html5UploadMgr.uploader.html5uploader.mon(n.html5UploadMgr.uploader.html5uploader, "onAllComplete", c), n.html5UploadMgr.uploader.html5uploader.addFiles.call(n.html5UploadMgr.uploader.html5uploader, r, !0, !1, {
                overwrite: o
            }, void 0, !1, n.blForceHtmlUpload)
        }, n.owner.getMsgBox().show({
            msg: _WFT("download", "downloading"),
            width: 300,
            progress: !0,
            closable: !1,
            buttons: Ext.MessageBox.CANCEL,
            fn: function() {
                a(!0)
            },
            scope: this
        }), s.setRequestHeader("Content-type", "application/x-www-form-urlencoded"), s.send(r[1])
    },
    onEndDrag: function(e) {
        var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
        Ext.each(t, function(e) {
            if (e.window && e.window.panelObj && e.window.panelObj.viewPanel) {
                var t = e.window.panelObj;
                t.viewPanel.getEl().un("drop", t.onDrop, t), t.viewPanel.getEl().on("drop", t.onDrop, t), t.viewPanel.getEl().un("dragenter", t.onDragEnter, t), t.viewPanel.getEl().on("dragenter", t.onDragEnter, t), t.viewPanel.getEl().un("dragover", t.onDragOver, t), t.viewPanel.getEl().on("dragover", t.onDragOver, t)
            }
        });
        var i = e.browserEvent.clientX,
            o = e.browserEvent.clientY;
        !this.isEnableDragToDesktop() || Ext.isEmpty(this.dragDropDownloadURL) || i >= 0 && i <= window.outerWidth && o >= 0 && o <= window.outerHeight || Ext.Ajax.request({
            url: this.dragDropDownloadURL,
            method: "GET",
            headers: {
                "X-TEST-URL": !0
            },
            skipSynoToken: !0,
            callback: function(e, t, i) {
                414 != i.status && 413 != i.status || this.showMsg(_T("download", "download_failed"), _WFT("error", "error_too_many_files")), this.dragDropDownloadURL = null
            },
            scope: this
        })
    },
    getDownloadURL: function() {
        var e, t, i, o = {
                api: "SYNO.FileStation.Download",
                version: 2,
                method: "download",
                mode: "download"
            },
            n = [],
            s = [],
            r = [];
        if (Ext.isEmpty(n = this.onBeforeDownloadAction(!1))) return null;
        for (e = 0; e < n.length; e++) r.push(n[e].get("filename")), i = n[e].get("file_id"), s.push(i);
        return t = this.getSuggestDLName(n), Ext.applyIf(o, {
            dlname: t,
            path: Ext.encode(s),
            stdhtml: !0
        }), {
            url: this.getAbsoluteUrl() + Ext.urlAppend("fbdownload/" + encodeURI(t), Ext.urlEncode(o)),
            metaType: "application/octet-stream",
            filename: t
        }
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.WindowPanel = function(e) {
    this.initDefVal(), Ext.apply(this, e || {}), this.scanExternMenu(), this.initButtons(), this.initDS();
    var t = {
        cls: "syno-webfm",
        items: [this.initNavArea(), this.initLayout()]
    };
    this.initUploader(), SYNO.FileStation.WindowPanel.superclass.constructor.call(this, t), this.mon(this.btnRefreshTree, "click", function() {
        var e = this.searchPanel;
        e.shareStore.reload(), e.groupStore.reload(), e.userStore.reload()
    }, this), this.mon(SYNO.SDS.StatusNotifier, "sharefolderchanged", function(e) {
        switch (e) {
            case "create":
            case "move":
            case "delete":
            case "encchanged":
            case "permission":
            case "setacl":
                this.reloadTree()
        }
    }, this), this.mon(SYNO.SDS.StatusNotifier, "externaldeviceactivity", function(e) {
        "ejectdevice" !== e && "injectdevice" !== e || this.reloadTree()
    }, this, {
        buffer: 100
    }), this.mon(SYNO.FileStation.Clipboard, "set", this.updateCutIcon, this), this.mon(SYNO.SDS.StatusNotifier, "servicechanged", this.scanExternMenu, this), this.mon(SYNO.SDS.StatusNotifier, "appprivilegechanged", this.scanExternMenu, this), this.mon(SYNO.SDS.StatusNotifier, "jsconfigLoaded", this.scanExternMenu, this)
}, Ext.extend(SYNO.FileStation.WindowPanel, SYNO.FileStation.MainPanel, {
    uploadGird: null,
    blShown: !1,
    localuserpath: null,
    blJava: !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablejava") ? AppletProgram.checkJava() : !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablejava") && "yes" === _S("gpo_enable_java") && AppletProgram.checkJava(),
    initInstanceFunc: function() {
        SYNO.FileStation.instance = function() {
            return {
                getUploadInstance: function() {
                    if (!this.uploadGird)
                        if (_S("standalone")) {
                            var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance")[0];
                            this.uploadGird = e.window.panelObj.monitorPanel.getUploadGrid()
                        } else {
                            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0];
                            this.uploadGird = t ? t.getUploadGrid() : null
                        } return this.uploadGird
                },
                getFileTaskInstance: function() {
                    if (!this.localGird)
                        if (_S("standalone")) {
                            var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance")[0];
                            this.localGird = e.window.panelObj.monitorPanel.getLocalGrid()
                        } else {
                            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0];
                            this.localGird = t ? t.getLocalGrid() : null
                        } return this.localGird
                },
                getDownloadInstance: function() {
                    if (!this.downloadGird)
                        if (_S("standalone")) {
                            var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance")[0];
                            this.downloadGird = e.window.panelObj.monitorPanel.getDownloadGrid()
                        } else {
                            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0];
                            this.downloadGird = t ? t.getDownloadGrid() : null
                        } return this.downloadGird
                }
            }
        }
    },
    updateLocalEnvDefer: function() {
        if (this.owner && !0 === this.blShown) {
            if (this.owner.isDestroyed) return;
            this.initInstanceFunc(), this.initLocalDS(), this.updateUploader(), this.dirTree.updateLocalRoot(), this.dirLocalTree = this.dirTree
        } else this.updateLocalEnvDefer.createDelegate(this).defer(100)
    },
    initLayout: function() {
        this.toolbar = SYNO.FileStation.Comp.WinToolbar(this);
        var e = this.initPanel({
                flex: 1
            }),
            t = [this.toolbar, e],
            i = new SYNO.ux.Panel({
                region: "center",
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                margins: "14 14 0 14",
                items: t
            });
        if (_S("standalone")) {
            var o = new SYNO.SDS.App.FileTaskMonitorTabPanel({
                jsConfig: this.appWindow.jsConfig,
                appInstance: this.appInstance
            }, this);
            i = [i, o], this.monitorPanel = o
        }
        return i
    },
    initNavArea: function() {
        var e = {
            RELURL: this.RELURL,
            webfm: this,
            plugins: [SYNO.FileStation.FocusPanelPluginInstance]
        };
        this.dirTree = new SYNO.FileStation.MixedTreePanel(e);
        var t = new Ext.Panel({
            region: "west",
            bodyStyle: "background-color: transparent;",
            split: !0,
            width: this.appInstance.getUserSettings("treePanelWidth") || 231,
            minWidth: 150,
            maxWidth: 500,
            layout: "fit",
            items: [this.dirTree],
            listeners: {
                resize: {
                    scope: this,
                    fn: function(e, t, i, o, n, s) {
                        this.appInstance.setUserSettings("treePanelWidth", o)
                    }
                }
            }
        });
        return this.navLayout = t, SYNO.FileStation.WindowPanel.superclass.initNavArea.call(this, {}), t
    },
    pathButtonInfo: function(e, t, i) {
        this.text = e, this.path = i, this.tooltip = t
    },
    updateCurrentPathLink: function(e) {
        var t, i, o, n, s = !1;
        if ("/" == e.substr(0, 1)) t = e.substr(1).split("/");
        else {
            var r, a = e.indexOf(":");
            if (!a) return;
            r = e.substr(a + 3), r ? (t = r.split("/"), t[0] = e.substr(0, a + 3) + t[0], (i = this.dirTree.getNodeById(SYNO.webfm.utils.source.remote + t[0])) && (o = i.attributes.real_path)) : t = [e], o || (o = t[0]), s = !0
        }
        var l, h, c, d, u, f = "",
            m = 0,
            p = [];
        if (t.length <= 1) d = s ? Ext.util.Format.htmlEncode(o) : Ext.util.Format.htmlEncode(e.substr(1)), SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) ? p[0] = new this.pathButtonInfo(d, d, e) : "/" === e ? p[0] = new this.pathButtonInfo("/", "/", f) : (p[0] = new this.pathButtonInfo("/", "/", "/"), p[1] = new this.pathButtonInfo(d, d, e));
        else {
            for (this.upDirPath = "", "localh" === this.getCurrentSource() ? (this.localuserpath = this.localuserpath ? this.localuserpath : AppletProgram.getUserPath({
                    action: "getuserpath"
                }, this), m = this.localuserpath.substr(1).split("/").length - 1, l = m) : l = 0, c = 0; l < t.length; l++, c++) {
                if (n = s && 0 === c ? o : t[l], d = Ext.util.Format.htmlEncode(n), u = d, t[l].length > 50 && (f = t[l].substr(0, 47) + "...", u = Ext.util.Format.htmlEncode(f)), f = "", l !== t.length - 1) {
                    for (h = 0; l > 0 && h < l; h++) 0 === h && s || (f += "/"), f += t[h];
                    0 === l && s || (f += "/"), f += t[l]
                }
                p[c] = new this.pathButtonInfo(u, d, f)
            }
            SYNO.webfm.utils.isRemoteSource(this.getCurrentSource()) || "localh" === this.getCurrentSource() || p.splice(0, 0, new this.pathButtonInfo("/", "/", "/"))
        }
        this.pathBar.addPathButtons(p)
    },
    updateWinCurrentPathLink: function(e) {
        if (":\\" == e.substr(1, 2)) {
            var t, i, o, n, s, r, a = "",
                l = 0,
                h = [];
            if (3 == e.length) {
                e = Ext.util.Format.htmlEncode(e);
                var c = e.substr(0, 2);
                h[0] = new this.pathButtonInfo(c, c, a)
            } else
                for (t = "\\" == e.substr(e.length - 1) ? e.substr(0, e.length - 1).split("\\") : e.split("\\"), this.upDirPath = "", "localh" === this.getCurrentSource() ? (this.localuserpath = this.localuserpath ? this.localuserpath : AppletProgram.getUserPath({
                        action: "getuserpath"
                    }, this), l = this.localuserpath.split("\\").length - 1, i = l) : i = 0, n = 0; i < t.length; i++, n++) {
                    if (s = Ext.util.Format.htmlEncode(t[i]), r = s, t[i].length > 50 && (a = t[i].substr(0, 47) + "...", r = Ext.util.Format.htmlEncode(a)), a = "", i !== t.length - 1) {
                        for (o = 0; i > 0 && o < i; o++) a += t[o], a += "\\";
                        a += t[i], 0 === i && (a += "\\")
                    }
                    h[n] = new this.pathButtonInfo(r, s, a)
                }
            this.pathBar.addPathButtons(h)
        }
    },
    callFileBrowsers: function(e, t) {
        var i = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
        Ext.each(i, function(i) {
            var o = i.window.getPanelInstance();
            Ext.getClassByName("SYNO.FileStation.WindowPanel.superclass." + e).apply(o, t)
        })
    },
    setHighlightEntry: function() {
        this.callFileBrowsers("setHighlightEntry", arguments)
    },
    refreshTreeNode: function() {
        this.callFileBrowsers("refreshTreeNode", arguments)
    },
    refreshVTreeNode: function() {
        this.callFileBrowsers("refreshVTreeNode", arguments)
    },
    refreshRTreeNode: function() {
        this.callFileBrowsers("refreshRTreeNode", arguments)
    },
    refreshVFSTreeNode: function() {
        this.callFileBrowsers("refreshVFSTreeNode", arguments)
    },
    refreshFavTreeNode: function() {
        this.callFileBrowsers("refreshFavTreeNode", arguments)
    },
    updateRemoteMountIcon: function() {
        this.callFileBrowsers("updateRemoteMountIcon", arguments)
    },
    getUploadInstance: function() {
        if (!this.uploadGird)
            if (_S("standalone")) this.uploadGird = this.monitorPanel.getUploadGrid();
            else {
                var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0];
                this.uploadGird = e ? e.getUploadGrid() : null
            } return this.uploadGird
    },
    getDownloadInstance: function() {
        return SYNO.FileStation.instance().getDownloadInstance()
    },
    onChangeDisplayTypeMenu: function(e) {
        this.showContent != e && this.displayType.menu.items.forEach(function(t) {
            t.itemId === e ? t.setIconClass("syno-sds-fs-tbar-sel-display") : t.setIconClass(void 0)
        })
    },
    onChangeDisplayType: function(e) {
        this.showContent != e && (this.onChangeDisplayTypeMenu(e), SYNO.FileStation.WindowPanel.superclass.onChangeDisplayType.call(this, e))
    },
    scanExternMenu: function() {
        var e, t;
        this.externPlugins = [], this.externCodeIcon = [], this.externThumbnailExts = [], this.actionPlugins = {
            open: [],
            delete: [],
            rename: [],
            copy: [],
            move: []
        };
        for (e in SYNO.SDS.Config.FnMap)
            if (SYNO.SDS.Config.FnMap.hasOwnProperty(e) && SYNO.SDS.StatusNotifier.isAppEnabled(e)) {
                t = SYNO.SDS.Config.FnMap[e];
                var i = t.config.type;
                if ("standalone" !== i && "app" !== i && "lib" !== i && "common_lib" !== i && "SYNO.SDS.AudioStation.Application" !== e) continue;
                var o = function(o, n, s, r) {
                    var a = {
                        apptype: t.config.type,
                        version: r,
                        baseURL: t.config.jsBaseURL,
                        className: e,
                        data: o
                    };
                    if ("SYNO.SDS.AudioStation.Application" !== e || "video_player:menu_play" !== o.text) {
                        if ("SYNO.SDS.AccessFolder.FBExt" === e) return void(this.accessFolderPlugin = a);
                        if ("standalone" === i || "app" === i || "lib" === i || "common_lib" === i) {
                            if (("standalone" === t.config.type || "app" === t.config.type || Ext.isString(o.launchFn)) && this.externPlugins.push(a), Ext.isString(o.checkFn) && SYNO.SDS.JSLoad(o.checkFn), Ext.isArray(o.items) && Ext.each(o.items, function(e) {
                                    Ext.isString(e.checkFn) && SYNO.SDS.JSLoad(e.checkFn)
                                }), Ext.isString(o.getIconFn) && (SYNO.SDS.JSLoad(o.getIconFn), this.externCodeIcon.push(a)), Ext.isString(o.launchFn) && SYNO.SDS.JSLoad(o.launchFn), void 0 !== o.thumbnail && Ext.isString(o.thumbnail.checkFn) && Ext.isString(o.thumbnail.getFn)) {
                                var l = o.thumbnail,
                                    h = Ext.apply({
                                        supportFBShare: !1,
                                        checkFn: !1,
                                        getFn: !1
                                    }, l);
                                this.externThumbnailExts.push(h),
                                    h.checkFn = Ext.emptyFn, h.getFn = Ext.emptyFn, SYNO.SDS.JSLoad(l.checkFn, function() {
                                        h.checkFn = Ext.getClassByName(l.checkFn)
                                    }, this), SYNO.SDS.JSLoad(l.getFn, function() {
                                        h.getFn = Ext.getClassByName(l.getFn)
                                    }, this)
                            }
                            if (3 === r && o.actions) {
                                var c = Ext.isArray(o.actions) ? o.actions : [o.actions];
                                Ext.isArray(c) && Ext.each(c, function(e) {
                                    Ext.isObject(e) && Ext.isString(e.checkFn) && SYNO.SDS.JSLoad(e.checkFn, function() {
                                        Ext.each(e.types, function(t) {
                                            this.actionPlugins.hasOwnProperty(t) && this.actionPlugins[t].push({
                                                plugin: a,
                                                checkFn: Ext.getClassByName(e.checkFn)
                                            })
                                        }, this)
                                    }, this)
                                }, this)
                            }
                        }
                    }
                };
                Ext.isArray(t.config.fb_extern_v3) ? Ext.each(t.config.fb_extern_v3, o.createDelegate(this, [3], !0), this) : Ext.isArray(t.config.fb_extern_v2) ? Ext.each(t.config.fb_extern_v2, o.createDelegate(this, [2], !0), this) : Ext.isArray(t.config.fb_extern) && Ext.each(t.config.fb_extern, o.createDelegate(this, [1], !0), this)
            }
    },
    onInsertExternMenu: function(e, t) {
        if (!_S("ha_safemode")) {
            var i = 0,
                o = !1;
            Ext.each(this.externPlugins, function(n) {
                this.onCheckPlugin(n, e, t, !1) && (this.onInsertExternMenuItem(n, e), i++, n.data.dirdbclick && n.data.launchFn && (o = !0))
            }, this), o && 1 === e.length && e[0].get("isdir") && (this.onInsertExternMenuItem(this.accessFolderPlugin, e), i++), i > 0 && (this.gridCtxMenu.insert(i, new Ext.menu.Separator({})), this.toolbarMenu.insert(i, new Ext.menu.Separator({})))
        }
    },
    onCheckPlugin: function(e, t, i, o) {
        if (1 < t.length && !0 !== e.data.multiple) return !1;
        if (i && !e.data.vfs) return !1;
        if (!SYNO.webfm.Plugin.checkFileType(this, e.data, t)) return !1;
        if (!Ext.isString(e.data.checkFn)) return (o || e.data.text) && ("standalone" === e.apptype || "app" === e.apptype || Ext.isString(e.data.launchFn));
        var n = !0;
        try {
            n = Ext.getClassByName(e.data.checkFn).call(this, e, t, o)
        } catch (e) {
            return SYNO.Debug(e), !1
        }
        return n
    },
    onInsertExternMenuItem: function(e, t) {
        var i, o = e.data.iconCls,
            n = e.data.icon,
            s = e.data.inMenu,
            r = e.data.menuPriority || 0;
        if (Ext.isString(e.data.launchFn)) {
            var a = Ext.getClassByName(e.data.launchFn);
            i = a.createDelegate(this, [t, this])
        } else i = this.onClickExternMenu.createDelegate(this, [e, t]);
        Ext.isString(o) ? n = null : Ext.isString(n) && !o && (o = "legacy-webfm-icon", n = e.baseURL + "/" + n);
        var l = {
            ignoreParentClicks: !0,
            iconCls: o,
            icon: n,
            text: this.localizeMsg(e.data.text, e.className),
            isExtern: !0,
            menuPriority: r
        };
        if (Ext.isArray(e.data.items)) {
            var h, c, d = !1,
                u = [];
            if (Ext.each(e.data.items, function(s) {
                    if (h = void 0, Ext.isString(s.checkFn)) {
                        if (c = Ext.getClassByName(s.checkFn), !c.call(this, e, t, s.data)) return;
                        d = !0
                    }
                    if (Ext.isString(s.launchFn)) {
                        var r = Ext.getClassByName(s.launchFn);
                        h = r.createDelegate(this, [t, s.data])
                    }
                    u.push({
                        icon: s.icon || n,
                        iconCls: s.iconCls || o,
                        text: this.localizeMsg(s.text, e.className),
                        handler: h || i,
                        useBuffer: !1
                    })
                }, this), !d) return !1;
            Ext.apply(l, {
                menu: new SYNO.ux.Menu({
                    useBuffer: !1,
                    cls: "syno-webfm",
                    items: u
                })
            })
        } else Ext.apply(l, {
            handler: i,
            useBuffer: !1
        });
        if (s) {
            var f = this.gridCtxMenu.getComponent(s);
            this.onInsertExternMenuConfig(f.menu, l), f.show(), f = this.toolbarMenu.getComponent(s), this.onInsertExternMenuConfig(f.menu, l), f.show()
        } else this.onInsertExternMenuConfig(this.gridCtxMenu, l), this.onInsertExternMenuConfig(this.toolbarMenu, l);
        return !0
    },
    onInsertExternMenuConfig: function(e, t) {
        var i = 0,
            o = t.menuPriority;
        e.items && e.items.each(function(e, t) {
            var n = e.menuPriority || 0;
            if (o <= n) return !1;
            i = t + 1
        }), e.insert(i, t)
    },
    localizeMsg: function(e, t) {
        var i;
        return e ? (i = e.split(":"), Ext.isArray(t) || (t = [t]), i.length < 2 ? e : (3 === i.length && t.push(i.shift()), t.push("SYNO.SDS.App.FileStation3.Instance"), i[1] = SYNO.SDS.UIString.GetLocalizedString(i[0] + ":" + i[1], t), i.shift(), String.format.apply(String, i))) : ""
    },
    onRemoveExternMenu: function(e) {
        for (var t;
            "gc_extern_last" !== (t = e.get(0)).getItemId();) e.remove(t, !0);
        e.items.each(function(e) {
            e.menuExternable && e.menu.items && (e.menu.items.each(function(t) {
                t.isExtern && e.menu.remove(t, !0)
            }), 0 === e.menu.items.length && e.hide())
        })
    },
    onUpdateExternMenu: function(e, t) {
        this.onRemoveExternMenu(this.gridCtxMenu), this.onRemoveExternMenu(this.toolbarMenu), e && this.onInsertExternMenu(e, t)
    },
    onClickExternMenu: function(e, t) {
        SYNO.SDS.AppLaunch(e.className, {
            fb_recs: t,
            fb_param: e.data.param || {}
        })
    },
    onExternDbClick: function(e) {
        var t = !1,
            i = SYNO.webfm.VFS.isVFSPath(e.get("path"));
        return Ext.each(this.externPlugins, function(o) {
            var n;
            try {
                if (!e.get("isdir") && !0 !== o.data.dbclick || e.get("isdir") && !0 !== o.data.dirdbclick) return;
                if (!this.onCheckPlugin(o, [e], i, !0)) return;
                if (Ext.isString(o.data.launchFn)) {
                    n = Ext.getClassByName(o.data.launchFn).createDelegate(this, [
                        [e], this
                    ])
                } else "app" !== o.apptype && "standalone" !== o.apptype || (n = this.onClickExternMenu.createDelegate(this, [o, [e]]));
                return n && n(), t = !0, !1
            } catch (e) {
                SYNO.Debug("Fail to click " + e)
            }
        }, this), t
    },
    showJavaMsg: function(e) {
        if (!Ext.isGecko && !Ext.isChrome) {
            var t, i = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablejava") || !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablejava") && "yes" === _S("gpo_enable_java"),
                o = !0 === this.appInstance.getUserSettings("blShowNorMsg"),
                n = "";
            if (e && !Ext.isEmpty(Ext.util.Cookies.get("not_show_java_version"))) {
                var s = deployJava.getJREs();
                Ext.isEmpty(s) || (n = s[0], Ext.util.Cookies.get("not_show_java_version") === n && (e = !1))
            }
            if (e || !(Ext.isOpera || Ext.isSafari && Ext.isWindows || o) && !this.blJava && i) {
                var r = Ext.id(),
                    a = Ext.id();
                t = _WFT("java", "java_installation").replace("{@}", '<a href="' + deployJava.getJavaURL + '" target="_blank">Java</a>'), t += "<br><a id = '" + a + '\' class="pathlink"">', t += "<br><span>", t += _WFT("java", "java_help"), t += "</span></a><br>", t += "<input type='checkbox' id='" + r + "' autocomplete='off' class=' x-form-checkbox x-form-field'>", t += "<label class='x-form-cb-label' style='top: -2px;'>" + _WFT("java", "java_not_remind") + "</label>";
                var l = SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", _T("tree", "leaf_filebrowser"), t, 0, !1),
                    h = Ext.get(a),
                    c = function() {
                        this.owner.onClickHelp()
                    };
                h.on("click", c, this);
                var d = Ext.get(r),
                    u = function() {
                        e ? Ext.util.Cookies.set("not_show_java_version", d.dom.checked ? n : "") : this.appInstance.setUserSettings("blShowNorMsg", d.dom.checked)
                    };
                d.on("click", u, this), l.mon(l, "destory", function() {
                    h.un("click", c, this), d.un("click", u, this)
                }, this)
            }
        }
    },
    onGoToFolder: function(e) {
        this.dirTree.getSelectionModel().getSelectedNode() ? this.onGoToPathWithDir(e) : this.mon(this.remoteDS, "load", function() {
            this.onGoToPathWithDir(e)
        }, this, {
            single: !0
        })
    },
    onGoToFile: function(e) {
        this.dirTree.getSelectionModel().getSelectedNode() ? this.onGoToPathWithFile(e) : this.mon(this.remoteDS, "load", function() {
            this.onGoToPathWithFile(e)
        }, this, {
            single: !0
        })
    },
    onCreateShareFolder: function() {
        SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
            fn: "SYNO.SDS.AdminCenter.Share.Main",
            dlg: "create"
        })
    },
    updateCutIcon: function(e, t) {
        var i = SYNO.FileStation.Clipboard.get();
        if (i && "move" === i.action) {
            var o, n = i.params.source,
                s = this.grid.getStore(),
                r = i.recs,
                a = this.dirTree;
            Ext.each(r, function(e) {
                if ((o = s.indexOfId(e.get("file_id"))) >= 0) {
                    this.grid.getView().addRowClass(o, "syno-sds-fs-file-cut"), Ext.iterate(this.dataView, function(e, t) {
                        var i = this.dataView[e].getNode(o);
                        i && Ext.fly(i).addClass("syno-sds-fs-file-cut")
                    }, this);
                    var t = function t() {
                        o = s.indexOfId(e.get("file_id")), o >= 0 && (this.grid.getView().removeRowClass(o, "syno-sds-fs-file-cut"), Ext.iterate(this.dataView, function(e, t) {
                            var i = this.dataView[e].getNode(o);
                            i && Ext.fly(i).removeClass("syno-sds-fs-file-cut")
                        }, this)), this.mun(SYNO.FileStation.Clipboard, "beforeset", t, this), this.mun(SYNO.FileStation.Clipboard, "clean", t, this)
                    };
                    this.mon(SYNO.FileStation.Clipboard, "beforeset", t, this, {
                        single: !0
                    }), this.mon(SYNO.FileStation.Clipboard, "clean", t, this, {
                        single: !0
                    })
                }
                if (e.get("isdir")) {
                    var i = a.getNodeById(n + e.get("file_id"));
                    if (i && i.ui) {
                        i.ui.addClass("syno-sds-fs-file-cut");
                        var r = function t() {
                            i = a.getNodeById(n + e.get("file_id")), i && i.ui && i.ui.removeClass("syno-sds-fs-file-cut"), this.mun(SYNO.FileStation.Clipboard, "beforeset", t, this), this.mun(SYNO.FileStation.Clipboard, "clean", t, this)
                        };
                        this.mon(SYNO.FileStation.Clipboard, "beforeset", r, this, {
                            single: !0
                        }), this.mon(SYNO.FileStation.Clipboard, "clean", r, this, {
                            single: !0
                        })
                    }
                }
            }, this)
        }
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.CopyMoveCtxMenu = Ext.extend(SYNO.ux.Menu, {
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = new Ext.menu.Item({
            activeClass: "",
            style: "cursor:default;",
            itemId: "text",
            text: "",
            htmlEncode: !1
        });
        SYNO.FileStation.CopyMoveCtxMenu.superclass.constructor.call(this, Ext.apply(e, {
            cls: "syno-webfm",
            items: [t, {
                itemId: "copy_overwrite",
                iconCls: "webfm-copy-icon",
                text: _WFT("filetable", "filetable_copy") + " - " + _WFT("filetable", "filetable_overwrite"),
                handler: this.onMVCPItemClick,
                scope: this
            }, {
                itemId: "copy_skip",
                iconCls: "webfm-copy-icon",
                text: _WFT("filetable", "filetable_copy") + " - " + _WFT("filetable", "filetable_skip"),
                handler: this.onMVCPItemClick,
                scope: this
            }, {
                itemId: "move_overwrite",
                iconCls: "webfm-copy_to_move_to-icon",
                text: _WFT("filetable", "filetable_move") + " - " + _WFT("filetable", "filetable_overwrite"),
                handler: this.onMVCPItemClick,
                scope: this
            }, {
                itemId: "move_skip",
                iconCls: "webfm-copy_to_move_to-icon",
                text: _WFT("filetable", "filetable_move") + " - " + _WFT("filetable", "filetable_skip"),
                handler: this.onMVCPItemClick,
                scope: this
            }, "-", {
                itemId: "cancel",
                iconCls: "webfm-cancel-icon",
                text: _WFT("common", "cancel"),
                handler: this.hide,
                scope: this
            }]
        }))
    },
    onMVCPItemClick: function(e, t) {
        var i = "copy",
            o = !1,
            n = e.itemId,
            s = this.webfm;
        switch (n) {
            case "copy_overwrite":
            case "copy_skip":
                i = "copy", "copy_overwrite" == n && (o = !0);
                break;
            case "move_overwrite":
            case "move_skip":
                i = "move", "move_overwrite" == n && (o = !0);
                break;
            default:
                return
        }
        if ("upload" === this.action) {
            if (_S("demo_mode")) return void s.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
            s.FileAction.directlyUpload(s.ddParams.target, s.ddParams.src, o)
        } else if ("download" === this.action) {
            var r = [],
                a = [],
                l = s.ddParams.src;
            if (Ext.isArray(l)) r = s.ddParams.src;
            else {
                var h = s.ddParams.srcnode.attributes,
                    c = h.type,
                    d = SYNO.webfm.utils.isLocalSource(c),
                    u = d && Ext.isWindows ? "\\" : "/",
                    f = h.path || "",
                    m = h.real_path,
                    p = SYNO.webfm.utils.getBaseName(f, u);
                r[0] = new Ext.data.Record({
                    isdir: !0,
                    file_id: f,
                    path: f,
                    real_path: m,
                    filename: p,
                    size: 0
                })
            }
            r.forEach(function(e) {
                a.push(e.data)
            }), s.FileAction.onJavaDownload(i, s.ddParams.target, a, o)
        } else {
            var g;
            if (_S("demo_mode")) return g = "copy" == i ? _WFT("filetable", "filetable_copy") : _WFT("filetable", "filetable_move"), void s.owner.getMsgBox().alert(g, _JSLIBSTR("uicommon", "error_demo"));
            s.FileAction.onDDMVCP(s.ddParams.src, i, o, s.ddParams.target, s.ddParams)
        }
    }
}), SYNO.FileStation.TreeCtxMenu = Ext.extend(SYNO.ux.Menu, {
    ignoreParentClicks: !0,
    itemId: "rTreeCtx",
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = new Ext.menu.Item({
            activeClass: "",
            style: "cursor:default;",
            itemId: "text",
            canActivate: !1,
            htmlEncode: !1,
            text: ""
        });
        SYNO.FileStation.TreeCtxMenu.superclass.constructor.call(this, Ext.apply(e, {
            cls: "syno-webfm",
            items: [t, {
                itemId: "gc_cleanfav",
                iconCls: "webfm-clear-icon",
                text: _WFT("favorite", "clean_favorite"),
                hidden: !0,
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_renamefav",
                iconCls: "webfm-rename-icon",
                text: _WFT("favorite", "rename_favorite"),
                hidden: !0,
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_delfav",
                iconCls: "webfm-remove_from_favorites-icon",
                text: _WFT("favorite", "del_favorite"),
                hidden: !0,
                handler: this.onTreeCTClick,
                scope: this
            }, new Ext.menu.Separator({
                itemId: "gc_sep_createfolder"
            }), {
                itemId: "gc_createfolder",
                iconCls: "webfm-create_new_folder-icon",
                text: _WFT("filetable", "filetable_create_folder"),
                handler: this.onTreeCTClick,
                hidden: _S("demo_mode"),
                scope: this
            }, new Ext.menu.Separator, {
                itemId: "gc_umount",
                iconCls: "webfm-unmount_eject-icon",
                text: _WFT("mount", "umount"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this,
                hidden: !0
            }, {
                itemId: "gc_eject",
                iconCls: "webfm-unmount_eject-icon",
                text: _T("usb", "usb_eject"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this,
                hidden: !0
            }, {
                itemId: "gc_disconnect_vfs",
                iconCls: "webfm-unmount_eject-icon",
                text: _WFT("vfs", "disconnect"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this,
                hidden: !0
            }, {
                itemId: "gc_remove_vfs",
                iconCls: "webfm-delete-icon",
                text: _WFT("vfs", "remove_profile"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this,
                hidden: !0
            }, new Ext.menu.Separator({
                itemId: "gc_sep_upload"
            }), this.webfm.btnTreeUpSubMenuAction, this.webfm.btnTreeUpBrowserAction, {
                itemId: "gc_local_upload",
                iconCls: "webfm-upload-icon",
                text: _WFT("filetable", "filetable_upload"),
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_download",
                iconCls: "webfm-download-icon",
                text: _WFT("filetable", "filetable_download"),
                handler: this.onTreeCTClick,
                scope: this
            }, this.webfm.btnTreeDownSubMenuAction, new Ext.menu.Separator({
                itemId: "gc_sep_cutcopy"
            }), this.webfm.btnTreeMVCPToSubMenuAction, {
                itemId: "gc_cut",
                iconCls: "webfm-cut-icon",
                text: _WFT("filetable", "filetable_cut"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this
            }, {
                itemId: "gc_copy",
                iconCls: "webfm-copy-icon",
                text: _WFT("filetable", "filetable_copy"),
                handler: this.onTreeCTClick,
                disableClearLastDom: !0,
                scope: this
            }, {
                itemId: "gc_paste_ovwr",
                iconCls: "webfm-paste-icon",
                text: _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_overwrite"),
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_paste_skip",
                iconCls: "webfm-paste-icon",
                text: _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_skip"),
                handler: this.onTreeCTClick,
                scope: this
            }, new Ext.menu.Separator({
                itemId: "gc_sep_del"
            }), {
                itemId: "gc_delete",
                iconCls: "webfm-delete-icon",
                text: _WFT("filetable", "filetable_delete"),
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_rename",
                iconCls: "webfm-rename-icon",
                text: _WFT("filetable", "filetable_rename"),
                handler: this.onTreeCTClick,
                scope: this
            }, new Ext.menu.Separator({
                itemId: "gc_sep_property"
            }), {
                itemId: "gc_snapshot_history",
                iconCls: "webfm-browse_previous_versions-icon",
                text: _T("disk_info", "disk_view_history"),
                handler: this.onTreeCTClick,
                scope: this
            }, {
                itemId: "gc_property",
                iconCls: "webfm-properties-icon",
                text: _WFT("filetable", "filetable_properties"),
                handler: this.onTreeCTClick,
                scope: this
            }]
        })), "yes" !== _D("supportmount") && this.remove("gc_umount")
    },
    onTreeCTClick: function(e, t) {
        var i = this.webfm,
            o = e.itemId,
            n = [];
        if (i.currCTNodeTmp) {
            i.currCTNode = i.currCTNodeTmp, i.currCTAction = o;
            var s = i.currCTNode.attributes,
                r = i.currCTNode.attributes.type,
                a = SYNO.webfm.utils.isLocalSource(r),
                l = a && Ext.isWindows ? "\\" : "/",
                h = i.currCTNode.attributes.path || "",
                c = i.currCTNode.attributes.real_path,
                d = i.currCTNode.attributes.text,
                u = SYNO.webfm.utils.getBaseName(h, l),
                f = i.currCTNode.attributes.uid,
                m = i.currCTNode.attributes.gid,
                p = i.currCTNode.attributes.right,
                g = i.currCTNode.attributes.ftpright,
                b = h.substr(0, h.lastIndexOf(l)),
                S = i.currCTNode.attributes.isMountPoint,
                _ = i.currCTNode.attributes.mountType;
            switch (o) {
                case "gc_createfolder":
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c
                        }), !a && !i.onCheckVFSAction("create", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "not_support"));
                    if (!a && !i.onCheckPrivilege("create", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.Create(h, r);
                    break;
                case "gc_disconnect_vfs":
                    if (!SYNO.webfm.VFS.isRootFolder(h)) return;
                    i.FileAction.DisconnectProtocol(s.path);
                    break;
                case "gc_remove_vfs":
                    if (!SYNO.webfm.VFS.isRootFolder(h)) return;
                    i.FileAction.RemoveProtocol(s.path);
                    break;
                case "gc_umount":
                    if (!0 === _S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("mount", "umount"), _JSLIBSTR("uicommon", "error_demo"));
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c,
                            isMountPoint: S,
                            mountType: _
                        }), !i.onCheckVFSAction("umount", n)) return void i.owner.getMsgBox().alert(_WFT("mount", "umount"), _WFT("error", "not_support"));
                    if (!i.onCheckPrivilege("umount", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("mount", "umount"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.Umount(n, [b]);
                    break;
                case "gc_eject":
                    n[0] = new Ext.data.Record({
                        uid: f,
                        gid: m,
                        isdir: !0,
                        type: "",
                        filename: u,
                        file_id: h,
                        path: h,
                        real_path: c
                    }), i.FileAction.Eject(n);
                    break;
                case "gc_snapshot_history":
                    n[0] = new Ext.data.Record({
                        path: h
                    }), i.FileAction.ViewSnapshotHistory(n[0], this.webfm.owner);
                    break;
                case "gc_download":
                    var w = [],
                        x = u + ".zip";
                    if (w[0] = u, n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p
                        }), !i.onCheckVFSAction("download", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "not_support"));
                    if (!i.onCheckPrivilege("download", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.Download([h], x);
                    break;
                case "gc_copy":
                    if (!0 === _S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_copy"), _JSLIBSTR("uicommon", "error_demo"));
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c,
                            size: 0
                        }), !a && !i.onCheckVFSAction("copy", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_copy"), _WFT("error", "not_support"));
                    if (!a && !i.onCheckPrivilege("copy", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_copy"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.MVCP(n, "copy", i.userId, i.userGroup, r);
                    break;
                case "gc_cut":
                    if (!0 === _S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_cut"), _JSLIBSTR("uicommon", "error_demo"));
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c,
                            size: 0
                        }), !a && !i.onCheckVFSAction("move", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_cut"), _WFT("error", "not_support"));
                    if (!a && !i.onCheckPrivilege("move", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_cut"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.MVCP(n, "move", i.userId, i.userGroup, r);
                    break;
                case "gc_paste_ovwr":
                case "gc_paste_skip":
                    if (_S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_paste"), _JSLIBSTR("uicommon", "error_demo"));
                    n[0] = new Ext.data.Record({
                        uid: f,
                        gid: m,
                        isdir: !0,
                        type: "",
                        filename: u,
                        right: p,
                        ftpright: g,
                        file_id: h,
                        path: h,
                        real_path: c
                    }), i.FileAction.Paste(n[0], "gc_paste_ovwr" === o, r);
                    break;
                case "gc_delete":
                    if (!0 === _S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _JSLIBSTR("uicommon", "error_demo"));
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c
                        }), !a && !i.onCheckVFSAction("delete", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _WFT("error", "not_support"));
                    if (!a && !i.onCheckPrivilege("delete", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_delete"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.Delete(n, [b], r);
                    break;
                case "gc_rename":
                    if (n[0] = new Ext.data.Record({
                            uid: f,
                            gid: m,
                            isdir: !0,
                            type: "",
                            filename: u,
                            fileprivilege: p,
                            file_id: h,
                            path: h,
                            real_path: c
                        }), !0 === _S("demo_mode")) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _JSLIBSTR("uicommon", "error_demo"));
                    if (!a && !i.onCheckVFSAction("rename", n)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "not_support"));
                    if (!a && !i.onCheckPrivilege("rename", n, !1, !0)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_rename"), _WFT("error", "error_privilege_not_enough"));
                    i.FileAction.Rename(n, b, r);
                    break;
                case "gc_renamefav":
                    i.FileAction.RenameFav(h, d);
                    break;
                case "gc_delfav":
                    i.FileAction.DelFav(h, d);
                    break;
                case "gc_cleanfav":
                    i.FileAction.CleanFav();
                    break;
                case "gc_local_upload":
                    n[0] = new Ext.data.Record({
                        uid: f,
                        gid: m,
                        isdir: !0,
                        type: "",
                        filename: u,
                        fileprivilege: p,
                        file_id: h,
                        path: h,
                        real_path: c
                    }), i.FileAction.localUpload(n, i.userId, i.userGroup);
                    break;
                case "gc_property":
                    n[0] = new Ext.data.Record({
                        uid: f,
                        gid: m,
                        owner: i.currCTNode.attributes.owner,
                        group: i.currCTNode.attributes.group,
                        privilege: i.currCTNode.attributes.privilege,
                        mt: i.currCTNode.attributes.mt,
                        fileprivilege: p,
                        isdir: !0,
                        type: "",
                        filename: u,
                        isshare: SYNO.webfm.utils.isShareByPath(h),
                        file_id: h,
                        path: h,
                        real_path: c,
                        filesize: 0,
                        is_sync_share: s.is_sync_share,
                        name: s.name,
                        readonly: s.readonly,
                        is_disable_list: s.is_disable_list,
                        is_disable_modify: s.is_disable_modify,
                        is_disable_download: s.is_disable_download,
                        is_snapshot: s.is_snapshot,
                        is_btrfs_subvol: s.is_btrfs_subvol,
                        has_snapshot: s.has_snapshot
                    }), i.FileAction.Property(n, i.userId, r)
            }
        }
    }
}), SYNO.FileStation.GridCtxMenu = Ext.extend(SYNO.ux.Menu, {
    ignoreParentClicks: !0,
    itemId: "rGridCtx",
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = this.webfm,
            i = SYNO.FileStation.Comp;
        SYNO.FileStation.GridCtxMenu.superclass.constructor.call(this, Ext.apply(e, {
            cls: "syno-webfm",
            items: [{
                itemId: "gc_extern_last",
                hidden: !0
            }, {
                itemId: "gc_open",
                iconCls: "webfm-open_containing_folder-icon",
                text: _WFT("filetable", "open_folder"),
                hidden: !0,
                useBuffer: !1,
                handler: t.onOpenContainingFolder,
                scope: t
            }, {
                itemId: "gc_view",
                iconCls: "webfm-view-icon",
                text: _WFT("acl_editor", "view"),
                menuExternable: !0,
                hidden: !0,
                useBuffer: !1,
                menu: new SYNO.ux.Menu({
                    cls: "syno-webfm",
                    ignoreParentClicks: !0
                })
            }, t.btnUpSubMenuAction, t.btnUpBrowserAction, {
                itemId: "gc_download",
                iconCls: "webfm-download-icon",
                text: _WFT("filetable", "filetable_download"),
                handler: t.onDownloadAction,
                useBuffer: !1,
                scope: t
            }, i.cDownloadMenu(Ext.menu.Item, !0, t), i.cMultiDownloadMenu(Ext.menu.Item, !0, t), new Ext.menu.Separator({
                itemId: "gc_sep_download"
            }), {
                itemId: "gc_openwin",
                iconCls: "webfm-open_in_new_window-icon",
                text: _WFT("filetable", "filetable_openwin"),
                handler: t.onOpenWinAction,
                useBuffer: !1,
                scope: t
            }, new Ext.menu.Separator({
                itemId: "gc_sep_createfolder"
            }), {
                itemId: "gc_createfolder",
                iconCls: "webfm-create_new_folder-icon",
                text: _WFT("filetable", "filetable_create_folder"),
                handler: t.onCreateFolder,
                hidden: _S("demo_mode"),
                scope: t
            }, i.cSort(Ext.menu.Item, t, {
                iconCls: "webfm-sort-icon",
                itemId: "gc_sort",
                type_group: "gc_sort_type",
                dir_group: "gc_sort_dir"
            }), "-", {
                itemId: "gc_mount_iso",
                iconCls: "webfm-mount_virtual_drive-icon",
                text: _WFT("filetable", "filetable_mount_iso"),
                handler: t.onMountISOClick,
                useBuffer: !1,
                scope: t
            }, {
                itemId: "gc_umount",
                iconCls: "webfm-unmount_eject-icon",
                text: _WFT("mount", "umount"),
                handler: t.onUmountClick,
                useBuffer: !1,
                scope: t,
                hidden: !0
            }, i.cExtractMenuBtn(Ext.menu.Item, !0, t), {
                itemId: "gc_compress_adv",
                iconCls: "webfm-compress-icon",
                text: _WFT("filetable", "filetable_add_archive"),
                handler: t.onCompressAdvItemsClick,
                useBuffer: !1,
                scope: t
            }, {
                itemId: "gc_compress",
                iconCls: "webfm-compress-icon",
                text: _WFT("filetable", "filetable_compress_to"),
                handler: t.onCompressItemsClick,
                useBuffer: !1,
                scope: t
            }, new Ext.menu.Separator({
                itemId: "gc_sep_archive"
            }), i.cMVCPToMenu(Ext.menu.Item, !0, t), {
                itemId: "gc_cut",
                iconCls: "webfm-cut-icon",
                text: _WFT("filetable", "filetable_cut"),
                disableClearLastDom: !0,
                handler: t.onCutAction,
                scope: t
            }, {
                itemId: "gc_copy",
                iconCls: "webfm-copy-icon",
                text: _WFT("filetable", "filetable_copy"),
                handler: t.onCopyAction,
                disableClearLastDom: !0,
                scope: t
            }, {
                itemId: "gc_paste_ovwr",
                iconCls: "webfm-paste-icon",
                text: _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_overwrite"),
                handler: function(e) {
                    this.onPasteAction(e, !0)
                },
                scope: t
            }, {
                itemId: "gc_paste_skip",
                iconCls: "webfm-paste-icon",
                text: _WFT("filetable", "filetable_paste") + " - " + _WFT("filetable", "filetable_skip"),
                handler: function(e) {
                    this.onPasteAction(e, !1)
                },
                scope: t
            }, {
                itemId: "gc_delete",
                iconCls: "webfm-delete-icon",
                text: _WFT("filetable", "filetable_delete"),
                handler: t.onDeleteAction,
                scope: t
            }, {
                itemId: "gc_rename",
                iconCls: "webfm-rename-icon",
                text: _WFT("filetable", "filetable_rename"),
                handler: t.onRenameAction,
                scope: t
            }, "-", i.cAddFavMenuBtn(Ext.menu.Item, !0, t), i.cDSMDeskShortcutBtn(Ext.menu.Item, !0, t, _WFT("shortcut", "make_to_dsm_dekstop")), new Ext.menu.Separator({
                itemId: "gc_sep_fav"
            }), i.cSnapshotHistory(Ext.menu.Item, t), {
                itemId: "gc_property",
                iconCls: "webfm-properties-icon",
                text: _WFT("filetable", "filetable_properties"),
                useBuffer: !0,
                handler: t.onPropertyClick,
                scope: t
            }, {
                itemId: "gc_share",
                iconCls: "webfm-share_file_links-icon",
                text: _WFT("common", "share"),
                useBuffer: !0,
                handler: t.onShareClick,
                scope: t
            }, {
                itemId: "gc_filerequest",
                iconCls: "webfm-filerequest_upload-icon",
                text: _WFT("sharing", "file_request"),
                useBuffer: !0,
                handler: t.onFileRequestClick,
                scope: t
            }]
        })), "yes" !== _D("supportmount") && (this.remove("gc_mount_iso"), this.remove("gc_umount"))
    },
    showAt: function(e, t) {
        SYNO.webfm.utils.ShowHideMenu(this.items), SYNO.FileStation.GridCtxMenu.superclass.showAt.call(this, e, t)
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.BasicTreePanel = Ext.extend(SYNO.ux.TreePanel, {
    cls: "syno-sds-fs-tree",
    initEvents: function() {
        var e = this;
        this.dropZone = new SYNO.webfm.utils.TreeDropZone(this, this.dropConfig || {
            ddGroup: this.ddGroup || "SDSShortCut",
            appendOnly: !0 === this.ddAppendOnly
        }), this.dragZone = new Ext.tree.TreeDragZone(this, this.dragConfig || {
            ddGroup: this.ddGroup || "SDSShortCut",
            scroll: this.ddScroll,
            onBeforeDrag: function(t, i) {
                var o = e.webfm,
                    n = o.getRecByTreeNodeAttr(t.node.attributes);
                return SYNO.webfm.SmartDDMVCPMgr.initDragData(o, n), Ext.tree.TreeDragZone.prototype.onBeforeDrag.apply(this, arguments)
            },
            onDragOver: function(e, t) {
                delete this.cachedTarget, Ext.tree.TreeDragZone.prototype.onDragOver.apply(this, arguments)
            },
            validateTarget: function(e, t, i) {
                var o = t.getTarget("li.launch-icon");
                if (SYNO.SDS.Desktop.getEl().id === t.getTarget().id || o && Ext.fly(o).findParentNode(".sds-desktop-shortcut")) {
                    var n = this.dragData;
                    return !n || !n.node || !SYNO.webfm.utils.isLocalSource(n.node.attributes.type) && !SYNO.webfm.VFS.isVFSPath(n.node.attributes.path)
                }
                o = t.getTarget();
                var s, r;
                return o && (Ext.fly(o).is("div.syno-sds-fs-grid-scroller") || (r = Ext.fly(o).findParentNode("div.syno-sds-fs-grid-scroller")) || (r = Ext.fly(o).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))) ? (r = r || o, r = Ext.fly(r).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE), s = SYNO.SDS.WindowMgr.get(r.id), s && s.toFront(), !0) : (r = r || o, r && (r = Ext.fly(r).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE)) && (s = SYNO.SDS.WindowMgr.get(r.id)) && s.toFront(), !1)
            }
        }), SYNO.FileStation.BasicTreePanel.superclass.initEvents.apply(this, arguments)
    },
    constructor: function(e) {
        SYNO.FileStation.BasicTreePanel.superclass.constructor.call(this, Ext.apply(e, {
            useArrows: !0,
            animate: !1,
            border: !1,
            enableDD: !0
        })), Ext.isIE && !Ext.isModernIE && this.mon(this, "beforeappend", function(e, t, i) {
            return delete i.attributes.qtip, !0
        })
    },
    onNodeClick: function(e, t) {
        if (t) {
            var i = !1;
            this.webfm.getCurrentSource() !== t.attributes.type && (this.webfm.switchSource(t.attributes.type), i = !0), t.id && ((i || t.attributes.path != this.webfm.getCurrentDir()) && this.webfm.onChangeDir(t.attributes.path), this.webfm.fireEvent("onNodeClick", t))
        }
    },
    nodeDragOver: function(e) {
        var t = e.source,
            i = t.getProxy().getGhost(),
            o = this.webfm,
            n = e.target,
            s = e.data.node,
            r = e.data.grid || e.data.from,
            a = s ? s.attributes.type : r ? r.getStore().storetype : null;
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable() && (SYNO.webfm.SmartDDMVCPMgr.focus(o, e.data), SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(!0), SYNO.webfm.SmartDDMVCPMgr.onDragOver(e.rawEvent)), !n || !a) return !1;
        var l;
        if ("above" === e.point || "below" === e.point || "append" === e.point && "fm_fav_root" === n.id) {
            if ("fm_fav_root" === n.id || n.parentNode && "fm_fav_root" === n.parentNode.id) {
                if (s && SYNO.webfm.VFS.isVFSPath(s.attributes.path)) return !1;
                if (SYNO.webfm.utils.isLocalSource(a)) return !1;
                if (r) {
                    if (l = r.getSelectionModel().getSelections(), Ext.isEmpty(l) || 1 < l.length || !l[0].get("isdir")) return i.update(_WFT("favorite", "insert_invalid_favorite")), !1;
                    if (SYNO.webfm.VFS.isVFSPath(l[0].get("path"))) return !1
                } else if (s && ("broken" === s.attributes.status || "fm_fav_root" === s.parentNode.id && o !== s.ownerTree.webfm)) return !1;
                return i.update(SYNO.webfm.utils.isFavSource(a) ? _WFT("favorite", "insert_favorite") : _WFT("favorite", "add_favorite")), ("fm_fav_root" !== n.id || !SYNO.webfm.utils.isFavSource(a)) && ("fm_fav_root" === n.id || "fm_fav_root" === n.parentNode.id)
            }
            return !1
        }
        if (s && ("fm_fav_root" === s.parentNode.id || "broken" === s.attributes.status) || n && "broken" === n.attributes.status) return i.update(_WFT("favorite", "insert_invalid_favorite")), !1;
        if (n) {
            var h = n.attributes.type;
            if (!h) return !1;
            if (h === SYNO.webfm.utils.source.remotev) return i.update(_WFT("error", "error_fs_ro")), !1
        }
        var c, d, u = e.target ? Ext.util.Format.ellipsis(e.target.text, 36) : "",
            f = !!n && SYNO.webfm.utils.isLocalSource(n.attributes.type),
            m = SYNO.webfm.utils.isLocalSource(a),
            p = !0,
            g = !!n.attributes.is_snapshot,
            b = !1,
            S = !1,
            _ = n.attributes.path;
        if (_ && SYNO.webfm.VFS.isVFSPath(_) && (b = !0), r ? (l = r.getSelectionModel().getSelections(), Ext.each(l, function(e) {
                if ((_ = e.get("path")) && SYNO.webfm.VFS.isVFSPath(_)) return S = !0, !1
            })) : s && (_ = s.attributes.path) && SYNO.webfm.VFS.isVFSPath(_) && (S = !0), !f && m) {
            if (!o.onCheckVFSAction("upload", n) || g) return !1;
            c = String.format(_WFT("filetable", "upload_ddtext"), Ext.util.Format.htmlEncode(u)), d = "upload"
        } else if (f && !m) {
            if (r ? (l = r.getSelectionModel().getSelections(), Ext.each(l, function(e) {
                    return p = !o.checkFTPDownloadRightByPath(e.get("file_id"))
                })) : s && o.checkFTPDownloadRight(s) && (p = !1), !o.onCheckVFSAction("download", l || s)) return !1;
            c = p ? String.format(_WFT("download", "download_to"), Ext.util.Format.htmlEncode(u)) : _WFT("error", "error_privilege_not_enough"), d = "download"
        } else {
            if (!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !o.onCheckVFSAction("copy", l || s, n) && !o.onCheckVFSAction("move", s || l, n) || SYNO.webfm.SmartDDMVCPMgr.isEnable() && !o.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), s || l, n) || g) return !1;
            c = String.format(_WFT("filetable", "mvcp_ddtext"), Ext.util.Format.htmlEncode(u)), d = "mvcp"
        }
        var w = !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd"),
            x = !o.onCheckVFSAction("move", s || l, n);
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable() || w) {
            var v = b ? SYNO.webfm.utils.source.remotevfs : SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, n.attributes.path, n.attributes.type);
            SYNO.webfm.SmartDDMVCPMgr.setDragDropData(u, d, t.getProxy()), SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(x), SYNO.webfm.SmartDDMVCPMgr.updateDefaultAction(v, S, b), w || (c = String.format(SYNO.webfm.SmartDDMVCPMgr.getDDText(x), Ext.util.Format.htmlEncode(u)))
        }
        return i.update(c), p
    },
    getTargetAndSource: function(e) {
        var t;
        if (e.data.node) {
            if (e.target == e.data.node.parentNode) return null;
            t = {
                src: e.data.node.attributes.path,
                target: e.target.attributes.path,
                srcsource: e.data.node.attributes.type,
                srcnode: e.data.node
            }
        } else if (e.data.selections) {
            var i = e.data.grid || e.data.from;
            t = {
                src: e.data.selections,
                target: e.target.attributes.path,
                srcsource: i && i.getStore() ? i.getStore().storetype : ""
            }, i && i.getStore().storetype === SYNO.webfm.utils.source.remotes && Ext.apply(t, {
                search_taskid: i.getStore().search_taskid
            })
        } else t = null;
        return t
    },
    beforeNodeDrop: function(e) {
        e.cancel = !0;
        var t = this.webfm,
            i = e.rawEvent.getTarget();
        if (i && (i = Ext.fly(i).findParentNode("div.syno-sds-fs-win")) && i !== t.owner.el.dom) return !1;
        var o = e.target,
            n = e.data.node,
            s = e.data.grid || e.data.from;
        if (!n || !1 !== n.attributes.draggable) {
            var r, a = n ? n.attributes.type : s ? s.getStore().storetype : null,
                l = !!o && SYNO.webfm.utils.isLocalSource(o.attributes.type),
                h = SYNO.webfm.utils.isLocalSource(a),
                c = [],
                d = 0;
            if ("above" === e.point || "below" === e.point || "append" === e.point && "fm_fav_root" === o.id) {
                if ("fm_fav_root" === o.parentNode.id || "fm_fav_root" === o.id) {
                    if (e.cancel = !1, n || s) {
                        var u = e.target;
                        r = u.attributes.path, u.parentNode.childNodes.forEach(function(e) {
                            if (e.attributes.path === r) return !1;
                            d++
                        }), "below" === e.point && d++
                    }
                    return void(n ? "fm_fav_root" !== n.parentNode.id && (r = n.attributes.path, c[0] = new Ext.data.Record({
                        isdir: !0,
                        file_id: r,
                        filename: SYNO.webfm.utils.getBaseName(r)
                    }), t.FileAction.AddFav(c, {
                        index: d
                    })) : s && (c = s.getSelectionModel().getSelections(), t.FileAction.AddFav(c, {
                        index: d
                    })))
                }
            } else {
                var f = _T("tree", "leaf_filebrowser");
                if (null === (t.ddParams = this.getTargetAndSource(e))) return void t.owner.getMsgBox().alert(f, _WFT("error", "error_select_conflict"));
                e.cancel = !1;
                var m = e.target.attributes.real_path,
                    p = l && Ext.isWindows ? "\\" : "/";
                if (l === h)
                    if (e.data.node) {
                        if (SYNO.webfm.utils.isConflictTargetPath(e.data.node.attributes.real_path, m, p)) return void t.owner.getMsgBox().alert(f, _WFT("error", "error_select_conflict"))
                    } else if (e.data.grid || e.data.from)
                    for (var g = 0; g < e.data.selections.length; g++) {
                        var b = e.data.selections[g].get("real_path");
                        if (SYNO.webfm.utils.isConflictTargetPath(b, m, p)) return void t.owner.getMsgBox().alert(f, _WFT("error", "error_select_conflict"))
                    }
                var S = t.copymoveCtxMenu,
                    _ = S.items,
                    w = Ext.util.Format;
                _.each(function(e) {
                    e.enable(), e.show()
                });
                var x, v, y = e.target ? "<b>[" + w.htmlEncode(w.ellipsis(e.target.text, 36)) + "]</b>" : "";
                if (s && (c = s.getSelectionModel().getSelections()), !l && h) {
                    if (e.target) {
                        if (!0 === _S("demo_mode")) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
                        if (!t.checkUploadRight(e.target)) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough"));
                        if (!t.onCheckVFSAction("upload", o)) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support"));
                        v = t.checkFtpModifyRight(e.target), v && _.get("copy_overwrite").disable(), _.get("move_skip").hide(), _.get("move_overwrite").hide(), _.get("text").setText(String.format("<b>" + _WFT("filetable", "upload_ddtext") + "&nbsp</b>", y)), x = "upload"
                    }
                } else if (l && !h) {
                    if (t.checkFTPDownloadRight(e.target)) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
                    if (!t.onCheckVFSAction("download", n || c)) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support"));
                    v = t.checkFtpModifyRight(e.target), (v || this.isSrcReadOnly(e.data)) && (_.get("move_overwrite").disable(), _.get("move_skip").disable()), _.get("text").setText(String.format("<b>" + _WFT("download", "download_to") + "&nbsp</b>", y)), x = "download"
                } else {
                    if (!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !t.onCheckVFSAction("move", n || c, o) && !t.onCheckVFSAction("copy", n || c, o) || SYNO.webfm.SmartDDMVCPMgr.isEnable() && !t.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), n || c, o)) return void t.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support"));
                    this.isSrcReadOnly(e.data) && (_.get("move_overwrite").disable(), _.get("move_skip").disable()), _.get("text").setText(y), x = "copymove"
                }
                S.action = x, SYNO.webfm.SmartDDMVCPMgr.onAction(S, t, e.rawEvent)
            }
        }
    },
    isSrcReadOnly: function(e) {
        var t = e.node && e.node.attributes && (e.node.attributes.is_snapshot || e.node.attributes.type === SYNO.webfm.utils.source.remotev || e.node.attributes.isMountPoint) || e.grid && SYNO.webfm.utils.doesIncludeMountPoint(e.grid.getSelectionModel().getSelections()) || e.grid && e.grid.owner && SYNO.webfm.utils.source.remotev === e.grid.owner.getCurrentSource() || e.datview && SYNO.webfm.utils.doesIncludeMountPoint(e.datview.getSelectionModel().getSelections()) || e.datview && e.datview.owner && SYNO.webfm.utils.source.remotev === e.datview.owner.getCurrentSource();
        return t || (e.grid || e.from) && e.selections.forEach(function(e) {
            var i = e.data.mountType;
            if (e.data.is_snapshot && (t = !0), "iso" === i || "remotefail" === i || "remote" === i) return t = !0, !1
        }, this), t
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.MixedTreeLoader = Ext.extend(SYNO.API.TreeLoader, {
    timeout: SYNO.webfm.Cfg.timeout,
    clearOnLoad: !0,
    processResponse: function(e, t, i, o) {
        var n = e.responseText;
        try {
            var s, r = e.responseData || Ext.decode(n);
            if ("fm_fav_root" === t.id ? s = ["data", "favorites"] : "fm_root" === t.id ? (s = ["data", "shares"], this.parseVolumeName(r.data.shares)) : s = "fm_top_root" === t.parentNode.id ? ["data", "folders"] : ["data", "files"], s) {
                Ext.isArray(s) || (s = s.split(","));
                for (var a in s) s.hasOwnProperty(a) && (r = r[s[a]])
            }
            t.beginUpdate();
            for (var l = 0, h = r.length; l < h; l++) {
                var c = this.createNode(r[l], t);
                if (c) {
                    var d = t.appendChild(c);
                    this.doNodeload(d)
                }
            }
            t.endUpdate(), this.runCallback(i, o || t, [t])
        } catch (t) {
            SYNO.Debug("exception: " + t + ", response: " + e), this.handleFailure(e)
        }
    },
    doNodeload: function(e) {
        if (e.attributes.children) {
            if (e.childNodes.length < 1) {
                var t = e.attributes.children;
                e.beginUpdate();
                for (var i = 0, o = t.length; i < o; i++) {
                    var n = e.appendChild(this.createNode(t[i], e));
                    this.doNodeload(n)
                }
                e.endUpdate()
            }
            return !0
        }
        return !1
    },
    parseVolumeName: function(e) {
        var t, i = 0,
            o = 0;
        for (i = 0; i < e.length; i++)
            if (e[i].additional)
                if (t = e[i].additional.real_path, this.isUSBShareFolder(e[i])) {
                    e[i].additional.volume = e[i].name;
                    var n = t.substr(0, t.indexOf("@sharebin") - 1);
                    for (o = 0; o < e.length; o++) n === e[o].additional.real_path && (e[i].additional.volume = e[o].name)
                } else e[i].additional.volume = t.substr(1, t.indexOf("/", 1) - 1)
    },
    isUSBShareFolder: function(e) {
        return null !== e.additional.real_path.match(/^\/volumeUSB/)
    }
}), SYNO.FileStation.MixedTreeNodeUI = Ext.extend(Ext.tree.TreeNodeUI, {
    recycleBinCls: "recycle",
    constructor: function(e) {
        SYNO.FileStation.MixedTreeNodeUI.superclass.constructor.call(this, e)
    },
    initEvents: function() {
        this.node.on("move", this.onMove, this), this.node.disabled && this.onDisableChange(this.node, !0), this.node.hidden && this.hide();
        var e = this.node.getOwnerTree();
        if ((e.enableDD || e.enableDrag || e.enableDrop) && (!this.node.isRoot || e.rootVisible)) {
            var t = this.node.attributes,
                i = t.path,
                o = SYNO.webfm.utils.getBaseName(i),
                n = !t.isMountPoint && SYNO.webfm.utils.isRecycleBinFolder(t.path),
                s = "/images/1x/files_ext_64/" + (n ? "recycle_bin.png" : "folder.png"),
                r = {
                    isdir: !0,
                    file_id: t.path,
                    opendir: t.path,
                    filename: o
                };
            o = Ext.util.Format.htmlEncode(o), Ext.dd.Registry.register(this.elNode, {
                node: this.node,
                handles: this.getDDHandles(),
                isHandle: !1,
                SDSShortCut: [{
                    config: {
                        className: "SYNO.SDS.App.FileStation3.Instance",
                        title: o,
                        desc: Ext.util.Format.htmlEncode(t.path),
                        icon: s,
                        param: r,
                        removable: !0
                    },
                    pos: -1,
                    skipRegister: !1
                }],
                _fromFile: !0,
                ddText: _T("desktop", "add_shortcut")
            }), n && Ext.fly(this.getIconEl()).addClass(this.recycleBinCls)
        }
    },
    ecClick: function(e) {
        if (!this.animating && this.node.isExpandable()) {
            if (SYNO.webfm.utils.isRootNode(this.node)) return !0;
            var t = SYNO.webfm.utils.transNodeToRecs(this.node),
                i = this.node.ownerTree.webfm;
            SYNO.webfm.Plugin.checkActionByPlugin(i, i.owner, "open", t, {
                fn: function() {
                    this.node.toggle()
                },
                scope: this
            })
        }
    },
    renderElements: function(e, t, i, o) {
        this.indentMarkup = e.parentNode ? e.parentNode.ui.getChildIndent() : "";
        var n, s, r = Ext.isBoolean(t.checked),
            a = this.getHref(t.href),
            l = ['<li class="x-tree-node"><div ext:tree-node-id="', e.id, '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', t.cls, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', '<img alt="" src="', t.icon || this.emptyIcon, '" class="x-tree-node-icon', t.icon ? " x-tree-node-inline-icon" : "", t.iconCls ? " " + t.iconCls : "", '" unselectable="on" />', r ? '<input class="x-tree-node-cb" type="checkbox" ' + (t.checked ? 'checked="checked" />' : "/>") : "", '<a hidefocus="on" class="x-tree-node-anchor" href="', a, '" tabIndex="1" ', t.hrefTarget ? ' target="' + t.hrefTarget + '"' : "", '><span unselectable="on">', e.text, "</span></a>"];
        s = t.isHybridShare ? ['<img alt="" src="', t.hybridShareIcon, '"ext:qtip="', t.qtip, '" class="tree-hybrindshare-status" />', "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"] : ["</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"], l.push.apply(l, s), l = l.join(""), !0 !== o && e.nextSibling && (n = e.nextSibling.ui.getEl()) ? this.wrap = Ext.DomHelper.insertHtml("beforeBegin", n, l) : this.wrap = Ext.DomHelper.insertHtml("beforeEnd", i, l), this.elNode = this.wrap.childNodes[0], this.ctNode = this.wrap.childNodes[1];
        var h = this.elNode.childNodes;
        this.indentNode = h[0], this.ecNode = h[1], this.iconNode = h[2];
        var c = 3;
        r && (this.checkbox = h[3], this.checkbox.defaultChecked = this.checkbox.checked, c++), this.anchor = h[c], this.textNode = h[c].firstChild
    }
}), SYNO.FileStation.MixedTreePanel = Ext.extend(SYNO.FileStation.BasicTreePanel, {
    autoFlexcroll: !1,
    checkNodeIsSelected: function() {
        var e = this.webfm.dirTree.getSelectionModel();
        if (Ext.isEmpty(e.getSelectedNode())) {
            var t = this.webfm.dirTree.getNodeById("fm_root");
            t.childNodes && 0 < t.childNodes.length && e.select(t.childNodes[0])
        }
    },
    initRemoteLoader: function() {
        var e = this.webfm;
        return new SYNO.FileStation.MixedTreeLoader({
            api: "SYNO.FileStation.List",
            method: "list_share",
            version: 2,
            dataroot: ["data", "shares"],
            hybridShares: e.hybridShares,
            baseParams: {
                filetype: "dir",
                sort_by: "name",
                check_dir: !0,
                additional: ["real_path", "owner", "time", "perm", "mount_point_type", "sync_share", "volume_status", "indexed"]
            },
            listeners: {
                scope: this,
                beforeload: function(e, t) {
                    this.webfm.goto_path ? (e.baseParams.goto_path = this.webfm.goto_path, delete this.webfm.goto_path) : delete e.baseParams.goto_path, this.bltreeloaded = !1,
                        function() {
                            this.bltreeloadedmask || this.bltreeloaded || !this.webfm.owner || this.webfm.owner.el.isMasked() || (this.bltreeloadedmask = !0, this.webfm.owner.mask(0, _WFT("common", "loading"), "x-mask-loading"))
                        }.createDelegate(this).defer(1e3), SYNO.webfm.utils.getRemoteTreeParams(e, t)
                },
                load: function(e, t, i) {
                    if (this.bltreeloaded = !0, this.bltreeloadedmask && this.webfm.owner.unmask(), "fm_fav_root" === t.id) {
                        var o = t.ui;
                        if (!o) return;
                        !t.childNodes || 0 >= t.childNodes.length ? (o.hide(), this.checkNodeIsSelected()) : o.show()
                    }
                    this.webfm.updateCutIcon()
                },
                loadexception: function(e, t, i) {
                    if (this.bltreeloaded = !0, this.bltreeloadedmask && this.webfm.owner.unmask(), "fm_fav_root" === t.id) {
                        var o = this.webfm.dirTree.getNodeById("fm_fav_root");
                        o && o.ui && (o.ui.hide(), this.checkNodeIsSelected())
                    }
                }
            },
            createNode: function(t, i) {
                var o, n = !1;
                if (SYNO.webfm.utils.parseRemoteTreeNode(t, i), t.isHybridShare = !1, SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.C2FS.Application") && this.hybridShares.hasOwnProperty(t.name) && 2 === t.path.split("/").length) {
                    var s = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x";
                    t.isHybridShare = !0, t.hybridShareIcon = "../webman/3rdparty/FileBrowser/images/" + s + "/", t.hybridShareIcon += this.getHybridShareIcon(this.hybridShares[t.name])
                }
                if (t.isMountPoint && ("iso" != t.mountType && "remote" != t.mountType && "remotefail" != t.mountType || (n = !0)), t.uiProvider = SYNO.FileStation.MixedTreeNodeUI, !n && !Ext.isEmpty(e.externCodeIcon) && SYNO.webfm.utils.isRemoteSource(t.type)) {
                    var r = e.getRecByTreeNodeAttr(t);
                    (o = e.getExternIcon(r[0])) && (Ext.isEmpty(o.url) || (t.icon = o.url, t.cls = "node_no_background"), t.iconCls = (t.iconCls || "") + " " + o.css)
                }
                return SYNO.FileStation.MixedTreeLoader.prototype.createNode.call(this, t)
            },
            updateHybridShares: function() {
                this.hybridShares = e.hybridShares
            },
            getHybridShareIcon: function(e) {
                return e ? "tree_hybridshare_online.png" : "tree_hybridshare_offline.png"
            }
        })
    },
    initRemoteRoot: function(e) {
        this.webfm.deviceObj = {};
        var t = new Ext.tree.AsyncTreeNode({
            cls: "root_node",
            text: _S("hostname"),
            draggable: !1,
            expanded: !0,
            id: "fm_root",
            allowDrop: !1,
            loader: e,
            listeners: {
                scope: this,
                expand: function(t) {
                    var i = this.webfm.dirTree.getSelectionModel();
                    this.webfm.expandTreeToDir(t, t.childNodes, Ext.isEmpty(i.getSelectedNode())), this.blInitVirtualRoot || (this.setVFSRemoteProtocol(e), "yes" === _D("supportmount") && (this.root.appendChild(this.initVirtualDeviceRoot(e)), this.root.appendChild(this.initRemoteFolderRoot(e))), this.blInitVirtualRoot = !0)
                },
                beforeload: function() {
                    this.searchNode && (this.blHideSearchNode = this.searchNode.hidden), this.initExtDeviceInfo()
                },
                load: function(e) {
                    "fm_root" !== e.id || this.getNodeById("fm_search_root") || t.appendChild(this.createSearchNode(this.blHideSearchNode))
                }
            }
        });
        return t.expand(), this.treeroot = t, t
    },
    initRemoteFolderRoot: function(e) {
        var t = new SYNO.FileStation.MixedTreeLoader({
                api: "SYNO.FileStation.VirtualFolder",
                method: "list",
                version: 2,
                dataroot: ["data", "folders"],
                baseParams: {
                    filetype: "dir",
                    type: ["cifs", "nfs"],
                    sort_by: "name",
                    additional: ["real_path", "owner", "time", "perm", "mount_point_type", "volume_status"]
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        this.webfm.goto_path ? (e.baseParams.goto_path = this.webfm.goto_path, delete this.webfm.goto_path) : delete e.baseParams.goto_path, SYNO.webfm.utils.getRemoteTreeParams(e, t)
                    },
                    load: function(e, t, i) {
                        t.ui && (this.mountInfo.initRemoteFolder || (this.handleMountList(t), this.mountInfo.initRemoteFolder = !0), !t.childNodes || 0 >= t.childNodes.length ? (t.ui.hide(), this.checkNodeIsSelected()) : t.ui.show(), this.updateScrollbar(this.getTreeEl().dom))
                    },
                    loadexception: function(e, t, i) {
                        t && "fm_rf_root" === t.id && t.ui && (t.ui.hide(), this.checkNodeIsSelected())
                    }
                },
                createNode: function(t, i) {
                    return t.loader = e, SYNO.webfm.utils.parseRemoteTreeNode(t, i), SYNO.FileStation.MixedTreeLoader.prototype.createNode.call(this, t)
                }
            }),
            i = new Ext.tree.AsyncTreeNode({
                cls: "root_node",
                text: _WFT("mount", "remote_volume"),
                draggable: !1,
                expanded: !0,
                id: "fm_rf_root",
                allowDrop: !1,
                hidden: !0,
                loader: t
            });
        return i.expand(), i
    },
    initVirtualDeviceRoot: function(e) {
        var t = new SYNO.FileStation.MixedTreeLoader({
                api: "SYNO.FileStation.VirtualFolder",
                method: "list",
                version: 2,
                dataroot: ["data", "folders"],
                baseParams: {
                    type: "iso",
                    sort_by: "name",
                    additional: ["real_path", "owner", "time", "perm", "mount_point_type", "volume_status"]
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        this.webfm.goto_path ? (e.baseParams.goto_path = this.webfm.goto_path, delete this.webfm.goto_path) : delete e.baseParams.goto_path, SYNO.webfm.utils.getRemoteTreeParams(e, t)
                    },
                    load: function(e, t, i) {
                        t.ui && (this.mountInfo.initVirtualDeviceRoot || (this.handleMountList(t), this.mountInfo.initVirtualDeviceRoot = !0), !t.childNodes || 0 >= t.childNodes.length ? (t.ui.hide(), this.checkNodeIsSelected()) : t.ui.show(), this.updateScrollbar(this.getTreeEl().dom))
                    },
                    loadexception: function(e, t, i) {
                        t && "fm_rf_root" === t.id && t.ui && (t.ui.hide(), this.checkNodeIsSelected())
                    }
                },
                createNode: function(t, i) {
                    return t.loader = e, SYNO.webfm.utils.parseRemoteTreeNode(t, i), SYNO.FileStation.MixedTreeLoader.prototype.createNode.call(this, t)
                }
            }),
            i = new Ext.tree.AsyncTreeNode({
                cls: "root_node",
                text: _WFT("mount", "virtual_folder"),
                draggable: !1,
                expanded: !0,
                id: "fm_vd_root",
                allowDrop: !1,
                hidden: !0,
                loader: t
            });
        return i.expand(), i
    },
    initFavoriteNode: function(e) {
        var t = new Ext.tree.AsyncTreeNode({
            type: SYNO.webfm.utils.source.remotefav,
            cls: "root_node",
            text: _WFT("favorite", "my_favorite"),
            draggable: !1,
            expanded: !0,
            id: "fm_fav_root",
            allowDrop: !0,
            hidden: !0,
            loader: e,
            listeners: {
                scope: this.webfm,
                load: function(e) {
                    "fm_fav_root" === e.id && this.updateFavBtn()
                }
            }
        });
        return t.expand(), t
    },
    initExtDeviceInfo: function() {
        _S("is_admin") && !0 !== _S("demo_mode") && this.sendWebAPI({
            api: "SYNO.Entry.Request",
            version: 1,
            method: "request",
            params: {
                compound: [{
                    api: "SYNO.Core.ExternalDevice.Storage.USB",
                    version: 1,
                    method: "list",
                    additional: ["dev_type", "product", "status", "partitions"]
                }, {
                    api: "SYNO.Core.ExternalDevice.Storage.eSATA",
                    version: 1,
                    method: "list",
                    additional: ["dev_type", "status", "partitions"]
                }]
            },
            callback: this.loadData,
            scope: this
        })
    },
    createVFSRoot: function(e, t, i) {
        var o = new SYNO.FileStation.MixedTreeLoader({
                api: "SYNO.FileStation.VirtualFolder",
                method: "list",
                version: 2,
                dataroot: ["data", "folders"],
                baseParams: {
                    type: t,
                    sort_by: "name",
                    additional: ["real_path", "owner", "time", "perm", "mount_point_type"]
                },
                listeners: {
                    scope: this,
                    beforeload: function(e, i) {
                        SYNO.webfm.utils.getRemoteTreeParams(e, i, t)
                    },
                    load: function(e, t, i) {
                        t.ui && (!t.childNodes || 0 >= t.childNodes.length ? (t.ui.hide(), this.checkNodeIsSelected()) : t.ui.show(), this.updateScrollbar(this.getTreeEl().dom))
                    },
                    loadexception: function(e, t, i) {
                        t && t.parentNode && "fm_top_root" === t.parentNode.id && t.ui && (t.ui.hide(), this.checkNodeIsSelected())
                    }
                },
                createNode: function(t, i) {
                    var o = t.path;
                    return -1 === o.indexOf("sharing://") && (t.name = t.name + " (" + o.substring(o.indexOf("://") + 3) + ")"), t.loader = e, SYNO.webfm.utils.parseRemoteTreeNode(t, i), SYNO.FileStation.MixedTreeLoader.prototype.createNode.call(this, t)
                }
            }),
            n = new Ext.tree.AsyncTreeNode({
                cls: "root_node",
                text: i,
                draggable: !1,
                expanded: !0,
                id: t,
                allowDrop: !1,
                hidden: !0,
                loader: o
            });
        return n.expand(), n
    },
    loadData: function(e, t, i, o) {
        var n = t.result,
            s = [],
            r = {
                data: {
                    deviceList: []
                }
            },
            a = r.data.deviceList;
        n.forEach(function(e) {
            e.error && e.error.code ? s.push(SYNO.API.getErrorString(e.error.code)) : a = a.concat(e.data.devices)
        }), 0 !== s.length && this.getMsgBox.alert(_T("common", "error"), s.join("<br>")), 0 !== a.length && (this.webfm.deviceObj.ExternalDeviceList = a)
    },
    handleMountList: function(e) {
        if (!_S("ha_safemode")) {
            var t, i = {},
                o = this.mountInfo.isoList,
                n = this.mountInfo.remoteList,
                s = this;
            Ext.isEmpty(o) && Ext.isEmpty(n) || (Ext.each(e.childNodes, function(e) {
                i[e.attributes.real_path] = e
            }), "fm_vd_root" === e.id ? t = o : "fm_rf_root" === e.id && (t = n), Ext.each(t, function(e) {
                var t = i[e.mount_point];
                t ? t.attributes.isMountPoint || s.doMount(e, !1) : s.doMount(e, !0)
            }))
        }
    },
    doMount: function(e, t) {
        var i, o = e.mount_point,
            n = o.replace(/^\/volume\d+\//, "/");
        if ("iso" === e.type) {
            var s = e.source.replace(/^\/volume\d+\//, "/");
            i = this.webfm.addWebAPITask({
                api: "SYNO.FileStation.Mount",
                version: 1,
                method: "mount_iso",
                params: {
                    source: s,
                    mount_point: n,
                    auto_mount: e.auto_mount,
                    user_set: !1
                },
                callback: function(e, t, i) {
                    if (e) this.webfm.reloadTree();
                    else {
                        var o = _WFT("filetable", "filetable_mount_iso") + ": " + SYNO.webfm.utils.getWebAPIErrStr(e, t);
                        this.webfm.owner.getMsgBox().alert("", o)
                    }
                },
                scope: this,
                single: !0
            })
        } else "cifs" !== e.type && "nfs" !== e.type || (i = this.webfm.addWebAPITask({
            api: "SYNO.FileStation.Mount.List",
            version: 1,
            method: "reconnect",
            params: {
                mount_point: [o]
            },
            callback: function(e, t) {
                if (e) this.webfm.reloadTree();
                else {
                    var i = _WFT("filetable", "filetable_mount_remote_volume") + ": " + SYNO.webfm.utils.getWebAPIErrStr(e, t);
                    this.webfm.owner.getMsgBox().alert("", i)
                }
            },
            scope: this,
            single: !0
        }));
        if (t) {
            var r = n.split("/"),
                a = r.pop(),
                l = r.join("/");
            SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: l,
                name: a,
                force_parent: !1
            }, function(e, t) {
                if (e) i.start(!0);
                else if (1100 === t.code) i.start(!0);
                else {
                    var o = SYNO.webfm.utils.getWebAPIErrStr(e, t);
                    this.showMsg(_WFT("filetable", "filetable_create_folder"), o)
                }
            }, this)
        } else i.start(!0)
    },
    getMountList: function() {
        _S("ha_safemode") || this.sendWebAPI({
            api: "SYNO.FileStation.Mount.List",
            async: !1,
            timeout: 10,
            version: 1,
            method: "get",
            scope: this,
            callback: function(e, t, i, o) {
                if (!e) return !1;
                this.mountInfo.isoList = t.isoList, this.mountInfo.mountConfig = t.mountConfig, this.mountInfo.remoteList = t.remoteList, this.mountInfo.initRemoteFolder = !1, this.mountInfo.initVirtualDeviceRoot = !1
            }
        })
    },
    createSearchNode: function(e) {
        var t = new Ext.tree.AsyncTreeNode({
            text: _WFT("search", "search_results"),
            id: "fm_search_root",
            cls: "search_node",
            allowDrag: !1,
            allowDrop: !1,
            allowChildren: !1,
            expandable: !1,
            isTarget: !1,
            hidden: !1 !== e
        });
        return t.attributes.type = SYNO.webfm.utils.source.remotes, t.attributes.path = SYNO.webfm.utils.source.remotes + "fm_search_root", this.searchNode = t, t
    },
    updateLocalRoot: function() {
        var e = this.initLocalRoot();
        this.isDestroyed || this.root.appendChild(e)
    },
    initLocalRoot: function() {
        var e = new AppletTreeLoader({
                action: "getdirectories"
            }, this.webfm),
            t = new Ext.tree.AsyncTreeNode({
                cls: "root_node",
                text: Ext.isMac ? _WFT("filetable", "mac_local_computer") : _WFT("filetable", "local_computer"),
                draggable: !1,
                expanded: !0,
                id: "fm_local_root",
                allowDrop: !1,
                loader: e
            });
        return Ext.isIE && !Ext.isModernIE && this.mon(t, "beforeappend", function(e, t, i) {
            return delete i.attributes.qtip, !0
        }), t.expand(), t
    },
    constructor: function(e) {
        Ext.apply(this, e || {});
        var t = function(e, t) {
                if ("fm_search_root" !== e.id) {
                    var i = !1,
                        o = this.webfm.treeCtxMenu,
                        n = e.attributes && e.attributes.isMountPoint && ("iso" === e.attributes.mountType || "remote" === e.attributes.mountType || "remotefail" === e.attributes.mountType),
                        s = o.items;
                    if (this.webfm.currCTNode = null, this.webfm.currCTNodeTmp = null, t.cancel = !0, "fm_root" != e.id && "fm_local_root" != e.id && "fm_vd_root" !== e.id && "fm_rf_root" !== e.id && e.parentNode && "fm_local_root" != e.parentNode.id && ("fm_top_root" !== e.parentNode.id || "fm_fav_root" === e.id)) {
                        var r, a, l = SYNO.webfm.utils.isInRecycleBinFolder(e.attributes.path),
                            h = !1,
                            c = _S("is_admin") && this.webfm.isExternalDevice(e.attributes.path),
                            d = e.parentNode && "fm_fav_root" === e.parentNode.id,
                            u = !!e.attributes.is_snapshot,
                            f = SYNO.webfm.utils.isSnapshotTopFolder(e.attributes.path, u),
                            m = !!e.attributes.has_snapshot && !u,
                            p = [],
                            g = !1,
                            b = !1,
                            S = !1,
                            _ = !0,
                            w = !0,
                            x = !0,
                            v = !0,
                            y = !0,
                            F = !0,
                            T = !0,
                            N = !0,
                            E = !0;
                        if ("fm_fav_root" === e.id || d && "broken" === e.attributes.status) Ext.each(o.items.items, function(e) {
                            e.hide()
                        }), s.get("gc_cleanfav").show();
                        else {
                            var C = SYNO.webfm.utils.isLocalSource(e.attributes.type, u),
                                D = e.attributes.type === SYNO.webfm.utils.source.remotev || "iso" === e.attributes.mountType,
                                O = D || e.parentNode && "fm_rf_root" === e.parentNode.id;
                            if ((r = e.attributes.path) && SYNO.webfm.VFS.isVFSPath(r)) {
                                g = !0, b = SYNO.webfm.VFS.isRootFolder(r), S = SYNO.webfm.VFS.isSharingPath(r), a = SYNO.webfm.VFS.getBaseURI(r);
                                var k = this.webfm.dirTree.getNodeById("remote" + a);
                                k && k.attributes.api && (p = k.attributes.api)
                            }
                            Ext.each(o.items.items, function(e) {
                                e.show()
                            }), o.items.get("mvcpto").setOvwrVisible(C), s.get("gc_renamefav").setVisible(d), s.get("gc_delfav").setVisible(d);
                            var P = !C && e.parentNode && "fm_fav_root" == e.parentNode.id,
                                Y = !this.webfm.checkFTPDownloadRight(e);
                            (P || C || f || g && !this.webfm.onCheckVFSAction("download", r, null, p)) && (N = !1), s.get("gc_download_menu").setDisabled(!Y), s.get("gc_download").setDisabled(!Y), N && 1 === AppletProgram.blJavaPermission ? (s.get("gc_download_menu").setVisible(!P && !C), s.get("gc_download").hide()) : (s.get("gc_download").setVisible(N), s.get("gc_download_menu").hide()), (u || _S("demo_mode") || g && !this.webfm.onCheckVFSAction("create", r, null, p)) && (y = !1), s.get("gc_createfolder").setVisible(y), s.get("gc_createfolder").setDisabled(D), (P || u || g && !this.webfm.onCheckVFSAction("move", r, null, p)) && (_ = !1), (P || u || g && !this.webfm.onCheckVFSAction("copy", r, null, p)) && (w = !1), s.get("gc_copy").setVisible(w), s.get("mvcpto").setVisible(_ || w), s.get("mvcpto").setMoveDisabled(O || !_), (P || u || g && !this.webfm.onCheckVFSAction("move", r, null, p)) && (x = !1), s.get("gc_cut").setVisible(x), s.get("gc_cut").setDisabled(O || !x), (P || u || g && !this.webfm.onCheckVFSAction("delete", r, null, p)) && (v = !1), s.get("gc_delete").setVisible(v), s.get("gc_delete").setDisabled(O), (P || u || g && !this.webfm.onCheckVFSAction("rename", r, null, p)) && (T = !1), s.get("gc_rename").setVisible(T), s.get("gc_rename").setDisabled(O), s.get("gc_cleanfav").hide(), s.get("gc_local_upload").setVisible(C), s.get("gc_eject").setVisible(c), C || u || l || g && !this.webfm.onCheckVFSAction("upload", r, null, p) ? (this.webfm.btnTreeUpBrowserAction.setHidden(!0), this.webfm.btnTreeUpSubMenuAction.setHidden(!0), E = !1) : SYNO.FileStation.FlashUploader.blFlash || 1 === AppletProgram.blJavaPermission || SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() ? this.webfm.onShowUpSubMenu(!0) : this.webfm.onShowUpSubMenu(!1), F = !SYNO.FileStation.Clipboard.isEmpty();
                            var M = SYNO.FileStation.Clipboard.get();
                            if (g && M && !this.webfm.onCheckVFSAction(M.action, M.recs, r, null, p) && (F = !1), s.get("gc_paste_ovwr").setVisible(F), s.get("gc_paste_skip").setVisible(F), s.get("gc_paste_ovwr").setDisabled(D), s.get("gc_paste_skip").setDisabled(D), h = -1 === e.attributes.path.indexOf("/", 1), !C && h && (Ext.each(o.items.items, function(e) {
                                    e.hide()
                                }), c && s.get("gc_eject").show(), d && (s.get("gc_renamefav").show(), s.get("gc_delfav").show()), y && s.get("gc_createfolder").show(), E && (SYNO.FileStation.FlashUploader.blFlash || 1 === AppletProgram.blJavaPermission || SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() ? this.webfm.onShowUpSubMenu(!0) : this.webfm.onShowUpSubMenu(!1)), F && (s.get("gc_paste_ovwr").setVisible(F), s.get("gc_paste_skip").setVisible(F))), "yes" === _D("supportmount") && (!g && n ? ("remotefail" === e.attributes.mountType && Ext.each(o.items.items, function(e) {
                                    e.hide()
                                }), o.items.get("gc_umount") && o.items.get("gc_umount").show()) : o.items.get("gc_umount") && o.items.get("gc_umount").hide()), s.get("gc_disconnect_vfs").setVisible(b && "remotefail" !== e.attributes.mountType), s.get("gc_remove_vfs").setVisible(b && !S), s.get("gc_snapshot_history").setVisible(m), C || d || b || "/home" === e.attributes.path || e.parentNode && ("fm_vd_root" == e.parentNode.id || "fm_rf_root" == e.parentNode.id) ? o.items.get("gc_property").hide() : o.items.get("gc_property").show(), Ext.each(o.items.items, function(e) {
                                    if (!1 === e.hidden) return i = !0, !1
                                }), !i) return
                        }
                        e.parentNode && "fm_top_root" !== e.parentNode.id && (o.items.get("text").show(), o.items.get("text").setText("<b>[" + Ext.util.Format.htmlEncode(Ext.util.Format.ellipsis(e.text, 36)) + "]</b>")), SYNO.webfm.utils.ShowHideMenu(o.items), o.showAt(t.getXY()), e.isSelected() || e.ui.addClass("context-menu-open"), this.webfm.mon(o, "hide", function() {
                            e.ui.removeClass("context-menu-open")
                        }, this, {
                            single: !0
                        }), this.webfm.currCTNodeTmp = e
                    }
                }
            },
            i = {
                ddGroup: "SDSShortCut",
                rootVisible: !1,
                autoFlexcroll: !0,
                mountInfo: {},
                updateScrollBarEventNames: ["append", "insert", "remove", "expandnode", "collapsenode", "resize"],
                selModel: new Ext.tree.DefaultSelectionModel({
                    listeners: {
                        selectionchange: {
                            fn: this.onNodeClick,
                            scope: this
                        },
                        beforeselect: {
                            fn: function(e, t, i) {
                                return !SYNO.webfm.utils.isRootNode(t)
                            },
                            scope: this
                        }
                    }
                }),
                listeners: {
                    containercontextmenu: {
                        fn: function(e, i) {
                            var o = e.getSelectionModel(),
                                n = o.getSelectedNode();
                            Ext.isEmpty(n) || t.call(this, n, i)
                        },
                        scope: this
                    },
                    contextmenu: {
                        fn: t,
                        scope: this
                    },
                    expandnode: {
                        fn: function(e) {
                            if (e !== this.root) {
                                var t = this.webfm.getCurrentDir(),
                                    i = this.webfm.getCurrentSource(),
                                    o = this.getNodeById(i + t);
                                o && o !== this.getSelectionModel().getSelectedNode() ? this.getSelectionModel().select(o) : e && e.ensureVisible()
                            }
                        },
                        scope: this
                    },
                    beforenodedrop: {
                        fn: this.beforeNodeDrop,
                        scope: this
                    },
                    movenode: {
                        fn: function(e, t, i, o, n) {
                            "fm_fav_root" === i.id && e.webfm.FileAction.SaveFav()
                        },
                        scope: this
                    },
                    beforemovenode: {
                        fn: function(e, t, i, o, n) {
                            return t.parentNode && "fm_fav_root" === t.parentNode.id && "fail" !== t.attributes.favstatus && o && "fm_fav_root" === o.id
                        },
                        scope: this
                    },
                    nodedragover: {
                        fn: this.nodeDragOver,
                        scope: this
                    },
                    afterrender: {
                        scope: this,
                        fn: function(e) {
                            Ext.isMac && e.getTreeEl().on("keyup", function(e) {
                                var t = this.getCmdCode();
                                Ext.isArray(t) ? this.cmdKeyDown = this.cmdKeyDown && -1 === t.indexOf(e.getKey()) : this.cmdKeyDown = this.cmdKeyDown && t !== e.getKey()
                            }, this)
                        },
                        single: !0
                    }
                },
                root: new Ext.tree.TreeNode({
                    id: "fm_top_root",
                    text: "none",
                    allowDrag: !1,
                    allowDrop: !1
                }),
                keys: this.getHotKeyMap()
            };
        SYNO.FileStation.MixedTreePanel.superclass.constructor.call(this, Ext.apply(e, i)), this.getMountList(), this.webfm.updateHybridShares(), this.remoteLoader = this.initRemoteLoader(), this.root.appendChild(this.initFavoriteNode(this.remoteLoader)), this.root.appendChild(this.initRemoteRoot(this.remoteLoader)), this.blInitVirtualRoot = !1
    },
    setVFSRemoteProtocol: function(e) {
        var t = this.getBaseURL({
            api: "SYNO.FileStation.VFS.Protocol",
            method: "list",
            version: 1
        });
        t = Ext.urlAppend(t, Ext.urlEncode({
            v: _S("fullversion")
        })), Ext.Ajax.request({
            url: t,
            method: "GET",
            scope: this,
            disableCaching: !1,
            callback: function(t, i, o) {
                if (o && o.responseText) {
                    var n = Ext.decode(o.responseText).data;
                    if (i) {
                        if (this.isDestroyed || !this.root) return;
                        var s = 0,
                            r = n.protocols;
                        for (this.initProtocolList(r), s = 0; s < r.length; s++) {
                            var a = r[s];
                            !1 !== a.has_server && this.root.appendChild(this.createVFSRoot(e, a.protocol, a.name))
                        }
                        this.updateScrollbar(this.getTreeEl().dom)
                    }
                }
            }
        })
    },
    getCmdCode: function() {
        return SYNO.webfm.utils.getCmdCode()
    },
    getHotKeyMap: function() {
        if (Ext.isMac) {
            return [{
                key: this.getCmdCode(),
                fn: function() {
                    this.cmdKeyDown = !0
                },
                scope: this
            }, {
                key: Ext.EventObject.DELETE,
                fn: this.onDelete,
                scope: this
            }, {
                key: Ext.EventObject.C,
                fn: this.onCopy,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.X,
                fn: this.onCut,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.V,
                fn: this.onPaste,
                stopEvent: !0,
                scope: this
            }, {
                key: Ext.EventObject.F2,
                fn: this.onRename,
                scope: this
            }]
        }
        return [{
            key: Ext.EventObject.DELETE,
            fn: this.onDelete,
            scope: this
        }, {
            key: Ext.EventObject.C,
            ctrl: !0,
            fn: this.onCopy,
            scope: this
        }, {
            key: Ext.EventObject.X,
            ctrl: !0,
            fn: this.onCut,
            scope: this
        }, {
            key: Ext.EventObject.V,
            ctrl: !0,
            fn: this.onPaste,
            scope: this
        }, {
            key: Ext.EventObject.F2,
            fn: this.onRename,
            scope: this
        }]
    },
    onCopy: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && SYNO.webfm.utils.NodeActionEnable.isEnableCopy(e) && (Ext.isMac && !this.cmdKeyDown || this.onAction("gc_copy"))
    },
    onCut: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && SYNO.webfm.utils.NodeActionEnable.isEnableCut(e) && (Ext.isMac && !this.cmdKeyDown || this.onAction("gc_cut"))
    },
    onPaste: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && SYNO.webfm.utils.NodeActionEnable.isEnablePaste(e) && (Ext.isMac && !this.cmdKeyDown || SYNO.FileStation.Clipboard.isEmpty() || this.onAction("gc_paste_skip"))
    },
    onRename: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && SYNO.webfm.utils.NodeActionEnable.isEnableRename(e) && this.onAction("gc_rename")
    },
    onDelete: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && SYNO.webfm.utils.NodeActionEnable.isEnableDelete(e) && this.onAction("gc_delete")
    },
    onAction: function(e) {
        var t = this.webfm.treeCtxMenu.items.get(e);
        t && (this.webfm.currCTNodeTmp = this.getSelectionModel().getSelectedNode(), this.webfm.treeCtxMenu.onTreeCTClick(t))
    },
    selectSearchNode: function() {
        this.searchNode.ui.show(), this.getSelectionModel().select(this.searchNode), this.searchNode.ensureVisible(), this.updateScrollbar(this.getTreeEl().dom)
    },
    unselectSearchNode: function(e) {
        if (e) {
            var t = this.treeroot.firstChild || this.treeroot;
            this.getSelectionModel().select(t), t.ensureVisible()
        }
        this.searchNode.ui.hide(), this.updateScrollbar(this.getTreeEl().dom)
    },
    unselectCurrentNode: function(e) {
        var t = this.getSelectionModel();
        t.unselect(t.getSelectedNode(), e || !0)
    },
    initProtocolList: function(e) {
        this.protocolMap = {}, Ext.each(e, function(e) {
            this.protocolMap[e.protocol] = e.name
        }, this)
    },
    createVFSNodeOnline: function(e) {
        e in this.protocolMap && this.root.appendChild(this.createVFSRoot(this.remoteLoader, e, this.protocolMap[e]))
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.PathBar = Ext.extend(Ext.util.Observable, {
    constructor: function(e) {
        this.init(e), SYNO.FileStation.PathBar.superclass.constructor.apply(this, arguments), this.addEvents("updatepath")
    },
    init: function(e) {
        return this.webfm = e.webfm, this.pathEditable = e.pathEditable || !1, this.tbPanel = new SYNO.FileStation.PathButtonsPanel({
            cls: "ux-pathtoolbar",
            webfm: this.webfm,
            pathEditable: this.pathEditable,
            owner: this
        }), this.pathEditable && (this.pathEditArea = this.getPathEditArea(), this.mainPanel = new SYNO.ux.Panel({
            autoFlexcroll: !1,
            activeItem: 0,
            layout: "card",
            defaults: {
                border: !1
            },
            items: [this.tbPanel, this.pathEditArea]
        }), this.registerPathEditAreaEvent()), this
    },
    addPathButton: function(e, t, i, o, n, s) {
        return this.tbPanel.addButton(e, t, i, o, n, s, this.webfm)
    },
    updatePathButton: function(e, t, i, o, n) {
        return this.tbPanel.updateButton(e, t, i, o, n)
    },
    addPathButtons: function(e) {
        for (var t = Math.max(this.tbPanel.items.length, e.length), i = e.length - 1, o = 0; o < t; o++)
            if (o < this.tbPanel.items.length && o < e.length) this.updatePathButton(o, e[o].text, e[o].tooltip, e[o].path, o === i);
            else {
                if (!(o < e.length)) {
                    this.removePathButtons(o, t);
                    break
                }
                this.addPathButton(this.tbPanel.items.length, e[o].text, e[o].tooltip, e[o].path, 0 === o, o === i)
            } this.tbPanel.setActiveButton(this.tbPanel.items[this.tbPanel.items.length - 1]), this.fireEvent("updatepath", this)
    },
    removePathButtons: function(e, t) {
        this.tbPanel.removeButtons(e, t)
    },
    setWidth: function(e) {
        this.tbPanel.setWidth(e), this.pathEditable && this.pathEditArea.setWidth(e)
    },
    getPathStore: function() {
        var e = new Ext.data.JsonReader({
                root: "shares",
                id: "path"
            }, [{
                name: "path"
            }]),
            t = {
                node: "fm_root",
                filetype: "dir",
                sort_by: "name",
                enum_cluster: !0,
                additional: []
            },
            i = new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "path"
            }]),
            o = {
                offset: 0,
                limit: 1e3,
                sort_by: "name",
                sort_direction: "ASC",
                filetype: "dir",
                additional: []
            };
        return new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                timeout: SYNO.webfm.Cfg.timeout,
                api: "SYNO.FileStation.List",
                method: "list",
                version: 2,
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    }
                }
            }),
            reader: i,
            readerForDir: i,
            readerForShare: e,
            remoteSort: !0,
            baseParams: o,
            baseParamsForDir: o,
            baseParamsForShare: t,
            listeners: {
                scope: this,
                load: function(e, t, i) {
                    e.filter(this.pathEditArea.displayField, this.pathEditArea.typedQueryPath)
                }
            }
        })
    },
    getPathEditArea: function() {
        return new SYNO.ux.ComboBox({
            editable: !0,
            displayField: "path",
            mode: "remote",
            typeAhead: !0,
            typeAheadDelay: 10,
            store: this.getPathStore(),
            height: 26,
            autoSelect: !1,
            minChars: 0,
            triggerAction: "query",
            queryParam: "query_full_path",
            hideTrigger: !0,
            tpl: ['<tpl for=".">', '<div class="x-combo-list-item {[values.cls || ""]}" ', 'role="option" ', 'ext:qtip="{[Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(values.path))]}" ', 'aria-label="{[Ext.util.Format.htmlEncode(Ext.util.Format.stripTags(values.path))]}" ', 'id="{[Ext.id()]}">', "{[Ext.util.Format.htmlEncode(values.path)]}", "</div>", "</tpl>"].join(""),
            listeners: {
                scope: this,
                beforeQuery: function(e) {
                    var t = this.pathEditArea;
                    t.typedQueryPath = e.query;
                    var i = e.query.replace(/\/[^\/]*$/g, ""),
                        o = e.query.substr(e.query.lastIndexOf("/") + 1);
                    if (t.lastQuery) {
                        var n = t.lastQuery.replace(/\/[^\/]*$/g, ""),
                            s = t.lastQuery.substr(t.lastQuery.lastIndexOf("/") + 1);
                        if (t.store.getCount() < 1e3 && n === i && 0 === o.indexOf(s)) return e.query = t.lastQuery, void t.store.filter(t.displayField, t.typedQueryPath)
                    }
                    "" === i ? (t.store.proxy.method = "list_share", t.store.reader = t.store.readerForShare, t.store.baseParams = t.store.baseParamsForShare) : (t.store.proxy.method = "list", t.store.reader = t.store.readerForDir, t.store.baseParams = t.store.baseParamsForDir), t.store.baseParams.folder_path = i,
                        t.store.baseParams.pattern = o + "*"
                }
            },
            select: function(e, t) {
                SYNO.ux.ComboBox.superclass.select.call(this, e, t);
                var i = this.store.getAt(e).data[this.displayField];
                this.setRawValue(i)
            },
            onKeyUp: function(e) {
                var t = e.getKey();
                SYNO.ux.ComboBox.superclass.onKeyUp.call(this, e), !1 === this.editable || !0 === this.readOnly || t != e.BACKSPACE && e.isSpecialKey() || this.view.clearSelections()
            }
        })
    },
    registerPathEditAreaEvent: function() {
        this.pathEditArea.on("blur", this.onPathEditAreaBlur, this), this.pathEditArea.on("select", function() {
            var e = this,
                t = this.webfm,
                i = this.pathEditArea;
            if (i.dqTask.cancel(), i.taTask.cancel(), i.store.suspendEvents(), i.collapse(), i.getValue() === i.currentDir) return void this.onPathEditAreaBlur();
            t.onGoToPathWithDirBySource(!0, i.getValue(), void 0, void 0, function(o) {
                o ? e.onPathEditAreaBlur() : (i.un("blur", e.onPathEditAreaBlur, e), t.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "error_dest_no_path"), function() {
                    i.on("blur", e.onPathEditAreaBlur, e), i.store.resumeEvents(), i.markInvalid(_WFT("error", "error_dest_no_path"))
                }))
            })
        }, this), this.pathEditArea.on("specialkey", function(e, t) {
            var i;
            t.getKey() === t.ENTER && (i = this.pathEditArea.getRawValue(), i = i.replace(/^\s+|\s+$|\/+$/g, ""), -1 !== i.search(/^[^\/][^:\/\/]+$/g) && (i = this.pathEditArea.currentDir + "/" + i), this.pathEditArea.setValue(i), this.pathEditArea.fireEvent("select"))
        }, this)
    },
    onPathEditAreaBlur: function() {
        this.mainPanel.getLayout().setActiveItem(0), this.tbPanel.trigger.focus()
    }
}), SYNO.FileStation.PathButtonsPanel = Ext.extend(Ext.BoxComponent, {
    activeButton: null,
    enableScroll: !0,
    scrollRepeatInterval: 400,
    scrollDuration: .35,
    buttonWidthSet: !1,
    allowDomMove: !1,
    edgeMinWidth: 30,
    onRender: function() {
        SYNO.FileStation.PathButtonsPanel.superclass.onRender.call(this, arguments), this.mon(this, "resize", this.delegateUpdates), this.items = [], this.selMenu = new SYNO.ux.Menu({
            items: [],
            listeners: {
                click: {
                    fn: function(e, t) {
                        t.path && this.webfm.onGoToPathWithDir(t.path)
                    },
                    scope: this
                }
            }
        }), this.stripWrap = this.el.createChild({
            cls: "ux-pathbuttons-strip-wrap",
            cn: {
                tag: "ul",
                cls: "ux-pathbuttons-strip"
            }
        }), this.stripSpacer = this.el.createChild({
            cls: "ux-pathbuttons-strip-spacer"
        }), this.strip = new Ext.Element(this.stripWrap.dom.firstChild), this.edge = this.strip.createChild({
            tag: "li",
            cls: "ux-pathbuttons-edge"
        }), this.pathEditable && (this.trigger = this.el.createChild({
            cls: "ux-pathbuttons-trigger",
            tabIndex: -1
        }), this.mon(this.edge, "click", this.onClickTrigger, this), this.mon(this.trigger, "click", this.onClickTrigger, this), this.mon(this.trigger, "keydown", this.onKeyDownEdge, this)), this.strip.createChild({
            cls: "x-clear"
        })
    },
    addButton: function(e, t, i, o, n, s, r) {
        var a = this.strip.createChild({
                tag: "li"
            }, this.edge),
            l = new SYNO.FileStation.PathBar.PathButton(a, e, t, i, o, n, s, r);
        return this.items.push(l), this.buttonWidthSet || (this.lastButtonWidth = l.container.getWidth()), this.addManagedComponent(l), l
    },
    updateButton: function(e, t, i, o, n) {
        this.items[e].updateButton(t, i, o, n)
    },
    removeButtons: function(e, t) {
        for (var i, o, n = e; n < t; n++) o = this.items[n], i = document.getElementById(o.container.id), this.removeManagedComponent(o), o.destroy(), i.parentNode.removeChild(i);
        var s = [];
        for (n = 0; n < e; n++) s.push(this.items[n]);
        this.items = s, this.delegateUpdates()
    },
    setActiveButton: function(e) {
        this.activeButton = e, this.delegateUpdates()
    },
    delegateUpdates: function() {
        this.enableScroll && this.rendered && this.autoScroll()
    },
    autoScroll: function() {
        var e = this.items.length,
            t = this.el.dom.clientWidth,
            i = this.stripWrap,
            o = this.edge.getWidth(),
            n = this.strip.getWidth() - o,
            s = i.dom.offsetWidth,
            r = this.getScrollPos(),
            a = this.edge.getOffsetsTo(this.stripWrap)[0] + r;
        if (!(!this.enableScroll || e < 1 || s < 20)) {
            i.setWidth(t), this.pathEditable && (n < t - this.edgeMinWidth ? this.edge.setWidth(t - n) : this.edge.setWidth(this.edgeMinWidth));
            var l = 1 == this.items.length;
            a <= t || l ? (i.dom.scrollLeft = 0, this.showSelBtn && (this.showSelBtn = !1, this.el.removeClass("x-pathbuttons-selection-btn-displayed"), this.menuBtn.hide())) : (this.showSelBtn || this.el.addClass("x-pathbuttons-selection-btn-displayed"), t -= i.getMargins("lr"), i.setWidth(t > 20 ? t : 20), this.showSelBtn || (this.menuBtn ? this.menuBtn.show() : this.createMenuBtn()), this.showSelBtn = !0, this.updateScrollandSelMenu())
        }
    },
    createMenuBtn: function() {
        var e = this.el.dom.offsetHeight,
            t = this.el.insertFirst({
                cls: "ux-pathbuttons-selection-btn"
            });
        t.setHeight(e), t.addClassOnOver("ux-pathbuttons-selection-btn-over"), t.addClassOnClick("ux-pathbuttons-selection-btn-click"), this.leftRepeater = new Ext.util.ClickRepeater(t, {
            interval: this.scrollRepeatInterval,
            handler: this.onShowMenu,
            scope: this
        }), this.menuBtn = t
    },
    onShowMenu: function() {
        var e = this.menuBtn.getXY();
        this.selMenu.isVisible() ? this.selMenu.hide() : this.selMenu.showAt([e[0] + -5, e[1] + 28])
    },
    getScrollPos: function() {
        return parseInt(this.stripWrap.dom.scrollLeft, 10) || 0
    },
    updateScrollandSelMenu: function() {
        for (var e, t = this.items.length, i = t - 1, o = 0, n = this.stripWrap.getWidth(), s = i; s >= 0 && (e = this.items[s].el.child(".ux-pathbutton-center"), !((o += e.getWidth() + 14) > n)); s--);
        s == i && (s -= 1), this.selMenu.removeAll();
        for (var r = 0; r <= s; r++) this.selMenu.addItem({
            path: this.items[r].path,
            text: this.items[r].text,
            htmlEncode: !1
        });
        var a = this.items[s + 1],
            l = this.stripWrap.dom.scrollLeft,
            h = a.el.getOffsetsTo(this.stripWrap)[0] + l;
        this.stripWrap.scrollTo("left", h - 14)
    },
    onClickTrigger: function() {
        "remotesfm_search_root" !== this.webfm.getCurrentDir() && (this.owner.pathEditArea.currentDir = this.webfm.getCurrentDir(), this.owner.pathEditArea.clearInvalid(), this.owner.pathEditArea.setValue(this.owner.pathEditArea.currentDir), this.owner.pathEditArea.store.resumeEvents(), this.owner.mainPanel.getLayout().setActiveItem(1), this.owner.pathEditArea.focus(), this.owner.pathEditArea.selectText())
    },
    onKeyDownEdge: function(e) {
        e.getKey() === e.ENTER && this.onClickTrigger()
    }
}), SYNO.FileStation.PathBar.PathButton = function(e, t, i, o, n, s, r, a) {
    this.webfm = a;
    var l = s ? this.firstBtnCls : "",
        h = r ? this.lastBtnCls : "";
    SYNO.FileStation.PathBar.PathButton.superclass.constructor.call(this, {
        text: i,
        itemId: t,
        renderTo: e,
        tooltip: o,
        clickEvent: "mousedown",
        tabIndex: -1,
        listeners: {
            click: {
                fn: function() {
                    var e = this.getPath();
                    e && this.webfm.onGoToPathWithDir(e)
                },
                scope: this
            }
        },
        template: new Ext.Template('<table cellspacing="0" class="x-btn ' + l + " " + h + ' {3}"><tbody><tr>', '<td class="ux-pathbutton-left"></td>', '<td class="ux-pathbutton-center"><em class="{5} unselectable="on">', '<button class="x-btn-text {2}" type="{1}" style="height:18px;">{0}</button>', "</em></td>", '<td class="ux-pathbutton-right"></td>', "</tr></tbody></table>")
    }), this.setPath(n)
}, Ext.extend(SYNO.FileStation.PathBar.PathButton, Ext.Button, {
    firstBtnCls: "x-first-btn",
    lastBtnCls: "x-last-btn",
    setPath: function(e) {
        this.path = e
    },
    getPath: function() {
        return this.path
    },
    updateButton: function(e, t, i, o) {
        this.setPath(i), this.setText(e), this.setTooltip(t), o ? this.addClass(this.lastBtnCls) : this.removeClass(this.lastBtnCls)
    }
}), Ext.define("SYNO.FileStation.CrtFdrDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.checkName = !0, this.updateDsmStyle(e), Ext.apply(this, e || {});
        var t = this.init(),
            i = {
                owner: this.owner,
                width: 450,
                height: 180,
                shadow: !0,
                collapsible: !1,
                resizable: !1,
                autoScroll: !1,
                constrainHeader: !0,
                closeAction: "closeHandler",
                plain: !0,
                title: _WFT("filetable", "filetable_create_folder"),
                layout: "fit",
                items: [t],
                buttons: [{
                    text: _WFT("common", "common_cancel"),
                    scope: this,
                    handler: this.closeHandler
                }, {
                    btnStyle: "blue",
                    text: _WFT("common", "common_submit"),
                    scope: this,
                    handler: this.saveFolderName
                }],
                listeners: {
                    afterlayout: {
                        fn: function() {
                            this.focusEl = this.crtFdrForm.get("name"), this.center()
                        },
                        scope: this,
                        single: !0
                    }
                }
            };
        this.addEvents({
            callback: !0
        }), SYNO.FileStation.CrtFdrDialog.superclass.constructor.call(this, i)
    },
    init: function() {
        var e = {
                labelWidth: 75,
                labelAlign: "top",
                trackResetOnLoad: !0,
                waitMsgTarget: !0,
                border: !1,
                bodyStyle: this.isV5Style() ? "padding: 0 4px" : "padding: 20px",
                items: [{
                    xtype: this.isV5Style() ? "syno_textfield" : "textfield",
                    itemId: "name",
                    fieldLabel: _WFT("filetable", "filetable_fill_name"),
                    name: "name",
                    maxlength: 255,
                    anchor: "100%",
                    enableKeyEvents: !0,
                    listeners: {
                        keypress: function(e, t) {
                            t.getKey() === Ext.EventObject.ENTER && this.saveFolderName()
                        },
                        buffer: 100,
                        scope: this
                    }
                }],
                listeners: {
                    actionfailed: {
                        fn: this.closeHandler,
                        scope: this
                    }
                }
            },
            t = new Ext.form.FormPanel(e);
        return this.crtFdrForm = t, t
    },
    callbackHandler: function() {
        this.hide(), this.fireEvent("callback")
    },
    closeHandler: function() {
        this.callbackHandler()
    },
    saveFolderName: function() {
        var e = "";
        if (!this.crtFdrForm || !this.crtFdrForm.form.findField("name")) return void this.closeHandler();
        if (e = this.crtFdrForm.form.findField("name").getValue(), !(e = Ext.util.Format.trim(e))) return void this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_empty_name"));
        if (this.checkName) {
            if (!SYNO.webfm.utils.checkFileLen(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_long_path"));
            if (SYNO.webfm.utils.isNameReserved(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_reserved_name"));
            if (SYNO.webfm.utils.isNameCharIllegal(e)) return void this.getMsgBox().alert(_WFT("filetable", "filetable_create_folder"), _WFT("error", "error_reserved_name"))
        }
        this.fdrName = e, this.callbackHandler()
    },
    resetDialogForm: function() {
        this.crtFdrForm && this.crtFdrForm.form.reset()
    },
    getFolderName: function() {
        return this.fdrName
    },
    resetFolderName: function() {
        this.fdrName = null
    },
    setParentDir: function(e) {
        this.parentDir = e
    },
    setCheckName: function(e) {
        SYNO.webfm.utils.isLocalSource(e) ? this.checkName = !1 : this.checkName = !0
    },
    getParentDir: function() {
        return this.parentDir
    },
    load: function() {
        this.resetDialogForm(), this.resetFolderName(), this.show()
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.SelectAllRowSelectionModel = Ext.extend(Ext.grid.RowSelectionModel, {
    constructor: function(e) {
        SYNO.FileStation.SelectAllRowSelectionModel.superclass.constructor.call(this, e), this.pageSelections = new Ext.util.MixedCollection(!1, function(e) {
            return e.id
        })
    },
    onRefresh: function() {
        var e, t, i = this.grid.store,
            o = this.getSelections(),
            n = 0,
            s = o.length;
        for (this.silent = this.silentMode && !0, this.clearSelections(!0); n < s; n++) t = o[n], -1 != (e = i.indexOfId(t.id)) && this.selectRow(e, !0);
        o.length != this.pageSelections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
    },
    maskGrid: function(e) {
        e.loadMask && e.loadMask.show()
    },
    unmaskGrid: function(e) {
        e.loadMask && e.loadMask.hide()
    },
    selectAllRow: function(e) {
        if (!this.isLocked()) {
            var t = this.grid,
                i = this.grid.store,
                o = this.grid.store.getCount();
            this.maskGrid(t), this.selections.clear();
            for (var n = 0; n < o; n++) this.selectRow(n, !0);
            if (i.storetype === SYNO.webfm.utils.source.remotes) return this.unmaskGrid(t), void(i.getTotalCount() !== i.getCount() && t.owner.findAppWindow().getToastBox.call(t, _WFT("search", "select_current_page_all"), !1, !1, {
                delay: 2500,
                offsetY: 32
            }));
            if (i.getTotalCount() === i.getCount()) return void this.unmaskGrid(t);
            i.suspendEvents(), i.load({
                params: {
                    offset: 0,
                    limit: i.getTotalCount()
                },
                callback: function() {
                    this.pageSelections.clear(), this.pageSelections.addAll(i.data.items), i.resumeEvents(), this.unmaskGrid(t), e.callback && e.callback.call(e.scope || this)
                },
                scope: this
            })
        }
    },
    clearSelections: function(e) {
        if (!this.isLocked()) {
            if (!0 !== e) {
                var t = this.grid.store,
                    i = this.selections;
                i.each(function(e) {
                    this.deselectRow(t.indexOfId(e.id))
                }, this), i.clear()
            } else this.selections.clear();
            this.last = !1
        }
    },
    clearAllSelections: function(e) {
        if (!this.isLocked())
            if (!0 !== e) {
                var t = this.grid.store,
                    i = this.pageSelections;
                i.each(function(e) {
                    this.deselectRow(t.indexOfId(e.id))
                }, this), i.clear()
            } else this.pageSelections.clear()
    },
    selectRow: function(e, t, i) {
        if (!(this.isLocked() || e < 0 || e >= this.grid.store.getCount() || t && this.isSelected(e))) {
            var o = this.grid.store.getAt(e);
            o && !1 !== this.fireEvent("beforerowselect", this, e, t, o) && (t && !this.singleSelect || (this.clearSelections(), this.clearAllSelections()), this.selections.add(o), this.pageSelections.add(o), this.last = this.lastActive = e, i || this.grid.getView().onRowSelect(e), this.silent || (this.fireEvent("rowselect", this, e, o), this.fireEvent("selectionchange", this)))
        }
    },
    selectRows: function(e, t) {
        t || (this.clearSelections(), this.clearAllSelections());
        for (var i = 0, o = e.length; i < o; i++) this.selectRow(e[i], !0)
    },
    selectRange: function(e, t, i) {
        var o;
        if (!this.isLocked())
            if (i || (this.clearSelections(), this.clearAllSelections()), e <= t)
                for (o = e; o <= t; o++) this.selectRow(o, !0);
            else
                for (o = e; o >= t; o--) this.selectRow(o, !0)
    },
    deselectRow: function(e, t) {
        if (!this.isLocked()) {
            this.last == e && (this.last = !1), this.lastActive == e && (this.lastActive = !1);
            var i = this.grid.store.getAt(e);
            i && (this.selections.remove(i), this.pageSelections.remove(i), t || this.grid.getView().onRowDeselect(e), this.fireEvent("rowdeselect", this, e, i), this.fireEvent("selectionchange", this))
        }
    },
    getSelections: function() {
        return [].concat(this.pageSelections.items)
    }
}), Ext.define("SYNO.FileStation.TypeAndSearchPlugin", {
    extend: "Ext.Component",
    delayTime: 50,
    delayClearTime: 720,
    init: function(e) {
        var t = this;
        t.keyword = "", t.view = e, e.mon(e, "afterlayout", function() {
            this.mon(e.getEl(), "keypress", this.onDetectKeyPress, this)
        }, t, {
            single: !0
        })
    },
    runSearchTask: function() {
        var e = this;
        e.runTask("searchTask", e.search, Ext.isNumber(e.delayTime) ? e.delayTime : 50)
    },
    runClearKeywordTask: function() {
        var e = this;
        e.runTask("clearKeywordTask", e.clearKeyword, Ext.isNumber(e.delayClearTime) ? e.delayClearTime : 720)
    },
    clearKeyword: function() {
        this.keyword = ""
    },
    search: function() {
        var e = this,
            t = e.view,
            i = e.keyword;
        t && Ext.isFunction(t.searchAndFocus) && t.searchAndFocus(i, i.length > 1)
    },
    hasModifiers: function(e) {
        for (var t, i = ["shift", "ctrl", "alt"], o = 0, n = i.length; o < n; ++o)
            if (t = i[o], e[t + "Key"]) return !0;
        return !1
    },
    onDetectKeyPress: function(e) {
        var t = this;
        if (t.hasModifiers(e)) return void t.clearKeyword();
        t.keyword = Ext.isString(t.keyword) ? t.keyword : "", t.keyword += String.fromCharCode(e.getCharCode()), t.runSearchTask(), t.runClearKeywordTask()
    },
    destroy: function() {
        var e = this,
            t = ["searchTask", "clearKeywordTask"];
        Ext.each(t, function(e, t, i) {
            this.removeDelayedTask(e)
        }, e), e.callParent(arguments)
    }
}), Ext.preg("typeandsearchplugin", SYNO.FileStation.TypeAndSearchPlugin), Ext.ns("SYNO.FileStation"), SYNO.FileStation.FocusGridPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        e.mon(e, "click", function(e) {
            document.activeElement.id !== this.getView().focusEl.id && (Ext.isGecko ? this.getView().focusEl.focus() : this.getView().focusEl.focus.defer(1, this.getView().focusEl))
        }, e)
    }
}), SYNO.FileStation.FocusGridPluginInstance = new SYNO.FileStation.FocusGridPlugin, Ext.preg("focusgridplugin", SYNO.FileStation.FocusGridPlugin), Ext.ns("SYNO.FileStation"), SYNO.FileStation.FocusPanelPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        e.mon(e, "click", function(e) {
            this.body.tabindex || this.body.set({
                tabindex: -1
            }), document.activeElement.id !== this.body.id && (Ext.isGecko ? this.body.focus() : this.body.focus.defer(1, this.body))
        }, e)
    }
}), SYNO.FileStation.FocusPanelPluginInstance = new SYNO.FileStation.FocusPanelPlugin, Ext.preg("focuspanelplugin", SYNO.FileStation.FocusPanelPlugin), Ext.ns("SYNO.FileStation"), SYNO.FileStation.GridPanelFlexcrollPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        var t = this;
        Ext.apply(e, {
            updateScrollbar: t.updateScrollbar
        }), e.mon(e, "beforerender", function() {
            e.cls = e.cls ? e.cls + " syno-webfm-scroll" : "syno-webfm-scroll", e.overCls = e.overCls ? e.overCls + " syno-webfm-scroll-over" : "syno-webfm-scroll-over"
        }, this), e.mon(e, "afterrender", function(e) {
            var t = e.getView().scroller;
            e.updateScrollbar(t.dom), e.mon(e, "resize", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getView(), "refresh", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "load", function() {
                this.updateScrollbar(t.dom, !0), this.fireEvent("afterUpdateScrollbar", this)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "clear", function() {
                this.updateScrollbar(t.dom, !0)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "datachanged", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "update", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            })
        }, this)
    },
    updateScrollbar: function(e, t) {
        e && e.fleXcroll ? (t && e.fleXcroll.setScrollPos(!1, 0), e.fleXcroll.updateScrollBars(), t || e.fleXcroll.setScrollPos(0, 0, !0)) : e && (fleXenv.fleXcrollMain(e), e.onfleXcroll = function() {
            this.isVisible() && this.getView().update && this.getView().update()
        }.createDelegate(this))
    }
}), SYNO.FileStation.GridPanelFlexcrollPluginInstance = new SYNO.FileStation.GridPanelFlexcrollPlugin, Ext.preg("gridpanelflexcrollplugin", SYNO.FileStation.GridPanelFlexcrollPlugin), SYNO.FileStation.BufferViewFlexcrollPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        var t = this;
        Ext.apply(e.getView(), {
            initTemplates: t.initTemplates,
            getVscrollerbarBase: t.getVscrollerbarBase,
            getContentwrapper: t.getContentwrapper,
            getVisibleRowCount: t.getVisibleRowCount,
            getVisibleRows: t.getVisibleRows
        })
    },
    initTemplates: function() {
        Ext.ux.grid.BufferView.prototype.initTemplates.apply(this, arguments);
        var e = this.templates;
        e.hcell = new Ext.Template('<td class="x-grid3-hd x-grid3-cell x-grid3-td-{id} {css}" style="{style}"><div class="x-grid3-hd-row-split"></div><div {tooltip} {attr} class="x-grid3-hd-inner webfm-x-grid3-hd x-grid3-hd-{id}" unselectable="on" style="{istyle}">', this.grid.enableHdMenu ? '<a class="x-grid3-hd-btn" href="#"></a>' : "", "{value}", '<img alt="" class="x-grid3-sort-icon" src="', Ext.BLANK_IMAGE_URL, '" />', "</div>", "</td>"), e.hcell.disableFormats = !0, e.hcell.compile()
    },
    getVscrollerbarBase: function() {
        return this.scrollerbarbase ? this.scrollerbarbase : this.scrollerbarbase = Ext.get(this.el.child("div.scrollerbarbase"))
    },
    getContentwrapper: function() {
        return this.vscrollerbar ? this.vscrollerbar : this.vscrollerbar = Ext.get(this.el.child("div.contentwrapper"))
    },
    getVisibleRowCount: function() {
        var e = this.getCalculatedRowHeight(),
            t = Ext.isEmpty(this.getVscrollerbarBase()) ? this.scroller.dom.clientHeight : this.getVscrollerbarBase().getHeight();
        return t < 1 ? 0 : Math.ceil(t / e)
    },
    getVisibleRows: function() {
        var e = this.getVisibleRowCount(),
            t = Ext.isEmpty(this.getContentwrapper()) ? this.scroller.dom.scrollTop : -1 * this.getContentwrapper().getTop(!0) + 1,
            i = 0 === t ? 0 : Math.floor(t / this.getCalculatedRowHeight()) - 1;
        return {
            first: Math.max(i, 0),
            last: Math.min(i + e + 3, this.ds.getCount() - 1)
        }
    }
}), SYNO.FileStation.BufferViewFlexcrollPluginInstance = new SYNO.FileStation.BufferViewFlexcrollPlugin, Ext.preg("bufferviewflexcrollplugin", SYNO.FileStation.BufferViewFlexcrollPlugin), SYNO.SDS.Utils.DataView.DragSelector = function() {
    function e(e) {
        F = new Ext.dd.DragTracker({
            onBeforeStart: t,
            onStart: i,
            onDrag: o,
            onEnd: n
        }), F.initEl(e.el)
    }

    function t(e) {
        var t = w.el.isMasked(),
            i = null !== e.getTarget(w.itemSelector),
            o = null !== e.getTarget(".vscrollerbar") || null !== e.getTarget(".hscrollerbar");
        return W = e.ctrlKey, !t && !i && !o
    }

    function i(e) {
        w.focus(), x = w.el, v = w.getTemplateTarget().parent(), w.on("containerclick", p, w), w.on("flexcroll", s, w), w.el.on("keydown", r, w.el), a(), h(), C = {
            x: F.startXY[0],
            y: F.startXY[1]
        }, I = v.getTop(!0), A = v.getLeft(!0), W || w.clearAllSelections(), Ext.QuickTips.disable()
    }

    function o(e) {
        D = {
            x: F.getXY()[0],
            y: F.getXY()[1]
        }, u(), m(), b()
    }

    function n(e) {
        l(), P = setTimeout(function() {
            w.un("containerclick", p, w)
        }, 0), w.un("flexcroll", s, w), w.el.un("keydown", r, w.el), k && clearInterval(k), Ext.QuickTips.enable()
    }

    function s() {
        E = v.getRegion(), d(), u(), m()
    }

    function r(e) {
        var t = e.getKey();
        t === e.ENTER || t === e.ESC || 93 === t ? (F.onMouseUp(e), clearTimeout(P), w.el.on("mouseup", g, w)) : t === e.DELETE && F.onMouseUp(e)
    }

    function a() {
        y ? (y.dom.parentNode !== v.dom && v.dom.appendChild(y.dom), y.setDisplayed("block")) : y = v.createChild({
            cls: "x-view-selector"
        })
    }

    function l() {
        y && y.setDisplayed(!1)
    }

    function h() {
        N = x.getRegion(), E = v.getRegion(), c()
    }

    function c() {
        var e = 0;
        T = [], Y = w.store.getCount(), w.all.each(function(t) {
            T.push(t.getRegion()), T[e].el = t, W && (T[e].isSelected = T[e].isStartWithSelected = w.isSelected(e)), e += 1
        })
    }

    function d() {
        var e = 0;
        Y !== w.store.getCount() ? c() : w.all.forEach(function(t) {
            var i = t.getRegion();
            T[e].left = i.left, T[e].top = i.top, T[e].right = i.right, T[e].bottom = i.bottom, e += 1
        })
    }

    function u() {
        var e = v.getTop(!0) - I,
            t = v.getLeft(!0) - A,
            i = {
                x: C.x + t,
                y: C.y + e
            };
        O = {
            x: Math.min(Math.max(N.left, D.x), N.right),
            y: Math.min(Math.max(N.top, D.y), N.bottom)
        }, M.left = Math.min(i.x, O.x), M.top = Math.min(i.y, O.y), M.right = M.left + Math.abs(i.x - O.x), M.bottom = M.top + Math.abs(i.y - O.y);
        var o = f();
        M.constrainTo(o), y.setRegion(M)
    }

    function f() {
        var e = {
            left: N.left,
            top: N.top,
            right: N.right,
            bottom: N.bottom
        };
        return x.getHeight(!0) >= v.getHeight(!0) ? e : (M.top !== O.y ? e.top = E.top : e.bottom = E.bottom, M.left !== O.x ? e.left = E.left : e.right = E.right, e)
    }

    function m() {
        for (var e = 0, t = T.length; e < t; e++) {
            var i = T[e],
                o = !!M.intersect(i);
            i.isStartWithSelected && (o = !o), o && !T[e].isSelected ? (T[e].isSelected = !0, w.select(e, !0)) : !o && T[e].isSelected && (T[e].isSelected = !1, w.deselect(e))
        }
    }

    function p() {
        return !1
    }

    function g() {
        setTimeout(function() {
            w.un("containerclick", p, w)
        }, 0), w.el.un("mouseup", g, w)
    }

    function b() {
        var e = R.increment,
            t = !0 === x.dom.fleXdata.scroller[0],
            i = !0 === x.dom.fleXdata.scroller[1];
        k && clearInterval(k), t && D.x < N.left ? S(-1 * e, B) : t && D.x > N.right && S(e, B), i && D.y < N.top ? S(-1 * e, V) : i && D.y > N.bottom && S(e, V)
    }

    function S(e, t) {
        k = setInterval(_(e, t), R.frequency), _(e, t)()
    }

    function _(e, t) {
        return function() {
            var i = x.dom.fleXdata,
                o = i.scrollPosition[t][0],
                n = i.scrollPosition[t][1],
                s = o + e;
            s = Math.min(s, n), s = Math.max(s, 0), t === B ? x.dom.fleXcroll.setScrollPos(s, 0) : x.dom.fleXcroll.setScrollPos(0, s)
        }
    }
    var w, x, v, y, F, T, N, E, C, D, O, k, P, Y, M = new Ext.lib.Region(0, 0, 0, 0),
        I = 0,
        A = 0,
        W = !1,
        R = {
            frequency: 100,
            increment: 20
        },
        B = 0,
        V = 1;
    this.init = function(t) {
        w = t, w.mon(w, "render", e)
    }
}, Ext.ns("SYNO.FileStation"), SYNO.FileStation.FocusComponentPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        e.mon(e, "afterrender", function() {
            this.onAfterRender(e)
        }, this)
    },
    onAfterRender: function(e) {
        e.getEl().on("click", function(e) {
            Ext.isGecko ? this.getEl().focus() : this.getEl().focus.defer(1, this.getEl())
        }, e)
    }
}), SYNO.FileStation.FocusComponentPluginInstance = new SYNO.FileStation.FocusComponentPlugin, Ext.preg("focuscomponentplugin", SYNO.FileStation.FocusComponentPlugin), SYNO.FileStation.DataViewSelectionModel = function(e) {
    var t = e,
        i = function() {
            return t.getSelectionCount() > 0
        },
        o = function() {
            return t.getSelectedRecords()
        };
    return {
        dataView: t,
        getSelected: function() {
            return o()[0]
        },
        getCount: function() {
            return t.getSelectionCount()
        },
        hasSelection: i,
        getSelections: o,
        selectAllRow: function(e) {
            t.selectAllRow(e)
        },
        clearAllSelections: function(e) {
            t.clearAllSelections(e)
        },
        clearSelections: function(e) {
            t.clearSelections(e)
        },
        selectRow: function(e, i) {
            t.select(e, i)
        },
        selectRecords: function(e, i) {
            var o = 0;
            if (!Ext.isEmpty(e))
                for (i || this.clearAllSelections(), o = 0; o < e.length; o++) this.selectRow(t.store.indexOf(e[o]), !0)
        }
    }
}, SYNO.FileStation.SelectAllDataView = Ext.extend(SYNO.SDS.Utils.DataView.LazyDataView, {
    constructor: function(e) {
        SYNO.FileStation.SelectAllDataView.superclass.constructor.call(this, e), this.selectAll = new Ext.util.MixedCollection(!1, function(e) {
            return e.id
        }), this.on("afterrender", this.protectFocus.createDelegate(this, [!0]), this)
    },
    protectFocus: function(e) {
        this.rendered && (this.el.dom.focusProtect = e)
    },
    getSelectionModel: function() {
        return this.selectionModel || (this.selectionModel = new SYNO.FileStation.DataViewSelectionModel(this))
    },
    getSelectionCount: function() {
        return this.selectAll.items.length
    },
    getSelectedNodes: function() {
        return [].concat(this.selectAll.items)
    },
    getSelectedRecords: function() {
        return [].concat(this.selectAll.items)
    },
    clearAllSelections: function(e, t) {
        (this.multiSelect || this.singleSelect) && this.selectAll.getCount() > 0 && (t || this.selected.removeClass(this.selectedClass), this.selected.clear(), this.selectAll.clear(), this.last = !1, e || this.fireEvent("selectionchange", this, this.selected.elements))
    },
    onContainerClick: function(e) {
        null === e.getTarget(".vscrollerbar") && null === e.getTarget(".hscrollerbar") && this.clearAllSelections()
    },
    selectAllRow: function(e) {
        var t = this,
            i = t.getStore(),
            o = i.getCount();
        t.getEl().mask(t.loadingText || "", "x-mask-loading"), t.clearAllSelections();
        for (var n = 0; n < o; n++) t.select(n, !0, !0);
        return i.storetype === SYNO.webfm.utils.source.remotes ? (t.getEl().unmask(), void(i.getTotalCount() !== i.getCount() && this.owner.findAppWindow().getToastBox.call(this, _WFT("search", "select_current_page_all"), !1, !1, {
            delay: 2500,
            offsetY: 32
        }))) : i.getTotalCount() === i.getCount() ? void t.getEl().unmask() : (i.suspendEvents(), void i.load({
            params: {
                offset: 0,
                limit: i.getTotalCount()
            },
            callback: function() {
                t.isDestroy || (this.selectAll.addAll(i.data.items), i.resumeEvents(), t.getEl().unmask(), e.callback && e.callback.call(e.scope || this))
            },
            scope: this
        }))
    },
    selectRange: function(e, t, i) {
        i || this.clearAllSelections(!0), this.select(this.getNodes(e, t), !0)
    },
    isSelected: function(e) {
        return this.selectAll.contains(this.getRecord(this.getNode(e)))
    },
    deselect: function(e) {
        this.isSelected(e) && (e = this.getNode(e), this.selected.removeElement(e), this.selectAll.remove(this.getRecord(this.getNode(e))), this.last == e.viewIndex && (this.last = !1), Ext.fly(e).removeClass(this.selectedClass), this.fireEvent("selectionchange", this, this.selected.elements))
    },
    select: function(e, t, i) {
        if (Ext.isArray(e)) {
            t || this.clearAllSelections(!0);
            for (var o = 0, n = e.length; o < n; o++) this.select(e[o], !0, !0);
            i || this.fireEvent("selectionchange", this, this.selected.elements)
        } else {
            var s = this.getNode(e);
            t || this.clearAllSelections(!0), s && !this.isSelected(s) && !1 !== this.fireEvent("beforeselect", this, s, this.selected.elements) && (Ext.fly(s).addClass(this.selectedClass), this.selected.add(s), this.selectAll.add(this.getRecord(this.getNode(s))), this.last = s.viewIndex, i || this.fireEvent("selectionchange", this, this.selected.elements))
        }
    },
    refresh: function() {
        SYNO.FileStation.SelectAllDataView.superclass.refresh.call(this);
        for (var e, t = this, i = t.getSelectedRecords(), o = 0, n = t.getStore(), s = i.length; o < s; o++) {
            var r = i[o]; - 1 != (e = n.indexOfId(r.id)) && this.select(e, !0, !0)
        }
    }
}), SYNO.FileStation.ThumbnailSizeManager = Ext.extend(Object, {
    constructor: function(e) {
        var t = this;
        e = e || {}, t.largeThumbCls = "syno-sds-fs-large-thumb", t.smallThumbCls = "syno-sds-fs-small-thumb", t.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM, Ext.apply(t, e)
    },
    resizeThumb: function(e) {
        var t = e.getWidth(),
            i = e.getHeight();
        e.removeClass("syno-sds-fs-large-thumb-width"), e.removeClass("syno-sds-fs-large-thumb-height"), t >= i ? e.addClass("syno-sds-fs-large-thumb-width") : e.addClass("syno-sds-fs-large-thumb-height")
    },
    getThumbSize: function() {
        return this.thumbSize
    },
    changeThumbSize: function(e, t) {
        var i = this;
        switch (e.removeClass(i.largeThumbCls), e.removeClass(i.smallThumbCls), t) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
                e.addClass(i.smallThumbCls), i.thumbSize = SYNO.webfm.utils.ThumbSize.SMALL;
                break;
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                i.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM;
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                e.addClass(i.largeThumbCls), i.thumbSize = SYNO.webfm.utils.ThumbSize.LARGE;
                break;
            default:
                i.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM
        }
    }
}), Ext.define("SYNO.FileStation.ImageLoader", {
    extend: "Ext.Component",
    maxImageRequest: 24,
    constructor: function() {
        this.imageQueue = [], this.imageToDoQueue = [], this.callParent(arguments)
    },
    getTask: function() {
        return this.actionTask = this.actionTask || this.addTask({
            id: "task_set_image",
            interval: 17,
            run: this.setImage,
            scope: this
        }), this.actionTask
    },
    addImage: function(e) {
        this.innerAddImage(e)
    },
    innerAddImage: function(e) {
        var t = this,
            i = t.imageToDoQueue,
            o = t.getTask(); - 1 === i.indexOf(e) && -1 === t.imageQueue.indexOf(e) && (i.push(e), !1 === o.running && o.restart(!0))
    },
    removeImage: function(e) {
        var t = this,
            i = t.imageQueue;
        0 !== i.length && -1 !== i.indexOf(e) && (i.remove(e), 0 === i.length && t.getTask().stop())
    },
    removeAll: function() {
        var e = this;
        e.imageQueue = [], e.imageToDoQueue = [], e.getTask().stop()
    },
    setImage: function() {
        var e, t = this,
            i = 0,
            o = t.imageToDoQueue.concat(t.imageQueue),
            n = Math.min(t.maxImageRequest, o.length),
            s = [];
        for (t.imageToDoQueue = [], i = 0; i < n; i++) e = o[i], !1 === t.fireEvent("setimage", e) && s.push(e);
        o.splice(0, n), o = o.concat(s), t.imageQueue = o, 0 === o.length && t.getTask().stop()
    },
    stop: function() {
        this.getTask().stop()
    },
    destroy: function() {
        var e = this;
        e.imageQueue = null, e.imageToDoQueue = null, e.actionTask && (e.actionTask = null), e.callParent(arguments)
    }
}), Ext.define("SYNO.FileStation.ThumbnailsView", {
    delay: 100,
    extend: "SYNO.FileStation.SelectAllDataView",
    ieMaxURLLength: 2048,
    shadowCls: "syno-sds-fs-thumb-shadow",
    defaultSupportExt: ["jpg", "jpeg", "jpe", "bmp", "png", "tif", "tiff", "gif", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "raw", "heic", "heif"],
    defaultSupportVideoExt: ["3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "mk3d", "mka", "mks", "m4a", "m4v", "mkv", "mp4", "mts", "m4p", "m4b", "m4r", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "flv", "f4v", "avi", "swf", "vdr", "iso"],
    constructor: function(e) {
        this.supportExt = SYNO.SDS.Config && SYNO.SDS.Config.FnMap ? SYNO.SDS.Config.FnMap["SYNO.SDS.PhotoViewer.Application"].config.fb_extern[0].file || this.defaultSupportExt : this.defaultSupportExt, e = e || {}, e = Ext.apply({
            loadingText: _WFT("common", "loading"),
            cls: "syno-sds-fs-thumbnailsView",
            region: "center",
            multiSelect: !0,
            autoScroll: !0,
            itemMarginWidth: 12,
            itemSelector: "div.thumb-wrap",
            disableTextSelect: !0,
            itemCls: ".syno-sds-fs-thumbnailsView .thumb-wrap",
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap" id="{[this.htmlEncode(values.file_id)]}" role="option" aria-haspopup="true">', '<div ext:qtip="{[this.getTooltip(values)]}" class="thumb">', '<div class="thumb-hover thumb-loading" externalcss="{[this.getExternalCSS(values)]}">', '<img defaulticon="{icon}" draggable="false" class="{[this.hasThumbnail(values)]}" thumbnails="{[this.getThumbnailURL(values)]}" src="{[this.getDefaultSrc()]}" isvideo="{[this.getVideoType(values)]}">', "</div>", "<span>{[this.htmlEncode(values.filename)]}</span>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>', {
                compiled: !0,
                disableFormats: !0,
                getThumbnailURL: this.getThumbnailURL.createDelegate(this),
                hasThumbnail: this.hasThumbnail.createDelegate(this),
                getVideoType: this.getVideoType.createDelegate(this),
                getDefaultSrc: this.getDefaultSrc.createDelegate(this),
                getExternalCSS: this.getExternalCSS.createDelegate(this),
                getTooltip: this.getTooltip.createDelegate(this),
                htmlEncode: Ext.util.Format.htmlEncode
            }),
            prepareData: function(e) {
                return Ext.isEmpty(e.icon) && (e.icon = SYNO.webfm.utils.getThumbName(e)), e
            }.createDelegate(this)
        }, e), this.thumbSizeManager = new SYNO.FileStation.ThumbnailSizeManager, this.imageLoader = new SYNO.FileStation.ImageLoader, this.callParent([e]), this.mon(this.imageLoader, "setimage", this.setImgURL, this)
    },
    onStoreLoad: function() {
        this.updateScrollbar(this.trackResetOnLoad), this.trackResetOnLoad = !0, this.fireEvent("afterUpdateScrollbar", this)
    },
    convertFileName: function(e, t) {
        var i = e.is_snapshot && e.is_btrfs_subvol,
            o = Ext.util.Format.htmlEncode(e.filename);
        return i ? (o = o.replace(/-/g, " "), o = o.substr(0, 14).replace(/\./g, "-") + o.substr(14, o.length).replace(/\./g, ":"), t && "" !== e.snapshot_desc && (o += Ext.util.Format.htmlEncode(" - " + e.snapshot_desc)), o) : o
    },
    getThumbnailSize: function(e) {
        var t = "small";
        switch (e) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                t = "medium";
                break;
            default:
                t = "small"
        }
        return t
    },
    getSizeNumber: function(e) {
        var t = 128;
        switch (e) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
                t = 64;
                break;
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                t = 128;
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                t = 256;
                break;
            default:
                t = 128
        }
        return t
    },
    resizeThumb: function(e) {},
    changeThumbSize: function(e) {
        this.thumbSizeManager.changeThumbSize(this.getEl(), e), this.onResize()
    },
    getTooltip: function(e) {
        var t = "{0}<br>{1}<br>{2}";
        return t = e.isdir ? String.format("{0}<br>{1}", _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        })) : String.format(t, _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("common", "common_filesize") + _T("common", "colon") + Ext.util.Format.fileSize(e.filesize)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        }))
    },
    afterRender: function() {
        this.callParent(arguments), this.mun(this.getTemplateTarget(), "click", this.onClick, this), this.on("flexcrollInitDone", function() {
            this.mon(this.el.child(".mcontentwrapper"), "click", this.onClick, this)
        }, this, {
            single: !0
        }), this.keys && (this.keymap = new Ext.KeyMap(this.getEl(), this.keys))
    },
    getDefaultSrc: function() {
        return this.defaultSrc = this.RELURL + "../../../scripts/ext-3/resources/images/default/s.gif", this.defaultSrc
    },
    isSupportExt: function(e) {
        var t = !1;
        return Ext.each(this.supportExt, function(i) {
            e === i && (t = !0)
        }, this), t
    },
    isSupportVideoExt: function(e) {
        var t = !1;
        return Ext.each(this.defaultSupportVideoExt, function(i) {
            e === i && (t = !0)
        }, this), t
    },
    getExternalCSS: function(e) {
        var t, i = this.getStore().getById(e.file_id),
            o = this.thumbSizeManager.getThumbSize();
        return SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && (t = this.owner.getExternIcon(i, this.getSizeNumber(o))) ? (e.iconObj = t, t.css ? t.css : "") : ""
    },
    hasThumbnail: function(e) {
        return "remotefail" === e.mountType ? "" : this.isSupportExt(e.type.toLowerCase()) || this.isSupportVideoExt(e.type.toLowerCase()) || this.isSupportPluginExt(e) ? this.shadowCls : ""
    },
    getVideoType: function(e) {
        return this.isSupportVideoExt(e.type.toLowerCase())
    },
    isSupportPluginExt: function(e) {
        var t = !1;
        return Ext.each(this.owner.externThumbnailExts, function(i) {
            try {
                if (i.checkFn(e) && !1 !== i.shadow) return t = !0, !1
            } catch (e) {
                return !1
            }
        }), t
    },
    getExtThumbnailURL: function(e, t) {
        var i = !1;
        return Ext.each(this.owner.externThumbnailExts, function(o) {
            try {
                if (o.checkFn(e)) return i = o.getFn(t), !1
            } catch (e) {
                return !0
            }
        }), i
    },
    getDefaultIcon: function(e) {
        var t = window.location.pathname,
            i = "";
        return i = _S("standalone") && t ? t + "webman/modules/FileBrowser/" : "/webman/modules/FileBrowser/", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i + "images/{1}/files_ext_256/" + e, "FileType", !0)
    },
    getThumbnailURL: function(e) {
        var t = this.getDefaultIcon(e.icon),
            i = this.isSupportVideoExt(e.type.toLowerCase()),
            o = t,
            n = {
                path: Ext.encode(e.path),
                mt: e.mt
            };
        return "remotefail" === e.mountType ? this.getDefaultIcon("remotefailmountpoint.png") : !1 !== (o = this.getExtThumbnailURL(e, n)) ? o : SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && e.iconObj && e.iconObj.url ? e.iconObj.url : ((this.isSupportExt(e.type.toLowerCase()) || i) && (o = Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.FileStation.Thumb", "get", 2), Ext.urlEncode(n))), SYNO.webfm.VFS.isVFSPath(this.owner.getCurrentDir()) || o.length > this.ieMaxURLLength ? t : o)
    },
    removeListeners: function(e) {
        Ext.get(e).removeAllListeners()
    },
    onImageLoad: function(e, t, i) {
        var o = Ext.get(t);
        o.parent().removeClass("thumb-loading"), o.parent().addClass(Ext.fly(t).parent().getAttribute("externalcss")), this.resizeThumb(o), o.addClass("fadein")
    },
    onImageError: function(e) {
        var t = e.getAttribute("defaulticon"),
            i = this.getDefaultIcon(t),
            o = Ext.get(e);
        o.removeClass(this.shadowCls), o.on("error", this.setDefaultIcon, this), e.src = i, e.loaded = void 0
    },
    onImageLoadEvent: function(e) {
        Ext.get(e).on("load", this.onImageLoad, this)
    },
    setDefaultIcon: function(e, t, i) {
        var o = this.getDefaultIcon("misc.png"),
            n = Ext.get(t);
        n.removeClass(this.shadowCls), this.onImageLoadEvent(t), t.src = o, n.un("error", this.setDefaultIcon, this)
    },
    errorHandler: function(e, t, i) {
        this.onImageError(t)
    },
    setImgURL: function(e) {
        var t, i, o, n, s = this.thumbSizeManager.getThumbSize();
        this.all.each(function(o) {
            if (o.id === e) return t = o, i = t.select("img"), !1
        }, this), i && i.elements.length > 0 && (o = i.elements[0], n = o.getAttribute("thumbnails"), this.onImageLoadEvent(o), "false" === n ? this.errorHandler(null, o) : (Ext.fly(o).on("error", this.errorHandler, this), "true" == o.getAttribute("isvideo") && (s = SYNO.webfm.utils.ThumbSize.LARGE), o.src = Ext.urlAppend(n, "size=" + this.getThumbnailSize(s))), o.loaded = s)
    },
    onLoadItem: function(e) {
        var t, i = e.select("img"),
            o = this.thumbSizeManager.getThumbSize();
        i.elements.length > 0 && (t = i.elements[0], t.loaded !== o && t.loaded !== SYNO.webfm.utils.ThumbSize.LARGE ? this.imageLoader.addImage(e.id) : this.resizeThumb(Ext.fly(t)))
    },
    onUnLoadItem: function(e) {
        this.imageLoader.removeImage(e.id)
    },
    removeEvents: function() {
        var e = this.getTemplateTarget();
        if (e)
            for (var t = Ext.query(".thumb-hover img", e.dom), i = 0; i < t.length; i++) this.removeListeners(t[i])
    },
    refresh: function() {
        this.removeEvents(), this.imageLoader.removeAll(), this.callParent(arguments)
    },
    destroy: function() {
        this.removeEvents(), this.imageLoader.destroy(), this.callParent(arguments)
    }
}), Ext.define("SYNO.FileStation.FolderSharingThumbnailsView", {
    extend: "SYNO.FileStation.ThumbnailsView",
    getExternalCSS: function() {
        return ""
    },
    getThumbnailURL: function(e) {
        var t = this.getDefaultIcon(e.icon),
            i = this.isSupportVideoExt(e.type.toLowerCase());
        if ("remotefail" === e.mountType) return this.getDefaultIcon("remotefailmountpoint.png");
        if (e.iconObj && e.iconObj.url) return e.iconObj.url;
        var o = this.isSupportExt(e.type.toLowerCase()) || i ? Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.FolderSharing.Thumb", "get", 2), Ext.urlEncode({
            path: Ext.encode(e.path),
            mt: e.mt,
            _sharing_id: Ext.encode(this.folderSharingURL)
        })) : t;
        return o.length > this.ieMaxURLLength ? t : o
    }
}), Ext.define("SYNO.FileStation.ColumnView", {
    extend: "SYNO.FileStation.SelectAllDataView",
    constructor: function(e) {
        var t = {
            loadingText: _WFT("common", "loading"),
            cls: "syno-sds-fs-columnView",
            multiSelect: !0,
            disableTextSelect: !0,
            itemSelector: "div.file-wrap",
            tpl: this.getColumnViewTemplate()
        };
        this.callParent([Ext.apply(t, e)])
    },
    getColumnViewTemplate: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="file-wrap" id="{[this.htmlEncode(values.file_id)]}" role="option" aria-haspopup="true">', '<div class="webfm-file-type-icon {[this.getClass(values)]}"', ' ext:qtip="{[this.getTooltip(values)]}"', ' style="background:url({[this.getIconUrl(values)]}) no-repeat; background-size: 16px 16px;\tbackground-position: 5px 0;"/>', "{[this.htmlEncode(values.filename)]}", "</div>", "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            htmlEncode: Ext.util.Format.htmlEncode,
            getTooltip: this.getTooltip.createDelegate(this),
            getClass: this.getClass.createDelegate(this),
            getIconUrl: this.getIconUrl.createDelegate(this)
        })
    },
    getTemplateTarget: function() {
        var e = this;
        if (e.el.dom) return e.scrollBar = e.scrollBar || e.el.createChild({
            tag: "div",
            style: "display: inline-flex; flex-wrap: wrap; flex-direction: column; height: 100%;"
        }), e.scrollBar
    },
    updateScrollbar: function() {
        this.scrollBar && (this.scrollBar.removeClass("ellipsis"), this.scrollBar.setWidth("auto"), this.scrollBar.setWidth(this.scrollBar.dom.scrollWidth), this.scrollBar.addClass("ellipsis")), this.callParent(arguments)
    },
    onUpdateScrollbar: function(e) {
        var t = this;
        if (t.isVisible()) {
            var i = t.el.dom;
            i && i.fleXcroll ? (e && i.fleXcroll.setScrollPos(0, 0), i.fleXcroll.updateScrollBars(), e || i.fleXcroll.setScrollPos(0, 0, !0)) : i && (fleXenv.fleXcrollMain(i, this.disableTextSelect), i.onfleXcroll = function() {
                t.isVisible() && t.onUpdateView && t.onUpdateView(), this.fireEvent("flexcroll", this, this.getFleXcrollInfo(t.el.dom))
            }.createDelegate(this), i.fleXcroll && this.fireEvent("flexcrollInitDone")), i = null
        }
    },
    onStoreLoad: function() {
        this.updateScrollbar(this.trackResetOnLoad), this.trackResetOnLoad = !0, this.fireEvent("afterUpdateScrollbar", this)
    },
    afterRender: function() {
        this.callParent(arguments), this.mun(this.getTemplateTarget(), "click", this.onClick, this), this.on("flexcrollInitDone", function() {
            this.mon(this.el.child(".mcontentwrapper"), "click", this.onClick, this)
        }, this, {
            single: !0
        }), this.keys && (this.keymap = new Ext.KeyMap(this.getEl(), this.keys))
    },
    getThumbnailRowNum: function(e) {
        var t = e.getTemplateTarget(),
            i = e.selected.elements[0].getHeight();
        return Math.floor(t.getHeight() / i)
    },
    onKeyUp: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this;
        e.shiftKey ? t.selectPreItemIn() : t.selectPreItem()
    },
    onKeyDown: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this;
        e.shiftKey ? t.selectNextItemIn() : t.selectNextItem()
    },
    onKeyRight: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this,
            i = t.getThumbnailRowNum(t);
        e.shiftKey ? t.selectNextRowItemIn(i) : t.selectNextRowItem(i)
    },
    onKeyLeft: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this,
            i = t.getThumbnailRowNum(t);
        e.shiftKey ? t.selectPreRowItemIn(i) : t.selectPreRowItem(i)
    },
    getTooltip: function(e) {
        var t = "{0}<br>{1}<br>{2}";
        return t = e.isdir ? String.format("{0}<br>{1}", _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        })) : String.format(t, _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("common", "common_filesize") + _T("common", "colon") + Ext.util.Format.fileSize(e.filesize)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        }))
    },
    getClass: function(e) {
        var t, i = this.getStore().getById(e.file_id);
        return "remotefail" !== e.mountType && SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && (t = this.owner.getExternIcon(i)) ? t.css : ""
    },
    getIconUrl: function(e) {
        var t, i = Ext.isEmpty(e.icon) ? SYNO.webfm.utils.getThumbName(e) : e.icon,
            o = this.getStore().getById(e.file_id),
            n = window.location.pathname,
            s = "";
        s = _S("standalone") && n ? ("/index.cgi" === n ? "/" : n) + "webman/modules/FileBrowser/" : "/webman/modules/FileBrowser/", "remotefail" === e.mountType && (i = "remotefailmountpoint.png");
        var r = SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(s + "images/{1}/files_ext/" + i, "Desktop", !0);
        return "remotefail" !== e.mountType && SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && (t = this.owner.getExternIcon(o)) ? t.url || r : r
    }
}), Ext.define("SYNO.FileStation.BlobDownloadMgr", {
    extend: Ext.util.Observable,
    constructor: function(e) {
        this.callParent(arguments), Ext.apply(this, e || {}), this.tasks = new Map, this.downloader = [], this.taskDownloadingIndex = 0, this.blDownloading = !1, this.initDownloader()
    },
    getTaskSize: function() {
        return this.tasks ? this.tasks.size : 0
    },
    getDownloadingTaskIndex: function() {
        return this.taskDownloadingIndex
    },
    pauseDownloadTask: function(e) {
        if (e && this.downloader.dlWriter.cleanFileSystem(), this.blDownloading) {
            var t = _WFT("filetable", "filetable_download") || "",
                i = _WFT("filetable", "download_paused") || "";
            this.webfm.getDownloadInstance().onPause({
                id: this.currentTask.hash_id,
                name: this.currentTask.get("filename"),
                progress: 0,
                status: "PAUSE"
            }), this.downloader.pause(e), SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.App.FileStation3.Instance", t, i)
        }
    },
    resumeDownloadTask: function() {
        this.blDownloading && (this.webfm.getDownloadInstance().onResume({
            id: this.currentTask.hash_id,
            name: this.currentTask.get("filename"),
            progress: 0,
            status: "PROCESSING"
        }), this.downloader.resume())
    },
    addDownloadTask: function(e, t) {
        Ext.isArray(e) || (e = [e]);
        var i = this;
        Ext.each(e, function(e) {
            var o = e.get("filename"),
                n = e.get("file_id");
            e.url = i.getDownloadURL(o, n, e, t), e.dl_id = SYNO.webfm.utils.bin2hex(n), e.hash_id = i.getTaskSize(), e.status = "NOT_STARTED", i.tasks.set(i.getTaskSize(), e), i.webfm.getDownloadInstance().onSelect({
                id: e.hash_id,
                name: o,
                starttime: (new Date).getTime() / 1e3
            })
        }), this.downloadNext()
    },
    removeDownloadTask: function(e) {
        var t = this.tasks.get(e);
        Ext.isEmpty(t) || ("PROCESSING" === t.status && (this.downloader.abort(), this.blDownloading = !1, this.downloadNext()), t.status = "CANCEL")
    },
    initDownloader: function() {
        this.webfm.initInstanceFunc(), this.webfm.getDownloadInstance().on("cancel", this.removeDownloadTask, this), this.downloader = new SYNO.FileStation.BlobDownloader({
            webfm: this.webfm,
            downloadMgr: this
        }), this.downloader.on("onBeforeStart", this.onBeforeStartTask, this), this.downloader.on("onProgress", this.onProgressTask, this), this.downloader.on("onFinish", this.onFinishTask, this), this.downloader.on("onError", this.onErrorTask, this)
    },
    downloadNext: function() {
        if (!this.blDownloading) {
            var e, t, i = this.getTaskSize();
            for (t = this.taskDownloadingIndex; t < i; t++)
                if (e = this.tasks.get(t), this.currentTask = e, this.taskDownloadingIndex++, e && "NOT_STARTED" === e.status) {
                    this.blDownloading = !0, e.status = "PROCESSING", this.downloader.download(e);
                    break
                } t >= i && this.webfm.getDownloadInstance().onAllComplete()
        }
    },
    onBeforeStartTask: function(e) {
        return !0
    },
    onProgressTask: function(e, t, i) {
        if (!this.downloader.blPaused) {
            var o = {};
            o.id = e.hash_id, o.name = e.get("filename"), o.progress = t, o.byteswrite = i, o.bytestotal = e.data.filesize, o.taskInfo = {
                progress: t,
                complete: i === e.get("filesize")
            }, this.webfm.getDownloadInstance().onProgressWithTime(o)
        }
    },
    onFinishTask: function(e, t) {
        e.status = "SUCCESS", this.webfm.getDownloadInstance().onComplete({
            id: e.hash_id
        }), this.blDownloading = !1, this.downloadNext.defer(500, this)
    },
    onErrorTask: function(e, t) {
        e.status = "FAIL", this.webfm.getDownloadInstance().onError({
            id: e.hash_id,
            response: this.getErrorObj(t)
        }), this.blDownloading = !1, this.downloadNext()
    },
    getErrorObj: function(e) {
        var t = {
            errno: {
                section: "common",
                key: "commfail"
            }
        };
        return "FileTooBigError" === e ? (t.errno.section = "filetable", t.errno.key = "filetable_download_file_toobig") : "QuotaExceededError" === e && (t.errno.section = "filetable", t.errno.key = "filetable_download_quota_exceed"), SYNO.Debug.error(e), t
    },
    getDownloadURL: function(e, t, i, o) {
        var n, s, r = SYNO.webfm.utils.replaceDLNameSpecChars(e);
        return Ext.isDefined(o) ? ((r.length <= o.length || -1 === r.toLowerCase().indexOf("." + o, r.length - o.length - 1)) && (r += "." + o), n = "fbgdrivedownload", s = String.format("/" + n + '/{0}?dlink="{1}"', encodeURIComponent(r), SYNO.webfm.utils.bin2hex(t)), s += "&noCache=" + (new Date).getTime() + "&mode=download&stdhtml=true&format=" + o) : (n = "fbdownload", s = String.format("/" + n + '/{0}?dlink="{1}"', encodeURIComponent(r), SYNO.webfm.utils.bin2hex(t)), s += "&noCache=" + (new Date).getTime() + "&mode=download&stdhtml=true"), s = Ext.urlAppend(s), i.get("isdir") || "exe" !== i.get("type").toLowerCase() || (s += "&f=.exe"), s
    },
    destroy: function() {
        this.downloader && (this.downloader.destroy(), this.downloader = null)
    }
}), Ext.define("SYNO.FileStation.BlobDownloader", {
    extend: Ext.util.Observable,
    maxChunkSize: 16777216,
    dlWriter: null,
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments), this.initDownloader(), this.chunks = [], this.blPaused = !1, this.addEvents("onProgress", "onFinish", "onError")
    },
    initDownloader: function() {
        SYNO.webfm.utils.isSupportFileSystem() ? this.dlWriter = new SYNO.FileStation.FSDLWriter({
            downloader: this
        }) : this.dlWriter = new SYNO.FileStation.MemDLWriter({
            downloader: this
        }), this.dlWriter.on("onSetup", this.onWriterSetup, this), this.dlWriter.on("onWriteEnd", this.onWriteEnd, this), this.dlWriter.on("onError", this.onError, this)
    },
    download: function(e) {
        if (this.task = e, !this.checkTask()) return void this.fireEvent("onError", this.task, "FileTooBigError");
        this.currentChunkIndex = 0, this.dlWriter.reset(this.task)
    },
    downloadNextChunk: function() {
        if (this.currentChunkIndex >= this.chunks.length && 0 < this.chunks.length) return this.saveAs(), void this.fireEvent("onFinish", this.task);
        var e = this.chunks[this.currentChunkIndex];
        e && e.download()
    },
    pause: function(e) {
        this.blPaused = !0, e && (this.abort(), this.dlWriter.reset(this.task))
    },
    resume: function() {
        this.blPaused = !1, this.downloadNextChunk()
    },
    abort: function() {
        if (!(this.currentChunkIndex > this.chunks.length)) {
            var e = this.chunks[this.currentChunkIndex];
            e && e.abort(), this.cleanChunks(), this.dlWriter.cleanFile()
        }
    },
    initTaskChunks: function() {
        this.cleanChunks();
        var e = 0,
            t = 0,
            i = this.task.get("filesize");
        for (this.currentChunkIndex = 0; t < i || 0 === e;) {
            var o = t + this.maxChunkSize;
            o = o > i ? i : o;
            var n = new SYNO.FileStation.DLChunk({
                chunk_id: e,
                url: this.task.url,
                startRange: t,
                endRange: o,
                downloader: this
            });
            this.chunks.push(n), t = o + 1, e++
        }
    },
    getMaxDownloadSize: function() {
        return Ext.isChrome ? 10632560640 : Ext.isGecko || Ext.isGecko2 || Ext.isGecko3 ? 1073741824 : Ext.isModernIE ? 134217728 : 0
    },
    checkTask: function() {
        return !(this.task.get("filesize") > this.getMaxDownloadSize())
    },
    onWriterSetup: function() {
        this.initTaskChunks(), this.blPaused || this.downloadNextChunk()
    },
    onWriteEnd: function() {
        this.currentChunkIndex++, this.blPaused || this.downloadNextChunk()
    },
    onChunkFinish: function(e, t) {
        var i = this.chunks[e].startRange;
        this.dlWriter.write(t, i), this.chunks[e].onDestroy(), delete this.chunks[e], this.chunks[e] = null
    },
    onProgress: function(e, t) {
        var i = e.startRange + t.loaded,
            o = i / this.task.get("filesize") * 100;
        this.fireEvent("onProgress", this.task, o, i)
    },
    onError: function(e, t) {
        this.cleanChunks(), this.dlWriter.cleanFile(), this.fireEvent("onError", this.task, t)
    },
    saveAs: function() {
        this.cleanChunks(), this.dlWriter.saveAs(this.task.get("filename"))
    },
    cleanChunks: function() {
        var e = 0;
        for (e = 0; e < this.chunks.length; e++) this.chunks[e] && (this.chunks[e].onDestroy(), delete this.chunks[e], this.chunks[e] = null);
        this.chunks = []
    },
    destroy: function() {
        this.dlWriter && (this.dlWriter.destroy(), this.dlWriter = null)
    }
}), Ext.define("SYNO.FileStation.DLChunk", {
    extend: Ext.util.Observable,
    startRange: 0,
    endRange: 0,
    url: "",
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments), this.initChunk()
    },
    initChunk: function() {
        try {
            this.xhr = new XMLHttpRequest, Ext.EventManager.on(this.xhr, "progress", this.onProgress, this), Ext.EventManager.on(this.xhr, "load", this.onFinish, this), Ext.EventManager.on(this.xhr, "error", this.onError, this)
        } catch (e) {
            SYNO.Debug.error("Faile to init xhr"), SYNO.Debug.error(e)
        }
    },
    download: function() {
        try {
            var e = "bytes=" + this.startRange + "-" + this.endRange;
            this.xhr.open("GET", this.url, !0), 0 < this.endRange && this.xhr.setRequestHeader("Range", e), this.xhr.responseType = "arraybuffer", this.xhr.send(null)
        } catch (e) {
            this.downloader.onError(this, e)
        }
    },
    abort: function() {
        try {
            this.xhr.abort()
        } catch (e) {
            SYNO.Debug.error("Failed to abort xhr")
        }
        this.onDestroy()
    },
    onProgress: function(e) {
        this.downloader.onProgress(this, e.browserEvent)
    },
    onFinish: function(e) {
        try {
            e.target.status >= 200 && e.target.status < 300 ? this.downloader.onChunkFinish(this.chunk_id, e.target.response) : this.downloader.onError(this, e.target.status)
        } catch (e) {
            SYNO.Debug.error(e), this.downloader.onError(this, e)
        }
        this.onDestroy()
    },
    onError: function(e) {
        this.downloader.onError(this, e), this.onDestroy()
    },
    onDestroy: function() {
        this.purgeListeners(), Ext.EventManager.un(this.xhr, "progress", this.onProgress, this), Ext.EventManager.un(this.xhr, "load", this.onFinish, this), Ext.EventManager.un(this.xhr, "error", this.onError, this), this.xhr = null
    }
}), Ext.define("SYNO.FileStation.DLWriter", {
    extend: Ext.util.Observable,
    file: null,
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments), this.save_link = document.createElementNS("http://www.w3.org/1999/xhtml", "a"), this.addEvents("onSetup", "onWriteEnd", "onError", "onFSClean")
    },
    reset: function(e) {
        return !0
    },
    write: function(e) {
        return !0
    },
    saveAs: function(e) {
        return !0
    },
    cleanFile: function() {
        return !0
    },
    downloadAsLink: function(e, t) {
        var i = this;
        this.save_link.href = e, this.save_link.download = t;
        var o = function(e) {
                var t = new MouseEvent("click");
                e.dispatchEvent(t)
            },
            n = function(e) {
                var t = function() {
                    window.URL.revokeObjectURL(e), e = null
                };
                Ext.isChrome ? (window.URL.revokeObjectURL(e), e = null) : setTimeout(t, 500)
            };
        setTimeout(function() {
            o(i.save_link), n(e)
        })
    },
    destroy: function() {
        return !0
    }
}), Ext.define("SYNO.FileStation.FSDLWriter", {
    extend: "SYNO.FileStation.DLWriter",
    internal_writer: null,
    reqMaxSize: 10737418240,
    marginSize: 104857600,
    maxRetryTimes: 20,
    folderName: "filestation",
    downloadingPrefix: "._SYNODownloading_",
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments), this.cleanFileSystem(), this.retryTimes = 0, this.on("onFSClean", this.onFSClean, this)
    },
    queryStorageQuota: function() {
        var e = this,
            t = e.filesize;
        navigator.webkitTemporaryStorage.queryUsageAndQuota(function(i, o) {
            i + t > o - e.marginSize ? navigator.webkitPersistentStorage.requestQuota(e.reqMaxSize, function(i) {
                t > i - e.marginSize ? e.fireEvent("onError", "FileTooBigError") : e.setupWriter(window.PERSISTENT)
            }, e.fsError.bind(e, "request-PERSISTENT")) : e.setupWriter(window.TEMPORARY)
        }, e.fsError.bind(e, "request-TEMPORARY"))
    },
    setupWriter: function(e) {
        var t = this;
        (window.requestFileSystem || window.webkitRequestFileSystem)(e, t.reqMaxSize, function(e) {
            e.root.getDirectory(t.folderName, {
                create: !0
            }, function(e) {
                var i = encodeURIComponent(t.downloadingPrefix + t.filename + "_" + (new Date).getTime()),
                    o = function() {
                        e.getFile(i, {
                            create: !0
                        }, function(e) {
                            t.file = e, e.createWriter(function(e) {
                                t.internal_writer = e, t.internal_writer.onwriteend = function() {
                                    t.blError || (t.retryTimes = 0, t.buffer = null, t.fireEvent("onWriteEnd"))
                                }, t.internal_writer.onerror = function(e) {
                                    t.blError = !0, t.maxRetryTimes <= t.retryTimes++ ? (SYNO.Debug.error(e), t.fireEvent("onError", void 0, "WriteError")) : (SYNO.Debug("Retry:" + t.retryTimes), t.write.defer(3e3 * t.retryTimes, t))
                                }, t.fireEvent("onSetup")
                            }, t.fsError.bind(t, "createWriter"))
                        }, t.fsError.bind(t, "getFile"))
                    };
                e.getFile(i, {
                    create: !1
                }, function(e) {
                    e.remove(Ext.emptyFn), o()
                }, function(e) {
                    "NotFoundError" === e.name ? o() : t.fsError(e)
                })
            }, t.fsError.bind(t, "setupWriter-getDirectory"))
        }, t.fsError.bind(t, "setupWriter-requestFileSystem"))
    },
    cleanFS: function(e) {
        var t = this;
        (window.requestFileSystem || window.webkitRequestFileSystem)(e, t.reqMaxSize, function(i) {
            i.root.getDirectory(t.folderName, {
                create: !0
            }, function(i) {
                var o = function() {
                    window.TEMPORARY === e && t.cleanFS(window.PERSISTENT)
                };
                i.removeRecursively(o, o)
            }, Ext.emptyFn)
        }, t.fsError.bind(t, "cleanFileSystem-requestFileSystem"))
    },
    cleanFileSystem: function() {
        this.cleanFS(window.TEMPORARY)
    },
    reset: function(e) {
        this.retryTimes = 0, this.buffer = null, this.blError = !1, this.filesize = e.get("filesize"), this.filename = e.get("filename"), this.dl_id = e.dl_id, this.cleanFile(), this.queryStorageQuota.defer(500, this)
    },
    write: function(e, t) {
        e && (this.buffer = e, this.position = t), this.internal_writer && this.buffer || this.fireEvent("onError"), this.blError && (this.internal_writer.seek(this.position), this.blError = !1), this.internal_writer.write(new Blob([this.buffer]))
    },
    saveAs: function(e) {
        var t = this.file.toURL();
        this.downloadAsLink(t, e)
    },
    fsError: function(e, t) {
        Ext.isEmpty(e) || SYNO.Debug.error(e), Ext.isEmpty(t) || SYNO.Debug.error(t.name + ": " + t.message), this.fireEvent("onError", void 0, t.name)
    },
    cleanFile: function() {
        if (this.file) {
            var e = this.file;
            this.file = null, setTimeout(function() {
                e.remove(Ext.emptyFn)
            }, 3e3)
        }
    },
    destroy: function() {
        this.cleanFileSystem(), this.purgeListeners(), this.internal_writer = null
    }
}), Ext.define("SYNO.FileStation.MemDLWriter", {
    extend: "SYNO.FileStation.DLWriter",
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments), this.file = []
    },
    reset: function(e) {
        this.cleanFile(), this.filesize = e.get("filesize"), this.filename = e.get("filename"), this.dl_id = e.dl_id, this.fireEvent("onSetup")
    },
    write: function(e) {
        this.file.push(new Blob([e])), this.fireEvent("onWriteEnd"), e = null
    },
    saveAs: function(e) {
        if (!Ext.isEmpty(this.file)) try {
            var t = new Blob(this.file);
            if (Ext.isModernIE) navigator.msSaveOrOpenBlob(t, e);
            else {
                var i = window.URL.createObjectURL(t);
                this.downloadAsLink(i, e)
            }
            this.cleanFile()
        } catch (e) {
            this.fireEvent("onError", e)
        }
    },
    cleanFile: function() {
        var e = 0;
        for (e = 0; e < this.file.length; e++) this.file[e] && (delete this.file[e], this.file[e] = null);
        this.file = []
    }
}), Ext.ns("SYNO.SDS.App.FileStation3"), SYNO.SDS.App.FileStation3 = Ext.extend(SYNO.SDS.AppWindow, {
    notifyArr: [],
    constructor: function(e) {
        SYNO.SDS.App.FileStation3.superclass.constructor.call(this, Ext.apply({
            monitorResize: !0,
            showHelp: !0,
            width: 1010,
            height: 566,
            minWidth: 1010,
            minHeight: 566,
            boxMinHeight: 566,
            boxMinWidth: 1010,
            closable: !0,
            minimizable: !0,
            maximizable: !0,
            resizable: !0,
            autoScroll: !1,
            layout: "fit",
            dsmStyle: "v5",
            cls: "syno-sds-fs-win",
            listeners: {
                show: {
                    fn: function() {
                        this.onAfterShow()
                    },
                    scope: this
                },
                beforeclose: {
                    fn: function() {
                        this.panelObj.beforeClose()
                    },
                    scope: this
                },
                close: {
                    fn: function() {
                        this.appInstance.setUserSettings("activeViewItemId", this.panelObj.getCurrentViewItemId()), this.appInstance.setUserSettings("activeViewSize", this.panelObj.getCurrentViewSize()), this.appInstance.setUserSettings("treePanelWidth", this.panelObj.navLayout.getWidth()), this.sendFileTaskNotify(!0)
                    },
                    scope: this
                }
            }
        }, e)), this.shouldCreatePanel = !0
    },
    initPanel: function() {
        this.createPanels(), this.add(this.panelObj), this.doLayout(), this.getEl().unmask();
        var e = new SYNO.FileStation.SearchHistoryPanel({
            webfm: this.panelObj
        });
        this.panelObj.historyPanel = e, this.addManagedComponent(e);
        var t = new SYNO.FileStation.SearchFormPanel({
            cls: "syno-sds-fs-search-panel",
            renderTo: Ext.getBody(),
            shadow: !1,
            jsConfig: this.jsConfig,
            RELURL: this.jsConfig.jsBaseURL + "/",
            webfm: this.panelObj,
            hidden: !0,
            owner: this
        });
        this.panelObj.searchPanel = t, this.bindEvents(t), this.bindClickEvents(), this.panelObj.blShown = !0, this.addManagedComponent(t), this.fireEvent("onContentReady")
    },
    bindClickEvents: function() {
        var e = this.panelObj;
        e.viewPanel.el.on("click", function(t) {
            "fileGrid" === e.activeView.itemId && t.target.classList.contains("webfm-listview-grid-panel") && e.grid.getSelectionModel().clearAllSelections()
        })
    },
    onGetPortalURLDone: function(e, t) {
        !0 === e && (this.curPortalUrl = t)
    },
    getPortalUrlTask: function() {
        SYNO.SDS.QuickConnect.Utils.getPortalUrl(SYNO.SDS.QuickConnect.Utils.TYPES.DIRECT, this.onGetPortalURLDone, this)
    },
    onAfterShow: function() {
        this.shouldCreatePanel && (this.getEl().mask(_WFT("common", "loading"), "x-mask-loading"), this.initPanel.defer(100, this), this.shouldCreatePanel = !1), this.panelObj && (this.panelObj.blShown = !0), SYNO.SDS.UserSettings.load(), this.getPortalUrlTask()
    },
    createPanels: function() {
        var e = new SYNO.FileStation.WindowPanel({
            region: "center",
            appInstance: this.initialConfig.appInstance,
            appWindow: this,
            jsConfig: this.jsConfig,
            RELURL: this.jsConfig.jsBaseURL + "/",
            owner: this
        });
        e.registerOwner(this), e.registerFileAction(), this.panelObj = e
    },
    bindEvents: function(e) {
        var t = 0,
            i = ["maximize", "minimize"],
            o = function() {
                e.hide()
            };
        for (Ext.EventManager.on(window, "unload", function() {
                this.sendFileTaskNotify(!1), e.onCleanSearch(!1)
            }, this), SYNO.SDS.StatusNotifier.on("logout", function() {
                this.sendFileTaskNotify(!1), e.onCleanSearch(!1)
            }, this), t = 0; t < i.length; t++) e.mon(this, i[t], o, e)
    },
    sendFileTaskNotify: function(e, t) {
        var i = e && Ext.isDefined(t) ? "one" : "all";
        SYNO.API.Request({
            api: "SYNO.FileStation.Notify",
            method: i,
            version: 1,
            async: e,
            timeout: e ? 3e3 : 1e3,
            params: {
                taskid: t
            }
        })
    },
    FileTaskNotify: function(e, t) {
        var i = e ? "one" : "all";
        SYNO.API.Request({
            api: "SYNO.FileStation.Notify",
            method: i,
            version: 1,
            async: e,
            timeout: e ? 3e3 : 1e3,
            params: {
                taskid: t
            }
        })
    },
    getPanelInstance: function() {
        return this.panelObj
    },
    onOpen: function(e) {
        SYNO.SDS.App.FileStation3.superclass.onOpen.apply(this, arguments), this.onOpenDir(e)
    },
    onRequest: function(e) {
        SYNO.SDS.App.FileStation3.superclass.onRequest.apply(this, arguments), this.onOpenDir(e)
    },
    onOpenDir: function(e) {
        if (e && e.opendir ? this.panelObj ? this.panelObj.onGoToFolder(e.opendir) : this.mon(this, "onContentReady", function() {
                this.panelObj.onGoToFolder(e.opendir)
            }, this, {
                single: !0
            }) : e && e.openfile && (this.panelObj ? this.panelObj.onGoToFile(e.openfile) : this.mon(this, "onContentReady", function() {
                if (e._sharing_id) {
                    var t = e._sharing_id.replace(/"/g, "");
                    this.sendWebAPI({
                        api: "SYNO.FolderSharing.List",
                        method: "list",
                        version: 2,
                        params: {
                            _sharing_id: t,
                            user: _S("user")
                        },
                        callback: function(e, t) {
                            e && this.panelObj.onGoToFile(t.path)
                        },
                        scope: this
                    })
                } else this.panelObj.onGoToFile(e.openfile)
            }, this, {
                single: !0
            })), e && e.windowState) this.panelObj ? this.restoreViewMode(e.windowState) : this.mon(this, "onContentReady", function() {
            this.restoreViewMode(e.windowState)
        });
        else {
            var t = {
                activeViewItemId: this.appInstance.getUserSettings("activeViewItemId"),
                activeViewSize: this.appInstance.getUserSettings("activeViewSize")
            };
            this.panelObj ? this.restoreViewMode(t) : this.mon(this, "onContentReady", function() {
                this.restoreViewMode(t)
            })
        }
    },
    restoreViewMode: function(e) {
        var t, i, o = e.activeViewItemId,
            n = e.activeViewSize;
        "thumbnailView" === o && (o += n), "columnView" === o && Ext.isIE9m && (o = "fileGrid"), t = this.panelObj.btnViewMode, (i = t.menu.getComponent(o)) && i.fireEvent("click")
    },
    getStateParam: function() {
        var e = SYNO.SDS.App.FileStation3.superclass.getStateParam.apply(this, arguments);
        return this.panelObj ? (Ext.apply(e, {
            activeViewItemId: this.panelObj.getCurrentViewItemId(),
            activeViewSize: this.panelObj.getCurrentViewSize()
        }), e) : e
    },
    getGrid: function() {
        return this.panelObj.grid
    },
    onDestroy: function() {
        SYNO.SDS.App.FileStation3.superclass.onDestroy.apply(this, arguments), this.getGrid().dddrop.removeFromGroup(this.getGrid().ddGroup), Ext.iterate(this.panelObj.dataView, function(e, t) {
            this.panelObj.dataView[e].dddrop.removeFromGroup(this.panelObj.dataView[e].ddGroup)
        }, this)
    }
}), SYNO.SDS.App.FileStation3.Instance = Ext.extend(SYNO.SDS.AppInstance, {
    appWindowName: "SYNO.SDS.App.FileStation3"
}), Ext.define("SYNO.SDS.Snapshot.HistoryWindow", {
    extend: "SYNO.SDS.ModalWindow",
    SNAPSHOT_TOP_FOLDER: "#snapshot",
    constructor: function(e, t) {
        this.grid = this.initGrid(t), this.goBtn = new SYNO.ux.Button({
            text: _T("filebrowser", "snapshot_go"),
            scope: this,
            disabled: !0,
            btnStyle: "blue",
            handler: function() {
                var e = this.grid.selModel.getSelections();
                if (1 === e.length) {
                    var i, o = this.owner,
                        n = e[0].get("stime"),
                        s = t.data.path,
                        r = s.substring(1, s.length).split("/");
                    o.panelObj.dirTree.getNodeById("fm_root").reload(function() {
                        r.splice(1, 0, this.SNAPSHOT_TOP_FOLDER, n), i = "/" + r.join("/"), o.panelObj.onGoToFile(i), this.close()
                    }, this)
                }
            }
        });
        var i = {
            owner: e.owner,
            width: 420,
            title: _T("filebrowser", "view_snapshot_history"),
            closable: !0,
            layout: "fit",
            items: this.grid,
            buttons: [this.goBtn]
        };
        this.callParent([i]), this.mon(this.grid, "viewready", function() {
            this.grid.view.updateScroller()
        }, this)
    },
    initGrid: function(e) {
        return new SYNO.SDS.Snapshot.HistoryGrid({
            path: e.data.path
        })
    }
}), Ext.define("SYNO.SDS.Snapshot.HistoryGrid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.createStore(e), this.recPath = e.path;
        var t = function(e, t) {
                var i = SYNO.webfm.utils.DateTimeFormatter(new Date(e), {
                    type: "datetimesec"
                });
                return t.attr = 'ext:qtip="' + i + '"', i
            },
            i = function(e, t) {
                var i = Ext.util.Format.htmlEncode(SYNO.webfm.utils.snapshotTimeRenderer(e));
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
            },
            o = [{
                header: _T("filebrowser", "snapshot"),
                dataIndex: "stime",
                width: 180,
                renderer: i
            }, {
                header: _WFT("filetable", "filetable_mtime"),
                dataIndex: "mtime",
                id: "mtime",
                width: 220,
                renderer: t
            }],
            n = Ext.apply({
                title: _T("filebrowser", "snapshot"),
                layout: "fit",
                store: this.store,
                width: 400,
                autoExpandColumn: "mtime",
                colModel: new Ext.grid.ColumnModel({
                    defaults: {
                        align: "left"
                    },
                    columns: o
                }),
                selModel: new Ext.grid.RowSelectionModel({
                    singleSelect: !0
                }),
                listeners: {
                    cellclick: {
                        fn: function(e, t) {
                            e.ownerCt.goBtn.enable()
                        }
                    }
                },
                view: new SYNO.ux.FleXcroll.grid.BufferView({
                    rowHeight: 26,
                    borderHeight: 1,
                    cacheSize: 100,
                    forceFit: !0
                })
            }, e);
        this.callParent([n]), this.store.load({
            path: n.path,
            callback: this.onLoad,
            scope: this
        })
    },
    onLoad: function(e, t, i) {
        0 === e.length && this.mask(_T("filebrowser", "snapshot_no_history"))
    },
    createStore: function(e) {
        this.store = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.Snapshot",
                method: "history",
                version: 2
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                id: "mtime"
            }, [{
                name: "mtime"
            }, {
                name: "stime"
            }]),
            baseParams: {
                path: e.path
            }
        })
    }
});