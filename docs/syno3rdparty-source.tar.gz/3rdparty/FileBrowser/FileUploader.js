/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.FileStation"), SYNO.FileStation.UploadDialog = function(e) {
    Ext.apply(this, e || {});
    var t = this.init(),
        i = {
            owner: this.owner,
            width: 580,
            height: 450,
            shadow: !0,
            minWidth: 580,
            minHeight: 200,
            collapsible: !1,
            autoScroll: !1,
            constrainHeader: !0,
            plain: !0,
            title: _WFT("filetable", "filetable_upload"),
            layout: "fit",
            items: t,
            buttons: [{
                text: _WFT("common", "common_cancel"),
                scope: this,
                handler: this.closeHandler
            }, {
                btnStyle: "blue",
                text: _WFT("common", "common_submit"),
                scope: this,
                handler: this.submitForm
            }],
            keys: [{
                key: 27,
                fn: this.closeHandler,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: function() {
                        this.center()
                    },
                    scope: this,
                    single: !0
                },
                beforeshow: {
                    fn: function() {
                        this.reset(this.blDisableWriteOption), this.addUpFileForm()
                    },
                    scope: this
                }
            }
        };
    SYNO.FileStation.UploadDialog.superclass.constructor.call(this, i), this.upFormArr = []
}, Ext.extend(SYNO.FileStation.UploadDialog, SYNO.SDS.ModalWindow, {
    MaxUploadCount: 10,
    limitSize: 2147482624,
    parentDir: null,
    uploadCnt: 0,
    upFormArr: [],
    init: function() {
        var e = new SYNO.ux.FormPanel({
            autoFlexcroll: !1,
            trackResetOnLoad: !0,
            labelWidth: 200,
            defaults: {
                style: "padding-top: 10px"
            },
            items: [new SYNO.ux.CompositeField({
                name: "writestrategyComposite",
                fieldLabel: _WFT("filetable", "filetable_same_file"),
                items: [{
                    xtype: "syno_radio",
                    boxLabel: _WFT("filetable", "filetable_skip"),
                    name: "writestrategy",
                    inputValue: "skip",
                    width: 100,
                    checked: !0
                }, {
                    xtype: "syno_radio",
                    boxLabel: _WFT("filetable", "filetable_overwrite"),
                    name: "writestrategy",
                    inputValue: "overwrite",
                    width: 100
                }]
            })],
            listeners: {
                actionfailed: {
                    fn: this.closeHandler,
                    scope: this
                }
            }
        });
        this.writeStrategyForm = e;
        var t = _WFT("filetable", "filetable_select_max");
        t = t.replace("_MAXNO_", this.MaxUploadCount);
        var i = new Ext.Panel({
            border: !1,
            autoFlexcroll: !0,
            defaults: {
                border: !1,
                style: "padding-left: 38px; padding-top: 1px; font-size: 12px"
            },
            items: [new SYNO.ux.DisplayField({
                hideLabel: !0,
                autoScroll: !1,
                value: t
            }), this.writeStrategyForm]
        });
        return this.formContainer = i, i
    },
    addUpFileForm: function() {
        if (!(this.uploadCnt >= this.MaxUploadCount)) {
            this.uploadCnt++;
            var e = new Ext.form.Field({
                    synotype: "indent",
                    itemId: "file",
                    fieldLabel: _WFT("upload", "upload_file"),
                    name: "file",
                    hiddenName: "file",
                    hideLabel: !0,
                    value: "",
                    autoCreate: {
                        tag: "input",
                        type: "file",
                        size: "20",
                        autocomplete: "off"
                    }
                }),
                t = {
                    autoFlexcroll: !1,
                    url: this.UploadCGI,
                    labelWidth: 0,
                    labelAlign: "left",
                    fileUpload: !0,
                    trackResetOnLoad: !0,
                    border: !1,
                    items: [new Ext.form.Field({
                        inputType: "hidden",
                        value: "",
                        name: "overwrite",
                        hiddenName: "overwrite"
                    }), new Ext.form.Field({
                        inputType: "hidden",
                        value: "",
                        name: "taskid",
                        hiddenName: "taskid"
                    }), new Ext.form.Field({
                        inputType: "hidden",
                        value: "/AAtest",
                        name: "path",
                        hiddenName: "path"
                    }), new Ext.form.Field({
                        inputType: "hidden",
                        value: "/AAtest",
                        name: "uploader_name",
                        hiddenName: "uploader_name"
                    }), new Ext.form.Field({
                        inputType: "hidden",
                        value: "/AAtest",
                        name: "sharing_id",
                        hiddenName: "sharing_id"
                    }), {
                        xtype: "syno_compositefield",
                        fieldLabel: _WFT("upload", "upload_file"),
                        name: "fileComposite",
                        itemId: "fileComposite",
                        items: [e]
                    }]
                },
                i = new SYNO.ux.FormPanel(t);
            i.fileField = e, this.formContainer.add(i), this.formContainer.doLayout();
            var r = this.upFormArr.length;
            this.onFieldChangeFn = function() {
                this.onFieldChange(r)
            }, i.mon(e.getEl(), "change", this.onFieldChangeFn, this), this.upFormArr.push(i)
        }
    },
    closeHandler: function() {
        this.close()
    },
    testFile: function() {
        for (var e = 0, t = 0; t < this.upFormArr.length; t++) {
            var i = this.upFormArr[t].fileField.getValue();
            i = Ext.util.Format.trim(i), i && e++
        }
        return e
    },
    submitForm: function() {
        var e = 0;
        if (1 > (e = this.testFile())) return void this.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("filetable", "filetable_select_one"));
        var t = "overwrite" === this.writeStrategyForm.form.getValues().writestrategy;
        this.hide(), SYNO.FileStation.FormUploader.initForm(this, this.upFormArr, t, this.parentDir, e, this.uploaderName, this.sharing_id)
    },
    setParameters: function(e, t, i) {
        this.parentDir = e, this.uploaderName = t, this.sharing_id = i
    },
    reset: function(e) {
        var t = this.writeStrategyForm.getEl();
        e ? t.setStyle("display", "none") : t.setStyle("display", "block")
    },
    load: function(e) {
        this.blDisableWriteOption = e, this.show()
    },
    onBrowserFileSize: function(e) {
        return this.upFormArr[e].fileField.getEl().dom.files[0].fileSize
    },
    onCheckFileSize: function(e) {
        var t = -1;
        return (Ext.isSafari || Ext.isGecko) && (t = this.onBrowserFileSize(e)), !(t > this.limitSize) || (this.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("upload", "upload_exceed_maximum_filesize")), this.upFormArr[e].fileField.setValue(""), !1)
    },
    onFieldChange: function(e) {
        if (this.onCheckFileSize(e)) {
            var t = this.upFormArr[this.upFormArr.length - 1],
                i = t.fileField;
            t.mun(i.getEl(), "change", this.onFieldChangeFn, this), t.mon(i.getEl(), "change", function() {
                this.onCheckFileSize(e)
            }, this), this.addUpFileForm()
        }
    }
}), Ext.ns("SYNO.FileStation.Uploader"), SYNO.FileStation.Uploader.HTMLUploaderTaskMgr = Ext.extend(Object, {
    tasks: new Map,
    taskUploadingIndex: 0,
    constructor: function(e) {
        this.uploader = e.uploader, SYNO.FileStation.Uploader.HTMLUploaderTaskMgr.superclass.constructor.apply(this, arguments), this.cleanTaskMonitor()
    },
    initTaskData: function() {
        this.tasks = new Map, this.taskUploadingIndex = 0
    },
    getTaskSize: function() {
        return this.tasks ? this.tasks.size : 0
    },
    getUploadingTaskIndex: function() {
        return this.taskUploadingIndex
    },
    addUploadTask: function(e) {
        this.tasks.set(this.getTaskSize(), e)
    },
    cleanTaskMonitor: function() {
        if (!_S("standalone") && !SYNO.FileStation.Uploader.Utils.blCleanMonitor) {
            try {
                var e = ["uploadGrid", "downloadGrid", "localGrid"],
                    t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance");
                Ext.each(e, function(e) {
                    t[0].window[e].getStore().removeAll()
                })
            } catch (e) {
                SYNO.Debug.error(e)
            }
            SYNO.FileStation.Uploader.Utils.blCleanMonitor = !0
        }
    },
    removeOneTask: function(e) {
        var t = this.tasks.get(e);
        t && ("PROCESSING" === t.status && (this.uploader && this.uploader.conn && this.uploader.conn.abort(t.reqId), this.blUploading = !1, this.uploader.clearFolderFiles && this.uploader.clearFolderFiles(t), this.taskUploadingIndex++, this.uploader.uploadNext()), t.file = null, t.status = "CANCEL")
    },
    restartOneTask: function(e) {
        var t = this.tasks.get(e);
        t && (this.uploader.addFiles([t.file], !0, !1, t.params, [t.dtItem], t.isDirectory), this.removeOneTask(e))
    }
}), SYNO.FileStation.Uploader.HTML5Uploader = Ext.extend(Ext.Component, {
    MAX_POST_FILESIZE: Ext.isWebKit ? -1 : window.console && window.console.firebug ? 20971521 : 4294963200,
    FileObj: function(e, t, i, r) {
        var o = SYNO.Util.copy(t || {}),
            n = SYNO.webfm.utils.getLastModifiedTime(e);
        return n && (o = Ext.apply(o, {
            mtime: n
        })), {
            id: i,
            file: e,
            dtItem: r,
            name: e.name || e.fileName,
            size: e.size || e.fileSize,
            progress: 0,
            status: "NOT_STARTED",
            params: o,
            chunkmode: !1
        }
    },
    constructor: function(e, t) {
        this.initDefData(), this.HTMLUploaderTask = new SYNO.FileStation.Uploader.HTMLUploaderTaskMgr({
            uploader: this
        }), Ext.apply(this.opts, e), SYNO.FileStation.Uploader.HTML5Uploader.superclass.constructor.apply(this, arguments), this.init(t)
    },
    initDefData: function() {
        this.blAppenddata = !1, this.nbExceed = 0, this.nbWrongType = 0, this.arrFolder = [], this.arrExceedFile = [], this.arrWrongType = [], this.arrBigFile = [], this.objErrFiles = {}, this.nbErrFiles = 0, this.opts = {
            bldropBody: !1,
            instantStart: !1,
            chunkmode: !1,
            chunksize: 10485760,
            filefiledname: "file",
            params: {}
        }
    },
    init: function(e) {
        e.container.on("destroy", this.onDestroy, this), e.container.mon(this, e.opts.listeners), this.initButtonEl(e.container, e.opts), this.initDragDropEl(e.container, e.opts), e.files && e.container.mon(e.container.ownerCt, "show", function() {
            this.dropFiles(e.files), e.files = null
        }, this, {
            single: !0
        })
    },
    onDestroy: function(e) {
        e.un("destroy", this.onDestroy, this)
    },
    onMask: function(e) {
        this.opts.dropcss && e.addClass(this.opts.dropcss), e.addClass("file-drag-over"), e.mask(this.opts.droptext || _T("filetable", "drop_file"))
    },
    onUnmask: function(e) {
        this.opts.dropcss && e.removeClass(this.opts.dropcss), e.unmask(), e.removeClass("file-drag-over")
    },
    initButtonEl: function(e, t) {
        var i = this;
        if (Ext.isFunction(e.getForm)) {
            var r = e.getForm().findField(this.opts.filefiledname);
            if (r) {
                var o = r.el;
                o && o.is("input[type=file]") && (this.textEl = e.getForm().findField("MultiText"), this.mon(o, "change", function() {
                    i.blFolderEabled = !1, i.addFiles.call(i, this.dom.files, !0, !1, void 0, void 0, !1);
                    var e = this.dom;
                    if (Ext.isIE10 || Ext.isIE9 || Ext.isIE8) e.type = "", e.type = "file";
                    else {
                        var t = e.disabled;
                        e.disabled = !0, e.value = "", e.disabled = t
                    }
                }))
            }
        }
    },
    initDragDropEl: function(e, t) {
        var i = "grid" === e.getXType() ? e.getView().scroller : e.getViewEl ? e.getViewEl() : e.el,
            r = this.opts.bldropBody ? e.body || i : i;
        r && (e.mon(r, "dragover", function(e) {
            if (!SYNO.webfm.utils.isInRecycleBinFolder(this.webfm.getCurrentDir()) && SYNO.FileStation.Uploader.Utils.isDragFile(e.browserEvent)) {
                if (!this.isDragMask) return;
                e.preventDefault(), e.stopPropagation(), e.browserEvent.dataTransfer.dropEffect = "copy", this.dragstarttime = (new Date).getTime()
            }
        }, this), e.mon(Ext.getDoc(), "dragover", function(t) {
            if (!SYNO.webfm.utils.isInRecycleBinFolder(this.webfm.getCurrentDir()) && SYNO.FileStation.Uploader.Utils.isDragFile(t.browserEvent)) {
                if (this.dragstarttime = (new Date).getTime(), !this.isDragMask) {
                    if (!e.isVisible() || e.owner && e.owner.maskCnt >= 1 || e.el.isMasked() || this.isDragMask || e.owner && e.owner.el.isMasked() || e.owner && e.owner.owner && e.owner.owner.el.isMasked() || Ext.getBody().hasClass("x-body-masked")) return;
                    return !1 !== this.fireEvent("onBeforeDragEnter", this, e, t) && (this.isDragMask = !0, this.dragPollTask || (this.dragPollTask = this.addTask({
                        interval: 300,
                        run: function() {
                            800 < (new Date).getTime() - this.dragstarttime && this.onDragEnd(e, r)
                        },
                        scope: this
                    })), this.dragPollTask.start(), !1 !== this.fireEvent("onDragEnter", this, e) && void this.onMask(r))
                }
                this.fireEvent("onDragOver", this, e)
            }
        }, this), e.mon(Ext.getDoc(), "dragend", this.onDragEnd.createDelegate(this, [e, r], !0)), e.mon(Ext.getDoc(), "drop", this.onDragEnd.createDelegate(this, [e, r], !0)), e.mon(r, "drop", function(t) {
            if (!SYNO.webfm.utils.isInRecycleBinFolder(this.webfm.getCurrentDir()) && SYNO.FileStation.Uploader.Utils.isDragFile(t.browserEvent)) {
                if (this.dragstarttime = void 0, this.isDragMask = !1, !1 === this.fireEvent("onDrop", this, e)) return;
                if (this.onUnmask(r), t.stopPropagation(), t.preventDefault(), t.stopEvent(), _S("demo_mode")) return void this.fireEvent("onError", this, _JSLIBSTR("uicommon", "error_demo"));
                var i = t.browserEvent.dataTransfer;
                i && i.files && i.files.length > 0 ? (i.items && i.items[0] && i.items[0].webkitGetAsEntry ? this.blFolderEabled = !!this.blFolderEabled && !0 : this.blFolderEabled = !1, this.addFiles.call(this, i.files, !1, !1, null, i.items)) : this.fireEvent("onError", this, _T("error", "upload_folder_error"))
            }
        }, this))
    },
    onDragEnd: function() {
        if (!SYNO.webfm.utils.isInRecycleBinFolder(this.webfm.getCurrentDir()) && this.dragPollTask && this.dragPollTask.running) {
            this.dragPollTask.stop();
            var e = arguments[arguments.length - 1],
                t = arguments[arguments.length - 2];
            if (this.isDragMask && e.isMasked() && this.onUnmask(e), this.isDragMask = !1, !1 === this.fireEvent("onDragEnd", this, t)) return !1
        }
    },
    initTaskData: function() {
        this.HTMLUploaderTask.initTaskData()
    },
    checkDirectory: function(e, t) {
        var i = e.file,
            r = null;
        if (t && t.getAsEntry) {
            if (r = t.getAsEntry()) return r.isDirectory
        } else if (t && t.webkitGetAsEntry) {
            if (r = t.webkitGetAsEntry()) return r.isDirectory
        } else {
            if (Ext.isGecko) {
                try {
                    var o;
                    if (File && File.prototype.slice) o = i.slice(0, 1);
                    else if (File && File.prototype.webkitSlice) o = i.webkitSlice(0, 1);
                    else {
                        if (!File || !File.prototype.mozSlice) return !1;
                        o = i.mozSlice(0, 1)
                    }
                    if (o && window.FileReader) {
                        var n = new FileReader;
                        n.readAsBinaryString(o)
                    }
                } catch (e) {
                    return !0
                }
                return !1
            }
            if (Ext.isSafari) return !1
        }
        return 0 === i.size
    },
    addFiles: function(e, t, i, r, o, n, s) {
        var l, a, d, p, h = [],
            f = [],
            u = o || null;
        if (!e || 0 === e.length) return void this.fireEvent("onError", this, _T("upload", "empty_input_file"));
        this.blForceHtmlUpload = !!s, this.blAppenddata || this.initTaskData(), this.nbExceed = 0, this.nbWrongType = 0, this.objErrFiles = {}, this.nbErrFiles = 0, this.arrExceedFile = [], this.arrWrongType = [], this.arrBigFile = [];
        var c, m = 0,
            g = this.getTaskSize(),
            F = [];
        for (a = 0; a < e.length; a++)
            if (l = e[a], p = l.name || l.fileName, !f[p] || !1 === this.fireEvent("onNameDuplicate")) {
                var S;
                if (f[p] = !0, l instanceof File) {
                    var b = u && u[a] ? u[a] : null;
                    if (b && (b = b.webkitGetAsEntry ? b.webkitGetAsEntry() : b), S = new this.FileObj(l, r, null, b), Ext.isBoolean(n)) Ext.isModernIE ? S.isDirectory = 0 === S.file.length : S.isDirectory = n;
                    else if (S.isDirectory = !1, u) {
                        for (d = a; d < u.length; d++)
                            if (u[d] && u[d].getAsFile && u[d].getAsFile() === l) {
                                S.isDirectory = this.checkDirectory(S, u[d]);
                                break
                            }
                    } else S.isDirectory = this.checkDirectory(S);
                    F.push(S)
                } else S = l, r && Ext.apply(S.params, r);
                !1 !== this.onSelect(S) && (t ? (c = this.getTaskSize(), S.id = c, !1 !== this.fireEvent("onSelect", this, S) && this.HTMLUploaderTask.addUploadTask(S)) : h.push(S.name), m++)
            } if (!1 !== i && this.textEl && this.setInputFieldValue(""), c = this.getTaskSize(), t) {
            if (this.textEl) {
                var E = m > 0 ? String.format(_T("upload", "files_selected"), m) : "";
                this.setInputFieldValue(E)
            }
            this.onAllSelect(g, c)
        } else 0 === m ? this.onAllSelect(g, c) : this.fireEvent("onBeforeDropfile", this, h, e, {
            fn: this.dropFiles,
            files: F,
            scope: this
        }, this.onAllSelectStr())
    },
    dropFiles: function(e, t) {
        this.addFiles(e, !0, !0, t)
    },
    checkAllowFiletype: function(e) {
        return SYNO.FileStation.Uploader.Uploader.prototype.checkAllowFiletype.apply(this, arguments)
    },
    onSelect: function(e) {
        var t = Ext.util.Format.htmlEncode(e.name);
        if (this.opts.limitSize && e.size > this.opts.limitSize) this.arrBigFile.push(t);
        else if (this.opts.limitFiles && this.getTaskSize() - this.HTMLUploaderTask.taskUploadingIndex >= this.opts.limitFiles) this.nbExceed++, this.arrExceedFile.push(t);
        else if (this.checkAllowFiletype(t)) {
            if (this.blFolderEabled || !e.isDirectory) return !0;
            this.arrFolder.push(t)
        } else this.nbWrongType++, this.arrWrongType.push(t);
        return !1
    },
    getTaskSize: function() {
        return this.HTMLUploaderTask.getTaskSize()
    },
    onAllSelectStr: function(e) {
        var t = "",
            i = e ? "<br>" : "",
            r = 0;
        if (this.nbExceed && (t += 1 == this.nbExceed ? _T("common", "common_unselect_file") : _T("common", "common_unselect_files"), t += i, 1 < this.nbExceed && (t = t.replace("_NFILES_", this.nbExceed)), this.nbExceed = 0, this.arrExceedFile = []), this.arrBigFile && 0 < this.arrBigFile.length) {
            for (t += _T("upload", "upload_exceed_maximum_filesize") + ": " + i, r = 0; r < this.arrBigFile.length && r < 5; r++) t += this.arrBigFile[r] + i;
            5 < this.arrBigFile.length && (t += "..." + i), t += i, this.arrBigFile = []
        }
        if (!this.blFolderEabled && this.arrFolder && 0 < this.arrFolder.length) {
            for (t += _T("upload", Ext.isMac ? "no_folder_upload_action" : "upload_folder_error") + i, r = 0; r < this.arrFolder.length && r < 5; r++) t += this.arrFolder[r] + i;
            5 < this.arrFolder.length && (t += "..." + i), this.arrFolder = []
        }
        return this.nbWrongType && (t += String.format(_T("upload", "wrong_files_format"), this.nbWrongType), this.nbWrongType = 0, this.arrWrongType = []), t
    },
    onAllSelect: function(e, t) {
        var i = this.onAllSelectStr(!0);
        return i && "" !== i && this.fireEvent("onError", this, i), this.fireEvent("onAllSelect", this, e, t), this.getTaskSize() && this.opts.instantStart && this.uploadNext.createDelegate(this).defer(10), !0
    },
    onUploadFile: function(e) {
        var t, i = !1;
        if (Ext.isFunction(SYNO.webfm.VFS.isVFSPath) && (i = SYNO.webfm.VFS.isVFSPath(e.params.path)), -1 !== this.MAX_POST_FILESIZE && e.size > this.MAX_POST_FILESIZE && i) return void this.onError({
            errno: {
                section: "error",
                key: "upload_too_large"
            }
        }, e);
        if (t = this.prepareStartFormdata(e), e.chunkmode) {
            var r = this.opts.chunksize,
                o = Math.ceil(e.size / r);
            this.onUploadPartailFile(t, e, {
                start: 0,
                index: 0,
                total: o
            })
        } else this.sendArray(t, e)
    },
    prepareStartFormdata: function(e) {
        var t, i;
        if (this.opts.chunkmode || -1 !== this.MAX_POST_FILESIZE && e.size > this.MAX_POST_FILESIZE) {
            e.chunkmode = !0;
            var r = "----html5upload-" + (new Date).getTime().toString() + Math.floor(65535 * Math.random()).toString(),
                o = "";
            if (this.opts.params)
                for (i in this.opts.params) this.opts.params.hasOwnProperty(i) && (o += "--" + r + '\r\nContent-Disposition: form-data; name="' + i + '"\r\n\r\n', o += unescape(encodeURIComponent(this.opts.params[i])) + "\r\n");
            if (e.params)
                for (i in e.params) e.params.hasOwnProperty(i) && (o += "--" + r + '\r\nContent-Disposition: form-data; name="' + i + '"\r\n\r\n', o += unescape(encodeURIComponent(e.params[i])) + "\r\n");
            var n = unescape(encodeURIComponent(e.name));
            return o += "--" + r + '\r\nContent-Disposition: form-data; name="' + (this.opts.filefiledname || "file") + '"; filename="' + n + '"\r\nContent-Type: application/octet-stream\r\n\r\n', {
                formdata: o,
                boundary: r
            }
        }
        if (t = new FormData, this.opts.params)
            for (i in this.opts.params) this.opts.params.hasOwnProperty(i) && t.append(i, this.opts.params[i]);
        if (e.params)
            for (i in e.params) e.params.hasOwnProperty(i) && t.append(i, e.params[i]);
        return t
    },
    onUploadPartailFile: function(e, t, i, r) {
        i.start = i.index * this.opts.chunksize;
        var o = Math.min(this.opts.chunksize, t.size - i.start);
        if ("PROCESSING" === t.status) {
            var n;
            if (File && File.prototype.slice) n = 1 > i.total || i.index === i.total - 1 ? t.file.slice(i.start) : t.file.slice(i.start, i.start + o);
            else if (File && File.prototype.webkitSlice) n = 1 > i.total || i.index === i.total - 1 ? t.file.webkitSlice(i.start) : t.file.webkitSlice(i.start, i.start + o);
            else if (File && File.prototype.mozSlice) n = 1 > i.total || i.index === i.total - 1 ? t.file.mozSlice(i.start) : t.file.mozSlice(i.start, i.start + o);
            else {
                if (!File || !File.prototype.slice) return void this.onError({}, t);
                n = t.file.slice(i.start, o)
            }
            if (!window.FileReader) return void this.onError({}, t);
            var s = this,
                l = new FileReader,
                a = !1;
            Ext.isFunction(l.readAsBinaryString) || (a = !0), l.onload = function(o) {
                o.target.readyState == FileReader.DONE && s.sendArray(e, t, o.target.result, i, r)
            }, l.onerror = function() {
                s.onError({
                    errno: {
                        section: "error",
                        key: "error_privilege_not_enough"
                    }
                }, t)
            }, a ? l.readAsArrayBuffer(n) : l.readAsBinaryString(n)
        }
    },
    sendArray: function(e, t, i, r, o) {
        if ("CANCEL" !== t.status) {
            var n, s = {},
                l = {};
            if (!0 === t.chunkmode)
                if (l = {
                        "Content-Type": "multipart/form-data; boundary=" + e.boundary
                    }, s = {
                        "X-TYPE-NAME": "SLICEUPLOAD",
                        "X-FILE-SIZE": t.size,
                        "X-FILE-CHUNK-END": 1 > r.total || r.index === r.total - 1 ? "true" : "false"
                    }, o && Ext.apply(s, {
                        "X-TMP-FILE": o
                    }), window.XMLHttpRequest.prototype.sendAsBinary) {
                    var a = e.formdata + ("" !== i ? i : "") + "\r\n--" + e.boundary + "--\r\n";
                    n = a
                } else if (window.Blob) {
                var d, p = 0,
                    h = 0,
                    f = 0,
                    u = "\r\n--" + e.boundary + "--\r\n",
                    c = e.formdata.length + u.length;
                for (f = Ext.isString(i) ? i.length : new Uint8Array(i).byteLength, c += f, d = new Uint8Array(c), p = 0; p < e.formdata.length; p++) d[p] = e.formdata.charCodeAt(p);
                if (Ext.isString(i))
                    for (h = 0; h < i.length; h++) d[p + h] = i.charCodeAt(h);
                else d.set(new Uint8Array(i), p);
                for (p += f, h = 0; h < u.length; h++) d[p + h] = u.charCodeAt(h);
                n = d
            } else {
                var m;
                window.MSBlobBuilder ? m = new MSBlobBuilder : window.BlobBuilder && (m = new BlobBuilder), m.append(e.formdata), "" !== i && m.append(i), m.append("\r\n--" + e.boundary + "--\r\n"), n = m.getBlob(), m = null
            } else e.append("size", t.size), t.name ? e.append(this.opts.filefiledname, t.file, t.name) : e.append(this.opts.filefiledname, t.file), n = e;
            this.conn = new Ext.data.Connection({
                method: "POST",
                url: this.url,
                defaultHeaders: l,
                timeout: null
            });
            var g = this.conn.request({
                headers: s,
                html5upload: !0,
                chunkmode: t.chunkmode,
                uploadData: n,
                success: this.onSuccess.createDelegate(this, [e, t, r], !0),
                failure: this.onFail.createDelegate(this, [t], !0),
                progress: this.onProgress.createDelegate(this, [t, t.chunkmode ? r.start : 0], !0)
            });
            t.reqId = g, t.isSubFile && t.rootObj && (t.rootObj.reqId = g), n = null
        }
    },
    onProgress: function(e, t, i) {
        if (e.lengthComputable) {
            t.size = t.size || 0;
            var r = Math.min(t.size, i + e.loaded);
            this.fireEvent("onProgress", this, t, r, t.size)
        }
    },
    onSuccess: function(e, t, i, r, o) {
        var n = Ext.util.JSON.decode(e.responseText);
        if (n.success) {
            if (!0 === r.chunkmode && o.index < o.total - 1) {
                var s = n.tmpfile || n.data.tmpfile;
                return s && "" !== s ? (o.index++, void this.onUploadPartailFile(i, r, o, s)) : void this.onError({}, r)
            }
            this.onFinish(n, r)
        } else this.onError(n, r)
    },
    onFinishFolderTask: function(e, t) {
        var i = this.HTMLUploaderTask.tasks.get(t.id);
        t.file = null, i.finishedFile = t.isSubFile ? i.finishedFile + 1 : i.finishedFile, "CANCEL" !== i.status && this.sendNextFile(t), i.finishedFile == i.fileNum && (t.rootObj.status = t.rootObj.errors ? "FAIL" : "SUCCESS", this.HTMLUploaderTask.taskUploadingIndex++, this.HTMLUploaderTask.blUploading = !1, this.fireEvent("onComplete", this, e, t), this.uploadNext())
    },
    onFinish: function(e, t) {
        if (t.isSubFile || t.isSubFolder) return this.fireEvent("onCompleteFolderFile", this, e, t), void this.onFinishFolderTask(e, t);
        this.HTMLUploaderTask.taskUploadingIndex++, this.HTMLUploaderTask.blUploading = !1, t.status = "SUCCESS", this.fireEvent("onComplete", this, e, t), t.file = null, this.uploadNext()
    },
    onError: function(e, t) {
        var i = t.isSubFile,
            r = t.isSubFolder;
        if (i || r || (this.HTMLUploaderTask.taskUploadingIndex++, this.HTMLUploaderTask.blUploading = !1, t.status = "FAIL"), this.blAppenddata) e || (e = {
            errno: {
                section: "error",
                key: "upload_folder_error"
            }
        }), this.fireEvent("onError", this, e, t);
        else {
            this.nbErrFiles++;
            var o = e && e.errno ? e.errno : {
                section: "error",
                key: "upload_folder_error"
            };
            o && this.objErrFiles[o.key] ? this.objErrFiles[o.key].files.push(t) : this.objErrFiles[o.key] = {
                section: o.section,
                files: [t]
            }
        }
        return r ? void this.sendNextFile(t) : i ? void this.onFinishFolderTask(e, t) : void this.uploadNext()
    },
    onFail: function(e, t, i) {
        var r = {};
        if (Ext.isSafari && e && 0 === e.status && (r = {
                errno: {
                    section: "error",
                    key: "upload_folder_error"
                }
            }), Ext.isChrome && e && 0 === e.status && "communication failure" === e.statusText && (r = {
                errno: {
                    section: "error",
                    key: "error_source_no_file"
                }
            }), e && e.responseText) try {
            r = Ext.util.JSON.decode(e.responseText)
        } catch (e) {
            r = {
                errno: {
                    section: "common",
                    key: "commfail"
                }
            }
        }
        this.onError(r, i)
    },
    onAllComplete: function() {
        var e, t, i, r;
        if (this.setInputFieldValue(""), !this.blAppenddata && this.getServerErrorCount() > 0) {
            var o = "";
            o += String.format(_T("download", "download_upload_erro_files"), this.nbErrFiles), o += " <br>";
            for (e in this.objErrFiles)
                if (this.objErrFiles.hasOwnProperty(e)) {
                    t = this.objErrFiles[e].files, i = t.length;
                    var n = "";
                    try {
                        n = _T(this.objErrFiles[e].section, e)
                    } catch (t) {
                        n = _WFT(this.objErrFiles[e].section, e)
                    }
                    for (o += (n || "") + "<br>", r = 0; r < i; r++) o += t[r].name + "<br>";
                    o += "<br>"
                } this.objErrFiles = {}, o && this.fireEvent("onError", this, o)
        }
        this.fireEvent("onAllComplete", this)
    },
    getServerErrorCount: function() {
        return this.nbErrFiles
    },
    uploadNext: function() {
        if (!0 !== this.HTMLUploaderTask.blUploading && !1 !== this.fireEvent("onBeforeSubmit", this)) {
            var e, t, i = this.getTaskSize();
            for (t = this.HTMLUploaderTask.taskUploadingIndex; t < i; t++) {
                if ((e = this.HTMLUploaderTask.tasks.get(t)) && "NOT_STARTED" === e.status) {
                    this.HTMLUploaderTask.blUploading = !0, e.status = "PROCESSING", this.fireEvent("onOpen", this, e), this.onSendFile(e);
                    break
                }
                this.HTMLUploaderTask.taskUploadingIndex++
            }
            t >= i && this.onAllComplete()
        }
    },
    onSendFile: function(e) {
        this.onUploadFile(e)
    },
    onSubmit: function() {
        if (this.HTMLUploaderTask.taskUploadingIndex >= this.getTaskSize()) return void this.fireEvent("onError", this, _T("upload", "empty_input_file"));
        this.uploadNext()
    },
    setInputFieldValue: function(e) {
        this.textEl && this.textEl.setValue(e)
    }
}), Ext.ns("SYNO.FileStation.Uploader"), SYNO.FileStation.Uploader.Utils = {}, SYNO.FileStation.Uploader.Utils = Ext.applyIf({
    isDragFile: function(e) {
        try {
            if (Ext.isWebKit) {
                return e.dataTransfer.types && -1 != e.dataTransfer.types.indexOf("Files")
            }
            if (Ext.isGecko) return e.dataTransfer.types.contains && e.dataTransfer.types.contains("application/x-moz-file") || 0 <= e.dataTransfer.types.indexOf("application/x-moz-file");
            if (Ext.isIE10 || Ext.isModernIE) return e.dataTransfer.files && e.dataTransfer.types && e.dataTransfer.types.contains("Files")
        } catch (e) {
            SYNO.Debug("Error in isDragFile")
        }
        return !1
    },
    getButtonTemplate: function(e) {
        if (SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload()) {
            var t = Ext.id();
            return {
                itemId: "htmlfield",
                name: "htmlfield",
                synotype: "indent",
                xtype: "compositefield",
                defaultMargins: "0 2 0 0",
                hideMode: "display",
                fieldLabel: _T("download", "download_lbl_input_file"),
                defaults: {
                    hideLabel: !0
                },
                items: [{
                    xtype: "textfield",
                    readOnly: !0,
                    name: "MultiText",
                    width: 157
                }, {
                    xtype: "button",
                    text: _T("download", "upload_browse"),
                    handler: function(e, i) {
                        i.preventDefault(), Ext.fly(t).dom.click()
                    }
                }, Ext.apply({
                    itemId: "htmlfield",
                    xtype: "textfield",
                    hideMode: "display",
                    inputType: "file",
                    autoCreate: {
                        id: t,
                        tag: "input",
                        type: "file",
                        multiple: "multiple",
                        style: "width:1px;height:1px;z-index:-1;"
                    }
                }, e || {})]
            }
        }
        return SYNO.SDS.Utils.Flash.isSupport() ? Ext.apply({
            itemId: "flashfield",
            synotype: "indent",
            xtype: "compositefield",
            defaultMargins: "0 2 0 0",
            hideMode: "display",
            fieldLabel: _T("download", "download_lbl_input_file"),
            defaults: {
                hideLabel: !0
            },
            items: [{
                xtype: "textfield",
                readOnly: !0,
                name: "MultiText",
                width: 157
            }, {
                id: e.btnFlashId,
                xtype: "button",
                itemId: "flashbtn",
                text: _T("download", "upload_browse")
            }]
        }, e || {}) : Ext.apply({
            itemId: "htmlfield",
            xtype: "textfield",
            hideMode: "display",
            inputType: "file",
            style: {
                "padding-top": Ext.isWebKit ? "3px" : "0"
            },
            width: Ext.isSafari ? 221 : Ext.isChrome ? 218 : Ext.isIE ? 213 : 220,
            autoCreate: {
                tag: "input",
                type: "file",
                size: Ext.isGecko ? Ext.isMac ? 18 : 24 : void 0
            }
        }, e || {})
    },
    blCleanMonitor: !1
}, SYNO.SDS.HTML5Utils), SYNO.FileStation.Uploader.Uploader = Ext.extend(Ext.util.Observable, {
    constructor: function(e) {
        this.initDefData(), SYNO.FileStation.Uploader.Uploader.superclass.constructor.call(this, e.cfg), Ext.apply(this.opts, e.cfg || {}), Ext.apply(this.htmlopts, e.htmlcfg || {}), Ext.apply(this.flashopts, e.flashcfg || {}), this.blInputEl = e.cfg.blInputEl, this.files = e.files
    },
    initDefData: function() {
        this.opts = {
            limitSize: 2147482624,
            limitFiles: 100,
            startId: "",
            url: ""
        }, this.flashopts = {}, this.htmlopts = {}
    },
    init: function(e) {
        e.mon(e, "afterlayout", this.onAfterLayout, this, {
            single: !0
        }), !1 !== this.blInputEl && Ext.isFunction(e.getForm) && (this.blInputEl = !0)
    },
    onAfterLayout: function(e) {
        this.initUploader(e)
    },
    initUploader: function(e) {
        if (this.opts.startId) {
            var t = Ext.getCmp(this.opts.startId);
            t && e.mon(t, "click", function(t) {
                this.onSubmit(e)
            }, this)
        }
        var i;
        SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() && (this.initHTML5Uploader(e), this.blInputEl && (i = e.getForm().findField("flashfield"))), i && (i.label.enableDisplayMode(), i.label.hide(), i.hide(), i.disable())
    },
    initHTML5Uploader: function(e) {
        this.html5uploader || (this.html5uploader = new SYNO.FileStation.Uploader.HTML5Uploader(Ext.apply({
            limitSize: this.opts.limitSize,
            limitFiles: this.opts.limitFiles
        }, this.htmlopts || {}), {
            container: e,
            opts: this.opts,
            files: this.files
        }))
    },
    onSubmit: function(e) {
        SYNO.FileStation.Uploader.Utils.isSupportHTML5Upload() ? this.html5uploader.onSubmit(e) : SYNO.SDS.Utils.Flash.isSupport() ? this.swiffy.onSubmit(e) : this.htmluploader.onSubmit(e)
    },
    checkAllowFiletype: function(e) {
        var t = this.opts.allowfilters;
        if (!t || 0 === t.length) return !0;
        var i = !1;
        return Ext.each(t, function(t) {
            if (SYNO.SDS.Utils.isValidExtension(e, "." + t)) return i = !0, !1
        }), i
    }
}), Ext.ns("SYNO.FileStation.Action.Uploader"), SYNO.FileStation.Action.Uploader.HTML5UploaderMgr = Ext.extend(Object, {
    constructor: function(e) {
        this.uploader = new SYNO.FileStation.Action.Uploader.Uploader({
            cfg: this.getCfg(e),
            htmlcfg: this.getHTML5Cfg(e),
            btncfg: e.btncfg
        })
    },
    init: function(e) {
        this.uploader.init(e), this.dragovertime = 0
    },
    getCfg: function(e) {
        return {
            limitFiles: 1e3,
            listeners: this.getUploadListeners(e.owner)
        }
    },
    getHTML5Cfg: function(e) {
        return {
            url: e.url,
            filefiledname: "file",
            instantStart: e.instantStart,
            listeners: {
                scope: e.owner,
                onBeforeDropfile: this.onBeforeDropfile,
                onDragEnter: this.onDragEnter,
                onDrop: this.onDrop,
                onDragEnd: this.onDragEnd,
                onBeforeDragEnter: this.onBeforeDragEnter,
                onDragOver: {
                    fn: this.onDragOver,
                    scope: this
                }
            }
        }
    },
    getUploadListeners: function(e) {
        return {
            scope: e,
            onOpen: this.onOpen,
            onSelect: this.onSelect,
            onAllSelect: this.onAllSelect,
            onError: this.onError,
            onBeforeBrowse: this.onBeforeBrowse
        }
    },
    onBeforeBrowse: function(e, t) {
        return !0 === _S("demo_mode") ? (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo")), !1) : this.onCheckVFSAction("upload", null, this.getUploadPath(t)) ? this.onCheckPrivilege("upload", null, !1, !1) ? !t.disabled && 1 !== AppletProgram.blJavaPermission && void(e.params = {
            path: this.getUploadPath(t)
        }) : (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1) : (this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support")), !1)
    },
    onOpen: function(e, t) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        this.getUploadInstance().onOpen({
            id: t.id
        })
    },
    onSelect: function(e, t) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        t.params.path || Ext.apply(t.params, {
            path: this.getCurrentDir()
        }), this.getUploadInstance().onSelect({
            id: t.id,
            name: t.name
        })
    },
    onAllSelect: function(e, t, i) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        this.getUploadInstance().onAllSelect(t, i)
    },
    onError: function(e, t, i) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        if (!i) {
            var r = _WFT("error", "error_error_system");
            return Ext.isString(t) && (r = t), SYNO.webfm.utils.isSharingUpload() ? (this.onUploadFolderError(), !1) : void this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), r)
        }
    },
    onBeforeDropfile: function(e, t, i, r, o) {
        var n = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite");
        if (!this.onCheckVFSAction("upload", null, this.getUploadPath())) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support")), !1;
        if (!this.onCheckPrivilege("upload", null, !1, !1)) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
        if (SYNO.webfm.utils.isSharingUpload()) {
            var s = !1;
            if (this.blUploading) return;
            if (Ext.each(r.files, function(e) {
                    if (e.isDirectory) return s = !0, !1
                }), s) return void this.onUploadFolderError()
        }
        var l = new SYNO.FileStation.DropConfirmDialog({
            owner: this.owner
        }, {
            cb: r,
            filenames: t
        }, o);
        n || SYNO.webfm.utils.isSharingUpload() ? l.upload(n) : l.show()
    },
    onBeforeDragEnter: function(e, t, i) {
        if (1 === AppletProgram.blJavaPermission) {
            if ((Ext.isIE || Ext.isModernIE || Ext.isChrome) && SYNO.SDS.AppMgr) {
                var r = !1,
                    o = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
                if (o.length < 1) return !1;
                Ext.each(o, function(e) {
                    if (e.window === SYNO.SDS.WindowMgr.getActive()) return r = !0, !1
                });
                var n;
                if (r ? n = SYNO.SDS.WindowMgr.getActive() : (n = o[0].window, SYNO.SDS.WindowMgr.bringToFront(n)), t.owner.appWindow !== n) return !1
            }
            return "remote" === t.owner.getCurrentSource()
        }
        if (t.owner && "remotes" === t.owner.getCurrentSource()) return !1
    },
    onDragEnter: function(e, t) {
        if (!_S("demo_mode") && 1 === AppletProgram.blJavaPermission) {
            var i = t.html5cfg.dropppanelapplet;
            return i && i.showDropPanel(), !1
        }
    },
    onDragOver: function(e, t) {
        if (!_S("demo_mode") && 1 === AppletProgram.blJavaPermission) {
            var i = t.html5cfg.dropppanelapplet;
            i && 100 < (new Date).getTime() - this.dragovertime && (i.showDropPanel(), this.dragovertime = (new Date).getTime())
        }
    },
    onDrop: function(e, t) {
        if (e.blFolderEabled = !0, !_S("demo_mode") && 1 === AppletProgram.blJavaPermission) return !1
    },
    onDragEnd: function(e, t) {
        if (!_S("demo_mode") && 1 === AppletProgram.blJavaPermission) {
            var i = t.html5cfg.dropppanelapplet;
            return i && !i.processing && (i.hideDropPanel(), this.dragovertime = 0), !1
        }
    },
    onRemoveBtnClick: function(e) {
        this.uploader && this.uploader.onRemoveBtnClick(e)
    },
    onAddBtnClick: function(e) {
        this.uploader && this.uploader.onAddBtnClick(e)
    },
    onAddJavaDropPanel: function(e, t) {
        this.uploader && this.uploader.onAddJavaDropPanel(e, t)
    }
}), SYNO.FileStation.Action.Uploader.Uploader = Ext.extend(SYNO.FileStation.Uploader.Uploader, {
    constructor: function(e) {
        SYNO.FileStation.Action.Uploader.Uploader.superclass.constructor.apply(this, arguments), this.initContainer(e)
    },
    initContainer: function(e) {
        var t = this;
        this.init = function(i) {
            i.mon(i, "afterlayout", function(t) {
                t.html5cfg = {}, t.html5cfg.btncfg = e.btncfg, this.initHTML5Uploader(i)
            }, t, {
                single: !0
            })
        }
    },
    initHTML5Uploader: function(e) {
        this.html5uploader = new SYNO.FileStation.Action.Uploader.HTML5Uploader(Ext.apply({
            limitFiles: this.opts.limitFiles
        }, this.htmlopts || {}), {
            container: e,
            opts: this.opts
        })
    },
    onRemoveBtnClick: function(e) {
        this.html5uploader && this.html5uploader.onRemoveBtnClick(e)
    },
    onAddBtnClick: function(e) {
        this.html5uploader && this.html5uploader.onAddBtnClick(e)
    },
    onAddJavaDropPanel: function(e, t) {
        this.html5uploader && this.html5uploader.onAddJavaDropPanel(e, t)
    }
}), SYNO.FileStation.Action.Uploader.HTML5Uploader = Ext.extend(SYNO.FileStation.Uploader.HTML5Uploader, {
    blFolderEabled: !0,
    constructor: function(e, t) {
        this.initDefData(), SYNO.FileStation.HTML5Uploader ? this.HTMLUploaderTask = SYNO.FileStation.HTMLUploaderTaskMgr : (this.HTMLUploaderTask = new SYNO.FileStation.Uploader.HTMLUploaderTaskMgr({
            uploader: this
        }), SYNO.FileStation.HTMLUploaderTaskMgr = this.HTMLUploaderTask), Ext.apply(this.opts, e), SYNO.FileStation.Uploader.HTML5Uploader.superclass.constructor.apply(this, arguments), this.init(t), this.blInitListener || (this.mon(this, {
            scope: this,
            onProgress: this.onProgressFn,
            onComplete: this.onCompleteFn,
            onAllComplete: this.onAllCompleteFn,
            onError: this.onErrorFn,
            onCompleteFolderFile: this.onCompleteFolderFileFn
        }), this.blInitListener = !0), this.webfm = this.opts.listeners.scope, this.folderFiles = {}
    },
    getUploadInstance: function() {
        return this.uploadGird || (this.uploadGird = this.webfm.getUploadInstance()), this.uploadGird
    },
    onProgressFn: function(e, t, i) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        var r, o, n, s, l;
        if (t.isSubFile) {
            var a = t.rootObj,
                d = a.uploadByte;
            l = i + d, s = a.totalByte, r = Math.floor((d + i) / s * 100), t.byteswrite = i, o = t.rootObj.name, n = t.params.path.replace(a.params.path + "/", "") + "/" + t.name
        } else r = t.size ? Math.floor(i / t.size * 100) : 0, o = t.name, n = t.name, s = t.size, l = i;
        (t.isSubFile || 0 < r) && this.getUploadInstance().onProgressWithTime({
            id: t.id,
            byteswrite: l,
            bytestotal: s,
            progress: r,
            name: o,
            curname: n,
            taskInfo: {
                progress: r,
                isSubFile: t.isSubFile,
                complete: i === t.size
            }
        })
    },
    onCompleteFn: function(e, t, i) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        this.getUploadInstance().onComplete({
            id: i.id,
            remotedir: i.params.path,
            isSkip: t.blSkip,
            name: i.name,
            isSubFile: i.isSubFile,
            isSubFolder: i.isSubFolder,
            rootObj: i.rootObj
        })
    },
    onCompleteFolderFileFn: function(e, t, i) {
        this.getUploadInstance().onCompleteFolderFile && this.getUploadInstance().onCompleteFolderFile({
            id: i.id,
            size: i.size,
            rootObj: i.rootObj
        })
    },
    onAllCompleteFn: function(e) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        this.getUploadInstance().onAllComplete()
    },
    onErrorFn: function(e, t, i) {
        if (!this.blForceHtmlUpload && 1 === AppletProgram.blJavaPermission) return !1;
        if (i) {
            if (i.isSubFile || i.isSubFolder) {
                i.rootObj.errors || (i.rootObj.errors = []);
                var r;
                if (t && t.error && t.error.code) r = SYNO.webfm.utils.getWebAPIErr(!1, t.error);
                else if (t && t.errno && t.errno.section && t.errno.key) {
                    var o = t.errno.section,
                        n = t.errno.key;
                    r = _WFT(o, n) || _T(o, n)
                } else r = Ext.isString(t) ? t : _WFT("common", "commfail");
                var s = {
                    name: i.params.path + "/" + i.name,
                    errStr: r
                };
                i.rootObj.errors.push(s)
            }
            this.getUploadInstance().onError({
                id: i.id,
                curname: i.name,
                response: t,
                status: i.status,
                size: i.size,
                byteswrite: i.byteswrite || 0,
                isSubFile: i.isSubFile,
                isSubFolder: i.isSubFolder,
                rootObj: i.rootObj
            })
        }
    },
    initDefData: function() {
        SYNO.FileStation.Action.Uploader.HTML5Uploader.superclass.initDefData.apply(this, arguments), this.blAppenddata = !0, this.btncfgs = []
    },
    init: function(e) {
        SYNO.FileStation.Action.Uploader.HTML5Uploader.superclass.init.apply(this, arguments), e.container.html5cfg.html5uploader = this
    },
    onAddJavaDropPanel: function(e, t) {
        1 === AppletProgram.blJavaPermission && (e.html5cfg.dropppanelapplet = new AppletProgram.DropPanel(t))
    },
    onDestroy: function(e) {
        SYNO.FileStation.Action.Uploader.HTML5Uploader.superclass.onDestroy.apply(this, arguments), e.html5cfg.skipinputel && Ext.destroy(e.html5cfg.skipinputel), e.html5cfg.overinputel && Ext.destroy(e.html5cfg.overinputel), e.html5cfg.dropppanelapplet && e.html5cfg.dropppanelapplet.onDestroy()
    },
    onCreateInputEl: function() {
        var e, t = Ext.id();
        return e = document.createElement("input"), e.setAttribute("id", t), e.setAttribute("type", "file"), e.setAttribute("multiple", "multiple"), e.setAttribute("style", "position:absolute;left:-10000px;width:1px;1px;"), this.webfm.fireEvent("onAfterCreateInputEl", e), Ext.getBody().appendChild(e)
    },
    onAddSkipBtnClick: function(e, t) {
        var i = e.html5cfg;
        i.skipinputel || (i.skipinputel = this.onCreateInputEl(), e.mon(i.skipinputel, "change", function(e, i) {
            if (this.blFolderEabled = !1, this.addFiles.call(this, i.files, !0, !1, Ext.apply(t, this.params || {}), void 0, !1), Ext.isIE10 || Ext.isIE9 || Ext.isIE8) i.type = "", i.type = "file";
            else {
                var r = i.disabled;
                i.disabled = !0, i.value = "", i.disabled = r
            }
            this.webfm.btnRemoteUpload && this.webfm.btnRemoteUpload.focus()
        }, this)), Ext.each(i.btncfg.skipbtncfg, function(t) {
            var i = t.cmp || Ext.getCmp(t.id);
            i && (i.html5cfg = {}, i.html5cfg.container = e, e.mon(i, "click", this.onClickSkipBtn, this))
        }, this)
    },
    onClickSkipBtn: function(e, t) {
        Ext.isGecko || t.preventDefault(), !1 !== this.fireEvent("onBeforeBrowse", this, e) && e.html5cfg.container.html5cfg.skipinputel.dom.click()
    },
    onRemoveSkipBtnClick: function(e) {
        Ext.each(e.html5cfg.btncfg.skipbtncfg, function(t) {
            var i = t.cmp || Ext.getCmp(t.id);
            e.mun(i, "click", this.onClickSkipBtn, this)
        }, this)
    },
    onAddOvwrBtnClick: function(e, t) {
        var i = e.html5cfg;
        i.overinputel || (i.overinputel = this.onCreateInputEl(), e.mon(i.overinputel, "change", function(e, i) {
            if (this.blFolderEabled = !1, this.addFiles.call(this, i.files, !0, !1, Ext.apply(t, this.params || {}), void 0, !1), Ext.isIE10 || Ext.isIE9 || Ext.isIE8) i.type = "", i.type = "file";
            else {
                var r = i.disabled;
                i.disabled = !0, i.value = "", i.disabled = r
            }
            this.webfm.btnRemoteUpload && this.webfm.btnRemoteUpload.focus()
        }, this)), Ext.each(i.btncfg.ovwrbtncfg, function(t) {
            var i = t.cmp || Ext.getCmp(t.id);
            i && (i.html5cfg = {}, i.html5cfg.container = e, e.mon(i, "click", this.onClickOvwrBtn, this))
        }, this)
    },
    onClickOvwrBtn: function(e, t) {
        Ext.isGecko || t.preventDefault(), !1 !== this.fireEvent("onBeforeBrowse", this, e) && e.html5cfg.container.html5cfg.overinputel.dom.click()
    },
    onRemoveOvwrBtnClick: function(e) {
        Ext.each(e.html5cfg.btncfg.ovwrbtncfg, function(t) {
            var i = t.cmp || Ext.getCmp(t.id);
            e.mun(i, "click", this.onClickOvwrBtn, this)
        }, this)
    },
    onRemoveBtnClick: function(e) {
        this.onRemoveOvwrBtnClick(e), this.onRemoveSkipBtnClick(e)
    },
    onAddBtnClick: function(e) {
        this.onAddOvwrBtnClick(e, {
            overwrite: !0
        }), this.onAddSkipBtnClick(e, {
            overwrite: !1
        })
    },
    initFolderFile: function(e, t, i) {
        var r = {
                path: i,
                overwrite: e.params.overwrite
            },
            o = this,
            n = function(t) {
                r.mtime = SYNO.webfm.utils.getLastModifiedTime(t);
                var i = new o.FileObj(t, r);
                i.id = e.id, i.isSubFile = !0, i.rootObj = e, e.totalByte += t.size, e.fileArr.push(i), o.pendingSendFile && (o.sendFolderFiles(e), o.pendingSendFile = !1)
            };
        t.file(n)
    },
    sendFolderFiles: function(e) {
        e.fileArr[0] ? this.sendCheckInfo(e.fileArr[0]) : this.pendingSendFile = !0
    },
    uploadSubFolder: function(e) {
        if (0 === e.creatingDirs.length) return void(e.fileNum > 0 ? this.sendFolderFiles(e) : this.onFinish({
            blSkip: !1
        }, e));
        if (!0 !== this.creatingFolder) {
            var t = e.creatingDirs[0];
            this.creatingFolder = !0, SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
                folder_path: t.relPath,
                name: t.name,
                force_parent: !1
            }, function(i, r, o, n) {
                if (this.creatingFolder = !1, e.creatingDirs.splice(0, 1), e.folderNum--, !i) {
                    if (!r.errors) return void this.onError({
                        error: {
                            code: 400
                        }
                    }, t);
                    for (var s = 0; s < r.errors.length; s++)
                        if (414 != r.errors[s].code) return void this.onError({
                            error: {
                                code: r.errors[s].code
                            }
                        }, t)
                }
                this.uploadSubFolder(e)
            }, this)
        }
    },
    countFileNum: function(e, t, i) {
        var r = this;
        e.readEntries(function(o) {
            if (!o.length) {
                for (; t.dirArr.length;) {
                    var n = t.dirArr.splice(0, 1)[0];
                    e = n.createReader(), r.countFileNum.call(r, e, t, t.params.path + n.fullPath), t.creatingDirs.push(n)
                }
                return void r.uploadSubFolder.call(r, t)
            }
            for (var s = 0; s < o.length; s++) o[s].isFile && (t.fileNum++, r.initFolderFile(t, o[s], i)), o[s].isDirectory && (t.folderNum++, o[s].relPath = i, t.dirArr.push(o[s]));
            r.countFileNum.call(r, e, t, i)
        }, function(e) {
            r.onError(_WFT("upload", "upload_nofile"), t)
        })
    },
    preprocFolder: function(e) {
        e.fileNum = 0, e.folderNum = 0, e.totalByte = 0, e.uploadByte = 0, e.dirArr = [], e.fileArr = [], e.creatingDirs = [], SYNO.API.currentManager.requestAPI("SYNO.FileStation.CreateFolder", "create", "2", {
            folder_path: e.params.path,
            name: e.name,
            force_parent: !1
        }, function(t, i, r, o) {
            if (!t)
                for (var n = 0; n < i.errors.length; n++)
                    if (414 != i.errors[n].code) return void this.onError({
                        error: {
                            code: i.errors[n].code
                        }
                    }, e);
            var s = e.dtItem.createReader();
            this.countFileNum(s, e, e.params.path + "/" + e.name), this.getUploadInstance().onCompleteRootFolder({
                id: e.id,
                remotedir: e.params.path
            })
        }, this)
    },
    onSendFile: function(e) {
        if (e.isDirectory || e.dtItem && e.dtItem.isDirectory) return e.finishedFile = 0, void this.preprocFolder(e);
        this.sendCheckInfo(e)
    },
    sendNextFile: function(e) {
        var t, i = e.rootObj,
            r = i.fileArr;
        if (r && r.length > 0) {
            for (t = 0; t < r.length; t++) r[t] === e && r.splice(t, 1);
            r.length > 0 && this.sendCheckInfo(r[0])
        }
    },
    clearFolderFiles: function(e) {
        e.fileArr = [], e.dirArr = []
    },
    sendCheckInfo: function(e) {
        var t = {
            path: e.params.path,
            filename: e.name,
            size: e.size,
            overwrite: e.params.overwrite
        };
        Ext.isEmpty(e.params.sharing_id) || (t.sharing_id = e.params.sharing_id, t.uploader_name = e.params.uploader_name, delete t.path, delete e.params.path), this.sendWebAPI({
            api: "SYNO.FileStation.CheckPermission",
            method: "write",
            version: 3,
            params: t,
            scope: this,
            callback: function(t, i, r) {
                if (!t) return void this.onError({
                    error: i
                }, e);
                i.blSkip ? this.onFinish(i, e) : this.onUploadFile(e)
            }
        })
    }
}), SYNO.FileStation.DropConfirmDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    constructor: function(e, t, i) {
        this.callback = t.cb;
        var r, o = t.filenames,
            n = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite");
        if (1 == o.length) {
            var s = o[0];
            s = s.substring(s.lastIndexOf(Ext.isWindows ? "\\" : "/") + 1), r = String.format(_WFT("upload", "upload_one_file"), Ext.util.Format.ellipsis(s, 50))
        } else r = String.format(_WFT("upload", "upload_files"), o.length);
        i && "" !== i && (r += "<br>(" + i + ")");
        var l = {
            owner: e.owner,
            resizable: !1,
            minimizable: !1,
            maximizable: !1,
            stateful: !1,
            buttonAlign: "left",
            width: 500,
            height: i && "" !== i ? 260 : 225,
            footer: !0,
            cls: "x-window-dlg",
            title: _WFT("filetable", "filetable_upload"),
            items: [{
                xtype: "syno_displayfield",
                value: r
            }, {
                xtype: "syno_checkbox",
                itemId: "option",
                checked: n,
                boxLabel: _WFT("filetable", "upload_copy_auto_overwrite")
            }],
            fbar: new Ext.Toolbar({
                defaultType: "syno_button",
                items: [{
                    text: _WFT("filetable", "filetable_skip"),
                    scope: this,
                    handler: function() {
                        this.onUpload(!1)
                    }
                }, "->", {
                    text: _WFT("common", "cancel"),
                    scope: this,
                    handler: function() {
                        this.onCancel()
                    }
                }, {
                    text: _WFT("filetable", "filetable_overwrite"),
                    scope: this,
                    btnStyle: "blue",
                    handler: function() {
                        this.onUpload(!0)
                    }
                }],
                enableOverflow: !1
            }),
            keys: [{
                key: 27,
                fn: this.close,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                }
            }
        };
        SYNO.FileStation.DropConfirmDialog.superclass.constructor.call(this, l)
    },
    onUpload: function(e) {
        var t = this.getComponent("option").getValue();
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite", t), this.upload(e), this.close()
    },
    onCancel: function() {
        this.close()
    },
    upload: function(e) {
        this.callback.fn.apply(this.callback.scope, [this.callback.files, {
            overwrite: e
        }])
    }
});