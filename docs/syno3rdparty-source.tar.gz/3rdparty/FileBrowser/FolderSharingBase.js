/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _defineProperty(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}

function getModalWindow(e) {
    if (e) {
        if ("ModalWindow" === e.$options.name || "MessageBoxWindow" === e.$options.name || "WizardWindow" === e.$options.name) return e;
        var t = !0,
            r = !1,
            i = void 0;
        try {
            for (var o, s = e.$children[Symbol.iterator](); !(t = (o = s.next()).done); t = !0) {
                var n = o.value,
                    a = getModalWindow(n);
                if (a) return a
            }
        } catch (e) {
            r = !0, i = e
        } finally {
            try {
                t || null == s.return || s.return()
            } finally {
                if (r) throw i
            }
        }
    }
}

function inJsdom() {
    return navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom")
}

function _WFT(e, t) {
    try {
        return window.SYNO_FileStation_Strings ? window.SYNO_FileStation_Strings[e][t] : _TT("SYNO.SDS.App.FileStation3.Instance", e, t) || _T(e, t)
    } catch (e) {
        return SYNO.Debug.error(e), ""
    }
}
Ext.namespace("SYNO.SDS.BaseWindow"), Ext.define("SYNO.SDS.AbstractWindow", {
    extend: "Ext.Window",
    closeDisabled: !1,
    toolTarget: "toolCt",
    toolCtCls: "x-window-toolCt",
    toolTemplate: new Ext.XTemplate('<div class="x-tool x-tool-{id}" role="option" aria-label="{text}">&#160;</div>'),
    realHeight: void 0,
    realWidth: void 0,
    constructor: function(e) {
        var t = Ext.urlDecode(location.search.substr(1));
        this.enableAlertHeight = t.alertHeight;
        var r = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl() : Ext.getBody();
        e = Ext.apply({
            autoFitDesktopHeight: !1,
            maximizable: !0,
            minimizable: !0,
            closable: !0,
            width: 300,
            height: 300,
            constrain: !1,
            constrainHeader: !0,
            modal: !1,
            renderTo: r,
            manager: SYNO.SDS.WindowMgr
        }, e), SYNO.SDS.AbstractWindow.superclass.constructor.call(this, e), (this.constrain || this.constrainHeader) && this.resizer && (this.resizer.constrainTo = this.container), this.mon(this, "titlechange", this.onWindowTitleChanged, this)
    },
    initEvents: function() {
        if (SYNO.SDS.AbstractWindow.superclass.initEvents.apply(this, arguments), this.resizer) {
            var e = Ext.Resizable.positions;
            for (var t in e) this.resizer[e[t]] && this.mon(this.resizer[e[t]].el, "mousedown", this.toFront, this)
        }
        this.mon(this, "beforeclose", this._onClose, this), this.mon(this, "beforemaximize", this._onBeforeMaximize, this), this.mon(this, "maximize", this._onMaximize, this), this.mon(this, "minimize", this._onMinimize, this), this.mon(this, "restore", this._onRestore, this), this.mon(this, "activate", this._onActivate, this), this.mon(this, "deactivate", this._onDeactivate, this), this.header && this.mon(this.header, "contextmenu", this.onHeaderContextMenu, this)
    },
    _onClose: function() {
        return !this.closeDisabled && this.onClose.apply(this, arguments)
    },
    _onMaximize: function() {
        return this.onMaximize.apply(this, arguments)
    },
    _onBeforeMaximize: function() {
        return this.onBeforeMaximize.apply(this, arguments)
    },
    _onMinimize: function() {
        return this.onMinimize.apply(this, arguments)
    },
    _onRestore: function() {
        return this.onRestore.apply(this, arguments)
    },
    _onActivate: function() {
        return this.onActivate.apply(this, arguments)
    },
    _onDeactivate: function() {
        return this.onDeactivate.apply(this, arguments)
    },
    _onDragWindow: function(e) {
        SYNO.SDS.TaskBar
    },
    _endDragWindow: function(e, t) {
        SYNO.SDS.TaskBar && SYNO.SDS.TaskBar.toggleCollideOverlay(!1)
    },
    onClose: Ext.emptyFn,
    onMaximize: Ext.emptyFn,
    onBeforeMaximize: Ext.emptyFn,
    onMinimize: Ext.emptyFn,
    onRestore: Ext.emptyFn,
    onActivate: Ext.emptyFn,
    onDeactivate: Ext.emptyFn,
    onHeaderContextMenu: function(e) {
        e.preventDefault()
    },
    onShow: function() {
        this.removeClass("syno-window-hide"), delete this.hideForMinimize, this.enableAlertHeight && this.isVisible() && this.getHeight() > 580 && window.alert(String.format("Height: {0}px, Plz contact your PM to adjust UI.", this.getHeight())), this.tryConstrainHeight()
    },
    doConstrain: function() {
        var e, t;
        this.constrainHeader && (e = this.getSize(), t = this.el.getConstrainToXY(this.container, !0, void 0), t && (t[0] + e.width > this.container.getWidth() && (t[0] = this.container.getWidth() - e.width), this.setPosition(t[0], t[1])), this.tryConstrainHeight())
    },
    tryConstrainHeight: function() {
        if (this.realHeight = this.getHeight(), this.realWidth = this.getWidth(), !0 !== this.isWizard) {
            var e = Ext.getBody().getHeight();
            e < this.minHeight && (e = this.minHeight), this.constrainHeight(e)
        }
    },
    constrainHeight: function(e, t) {
        (this.isVisible() || Ext.isDefined(t)) && this.realHeight > e && (this.setHeight(e), this.heightConstrained = !0)
    },
    disableCloseButton: function() {
        var e = this.toolCt.child(".x-tool.x-tool-close");
        this.closeDisabled = !0, e && e.addClass("disabled")
    },
    enableCloseButton: function() {
        var e = this.toolCt.child(".x-tool.x-tool-close");
        this.closeDisabled = !1, e && e.removeClass("disabled")
    },
    _onCloseAction: function() {
        if (this.closeDisabled) return !1;
        this[this.closeAction].apply(this, arguments)
    },
    beforeDestroy: function() {
        this.onBeforeDestroy(), SYNO.SDS.AbstractWindow.superclass.beforeDestroy.apply(this, arguments)
    },
    setIcon: function(e) {
        this.header && this.header.setStyle("background-image", e ? "url(" + e + ")" : "")
    },
    onBeforeDestroy: function() {
        this.appInstance && this.appInstance.removeInstance(this)
    },
    open: function() {
        return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
    },
    onOpen: function() {
        this.minimized ? this.el.hide() : this.show()
    },
    onRequest: function() {
        if (!this.isVisible()) return void this.show();
        this.toFront()
    },
    onWindowTitleChanged: function(e, t) {
        this.rendered && this.focusEl instanceof Ext.Element && this.focusEl.set({
            "aria-label": Ext.util.Format.stripTags(t)
        })
    },
    getSizeAndPosition: function() {
        var e, t = {};
        return this.maximized || this.hidden ? (this.draggable && this.restorePos ? (t.x = this.restorePos[0], t.y = this.restorePos[1]) : (t.x = this.x, t.y = this.y), this.resizable && (this.restoreSize ? (t.width = this.restoreSize.width, t.height = this.restoreSize.height) : (t.width = this.width, t.height = this.height))) : (e = this.el.origXY || this.getPosition(!1), t.pageX = e[0], t.pageY = e[1], this.resizable && (t.width = this.getWidth(), t.height = this.getHeight())), t
    },
    setResizable: function(e) {
        this.el[e ? "removeClass" : "addClass"]("no-resize")
    },
    getConstrainSize: function() {
        var e = this.getSize();
        return e.width < this.minWidth && (e.width = this.minWidth), e.height < this.minHeight && (e.height = this.minHeight), e
    },
    maximize: function() {
        return this.maximized || (this.fireEvent("beforemaximize", this), this.expand(!1), this.restoreSize = this.getConstrainSize(), this.restorePos = this.getPosition(!0), this.maximizable && (this.tools.maximize.hide(), this.tools.restore.show()), this.maximized = !0, this.el.disableShadow(), this.dd && this.dd.lock(), this.collapsible && this.tools.toggle.hide(), this.el.addClass("x-window-maximized"), this.container.addClass("x-window-maximized-ct"), SYNO.SDS.TaskBar && this.setPosition(0, this.isFullScreen ? 0 : SYNO.SDS.TaskBar.height()), this.fitContainer(), this.fireEvent("maximize", this)), this
    },
    fitContainer: function() {
        var e = this.container.getViewSize(!1);
        SYNO.SDS.TaskBar && !this.isFullScreen ? this.setSize(e.width, e.height - SYNO.SDS.TaskBar.height()) : this.setSize(e.width, e.height)
    },
    setTitle: function(e, t, r) {
        return this.titleEncoded = r, this.title = e, !1 !== r && (e = Ext.util.Format.htmlEncode(e)), this.header && this.headerAsText && this.header.child("span").update(e), t && this.setIconClass(t), this.fireEvent("titlechange", this, this.title), this
    },
    getStateParam: function() {
        var e = {};
        return (this.maximized || this.hidden) && (e.maximized = this.maximized, e.minimized = this.hidden), e
    },
    getToolSelectedEl: function() {
        var e = this.toolCt.dom.getAttribute("aria-activedescendant");
        return e ? Ext.get(e) : null
    },
    selectToolNext: function() {
        var e, t = this.getToolSelectedEl();
        if (!t) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.first().id
        }), void this.toolCt.first().addClass("x-tool-selected");
        for (e = t.next(); e && !e.isVisible();) e = e.next();
        e && (t.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": e.id
        }), e.addClass("x-tool-selected"))
    },
    selectToolPre: function() {
        var e, t = this.getToolSelectedEl();
        if (!t) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.last().id
        }), void this.toolCt.last().addClass("x-tool-selected");
        for (e = t.prev(); e && !e.isVisible();) e = e.prev();
        e && (t.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": e.id
        }), e.addClass("x-tool-selected"))
    },
    onToolCtKenEnter: function() {
        var e = this.getToolSelectedEl();
        e && e.handler.call(this)
    },
    addTool: function() {
        if (this.rendered && !this.toolCt && this.header && (this.elements += ",toolCt", this.toolCt = this.header.createChild({
                cls: "x-window-toolCt"
            }, this.header.first("." + this.headerTextCls, !0)), this.toolCt.setARIA({
                role: "listbox",
                label: _T("desktop", "window_toolbar_list"),
                activedescendant: "false"
            }), this.toolCt.addKeyListener(Ext.EventObject.LEFT, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.RIGHT, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.DOWN, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.UP, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.ENTER, this.onToolCtKenEnter, this)), this.callParent(arguments), this.rendered && this.header) {
            var e, t = arguments,
                r = t.length,
                i = this.tools;
            for (e = 0; e < r; e++) {
                var o = t[e];
                i[o.id].handler || (i[o.id].handler = o.handler)
            }
        }
    },
    createGhost: function(e, t, r) {
        var i = document.createElement("div");
        if (i.className = "x-panel-ghost " + (e || ""), this.header && i.appendChild((this.tl || this.el.dom.firstChild).cloneNode(!0)), Ext.fly(i.appendChild(document.createElement("ul"))).setHeight(this.bwrap.getHeight()), i.style.width = this.el.dom.offsetWidth + "px", r ? Ext.getDom(r).appendChild(i) : this.container.dom.appendChild(i), !1 !== t && !1 !== this.el.useShim) {
            var o = new Ext.Layer({
                shadow: !1,
                useDisplay: !0,
                constrain: !1
            }, i);
            return o.show(), o
        }
        return new Ext.Element(i)
    },
    initTools: function() {
        this.minimizable && this.addTool({
            id: "minimize",
            text: _T("desktop", "minimize"),
            handler: this.minimize.createDelegate(this, [])
        }), this.maximizable && (this.addTool({
            id: "maximize",
            text: _T("desktop", "maximize"),
            handler: this.maximize.createDelegate(this, [])
        }), this.addTool({
            id: "restore",
            text: _T("destop", "restore"),
            handler: this.restore.createDelegate(this, []),
            hidden: !0
        })), this.closable && this.addTool({
            id: "close",
            text: _T("common", "close"),
            handler: this._onCloseAction.createDelegate(this, [])
        })
    },
    openVueWindow: function(e, t) {
        var r, i, o;
        if (Ext.isString(e)) {
            r = Ext.getClassByName(e)
        } else r = e;
        if (r._isVue) o = i = r, document.querySelector("#sds-desktop").appendChild(r.$el);
        else {
            var s = document.createElement("div");
            o = new r({
                propsData: t
            }), SYNO.SDS.Desktop && o && SYNO.SDS.Desktop.appendChild(o), document.querySelector("#sds-desktop").appendChild(s), o.$mount(s), i = getModalWindow(o)
        }
        return i.setOwner(this), i.init(), this.modalWin.push(i), {
            window: i,
            component: o
        }
    }
}), SYNO.SDS.BaseWindow = Ext.extend(SYNO.SDS.AbstractWindow, {
    maskCnt: 0,
    maskTask: null,
    siblingWin: null,
    sinkModalWin: null,
    modalWin: null,
    msgBox: null,
    dsmStyle: "v5",
    owner: null,
    useDefualtKey: !0,
    onEsc: function() {
        !1 !== this.useDefualtKey && SYNO.SDS.BaseWindow.superclass.onEsc.apply(this, arguments)
    },
    constructor: function(e) {
        var t, r = !!e.owner;
        this.siblingWin = [], this.modalWin = [], this.sinkModalWin = [], this.updateDsmStyle(e), e.useStatusBar && (e = this.addStatusBar(e)), t = Ext.urlDecode(location.search.substr(1)), t.dsmStyle && (this.dsmStyle = t.dsmStyle), e.cls = String.format("{0}{1}", e.cls ? e.cls : "", this.isV5Style() ? " sds-window-v5" : " sds-window"), this.fillPadding(e), SYNO.SDS.BaseWindow.superclass.constructor.call(this, Ext.applyIf(e, {
            border: !0,
            plain: !1,
            shadow: !this.isV5Style() && !SYNO.SDS.UIFeatures.test("disableWindowShadow") && "frame",
            shadowOffset: 6,
            closeAction: "close"
        })), !r || e.owner instanceof SYNO.SDS.BaseWindow || e.owner._isVue || SYNO.Debug.warn(String.format('WARNING! owner of window "{0}" is not BaseWindow', this.title || this.id)), this.mon(this, "hide", this.restoreWindowFocus, this)
    },
    findTopWin: function() {
        for (var e, t = !1, r = this; !1 === t;)
            if (Ext.isArray(r.modalWin) && r.modalWin.length > 0)
                for (e = r.modalWin.length - 1; e >= 0; e--) {
                    if (r.modalWin[e] && !(r.modalWin[e].hidden || r.modalWin[e].isDestroyed || r.modalWin[e].destroying)) {
                        r = r.modalWin[e];
                        break
                    }
                    0 === e && (t = !0)
                } else t = !0;
        return r
    },
    restoreWindowFocus: function() {
        !0 !== this.focusLeave && SYNO.SDS.FocusMgr && (SYNO.SDS.FocusMgr.focusActiveWindow(), this.focusLeave = !0)
    },
    focusLastWindowPt: function() {
        var e, t = this.findTopWin();
        if (!(e = t.focusStack)) return void t.focusEl.focus();
        var r, i, o = !1;
        for (r = e.length - 1; r >= 0 && !0 !== o; r--)(i = Ext.fly(e[r])) && i.dom && i.isVisible() && -1 !== i.dom.getAttribute("tabIndex") && (i.focus(), o = !0);
        o || (this.focusEl.focus(), i = this.focusEl), t.focusStack = [i.dom]
    },
    addFocusPt: function() {
        var e, t = document.activeElement;
        t && Ext.fly(t).up(".x-window") && (e = this.findTopWin(), e.focusStack || (e.focusStack = []), e.focusStack.push(t))
    },
    updateDsmStyle: function(e) {
        Ext.isDefined(e) && (e.dsmStyle ? this.dsmStyle = e.dsmStyle : e.owner && this.setToOwnerDsmStyle(e.owner))
    },
    getDsmStyle: function() {
        return this.dsmStyle
    },
    isV5Style: function() {
        return "v5" === this.getDsmStyle()
    },
    setToOwnerDsmStyle: function(e) {
        Ext.isFunction(e.getDsmStyle) && (this.dsmStyle = e.getDsmStyle())
    },
    addStatusBar: function(e) {
        var t = {
            xtype: "statusbar",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: []
        };
        return this.isV5Style() && (t.defaults = {
            xtype: "syno_button",
            btnStyle: "grey"
        }), e.buttons && (t.items = t.items.concat(e.buttons), delete e.buttons), Ext.applyIf(e, {
            fbar: t
        }), e
    },
    createGhost: function(e, t, r) {
        if (this.isV5Style() && (e += " sds-window-v5"), SYNO.SDS.UIFeatures.test("windowGhost")) return SYNO.SDS.BaseWindow.superclass.createGhost.apply(this, arguments);
        var i = this.el.dom,
            o = document.createElement("div"),
            s = o.style;
        return o.className = "x-panel-ghost-simple", s.width = i.offsetWidth + "px", s.height = i.offsetHeight + "px", r ? Ext.getDom(r).appendChild(o) : this.container.dom.appendChild(o), new Ext.Element(o)
    },
    isModalized: function() {
        return !1
    },
    hasOwnerWin: function(e) {
        var t = this;
        do {
            if (e === t) return !0;
            t = t._isVue ? t.$options.owner : t.owner
        } while (t);
        return !1
    },
    getTopWin: function() {
        for (var e = this, t = this; e;) t = e, e = e._isVue ? e.$options.owner : e.owner;
        return t
    },
    getGroupWinAccessTime: function() {
        var e = this._lastAccess || 0;
        return Ext.each(this.modalWin, function(t) {
            t && t._lastAccess && t._lastAccess > e && (e = t._lastAccess)
        }), Ext.each(this.siblingWin, function(t) {
            t && t._lastAccess && t._lastAccess > e && (e = t._lastAccess)
        }), e
    },
    getMsgBox: function(e) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            var t = e && e.owner || this;
            t = t.isDestroyed ? null : t, this.isV5Style() ? this.msgBox = new SYNO.SDS.MessageBoxV5({
                owner: t,
                preventDelay: !!e && (e.preventDelay || !1),
                draggable: !!e && (e.draggable || !1)
            }) : this.msgBox = new SYNO.SDS.MessageBox({
                owner: t
            })
        }
        return this.msgBox.getWrapper(e)
    },
    confirmLeave: function(e) {
        var t = {
            yes: {
                text: _T("common", "leave")
            },
            cancel: !0
        };
        this.getMsgBox().confirm("", _T("common", "confirm_lostchange"), e, this, t)
    },
    confirmLostChangePromise: function(e, t, r, i, o) {
        var s, n = {};
        if (Ext.isFunction(e)) s = e;
        else {
            if (!Ext.isObject(e)) return void SYNO.Debug.error("func should be object(for promise) or function(for callback)");
            n = e
        }
        var a = n.save,
            l = n.dontSave,
            c = n.cancel,
            u = n.confirmText;
        r = r || Ext.emptyFn, i = i || Ext.emptyFn, o = o || Ext.emptyFn, this.getMsgBox().confirm("", u || _T("common", "confirm_lostchange_without_save"), s || function(e) {
            Ext.isFunction(r) && r.apply(t, []), "yes" === e ? this.confirmLostChangeCallback(a, i, t) : "cancel" === e ? this.confirmLostChangeCallback(c, o, t) : "leftCustom" === e && this.confirmLostChangeCallback(l, i, t)
        }.bind(this), this, {
            yes: _T("common", "save"),
            cancel: !0,
            leftCustom: {
                text: _T("common", "dont_save"),
                extraStyle: "syno-ux-button-dontsave"
            }
        })
    },
    confirmLostChangeCallback: function(e, t, r) {
        if (!Ext.isFunction(e)) return void SYNO.Debug.error("Callback should be callable");
        var i = e.apply(r, []);
        i && i.then && Ext.isFunction(i.then) || (i = Promise.resolve()), i.then(function(e) {
            Ext.isFunction(t) && t.apply(r, [])
        }.bind(r)).catch(function(e) {}.bind(r))
    },
    getToastBox: function(e, t, r, i) {
        this.toastBox && !this.toastBox.isDestroyed && this.toastBox.destroy();
        var o = {
            text: e,
            closable: t,
            owner: this
        };
        return Ext.isObject(r) && (Ext.isString(r.text) && (o.actionText = r.text), Ext.isFunction(r.fn) && (o.actionHandler = r.fn), Ext.isObject(r.scope) && (o.actionHandlerScope = r.scope)), Ext.isObject(i) && (Ext.isNumber(i.delay) && (o.delay = i.delay), Ext.isNumber(i.offsetY) && (o.offsetY = i.offsetY), Ext.isNumber(i.offsetX) && (o.offsetX = i.offsetX), Ext.isDefined(i.alignEl) && (o.alignEl = i.alignEl), o.alignBottom = !0 === i.alignBottom), this.toastBox = new SYNO.SDS.ToastBox(o), this.toastBox
    },
    onBeforeDestroy: function() {
        function e(e) {
            e && e.destroy()
        }
        this.msgBox && this.msgBox.destroy(), this.toastBox && this.toastBox.destroy(), Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e), delete this.msgBox, delete this.modalWin, delete this.siblingWin, delete this.maskTask, SYNO.SDS.BaseWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        function e(e) {
            e && (e.hideForMinimize = !0, e.minimize())
        }
        SYNO.SDS.BaseWindow.superclass.onMinimize.apply(this, arguments), Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e)
    },
    applyToAllWindows: function(e) {
        Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e)
    },
    addClassToAllWindows: function(e) {
        function t(t) {
            t.addClassToAllWindows(e)
        }
        this.el.addClass(e), this.applyToAllWindows(t)
    },
    removeClassFromAllWindows: function(e) {
        function t(t) {
            t.removeClassFromAllWindows(e)
        }
        this.el.removeClass(e), this.applyToAllWindows(t)
    },
    disableAllShadow: function() {
        function e(e) {
            e.disableAllShadow()
        }
        this.el.disableShadow(), this.applyToAllWindows(e)
    },
    onClose: function() {
        function e(e) {
            return !e || (e.close(), e.isDestroyed)
        }
        var t;
        return Ext.each(this.modalWin, e), Ext.each(this.sinkModalWin, e), this.modalWin.length || Ext.each(this.siblingWin, e), t = !this.modalWin.length && !this.siblingWin.length, t && (t = !1 !== SYNO.SDS.BaseWindow.superclass.onClose.apply(this, arguments)), t
    },
    onActivate: function() {
        var e = this.getTopWin();
        e.taskButton && e.taskButton.setState("active"), this.el.replaceClass("deactive-win", "active-win"), SYNO.SDS.BaseWindow.superclass.onActivate.apply(this, arguments)
    },
    onDeactivate: function() {
        var e = this.getTopWin();
        e.taskButton && e.taskButton.setState("deactive"), this.el.replaceClass("active-win", "deactive-win"), SYNO.SDS.BaseWindow.superclass.onDeactivate.apply(this, arguments), this.el && this.el.enableShadow(!0)
    },
    blinkShadow: function(e) {
        if (this.isV5Style()) return this.blinkShadowV5(e);
        !this.shadow || e <= 0 || (this.el.disableShadow(), function() {
            this.el.enableShadow(!0), this.blinkShadow.createDelegate(this, [--e]).defer(100)
        }.createDelegate(this).defer(100))
    },
    blinkShadowV5: function(e) {
        !this.el || !this.el.isVisible() || e <= 0 || (this.el.addClass("sds-window-v5-no-shadow"), function() {
            this.el && this.el.isVisible() && (this.el.removeClass("sds-window-v5-no-shadow"), this.blinkShadowV5.createDelegate(this, [--e]).defer(100))
        }.createDelegate(this).defer(100))
    },
    synchronizedMask: function(e) {
        this.mask(e)
    },
    delayedMask: function(e, t) {
        t = Ext.isNumber(t) ? t : 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [e])), this.mask(0), this.maskTask.delay(t)
    },
    setMaskOpacity: function(e) {
        if (this.el.dom) {
            var t = Ext.Element.data(this.el.dom, "mask");
            t && t.setOpacity(e)
        }
    },
    mask: function(e, t, r, i) {
        if (!this.isDestroyed) {
            if (e = Ext.isNumber(e) ? e : 0, ++this.maskCnt > 1) return void this.setMaskOpacity(e, i);
            var o = this.el.mask(t, r);
            o.addClass("sds-window-mask"), this.mon(o, "mousedown", this.blinkModalChild, this), this.setMaskOpacity(e, i)
        }
    },
    unmask: function() {
        if (!(this.isDestroyed || --this.maskCnt > 0)) {
            this.maskCnt = 0, this.maskTask && this.maskTask.cancel();
            var e = Ext.Element.data(this.el, "mask");
            this.mun(e, "mousedown", this.blinkModalChild, this), this.el.unmask()
        }
    },
    blinkModalChild: function() {
        if (SYNO.SDS.WindowMgr) {
            this.modalWin.sort(SYNO.SDS.WindowMgr.sortWindows);
            var e = this.modalWin[this.modalWin.length - 1];
            if (!e) return void(this.isModalized() && (this.toFront(), this.blinkShadow(3)));
            e.blinkModalChild()
        }
    },
    clearStatus: function(e) {
        var t = this.getFooterToolbar();
        t && Ext.isFunction(t.clearStatus) && t.clearStatus(e)
    },
    clearStatusBusy: function(e) {
        this.unmask(), 0 === this.maskCnt && this.clearStatus(e)
    },
    setStatus: function(e) {
        e = e || {};
        var t = this.getFooterToolbar();
        t && Ext.isFunction(t.setStatus) && t.setStatus(e)
    },
    setStatusOK: function(e) {
        e = e || {}, Ext.applyIf(e, {
            text: _T("common", "setting_applied"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-success" : "x-status-valid",
            clear: !0
        }), this.setStatus(e)
    },
    setStatusError: function(e) {
        e = e || {}, Ext.applyIf(e, {
            text: _T("common", "error_system"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-error" : "x-status-error"
        }), this.setStatus(e)
    },
    setStatusBusy: function(e, t, r) {
        e = e || {}, Ext.applyIf(e, {
            text: _T("common", "loading"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-loading" : "x-status-busy"
        }), this.setStatus(e), this.maskForBusy(t, r)
    },
    maskForBusy: function(e, t) {
        e = Ext.isNumber(e) ? e : .4, t = Ext.isNumber(t) ? t : 400, t > 0 ? this.delayedMask(e, t) : this.synchronizedMask(e)
    },
    hide: function() {
        this.maximized || (this.restoreSize = this.getSize(), this.restorePos = this.getPosition(!0)), this.addClass("syno-window-hide"), SYNO.SDS.BaseWindow.superclass.hide.apply(this, arguments)
    },
    centerTitle: function() {
        var e, t = 0,
            r = ["help", "minimize", "maximize", "close"];
        this.tools && (Ext.each(r, function(e) {
            this.tools[e] && (t += 32)
        }, this), this.header && (e = this.header.child(".x-window-header-text")) && e.setStyle("padding-left", t + "px"))
    },
    fillPadding: function(e) {
        var t;
        return t = this.getFirstItem(e), t ? this.isGridPanel(t) || this.isFormPanel(t) ? void this.fillWindowPadding(e) : this.isTabPanel(t) && this.hasItems(t) ? void this.fillWindowPadding(e) : void 0 : e
    },
    hasItems: function(e) {
        return !!Ext.isArray(e.items) || e.items instanceof Ext.util.MixedCollection
    },
    fillWindowPadding: function(e) {
        Ext.applyIf(e, {
            padding: "16px 16px 0 16px"
        })
    },
    getFirstItem: function(e) {
        var t;
        return Ext.isArray(e.items) && 1 === e.items.length ? t = e.items[0] : Ext.isObject(e.items) && (t = e.items), t
    },
    isTabPanel: function(e) {
        return this.isPanelOf(e, Ext.TabPanel, ["tabpanel", "syno_tabpanel"])
    },
    isFormPanel: function(e) {
        return this.isPanelOf(e, Ext.form.FormPanel, ["form", "syno_formpanel"])
    },
    isGridPanel: function(e) {
        return this.isPanelOf(e, Ext.grid.GridPanel, ["grid", "syno_gridpanel"])
    },
    isPanelOf: function(e, t, r) {
        var i, o, s;
        if (!e) return !1;
        if (e instanceof t) return !0;
        for (i = e.xtype, o = 0, s = r.length; o < s; o++)
            if (i === r[o]) return !0;
        return !1
    },
    destroy: function() {
        this.isDestroyed || !1 !== this.fireEvent("beforedestroy", this) && (this.destroying = !0, this.focusStack && (this.focusStack = null), this.restoreWindowFocus(), SYNO.SDS.BaseWindow.superclass.destroy.call(this))
    }
}), Ext.namespace("SYNO.SDS.Window"), SYNO.SDS.Window = Ext.extend(SYNO.SDS.BaseWindow, {
    constructor: function(e) {
        e = Ext.apply({
            minimizable: !1
        }, e), SYNO.SDS.Window.superclass.constructor.call(this, e), this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.push(this)
    },
    onBeforeDestroy: function() {
        this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.remove(this), SYNO.SDS.Window.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        this.hide(), SYNO.SDS.Window.superclass.onMinimize.apply(this, arguments)
    },
    isAlwaysOnTop: function() {
        return _S("standalone")
    }
}), Ext.namespace("SYNO.SDS"), Ext.namespace("SYNO.SDS.Utils"), SYNO.SDS.emptyFn = function() {}, SYNO.SDS.isFunction = function(e) {
    return "[object Function]" === Object.prototype.toString.apply(e)
}, SYNO.SDS.isDefined = function(e) {
    return void 0 !== e
}, SYNO.SDS.GetBody = function() {
    return document.body || document.documentElement
}, SYNO.SDS.Utils.UserAgent = function() {
    var e = navigator.userAgent.toLowerCase(),
        t = function(t) {
            return t.test(e)
        },
        r = {};
    return r.isEdge = t(/edge/), r.isOpera = t(/opera/), r.isChrome = !r.isEdge && t(/\bchrome\b/), r.isWebKit = !r.isEdge && t(/webkit/), r.isSafari = !(r.isChrome || r.isEdge) && t(/safari/), r.isSafari2 = r.isSafari && t(/applewebkit\/4/), r.isSafari3 = r.isSafari && t(/version\/3/), r.isSafari4 = r.isSafari && t(/version\/4/), r.isSafari5 = r.isSafari && t(/version\/5/), r.isSafari5_0 = r.isSafari && t(/version\/5.0/), r.isGecko = !(r.isWebKit || r.isIE11 || r.isEdge) && t(/gecko/), r.isGecko2 = r.isGecko && t(/rv:1\.8/), r.isGecko3 = r.isGecko && t(/rv:1\.9/), r.isIE = !r.isOpera && t(/msie/), r.isTrident7 = t(/trident\/7/), r.isIE11 = r.isTrident7, r.isIE12 = t(/edge\/(\d+)./), r.isIE10 = r.isIE && (t(/msie 10/) || t(/trident\/6/)), r.isTrident6 = r.isIE && t(/trident\/6/), r.isIE10Touch = r.isTrident6 && t(/touch;/), r.isIE9 = r.isIE && t(/trident\/5/), r.isIE8 = r.isIE && !r.isIE9 && !r.isIE10 && !r.isIE11 && t(/trident/), r.isIE7 = r.isIE && !r.isIE8 && !r.isIE9 && !r.isIE10 && !r.isIE11 && t(/msie 7/), r.isIE6 = r.isIE && !r.isIE7 && !r.isIE8 && !r.isIE9 && !r.isIE10 && !r.isIE11 && t(/msie 6/), r.isModernIE = r.isIE12 || r.isIE11 || r.isIE && !r.isIE6 && !r.isIE7 && !r.isIE8, r.isIE9m = r.isIE && (r.isIE6 || r.isIE7 || r.isIE8 || r.isIE9), r.isBorderBox = r.isIE9m && !r.isStrict, r.isWindows = t(/windows|win32/), r.isMac = t(/macintosh|mac os x/), r.isAir = t(/adobeair/), r.isLinux = t(/linux/), r
}(), SYNO.SDS.Utils.GetURLParam = function(e, t) {
    var r, i, o = e.split("&"),
        s = decodeURIComponent,
        n = {};
    return o.forEach(function(e) {
        e = e.split("="), r = s(e[0]), i = s(e[1]), n[r] = t || !n[r] ? i : [].concat(n[r]).concat(i)
    }), n
}, Ext.define("SYNO.SDS.IEUpgradeAlert", {
    extend: "SYNO.SDS.Window",
    constructor: function() {
        var e = {
            cls: "ie-upgrade-alert",
            width: 450,
            height: 230,
            maximizable: !1,
            title: _D("manager"),
            items: [{
                xtype: "syno_formpanel",
                name: "ie_alert_form",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("desktop", "upgrade_ie_browser")
                }, {
                    name: "skip_alert",
                    xtype: "syno_checkbox",
                    checked: !1,
                    boxLabel: _T("common", "dont_alert_again")
                }]
            }],
            fbar: {
                toolbarCls: "x-panel-fbar x-statusbar",
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: function() {
                        var e = this.find("name", "skip_alert")[0],
                            t = new Date;
                        !0 === e.getValue() && Ext.util.Cookies.set("skip_upgrade_ie_alert", !0, t.add(Date.YEAR, 1)), this.close()
                    },
                    scope: this
                }]
            }
        };
        this.callParent([e])
    }
}), SYNO.SDS.HTML5Utils = function() {
    var e = window.XMLHttpRequest ? new XMLHttpRequest : {},
        t = SYNO.SDS.Utils.UserAgent;
    return {
        HTML5Progress: !!e.upload,
        HTML5SendBinary: !(!e.sendAsBinary && !e.upload),
        HTML5ReadBinary: !!(window.FileReader || window.File && window.File.prototype.getAsBinary),
        HTML5Slice: !(!window.File || !(window.File.prototype.slice || window.File.prototype.mozSlice || window.File.prototype.webkitSlice)),
        isSupportHTML5Upload: function() {
            return (t.isChrome || !t.isSafari4 && !t.isSafari5_0 && !(t.isWindows && t.isSafari) && !t.isGecko3 && !t.isOpera) && (!!window.FormData || SYNO.SDS.HTML5Utils.HTML5SendBinary && SYNO.SDS.HTML5Utils.HTML5ReadBinary && SYNO.SDS.HTML5Utils.HTML5Slice)
        },
        isDragFile: function(e) {
            try {
                if (t.isWebKit) {
                    return e.dataTransfer.types && -1 != e.dataTransfer.types.indexOf("Files")
                }
                if (t.isGecko) return e.dataTransfer.types.contains && e.dataTransfer.types.contains("application/x-moz-file") || 0 <= e.dataTransfer.types.indexOf("application/x-moz-file");
                if (t.isIE10 || t.isModernIE) return e.dataTransfer.files && e.dataTransfer.types && e.dataTransfer.types.contains("Files")
            } catch (e) {
                SYNO.Debug.log("Error in isDragFile")
            }
            return !1
        }
    }
}(), SYNO.SDS.UpdateSynoToken = function(e) {
    Ext.Ajax.request({
        url: "webapi/entry.cgi?api=SYNO.API.Auth&version=6&method=token",
        updateSynoToken: !0,
        callback: function(t, r, i) {
            var o = Ext.util.JSON.decode(i.responseText);
            r && o.data && !Ext.isEmpty(o.data.synotoken) && (SYNO.SDS.Session.SynoToken = encodeURIComponent(o.data.synotoken), synowebapi && synowebapi.env.setSynoToken(SYNO.SDS.Session.SynoToken)), Ext.isFunction(e) && e(t, r)
        }
    })
}, SYNO.SDS.UIFeatures = function() {
    var e, t, r = SYNO.SDS.Utils.UserAgent,
        i = {
            previewBox: !r.isIE || r.isModernIE,
            expandMenuHideAll: !0,
            windowGhost: !r.isIE || r.isModernIE,
            disableWindowShadow: r.isIE && !r.isModernIE,
            exposeWindow: !r.isIE || r.isIE10p,
            msPointerEnabled: window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isTouch: "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isRetina: function() {
                var e = !1;
                return window.devicePixelRatio >= 1.5 && (e = !0), window.matchMedia && window.matchMedia("(-webkit-min-device-pixel-ratio: 1.5),(min--moz-device-pixel-ratio: 1.5),(-o-min-device-pixel-ratio: 3/2),(min-resolution: 1.5dppx)").matches && (e = !0), e
            }(),
            isSupportFullScreen: document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled
        },
        o = SYNO.SDS.Utils.GetURLParam(location.search.substr(1));
    for (e in o) o.hasOwnProperty(e) && (t = o[e], void 0 !== i[e] && (i[e] = "false" !== t));
    return {
        test: function(e) {
            return !!i[e]
        },
        listAll: function() {
            var e, t = "== Feature List ==\n";
            for (e in i) i.hasOwnProperty(e) && (t += String.format("{0}: {1}\n", e, i[e]));
            return t
        },
        isFullScreenMode: function() {
            return !!(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
        }
    }
}(), SYNO.SDS.UIFeatures.IconSizeManager = {
    PortalIcon: 64,
    GroupView: 24,
    Taskbar: 24,
    WidgetHeader: 32,
    GroupViewHover: 48,
    Desktop: 64,
    ClassicalDesktop: 48,
    AppView: 72,
    AppViewClassic: 48,
    Header: 24,
    HeaderV4: 16,
    TreeIcon: 16,
    StandaloneHeader: 24,
    FavHeader: 16,
    FinderPreview: 128,
    isEnableHDPack: !1,
    cls: "synohdpack",
    debugCls: "synohdpackdebug",
    getAppPortalIconPath: function(e) {
        var t = this.isRetinaMode(),
            r = t ? 256 : this.PortalIcon,
            i = t ? "2x" : "1x";
        return String.format(e, r, i)
    },
    getIconPath: function(e, t, r) {
        var i, o, s = this.isRetinaMode(),
            n = function(e, t, r, i) {
                return e.replace(t, "48" === t ? "128" : 2 * t)
            },
            a = function(e, t, r, i) {
                return e.replace(t, "48" === t ? "128" : 2 * t)
            };
        if (0 === e.indexOf("webman/3rdparty/")) {
            s = "FavHeader" !== t && s;
            return String.format("webapi/entry.cgi?api=SYNO.Core.Synohdpack&version=1&method=getHDIcon&res={0}&retina={1}&path={2}", this.getRes(t), s, e)
        }
        switch (-1 === e.indexOf("{1}") ? s ? (r = r || !1, o = r || -1 !== e.indexOf("shortcut_icons") || -1 !== e.indexOf("webfm/images") ? e : 0 === e.indexOf("webman/") ? "/synohdpack/images/dsm/" + e.substr("webman/".length) : "/synohdpack/images/dsm/" + e) : o = e : o = e.replace("{1}", s ? "2x" : "1x"), t) {
            case "Taskbar":
                i = String.format(o, s ? 2 * this.Taskbar : this.Taskbar);
                break;
            case "Desktop":
                -1 != o.indexOf("files_ext_48") && "classical" != SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle") && (o = o.replace("files_ext_48", "files_ext_64")), -1 != o.indexOf("files_ext_") ? (o = o.replace(/webfm\/images/, s ? "images/2x" : "images/1x"), i = s ? o.replace(/.*\/files_ext_(\d+)\/.*/, n) : o) : -1 != o.indexOf("shortcut_icons") ? (o = o.replace(/images\/default\/.+\/shortcut_icons/, s ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), i = s ? o.replace(/.*\/.*_(\d+)\.png$/, a) : o) : i = String.format(o, s ? 256 : this.Desktop);
                break;
            case "ClassicalDesktop":
                -1 != o.indexOf("files_ext_") ? (o = o.replace(/webfm\/images/, s ? "images/2x" : "images/1x"), i = s ? o.replace(/.*\/files_ext_(\d+)\/.*/, n) : o) : -1 != o.indexOf("shortcut_icons") ? (o = o.replace(/images\/default\/.+\/shortcut_icons/, s ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), i = s ? o.replace(/.*\/.*_(\d+)\.png$/, a) : o) : i = String.format(o, s ? 256 : this.ClassicalDesktop);
                break;
            case "AppView":
                i = String.format(o, s ? 256 : this.AppView);
                break;
            case "AppViewClassic":
                i = String.format(o, s ? 256 : this.AppViewClassic);
                break;
            case "Header":
                i = String.format(o, s ? 2 * this.Header : this.Header);
                break;
            case "HeaderV4":
                i = String.format(o, s ? 2 * this.HeaderV4 : this.HeaderV4);
                break;
            case "StandaloneHeader":
                i = String.format(o, s ? 2 * this.StandaloneHeader : this.StandaloneHeader);
                break;
            case "FavHeader":
                i = String.format(o, s ? 2 * this.FavHeader : this.FavHeader);
                break;
            case "FileType":
                i = s ? o.replace(/.*\/files_ext_(\d+)\/.*/, n) : o;
                break;
            case "TreeIcon":
                i = String.format(o, s ? 3 * this.TreeIcon : this.TreeIcon);
                break;
            case "FinderPreview":
                i = String.format(o, s ? 256 : 128);
                break;
            case "WidgetHeader":
                i = String.format(o, s ? 2 * this.WidgetHeader : this.WidgetHeader);
                break;
            default:
                i = o
        }
        return -1 == i.indexOf(String.format("?v={0}", _S("fullversion"))) && ".png" === i.substr(i.length - 4) && (i += "?v=" + _S("fullversion")), i = encodeURI(i)
    },
    enableHDDisplay: function(e) {
        SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = e
    },
    isRetinaMode: function() {
        return SYNO.SDS.UIFeatures.test("isRetina") && this.isEnableHDPack
    },
    getRetinaAndSynohdpackStatus: function() {
        return SYNO.Debug("SYNO.SDS.UIFeatures.IconSizeManager.getRetinaAndSynohdpackStatus() was renamed, please call SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() instead."), this.isRetinaMode()
    },
    addHDClsAndCSS: function() {
        var e = !1;
        SYNO.SDS.UIFeatures.test("isRetina") && (document.documentElement.classList.add(this.cls), e = !0), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = e
    },
    enableRetinaDisplay: function() {
        document.documentElement.classList.remove(this.debugCls), document.documentElement.classList.add(this.cls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
    },
    enableRetinaDebugMode: function() {
        document.documentElement.classList.remove(this.cls), document.documentElement.classList.add(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
    },
    disableRetinaDisplay: function() {
        document.documentElement.classList.remove(this.cls), document.documentElement.classList.remove(this.debugCls),
            SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !1
    },
    getRes: function(e) {
        return this[e] ? this[e] : -1
    }
}, Ext.namespace("SYNO.SDS.Gesture"), SYNO.SDS.Gesture.EmptyGesture = Ext.extend(Ext.util.Observable, {
    onTouchStart: Ext.emptyFn,
    onTouchMove: Ext.emptyFn,
    onTouchEnd: Ext.emptyFn,
    onTouchCancel: Ext.emptyFn
}), SYNO.SDS.Gesture.BaseGesture = Ext.extend(SYNO.SDS.Gesture.EmptyGesture, {
    constructor: function() {
        SYNO.SDS.Gesture.BaseGesture.superclass.constructor.apply(this, arguments)
    },
    getBrowserEvent: function(e) {
        return e && e.browserEvent ? e.browserEvent : null
    },
    getFirstTouch: function(e) {
        var t, r = null;
        return t = this.getBrowserEvent(e), t && t.touches && t.touches.length > 0 && (r = t.touches[0]), r
    },
    getFirstChangedTouch: function(e) {
        var t, r = null;
        return t = this.getBrowserEvent(e), t && t.changedTouches && t.changedTouches.length > 0 && (r = t.changedTouches[0]), r
    },
    getChangedTouchCount: function(e) {
        var t;
        return t = this.getBrowserEvent(e), t && t.changedTouches && Ext.isNumber(t.changedTouches.length) ? t.changedTouches.length : -1
    },
    getTouchCount: function(e) {
        var t;
        return t = this.getBrowserEvent(e), t && t.touches && Ext.isNumber(t.touches.length) ? t.touches.length : -1
    }
}), SYNO.SDS.Gesture.Swipe = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDistance: 80,
        maxOffset: 100,
        maxDuration: 1e3
    },
    fireSwipe: function(e, t, r, i, o) {
        SYNO.SDS.GestureMgr.fireEvent("swipe", e, t, r, i, o)
    },
    getMinDistance: function() {
        return this.config.minDistance
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    setInitialXY: function(e) {
        var t, r, i;
        for (t = 0, r = e.changedTouches.length; t < r; t++) i = e.changedTouches[t], this.initialTouches[i.identifier] = {
            x: i.pageX,
            y: i.pageY
        }
    },
    getInitialXY: function(e) {
        var t = this.initialTouches[e.identifier];
        return {
            x: t.x,
            y: t.y
        }
    },
    onTouchStart: function(e, t, r) {
        var i = this.getBrowserEvent(e);
        this.startTime = i.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(i), this.touchCount = this.getTouchCount(e)
    },
    onTouchMove: function(e, t, r) {
        return 3 === this.getTouchCount(e) && (e.preventDefault(), this.checkTouchMove(e, t, r))
    },
    checkTouchXY: function(e, t, r) {
        var i, o, s, n;
        if (i = e.pageX, o = e.pageY, s = Math.abs(i - t), n = Math.abs(o - r), this.isVertical && s > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && n > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(e, t, r) {
        var i, o, s, n, a;
        if (n = this.getBrowserEvent(e), n.timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (i = 0, a = n.changedTouches.length; i < a; i++)
            if (s = n.changedTouches[i], o = this.initialTouches[s.identifier]) {
                if (!1 === this.checkTouchXY(s, o.x, o.y)) return !1
            } else SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + s.identifier)
    },
    onTouchEnd: function(e, t, r) {
        var i, o, s, n, a, l, c, u, d, h, f, m;
        if (0 !== this.getTouchCount(e)) return !1;
        if (3 !== this.touchCount) return !1;
        if (!(i = this.getFirstChangedTouch(e))) return !1;
        if (o = i.pageX, s = i.pageY, n = this.getInitialXY(i), a = o - n.x, l = s - n.y, c = Math.abs(a), u = Math.abs(l), d = this.getMinDistance(), h = e.browserEvent.timeStamp - this.startTime, this.isVertical && u < d && (this.isVertical = !1), this.isHorizontal && c < d && (this.isHorizontal = !1), this.isHorizontal) f = a < 0 ? "left" : "right", m = c;
        else {
            if (!this.isVertical) return this.fail();
            f = l < 0 ? "up" : "down", m = u
        }
        this.fireSwipe(e, i, f, m, h)
    },
    fail: function() {
        return !1
    }
}), SYNO.SDS.Gesture.LongPress = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDuration: 500
    },
    fireLongPress: function(e, t) {
        SYNO.SDS.GestureMgr.fireEvent("longpress", e, t)
    },
    getMinDuration: function() {
        return this.config.minDuration
    },
    onTouchStart: function(e, t, r) {
        var i = this;
        this.timer && this.removeTimer(), this.timer = setTimeout(function() {
            i.fireLongPress(e, t), this.timer = null
        }, this.getMinDuration())
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(e, t, r) {
        return this.fail()
    },
    removeTimer: function() {
        clearTimeout(this.timer), this.timer = null
    },
    fail: function() {
        return this.removeTimer(), !1
    }
}), SYNO.SDS.Gesture.DoubleTap = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        maxDuration: 300,
        maxOffset: 50
    },
    singleTapTimer: null,
    fireSingleTap: function(e, t) {},
    fireDoubleTap: function(e, t) {
        e.preventDefault(), SYNO.SDS.GestureMgr.fireEvent("doubletap", e, t)
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    onTouchStart: function(e, t, r) {
        e && e.browserEvent && this.isInMaxDuration(e.browserEvent.timeStamp, this.lastTapTime) && e.preventDefault()
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(e, t, r) {
        var i, o, s, n, a = this.lastTapTime,
            l = this.lastX,
            c = this.lastY;
        return this.getTouchCount(e) > 0 ? this.fail() : (e && e.browserEvent && (i = e.browserEvent.timeStamp), this.lastTapTime = i, !!(o = this.getFirstChangedTouch(e)) && (s = o.pageX, n = o.pageY, this.lastX = s, this.lastY = n, a && this.checkXY(l, c) && this.isInMaxDuration(i, a) ? (this.lastTapTime = 0, void this.fireDoubleTap(e, t)) : void 0))
    },
    checkXY: function(e, t) {
        var r = Math.abs(this.lastX - e),
            i = Math.abs(this.lastY - t),
            o = this.getMaxOffset();
        return r < o && i < o
    },
    isInMaxDuration: function(e, t) {
        return !(!e || !t) && e - t <= this.getMaxDuration()
    },
    fail: function() {
        return this.lastTapTime = 0, this.lastX = void 0, this.lastY = void 0, !1
    }
}), Ext.ns("SYNO.SDS.Gesture.MS"), SYNO.SDS.Gesture.MS.Swipe = Ext.extend(SYNO.SDS.Gesture.Swipe, {
    config: {
        minDistance: 80,
        maxOffset: 500,
        maxDuration: 1e3
    },
    constructor: function() {
        var e = this;
        SYNO.SDS.Gesture.MS.Swipe.superclass.constructor.apply(e, arguments)
    },
    setInitialXY: function(e) {
        this.initialTouches[e.pointerId] = {
            x: e.pageX,
            y: e.pageY
        }
    },
    getTouchCount: function() {
        var e, t = 0;
        if (this.initialTouches)
            for (e in this.initialTouches) this.initialTouches.hasOwnProperty(e) && t++;
        return t
    },
    checkTouchXY: function(e, t, r) {
        var i, o, s, n;
        if (i = e.pageX, o = e.pageY, s = Math.abs(i - t), n = Math.abs(o - r), this.isVertical && s > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && n > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(e, t, r) {
        var i, o;
        if (o = this.getBrowserEvent(e), o.timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (i in this.initialTouches)
            if (this.initialTouches.hasOwnProperty(i)) {
                var s, n = this.initialTouches[i];
                if (o && o.touches && o.touches.length > 0 && (s = o.touches[0]), !n) {
                    SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + s.identifier);
                    continue
                }
                if (!1 === this.checkTouchXY(o, n.x, n.y)) return !1
            }
    },
    onTouchStart: function(e, t, r) {
        var i = this.getBrowserEvent(e);
        this.startTime = i.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(i), this.touchCount = this.getTouchCount()
    },
    onTouchMove: function(e, t, r) {
        return 3 === this.getTouchCount() && (e.preventDefault(), this.checkTouchMove(e, t, r))
    },
    onTouchEnd: function(e, t, r) {
        var i, o, s, n, a, l, c, u, d, h, f, m = this.getBrowserEvent(e);
        if (!this.initialTouches || !this.initialTouches[m.pointerId]) return !1;
        if (f = this.initialTouches[m.pointerId], delete this.initialTouches[m.pointerId], 0 !== this.getTouchCount()) return !1;
        if (3 !== this.touchCount) return !1;
        if (i = m.pageX, o = m.pageY, s = i - f.x, n = o - f.y, a = Math.abs(s), l = Math.abs(n), c = this.getMinDistance(), u = m.timeStamp - this.startTime, this.isVertical && l < c && (this.isVertical = !1), this.isHorizontal && a < c && (this.isHorizontal = !1), this.isHorizontal) d = s < 0 ? "left" : "right", h = a;
        else {
            if (!this.isVertical) return this.fail();
            d = n < 0 ? "up" : "down", h = l
        }
        this.fireSwipe(e, void 0, d, h, u)
    },
    onTouchCancel: function() {
        this.fail(), delete this.initialTouches
    }
}), SYNO.SDS.Gesture.EmptyGestureObject = new SYNO.SDS.Gesture.EmptyGesture, SYNO.SDS.Gesture.MS.EmptyGestureObject = SYNO.SDS.Gesture.EmptyGestureObject, SYNO.SDS.Gesture.GestureFactory = Ext.extend(Object, {
    create: function(e) {
        var t = SYNO.SDS.UIFeatures.test("msPointerEnabled"),
            r = "SYNO.SDS.Gesture." + (t ? "MS." : "");
        switch (e) {
            case "Swipe":
                if (t && (window.navigator.msMaxTouchPoints ? window.navigator.msMaxTouchPoints : 0) < 3) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                r += e;
                break;
            case "LongPress":
            case "DoubleTap":
                if (t) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                r += e;
                break;
            default:
                return t ? SYNO.SDS.Gesture.MS.EmptyGestureObject : SYNO.SDS.Gesture.EmptyGestureObject
        }
        return this.getGestureInstance(r)
    },
    getGestureInstance: function(e) {
        return new(Ext.getClassByName(e))
    }
}), Ext.namespace("SYNO.SDS._GestureMgr"), SYNO.SDS._GestureMgr = Ext.extend(Ext.util.Observable, {
    constructor: function() {
        SYNO.SDS._GestureMgr.superclass.constructor.apply(this, arguments), this.gestures = ["Swipe", "LongPress", "DoubleTap"], this.init()
    },
    init: function() {
        var e, t, r, i, o = SYNO.SDS.UIFeatures.test("msPointerEnabled");
        for (r = Ext.getDoc(), e = 0, t = this.gestures.length; e < t; e++) i = this.getGestureInstance(this.gestures[e]), Ext.EventManager.on(r, o ? "MSPointerCancel" : "touchcancel", i.onTouchCancel, i), Ext.EventManager.on(r, o ? "MSPointerDown" : "touchstart", i.onTouchStart, i), Ext.EventManager.on(r, o ? "MSPointerUp" : "touchend", i.onTouchEnd, i), Ext.EventManager.on(r, o ? "MSPointerMove" : "touchmove", i.onTouchMove, i);
        this.addGestureHandlers()
    },
    addGestureHandlers: function() {
        this.on("swipe", this.swipeHandler, this, {
            buffer: 10
        }), this.on("longpress", this.longPressHandler, this), this.on("doubletap", this.doubleTapHandler, this)
    },
    getGestureInstance: function(e) {
        return this.gestureFactory = this.gestureFactory || new SYNO.SDS.Gesture.GestureFactory, this.gestureFactory.create(e)
    },
    swipeHandler: function(e, t, r, i, o) {
        var s;
        "right" === r ? SYNO.SDS.TaskButtons.setRightWindowActive() : "left" === r ? SYNO.SDS.TaskButtons.setLeftWindowActive() : "up" === r && (s = SYNO.SDS.WindowMgr.getActiveAppWindow()) && s.minimize()
    },
    longPressHandler: function(e, t) {
        var r, i, o;
        for (r = this.findEventHandlers(t, "contextmenu"), i = 0, o = r.length; i < o; i++) r[i](e.browserEvent)
    },
    doubleTapHandler: function(e, t) {
        var r, i, o;
        for (r = this.findEventHandlers(t, "dblclick"), i = 0, o = r.length; i < o; i++) r[i](e.browserEvent)
    },
    findEventHandlers: function(e, t) {
        for (var r, i, o, s, n = Ext.get(e), a = []; n;) {
            r = Ext.EventManager.getListeners(n, t); {
                if (r) {
                    for (i = 0, o = r.length; i < o; i++) s = r[i], a.push(s[1]);
                    break
                }
                n = n.parent()
            }
        }
        return a
    }
}), Ext.namespace("SYNO"), SYNO.Debug = function() {
    function e(e) {
        performance.getEntriesByName(e, "mark").length > 0 && (n.warn("Mark", e, "already exists"), performance.clearMarks(e)), performance.mark(e)
    }

    function t(e) {
        if (!performance.getEntriesByName(e, "mark")[0]) return void n.warn("Mark", e, "not found");
        performance.measure(e, e);
        var t = performance.getEntriesByName(e, "measure")[0];
        n.log("%c" + e, "font-weight: bold;", "\n", "\t ", "start:", t.startTime, "\n", "\t ", "duration:", t.duration, "ms", "\n"), performance.clearMeasures(e), performance.clearMarks(e)
    }
    var r = Ext.urlDecode(location.search.substr(1)).jsDebug,
        i = window.console && window.console.log && !0,
        o = window.console || Ext.emptyFn,
        s = function(e) {
            function t(e) {
                return !r && -1 === s.indexOf(e) || !i ? Ext.emptyFn : (Ext.isFunction(window.console[e]) ? window.console[e] : Ext.emptyFn).bind(o)
            }
            var s = "error".split(",");
            e = e.split(",");
            var n = {};
            return Ext.each(e, function(e) {
                n[e] = t(e)
            }), n
        }("debug,trace,log,info,warn,error,group,groupCollapsed,groupEnd,profile,profileEnd,table,time,timeEnd,timeStamp"),
        n = s.log;
    Ext.apply(n, s);
    var a = Ext.urlDecode(location.search.substr(1)).perf;
    return Ext.apply(n, {
        isPerf: a,
        mark: a ? e : Ext.emptyFn,
        measure: a ? t : Ext.emptyFn
    }), n
}(), SYNO.Assert = function(e, t) {
    if (!e) throw t
}, Ext.namespace("SYNO.SDS.Utils.CMS"), SYNO.SDS.Utils.CMS.IsAllowRelay = function(e) {
    var t, r;
    return !!Ext.isObject(e) && (t = Ext.getClassByName("SYNO.SDS.AdminCenter.MainWindow"), r = Ext.getClassByName("SYNO.SDS.ResourceMonitor.App"), !(!(!Ext.isEmpty(t) && e instanceof t || !Ext.isEmpty(r) && e instanceof r || !0 === function(e) {
        return !!(!0 === e._relayObject && Ext.isFunction(e.findAppWindow) && Ext.isObject(e.openConfig) && Ext.isFunction(e.hasOpenConfig) && Ext.isFunction(e.getOpenConfig) && Ext.isFunction(e.setOpenConfig))
    }(e)) || !e.hasOpenConfig("cms_id")))
}, Ext.namespace("SYNO.API"), SYNO.API.EncodeFlatParams = function(e) {
    var t = {};
    if (!e) return t;
    var r = function e(t, r, i) {
        for (var o in t)
            if (t.hasOwnProperty(o)) {
                var s = t[o],
                    n = r ? r + "|" + o : o;
                Ext.isFunction(s) || (Ext.isObject(s) ? e(t[o], n, i) : i[n] = s)
            }
    };
    if (!Ext.isArray(e)) return r(e, void 0, t), t;
    for (var i = 0; i < (void 0).length; i++)(void 0)[i].api && (void 0)[i].method ? r((void 0)[i], (void 0)[i].api + "|" + (void 0)[i].method, t) : r(e, void 0, t);
    return t
}, SYNO.API.DecodeFlatParams = function(e) {
    var t = {};
    for (var r in e) Ext.isObject(e[r]) ? t[r] = e[r] : function e(t, r, i) {
        var o, s = t.indexOf("|");
        0 < s ? (o = t.substring(0, s), Ext.isObject(i[o]) || (i[o] = {}), e(t.substring(s + 1), r, i[o])) : i[t] = r
    }(r, e[r], t);
    return t
}, SYNO.API.EncodeParams = function(e) {
    var t = {};
    for (var r in e) e.hasOwnProperty(r) && (t[r] = Ext.encode(e[r]));
    return t
}, SYNO.API.DecodeParams = function(e) {
    var t = {};
    for (var r in e)
        if (e.hasOwnProperty(r)) try {
            t[r] = Ext.decode(e[r])
        } catch (i) {
            t[r] = SYNO.Util.copy(e[r])
        }
    return t
}, Ext.namespace("SYNO.API"), Ext.define("SYNO.API.QueryAPI", {
    singleton: !0,
    IsQuerying: !1,
    QueryAPIInfo: function() {
        var e = this;
        return e.IsQuerying && e.promise ? e.promise : (SYNO.API.Manager || (SYNO.API.Manager = new SYNO.API._Manager), SYNO.API.currentManager || (SYNO.API.currentManager = SYNO.API.Manager, SYNO.API.currentManager.isDeprecated = !0), e.promise = new Promise(function(t, r) {
            var i = function(i) {
                i ? t() : r(), e.IsQuerying = !1
            };
            e.IsQuerying = !0, SYNO.API.Manager.queryAPI("all", i)
        }), e.promise)
    }
}), SYNO.API.getErrorString = function(e) {
    var t, r = 100;
    return Ext.isNumber(e) ? r = e : Ext.isObject(e) && (t = SYNO.API.Response.GetFirstError(e), r = Ext.isNumber(t.code) ? t.code : 100), r <= 119 ? SYNO.API.Errors.common[r] : Ext.isString(SYNO.API.Errors.core[r]) ? SYNO.API.Errors.core[r] : _T("common", "error_system")
}, SYNO.API.CheckSpecialError = function(e, t, r) {
    var i;
    return "SYNO.DSM.Share" === r.api && ("delete" === r.method && 404 === t.code ? i = _T("error", "delete_default_share") : "edit" === r.method && 406 === t.code && (i = _T("error", "share_mounted_rename"))), i
}, SYNO.API.CheckResponse = function(e, t, r, i) {
    var o, s;
    if (e && t && !0 === t.has_fail && "array" === Ext.type(t.result)) return t.result.forEach(function(e) {
        Ext.isDefined(e.success) && !1 === e.success && Ext.isDefined(e.error) && "object" === Ext.type(e.error) && (105 === e.error.code || 107 === e.error.code ? SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[e.error.code], !0, !0) : 106 === e.error.code && SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[e.error.code], !0, !1))
    }), !0;
    if (e) return !0;
    if (Ext.isEmpty(t) || 0 === t.status) return !1;
    try {
        o = Ext.isDefined(t.status) ? 0 : t.code || 100, s = o < SYNO.API.Errors.minCustomeError ? SYNO.API.Errors.common[o] : SYNO.API.CheckSpecialError(e, t, r) || SYNO.API.Errors.core[o]
    } catch (e) {} finally {
        s || (o = 100, s = SYNO.API.Errors.common[o])
    }
    return i && Ext.isFunction(i.getResponseHeader) && !Ext.isEmpty(i.getResponseHeader("X-SYNO-SOURCE-ID")) || (105 === o || 107 === o ? SYNO.SDS.Utils.Logout.action(!0, s, !0, !0) : 106 === o && SYNO.SDS.Utils.Logout.action(!0, s, !0, !1)), s
}, SYNO.API.CheckRelayResponse = function(e, t, r, i, o) {
    var s, n = !1,
        a = Ext.getClassByName("SYNO.SDS.AppWindow");
    if (Ext.isEmpty(t) || Ext.isObject(o) && 0 === o.status) return n;
    if (!SYNO.SDS.Utils.CMS.IsAllowRelay(i.appWindow) || Ext.isEmpty(a)) return n;
    if (!((s = i.appWindow.findAppWindow()) instanceof a) || Ext.isEmpty(s.appInstance)) return n;
    if (!Ext.isObject(i.params)) return n;
    if ("SYNO.API.Info" === i.params.api) n = !0;
    else if ('"SYNO.CMS.DS"' !== i.params.api || '"relay"' !== i.params.method) return n;
    return !0 === n || (Ext.isObject(o) && Ext.isEmpty(o.getResponseHeader("X-SYNO-SOURCE-ID")) ? !Ext.isNumber(t.code) || 414 !== t.code && 406 !== t.code && 401 !== t.code && 423 !== t.code ? Ext.isObject(o) && o.status >= 400 && o.status < 600 && (n = !0) : n = !0 : Ext.isObject(i.userInfo.params) && Ext.isArray(i.userInfo.params.compound) ? Ext.each(t.result, function(e) {
        if (Ext.isObject(e.error) && e.error.code >= 105 && e.error.code <= 107) return n = !0, !1
    }, this) : Ext.isNumber(t.code) ? t.code >= 105 && t.code <= 107 && (n = !0) : Ext.isObject(o) && o.status >= 400 && o.status < 600 && (n = !0)), !0 === n && s.getMsgBox().alert(_T("error", "error_error"), _T("cms", "relaunch_app"), function() {
        s.close()
    }), n
}, SYNO.API._Manager = Ext.extend(Ext.util.Observable, {
    isDeprecated: !1,
    baseURL: "webapi",
    constructor: function() {
        SYNO.API._Manager.superclass.constructor.apply(this, arguments), this.jsDebug = Ext.urlDecode(location.search.substr(1)).jsDebug, this.knownAPI = {
            "SYNO.API.Info": {
                path: "query.cgi",
                minVersion: 1,
                maxVersion: 1
            }
        }
    },
    queryAPI: function(e, t, r, i) {
        var o = [];
        Ext.isArray(e) || (e = [e]), Ext.each(e, function(e) {
            this.knownAPI.hasOwnProperty(e) || o.push(e)
        }, this), this.requestAjaxAPI("SYNO.API.Info", "query", 1, {
            async: !Ext.isBoolean(i) || i
        }, {
            query: o.join(",")
        }, Ext.createDelegate(this.onQueryAPI, this, [t, r], !0))
    },
    onQueryAPI: function(e, t, r, i, o, s) {
        e && (Ext.isObject(r) && "all" === r.query ? this.knownAPI = Ext.apply({}, t) : Ext.apply(this.knownAPI, t)), o && o.call(s, e, t, r, i)
    },
    getKnownAPI: function(e, t) {
        var r, i, o = this.knownAPI[e];
        return Ext.isDefined(this.jsDebug) && Ext.isObject(o) ? (r = o.path + "/", "SYNO.Entry.Request" === e && Ext.isObject(t) && Ext.isArray(t.compound) ? (i = [], Ext.each(t.compound, function(e) {
            Ext.isString(e.api) && i.push(e.api)
        }), r += i.join()) : r += e, Ext.apply({}, {
            path: r
        }, o)) : o
    },
    getBaseURL: function(e, t, r, i, o) {
        var s, n, a, l;
        if (Ext.isObject(e))
            if (n = e, i = t, o = r, n.webapi && (n = n.webapi), Ext.isObject(n.compound)) {
                if (!Ext.isArray(n.compound.params)) return void SYNO.Debug.error("params must be array", n.compound.params);
                e = "SYNO.Entry.Request", t = "request", r = 1;
                for (var c = n.compound.params || [], u = [], d = 0; d < c.length; d++) u.push(Ext.apply({
                    api: c[d].api,
                    method: c[d].method,
                    version: c[d].version
                }, c[d].params));
                a = {
                    stop_when_error: !!Ext.isBoolean(n.compound.stopwhenerror) && n.compound.stopwhenerror,
                    mode: Ext.isString(n.compound.mode) ? n.compound.mode : "sequential",
                    compound: u
                }
            } else e = n.api, t = n.method, r = n.version, a = n.params;
        return (s = this.getKnownAPI(e, a)) ? (l = this.baseURL + "/" + s.path, Ext.isString(o) && !Ext.isEmpty(o) && (l += "/" + window.encodeURIComponent(o)), t && r ? (n = {
            api: e,
            method: t,
            version: r
        }, a && Ext.apply(n, "JSON" === s.requestFormat ? SYNO.API.EncodeParams(a) : a), Ext.urlAppend(l, Ext.urlEncode(n), i)) : l) : (SYNO.Debug.error("No Such API: " + e), void SYNO.API.QueryAPI.QueryAPIInfo())
    },
    requestAjaxAPI: function(e, t, r, i, o, s, n) {
        var a, l, c, u, d, h, f = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "POST",
            m = SYNO.Util.copy(o),
            p = null;
        if (Ext.isObject(e) && (l = e, l.webapi && (l = l.webapi), i = {}, Ext.apply(i, l), delete i.api, delete i.method, delete i.version, delete i.scope, delete i.callback, delete i.httpMethod, s = l.callback || e.callback, n = l.scope || e.scope, i.appWindow = e.appWindow, l.httpMethod && (f = l.httpMethod), Ext.isObject(l.compound) ? u = l.compound : (e = l.api, t = l.method, r = l.version, m = l.params)), i && i.compound && (u = i.compound), u) {
            if (!Ext.isArray(u.params)) return void SYNO.Debug.error("params must be array", u.params);
            e = "SYNO.Entry.Request", t = "request", r = 1;
            for (var _ = u.params || [], g = [], S = 0; S < _.length; S++) g.push(Ext.apply({
                api: _[S].api,
                method: _[S].method,
                version: _[S].version
            }, _[S].params));
            m = {
                stop_when_error: !!Ext.isBoolean(u.stopwhenerror) && u.stopwhenerror,
                mode: Ext.isString(u.mode) ? u.mode : "sequential",
                compound: g
            }
        }
        if (!(a = Ext.isObject(i.appWindow) && "SYNO.API.Info" !== e ? SYNO.API.Info.GetKnownAPI(i.appWindow, e, m) : this.getKnownAPI(e, m))) return h = Ext.isObject(i.appWindow) && i.appWindow.IsAllowRelay(), SYNO.Debug.error("No Such API: " + e), d = {
            error: {
                code: 102
            }
        }, SYNO.API.QueryAPI.QueryAPIInfo(), h && SYNO.API.CheckRelayResponse(!1, d, m, i), void(Ext.isFunction(s) && s.call(n || window, !1, d, m, i));
        if ((r < a.minVersion || a.maxVersion < r) && SYNO.Debug.warn(String.format("WARN: API({0}) version ({1}) is higher then server ({2})", e, r, a.version)), !Ext.isObject(m) && !Ext.isEmpty(m)) return void SYNO.Debug.error("params must be object, ", m);
        !Ext.isSecure && Ext.isArray(i.encryption) && (p = Ext.apply([], i.encryption)), delete i.encryption;
        var b, v = {
                api: e,
                method: t,
                version: r
            },
            T = this.baseURL + "/" + a.path;
        if (i && i.url) {
            var x = i.url;
            b = Ext.urlDecode(x.substr(x.indexOf("?") + 1)), b && b.api && b.method && b.version && (delete b.api, delete b.method, delete b.version, delete b.SynoToken, v = b, T = i.url)
        }
        return i && Ext.isElement(i.form) && /multipart\/form-data/i.test(i.form.enctype) ? (T = SYNO.API.GetBaseURL(v), v = {}) : Ext.isObject(i) && !0 === i.html5upload && (T = SYNO.API.GetBaseURL(Ext.apply({
            params: m
        }, v)), v = {}), i.method = f, c = Ext.apply(i || {}, {
            url: T,
            params: Ext.apply({}, v, "JSON" === a.requestFormat ? SYNO.API.EncodeParams(m) : m),
            callback: this.onRequestAPI.bind(this),
            userInfo: {
                params: m,
                cb: s,
                scope: n
            }
        }), Ext.isEmpty(p) ? this.sendRequest(c) : this.requestAjaxAPI("SYNO.API.Encryption", "getinfo", 1, {
            appWindow: c.appWindow || void 0,
            reqObj: c,
            reqEnc: p
        }, {
            format: "module"
        }, this.onEncryptRequestAPI, this)
    },
    onEncryptRequestAPI: function(e, t, r, i) {
        var o, s, n, a = i.reqObj,
            l = i.reqEnc,
            c = function(e) {
                for (var t in e)
                    if (e.hasOwnProperty(t)) return !1;
                return !0
            };
        if (!e) return Ext.Ajax.request(a);
        if (SYNO.Encryption.CipherKey = t.cipherkey, SYNO.Encryption.RSAModulus = t.public_key, SYNO.Encryption.CipherToken = t.ciphertoken, SYNO.Encryption.TimeBias = t.server_time - Math.floor(+new Date / 1e3), Ext.isEmpty(a.params.compound)) {
            for (o = SYNO.Encryption.EncryptParam(Ext.copyTo({}, a.params, l)), s = 0; s < l.length; s++) delete a.params[l[s]];
            return a.params = Ext.apply(a.params, o), this.sendRequest(a)
        }
        var u = Ext.apply({}, a.userInfo.params),
            d = this,
            h = 5;
        (Ext.isIE6 || Ext.isIE7 || Ext.isIE8) && (h = 1), s = 0;
        ! function e() {
            for (; s < u.compound.length; s++) {
                var t = Ext.apply({}, u.compound[s], u.compound[s].params),
                    r = {};
                for (o = {}, r = SYNO.API.EncodeParams(Ext.copyTo({}, t, l)), c(r) || (o = SYNO.Encryption.EncryptParam(r)), n = 0; n < l.length; n++) delete t[l[n]];
                if (u.compound[s] = Ext.apply(t, o), s + 1 === u.compound.length) return Ext.apply(a.params, SYNO.API.EncodeParams(u)), void d.sendRequest(a);
                if (s % h == 0) return s++, void window.setTimeout(e, 80)
            }
        }()
    },
    sendRequest: function(e) {
        var t, r, i, o = e.appWindow,
            s = this.getKnownAPI("SYNO.CMS.DS");
        if (Ext.isObject(o) && o.findAppWindow && (o = o.findAppWindow()), !Ext.isEmpty(s) && SYNO.SDS.Utils.CMS.IsAllowRelay(o) && o.hasOpenConfig("cms_id") && (r = o.getOpenConfig("cms_timeout") || 120, i = {
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                id: o.getOpenConfig("cms_id"),
                timeout: r
            }, Ext.isElement(e.form) && /multipart\/form-data/i.test(e.form.enctype) ? (t = Ext.urlDecode(e.url.substr(e.url.indexOf("?") + 1)), i.webapi = Ext.encode(Ext.copyTo({}, t, "api,version,method")), t.SynoToken && (i.SynoToken = t.SynoToken), e.url = this.baseURL + "/" + s.path + "?" + Ext.urlEncode(i)) : (e.url = this.baseURL + "/" + s.path, i.webapi = Ext.apply({
                api: e.params.api,
                version: e.params.version,
                method: e.params.method
            }, e.userInfo.params), e.params = SYNO.API.EncodeParams(i)), e.timeout = e.timeout || 1e3 * (r + 10)), SYNO.Debug.isPerf) {
            e.headers || (e.headers = {}), e.headers["Cusotm-Perf-Id"] = Date.now();
            var n = this.generatePerfName(e);
            SYNO.Debug.mark(n)
        }
        return Ext.Ajax.request(e)
    },
    requestAPI: function(e, t, r, i, o, s) {
        return this.requestAjaxAPI(e, t, r, {}, i, o, s)
    },
    onRequestAPI: function(e, t, r) {
        var i, o = !1,
            s = r;
        if (t) {
            try {
                i = Ext.decode(r.responseText)
            } catch (e) {}
            if (!1 === SYNO.SDS.HandShake.CheckAPIResponse(e, r)) return;
            Ext.isObject(i) && (i.success ? (o = !0, s = i.data) : (o = !1, s = i.error))
        }
        if (SYNO.API.CheckResponse(o, s, e.userInfo.params, r), (!SYNO.SDS.Utils.CMS.IsAllowRelay(e.appWindow) || !SYNO.API.CheckRelayResponse(o, s, void 0, e, r)) && (e.userInfo.cb && e.userInfo.cb.call(e.userInfo.scope, o, s, e.userInfo.params, e), SYNO.Debug.isPerf)) {
            var n = this.generatePerfName(e);
            SYNO.Debug.measure(n)
        }
    },
    generatePerfName: function(e) {
        return (e.compound && e.compound.params || [e.params]).map(function(e) {
            return "[API] " + e.api + " :" + e.method
        }).join("\n") + " - " + e.headers["Cusotm-Perf-Id"]
    }
}), SYNO.API.EscapeStr = function(e) {
    return e ? e.replace(/[\\]/g, "\\\\").replace(/[,]/g, "\\,") : ""
}, SYNO.API.Request = function(e) {
    return SYNO.API.Manager.requestAjaxAPI(e)
}, SYNO.API.RequestPromise = function(e) {
    return new Promise(function(t, r) {
        e.callback = function(e, i, o, s) {
            e ? t(i) : r(i)
        }, SYNO.API.Request(e)
    }.bind(this))
}, SYNO.API.GetKnownAPI = function(e, t) {
    return SYNO.API.Manager.getKnownAPI(e, t)
}, Ext.namespace("SYNO.SDS._UserSettings"), SYNO.SDS._UserSettings = Ext.extend(Ext.Component, {
    data: null,
    ajaxTask: null,
    delayedTask: null,
    modified: null,
    webapi: {
        get: {
            api: "SYNO.Core.UserSettings",
            method: "get",
            version: 1
        },
        apply: {
            api: "SYNO.Core.UserSettings",
            method: "apply",
            version: 1
        }
    },
    constructor: function() {
        SYNO.SDS._UserSettings.superclass.constructor.apply(this, arguments), this.data = SYNO.SDS.initUserSettings || {}, this.delayedTask = new Ext.util.DelayedTask(this.save, this), this._onCallbackObjs = [], SYNO.SDS.StatusNotifier && (this.mon(SYNO.SDS.StatusNotifier, "logout", this.saveByBeacon, this), this.mon(SYNO.SDS.StatusNotifier, "halt", this.saveAndUnload, this), this.mon(SYNO.SDS.StatusNotifier, "redirect", this.saveAndUnload, this)), this.registerUnloadEvent()
    },
    getUnloadEventName: function() {
        var e = "onpagehide" in window,
            t = "onbeforeunload" in window;
        return t ? "beforeunload" : e ? "pagehide" : null
    },
    registerUnloadEvent: function() {
        var e = this.getUnloadEventName();
        e && Ext.EventManager.on(window, e, this.saveByBeacon, this)
    },
    unregisterNotifierEvent: function() {
        SYNO.SDS.StatusNotifier && (this.mun(SYNO.SDS.StatusNotifier, "logout", this.saveByBeacon, this), this.mun(SYNO.SDS.StatusNotifier, "halt", this.saveAndUnload, this), this.mun(SYNO.SDS.StatusNotifier, "redirect", this.saveAndUnload, this))
    },
    unregisterUnloadEvent: function() {
        var e = this.getUnloadEventName();
        e && Ext.EventManager.un(window, e, this.syncSave, this)
    },
    saveAndUnload: function() {
        this.saveByBeacon(), this.unregisterUnloadEvent()
    },
    setLocalStorageByUser: function(e, t) {
        var r = this.getLocalStorageByUser(e) || {};
        r.key = t, localStorage.setItem(_S("user"), Ext.encode(r))
    },
    getLocalStorageByUser: function(e) {
        var t = Ext.decode(localStorage.getItem(_S("user")));
        return t ? t.key : null
    },
    setLocalStorage: function(e, t) {
        localStorage && localStorage.setItem(e, Ext.encode(t))
    },
    getLocalStorage: function(e) {
        return localStorage ? Ext.decode(localStorage.getItem(e)) : null
    },
    removeLocalStorage: function(e) {
        localStorage && localStorage.removeItem(e)
    },
    setLocalStorageRestoreParams: function() {
        if (this.modified.Desktop && this.modified.Desktop.restoreParams) {
            var e = {
                userName: _S("user"),
                restoreParams: this.modified.Desktop.restoreParams
            };
            this.setLocalStorage("restoreParams", e)
        }
    },
    getLocalStorageRestoreParams: function() {
        var e = this.getLocalStorage("restoreParams");
        return e && e.userName && e.userName === _S("user") ? e.restoreParams : null
    },
    removeLocalStorageRestoreParams: function() {
        var e = this.getLocalStorage("restoreParams");
        e && e.userName && e.userName === _S("user") && this.removeLocalStorage("restoreParams")
    },
    saveByBeacon: function() {
        if (SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("beforeUserSettingsUnload"), this.modified && !_S("demo_mode") && _S("isLogined"))
            if (navigator && navigator.sendBeacon) {
                this.ajaxTask && (this.ajaxTask._originalCallbackObj && this._onCallbackObjs.push(this.ajaxTask._originalCallbackObj), this.ajaxTask.remove()), this.setLocalStorageRestoreParams(), this.dirty = !1;
                var e = {
                    api: "SYNO.Core.UserSettings",
                    method: "apply",
                    version: 1
                };
                navigator.sendBeacon(SYNO.API.GetBaseURL(e), "data=".concat(Ext.encode(Ext.encode(this.modified))))
            } else this.syncSave()
    },
    syncSave: function(e) {
        SYNO.Debug.warn("synchronous XMLHttpRequest on the main thread is deprecated, will called by asynchronous"), SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("beforeUserSettingsUnload"), this.modified && !_S("demo_mode") && _S("isLogined") && (this.ajaxTask && (this.ajaxTask._originalCallbackObj && this._onCallbackObjs.push(this.ajaxTask._originalCallbackObj), this.ajaxTask.remove()), this.setLocalStorageRestoreParams(), this.dirty = !1, this.sendWebAPI(Ext.apply({
            timeout: 10,
            params: {
                data: Ext.encode(this.modified)
            },
            callback: this.onSaveSuccess.bind(this, e)
        }, this.webapi.apply)))
    },
    load: function() {
        this.addWebAPITask(Ext.apply({
            single: !0,
            callback: this.onLoadSuccess.createDelegate(this)
        }, this.webapi.get)).start()
    },
    save: function(e) {
        if (!this.modified || _S("demo_mode") || !_S("isLogined")) return this.onSaveSuccess(e);
        this.ajaxTask && (this.ajaxTask._originalCallbackObj && this._onCallbackObjs.push(this.ajaxTask._originalCallbackObj), this.ajaxTask.remove()), this.dirty = !1, this.ajaxTask = this.addWebAPITask(Ext.apply({
            single: !0,
            params: {
                data: Ext.encode(this.modified)
            },
            callback: this.onSaveSuccess.bind(this, e)
        }, this.webapi.apply)).start(), this.ajaxTask._originalCallbackObj = e
    },
    onLoadSuccess: function(e, t, r, i) {
        e && (this.data = t)
    },
    handleCallback: function(e) {
        var t;
        if (Ext.isObject(e)) {
            t = e.scope || this;
            var r = e.callback;
            Ext.isFunction(r) && r.apply(t, Array.from(arguments).slice(1))
        }
    },
    handlePreviousCallbacks: function() {
        var e = !0,
            t = !1,
            r = void 0;
        try {
            for (var i, o = this._onCallbackObjs[Symbol.iterator](); !(e = (i = o.next()).done); e = !0) {
                var s = i.value;
                this.handleCallback(s)
            }
        } catch (e) {
            t = !0, r = e
        } finally {
            try {
                e || null == o.return || o.return()
            } finally {
                if (t) throw r
            }
        }
        this._onCallbackObjs = []
    },
    onSaveSuccess: function(e) {
        !0 !== this.dirty && (this.modified = null), this.handlePreviousCallbacks(), this.handleCallback(e)
    },
    getProperty: function(e, t) {
        try {
            return this.data[e][t]
        } catch (e) {
            return null
        }
    },
    setProperty: function(e, t, r) {
        if (this.modified = this.modified || {}, this.dirty = !0, void 0 === r || null === r) return this.removeProperty(e, t);
        Ext.isObject(this.data[e]) || (this.data[e] = {}), this.data[e][t] = r, this.modified[e] = this.data[e], this.delayedTask.delay(3e3)
    },
    removeProperty: function(e, t) {
        this.data[e] && (this.dirty = !0, this.modified = this.modified || {}, this.modified[e] = this.data[e], delete this.data[e][t], this.delayedTask.delay(3e3))
    }
}), SYNO.SDS.UserSettingsProvider = Ext.extend(Ext.state.Provider, {
    constructor: function() {
        SYNO.SDS.UserSettingsProvider.superclass.constructor.apply(this, arguments)
    },
    set: function(e, t) {
        if (void 0 === t || null === t) return void this.clear(e);
        SYNO.SDS.UserSettingsProvider.superclass.set.call(this, e, t), SYNO.SDS.UserSettings.setProperty("desktop", "stateProvider", this.state)
    },
    clear: function(e) {
        SYNO.SDS.UserSettingsProvider.superclass.clear.call(this, e), SYNO.SDS.UserSettings.setProperty("desktop", "stateProvider", this.state)
    }
}), Ext.ns("SYNO.SDS.Utils.DataView"), SYNO.SDS.Utils.DataView.FlexcrollDataView = Ext.extend(Ext.DataView, {
    scrollCls: " ux-scroll",
    overScrollCls: " ux-scroll-over",
    autoFlexcroll: !0,
    trackResetOnLoad: !0,
    initComponent: function() {
        var e = this;
        SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.initComponent.call(e), e.addEvents("refresh", "updateScrollbar"), e.mon(e, "beforerender", function() {
            e.cls = e.cls ? e.cls + e.scrollCls : e.scrollCls, e.overCls = e.overCls ? e.overCls + e.overScrollCls : e.overScrollCls
        }, e)
    },
    onStoreException: function() {
        this.el.unmask()
    },
    onStoreLoad: function() {
        var e = this;
        e.updateScrollbar(e.trackResetOnLoad), e.fireEvent("afterUpdateScrollbar", e)
    },
    onStoreClear: function() {
        var e = this;
        e.updateScrollbar(e.trackResetOnLoad)
    },
    bindStore: function(e, t) {
        var r = this;
        SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.bindStore.apply(r, arguments), !t && this.store && (e !== this.store && this.store.autoDestroy ? this.store.destroy() : (r.mun(e, "loadexception", r.onStoreException, r), r.mun(e, "load", r.onStoreLoad, r), r.mun(e, "clear", r.onStoreClear, r), r.mun(e, "datachanged", r.updateScrollbar, r), r.mun(e, "update", r.updateScrollbar, r)), e || (this.store = null)), e && (e = Ext.StoreMgr.lookup(e), r.mon(e, "loadexception", r.onStoreException, r), r.mon(e, "load", r.onStoreLoad, r), r.mon(e, "clear", r.onStoreClear, r), r.mon(e, "datachanged", r.updateScrollbar, r), r.mon(e, "update", r.updateScrollbar, r))
    },
    afterRender: function() {
        var e = this;
        SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.afterRender.call(e), e.mon(e, "resize", e.updateScrollbar, e), e.mon(e, "afterrender", e.updateScrollbar, e), e.mon(e, "afterlayout", e.updateScrollbar, e), e.mon(e, "updateScrollbar", e.onUpdateScrollbar, e, {
            buffer: 100
        }), e.updateScrollbar()
    },
    getTemplateTarget: function() {
        var e = this;
        if (e.el.dom) return e.scrollBar = e.scrollBar || e.el.createChild({
            tag: "div",
            style: "display:inline-block;width:100%;"
        }), e.scrollBar
    },
    updateScrollbar: function(e) {
        var t = this;
        e = !!Ext.isBoolean(e) && e, e ? this.onUpdateScrollbar(e) : t.fireEvent("updateScrollbar", e)
    },
    onUpdateScrollbar: function(e) {
        var t = this;
        if (t.isVisible()) {
            var r = t.el.dom;
            r && r.fleXcroll ? (e && r.fleXcroll.setScrollPos(!1, 0), r.fleXcroll.updateScrollBars(), e || r.fleXcroll.setScrollPos(0, 0, !0)) : r && (fleXenv.fleXcrollMain(r, this.disableTextSelect), r.onfleXcroll = function() {
                this.fireEvent("flexcroll", this, this.getFleXcrollInfo(t.el.dom))
            }.createDelegate(this), r.fleXcroll && this.fireEvent("flexcrollInitDone")), r = null
        }
    },
    refresh: function() {
        var e = this;
        SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.refresh.call(e), e.fireEvent("refresh")
    },
    onDestroy: function() {
        var e = this;
        e.scrollBar && (Ext.destroy(e.scrollBar), delete e.scrollBar), SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.onDestroy.apply(e, arguments)
    }
}), SYNO.SDS.Utils.DataView.SquenceStrategy = function() {
    var e = this;
    e.isDestroyed || 0 !== e.all.getCount() && e.all.each(function(e) {
        this.updateItem(e)
    }, e)
}, SYNO.SDS.Utils.DataView.BinarySearchStrategy = function() {
    var e = this,
        t = null,
        r = -1,
        i = -1,
        o = -1,
        s = 0;
    if (!e.isDestroyed && 0 !== e.all.getCount())
        if (-1 === (r = (t = e.all.first()) && !0 === e.isIntens(t, e.getEl()) ? 0 : (t = e.all.last()) && !0 === e.isIntens(t, e.getEl()) ? e.all.getCount() - 1 : function() {
                for (var t = null, r = 0, i = 0, o = e.all.getCount() - 1, s = -1; i <= o;) {
                    if (s = Math.floor((i + o) / 2), t = e.all.item(s), r = e.isIntens(t, e.getEl()), t && !0 === r) return s;
                    !1 === r ? i = s + 1 : r < 0 && (o = s - 1)
                }
                return -1
            }())) e.all.each(function(e) {
            this.onUnLoadItem(e)
        }, e);
        else {
            for (s = r; s < e.all.getCount(); s++) {
                if (!0 !== e.isIntens(e.all.item(s), e.getEl())) {
                    o = s;
                    break
                }
                e.onLoadItem(t)
            }
            for (s = r - 1; s >= 0; s--) {
                if (!0 !== e.isIntens(e.all.item(s), e.getEl())) {
                    i = s;
                    break
                }
                e.onLoadItem(t)
            }
            if (-1 !== i)
                for (s = i; s >= 0; s--) e.onUnLoadItem(t);
            if (-1 !== o)
                for (s = o; s < e.all.getCount(); s++) e.onUnLoadItem(t)
        }
}, SYNO.SDS.Utils.DataView.ConstantSearchStrategy = function() {
    var e = this,
        t = null,
        r = -1,
        i = -1,
        o = -1,
        s = 0;
    if (!e.isDestroyed && 0 !== e.all.getCount())
        if (-1 === (r = (t = e.all.first()) && !0 === e.isIntens(t, e.getEl()) ? 0 : (t = e.all.last()) && !0 === e.isIntens(t, e.getEl()) ? e.all.getCount() - 1 : function(t) {
                var r = t.getSize(),
                    i = t.getMargins(),
                    o = e.el.dom.fleXdata ? e.el.dom.fleXdata.scrollPosition[1][0] : 0;
                return Math.floor(o / (r.height + i.top + i.bottom)) * Math.floor(e.el.getWidth() / (r.width + i.right + i.left))
            }(e.all.first()))) e.all.each(function(e) {
            this.onUnLoadItem(e)
        }, e);
        else {
            for (s = r; s < e.all.getCount(); s++) {
                if (!0 !== e.isIntens(e.all.item(s), e.getEl())) {
                    o = s;
                    break
                }
                e.onLoadItem(t)
            }
            for (s = r - 1; s >= 0; s--) {
                if (!0 !== e.isIntens(e.all.item(s), e.getEl())) {
                    i = s;
                    break
                }
                e.onLoadItem(t)
            }
            if (-1 !== i)
                for (s = i; s >= 0; s--) e.onUnLoadItem(e.all.item(s));
            if (-1 !== o)
                for (s = o; s < e.all.getCount(); s++) e.onUnLoadItem(e.all.item(s))
        }
}, SYNO.SDS.Utils.DataView.LazyDataView = Ext.extend(SYNO.SDS.Utils.DataView.FlexcrollDataView, {
    delay: 600,
    widthThreshold: 0,
    heightThreshold: 0,
    autoHeightThreshold: !0,
    constructor: function(e) {
        this.itemCls = e.itemCls || void 0, this.searchStrategy = this.searchStrategy || SYNO.SDS.Utils.DataView.SquenceStrategy.createDelegate(this), this.addPlugins(SYNO.ux.DataViewARIA, e), SYNO.SDS.Utils.DataView.LazyDataView.superclass.constructor.apply(this, [e]), this.last = !1
    },
    initKeyNav: function() {
        new Ext.KeyNav(this.el, {
            down: function(e) {
                this.onKeyDown(e)
            },
            up: function(e) {
                this.onKeyUp(e)
            },
            left: function(e) {
                this.onKeyLeft(e)
            },
            right: function(e) {
                this.onKeyRight(e)
            },
            scope: this
        })
    },
    focusNode: function(e) {
        var t = this,
            r = t.getNode(e);
        t.autoFlexcroll && t.fleXcrollTo(r)
    },
    getFirstSelItemIdx: function() {
        return this.getSelectedIndexes()[0]
    },
    getLastSelItemIdx: function() {
        return this.getSelectedIndexes()[this.getSelectedIndexes().length - 1]
    },
    getThumbnailRowNum: function(e) {
        var t = e.getTemplateTarget(),
            r = getComputedStyle(e.selected.elements[0]),
            i = parseInt(r.width, 10) + parseInt(r.marginLeft, 10) + parseInt(r.marginRight, 10);
        return Math.floor(t.getWidth() / i)
    },
    isNeedToShift: function() {
        return !!this.selected.elements[0]
    },
    selectItem: function(e, t) {
        t ? this.select(e, !0, !0) : this.select(e), this.focusNode(e)
    },
    selectPreItem: function() {
        var e, t = this.getFirstSelItemIdx();
        e = 0 === t ? 0 : t - 1, this.selectItem(e)
    },
    selectNextItem: function() {
        var e, t = this.getFirstSelItemIdx(),
            r = this.store.getCount() - 1;
        e = t == r ? r : t + 1, this.selectItem(e)
    },
    selectPreRowItem: function(e) {
        var t, r = this.getFirstSelItemIdx();
        if (r < e) return void this.selectItem(r);
        t = r - e, this.selectItem(t)
    },
    selectNextRowItem: function(e) {
        var t, r = this.getFirstSelItemIdx(),
            i = this.store.getCount() - 1;
        if ((t = r + e) > i) return void this.selectItem(r);
        this.selectItem(t)
    },
    selectPreItemIn: function() {
        var e, t = this.last;
        e = 0 === this.getLastSelItemIdx() ? 0 : this.getLastSelItemIdx() - 1, this.selectRange(t, e), this.last = t
    },
    selectNextItemIn: function() {
        var e, t = this.last,
            r = this.store.getCount() - 1;
        e = this.getLastSelItemIdx() + 1 > r ? r : this.getLastSelItemIdx() + 1, this.selectRange(t, e), this.last = t
    },
    selectPreRowItemIn: function(e) {
        var t, r = this.last;
        t = this.getLastSelItemIdx() < e ? 0 : this.getLastSelItemIdx() - e, this.selectRange(r, t), this.last = r
    },
    selectNextRowItemIn: function(e) {
        var t, r = this.last,
            i = this.store.getCount() - 1;
        t = this.getLastSelItemIdx() + e > i ? i : this.getLastSelItemIdx() + e, this.selectRange(r, t), this.last = r
    },
    onKeyUp: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this,
            r = t.getThumbnailRowNum(t);
        e.shiftKey ? t.selectPreRowItemIn(r) : t.selectPreRowItem(r)
    },
    onKeyDown: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this,
            r = t.getThumbnailRowNum(t);
        e.shiftKey ? t.selectNextRowItemIn(r) : t.selectNextRowItem(r)
    },
    onKeyRight: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this;
        e.shiftKey ? t.selectNextItemIn() : t.selectNextItem()
    },
    onKeyLeft: function(e) {
        if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
        var t = this;
        e.shiftKey ? t.selectPreItemIn() : t.selectPreItem()
    },
    setSearchStategy: function(e) {
        this.searchStrategy = e
    },
    onLoadItem: function(e) {},
    onUnLoadItem: function(e) {},
    belowthefold: function(e, t, r) {
        return (r || t.getY()) + t.dom.scrollTop + t.getHeight() - (e.getY() - this.heightThreshold)
    },
    rightoffold: function(e, t, r) {
        return (r || t.getX()) + t.dom.scrollLeft + t.getWidth() - (e.getX() - this.widthThreshold)
    },
    abovethetop: function(e, t, r) {
        return (r || t.getY()) + t.dom.scrollTop >= e.getY() + this.heightThreshold + e.getHeight()
    },
    leftofbegin: function(e, t, r) {
        return (r || t.getX()) + t.dom.scrollLeft >= e.getX() + this.widthThreshold + e.getWidth()
    },
    isIntens: function(e, t) {
        var r = this,
            i = 0,
            o = 0,
            s = t.getX(),
            n = t.getY();
        return !!r.isVisible() && (!!e && (!r.abovethetop(e, t, n) && !r.leftofbegin(e, t, s) && ((o = r.belowthefold(e, t, n)) >= 0 && (i = r.rightoffold(e, t, s)) >= 0 || i + o)))
    },
    fitWidth: function() {
        var e = this,
            t = e.getTemplateTarget(),
            r = 0,
            i = 0,
            o = 0,
            s = e.all.item(0),
            n = !0,
            a = 0;
        if (Ext.isObject(s) && e.itemCls) {
            if (Ext.util.CSS.getRule(e.itemCls) && (e.marginLeft = e.marginLeft || s.getMargins("l") || 0, e.marginRight = e.marginRight || s.getMargins("r") || 0, a = e.marginLeft + e.marginRight, Ext.isNumber(a) && (o = s.getWidth() + a, 0 !== (i = Math.floor(t.getWidth() / o))))) return r = Math.floor(t.getWidth() % o), s.getMargins("l") !== Math.floor(e.marginLeft + r / 2 / i) && (n = n && Ext.util.CSS.updateRule(e.itemCls, "margin-left", Math.floor(e.marginLeft + r / 2 / i) + "px"), n = n && Ext.util.CSS.updateRule(e.itemCls, "margin-right", Math.floor(e.marginRight + r / 2 / i) + "px")), n
        }
    },
    updateScrollbar: function(e) {
        var t = this;
        e = !!Ext.isBoolean(e) && e, e ? this.onUpdateScrollbar(e) : t.fireEvent("updateScrollbar", e)
    },
    onUpdateScrollbar: function(e) {
        var t = this;
        if (t.isVisible()) {
            var r = t.el.dom;
            r && r.fleXcroll ? (e && r.fleXcroll.setScrollPos(!1, 0), r.fleXcroll.updateScrollBars(), e || r.fleXcroll.setScrollPos(0, 0, !0)) : r && (fleXenv.fleXcrollMain(r, this.disableTextSelect), r.onfleXcroll = function() {
                t.isVisible() && t.onUpdateView && t.onUpdateView(), this.fireEvent("flexcroll", this, this.getFleXcrollInfo(t.el.dom))
            }.createDelegate(this), r.fleXcroll && this.fireEvent("flexcrollInitDone")), r = null
        }
    },
    afterRender: function() {
        var e = this;
        SYNO.SDS.Utils.DataView.LazyDataView.superclass.afterRender.call(e), e.mon(e, {
            resize: e.onResize,
            scope: e
        }), e.initKeyNav(), this.updateHeightThreshold()
    },
    onUserResize: function() {
        this.updateScrollbar(), this.updateHeightThreshold(), this.fitWidth.createSequence(function() {
            this.updateScrollbar.defer(300, this)
        }, this).defer(330, this)
    },
    onResize: function() {
        this.resizeTask || (this.resizeTask = new Ext.util.DelayedTask(this.onUserResize, this)), this.resizeTask.delay(350)
    },
    updateHeightThreshold: function() {
        !this.autoHeightThreshold || Ext.isIE && !Ext.isModernIE || (this.heightThreshold = this.getEl().getHeight())
    },
    onUpdateView: function() {
        this.delay ? (this.renderTask || (this.renderTask = new Ext.util.DelayedTask(this.searchStrategy, this)), this.renderTask.delay(this.delay)) : this.searchStrategy()
    },
    updateItem: function(e) {
        var t = this;
        e.isVisible() && !0 === t.isIntens(e, t.getEl()) ? t.onLoadItem(e) : t.onUnLoadItem(e)
    },
    lazyLoadItem: function(e) {
        this.updateItem(Ext.fly(e))
    },
    onBeforeLoad: function() {
        this.loadingText && (this.clearSelections(!1, !0), this.getEl().mask(this.loadingText, "x-mask-loading"), this.all.clear())
    },
    refresh: function() {
        var e = this;
        this.loadingText && this.getEl().unmask(), SYNO.SDS.Utils.DataView.LazyDataView.superclass.refresh.call(e), e.onUpdateView()
    },
    removeTask: function(e) {
        var t = this[e];
        t && t.cancel && (t.cancel(), this[e] = null)
    },
    destroy: function() {
        this.removeTask("renderTask"), this.removeTask("resizeTask"), SYNO.SDS.Utils.DataView.LazyDataView.superclass.destroy.call(this)
    }
}), Ext.namespace("SYNO.API"), SYNO.API.GetErrors = function() {
    var e = {};
    return e.minCustomeError = 400, e.common = {
        0: _T("common", "commfail"),
        100: _T("common", "error_system"),
        101: "Bad Request",
        102: "No Such API",
        103: "No Such Method",
        104: "Not Supported Version",
        105: _T("error", "error_privilege_not_enough"),
        106: _T("error", "error_timeout"),
        107: _T("login", "error_interrupt"),
        108: _T("user", "user_file_upload_fail"),
        109: _T("error", "error_error_system"),
        110: _T("error", "error_error_system"),
        111: _T("error", "error_error_system"),
        112: "Stop Handling Compound Request",
        113: "Invalid Compound Request",
        114: _T("error", "error_invalid"),
        115: _T("error", "error_invalid"),
        116: _JSLIBSTR("uicommon", "error_demo"),
        117: _T("error", "error_error_system"),
        118: _T("error", "error_error_system"),
        119: _T("error", "error_timeout"),
        122: _T("error", "error_privilege_not_enough"),
        123: _T("error", "error_privilege_not_enough"),
        124: _T("error", "error_privilege_not_enough"),
        125: _T("error", "error_timeout"),
        126: _T("error", "error_privilege_not_enough"),
        127: _T("error", "error_privilege_not_enough"),
        160: _T("error", "error_privilege_not_enough"),
        164: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        165: String.format(_T("error", "error_set_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>")
    }, e.core = {
        402: _T("share", "no_such_share"),
        403: _T("error", "error_invalid"),
        404: _T("error", "error_privilege_not_enough"),
        1101: _T("error", "error_subject"),
        1102: _T("firewall", "firewall_restore_failed"),
        1103: _T("firewall", "firewall_block_admin_client"),
        1104: _T("firewall", "firewall_rule_exceed_max_number"),
        1105: _T("firewall", "firewall_rule_disable_fail"),
        1198: _T("common", "version_not_support"),
        1201: _T("error", "error_subject"),
        1202: _T("firewall", "firewall_tc_ceil_exceed_system_upper_bound"),
        1203: _T("firewall", "firewall_tc_max_ceil_too_large"),
        1204: _T("firewall", "firewall_tc_restore_failed"),
        1301: _T("error", "error_subject"),
        1302: _T("firewall", "firewall_dos_restore_failed"),
        1402: _T("service", "service_ddns_domain_load_error"),
        1410: _T("service", "service_ddns_operation_fail"),
        1500: _T("common", "error_system"),
        1501: _T("common", "error_apply_occupied"),
        1502: _T("routerconf", "routerconf_external_ip_warning"),
        1503: _T("routerconf", "routerconf_require_gateway"),
        1504: _T("routerconf", "dns_setting_no_response"),
        1510: _T("routerconf", "routerconf_update_db_failed"),
        1521: _T("routerconf", "routerconf_exceed_singel_max_port"),
        1522: _T("routerconf", "routerconf_exceed_combo_max_port"),
        1523: _T("routerconf", "routerconf_exceed_singel_range_max_port"),
        1524: _T("routerconf", "routerconf_exceed_max_rule"),
        1525: _T("routerconf", "routerconf_port_conflict"),
        1526: _T("routerconf", "routerconf_add_port_failed"),
        1527: _T("routerconf", "routerconf_apply_failed"),
        1528: _T("routerconf", "protocol_on_router_not_enabled"),
        1530: _T("routerconf", "routerconf_syntax_version_error"),
        1600: _T("ups", "operation_failed"),
        1601: _T("ups", "set_info_failed"),
        1602: _T("ups", "get_info_failed"),
        1701: _T("error", "error_port_conflict"),
        1702: _T("error", "error_file_exist"),
        1703: _T("error", "error_no_path"),
        1704: _T("error", "error_error_system"),
        1706: _T("error", "error_volume_ro"),
        1903: _T("error", "error_port_conflict"),
        1904: _T("error", "error_port_conflict"),
        1905: _T("ftp", "ftp_annoymous_root_share_invalid"),
        1951: _T("error", "error_port_conflict"),
        2001: _T("error", "error_error_system"),
        2002: _T("error", "error_error_system"),
        2101: _T("error", "error_error_system"),
        2102: _T("error", "error_error_system"),
        2201: _T("error", "error_error_system"),
        2202: _T("error", "error_error_system"),
        2301: _T("error", "error_invalid"),
        2303: _T("error", "error_port_conflict"),
        2331: _T("nfs", "nfs_key_wrong_format"),
        2332: _T("user", "user_file_upload_fail"),
        2371: _T("error", "error_mount_point_nfs"),
        2372: _T("error", "error_hfs_plus_mount_point_nfs"),
        2401: _T("error", "error_error_system"),
        2402: _T("error", "error_error_system"),
        2403: _T("error", "error_port_conflict"),
        2500: _T("error", "error_unknown_desc"),
        2502: _T("error", "error_invalid"),
        2503: _T("error", "error_error_system"),
        2504: _T("error", "error_error_system"),
        2505: _T("error", "error_error_system"),
        2601: _T("network", "domain_name_err"),
        2602: _T("network", "domain_dns_name_err"),
        2603: _T("network", "domain_kdc_ip_error"),
        2604: _T("network", "error_badgname"),
        2605: _T("network", "domain_unreachserver_err"),
        2606: _T("network", "domain_port_unreachable_err"),
        2607: _T("network", "domain_password_err"),
        2608: _T("network", "domain_acc_revoked_ads"),
        2609: _T("network", "domain_acc_revoked_rpc"),
        2610: _T("network", "domain_acc_err"),
        2611: _T("network", "domain_notadminuser"),
        2612: _T("network", "domain_change_passwd"),
        2613: _T("network", "domain_check_kdcip"),
        2614: _T("network", "domain_error_misc_rpc"),
        2615: _T("network", "domain_join_err"),
        2616: _T("directory_service", "warr_enable_samba"),
        2626: _T("directory_service", "warr_db_not_ready"),
        2628: _T("directory_service", "warr_synoad_exists"),
        2702: _T("network", "status_connected"),
        2703: _T("network", "status_disconnected"),
        2704: _T("common", "error_occupied"),
        2705: _T("common", "error_system"),
        2706: _T("ldap_error", "ldap_invalid_credentials"),
        2707: _T("ldap_error", "ldap_operations_error"),
        2708: _T("ldap_error", "ldap_server_not_support"),
        2709: _T("domain", "domain_ldap_conflict"),
        2710: _T("ldap_error", "ldap_operations_error"),
        2712: _T("ldap_error", "ldap_no_such_object"),
        2713: _T("ldap_error", "ldap_protocol_error"),
        2714: _T("ldap_error", "ldap_invalid_dn_syntax"),
        2715: _T("ldap_error", "ldap_insufficient_access"),
        2716: _T("ldap_error", "ldap_insufficient_access"),
        2717: _T("ldap_error", "ldap_timelimit_exceeded"),
        2718: _T("ldap_error", "ldap_inappropriate_auth"),
        2719: _T("ldap_error", "ldap_smb2_enable_warning"),
        2721: _T("ldap_error", "ldap_confidentiality_required"),
        2723: _T("ldap_error", "ldap_weak_pwd"),
        2799: _T("common", "error_system"),
        2800: _T("error", "error_unknown_desc"),
        2801: _T("error", "error_unknown_desc"),
        2900: _T("error", "error_unknown_desc"),
        2901: _T("error", "error_unknown_desc"),
        2902: _T("relayservice", "relayservice_err_network"),
        2903: _T("relayservice", "error_alias_server_internal"),
        2904: _T("relayservice", "relayservice_err_alias_in_use"),
        2905: _T("pkgmgr", "myds_error_account"),
        2906: _T("relayservice", "error_alias_used_in_your_own"),
        3e3: _T("error", "error_unknown_desc"),
        3001: _T("error", "error_unknown_desc"),
        3002: _T("relayservice", "relayservice_err_resolv"),
        3003: _T("relayservice", "myds_server_internal_error"),
        3004: _T("error", "error_auth"),
        3005: _T("relayservice", "relayservice_err_alias_in_use"),
        3006: _T("relayservice", "myds_exceed_max_register_error"),
        3009: _T("error", "error_unknown_desc"),
        3010: _T("myds", "already_logged_in"),
        3013: _T("myds", "error_migrate_authen"),
        3015: _T("myds", "invalid_machine"),
        3106: _T("user", "no_such_user"),
        3107: _T("user", "error_nameused"),
        3108: _T("user", "error_nameused"),
        3109: _T("user", "error_disable_admin"),
        3110: _T("user", "error_too_much_user"),
        3111: _T("user", "homes_not_found"),
        3112: _T("common", "error_apply_occupied"),
        3113: _T("common", "error_occupied"),
        3114: _T("user", "error_nameused"),
        3115: _T("user", "user_cntrmvdefuser"),
        3116: _T("user", "user_set_fail"),
        3117: _T("user", "user_quota_set_fail"),
        3118: _T("common", "error_no_enough_space"),
        3119: _T("user", "error_home_is_moving"),
        3121: _T("common", "err_pass"),
        3122: _T("login", "password_in_history"),
        3123: _T("login", "password_too_common"),
        3124: _T("common", "err_pass"),
        3130: _T("user", "invalid_syntax_enclosed_trailing"),
        3131: _T("user", "invalid_syntax_double_quote_in_middle"),
        3132: _T("user", "invalid_syntax_not_double_quote_ending"),
        3191: _T("user", "user_file_open_fail"),
        3192: _T("user", "user_file_empty"),
        3193: _T("user", "user_file_not_utf8"),
        3194: _T("user", "user_upload_no_volume"),
        3202: _T("common", "error_occupied"),
        3204: _T("group", "failed_load_group"),
        3205: _T("group", "failed_load_group"),
        3206: _T("group", "error_nameused"),
        3207: _T("group", "error_nameused"),
        3208: _T("group", "error_badname"),
        3209: _T("group", "error_toomanygr"),
        3210: _T("group", "error_rmmember"),
        3217: _T("group", "error_too_many_dir_admin"),
        3221: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
        3299: _T("common", "error_system"),
        3301: _T("share", "share_already_exist"),
        3302: _T("share", "share_acl_volume_not_support"),
        3303: _T("share", "error_encrypt_reserve"),
        3304: _T("share", "error_volume_not_found"),
        3305: _T("share", "error_badname"),
        3308: _T("share", "encryption_wrong_key"),
        3309: _T("share", "error_toomanysh"),
        3312: _T("share", "share_normal_folder_exist"),
        3313: _T("share", "error_volume_not_found"),
        3314: _T("share", "error_volume_read_only"),
        3319: _T("share", "error_nameused"),
        3320: _T("share", "share_space_not_enough"),
        3321: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
        3322: _T("share", "mount_point_not_empty"),
        3323: _T("error", "error_mount_point_change_vol"),
        3324: _T("error", "error_mount_point_rename"),
        3326: _T("share", "error_key_file"),
        3327: _T("share", "share_conflict_on_new_volume"),
        3328: _T("share", "get_lock_failed"),
        3329: _T("share", "error_toomanysnapshot"),
        3330: _T("share", "share_snapshot_busy"),
        3332: _T("backup", "is_backing_up_restoring"),
        3334: _T("share", "error_mount_point_restore"),
        3335: _T("share", "share_cannot_move_fstype_not_support"),
        3336: _T("share", "share_cannot_move_replica_busy"),
        3337: _T("snapmgr", "snap_system_preserved"),
        3338: _T("share", "error_mounted_encrypt_restore"),
        3340: _T("snapmgr", "snap_restore_share_conf_err"),
        3341: _T("snapmgr", "err_quota_is_not_enough"),
        3344: _T("keymanager", "error_invalid_passphrase"),
        3345: _T("keymanager", "error_used_keystore"),
        3400: _T("error", "error_error_system"),
        3401: _T("error", "error_error_system"),
        3402: _T("error", "error_error_system"),
        3403: _T("app_privilege", "error_no_such_user_or_group"),
        3404: _T("error", "error_privilege_not_enough"),
        3405: _T("app_privilege", "error_wrong_data_format"),
        3500: _T("error", "error_invalid"),
        3501: _T("common", "error_badport"),
        3502: _T("error", "error_port_conflict"),
        3503: _T("error", "error_port_conflict"),
        3504: _T("error", "error_port_conflict"),
        3505: _T("app_port_alias", "err_fqdn_duplicated"),
        3510: _T("error", "error_invalid"),
        3511: _T("app_port_alias", "err_port_dup"),
        3550: _T("volume", "volume_no_volumes"),
        3551: _T("error", "error_no_shared_folder"),
        3552: String.format(_T("volume", "volume_crashed_service_disable"), _T("common", "web_station")),
        3553: _T("volume", "volume_expanding_waiting"),
        3554: _T("error", "error_port_conflict"),
        3555: _T("common", "error_badport"),
        3603: _T("volume", "volume_share_volumeno"),
        3604: _T("error", "error_space_not_enough"),
        3605: _T("usb", "usb_printer_driver_fail"),
        3606: _T("login", "error_cantlogin"),
        3607: _T("common", "error_badip"),
        3608: _T("usb", "net_prntr_ip_exist_error"),
        3609: _T("usb", "net_prntr_ip_exist_unknown"),
        3610: _T("common", "error_demo"),
        3611: _T("usb", "net_prntr_name_exist_error"),
        3700: _T("error", "error_invalid"),
        3701: _T("status", "status_not_available"),
        3702: _T("error", "error_invalid"),
        3710: _T("status", "status_not_available"),
        3711: _T("error", "error_invalid"),
        3712: _T("cms", "fan_mode_not_supported"),
        3720: _T("status", "status_not_available"),
        3721: _T("error", "error_invalid"),
        3730: _T("status", "status_not_available"),
        3731: _T("error", "error_invalid"),
        3740: _T("status", "status_not_available"),
        3741: _T("error", "error_invalid"),
        3750: _T("status", "status_not_available"),
        3751: _T("error", "error_invalid"),
        3760: _T("status", "status_not_available"),
        3761: _T("error", "error_invalid"),
        3795: _T("error", "error_port_conflict"),
        3800: _T("error", "error_invalid"),
        3801: _T("error", "error_invalid"),
        4e3: _T("error", "error_invalid"),
        4001: _T("error", "error_error_system"),
        4002: _T("dsmoption", "error_format"),
        4003: _T("dsmoption", "error_size"),
        4100: _T("error", "error_invalid"),
        4101: _T("error", "error_invalid"),
        4102: _T("app_port_alias", "err_alias_refused"),
        4103: _T("app_port_alias", "err_alias_used"),
        4104: _T("app_port_alias", "err_port_used"),
        4105: _T("app_port_alias", "err_port_used"),
        4106: _T("app_port_alias", "err_port_used"),
        4107: _T("app_port_alias", "err_fqdn_duplicated"),
        4154: _T("app_port_alias", "err_fqdn_duplicated"),
        4155: _T("app_port_alias", "err_port_used"),
        4156: _T("app_port_alias", "err_invalid_backend_host"),
        4164: _T("app_port_alias", "err_invalid_header_name"),
        4165: _T("app_port_alias", "err_invalid_header_value"),
        4166: _T("app_port_alias", "err_header_name_duplicated"),
        4168: _T("app_port_alias", "err_proxy_timeout"),
        4169: _T("app_port_alias", "err_proxy_timeout"),
        4170: _T("app_port_alias", "err_proxy_timeout"),
        4300: _T("error", "error_error_system"),
        4301: _T("error", "error_error_system"),
        4302: _T("error", "error_error_system"),
        4303: _T("error", "error_invalid"),
        4304: _T("error", "error_error_system"),
        4305: _T("error", "error_error_system"),
        4306: _T("error", "error_error_system"),
        4307: _T("error", "error_error_system"),
        4308: _T("error", "error_error_system"),
        4309: _T("error", "error_invalid"),
        4310: _T("error", "error_error_system"),
        4311: _T("network", "interface_not_found"),
        4312: _T("tcpip", "tcpip_ip_used"),
        4313: _T("tcpip", "ipv6_ip_used"),
        4314: _T("tunnel", "tunnel_conn_fail"),
        4315: _T("tcpip", "ipv6_err_link_local"),
        4316: _T("network", "error_applying_network_setting"),
        4317: _T("common", "error_notmatch"),
        4319: _T("error", "error_error_system"),
        4320: _T("vpnc", "name_conflict"),
        4321: _T("service", "service_illegel_crt"),
        4322: _T("service", "service_illegel_key"),
        4323: _T("service", "service_ca_not_utf8"),
        4324: _T("service", "service_unknown_cipher"),
        4325: _T("vpnc", "l2tp_conflict"),
        4326: _T("vpnc", "vpns_conflict"),
        4327: _T("vpnc", "ovpnfile_invalid_format"),
        4340: _T("background_task", "task_processing"),
        4350: _T("tcpip", "ipv6_invalid_config"),
        4351: _T("tcpip", "ipv6_router_bad_lan_req"),
        4352: _T("tcpip", "ipv6_router_err_enable"),
        4353: _T("tcpip", "ipv6_router_err_disable"),
        4354: _T("tcpip", "ipv6_no_public_ip"),
        4370: _T("ovs", "ovs_not_support_bonding"),
        4371: _T("ovs", "ovs_not_support_vlan"),
        4372: _T("ovs", "ovs_not_support_bridge"),
        4373: _T("network", "linkaggr_mode_inconsistent_err"),
        4380: _T("router_networktools", "ping_target_invalid"),
        4381: _T("router_networktools", "ping_timeout"),
        4382: _T("router_networktools", "traceroute_target_invalid"),
        4500: _T("error", "error_error_system"),
        4501: _T("error", "error_error_system"),
        4502: _T("pkgmgr", "pkgmgr_space_not_ready"),
        4503: _T("error", "volume_creating"),
        4504: _T("pkgmgr", "error_sys_no_space"),
        4506: _T("pkgmgr", "noncancellable"),
        4520: _T("error", "error_space_not_enough"),
        4521: _T("pkgmgr", "pkgmgr_file_not_package"),
        4522: _T("pkgmgr", "broken_package"),
        4529: _T("pkgmgr", "pkgmgr_pkg_cannot_upgrade"),
        4530: _T("pkgmgr", "error_occupied"),
        4531: _T("pkgmgr", "pkgmgr_not_syno_publish"),
        4532: _T("pkgmgr", "pkgmgr_unknown_publisher"),
        4533: _T("pkgmgr", "pkgmgr_cert_expired"),
        4534: _T("pkgmgr", "pkgmgr_cert_revoked"),
        4535: _T("pkgmgr", "broken_package"),
        4540: _T("pkgmgr", "pkgmgr_file_install_failed"),
        4541: _T("pkgmgr", "upgrade_fail"),
        4542: _T("error", "error_error_system"),
        4543: _T("pkgmgr", "pkgmgr_file_not_package"),
        4544: _T("pkgmgr", "pkgmgr_pkg_install_already"),
        4545: _T("pkgmgr", "pkgmgr_pkg_not_available"),
        4548: _T("pkgmgr", "install_version_less_than_limit"),
        4549: _T("pkgmgr", "depend_cycle"),
        4570: _T("common", "error_invalid_serial"),
        4580: _T("pkgmgr", "pkgmgr_pkg_start_failed"),
        4581: _T("pkgmgr", "pkgmgr_pkg_stop_failed"),
        4590: _T("pkgmgr", "invalid_feed"),
        4591: _T("pkgmgr", "duplicate_feed"),
        4592: _T("pkgmgr", "duplicate_certificate"),
        4593: _T("pkgmgr", "duplicate_certificate_sys"),
        4594: _T("pkgmgr", "revoke_certificate"),
        4595: _T("service", "service_illegel_crt"),
        4600: _T("error", "error_error_system"),
        4601: _T("error", "error_error_system"),
        4602: _T("notification", "google_auth_failed"),
        4631: _T("error", "error_error_system"),
        4632: _T("error", "error_error_system"),
        4633: _T("error", "sms_provider_not_found"),
        4634: _T("error", "sms_provider_exist"),
        4635: _T("error", "error_error_system"),
        4661: _T("pushservice", "error_update_ds_info"),
        4681: _T("error", "error_error_system"),
        4682: _T("error", "error_error_system"),
        4683: _T("error", "webhook_provider_not_found"),
        4684: _T("error", "webhook_provider_exist"),
        4685: _T("error", "error_error_system"),
        4800: _T("schedule", "error_unknown"),
        4801: _T("schedule", "error_load_failed"),
        4802: _T("schedule", "error_delete_failed"),
        4803: _T("schedule", "error_run_failed"),
        4804: _T("schedule", "error_save_failed"),
        4900: _T("error", "error_invalid"),
        4901: _T("error", "error_error_system"),
        4902: _T("user", "no_such_user"),
        4903: _T("report", "err_dest_share_not_exist"),
        4904: _T("error", "error_file_exist"),
        4905: _T("error", "error_space_not_enough"),
        5e3: _T("error", "error_invalid"),
        5001: _T("error", "error_invalid"),
        5002: _T("error", "error_invalid"),
        5003: _T("error", "error_invalid"),
        5004: _T("error", "error_invalid"),
        5005: _T("syslog", "err_server_disconnected"),
        5006: _T("syslog", "service_ca_copy_failed"),
        5007: _T("syslog", "service_ca_copy_failed"),
        5008: _T("error", "error_invalid"),
        5009: _T("error", "error_port_conflict"),
        5010: _T("error", "error_invalid"),
        5011: _T("error", "error_invalid"),
        5012: _T("syslog", "err_name_conflict"),
        5016: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5017: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5018: String.format(_T("error", "error_unexpected_load_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5019: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5020: String.format(_T("error", "error_set_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5021: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
        5100: _T("error", "error_invalid"),
        5101: _T("error", "error_invalid"),
        5102: _T("error", "error_invalid"),
        5103: _T("error", "error_invalid"),
        5104: _T("error", "error_invalid"),
        5105: _T("error", "error_invalid"),
        5106: _T("error", "error_invalid"),
        5202: _T("update", "error_apply_lock"),
        5203: _T("volume", "volume_busy_waiting"),
        5205: _T("update", "error_bad_dsm_version"),
        5206: _T("update", "update_notice"),
        5207: _T("update", "error_model"),
        5208: _T("update", "error_apply_lock"),
        5209: _T("update", "error_patch"),
        5211: _T("update", "upload_err_no_space"),
        5213: _T("pkgmgr", "error_occupied"),
        5214: _T("update", "check_new_dsm_err"),
        5215: _T("error", "error_space_not_enough"),
        5216: _T("error", "error_fs_ro"),
        5217: _T("error", "error_dest_no_path"),
        5219: _T("update", "autoupdate_cancel_failed_running"),
        5220: _T("update", "autoupdate_cancel_failed_no_task"),
        5221: _T("update", "autoupdate_cancel_failed"),
        5222: _T("update", "error_verify_patch"),
        5223: _T("update", "error_updater_prehook_failed"),
        5224: _T("update", "error_hybrid_ha_patch_version_inconsistent"),
        5225: _T("update", "error_hybrid_ha_passive_bad_model"),
        5300: _T("error", "error_invalid"),
        5301: _T("user", "no_such_user"),
        5510: _T("service", "service_illegel_crt"),
        5511: _T("service", "service_illegel_key"),
        5512: _T("service", "service_illegal_inter_crt"),
        5513: _T("service", "service_unknown_cypher"),
        5514: _T("service", "service_key_not_match"),
        5515: _T("service", "service_ca_copy_failed"),
        5516: _T("service", "service_ca_not_utf8"),
        5517: _T("certificate", "inter_and_crt_verify_error"),
        5518: _T("certificate", "not_support_dsa"),
        5519: _T("service", "service_illegal_csr"),
        5520: _T("backup", "general_backup_destination_no_response"),
        5521: _T("certificate", "err_connection"),
        5522: _T("certificate", "err_server_not_match"),
        5523: _T("certificate", "err_too_many_reg"),
        5524: _T("certificate", "err_too_many_req"),
        5525: _T("certificate", "err_mail"),
        5526: _T("s2s", "err_invalid_param_value"),
        5527: _T("certificate", "err_le_server_busy"),
        5528: _T("certificate", "err_not_synoddns"),
        5529: _T("certificate", "err_invalid_domain"),
        5530: _T("certificate", "err_challenge_unauthorized"),
        5600: _T("error", "error_no_path"),
        5601: _T("file", "error_bad_file_content"),
        5602: _T("error", "error_error_system"),
        5603: _T("texteditor", "LoadFileFail"),
        5604: _T("texteditor", "SaveFileFail"),
        5605: _T("error", "error_privilege_not_enough"),
        5606: _T("texteditor", "CodepageConvertFail"),
        5607: _T("texteditor", "AskForceSave"),
        5608: _T("error", "error_encryption_long_path"),
        5609: _T("error", "error_long_path"),
        5610: _T("error", "error_quota_not_enough"),
        5611: _T("error", "error_space_not_enough"),
        5612: _T("error", "error_io"),
        5613: _T("error", "error_privilege_not_enough"),
        5614: _T("error", "error_fs_ro"),
        5615: _T("error", "error_file_exist"),
        5616: _T("error", "error_no_path"),
        5617: _T("error", "error_dest_no_path"),
        5618: _T("error", "error_testjoin"),
        5619: _T("error", "error_reserved_name"),
        5620: _T("error", "error_fat_reserved_name"),
        5621: _T("texteditor", "exceed_load_max"),
        5703: _T("time", "ntp_service_disable_warning"),
        5800: _T("error", "error_invalid"),
        5801: _T("share", "no_such_share"),
        5901: _T("error", "error_subject"),
        5902: _T("firewall", "firewall_vpnpassthrough_restore_failed"),
        5903: _T("firewall", "firewall_vpnpassthrough_specific_platform"),
        6e3: _T("error", "error_error_system"),
        6001: _T("error", "error_error_system"),
        6002: _T("error", "error_error_system"),
        6003: _T("error", "error_error_system"),
        6004: _T("common", "loadsetting_fail"),
        6005: _T("error", "error_subject"),
        6006: _T("error", "error_service_start_failed"),
        6007: _T("error", "error_service_stop_failed"),
        6008: _T("error", "error_service_start_failed"),
        6009: _T("firewall", "firewall_save_failed"),
        6010: _T("common", "error_badip"),
        6011: _T("common", "error_badip"),
        6012: _T("common", "error_badip"),
        6013: _T("share", "no_such_share"),
        6014: _T("cms", "cms_no_volumes"),
        6015: _T("ftp", "tftp_no_privilege_restart_service"),
        6016: _T("ftp", "tftp_invalid_root_folder"),
        6200: _T("error", "error_error_system"),
        6201: _T("error", "error_acl_volume_not_support"),
        6202: _T("error", "error_fat_privilege"),
        6203: _T("error", "error_remote_privilege"),
        6204: _T("error", "error_fs_ro"),
        6205: _T("error", "error_privilege_not_enough"),
        6206: _T("error", "error_no_path"),
        6207: _T("error", "error_no_path"),
        6208: _T("error", "error_testjoin"),
        6209: _T("error", "error_privilege_not_enough"),
        6210: _T("acl_editor", "admin_cannot_set_acl_perm"),
        6211: _T("acl_editor", "error_invalid_user_or_group"),
        6212: _T("error", "error_acl_mp_not_support"),
        6213: _T("acl_editor", "quota_exceeded"),
        6215: _T("acl_editor", "acl_rules_reach_limit"),
        6216: _T("acl_editor", "error_xattr_exceeded"),
        6703: _T("error", "error_port_conflict"),
        6704: _T("error", "error_port_conflict"),
        6705: _T("user", "no_such_user"),
        6706: _T("user", "error_nameused"),
        6708: _T("share", "error_volume_not_found"),
        6709: _T("netbackup", "err_create_service_share"),
        7100: _T("connections", "error_disable_admin_name"),
        8e3: _T("router_wireless", "wifi_daemon_not_ready"),
        8001: _T("network", "net_daemon_not_ready"),
        8002: _T("network", "usbmodem_daemon_not_ready"),
        8003: _T("wireless_ap", "ap_ssid_limit_alert"),
        8010: _T("router_topology", "get_topology_fail"),
        8011: _T("network", "net_get_fail"),
        8012: _T("network", "net_get_setting_fail"),
        8013: _T("router_wireless", "wifi_setting_get_fail"),
        8020: _T("router_topology", "set_topology_fail"),
        8021: _T("network", "net_set_fail"),
        8022: _T("network", "net_set_setting_fail"),
        8023: _T("router_wireless", "wifi_setting_set_fail"),
        8030: _T("network", "get_redirect_info_fail"),
        8031: _T("router_common", "dhcp_range_conflict_err"),
        8100: _T("router_wireless", "guest_network_get_count_down_fail"),
        8101: _T("router_wireless", "guest_network_set_count_down_fail"),
        8130: _T("pppoe", "pppoe_get_setting_fail"),
        8131: _T("pppoe", "pppoe_set_setting_fail"),
        8132: _T("pppoe", "pppoe_no_interface_available"),
        8133: _T("pppoe", "pppoe_service_start_fail"),
        8134: _T("pppoe", "pppoe_service_stop_fail"),
        8135: _T("pppoe", "pppoe_connection_failed"),
        8136: _T("pppoe", "pppoe_disconnect_fail"),
        8150: _T("wireless_ap", "country_code_get_fail"),
        8151: _T("wireless_ap", "country_code_set_fail"),
        8152: _T("wireless_ap", "country_code_read_list_fail"),
        8153: _T("wireless_ap", "country_code_region_not_support"),
        8170: _T("routerconf", "routerconf_exceed_max_rule"),
        8175: _T("smartwan", "sw_too_many_rules"),
        8180: _T("routerconf", "routerconf_exceed_max_rule"),
        8190: _T("router_parental", "err_device_reach_max"),
        8200: _T("router_parental", "err_domain_name_reach_max"),
        8230: _T("routerconf", "routerconf_exceed_max_reservation"),
        8231: _T("routerconf", "routerconf_exceed_max_reservation_v6"),
        9060: _T("disk_info", "disk_upload_db_error_verify"),
        9061: _T("error", "error_space_not_enough"),
        9062: _T("disk_info", "disk_upload_db_error_version_too_old"),
        9063: _T("disk_info", "disk_upload_db_error_model_not_match")
    }, e
}, SYNO.API.AssignErrorStr = function() {
    SYNO.API.Errors = SYNO.API.GetErrors()
}, SYNO.API.AssignErrorStr(), SYNO.API.Erros = function() {
    if (Ext.isIE8) return SYNO.API.Errors;
    var e = {};
    for (var t in SYNO.API.Errors) SYNO.API.Errors.hasOwnProperty(t) && function(t) {
        Object.defineProperty(e, t, {
            get: function() {
                return SYNO.Debug.warn("SYNO.API.Erros is deprecated (typo), please use SYNO.API.Errors instead."), SYNO.API.Errors[t]
            },
            configurable: !1
        })
    }(t);
    return e
}(), inJsdom() ? window.SYNO = {
    SDS: {
        Utils: {}
    }
} : Ext.namespace("SYNO.SDS.Utils"), window._D = window._D || function() {}, window._S = window._S || function() {}, String.prototype.hashCode = function() {
    var e, t, r = 0;
    if (0 === this.length) return r;
    for (e = 0; e < this.length; e++) t = this.charCodeAt(e), r = (r << 5) - r + t, r |= 0;
    return r
}, SYNO.SDS.Utils.addFavIconLink = function(e, t, r) {
    var i, o = document.getElementsByTagName("link"),
        s = document.createElement("link");
    s.rel = "icon", s.href = e, s.setAttribute("sizes", r), t && (s.type = t);
    for (var n = document.head || document.getElementsByTagName("head")[0], a = o.length - 1; a >= 0; a--) o[a] && "icon" === o[a].getAttribute("rel") && ((i = o[a].getAttribute("sizes")) && r !== i || n.removeChild(o[a]));
    n.appendChild(s)
}, SYNO.SDS.Utils.clone = function(e) {
    if (!e || "object" !== _typeof(e)) return e;
    if ("function" == typeof e.clone) return e.clone();
    var t, r, i = "[object Array]" === Object.prototype.toString.call(e) ? [] : {};
    for (t in e) e.hasOwnProperty(t) && (r = e[t], r && "object" === _typeof(r) ? i[t] = SYNO.SDS.Utils.clone(r) : i[t] = r);
    return i
}, SYNO.SDS.Utils.mergeDeep = function(e) {
    for (var t, r = arguments.length, i = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++) i[o - 1] = arguments[o];
    if (!i.length) return e;
    var s = i.shift();
    if (Ext.isObject(e) && Ext.isObject(s))
        for (var n in s) Ext.isObject(s[n]) ? (e[n] || Object.assign(e, _defineProperty({}, n, {})), SYNO.SDS.Utils.mergeDeep(e[n], s[n])) : Object.assign(e, _defineProperty({}, n, s[n]));
    return (t = SYNO.SDS.Utils).mergeDeep.apply(t, [e].concat(i))
}, SYNO.SDS.Utils.nextElementSibling = function(e, t) {
    var r = e.nextElementSibling;
    if (!t) return r;
    for (; r;) {
        if (r.matches(t)) return r;
        r = r.nextElementSibling
    }
    return null
}, SYNO.SDS.Utils.SelectableCLS = "allowDefCtxMenu selectabletext", SYNO.SDS.Utils.IsJson = function(e) {
    return "" !== e && (e = e.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@"), e = e.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?/g, "]"), e = e.replace(/(?:^|:|,)(?:\s*\[)+/g, ""), /^[\],:{}\s]*$/.test(e))
};
var isLowLevelModel;
SYNO.SDS.Utils.isLowLevelModel = function() {
    if (Ext.isDefined(isLowLevelModel)) return isLowLevelModel;
    var e = _D("upnpmodelname");
    return isLowLevelModel = /(j|slim|se)$/.test(e) && e.indexOf("620slim") < 0
}, inJsdom() && (module.exports = SYNO.SDS.Utils), Ext.BLANK_IMAGE_URL = "scripts/ext-3/resources/images/default/s.gif", Ext.data.Connection.prototype.timeout = 12e4, Ext.form.BasicForm.prototype.timeout = 120, Ext.QuickTip.prototype.maxWidth = 500, Ext.override(Ext.QuickTip, {
    hide: function() {
        var e = function() {
            delete this.activeTarget, Ext.QuickTip.superclass.hide.call(this), this.getEl().setOpacity(1)
        };
        return this.getEl().animate({
            opacity: {
                from: 1,
                to: 0
            }
        }, .3, e.createDelegate(this))
    }
}), Ext.override(Ext.Element, {
    addClassOnHover: function(e) {
        var t = this;
        "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0 ? Ext.getDoc().on("click", function(r) {
            r.within(t) ? t.addClass(e) : t.removeClass(e)
        }, t) : t.addClassOnOver(e)
    }
}), Ext.override(Ext.Component, {
    labelSeparator: _T("common", "colon"),
    getTaskRunner: function() {
        return this.taskRunner || (this.taskRunner = new SYNO.SDS.TaskRunner, this.addManagedComponent(this.taskRunner)), this.taskRunner
    },
    addTask: function(e) {
        return this.getTaskRunner().createTask(e)
    },
    addAjaxTask: function(e) {
        return this.getTaskRunner().createAjaxTask(e)
    },
    addWebAPITask: function(e) {
        return this.getTaskRunner().createWebAPITask(e)
    },
    getTask: function(e) {
        return this.taskRunner ? this.taskRunner.getTask(e) : null
    },
    removeTask: function(e) {
        var t = this.getTask(e);
        return t && t.remove(), t
    },
    addManagedComponent: function(e) {
        return this.components = this.components || [], this.components.push(e), e
    },
    removeManagedComponent: function(e) {
        return this.components = this.components || [], this.components.remove(e), e
    },
    beforeDestroy: function() {
        this.taskRunner = null, this.components = this.components || [];
        for (var e = 0; e < this.components.length; ++e) try {
            this.components[e] instanceof Vue ? this.components[e].$destroy() : this.components[e].destroy()
        } catch (t) {
            if (Ext.isDefined(SYNO.SDS.JSDebug)) throw SYNO.Debug.error(this.id, "sub-components[" + e + "] destroy failed.", this.components[e]), t
        }
        delete this.components
    },
    findWindow: function() {
        var e = this;
        if (e instanceof SYNO.SDS.BaseWindow) return e;
        for (; Ext.isObject(e.ownerCt); e = e.ownerCt);
        return e instanceof SYNO.SDS.BaseWindow ? e : void 0
    },
    findAppWindow: function() {
        var e = function(e) {
                return e && e._isVue && "AppWindow" === e.$options.name
            },
            t = this,
            r = Ext.getClassByName("SYNO.SDS.AppWindow");
        if (!Ext.isEmpty(r)) {
            if (t instanceof r || e(t)) return t;
            if (t._appWindow instanceof r || e(t._appWindow)) return t._appWindow;
            for (; Ext.isObject(t.ownerCt); t = t.ownerCt);
            if (t instanceof r || e(t._appWindow)) return this._appWindow = t, t;
            if (Ext.isObject(t)) {
                for (; Ext.isObject(t.owner || t.$options && t.$options.owner); t = t._isVue ? t.$options.owner : t.owner);
                return t instanceof r || e(t) ? (this._appWindow = t, t) : t.module && t.module.appWin && t.module.appWin instanceof r ? (this._appWindow = t.module.appWin, t.module.appWin) : void 0
            }
        }
    },
    getDsmVersion: function() {
        var e = this.findAppWindow();
        return e ? e.getOpenConfig("dsm_version") : null
    },
    getDsmHttpPort: function() {
        var e, t = this.findAppWindow();
        return t && t.hasOpenConfig("cms_ds_data") && (e = t.getOpenConfig("cms_ds_data").http_port), e
    },
    getDsmHost: function() {
        var e, t = this.findAppWindow();
        return t && t.hasOpenConfig("cms_ds_data") && (e = t.getOpenConfig("cms_ds_data").host), e
    },
    getBaseURL: function(e, t, r) {
        return e.appWindow = this.findAppWindow(), SYNO.API.GetBaseURL(e, t, r)
    },
    sendWebAPI: function(e) {
        return e.appWindow = this.findAppWindow(), SYNO.API.Request(e)
    },
    sendWebAPIPromise: function(e) {
        return new Promise(function(t, r) {
            e.callback = function(e, i, o, s) {
                e ? t(i) : r(i)
            }, this.sendWebAPI(e)
        }.bind(this))
    },
    pollReg: function(e) {
        return e.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.Register(e)
    },
    pollUnreg: function(e) {
        return SYNO.API.Request.Polling.Unregister(e)
    },
    pollList: function(e) {
        return e.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.List(e)
    },
    downloadWebAPI: function(e) {
        return e.appWindow = this.findAppWindow(), SYNO.SDS.Utils.IFrame.requestWebAPI(e)
    },
    IsAllowRelay: function() {
        var e = this.findAppWindow();
        return !!Ext.isObject(e) && (SYNO.SDS.Utils.CMS.IsAllowRelay && SYNO.SDS.Utils.CMS.IsAllowRelay(e))
    },
    _S: function(e) {
        var t = this.findAppWindow();
        return SYNO.API.Info.GetSession(t, e)
    },
    _D: function(e, t) {
        var r = this.findAppWindow();
        return SYNO.API.Info.GetDefine(r, e, t)
    },
    getKnownAPI: function(e) {
        var t = this.findAppWindow();
        return SYNO.API.Info.GetKnownAPI(t, e)
    },
    IsKnownAPI: function(e, t) {
        var r = SYNO.API.Info.GetKnownAPI(this.findAppWindow(), e);
        return !!Ext.isObject(r) && !(t < r.minVersion || r.maxVersion < t)
    }
}), Ext.override(Ext.grid.GridView, {
    onLayout: function() {
        var e = this.el.select(".x-grid3-scroller", this),
            t = e.elements[0];
        t.clientWidth === t.offsetWidth ? this.scrollOffset = 2 : this.scrollOffset = void 0, this.fitColumns(!1)
    }
}), Ext.override(Ext.data.Record, {
    set: function(e, t) {
        var r, i = Ext.isPrimitive(t) ? String : Ext.encode;
        if (i(this.data[e]) != i(t)) {
            if (this.dirty = !0, this.modified || (this.modified = {}), e in this.modified && this.modified[e] === t) {
                this.dirty = !1, delete this.modified[e];
                for (r in this.modified)
                    if (this.modified.hasOwnProperty(r)) {
                        this.dirty = !0;
                        break
                    }
            } else e in this.modified || (this.modified[e] = this.data[e]);
            this.data[e] = t, this.editing || this.afterEdit()
        }
    }
}), Ext.override(Ext.data.Store, {
    afterEdit: function(e) {
        var t = this.modified.indexOf(e);
        e.dirty && -1 == t ? this.modified.push(e) : e.dirty || -1 == t || this.modified.splice(t, 1), this.fireEvent("update", this, e, Ext.data.Record.EDIT)
    }
}), Ext.Element.addMethods(Ext.Fx), Ext.override(Ext.dd.DragSource, {
    validateTarget: function(e, t, r) {
        return !(r !== t.getTarget().id && !t.within(r)) || (this.getProxy().setStatus(this.dropNotAllowed), !1)
    },
    beforeDragEnter: function(e, t, r) {
        return this.validateTarget(e, t, r)
    },
    beforeDragOver: function(e, t, r) {
        var i = this.validateTarget(e, t, r);
        return this.proxy && this.proxy.setStatus(i ? this.dropAllowed : this.dropNotAllowed), i
    },
    beforeDragOut: function(e, t, r) {
        return this.validateTarget(e, t, r)
    },
    beforeDragDrop: function(e, t, r) {
        return !!this.validateTarget(e, t, r) || (this.onInvalidDrop(e, t, r), !1)
    }
}), Ext.override(Ext.form.CompositeField, {
    combineErrors: !1
}), Ext.isIE && (Ext.menu.BaseItem.prototype.clickHideDelay = -1), Ext.override(Ext.Window, {
    onRender: function(e, t) {
        Ext.Window.superclass.onRender.call(this, e, t), this.plain && this.el.addClass("x-window-plain"), this.focusEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: "0",
            role: this.ariaRole || "dialog",
            "aria-label": this.title
        }, this.el.first()), this.focusEl.swallowEvent("click", !0), this.focusEl.addKeyListener(Ext.EventObject.TAB, this.onFirstTab, this), this.lastEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: 0,
            role: "article",
            html: _T("desktop", "window_last_hint")
        }), this.lastEl.addKeyListener(Ext.EventObject.TAB, this.onLastTab, this), this.proxy = this.el.createProxy("x-window-proxy"), this.proxy.enableDisplayMode("block"), this.modal && (this.maskEl = this.container.createChild({
            cls: "ext-el-mask"
        }, this.el.dom), this.maskEl.enableDisplayMode("block"), this.maskEl.hide(), this.mon(this.maskEl, "click", this.focus, this)), this.maximizable && this.mon(this.header, "dblclick", this.toggleMaximize, this), this.frame && this.header && (this.tl = this.header.dom.parentNode.parentNode.parentNode)
    },
    onLastTab: function(e, t) {
        t.shiftKey || (t.preventDefault(), this.focusEl.focus())
    },
    onFirstTab: function(e, t) {
        if (t.shiftKey) t.preventDefault(), this.lastEl.focus();
        else if (Ext.isFunction(this.findTopWin)) {
            var r = this.findTopWin();
            r !== this && (t.preventDefault(), r.focus())
        }
    },
    beforeShow: function() {
        if (delete this.el.lastXY, delete this.el.lastLT, void 0 === this.x || void 0 === this.y) {
            var e = this.el.getAlignToXY(this.container, "c-c"),
                t = this.el.translatePoints(e[0], e[1]);
            this.x = void 0 === this.x ? t.left : this.x, this.y = void 0 === this.y ? t.top : this.y
        }
        this.el.setLeftTop(this.x, this.y), this.expandOnShow && this.expand(!1), this.modal && (Ext.getBody().addClass("x-body-masked"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0)), this.maskEl.show())
    },
    onWindowResize: function() {
        this.maximized && this.fitContainer(), this.modal && (this.maskEl.setSize("100%", "100%"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0))), this.doConstrain()
    },
    setZIndex: function(e) {
        this.modal && this.maskEl.setStyle("z-index", e), this.el.setZIndex(++e), e += 5, this.resizer && this.resizer.proxy.setStyle("z-index", ++e), this.lastZIndex = e
    },
    beforeDestroy: function() {
        this.rendered && (this.hide(), this.clearAnchor(), Ext.destroy(this.focusEl, this.resizer, this.dd, this.proxy, this.maskEl)), Ext.Window.superclass.beforeDestroy.call(this)
    },
    hide: function(e, t, r) {
        return this.hidden || !1 === this.fireEvent("beforehide", this) ? this : (t && this.on("hide", t, r, {
            single: !0
        }), this.hidden = !0, void 0 !== e && this.setAnimateTarget(e), this.modal && (this.maskEl.hide(), Ext.getBody().removeClass("x-body-masked")), this.animateTarget ? this.animHide() : (this.el.hide(), this.afterHide()), this)
    },
    getFrameHeight: function() {
        var e = this.el.getFrameWidth("tb") + this.bwrap.getFrameWidth("tb");
        return e += (this.tbar ? this.tbar.getHeight() : 0) + (this.bbar ? this.bbar.getHeight() : 0), this.frame ? e += (this.tl || this.el.dom.firstChild).offsetHeight + this.ft.dom.offsetHeight + this.mc.getFrameWidth("tb") : e += (this.header ? this.header.getHeight() : 0) + (this.footer ? this.footer.getHeight() : 0), e
    },
    toFront: function(e) {
        this.manager.bringToFront(this) && (this.focusLeave = !1, e && e.getTarget().focus ? (e.getTarget().focus(), document.activeElement !== e.getTarget() && this.focus()) : this.focus())
    }
}), Ext.override(Ext.grid.RowSelectionModel, {
    silentMode: !1,
    onRefresh: function() {
        var e, t, r = this.grid.store,
            i = this.getSelections(),
            o = 0,
            s = i.length;
        for (this.silent = this.silentMode && !0, this.clearSelections(!0); o < s; o++) t = i[o], -1 != (e = r.indexOfId(t.id)) && this.selectRow(e, !0);
        i.length != this.selections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
    }
}), Ext.override(Ext.grid.GridPanel, {
    getValues: function() {
        var e = [],
            t = this.getStore();
        return Ext.isObject(t) ? (t.each(function(t, r, i) {
            e.push(Ext.apply({}, t.data))
        }, this), e) : e
    },
    setValues: function(e) {
        var t = this.getStore(),
            r = [];
        if (!Ext.isObject(t) || !Ext.isArray(e)) return !1;
        t.removeAll(), Ext.each(e, function(e) {
            r.push(new Ext.data.Record(e))
        }, this), t.add(r)
    }
}), Ext.override(Ext.grid.GridView.ColumnDragZone, {
    getDragData: function(e) {
        var t = Ext.lib.Event.getTarget(e),
            r = this.view.findHeaderCell(t);
        return !!r && {
            ddel: Ext.fly(r).child("div.x-grid3-hd-inner", !0),
            header: r
        }
    }
}), Ext.override(Ext.grid.HeaderDropZone, {
    positionIndicator: function(e, t, r) {
        var i, o, s = Ext.lib.Event.getPageX(r),
            n = Ext.lib.Dom.getRegion(Ext.fly(t).child("div.x-grid3-hd-inner", !0)),
            a = n.top + this.proxyOffsets[1];
        return n.right - s <= (n.right - n.left) / 2 ? (i = n.right + this.view.borderWidth, o = "after") : (i = n.left, o = "before"), !this.grid.colModel.isFixed(this.view.getCellIndex(t)) && (i += this.proxyOffsets[0], this.proxyTop.setLeftTop(i, a), this.proxyTop.show(), this.bottomOffset || (this.bottomOffset = this.view.mainHd.getHeight()), this.proxyBottom.setLeftTop(i, a + this.proxyTop.dom.offsetHeight + this.bottomOffset), this.proxyBottom.show(), o)
    },
    onNodeDrop: function(e, t, r, i) {
        var o = i.header;
        if (o != e) {
            var s = this.grid.colModel,
                n = Ext.lib.Event.getPageX(r),
                a = Ext.lib.Dom.getRegion(Ext.fly(e).child("div.x-grid3-hd-inner", !0)),
                l = a.right - n <= (a.right - a.left) / 2 ? "after" : "before",
                c = this.view.getCellIndex(o),
                u = this.view.getCellIndex(e);
            return "after" == l && u++, c < u && u--, s.moveColumn(c, u), !0
        }
        return !1
    }
}), Ext.override(SYNO.ux.ModuleList, {
    getLocalizedString: function(e) {
        return SYNO.SDS.UIString.GetLocalizedString(e)
    }
}), Ext.override(SYNO.ux.FieldSet, {
    stateful: !0,
    stateEvents: ["expand", "collapse"],
    getState: function() {
        return {
            collapsed: this.collapsed
        }
    },
    saveState: function() {
        var e = this.getState();
        this.setUserCollapseState(e.collapsed)
    },
    getUserCollapseState: function() {
        var e = this.getStateId(),
            t = this.findAppWindow();
        if (t && t.appInstance && e) {
            var r = t.appInstance.getUserSettings("fieldset_collapse_status") || {};
            return Ext.isBoolean(r[e]) ? r[e] : this.collapsed
        }
        return this.collapsed
    },
    setUserCollapseState: function(e) {
        var t = this.getStateId(),
            r = this.findAppWindow();
        if (r && r.appInstance && t) {
            var i = r.appInstance.getUserSettings("fieldset_collapse_status") || {};
            i[t] = e, r.appInstance.setUserSettings("fieldset_collapse_status", i)
        }
    },
    updateUserCollapseState: function() {
        var e = this.getUserCollapseState(),
            t = {
                collapsed: e
            };
        this.applyState(t)
    }
});
var _urlAppend = Ext.urlAppend;
Ext.urlAppend = function(e, t, r) {
    var i = Ext.urlDecode(t);
    return r = void 0 === r || r, r && -1 === e.indexOf("SynoToken") && !Ext.isEmpty(_S("SynoToken")) && (i.SynoToken = decodeURIComponent(_S("SynoToken"))), _urlAppend(e, Ext.urlEncode(i))
}, Ext.ns("SYNO.SDS"), Ext.Ajax.on("beforerequest", function(e, t) {
    !0 !== t.updateSynoToken && Ext.isEmpty(t.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(t.headers) && (t.headers = {}), void 0 === t.headers["X-SYNO-TOKEN"] && (t.headers["X-SYNO-TOKEN"] = _S("SynoToken")))
}), Ext.util.Observable.observeClass(Ext.form.BasicForm), Ext.form.BasicForm.on("beforeaction", function(e, t) {
    e.url && (e.url = Ext.urlAppend(e.url))
}), Ext.util.Observable.observeClass(Ext.data.Connection), Ext.data.Connection.on("beforerequest", function(e, t) {
    Ext.isEmpty(t.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(t.headers) && (t.headers = {}), t.headers["X-SYNO-TOKEN"] = _S("SynoToken"))
}), Ext.define("Ext.data.JsonP", {
    singleton: !0,
    requestCount: 0,
    requests: {},
    timeout: 3e4,
    disableCaching: !0,
    disableCachingParam: "_dc",
    callbackKey: "callback",
    request: function(e) {
        e = Ext.apply({}, e);
        var t, r, i = this,
            o = Ext.isDefined(e.disableCaching) ? e.disableCaching : i.disableCaching,
            s = e.disableCachingParam || i.disableCachingParam,
            n = ++i.requestCount,
            a = e.callbackName || "callback" + n,
            l = e.callbackKey || i.callbackKey,
            c = Ext.isDefined(e.timeout) ? e.timeout : i.timeout,
            u = Ext.apply({}, e.params),
            d = e.url;
        return o && !u[s] && (u[s] = (new Date).getTime()), e.params = u, u[l] = "Ext.data.JsonP." + a, r = e.iframeUrl ? i.createIframe(d, u, e) : i.createScript(d, u, e), i.requests[n] = t = {
            url: d,
            params: u,
            script: r,
            id: n,
            scope: e.scope,
            success: e.success,
            failure: e.failure,
            callback: e.callback,
            callbackKey: l,
            callbackName: a
        }, c > 0 && (t.timeout = setTimeout(Ext.createDelegate(i.handleTimeout, i, [t]), c)), i.setupErrorHandling(t), i[a] = Ext.createDelegate(i.handleResponse, i, [t], !0), i.loadScript(t), t
    },
    abort: function(e) {
        var t, r = this,
            i = r.requests;
        if (e) e.id || (e = i[e]), r.handleAbort(e);
        else
            for (t in i) i.hasOwnProperty(t) && r.abort(i[t])
    },
    setupErrorHandling: function(e) {
        e.script.onerror = Ext.createDelegate(this.handleError, this, [e])
    },
    handleAbort: function(e) {
        e.errorType = "abort", this.handleResponse(null, e)
    },
    handleError: function(e) {
        e.errorType = "error", this.handleResponse(null, e)
    },
    cleanupErrorHandling: function(e) {
        e.script.onerror = null
    },
    handleTimeout: function(e) {
        e.errorType = "timeout", this.handleResponse(null, e)
    },
    handleResponse: function(e, t) {
        var r = !0;
        t.timeout && clearTimeout(t.timeout), delete this[t.callbackName], delete this.requests[t.id], this.cleanupErrorHandling(t), Ext.fly(t.script).remove(), t.errorType ? (r = !1, Ext.callback(t.failure, t.scope, [t.errorType])) : Ext.callback(t.success, t.scope, [e]), Ext.callback(t.callback, t.scope, [r, e, t.errorType])
    },
    createScript: function(e, t, r) {
        var i = document.createElement("script");
        return i.setAttribute("src", Ext.urlAppend(e, Ext.urlEncode(t))), i.setAttribute("async", !0), i.setAttribute("type", "text/javascript"), i
    },
    createIframe: function(e, t, r) {
        var i, o = Ext.urlAppend(e, Ext.urlEncode(t), !1);
        if (void 0 === r.iframeUrl) return void SYNO.Debug("no iframe url");
        var s = r.iframeUrl;
        return s += "&url=" + encodeURIComponent(o), s = Ext.urlAppend(s, "", !0), i = document.createElement("iframe"), i.setAttribute("src", s), i.setAttribute("style", "visibility: hidden"), i
    },
    loadScript: function(e) {
        Ext.get(document.getElementsByTagName("head")[0]).appendChild(e.script)
    }
}), Ext.override(SYNO.ux.Button, {
    getUXMenu: function(e) {
        if (!Ext.menu.MenuMgr.getMenuList) return Ext.menu.MenuMgr.get(e);
        var t = Ext.menu.MenuMgr.getMenuList();
        return "string" == typeof e ? t ? t[e] : null : e.events ? e : "number" == typeof e.length ? new SYNO.ux.Menu({
            items: e
        }) : Ext.create(e, "syno_menu")
    },
    initComponent: function() {
        this.menu && (Ext.isArray(this.menu) && (this.menu = {
            items: this.menu
        }), Ext.isObject(this.menu) && (this.menu.ownerCt = this), this.menu = this.getUXMenu(this.menu), this.menu.ownerCt = void 0), SYNO.ux.Button.superclass.initComponent.call(this)
    }
}), Ext.override(SYNO.ux.ComboBox, {
    afterRender: function() {
        SYNO.ux.ComboBox.superclass.afterRender.call(this), this.mon(this, "expand", this.onListExpand, this)
    },
    onDestroy: function() {
        this.mun(this, "expand", this.onListExpand, this), SYNO.ux.ComboBox.superclass.onDestroy.call(this)
    },
    onListExpand: function() {
        if (SYNO.SDS.Desktop) {
            var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                t = SYNO.SDS.Desktop.getEl();
            e && this.list.parent() === Ext.getBody() ? t.appendChild(this.list) : e || this.list.parent() !== t || Ext.getBody().appendChild(this.list)
        }
    }
}), Ext.override(SYNO.ux.DateField, {
    onDestroy: function() {
        this.menu && this.mun(this.menu, "show", this.onMenuShow, this), this.callParent(arguments)
    },
    onMenuShow: function() {
        if (SYNO.SDS.Desktop) {
            var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                t = SYNO.SDS.Desktop.getEl(),
                r = this.menu.el;
            e && r.parent() === Ext.getBody() ? t.appendChild(r) : e || r.parent() !== t || Ext.getBody().appendChild(r)
        }
    }
}), Ext.override(SYNO.ux.DateTimeField, {
    initComponent: function() {
        Ext.ux.form.DateTimeField.superclass.initComponent.call(this);
        var e = this.initialConfig,
            t = SYNO.SDS.DateTimeUtils;
        this.dateFormat = void 0 === e.dateFormat ? t.GetDateFormat() : e.dateFormat, this.timeFormat = void 0 === e.timeFormat ? t.GetTimeFormat() : e.timeFormat, this.format = this.isAllDay ? this.dateFormat : this.dateFormat + " " + this.timeFormat, this.afterMethod("afterRender", function() {
            this.getEl().applyStyles("top:0")
        })
    }
}), Ext.override(SYNO.ux.Menu, {
    onMenuShow: function() {
        if (SYNO.SDS.Desktop) {
            var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                t = SYNO.SDS.Desktop.getEl();
            e && this.el.parent() === Ext.getBody() ? t.appendChild(this.el) : e || this.el.parent() !== t || Ext.getBody().appendChild(this.el), this.resetWidthForFlexcroll()
        }
    }
}), Ext.override(SYNO.ux.DatePicker, {
    getWeekdayHeader: function(e) {
        var t = this.dayNames,
            r = "ger" === _S("lang") ? 2 : 1;
        return t[e].substr(0, r)
    }
}), Ext.override(Ext.form.Radio, {
    setValue: function(e) {
        if ("boolean" == typeof e) Ext.form.Radio.superclass.setValue.call(this, e);
        else if (this.rendered) {
            var t = this.getCheckEl().select("input[name=" + this.el.dom.name + "]");
            t.each(function(t) {
                var r = Ext.getCmp(t.dom.id);
                r.setValue(e === t.dom.value), r.fireEvent("check", r, r.checked)
            }, this)
        }
        return this
    },
    onClick: function() {
        this.el.dom.checked != this.checked && this.setValue(this.el.dom.value)
    }
}), SYNO.SDS.HandShake = function() {
    var e = void 0,
        t = void 0;
    return {
        get: function() {
            return t
        },
        Init: function(e) {
            SYNO.SDS.HandShake._noise = e, SYNO.SDS.HandShake._hhid = sodium.randombytes_random() % 65536, Ext.Ajax.on("beforerequest", function(e, t) {
                if (SYNO.SDS.HandShake.IsSupport()) return !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(t), !1) : void(t && t.params && t.params.api && "SYNO.Entry.Request" !== t.params.api && (Ext.isEmpty(t.headers) && (t.headers = {}), t.headers["X-SYNO-HASH"] || (t.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt(""), t.headers["X-SYNO-HHID"] = SYNO.SDS.HandShake._hhid)))
            })
        },
        GetLoginParams: function(t) {
            var r = {
                api: "SYNO.API.Auth",
                version: 6,
                method: "login",
                session: "webui",
                hhid: SYNO.SDS.HandShake._hhid,
                enable_syno_token: _S("enable_syno_token")
            };
            r = Object.assign(r, t);
            var i = Ext.urlDecode(window.location.search.split("?")[1]);
            if ("code" === i.response_type) {
                var o = {};
                ["client_id", "session", "redirect_uri", "code_challenge", "code_challenge_method", "response_type"].forEach(function(e) {
                    e in i && (o[e] = i[e])
                }), r = Object.assign(r, o)
            }
            return r = Object.assign(i, r), SYNO.SDS.HandShake.IsSupport() && (e = SYNO.SDS.HandShake.GetInstance("Noise_IK_25519_ChaChaPoly_BLAKE2b"), e ? (r.ik_message = SYNO.SDS.HandShake.Write(e), r.version = 7, r.client = "browser") : SYNO.SDS.HandShake.UnSupport()), r
        },
        GetLoginSynoToken: function(t) {
            var r = null,
                i = Ext.urlDecode(window.location.search.split("?")[1]),
                o = i.state;
            if (!0 === t.success && "true" === i.synossoJSSDK) return void window.location.replace("webman/sso/SSOOauth.cgi" + window.location.search);
            if (t.data.code && t.data.code.length > 0) {
                if (window.opener && "" === t.data.redirect_uri) return t.data.rs = Ext.util.Cookies.get("_SSID"), window.opener.postMessage(t.data, i.opener), void window.close();
                if ("" === t.data.redirect_uri) return void window.location.replace("/error");
                var s = t.data.redirect_uri + "?code=" + t.data.code;
                return s += "&rs=" + Ext.util.Cookies.get("_SSID"), o && (s += "&state=" + o), void window.location.replace(s)
            }
            if (!0 === t.success) {
                var n = localStorage.getItem("choseAuthType");
                n && (localStorage.setItem(t.data.account + ".AuthType", n), localStorage.removeItem("choseAuthType"))
            }
            return t.data && t.data.synotoken && (r = t.data.synotoken, SYNO.SDS.HandShake.IsSupport() && (e && t.data.ik_message ? (SYNO.SDS.HandShake.Read(e, t.data.ik_message), SYNO.SDS.CrossPortStorage.SetItem("currentLoginUser", t.data.account), e = void 0) : SYNO.SDS.HandShake.UnSupport())), r
        },
        GetHeaderError: function(e) {
            if (e && e.getResponseHeader) try {
                return e.getResponseHeader("x-request-error") || e.getResponseHeader("X-Request-Error")
            } catch (t) {
                return e.getResponseHeader["x-request-error"] || e.getResponseHeader["X-Request-Error"]
            }
        },
        CheckServerError: function(e) {
            if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(e)) return !1
        },
        CheckAPIResponse: function(e, t) {
            if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(t)) return Ext.isEmpty(SYNO.SDS.Session.DelayAjax) && (SYNO.SDS.Session.DelayAjax = []), SYNO.SDS.Session.DelayAjax.push(e), !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(e), !1) : (SYNO.SDS.Session.updateSession = !0, SYNO.SDS.HandShake.TryResumeSession().then(function(e) {
                SYNO.SDS.Session.updateSession = !1, e ? SYNO.SDS.Session.DelayAjax.forEach(function(e) {
                    e.headers["X-SYNO-HASH"] && (e.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt("")), Ext.Ajax.request(e)
                }) : SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[106], !0, !1), SYNO.SDS.Session.DelayAjax = void 0
            }), !1)
        },
        GetInstance: function(e) {
            var t = SYNO.SDS.HandShake._noise,
                r = Ext.util.Cookies.get("_SSID");
            if (r) {
                var i = SYNO.SDS.CrossPortStorage.GetItem("_HSID");
                if (!i) {
                    if ("Noise_IK_25519_ChaChaPoly_BLAKE2b" !== e) return;
                    i = sodium.to_base64(t.CreateKeyPair(t.constants.NOISE_DH_CURVE25519)[0]), SYNO.SDS.CrossPortStorage.PromoteLocal(), SYNO.SDS.CrossPortStorage.SetItem("_HSID", i)
                }
                var o = t.constants.NOISE_ROLE_INITIATOR,
                    s = t.HandshakeState(e, o),
                    n = sodium.from_base64(i),
                    a = sodium.from_base64(r);
                return s.Initialize(null, n, a, null), s
            }
        },
        Write: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            return sodium.to_base64(e.WriteMessage(t))
        },
        Read: function(e, r) {
            e.ReadMessage(sodium.from_base64(r), !0), t = e.Split(), t[0].n = 0, t[1].n = 0
        },
        Encrypt: function() {
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0], arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return t ? sodium.to_base64(t[0].EncryptWithAd(new Uint8Array, new Uint8Array)) + "." + sodium.to_base64("" + t[0].n++) : ""
        },
        IsSupport: function() {
            return ("http:" !== window.location.protocol || !0 !== _S("is_secure")) && void 0 !== SYNO.SDS.HandShake._noise
        },
        UnSupport: function() {
            SYNO.SDS.HandShake._noise = void 0
        },
        TryResumeSession: function() {
            return new Promise(function(e, t) {
                var r = SYNO.SDS.HandShake.GetInstance("Noise_KK_25519_ChaChaPoly_BLAKE2b");
                if (!r) return e(!1);
                var i = SYNO.SDS.CrossPortStorage.GetItem("currentLoginUser");
                if (!i) return e(!1);
                synowebapi.request({
                    url: "webapi/entry.cgi?api=SYNO.API.Auth",
                    requestFormat: "raw",
                    responseFormat: "raw",
                    method: "POST",
                    params: {
                        api: "SYNO.API.Auth",
                        version: 7,
                        method: "resume",
                        kk_message: SYNO.SDS.HandShake.Write(r),
                        hhid: SYNO.SDS.HandShake._hhid,
                        account: i
                    },
                    callback: function(t, i) {
                        if (!i.data || !i.data.kk_message) return e(!1);
                        SYNO.SDS.HandShake.Read(r, i.data.kk_message), SYNO.SDS.Session.isLogined = !0, e(!0)
                    }
                })
            })
        }
    }
}(), Ext.namespace("SYNO.SDS.TaskRunner"), SYNO.SDS._TaskMgr = function(e) {
    var t = e || 10,
        r = [],
        i = [],
        o = 0,
        s = !1,
        n = !1,
        a = function(e, t) {
            for (var r; 0 !== t;) r = e % t, e = t, t = r;
            return e
        },
        l = function() {
            var t, i, o = r[0].interval;
            for (t = 1; i = r[t]; t++) o = a(o, i.interval);
            return Math.max(o, e)
        },
        c = function() {
            var e = l();
            return e !== t && (t = e, !0)
        },
        u = function() {
            s = !1, clearTimeout(o), o = 0
        },
        d = function() {
            s || (s = !0, c(), setImmediate(m))
        },
        h = function(e) {
            i.push(e), e.onStop && e.onStop.apply(e.scope || e)
        },
        f = function(e) {
            e.processing = !0, Promise.resolve(e.run.apply(e.scope || e, e.args || [++e.taskRunCount])).then(function(t) {
                !1 === t && h(e), e.processing = !1
            })
        },
        m = function e() {
            var s, a, l, d, m = !1,
                p = (new Date).getTime();
            for (s = 0; a = i[s]; s++) r.remove(a), m = !0;
            if (i = [], !r.length) return void u();
            for (s = 0; a = r[s]; ++s)
                if (a = r[s], !n || !0 === a.preventHalt) {
                    if (d = p - a.taskRunTime, a.interval <= d) {
                        if (!1 === a.processing) try {
                            f(a)
                        } catch (e) {
                            if (!Ext.isIE && (SYNO.Debug.error("TaskRunner: task " + a.id + " exception: ", e), Ext.isDefined(SYNO.SDS.JSDebug))) throw a.taskRunTime = p, e
                        }
                        if (a.taskRunTime = p, l = a.interval, a.interval = a.adaptiveInterval(), l !== a.interval && (m = !0), a.taskRunCount === a.repeat) return void h(a)
                    }
                    a.duration && a.duration <= p - a.taskStartTime && h(a)
                } m && c(), o = setTimeout(e, t)
        };
    this.start = function(e, t) {
        var i = (new Date).getTime();
        return r.push(e), e.taskStartTime = i, e.taskRunTime = !1 === t ? i : 0, e.taskRunCount = 0, s ? (c(), clearTimeout(o), setImmediate(m)) : d(), e
    }, this.stop = function(e) {
        return h(e), e
    }, this.stopAll = function() {
        var e, t;
        for (u(), e = 0; t = r[e]; e++) t.onStop && t.onStop();
        r = [], i = []
    }, this.setHalt = function(e) {
        n = e
    }
}, SYNO.SDS.TaskMgr = new SYNO.SDS._TaskMgr(100), SYNO.SDS.TaskRunner = Ext.extend(Ext.util.Observable, {
    tasks: null,
    constructor: function() {
        SYNO.SDS.TaskRunner.superclass.constructor.apply(this, arguments), this.addEvents("add", "remove", "beforestart"), this.tasks = {}
    },
    destroy: function() {
        this.stopAll(), this.tasks = {}, this.isDestroyed = !0
    },
    start: function(e, t) {
        if (!this.isDestroyed) return e.running || (this.fireEvent("beforestart", e), SYNO.SDS.TaskMgr.start(e, t)), e.running = !0, e
    },
    stop: function(e) {
        return e.running && SYNO.SDS.TaskMgr.stop(e), e.running = !1, e
    },
    stopAll: function() {
        for (var e in this.tasks)
            if (this.tasks.hasOwnProperty(e)) {
                if (!this.tasks[e].running) continue;
                SYNO.SDS.TaskMgr.stop(this.tasks[e])
            }
    },
    addTask: function(e) {
        return e.id = e.id || Ext.id(), this.tasks[e.id] = e, this.fireEvent("add", e), e
    },
    createTask: function(e) {
        e.id = e.id || Ext.id();
        var t = this.tasks[e.id];
        return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.Task(e, this), this.addTask(t)), t
    },
    createAjaxTask: function(e) {
        e.id = e.id || Ext.id();
        var t = this.tasks[e.id];
        return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.AjaxTask(e, this), this.addTask(t)), t
    },
    createWebAPITask: function(e) {
        e.id = e.id || Ext.id();
        var t = this.tasks[e.id];
        return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.WebAPITask(e, this), this.addTask(t)), t
    },
    removeTask: function(e) {
        var t = this.tasks[e];
        t && (this.fireEvent("remove", t), delete this.tasks[e])
    },
    getTask: function(e) {
        return this.tasks[e] || null
    }
});
var LOW_LEVEL_RUNNER_INTERVAL_PENALTY = 2;
SYNO.SDS.TaskRunner.Task = Ext.extend(Ext.util.Observable, {
    INTERVAL_DEFAULT: 6e4,
    INTERVAL_FALLBACK: 6e4,
    manager: null,
    running: !1,
    processing: !1,
    removed: !1,
    taskFirstRunTime: 0,
    constructor: function(e, t) {
        SYNO.SDS.TaskRunner.Task.superclass.constructor.apply(this, arguments), this.manager = t, this.apply(e)
    },
    apply: function(e) {
        this.applyInterval(e.interval), delete e.interval, this.applyConfig(e)
    },
    applyConfig: function(e) {
        Ext.apply(this, e)
    },
    applyInterval: function(e) {
        this.intervalData = e, Ext.isFunction(this.intervalData) || Ext.isArray(this.intervalData) || Ext.isNumber(this.intervalData) || (this.intervalData = this.INTERVAL_DEFAULT), this.interval = this.adaptiveInterval()
    },
    adaptiveInterval: function() {
        var e, t = 0,
            r = this.intervalData,
            i = null;
        if (this.taskFirstRunTime && (t = (new Date).getTime() - this.taskFirstRunTime), Ext.isNumber(r)) i = r;
        else if (Ext.isFunction(r)) i = r.call(this.scope || this, t);
        else if (Ext.isArray(r))
            for (e = 0; e < r.length && !(r[e].time > t); ++e) i = r[e].interval;
        return Ext.isNumber(i) || (SYNO.Debug.debug("TaskRunner: Task " + this.id + " interval fallback to " + this.INTERVAL_FALLBACK), i = this.INTERVAL_FALLBACK), SYNO.SDS.Utils.isLowLevelModel() && (i *= LOW_LEVEL_RUNNER_INTERVAL_PENALTY), i
    },
    start: function(e) {
        var t = (new Date).getTime();
        if (!this.removed) return this.taskFirstRunTime || (this.taskFirstRunTime = !1 === e ? t + this.interval : t), this.manager.start(this, e)
    },
    stop: function() {
        if (!this.removed) return this.manager.stop(this)
    },
    restart: function(e) {
        this.stop(), this.start(e)
    },
    remove: function() {
        this.stop(), this.manager.removeTask(this.id), this.removed = !0
    }
}), SYNO.SDS.TaskRunner.AjaxTask = Ext.extend(SYNO.SDS.TaskRunner.Task, {
    constructor: function(e, t) {
        this.reqId = null, this.reqConfig = null, this.cbHandler = null, this.autoJsonDecode = !1, this.single = !1, SYNO.SDS.TaskRunner.AjaxTask.superclass.constructor.call(this, e, t)
    },
    applyConfig: function(e) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.autoJsonDecode = !0 === e.autoJsonDecode, this.single = !0 === e.single, this.preventHalt = !0 === e.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, e, ["scope", "callback", "success", "failure"]), Ext.apply(this.reqConfig, e), Ext.apply(this.reqConfig, {
            success: null,
            failure: null,
            callback: this.onCallback,
            scope: this
        }), Ext.applyIf(this.reqConfig, {
            method: "GET"
        }), delete this.reqConfig.id, delete this.reqConfig.autoJsonDecode, delete this.reqConfig.single
    },
    stop: function() {
        this.reqId && (Ext.Ajax.abort(this.reqId), this.reqId = null), SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.apply(this, arguments)
    },
    run: function() {
        if (!this.reqConfig.url) return void this.remove();
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = Ext.Ajax.request(this.reqConfig)
    },
    onCallback: function(e, t, r) {
        var i = r,
            o = Ext.apply({}, e);
        if (Ext.apply(o, {
                scope: this.cbHandler.scope,
                callback: this.cbHandler.callback,
                success: this.cbHandler.success,
                failure: this.cbHandler.failure
            }), t && this.autoJsonDecode) try {
            i = Ext.util.JSON.decode(r.responseText)
        } catch (e) {
            i = {
                success: !1
            }, t = !1
        }
        t && o.success ? o.success.call(o.scope, i, e) : !t && o.failure && o.failure.call(o.scope, i, e), o.callback && o.callback.call(o.scope, e, t, i),
            this.fireEvent("callback", e, t, i), t && this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), SYNO.SDS.TaskRunner.WebAPITask = Ext.extend(SYNO.SDS.TaskRunner.AjaxTask, {
    constructor: function(e, t) {
        SYNO.SDS.TaskRunner.WebAPITask.superclass.constructor.call(this, e, t)
    },
    applyConfig: function(e) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.single = !0 === e.single, this.preventHalt = !0 === e.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, e, ["callback", "scope"]), Ext.apply(this.reqConfig, e), Ext.apply(this.reqConfig, {
            callback: this.onCallback,
            scope: this
        }), delete this.reqConfig.id, delete this.reqConfig.single
    },
    run: function() {
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = SYNO.API.Request(this.reqConfig)
    },
    onCallback: function(e, t, r, i) {
        var o = Ext.apply({}, i);
        Ext.apply(o, {
            scope: this.cbHandler.scope,
            callback: this.cbHandler.callback
        }), o.callback && o.callback.call(o.scope, e, t, r, o), this.fireEvent("callback", e, t, r, o), this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), SYNO.SDS.Utils.IFrame = {
    createIFrame: function(e, t) {
        var r = Ext.id(),
            i = e.createElement("iframe");
        return i.setAttribute("src", ""), i.setAttribute("id", r), i.setAttribute("name", r), t && i.setAttribute("src", t), i.setAttribute("frameBorder", "0"), i.setAttribute("style", "border:0px none;width:0;height:0;position:absolute;top:-100000px"), e.body.appendChild(i), i
    },
    cleanIframe: function(e, t) {
        try {
            Ext.EventManager.removeAll(t), Ext.destroy(t), e.body.removeChild(t), t = void 0
        } catch (e) {}
    },
    getWebAPIResp: function(e) {
        var t;
        try {
            t = Ext.decode(e.contentDocument.body.firstChild.innerHTML), Ext.isEmpty(t.success) && (t = void 0)
        } catch (e) {
            t = void 0
        }
        return t
    },
    request: function(e, t, r, i, o, s) {
        var n, a, l = document,
            c = SYNO.SDS.Utils.IFrame.createIFrame(l, i ? Ext.SSL_SECURE_URL : s ? e : Ext.urlAppend(e)),
            u = Ext.isIE ? c.contentWindow.document : c.contentDocument || window.frames[c.id].document;
        if (o = Ext.isNumber(o) ? o : 12e4, n = setTimeout(function() {
                Ext.isFunction(t) && t.call(r || this, "timeout", c), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
            }.createDelegate(this), o), i) {
            a = document.createElement("form"), a.setAttribute("name", "dlform"), a.setAttribute("action", s ? e : Ext.urlAppend(e)), a.setAttribute("method", "POST");
            for (var d in i)
                if (i.hasOwnProperty(d)) {
                    var h = i[d];
                    a.appendChild(SYNO.SDS.Utils.IFrame.createHiddenInput(d, h))
                } u.body.appendChild(a)
        }
        return Ext.EventManager.on(c, "load", function() {
            var e;
            Ext.isEmpty(n) || clearTimeout(n), Ext.isFunction(t) && (e = this.getWebAPIResp(c), Ext.isObject(e) ? t.call(r || this, "load", c, e.success, e.success ? e.data : e.error) : t.call(r || this, "load", c)), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
        }, this, {
            single: !0
        }), Ext.EventManager.on(c, "error", function() {
            Ext.isEmpty(n) || clearTimeout(n), Ext.isFunction(t) && t.call(r || this, "error", c), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
        }, this, {
            single: !0
        }), i && (a.submit(), Ext.removeNode(a)), c
    },
    requestWebAPI: function(e) {
        var t, r, i, o, s, n;
        if (!Ext.isObject(e.webapi) || !SYNO.ux.Utils.checkApiObjValid(e.webapi)) return void SYNO.Debug.error("webapi is invalid");
        if (o = e.webapi, i = Ext.isObject(e.appWindow) ? e.appWindow.findAppWindow() : e.appWindow, SYNO.SDS.Utils.CMS.IsAllowRelay(i) && i.hasOpenConfig("cms_id")) r = {
            api: "SYNO.CMS.DS",
            version: 1,
            method: "relay"
        }, s = {
            id: i.getOpenConfig("cms_id"),
            timeout: i.getOpenConfig("cms_timeout") || 120,
            webapi: Ext.apply({
                api: o.api,
                version: o.version,
                method: o.method
            }, o.params)
        }, n = o.encryption ? ["webapi"] : null;
        else {
            if (!(!1 === i || i instanceof SYNO.SDS.AppWindow)) return SYNO.Debug.error("appWindow is invalid!"), SYNO.Debug.debug("appWindow can be found by Ext.Component.findAppWindow"), void SYNO.Debug.debug("ex: this.findAppWindow() or config.module.appWin.findAppWindow()");
            r = {
                api: o.api,
                method: o.method,
                version: o.version
            }, s = o.params, n = o.encryption
        }
        return n ? (t = SYNO.API.Manager.getBaseURL(r, !1, e.filename), s = this.encodeParams(r.api, s), this.sendEncrypedRequest({
            reqObj: {
                url: t,
                params: s
            },
            reqEnc: n,
            config: e
        })) : (r.params = s, t = SYNO.API.Manager.getBaseURL(r, !1, e.filename), this.request(t, e.callback, e.scope, null, e.timeout, e.skipAppendSynoToken))
    },
    sendEncrypedRequest: function(e) {
        return SYNO.API.Manager.requestAPI(Ext.apply({
            api: "SYNO.API.Encryption",
            method: "getinfo",
            version: 1,
            params: {
                format: "module"
            },
            callback: this.onEncryptRequestAPI,
            scope: this
        }, e))
    },
    onEncryptRequestAPI: function(e, t, r, i) {
        var o, s, n = i.config,
            a = i.reqObj,
            l = i.reqEnc;
        if (e) {
            for (SYNO.Encryption.CipherKey = t.cipherkey, SYNO.Encryption.RSAModulus = t.public_key, SYNO.Encryption.CipherToken = t.ciphertoken, SYNO.Encryption.TimeBias = t.server_time - Math.floor(+new Date / 1e3), o = Ext.copyTo({}, a.params, l), o = SYNO.Encryption.EncryptParam(o), s = 0; s < l.length; s++) delete a.params[l[s]];
            a.params = Ext.apply(a.params, o)
        }
        return this.request(a.url, n.callback, n.scope, a.params, n.timeout, n.skipAppendSynoToken)
    },
    encodeParams: function(e, t) {
        return "JSON" === SYNO.API.GetKnownAPI(e, t).requestFormat ? SYNO.API.EncodeParams(t) : t
    },
    createHiddenInput: function(e, t) {
        var r = document.createElement("input");
        return r.setAttribute("type", "hidden"), r.setAttribute("name", e), r.setAttribute("value", t), r
    }
}, SYNO.SDS.Utils._Language = {
    ENU: "enu",
    FRE: "fre",
    GER: "ger",
    ITA: "ita",
    SPN: "spn",
    CHT: "cht",
    CHS: "chs",
    JPN: "jpn",
    KRN: "krn",
    THA: "tha",
    RUS: "rus",
    NLD: "nld",
    CSY: "csy",
    PLK: "plk",
    DAN: "dan",
    SVE: "sve",
    HUN: "hun",
    TRK: "trk",
    NOR: "nor",
    PTG: "ptg",
    PTB: "ptb"
}, SYNO.SDS.Utils.Language = function() {
    var e = {},
        t = {},
        r = "",
        i = function(e, t, r) {
            Ext.isIE8 ? e[t] = r : Object.defineProperty(e, t, {
                value: r,
                enumerable: !0
            })
        };
    e = {
        GetDefaultHelpLanguage: function() {
            return SYNO.SDS.Utils._Language.ENU
        },
        GetSupportedLanguage: function() {
            return t
        }
    };
    for (var o in SYNO.SDS.Utils._Language) SYNO.SDS.Utils._Language.hasOwnProperty(o) && (r = SYNO.SDS.Utils._Language[o], i(e, o, r), i(t, r, _T("common", "language_" + r)));
    return e
}(), SYNO.SDS.Utils.getHelpLanguage = function(e) {
    var t = [SYNO.SDS.Utils.Language.DAN, SYNO.SDS.Utils.Language.SVE, SYNO.SDS.Utils.Language.HUN, SYNO.SDS.Utils.Language.TRK, SYNO.SDS.Utils.Language.NOR, SYNO.SDS.Utils.Language.PTG, SYNO.SDS.Utils.Language.PTB, SYNO.SDS.Utils.Language.THA];
    return e = e || _S("lang"), -1 !== t.indexOf(e) ? SYNO.SDS.Utils.Language.GetDefaultHelpLanguage() : SYNO.SDS.Utils.Language.GetSupportedLanguage()[e] ? e : SYNO.SDS.Utils.Language.GetDefaultHelpLanguage()
}, SYNO.SDS.Utils.getSupportedLanguage = function(e) {
    var t = SYNO.SDS.Utils.Language.GetSupportedLanguage(),
        r = [],
        i = 0;
    for (var o in t) t.hasOwnProperty(o) && (r[i++] = [o, t[o]]);
    var s = function(e, t) {
        return e[1] > t[1] ? 1 : e[1] < t[1] ? -1 : 0
    };
    return r = r.sort(s), e && r.unshift(["def", _T("common", "language_def")]), r
}, SYNO.SDS.Utils.getSupportedLanguageCodepage = function(e) {
    var t = {
            enu: _T("common", "language_enu"),
            fre: _T("common", "language_fre"),
            ger: _T("common", "language_ger"),
            gre: _T("common", "language_gre"),
            heb: _T("common", "language_heb"),
            tha: _T("common", "language_tha"),
            ita: _T("common", "language_ita"),
            spn: _T("common", "language_spn"),
            cht: _T("common", "language_cht"),
            chs: _T("common", "language_chs"),
            jpn: _T("common", "language_jpn"),
            krn: _T("common", "language_krn"),
            ptb: _T("common", "language_ptb"),
            rus: _T("common", "language_rus"),
            dan: _T("common", "language_dan"),
            nor: _T("common", "language_nor"),
            sve: _T("common", "language_sve"),
            nld: _T("common", "language_nld"),
            plk: _T("common", "language_plk"),
            ptg: _T("common", "language_ptg"),
            hun: _T("common", "language_hun"),
            trk: _T("common", "language_trk"),
            csy: _T("common", "language_csy"),
            ara: _T("common", "language_ara")
        },
        r = [],
        i = 0;
    for (var o in t) t.hasOwnProperty(o) && (r[i++] = [o, t[o]]);
    var s = function(e, t) {
        return e[1] > t[1] ? 1 : e[1] < t[1] ? -1 : 0
    };
    return r = r.sort(s), e && r.unshift(["def", _T("common", "language_def")]), r
}, SYNO.SDS.Utils.isCJKLang = function() {
    switch (SYNO.SDS.Session.lang) {
        case "cht":
        case "chs":
        case "jpn":
        case "krn":
            return !0;
        default:
            return !1
    }
}, SYNO.SDS.Utils.IsCJK = function(e) {
    if (!e) return !1;
    for (var t, r = 0; r < e.length; r++)
        if (" " !== (t = e[r]) && (void 0 === t || ! function(e) {
                return /^[\u4E00-\u9FA5]|^[\uFE30-\uFFA0]/.test(e)
            }(t) && ! function(e) {
                return /^[\u0800-\u4e00]/.test(e)
            }(t) && ! function(e) {
                return /^[\u3130-\u318F]|^[\uAC00-\uD7AF]/.test(e)
            }(t))) return !1;
    return !0
}, Ext.ns("SYNO.webfm.utils"), SYNO.webfm.Cfg = {}, Ext.apply(SYNO.webfm.Cfg, {
    timeout: 6e5
}), Ext.apply(SYNO.webfm.utils, {
    ThumbSize: {
        SMALL: "S",
        MEDIUM: "M",
        LARGE: "L"
    }
}), SYNO.webfm.VFS = {}, Ext.apply(SYNO.webfm.VFS, {
    SupportChmodList: ["ftp", "sftp", "ftps"],
    isVFSPath: function(e) {
        return !!e && ("/" !== e.charAt(0) && -1 != e.indexOf("://"))
    },
    isGDrivePath: function(e) {
        return !!this.isVFSPath(e) && 0 === e.indexOf("google://")
    },
    isGDriveRootPath: function(e) {
        return !!this.isGDrivePath(e) && -1 === e.indexOf("/", String("google://").length)
    },
    isGDriveDefaultFolder: function(e) {
        return !!this.isGDrivePath(e) && 2 === e.substring(String("google://").length).split("/", 3).length
    },
    isGDriveStarsPath: function(e) {
        if (!this.isGDrivePath(e)) return !1;
        var t = e.substring(String("google://").length),
            r = t.split("/", 3);
        return 2 === r.length && "Starred" === r[1]
    },
    isGDriveStarsFirstLevelPath: function(e) {
        if (!this.isGDrivePath(e)) return !1;
        var t = e.substring(String("google://").length),
            r = t.split("/", 4);
        return 3 === r.length && "Starred" === r[1]
    },
    isOneDrivePath: function(e) {
        return !!this.isVFSPath(e) && 0 === e.indexOf("onedrive://")
    },
    isSharingPath: function(e) {
        return !!this.isVFSPath(e) && 0 === e.indexOf("sharing://")
    },
    getBaseURI: function(e) {
        if (!SYNO.webfm.VFS.isVFSPath(e)) return "";
        var t = e.indexOf("://");
        if (-1 === t) return "";
        var r = e.indexOf("/", t + 3);
        return -1 === r ? e : e.substr(0, r)
    },
    isRootFolder: function(e) {
        if (!SYNO.webfm.VFS.isVFSPath(e)) return !1;
        var t = e.indexOf("://");
        return -1 !== t && -1 === (t = e.indexOf("/", t + 3))
    },
    getSchemaFromPath: function(e) {
        if (!SYNO.webfm.VFS.isVFSPath(e)) return "";
        var t = e.indexOf("://");
        return -1 === t ? "" : e.substr(0, t)
    }
}), SYNO.webfm.SmartDDMVCPMgr = {}, Ext.apply(SYNO.webfm.SmartDDMVCPMgr, {
    filename: "",
    blCtrl: !1,
    blShift: !1,
    blDisableUpate: !1,
    blHotkey: !1,
    blSrcReadOnly: !1,
    operation: "mvcp",
    action: "move",
    defaultAction: "move",
    ghost: null,
    proxy: null,
    sourceType: null,
    onAction: function(e, t, r) {
        var i = SYNO.webfm.SmartDDMVCPMgr,
            o = r.getXY(),
            s = !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd"),
            n = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp");
        if (Ext.isEmpty(n) || s) {
            var a = new SYNO.FileStation.DragDropHintDialog({
                owner: t.owner
            });
            a.on("onAskDone", function(r) {
                i.doAction(e, t, o, r)
            }), a.show().center()
        } else i.doAction(e, t, o, i.isEnable())
    },
    doAction: function(e, t, r, i) {
        var o = SYNO.webfm.SmartDDMVCPMgr;
        i ? (t.FileAction.onBeforeSmartDDMVCP(t.ddParams.src, e.action, t.ddParams.target, t.ddParams), o.updateHotkeyAction("keyup")) : (t.onCheckVFSAction("copy", t.ddParams.src, t.ddParams.target) || (e.getComponent("copy_skip").disable(), e.getComponent("copy_overwrite").disable()), t.onCheckVFSAction("move", t.ddParams.src, t.ddParams.target) || (e.getComponent("move_skip").disable(), e.getComponent("move_overwrite").disable()), e.showAt(r))
    },
    initDragData: function(e, t) {
        var r = SYNO.webfm.SmartDDMVCPMgr;
        r.blSrcReadOnly = !1, r.isEnable() && Ext.isDefined(t) && 0 !== t.length && (e.onCheckPrivilege("move", t, !1, !1) || (r.blSrcReadOnly = !0), r.sourceType = r.getSourceTypeByPath(e, t[0].get("path")))
    },
    setDragDropData: function(e, t, r, i) {
        var o = SYNO.webfm.SmartDDMVCPMgr;
        o.filename = e, o.operation = t, o.proxy = r, o.ghost = r.getGhost()
    },
    bindHotKey: function(e) {
        var t = SYNO.webfm.SmartDDMVCPMgr;
        e.mon(e.getEl(), "keydown", t.updateHotkey, t), e.mon(e.getEl(), "keyup", t.updateHotkey, t)
    },
    focus: function(e, t) {
        t.grid ? e.enableHotKeyByFocusGrid(t.grid) : t.from ? e.enableHotKeyByFocusDataView(t.from) : e.getEl().focus()
    },
    disableUpateDDText: function(e) {
        SYNO.webfm.SmartDDMVCPMgr.blDisableUpadte = e
    },
    isEnable: function() {
        return SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp")
    },
    onDragOver: function(e) {
        var t = e.browserEvent.ctrlKey,
            r = e.browserEvent.shiftKey,
            i = SYNO.webfm.SmartDDMVCPMgr;
        t || r || (i.action = i.defaultAction, i.blHotkey = !1), t && "move" == i.action && (i.blHotkey = !0, i.action = "copy"), r && "copy" == i.action && (i.blHotkey = !0, i.action = "move"), i.updateDDText()
    },
    updateHotkey: function(e) {
        var t = SYNO.webfm.SmartDDMVCPMgr;
        t.isEnable() && e && ("keydown" !== e.type || e.ctrlKey || e.shiftKey) && ("keyup" !== e.type || !e.ctrlKey && !e.shiftKey) && (t.blCtrl = e.ctrlKey, t.blShift = e.shiftKey, t.updateHotkeyAction(e.type), t.updateDDText())
    },
    updateDefaultAction: function(e, t, r) {
        var i = SYNO.webfm.SmartDDMVCPMgr,
            o = i.blSrcReadOnly ? "copy" : "move";
        (t || r || e && i.sourceType !== e) && (o = "copy"), i.defaultAction = o
    },
    updateHotkeyAction: function(e) {
        var t = SYNO.webfm.SmartDDMVCPMgr;
        t.blHotkey || (t.action = t.defaultAction), "copy" === t.action && "keydown" === e && t.blShift ? (t.blHotkey = !0, t.action = "move") : "move" === t.action && "keydown" === e && t.blCtrl ? (t.blHotkey = !0, t.action = "copy") : "keyup" === e && (t.blHotkey = !1, t.action = t.defaultAction)
    },
    updateDDText: function() {
        var e = SYNO.webfm.SmartDDMVCPMgr;
        !e.blDisableUpadte && e.ghost && e.proxy && e.proxy.dropNotAllowed !== e.proxy.dropStatus && e.ghost.update(String.format(e.getDDText(), Ext.util.Format.htmlEncode(e.filename)))
    },
    getAction: function() {
        var e = SYNO.webfm.SmartDDMVCPMgr,
            t = e.blHotkey ? e.action : e.defaultAction;
        return "upload" === e.operation ? "copy" : t
    },
    getDDText: function(e) {
        var t = SYNO.webfm.SmartDDMVCPMgr,
            r = t.blHotkey ? t.action : t.defaultAction,
            i = "";
        return e ? i = _WFT("filetable", "filetable_copy_to") + " {0}" : ("upload" === t.operation ? i = _WFT("filetable", "upload_ddtext") : "copy" === r ? i = "download" === t.operation ? _WFT("filetable", "filetable_download") + " " + _WFT("filetable", "filetable_copy_to") + " {0}" : _WFT("filetable", "filetable_copy_to") + " {0}" : "move" === r && (i = "download" === t.operation ? _WFT("filetable", "filetable_download") + " " + _WFT("filetable", "filetable_move_to") + " {0}" : _WFT("filetable", "filetable_move_to") + " {0}"), i)
    },
    getSourceTypeByPath: function(e, t, r) {
        var i, o, s = 1,
            n = (t || e.getCurrentDir()) + "/",
            a = r || e.getCurrentSource();
        if (SYNO.webfm.utils.isLocalSource(a)) return a;
        if (SYNO.webfm.VFS.isVFSPath(n)) return SYNO.webfm.utils.source.remotevfs;
        for (; - 1 !== (s = n.indexOf("/", s));) {
            if (i = n.substr(0, s), (o = e.dirTree.getNodeById(a + i)) && o.attributes && (o.attributes.type === SYNO.webfm.utils.source.remotev || "iso" === o.attributes.mountType)) return SYNO.webfm.utils.source.remotev;
            if (o && o.attributes && (o.attributes.type === SYNO.webfm.utils.source.remoter || "remote" == o.attributes.mountType)) return SYNO.webfm.utils.source.remoter;
            s++
        }
        return a
    }
}), Ext.apply(SYNO.webfm.utils, {
    hotKey: "hotKey",
    source: {
        local: "local",
        localh: "localh",
        remote: "remote",
        remotes: "remotes",
        remotev: "remotev",
        remoter: "remoter",
        remotefav: "remotefav",
        remotevfs: "remotevfs"
    },
    snapshotTimeRenderer: function(e) {
        var t, r, i, o, s, n = /GMT\-(\d+)\.(\d+)\.(\d+)\-(\d+)\.(\d+)\.(\d+)/,
            a = /GMT(\+|\-)(\d+)\-(\d+)\.(\d+)\.(\d+)\-(\d+)\.(\d+)\.(\d+)/,
            l = new Date;
        return !(s = n.exec(e) || a.exec(e)) || s.length < 7 ? e : (t = 7 === s.length ? 1 : 3, l.setUTCFullYear(s[t++]), l.setUTCMonth(parseInt(s[t++], 10) - 1), l.setUTCDate(s[t++]), l.setUTCHours(s[t++]), l.setUTCMinutes(s[t++]), l.setUTCSeconds(s[t++]), s.length > 7 && (r = "+" === s[1] ? -1 : 1, i = parseInt(s[2].substr(0, 2), 10), o = s[2].length > 2 ? parseInt(s[2].substr(2), 10) : 0, l = l.add(Date.HOUR, r * i), l = l.add(Date.MINUTE, r * o)), SYNO.webfm.utils.DateTimeFormatter(l, {
            type: "datetimesec"
        }))
    },
    isRemoteSource: function(e) {
        var t = SYNO.webfm.utils.source;
        return e && e.substr(0, 6) === t.remote && e !== t.remotes
    },
    isLocalSource: function(e) {
        var t = SYNO.webfm.utils.source;
        return e && e.substr(0, 5) === t.local
    },
    isFavSource: function(e) {
        var t = SYNO.webfm.utils.source;
        return e.substr(0, 9) === t.remotefav
    },
    isSharingUpload: function() {
        return !Ext.isEmpty(_S("sharing_id"))
    },
    isSupportFileSystem: function() {
        return !!(window.requestFileSysteme || window.webkitRequestFileSystem || window.mozRequestFileSystem)
    },
    isSupportMultiDownload: function() {
        return !(!SYNO.webfm.utils.isSupportFileSystem() || 0 !== AppletProgram.blJavaPermission || _S("standalone") || Ext.isMac)
    },
    getWebAPIErrStr: function(e, t, r) {
        if (!t) return _WFT("error", "error_error_system");
        switch (t.code) {
            case 400:
            case 401:
                return _WFT("error", "error_error_system");
            case 402:
                return _WFT("error", "error_system_busy");
            case 403:
            case 404:
            case 405:
                return _WFT("error", "error_invalid_user_group");
            case 406:
                return _WFT("error", "error_testjoin");
            case 407:
                return _WFT("error", "error_privilege_not_enough");
            case 408:
                return _WFT("error", "error_no_path");
            case 409:
                return _WFT("error", "error_privilege_not_enough");
            case 410:
                return _WFT("error", "conn_rv_fail");
            case 411:
                return _WFT("error", "error_fs_ro");
            case 412:
                return _WFT("error", "error_long_path");
            case 413:
                return _WFT("error", "error_encryption_long_path");
            case 414:
                return _WFT("error", "error_file_exist");
            case 415:
                return _WFT("error", "error_quota_not_enough");
            case 416:
                return _WFT("error", "error_space_not_enough");
            case 417:
                return _WFT("error", "error_io");
            case 418:
                return _WFT("error", "error_reserved_name");
            case 419:
                return _WFT("error", "error_fat_reserved_name");
            case 420:
                return _WFT("error", "error_error_system");
            case 421:
                return _WFT("error", "error_folder_busy");
            case 422:
                return _WFT("error", "not_support");
            case 423:
                return _WFT("error", "volume_no_volumes");
            case 424:
                return _WFT("error", "umount_fail");
            case 425:
                return _WFT("error", "disconnect_fail");
            case 426:
                return _WFT("error", "mount_iso_fail");
            case 427:
                return _WFT("property", "error_save_property");
            case 428:
                return _WFT("error", "error_mp_external");
            case 429:
                return _WFT("error", "error_mp_encshare");
            case 430:
                return _WFT("error", "error_mp_mp");
            case 431:
                return _WFT("error", "mount_fail_reach_limit");
            case 432:
                return _WFT("mount", "err_user_home");
            case 433:
                return _WFT("mount", "err_cloud_station");
            case 434:
                return _WFT("error", "error_mp_share");
            case 435:
                return _WFT("mount", "invalid_local_host");
            case 436:
                return _WFT("mount", "bad_remote_folder");
            case 437:
                return _WFT("error", "error_mp_nfs");
            case 438:
                return _WFT("mount", "err_permission_denied");
            case 439:
                return _WFT("error", "mount_remote_fail_reach_limit");
            case 440:
                return _WFT("mount", "err_no_such_device");
            case 441:
                return _WFT("error", "mount_point_not_empty");
            case 442:
                return _WFT("error", "error_dest_no_path");
            case 443:
                return _WFT("error", "error_acl_volume_not_support");
            case 444:
                return _WFT("error", "error_fat_privilege");
            case 445:
                return _WFT("error", "error_remote_privilege");
            case 446:
                return _WFT("error", "error_no_shared_folder");
            case 447:
                return String.format(_WFT("acl_editor", "error_privilage_mode"), t.errno.arg);
            case 448:
                return _WFT("property", "error_invalid_domain_user");
            case 449:
                return _WFT("property", "error_invalid_domain_group");
            case 450:
                return _WFT("mount", "config_remote_warning");
            case 451:
                return _WFT("error", "nfs_conn_rv_fail");
            case 452:
                return _WFT("error", "error_share_quota_not_enough");
            case 453:
                return _WFT("error", "error_cifs_smb1_disabled");
            case 454:
                return _WFT("error", "error_c2share_quota_not_enough");
            case 599:
                return "";
            case 600:
                return _WFT("search", "no_search_cache");
            case 800:
                return String.format(_WFT("favorite", "same_favorite_path"), Ext.util.Format.htmlEncode(t.errors[0].path), Ext.util.Format.htmlEncode(t.errors[0].name));
            case 801:
                return String.format(_WFT("favorite", "same_favorite_name"), Ext.util.Format.htmlEncode(t.errors[0].name));
            case 802:
                return _WFT("favorite", "over_limit");
            case 900:
                return _WFT("error", "delete_error_rmdir");
            case 1004:
                return _WFT("error", "error_overwrite_fail");
            case 1005:
                return _WFT("error", "error_select_conflict");
            case 1006:
                return _WFT("error", "mvcp_filename_illegal");
            case 1007:
                return _WFT("error", "mvcp_file_too_big");
            case 1100:
                return _WFT("error", "error_error_system");
            case 1101:
                return _WFT("error", "error_too_many_folder");
            case 1102:
                return SYNO.webfm.utils.getExceedMaxFolderMsg();
            case 1200:
            case 1300:
                return _WFT("error", "error_error_system");
            case 1301:
                return _WFT("compress", "compress_error_long_name");
            case 1400:
                return _WFT("error", "error_error_system");
            case 1401:
                return _WFT("error", "error_invalid_archive");
            case 1402:
                return _WFT("error", "error_invalid_archive_data");
            case 1403:
                return _WFT("error", "extract_passwd_missing");
            case 1404:
            case 1405:
                return _WFT("error", "error_error_system");
            case 1800:
                return _WFT("upload", "upload_error_data");
            case 1801:
                return _WFT("upload", "upload_error_timeout");
            case 1802:
                return _WFT("upload", "upload_nofile");
            case 1803:
                return _WFT("connections", "kick_connection");
            case 1804:
                return _WFT("error", "mvcp_file_too_big");
            case 1805:
                return _WFT("error", "error_select_conflict");
            case 1806:
                return _WFT("error", "upload_add_vfs_queue");
            case 1807:
                return _WFT("error", "error_io");
            case 1808:
                return _WFT("error", "upload_zero_size_file_error");
            case 1809:
                return _WFT("error", "error_file_exist");
            case 1810:
                return _WFT("upload", "upload_nofile");
            case 1811:
                return _WFT("error", "error_no_path");
            case 1812:
                return _WFT("upload", "upload_exceed_maximum_filesize");
            case 1813:
                return _WFT("extract", "extract_file_exist");
            case 1900:
                return _WFT("error", "download_add_vfs_queue");
            case 2001:
                return _WFT("error", "over_account_limit");
            case 2002:
                return _WFT("error", "unknown_db_error");
            case 2100:
                return _WFT("error", "vfs_no_such_server");
            case 2101:
                return _WFT("error", "vfs_duplicated_connection");
            case 2102:
                return _WFT("error", "vfs_authentication_failed");
            case 2103:
                return _WFT("error", "vfs_host_unreachable");
            case 2104:
                return _WFT("error", "vfs_connection_refused");
            case 2105:
                return _WFT("error", "vfs_read_config_failed");
            case 2106:
                return _WFT("error", "vfs_write_config_failed");
            case 2107:
                return _WFT("error", "vfs_wrong_fingerprint");
            case 2108:
                return _WFT("error", "vfs_identity_wrong");
            case 2109:
                return _WFT("error", "vfs_conn_rv_fail");
            case 2110:
                return _WFT("error", "vfs_reach_max_server_per_protocol");
            case 2111:
                return _WFT("error", "vfs_proxy_authentication_failed");
            case 2112:
                return _WFT("error", "vfs_err_ca_wrong");
            case 2113:
                return _WFT("error", "vfs_duplicated_profile");
            case 2114:
                return _WFT("error", "vfs_root_ioerror");
            case 2115:
                return _WFT("error", "vfs_token_expired");
            case 2116:
                return _WFT("error", "vfs_filesize_too_large");
            case 2117:
                return _T("ddsm", "unsupport_on_non_privileged_mode");
            case 2118:
                return _T("login", "error_maxtried");
            case 2119:
                return _WFT("error", "mvcp_filename_illegal");
            default:
                return _WFT("error", "error_error_system")
        }
    },
    getWebAPIErr: function(e, t, r) {
        var i, o, s, n, a, l, c;
        if (!e) {
            if (t) {
                if (t && t.code < 400) return SYNO.API.CheckResponse(e, t, r);
                if (i = t.errors, 800 !== t.code && 801 !== t.code && i && Ext.isArray(i) && i && 0 < i.length) {
                    for (l = i.length > 15 ? 15 : i.length, a = _WFT("error", "error_files"), o = 0; o < l; o++) n = i[o], n.path && (c = n.path, c = c.length > 52 ? '<span ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(n.path)) + '">' + Ext.util.Format.htmlEncode(c.substr(0, 25) + " ... " + c.substr(c.length - 25)) + "</span>" : Ext.util.Format.htmlEncode(c), a += "<br>" + c, (s = SYNO.webfm.utils.getWebAPIErr(e, n, r)) && (a += "&nbsp;(" + s + ")"));
                    l < i.length && (a += "<br>...")
                }
                return a || (a = SYNO.webfm.utils.getWebAPIErrStr(e, t, r)), a
            }
            return _WFT("error", "error_error_system")
        }
    },
    getExceedMaxFolderMsg: function() {
        var e = [_WFT("error", "error_exceed_folder_limit")];
        return _S("is_admin") && (e.push('<a class="pathlink" tabIndex="0"> '), e.push(_WFT("common", "goto_setting")), e.push("</a>")), e.join("")
    },
    isCompressFile: function(e, t) {
        if (t = t.toLowerCase(), -1 !== SYNO.webfm.utils.archive_type.indexOf(t)) return !0;
        var r, i = e.split(".");
        return 2 < i.length && (r = i[i.length - 2].toLowerCase(), -1 !== SYNO.webfm.utils.archive_type.indexOf(r) && ("001" === t || "000" === t))
    },
    getPathSeparator: function(e) {
        return !!e && SYNO.webfm.utils.isLocalSource(e) && Ext.isWindows ? "\\" : "/"
    },
    checkFileLen: function(e, t) {
        var r = window.unescape(encodeURIComponent(e)).length;
        return t && (r += t), r <= 255
    },
    getLangText: function(e) {
        return _WFT(e.section, e.key)
    },
    isNameReserved: function(e) {
        return "@eaDir" == e.toLowerCase()
    },
    isNameCharIllegal: function(e) {
        return -1 != e.indexOf("/")
    },
    ParseArrToFileName: function(e, t, r) {
        var i, o = r || "/",
            s = [];
        for (i = 0; i < e.length; i++) s.push(SYNO.webfm.utils.parseFullPathToFileName(e[i], o));
        return s.join(", ")
    },
    ParseArr: function(e, t) {
        var r, i = [];
        for (r = 0; r < e.length; r++) i.push(e[r].get(t));
        return i
    },
    ParsePairArr: function(e, t, r) {
        var i, o = [];
        for (i = 0; i < e.length; i++) o.push({
            file: e[i].get(t),
            path: r[i]
        });
        return o
    },
    ParseArrToJSON: function(e, t) {
        var r, i = [];
        for (r = 0; r < e.length; r++) i.push(e[r].get(t));
        return Ext.util.JSON.encode(i)
    },
    isConflictTargetPath: function(e, t, r) {
        var i = r || "/",
            o = "",
            s = "";
        if (t.length < e.length) {
            var n = e.lastIndexOf(i);
            return "\\" === r && ":" === e[n - 1] && n++, s = e.substring(n), t + s == e
        }
        return t.length == e.length ? t == e : (o = t.substring(0, e.length), s = t.substring(e.length), o == e && i == s.charAt(0))
    },
    isSubNotEqualPath: function(e, t, r) {
        var i = r || "/",
            o = "",
            s = "";
        return !(t.length <= e.length) && (o = t.substring(0, e.length), s = t.substring(e.length), o == e && i == s.charAt(0))
    },
    getParentDirArr: function(e, t) {
        var r = t || "/",
            i = [],
            o = -1,
            s = "";
        if (!(e instanceof Array)) return o = e.lastIndexOf(r), s = e.substring(0, o), "\\" === r && -1 === s.indexOf(r) && (s += "\\"), i.push(s), i;
        var n = e[0].data || e[0];
        i = this.getParentDirArr(n.file_id, r);
        for (var a = 0; a < e.length; a++) n = e[a].data || e[a], n.isdir && (s = n.file_id, o = s.lastIndexOf(r), s = s.substring(0, o), "\\" === r && -1 === s.indexOf(r) && (s += "\\"), this.strElementInArray(s, i) || i.push(s));
        return i
    },
    strElementInArray: function(e, t) {
        for (var r = 0; r < t.length; r++)
            if (e == t[r]) return !0;
        return !1
    },
    replaceDLNameSpecChars: function(e) {
        var t = Ext.isWindows ? /[\/\\\:\?\>\<\*\"\|]/g : /[\/\\\:]/g;
        return e.replace(t, "-")
    },
    checkIfNeedRedirect: function(e, t, r) {
        return !!(r && "login" == e || "error" == e && "error_testjoin" == t) && ("true" == _S("customized") ? window.location = "webUI/logout.cgi" : window.location = "/index.cgi", alert(_WFT(e, t)), !0)
    },
    parseFullPathToFileName: function(e, t) {
        var r = t || "/",
            i = e.lastIndexOf(r);
        return -1 == i && (i = e.lastIndexOf("\\" === r ? "/" : "\\")), e.substring(i + 1)
    },
    isParentDir: function(e, t) {
        if (!e || !t) return !1;
        var r = e.lastIndexOf("/");
        return -1 !== r && 0 !== r && e.substring(0, r) == t
    },
    isWinParentDir: function(e, t) {
        if (!e || !t) return !1;
        var r = e.lastIndexOf("\\");
        if (r < 2) return !1;
        return (3 != e.length ? e.substring(0, r + 1) : e) == t
    },
    utfencode: function(e) {
        e = e.replace(/\r\n/g, "\n");
        for (var t = "", r = 0; r < e.length; r++) {
            var i = e.charCodeAt(r);
            i < 128 ? t += String.fromCharCode(i) : i > 127 && i < 2048 ? (t += String.fromCharCode(i >> 6 | 192), t += String.fromCharCode(63 & i | 128)) : (t += String.fromCharCode(i >> 12 | 224), t += String.fromCharCode(i >> 6 & 63 | 128), t += String.fromCharCode(63 & i | 128))
        }
        return t
    },
    bin2hex: function(e) {
        e = SYNO.webfm.utils.utfencode(e);
        var t, r = 0,
            i = [];
        for (e += "", r = e.length, t = 0; t < r; t++) i[t] = e.charCodeAt(t).toString(16).replace(/^([\da-f])$/, "0$1");
        return i.join("")
    },
    checkPointInBox: function(e, t, r) {
        return !(t < e.x || r < e.y) && (e.right > t && e.bottom > r)
    },
    getBaseName: function(e, t) {
        var r = t || "/";
        if (!Ext.isDefined(e)) return "";
        var i = "",
            o = e.lastIndexOf(r);
        return -1 != o && (i = e.substr(o + 1)), i
    },
    getExt: function(e) {
        var t = SYNO.webfm.utils.getBaseName(e);
        e = t || e;
        var r = e.lastIndexOf(".");
        return -1 === r ? "" : e.substr(r + 1).toLowerCase()
    },
    getFullSize: function(e) {
        var t = 0;
        return t = parseFloat(e), Ext.isString(e) ? (e.indexOf("KB") > 0 ? t *= 1024 : e.indexOf("MB") > 0 ? t *= 1048576 : e.indexOf("GB") > 0 && (t *= 1073741824), t) : t
    },
    doesIncludeMountPoint: function(e) {
        return e && Ext.each(e, function(e) {
            if (e.data && "" !== e.data.mountType) return !0
        }), !1
    },
    getSupportedLanguage: function() {
        var e = SYNO.SDS.Utils.getSupportedLanguageCodepage();
        return e.push(["utf8", _WFT("codepage", "unicode")]), e
    },
    transNodeToRecs: function(e) {
        var t = e.attributes.path || "",
            r = e.attributes.real_path,
            i = e.attributes.name,
            o = e.attributes.uid,
            s = e.attributes.gid,
            n = e.attributes.right,
            a = e.attributes.ftpright,
            l = e.attributes.isMountPoint,
            c = e.attributes.mountType,
            u = [];
        return u[0] = new Ext.data.Record({
            uid: o,
            gid: s,
            isdir: !0,
            ftpright: a,
            fileprivilege: n,
            file_id: t,
            real_path: r,
            isMountPoint: l,
            mountType: c,
            filename: i,
            size: 0,
            type: ""
        }), u
    },
    isShareByPath: function(e) {
        return -1 === e.indexOf("/", 1)
    },
    getRemoteTreeParams: function(e, t, r) {
        delete e.baseParams.folder_path, delete e.baseParams.type, r ? (e.api = "SYNO.FileStation.VirtualFolder", e.method = "list", e.version = 2, e.dataroot = ["data", "folders"], e.baseParams.type = r) : "fm_fav_root" === t.id ? (e.api = "SYNO.FileStation.Favorite", e.method = "list", e.version = 2, e.dataroot = ["data", "favorites"], e.baseParams.enum_cluster = !0) : "fm_root" === t.id ? (e.api = "SYNO.FileStation.List", e.method = "list_share", e.version = 2, e.dataroot = ["data", "shares"]) : "fm_rf_root" === t.id ? (e.api = "SYNO.FileStation.VirtualFolder", e.method = "list", e.version = 2, e.dataroot = ["data", "folders"], e.baseParams.type = ["cifs", "nfs"]) : "fm_vd_root" === t.id ? (e.api = "SYNO.FileStation.VirtualFolder", e.method = "list", e.version = 2, e.dataroot = ["data", "folders"], e.baseParams.type = "iso") : (e.api = "SYNO.FileStation.List", e.method = "list", e.version = 2, e.dataroot = ["data", "files"], e.baseParams.folder_path = t.attributes.path)
    },
    parseRemoteTreeNode: function(e, t) {
        if (t) {
            var r = e.additional;
            e.leaf = !1, "fm_root" === t.id ? e.draggable = !1 : e.draggable = !0;
            var i = "";
            switch (t.attributes.type && (i = t.attributes.type), t.id) {
                case "fm_fav_root":
                    i = SYNO.webfm.utils.source.remotefav + e.name;
                    break;
                case "fm_vd_root":
                    i = SYNO.webfm.utils.source.remotev;
                    break;
                case "fm_rf_root":
                    i = SYNO.webfm.utils.source.remoter, e.draggable = !1;
                    break;
                default:
                    "fm_top_root" === t.parentNode.id && (i = SYNO.webfm.utils.source.remote)
            }
            if (e.id = i + e.path, e.type = i, e.text = e.name, e.qtip = e.text, e.children && e.children.files && (e.children = e.children.files), !r) return e;
            if (r.volume && (e.qtip = String.format("{0} @{1}", e.qtip, r.volume)), r.volume_status) {
                var o = r.volume_status;
                0 <= o.totalspace && 0 <= o.freespace && (e.qtip = String.format("{0}, {1}", e.qtip, String.format(_T("filetable", "space_size"), Ext.util.Format.fileSize(o.freespace), Ext.util.Format.fileSize(o.totalspace))))
            }
            if (e.real_path = r.real_path, e.isMountPoint = !Ext.isEmpty(r.mount_point_type), e.mountType = r.mount_point_type, r.time && (e.mt = r.time.mtime, e.at = r.time.atime, e.ct = r.time.crtime), r.perm) {
                if (r.perm.posix && (e.privilege = r.perm.posix), r.perm.acl) {
                    var s, n = r.perm.acl;
                    n.append && (s |= SYNO.webfm.utils.Mode_Append), n.del && (s |= SYNO.webfm.utils.Mode_Del), n.exec && (s |= SYNO.webfm.utils.Mode_Exec), n.read && (s |= SYNO.webfm.utils.Mode_Read), n.write && (s |= SYNO.webfm.utils.Mode_Write), e.right = s
                }
                r.perm.share_right && (e.right = r.perm.share_right), Ext.isBoolean(r.perm.acl_enable) && (e.isACLPrivilege = r.perm.acl_enable), e.ftpright = 0, r.perm && r.perm.adv_right && (Ext.isBoolean(r.perm.adv_right.disable_download) && (r.perm.adv_right.disable_download && (e.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD), e.is_disable_download = r.perm.adv_right.disable_download), Ext.isBoolean(r.perm.adv_right.disable_modify) && (r.perm.adv_right.disable_modify && (e.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY), e.is_disable_modify = r.perm.adv_right.disable_modify), Ext.isBoolean(r.perm.adv_right.disable_list) && (r.perm.adv_right.disable_list && (e.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST), e.bldisablesearch = !0, e.is_disable_list = r.perm.adv_right.disable_list))
            }
            return r.owner && (e.owner = r.owner.user, e.group = r.owner.group, e.uid = r.owner.uid, e.gid = r.owner.gid), Ext.isBoolean(r.sync_share) && (e.is_sync_share = r.sync_share), e.bldisablesearch = !1, SYNO.webfm.utils.isRecycleBinFolder(e.path) && (e.bldisablesearch = !0), e.isMountPoint && e.mountType && ("iso" == e.mountType ? e.cls = "isomountpoint_node" : "remote" == e.mountType ? e.cls = "remotemountpoint_node" : "remotefail" == e.mountType && (e.cls = "remotefailmountpoint_node")), t.attributes.isMountPoint && SYNO.webfm.utils.updateRemoteMountIconByNode(t), "broken" === e.status && (e.cls = "tree-node-broken-folder"), SYNO.webfm.utils.IndexFolderMap[e.path] = r.indexed || !1, e
        }
    },
    isRecycleBinFolder: function(e) {
        if (!e) return !1;
        var t = e.split("/", 7);
        return 3 === t.length && "#recycle" === t[2] || 4 === t.length && "homes" === t[1] && "#recycle" === t[3] || 6 === t.length && "homes" === t[1] && "#recycle" === t[5]
    },
    isInRecycleBinFolder: function(e) {
        if (!e) return !1;
        var t = e.split("/");
        return t.length >= 3 && "#recycle" === t[2] || t.length >= 4 && "homes" === t[1] && "#recycle" === t[3] || t.length >= 6 && "homes" === t[1] && "#recycle" === t[5]
    },
    isSnapshotFolder: function(e, t, r) {
        return this.isSnapshotShareFolder(e, t, r) || this.isSnapshotTopFolder(e, t)
    },
    isInHybridShareFolder: function(e, t) {
        if (!e) return !1;
        var r = e.split("/");
        return t.hasOwnProperty(r[1])
    },
    isSnapshotShareFolder: function(e, t, r) {
        if (!e || !t || !r) return !1;
        var i = e.split("/", 7);
        return 4 === i.length && "#snapshot" === i[2]
    },
    isSnapshotTopFolder: function(e, t) {
        if (!e || !t) return !1;
        var r = e.split("/", 7);
        return 3 === r.length && "#snapshot" === r[2]
    },
    isWebFolder: function(e) {
        return !!e && ("/" !== e[e.length - 1] && (e += "/"), 0 === e.indexOf("/web/") || 0 === e.indexOf("/home/www/") || 0 === e.indexOf("/homes/") && -1 !== e.indexOf("/www/"))
    },
    createCAErrorMsg: function(e) {
        var t = new Date,
            r = function(e) {
                var t = new Date(e || 0);
                return SYNO.webfm.utils.DateTimeFormatter(t, {
                    type: "date"
                })
            },
            i = [_WFT("error", "vfs_ca_unknown"), _T("certificate", "server_crt") + ":", String.format(_WFT("vfs", "vfs_ca_subject"), e.subject), String.format(_WFT("vfs", "vfs_ca_issuer"), e.issuer)];
        return (e.availDate > t.getTime() / 1e3 || e.expDate < t.getTime() / 1e3) && i.push(String.format(_WFT("vfs", "vfs_ca_availdate"), r(1e3 * e.availDate)), String.format(_WFT("vfs", "vfs_ca_expdate"), r(1e3 * e.expDate))), i.join("<br>")
    },
    getThumbName: function(e) {
        if (e.isdir) {
            var t = e.mountType;
            if (!Ext.isEmpty(t)) switch (t) {
                case "remote":
                    return "remotemountpoint.png";
                case "remotefail":
                    return "remotefailmountpoint.png";
                case "iso":
                    return "isomountpoint.png"
            }
            return SYNO.webfm.utils.isRecycleBinFolder(e.path) ? "recycle_bin.png" : SYNO.webfm.utils.isSnapshotFolder(e.path, e.is_snapshot, e.is_btrfs_subvol) ? "snapshot.png" : "folder.png"
        }
        var r = e.type;
        return r ? (r = r.toLowerCase(), -1 !== SYNO.webfm.utils.icon_type.indexOf(r) ? r + ".png" : "misc.png") : "misc.png"
    },
    onMailTo: function(e) {
        var t = e,
            r = "mailto:?subject=My DS Shared File Links&body=" + t;
        window.open(r, "_blank")
    },
    handleRemoteConnectionException: function(e, t, r, i, o, s, n) {
        var a = SYNO.API.Util.GetFirstError(e),
            l = function(e) {
                if ("yes" !== e) return void o.call(this);
                n ? i.call(this) : r.sendWebAPI({
                    timeout: 36e5,
                    api: "SYNO.FileStation.VFS.Connection",
                    method: "create",
                    version: 1,
                    params: {
                        profile_id: t.id,
                        force: !0
                    },
                    encryption: ["password", "access_token", "refresh_token"],
                    scope: s,
                    callback: function(e, t, r, o) {
                        i.call(this)
                    }
                })
            },
            c = function(e) {
                if ("yes" !== e) return void o.call(this);
                var n = t.id,
                    a = SYNO.webfm.VFS.getSchemaFromPath(t.id),
                    l = function(e) {
                        e.id = n;
                        var t = [{
                            timeout: 36e5,
                            api: "SYNO.FileStation.VFS.Connection",
                            method: "set",
                            version: 1,
                            params: e
                        }, {
                            api: "SYNO.FileStation.VFS.Profile",
                            method: "set",
                            version: 1,
                            params: e
                        }];
                        r.sendWebAPI({
                            params: {},
                            compound: {
                                stopwhenerror: !0,
                                params: t
                            },
                            encryption: ["password", "access_token", "refresh_token"],
                            scope: s,
                            callback: function(e, t, o, n) {
                                r.isDestroyed || i.call(s)
                            }
                        })
                    };
                SYNO.webfm.utils.startOAuth(a, l, s)
            },
            u = function(e) {
                if ("yes" !== e) return void o.call(this);
                var n = new SYNO.FileStation.RemoteConnection.EditDialog({
                    owner: r,
                    title: _WFT("vfs", "edit_profile")
                });
                this.mon(n, "editcomplete", i.createDelegate(s)), n.load(t.id)
            };
        switch (a.code) {
            case 2102:
                r.getMsgBox().confirm("", _WFT("error", "vfs_confirm_edit_profile"), u, s);
                break;
            case 2107:
                r.getMsgBox().confirm("", String.format(_WFT("error", "vfs_identity_unknown"), a.errors[0].fingerprint), l, s);
                break;
            case 2112:
                r.getMsgBox().confirm("", SYNO.webfm.utils.createCAErrorMsg(a.errors[0]), l, s);
                break;
            case 2115:
                r.getMsgBox({
                    preventDelay: !0
                }).confirm("", _WFT("error", "vfs_confirm_refresh_oauth"), c, s)
        }
    },
    startOAuth: function(e, t, r) {
        var i = window.location.href.indexOf("/", window.location.protocol.length + 2),
            o = window.location.href.slice(0, i);
        if (_S("rewrite_mode")) {
            var s = window.location.href.indexOf("/", i + 1);
            if (-1 !== s) {
                o += window.location.href.slice(i, s)
            }
        }
        this.register(e, t, r, "_webfmOAuthCallback"), this.popup = window.open("https://synooauth.synology.com/FileStation/Cloud/login.php?" + Ext.urlEncode({
            major: _S("majorversion"),
            minor: _S("minorversion"),
            version: _S("version"),
            fullversion: _S("fullversion"),
            unique: _D("unique"),
            timezone: _D("timezone"),
            callback: "_webfmOAuthCallback",
            host: o,
            type: e
        }), "mywindow", "menubar=1,resizable=0,width=600,height=520, top=100, left=300"), this.addPopupTimer(this)
    },
    updateRemoteMountIconByNode: function(e) {
        e && e.ui && e.ui.elNode && "remotefail" === e.attributes.mountType && Ext.fly(e.ui.elNode).hasClass("remotefailmountpoint_node") && (Ext.fly(e.ui.elNode).replaceClass("remotefailmountpoint_node", "remotemountpoint_node"), e.attributes.mountType = "remote")
    },
    register: function(e, t, r, i) {
        Ext.isIE || Ext.isIE11 ? window[i] = function(i) {
            i.protocol = e, t.call(r, i)
        } : (this.receiveMessage = function(o) {
            var s = o.browserEvent;
            if (s.origin === window.location.origin && !/setImmediate/.test(s.data)) {
                var n = JSON.parse(s.data);
                n.callback === i && (n.protocol = e, t.call(r, n))
            }
        }, Ext.EventManager.addListener(window, "message", this.receiveMessage))
    },
    unregister: function() {
        Ext.isIE || Ext.isIE11 || Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    },
    addPopupTimer: function(e) {
        if (e.popup && !e.popup.closed) var t = window.setInterval(function() {
            e.popup.closed && (e.unregister(), window.clearInterval(t), t = null)
        }, 1e3)
    },
    doClosePopup: function() {
        this.popup && !this.popup.closed && this.popup.close()
    },
    isRootNode: function(e) {
        return "fm_root" === e.id || "fm_local_root" === e.id || "fm_vd_root" === e.id || "fm_rf_root" === e.id || "fm_fav_root" === e.id || "fm_top_root" === e.id || e.parentNode && "fm_top_root" === e.parentNode.id || !0 === e.hidden
    }
}), SYNO.webfm.Plugin = {}, Ext.apply(SYNO.webfm.Plugin, {
    checkFileType: function(e, t, r) {
        var i = !0;
        return Ext.each(r, function(r) {
            var o = r.get("type") && r.get("type").toLowerCase() || r.get("filename") && SYNO.webfm.utils.getExt(r.get("filename")),
                s = r.get("isdir") ? t.dir : t.file;
            return !1 === t.support_mnt_point && "remotev" === SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(e, r.get("path")) ? i = !1 : !1 === s || Ext.isArray(s) && 0 > s.indexOf(o) ? i = !1 : void 0
        }, this), i
    },
    checkActionByPlugin: function(e, t, r, i, o) {
        var s, n;
        o && (s = o.arg1, n = o.warning_fn);
        var a = !0,
            l = [],
            c = i[0].get("path"),
            u = !1;
        if (c && SYNO.webfm.VFS.isVFSPath(c) && (u = !0), Ext.each(e.actionPlugins[r], function(t) {
                if (t.checkFn) {
                    var o = t.plugin.data;
                    if (!(1 < i.length && !0 !== o.multiple) && (!u || o.vfs) && SYNO.webfm.Plugin.checkFileType(e.webfm, o, i)) try {
                        var n = t.checkFn.call(e.webfm, r, i, s);
                        !1 === n ? a = "error" : Ext.isString(n) ? (a = "error", l.push(n)) : Ext.isObject(n) && (a = "error" !== a && "warning" === n.type ? n.type : "error", n.msg && l.push(n.msg))
                    } catch (e) {
                        return void SYNO.Debug(e)
                    }
                }
            }, this), !0 !== a) {
            var d = Ext.isEmpty(l) ? _WFT("error", "action") : l.join("<br>");
            if ("error" === a) return t.getMsgBox().alert("", d), !1;
            n ? n.call(o ? o.scope : null, l) : o && t.getMsgBox().confirm("", d, function(e) {
                "yes" == e && o.fn && o.fn.call(o.scope)
            })
        } else o && o.fn && o.fn.call(o.scope);
        return a
    }
}), SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST = 1, SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY = 2, SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD = 4, SYNO.webfm.utils.NA = 1, SYNO.webfm.utils.RW = 2, SYNO.webfm.utils.RO = 4, SYNO.webfm.utils.Mode_Exec = 1, SYNO.webfm.utils.Mode_Write = 2, SYNO.webfm.utils.Mode_Read = 4, SYNO.webfm.utils.Mode_Append = 8, SYNO.webfm.utils.Mode_Del = 512, SYNO.webfm.utils.Mode_All = 8191, SYNO.webfm.utils.ReqPrivilege = {}, SYNO.webfm.utils.ReqPrivilege.SrcFolder = {}, SYNO.webfm.utils.ReqPrivilege.DestFolder = {}, SYNO.webfm.utils.ReqPrivilege.SrcFile = {}, SYNO.webfm.utils.ReqPrivilege.DestFolder.Create = SYNO.webfm.utils.Mode_Exec | SYNO.webfm.utils.Mode_Append, SYNO.webfm.utils.ReqPrivilege.SrcFile.Copy = SYNO.webfm.utils.Mode_Read, SYNO.webfm.utils.ReqPrivilege.DestFolder.Copy = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.CopyDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.SrcFile.Move = SYNO.webfm.utils.Mode_Del, SYNO.webfm.utils.ReqPrivilege.DestFolder.Move = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.MoveDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.SrcFile.Delete = SYNO.webfm.utils.Mode_Del, SYNO.webfm.utils.ReqPrivilege.DestFolder.Upload = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.UploadDir = SYNO.webfm.utils.Mode_Exec | SYNO.webfm.utils.Mode_Append, SYNO.webfm.utils.ReqPrivilege.SrcFile.Download = SYNO.webfm.utils.Mode_Read, SYNO.webfm.utils.ReqPrivilege.SrcFolder.Download = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.Navigate = SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.SrcFile.Extract = SYNO.webfm.utils.Mode_Read, SYNO.webfm.utils.ReqPrivilege.DestFolder.Extract = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.ExtractDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.SrcFile.Compress = SYNO.webfm.utils.Mode_Read, SYNO.webfm.utils.ReqPrivilege.SrcFolder.Compress = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.DestFolder.Compress = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.ReqPrivilege.SrcFile.ISO = SYNO.webfm.utils.Mode_Read, SYNO.webfm.utils.ReqPrivilege.DestFolder.Mount = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec, SYNO.webfm.utils.IndexFolderMap = {}, SYNO.webfm.utils.tids = {}, SYNO.webfm.utils.checkShareRight = function(e, t) {
    var r;
    return "NA" == e ? r = SYNO.webfm.utils.NA : "RW" == e ? r = SYNO.webfm.utils.RW : "RO" == e && (r = SYNO.webfm.utils.RO), !!(t & r)
}, SYNO.webfm.utils.checkFileRight = function(e) {
    return !0 === _S("is_admin") || "true" == _S("domainUser") || (e.right & ~(SYNO.webfm.utils.Mode_All & ~e.needRight)) == e.needRight
}, SYNO.webfm.utils.parseMode = function(e) {
    var t = 0,
        r = 0,
        i = 0,
        o = 0;
    return t = parseInt(e, 10), t >= 100 && (r = Math.floor(t / 100), t -= 100 * r), t >= 10 && (i = Math.floor(t / 10), t -= 10 * i), o = t, {
        owner: r,
        group: i,
        others: o
    }
}, SYNO.webfm.utils.getShareRight = function(e, t) {
    if ("fm_root" === t.parentNode.id) return t.attributes.right;
    var r, i, o = t.attributes.path;
    if (-1 != (i = o.indexOf("/", 1))) {
        var s = o.substring(0, i);
        r = e.getNodeById(SYNO.webfm.utils.source.remote + s)
    } else r = e.getNodeById(SYNO.webfm.utils.source.remote + o);
    return r ? r.attributes.right : null
}, SYNO.webfm.utils.IsFolderIndexed = function(e) {
    return !Ext.isEmpty(e) && SYNO.webfm.utils.IndexFolderMap[e]
}, SYNO.webfm.utils.IsShareForceRO = function(e, t) {
    var r = t.indexOf("/", 1);
    if (-1 === r) return !1;
    var i = e.getNodeById(SYNO.webfm.utils.source.remote + t.substring(0, r));
    return !!i && i.attributes.additional.perm.is_share_readonly
}, SYNO.webfm.utils.getShareRightBySPath = function(e, t) {
    var r, i;
    if (-1 != (i = t.indexOf("/", 1))) {
        var o = t.substring(0, i);
        r = e.getNodeById(SYNO.webfm.utils.source.remote + o)
    } else r = e.getNodeById(SYNO.webfm.utils.source.remote + t);
    return r ? r.attributes.right : null
}, SYNO.webfm.utils.getShareFtpRight = function(e, t) {
    var r = t.attributes.path;
    return SYNO.webfm.utils.getShareFtpRightByPath(e, r)
}, SYNO.webfm.utils.getShareFtpRightByPath = function(e, t) {
    var r, i;
    if (-1 != (i = t.indexOf("/", 1))) {
        var o = t.substring(0, i);
        r = e.getNodeById(SYNO.webfm.utils.source.remote + o)
    } else r = e.getNodeById(SYNO.webfm.utils.source.remote + t);
    return r ? r.attributes.ftpright : null
}, SYNO.webfm.utils.getZipName = function(e) {
    var t = e.lastIndexOf(".");
    return e = e.substr(0, t), t = e.lastIndexOf("."), "tar" == e.substr(t + 1).toLowerCase() && (e = e.substr(0, t)), e
}, SYNO.webfm.utils.getImageName = function(e) {
    var t = e.lastIndexOf(".");
    return -1 === t ? "" : e = e.substr(0, t)
}, SYNO.webfm.utils.GridDropTarget = function(e, t, r) {
    this.webfm = r, SYNO.webfm.utils.GridDropTarget.superclass.constructor.call(this, e, t)
}, Ext.extend(SYNO.webfm.utils.GridDropTarget, Ext.dd.DropTarget, {
    notifyOverAndDrop: function(e, t, r, i, o, s) {
        var n = e.getProxy().getGhost();
        if (i.activeDS === i.remoteSearchDS && !0 !== o) return this.dropNotAllowed;
        if (e.tree) {
            if (e.tree === i.dirTree || e.tree === i.dirLocalTree) return this.dropNotAllowed;
            var a = r.node.parentNode;
            if (a && "fm_fav_root" === a.id) return n.update(_WFT("favorite", "insert_invalid_favorite")), this.dropNotAllowed
        }
        var l, c, u = r.node,
            d = r.from || e.grid,
            h = u ? u.attributes.type : d ? d.getStore().storetype : null,
            f = SYNO.webfm.utils.isLocalSource(i.activeDS.storetype),
            m = SYNO.webfm.utils.isLocalSource(h);
        if (s && (c = s.blTgtTreeType ? s.target.attributes.path : s.target.get("path")), d && (l = d.getSelectionModel().getSelections()), !f && m) {
            if (!this.webfm.onCheckVFSAction("upload", c)) return this.dropNotAllowed
        } else if (f && !m) {
            if (!this.webfm.onCheckVFSAction("download", u || l)) return this.dropNotAllowed;
            var p = !0;
            if (d ? Ext.each(l, function(e) {
                    return p = !this.webfm.checkFTPDownloadRightByPath(e.get("file_id"))
                }, this) : u && this.webfm.checkFTPDownloadRight(u) && (p = !1), !p) return n.update(_WFT("error", "error_privilege_not_enough")), this.dropNotAllowed
        } else if (!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !i.onCheckVFSAction("copy", u || l, c) && !i.onCheckVFSAction("move", u || l, c) || SYNO.webfm.SmartDDMVCPMgr.isEnable() && !i.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), u || l, c)) return this.dropNotAllowed;
        return this.dropAllowed
    },
    updateDefalutDDText: function(e, t, r) {
        SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(!0);
        var i = e.getProxy().getGhost();
        if (e.tree) i.update(""), r.node.ui.appendDDGhost(i.dom);
        else if (e.grid) {
            var o = e.grid.getDragDropText();
            i.update(o)
        } else e.dataview && i.update(e.dataview.getDragDropText())
    },
    notifyOut: function(e, t, r) {
        this.updateDefalutDDText(e, t, r)
    },
    notifyOver: function(e, t, r) {
        var i, o, s, n, a = this.webfm,
            l = !1,
            c = t.getTarget();
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable() && (SYNO.webfm.SmartDDMVCPMgr.focus(a, r), SYNO.webfm.SmartDDMVCPMgr.onDragOver(t)), c && Ext.fly(c).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE)) return this.dropAllowed;
        if (!1 === (i = this.getTarget(e, t, r))) this.updateDefalutDDText(e, t, r);
        else if (!1 === (s = this.getSource(e, t, r))) this.updateDefalutDDText(e, t, r);
        else {
            if (!e.tree && !e.grid && !e.dataview) return this.dropNotAllowed;
            o = i.blTgtTreeType, n = i.target;
            var u, d = e.getProxy().getGhost();
            o ? u = n.attributes.text : (u = n.get("filename"), l = n.get("isdir")), u = Ext.util.Format.htmlEncode(u), u = Ext.util.Format.ellipsis(u, 36);
            var h, f, m = r.node,
                p = r.from || e.grid,
                _ = m ? m.attributes.type : p ? p.getStore().storetype : null,
                g = SYNO.webfm.utils.isLocalSource(a.activeDS.storetype),
                S = SYNO.webfm.utils.isLocalSource(_);
            !g && S ? (h = String.format(_WFT("filetable", "upload_ddtext"), u), f = "upload") : g && !S ? (h = String.format(_WFT("download", "download_to"), u), f = "download") : (h = String.format(_WFT("filetable", "mvcp_ddtext"), u), f = "mvcp");
            var b = !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd"),
                v = !1;
            if (SYNO.webfm.SmartDDMVCPMgr.isEnable() || b) {
                var T, x = !1,
                    w = !1;
                0 < s.length && (x = SYNO.webfm.VFS.isVFSPath(s[0].get("path")), v = SYNO.webfm.VFS.isSharingPath(s[0].get("path")) || SYNO.webfm.VFS.isGDriveStarsFirstLevelPath(s[0].get("path"))), o || "remote" !== n.get("mountType") ? o || "iso" !== n.get("mountType") ? o ? (w = SYNO.webfm.VFS.isVFSPath(n.attributes.path), T = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, n.attributes.path)) : (w = SYNO.webfm.VFS.isVFSPath(n.get("path")), T = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, n.get("path"))) : T = SYNO.webfm.utils.source.remotev : T = SYNO.webfm.utils.source.remoter, SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(v), SYNO.webfm.SmartDDMVCPMgr.setDragDropData(u, f, e.getProxy()), SYNO.webfm.SmartDDMVCPMgr.updateDefaultAction(T, x, w), b || (h = String.format(SYNO.webfm.SmartDDMVCPMgr.getDDText(v), u))
            }
            d.update(h)
        }
        return this.notifyOverAndDrop(e, t, r, a, l, i)
    },
    getTarget: function(e, t, r) {
        var i, o = this.webfm,
            s = Ext.lib.Event.getTarget(t),
            n = o.grid.getView().findRowIndex(s),
            a = !0;
        if (!1 !== n && !Ext.isDefined(i = o.activeDS.getAt(n))) return !1;
        if (!1 !== n && i.get("isdir")) a = !1;
        else {
            if (e.grid && e.grid === o.grid) return !1;
            i = o.dirTree.getSelectionModel().getSelectedNode()
        }
        return {
            target: i,
            blTgtTreeType: a
        }
    },
    getSource: function(e, t, r) {
        var i;
        if (e.tree) i = r.node;
        else {
            if (!e.grid && !e.dataview) return !1;
            i = r.selections
        }
        return i
    },
    notifyDrop: function(e, t, r) {
        var i = this.webfm,
            o = t.getTarget();
        if (o && (o = Ext.fly(o).findParentNode("div.syno-sds-fs-win")) && o !== this.webfm.owner.el.dom) return !1;
        if (!e.grid && !e.tree && !e.dataview) return !1;
        var s, n, a, l;
        if (!1 === (a = this.getTarget(e, t, r))) return !1;
        l = a.blTgtTreeType, n = a.target;
        var c = !l && n.get("isdir");
        if (this.notifyOverAndDrop(e, t, r, i, c, a) === this.dropNotAllowed) return !1;
        if (!1 === (s = this.getSource(e, t, r))) return !1;
        var u = e.grid || e.dataview,
            d = l ? n.attributes.real_path : n.get("real_path"),
            h = _T("tree", "leaf_filebrowser"),
            f = SYNO.webfm.utils.isLocalSource(i.activeDS.storetype),
            m = e.tree ? SYNO.webfm.utils.isLocalSource(s.attributes.type) : SYNO.webfm.utils.isLocalSource(u.getStore().storetype);
        if (f === m) {
            var p = f && Ext.isWindows ? "\\" : "/";
            if (e.tree) {
                if (SYNO.webfm.utils.isConflictTargetPath(s.attributes.real_path, d, p)) return i.owner.getMsgBox().alert(h, _WFT("error", "error_select_conflict")), !1
            } else if (e.grid || e.dataview)
                for (var _ = 0; _ < s.length; _++) {
                    var g = s[_].get("real_path");
                    if (SYNO.webfm.utils.isConflictTargetPath(g, d, p)) return i.owner.getMsgBox().alert(h, _WFT("error", "error_select_conflict")), !1
                }
        }
        i.ddParams = {
            src: e.tree ? s.attributes.path : s,
            target: l ? n.attributes.path : n.get("file_id"),
            srcsource: e.tree ? s.attributes.type : u.getStore().storetype,
            srcnode: e.tree ? e.dragData.node : void 0
        }, u && u.getStore().storetype === SYNO.webfm.utils.source.remotes && Ext.apply(i.ddParams, {
            search_taskid: u.getStore().search_taskid,
            blsame: !l && e.grid === i.grid
        });
        var S = l ? n.attributes.text : n.get("filename");
        S = "<b>[" + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(S), 36) + "]</b>";
        var b = i.copymoveCtxMenu,
            v = b.items;
        v.each(function(e) {
            e.enable(), e.show()
        });
        var T, x, w = i.dirTree.getSelectionModel().getSelectedNode();
        if (!f && m) {
            if (!0 === _S("demo_mode")) return i.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo")), !1;
            if (!i.checkUploadRight(w)) return i.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
            x = i.checkFtpModifyRight(w), x && v.get("copy_overwrite").disable(), v.get("move_skip").hide(), v.get("move_overwrite").hide(), v.get("text").setText(String.format("<b>" + _WFT("filetable", "upload_ddtext") + "&nbsp</b>", Ext.util.Format.htmlEncode(S))), T = "upload"
        } else if (f && !m) {
            if (i.checkFTPDownloadRight(w)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
            x = i.checkFtpModifyRight(w), (x || this.isSrcReadOnly(e, s)) && (v.get("move_overwrite").disable(), v.get("move_skip").disable()), v.get("text").setText(String.format("<b>" + _WFT("download", "download_to") + "&nbsp</b>", S)), T = "download"
        } else this.isSrcReadOnly(e, s) && (v.get("move_overwrite").disable(), v.get("move_skip").disable()), v.get("text").setText(S), T = "copymove";
        return b.action = T, SYNO.webfm.SmartDDMVCPMgr.onAction(b, i, t), !0
    },
    isSrcReadOnly: function(e, t) {
        return e.tree && t.attributes && (t.attributes.is_snapshot || t.attributes.type === SYNO.webfm.utils.source.remotev || t.attributes.isMountPoint) || e.grid && SYNO.webfm.utils.doesIncludeMountPoint(e.grid.getSelectionModel().getSelections()) || e.grid && e.grid.owner && SYNO.webfm.utils.source.remotev === e.grid.owner.getCurrentSource() || e.dataview && SYNO.webfm.utils.doesIncludeMountPoint(e.dataview.getSelectionModel().getSelections()) || e.dataview && e.dataview.owner && SYNO.webfm.utils.source.remotev === e.dataview.owner.getCurrentSource()
    }
}), SYNO.webfm.utils.DataViewDragZone = function(e, t) {
    SYNO.webfm.utils.DataViewDragZone.superclass.constructor.call(this, e.getEl(), t), this.dataview = e, this.scroll = !1, this.ddel = document.createElement("div"), this.ddel.className = "x-grid-dd-wrap", this.preventDefault = !0
}, Ext.extend(SYNO.webfm.utils.DataViewDragZone, Ext.dd.DragZone, {
    proxy: new Ext.dd.StatusProxy({
        animRepair: !1
    }),
    onGetShortCutRecs: function(e) {},
    getDragData: function(e) {
        var t = this.dataview,
            r = e.getTarget(t.itemSelector, 10);
        if (r) {
            var i, o = t.getSelectionModel(),
                s = r.cloneNode(!0),
                n = t.indexOf(r);
            if (s.id = Ext.id(), -1 === n || t.isSelected(n) || e.hasModifier() || t.select(n, !1), -1 === n || !t.isSelected(n) || e.hasModifier()) return;
            return i = o.getSelections(), {
                from: t,
                ddel: this.ddel,
                index: n,
                selections: i,
                SDSShortCut: this.onGetShortCutRecs(i),
                _fromFile: !0,
                ddText: _T("desktop", "add_shortcut")
            }
        }
        return !1
    },
    validateTarget: function(e, t, r) {
        var i = e.getEl();
        if (Ext.fly(i).findParentNode("div.syno-sds-aceeditor-main-panel") || Ext.fly(i).findParentNode("div.sds-audioplayer-mini-player-window") || Ext.fly(i).findParentNode("div.syno-sds-filestation-available-drop-target")) return !0;
        var o = t.getTarget("li.launch-icon");
        if (SYNO.SDS.Desktop.getEl().id === t.getTarget().id || o && Ext.fly(o).findParentNode(".sds-desktop-shortcut")) {
            var s = this.dragData;
            return !(s && s.from && SYNO.webfm.utils.isLocalSource(s.from.getStore().storetype))
        }
        o = t.getTarget();
        var n, a;
        return o && (Ext.fly(o).is("div.syno-sds-fs-grid-scroller") || Ext.fly(o).is("div.syno-sds-fs-thumbnailsView") || Ext.fly(o).is("div.syno-sds-fs-columnView") || (a = Ext.fly(o).findParentNode("div.syno-sds-fs-grid-scroller")) || (a = Ext.fly(o).findParentNode("div.syno-sds-fs-thumbnailsView")) || (a = Ext.fly(o).findParentNode("div.syno-sds-fs-columnView")) || (a = Ext.fly(o).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))) ? (a = a || o, a = Ext.fly(a).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE), n = SYNO.SDS.WindowMgr.get(a.id), n && n.toFront(), !0) : (a = a || o, a && (a = Ext.fly(a).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE)) && (n = SYNO.SDS.WindowMgr.get(a.id)) && n.toFront(), !1)
    }
}), SYNO.webfm.utils.DataViewDropTarget = function(e, t, r) {
    this.webfm = r, this.dataview = e, SYNO.webfm.utils.DataViewDropTarget.superclass.constructor.call(this, e.getEl(), t)
}, Ext.extend(SYNO.webfm.utils.DataViewDropTarget, Ext.dd.DropTarget, {
    notifyOverAndDrop: function(e, t, r, i, o, s) {
        var n = e.getProxy().getGhost();
        if (i.activeDS === i.remoteSearchDS && !0 !== o) return this.dropNotAllowed;
        if (e.tree) {
            if (e.tree === i.dirTree || e.tree === i.dirLocalTree) return this.dropNotAllowed;
            var a = r.node.parentNode;
            if (a && "fm_fav_root" === a.id) return n.update(_WFT("favorite", "insert_invalid_favorite")), this.dropNotAllowed
        }
        var l, c, u = r.node,
            d = r.from || e.grid,
            h = u ? u.attributes.type : d ? d.getStore().storetype : null,
            f = SYNO.webfm.utils.isLocalSource(i.activeDS.storetype),
            m = SYNO.webfm.utils.isLocalSource(h);
        if (s && (c = s.blTgtTreeType ? s.target.attributes.path : s.target.get("path")), d && (l = d.getSelectionModel().getSelections()), !f && m) {
            if (!i.onCheckVFSAction("upload", c)) return this.dropNotAllowed
        } else if (f && !m) {
            if (!i.onCheckVFSAction("download", u || l)) return this.dropNotAllowed;
            var p = !0;
            if (d ? Ext.each(l, function(e) {
                    return p = !this.webfm.checkFTPDownloadRightByPath(e.get("file_id"))
                }, this) : u && this.webfm.checkFTPDownloadRight(u) && (p = !1), !p) return n.update(_WFT("error", "error_privilege_not_enough")), this.dropNotAllowed
        } else if (!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !i.onCheckVFSAction("copy", u || l, c) && !i.onCheckVFSAction("move", u || l, c) || SYNO.webfm.SmartDDMVCPMgr.isEnable() && !i.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), u || l, c)) return this.dropNotAllowed;
        return this.dropAllowed
    },
    updateDefalutDDText: function(e, t, r) {
        SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(!0);
        var i = e.getProxy().getGhost();
        if (e.tree) i.update(""), r.node.ui.appendDDGhost(i.dom);
        else if (e.grid) {
            var o = e.grid.getDragDropText();
            i.update(o)
        } else e.dataview && i.update(e.dataview.getDragDropText())
    },
    notifyOut: function(e, t, r) {
        this.updateDefalutDDText(e, t, r)
    },
    notifyOver: function(e, t, r) {
        var i, o, s, n, a = this.webfm,
            l = !1,
            c = t.getTarget();
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable() && (SYNO.webfm.SmartDDMVCPMgr.focus(a, r), SYNO.webfm.SmartDDMVCPMgr.onDragOver(t)), c && Ext.fly(c).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE)) return this.dropAllowed;
        if (!1 === (i = this.getTarget(e, t, r))) this.updateDefalutDDText(e, t, r);
        else if (!1 === (s = this.getSource(e, t, r))) this.updateDefalutDDText(e, t, r);
        else {
            if (!e.tree && !e.grid && !e.dataview) return this.dropNotAllowed;
            o = i.blTgtTreeType, n = i.target;
            var u, d = e.getProxy().getGhost();
            o ? u = n.attributes.text : (u = n.get("filename"), l = n.get("isdir")), u = Ext.util.Format.htmlEncode(u), u = Ext.util.Format.ellipsis(u, 36);
            var h, f, m = r.node,
                p = r.from,
                _ = m ? m.attributes.type : p ? p.getStore().storetype : null,
                g = SYNO.webfm.utils.isLocalSource(a.activeDS.storetype),
                S = SYNO.webfm.utils.isLocalSource(_);
            !g && S ? (h = String.format(_WFT("filetable", "upload_ddtext"), u), f = "upload") : g && !S ? (h = String.format(_WFT("download", "download_to"), u), f = "download") : (h = String.format(_WFT("filetable", "mvcp_ddtext"), u), f = "mvcp");
            var b = !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd"),
                v = !1;
            if (SYNO.webfm.SmartDDMVCPMgr.isEnable() || b) {
                var T, x = !1,
                    w = !1;
                0 < s.length && (x = SYNO.webfm.VFS.isVFSPath(s[0].get("path")), v = SYNO.webfm.VFS.isSharingPath(s[0].get("path")) || SYNO.webfm.VFS.isGDriveStarsFirstLevelPath(s[0].get("path"))), o || "remote" !== n.get("mountType") ? o || "iso" !== n.get("mountType") ? o ? (w = SYNO.webfm.VFS.isVFSPath(n.attributes.path), T = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, n.attributes.path)) : (w = SYNO.webfm.VFS.isVFSPath(n.get("path")), T = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, n.get("path"))) : T = SYNO.webfm.utils.source.remotev : T = SYNO.webfm.utils.source.remoter, SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(v), SYNO.webfm.SmartDDMVCPMgr.setDragDropData(u, f, e.getProxy()), SYNO.webfm.SmartDDMVCPMgr.updateDefaultAction(T, x, w), b || (h = String.format(SYNO.webfm.SmartDDMVCPMgr.getDDText(v), u))
            }
            d.update(h)
        }
        return this.notifyOverAndDrop(e, t, r, a, l, i)
    },
    getTarget: function(e, t, r) {
        var i, o = this.webfm,
            s = t.getTarget(this.dataview.itemSelector, 10),
            n = s ? this.dataview.indexOf(s) : -1,
            a = !0;
        if (-1 !== n && !Ext.isDefined(i = o.activeDS.getAt(n))) return !1;
        if (-1 !== n && i.get("isdir")) a = !1;
        else {
            if (e.dataview && e.dataview === o.thumbnailView) return !1;
            i = o.dirTree.getSelectionModel().getSelectedNode()
        }
        return {
            target: i,
            blTgtTreeType: a
        }
    },
    getSource: function(e, t, r) {
        var i;
        if (e.tree) i = r.node;
        else {
            if (!e.dataview && !e.grid) return !1;
            i = r.selections
        }
        return i
    },
    notifyDrop: function(e, t, r) {
        var i = this.webfm,
            o = t.getTarget();
        if (o && (o = Ext.fly(o).findParentNode("div.syno-sds-fs-win")) && o !== this.webfm.owner.el.dom) return !1;
        if (!e.dataview && !e.grid && !e.tree) return !1;
        var s, n, a, l;
        if (!1 === (a = this.getTarget(e, t, r))) return !1;
        l = a.blTgtTreeType, n = a.target;
        var c = !l && n.get("isdir");
        if (this.notifyOverAndDrop(e, t, r, i, c, a) === this.dropNotAllowed) return !1;
        if (!1 === (s = this.getSource(e, t, r))) return !1;
        var u = l ? n.attributes.real_path : n.get("real_path"),
            d = _T("tree", "leaf_filebrowser"),
            h = SYNO.webfm.utils.isLocalSource(i.activeDS.storetype),
            f = e.grid || e.dataview,
            m = e.tree ? SYNO.webfm.utils.isLocalSource(s.attributes.type) : SYNO.webfm.utils.isLocalSource(f.getStore().storetype);
        if (h === m) {
            var p = h && Ext.isWindows ? "\\" : "/";
            if (e.tree) {
                if (SYNO.webfm.utils.isConflictTargetPath(s.attributes.real_path, u, p)) return i.owner.getMsgBox().alert(d, _WFT("error", "error_select_conflict")), !1
            } else if (e.grid || e.dataview)
                for (var _ = 0; _ < s.length; _++) {
                    var g = s[_].get("real_path");
                    if (SYNO.webfm.utils.isConflictTargetPath(g, u, p)) return i.owner.getMsgBox().alert(d, _WFT("error", "error_select_conflict")), !1
                }
        }
        i.ddParams = {
            src: e.tree ? s.attributes.path : s,
            target: l ? n.attributes.path : n.get("file_id"),
            srcsource: e.tree ? s.attributes.type : f.getStore().storetype,
            srcnode: e.tree ? e.dragData.node : void 0
        }, f && f.getStore().storetype === SYNO.webfm.utils.source.remotes && Ext.apply(i.ddParams, {
            search_taskid: f.getStore().search_taskid,
            blsame: !l && f === i.dataview
        });
        var S = l ? n.attributes.text : n.get("filename");
        S = "<b>[" + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(S), 36) + "]</b>";
        var b = i.copymoveCtxMenu,
            v = b.items;
        v.each(function(e) {
            e.enable(), e.show()
        });
        var T, x, w = i.dirTree.getSelectionModel().getSelectedNode();
        if (!h && m) {
            if (!0 === _S("demo_mode")) return i.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo")), !1;
            if (!i.checkUploadRight(w)) return i.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
            x = i.checkFtpModifyRight(w), x && v.get("copy_overwrite").disable(), v.get("move_skip").hide(), v.get("move_overwrite").hide(), v.get("text").setText(String.format("<b>" + _WFT("filetable", "upload_ddtext") + "&nbsp</b>", Ext.util.Format.htmlEncode(S))), T = "upload"
        } else if (h && !m) {
            if (i.checkFTPDownloadRight(w)) return void i.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
            x = i.checkFtpModifyRight(w), (x || this.isSrcReadOnly(e, s)) && (v.get("move_overwrite").disable(), v.get("move_skip").disable()), v.get("text").setText(String.format("<b>" + _WFT("download", "download_to") + "&nbsp</b>", S)), T = "download"
        } else this.isSrcReadOnly(e, s) && (v.get("move_overwrite").disable(), v.get("move_skip").disable()), v.get("text").setText(S), T = "copymove";
        return b.action = T, SYNO.webfm.SmartDDMVCPMgr.onAction(b, i, t), !0
    },
    isSrcReadOnly: function(e, t) {
        return e.tree && t.attributes && (t.attributes.type === SYNO.webfm.utils.source.remotev || t.attributes.isMountPoint) || e.grid && SYNO.webfm.utils.doesIncludeMountPoint(e.grid.getSelectionModel().getSelections()) || e.grid && e.grid.owner && SYNO.webfm.utils.source.remotev === e.grid.owner.getCurrentSource() || e.dataview && SYNO.webfm.utils.doesIncludeMountPoint(e.dataview.getSelectionModel().getSelections()) || e.dataview && e.dataview.owner && SYNO.webfm.utils.source.remotev === e.dataview.owner.getCurrentSource()
    }
}), SYNO.webfm.utils.TreeDropZone = Ext.extend(Ext.tree.TreeDropZone, {
    onResetDragText: function(e, t, r) {
        var i = e.getProxy().getGhost();
        if (e.tree) i.update(""), r.node.ui.appendDDGhost(i.dom);
        else if (e.grid) {
            var o = e.grid.getDragDropText();
            i.update(o)
        } else e.dataview && i.update(e.dataview.getDragDropText())
    },
    onContainerOver: function(e, t, r) {
        return this.allowContainerDrop && this.isValidDropPoint({
            ddel: this.tree.getRootNode().ui.elNode,
            node: this.tree.getRootNode()
        }, "append", e, t, r) ? this.dropAllowed : (this.onResetDragText(e, t, r), this.dropNotAllowed)
    },
    onNodeOut: function(e, t, r, i) {
        this.onResetDragText(t, r, i), this.cancelExpand(), this.removeDropIndicators(e)
    },
    getDropPoint: function(e, t, r) {
        var i = SYNO.webfm.utils.TreeDropZone.superclass.getDropPoint.apply(this, arguments);
        return t && t.node && t.node.parentNode && "fm_fav_root" === t.node.parentNode.id ? i : "above" === i || "below" === i ? "append" : i
    }
}), SYNO.webfm.utils.parseDuration = function(e) {
    var t, r = {},
        i = SYNO.webfm.utils.durations;
    for (var o in i)
        if (i.hasOwnProperty(o) && (t = Math.floor(e / i[o])) && (r[o] = Ext.isNumber(t) && t < Number.MAX_VALUE ? t : Number.MAX_VALUE, 0 >= (e -= t * i[o]))) break;
    return r
}, SYNO.webfm.utils.fancyDuration = function(e) {
    var t = [],
        r = SYNO.webfm.utils.parseDuration(e);
    for (var i in r)
        if (r.hasOwnProperty(i)) {
            var o = r[i] > 9999 ? 9999 : r[i];
            t.push(o + " " + SYNO.webfm.utils.durationsAbbr[i])
        } return t.join(", ")
}, SYNO.webfm.utils.durations = {
    days: 86400,
    hours: 3600,
    minutes: 60,
    seconds: 1
}, SYNO.webfm.utils.durationsAbbr = {
    days: _WFT("upload", "upload_time_day"),
    hours: _WFT("upload", "upload_time_hour"),
    minutes: _WFT("upload", "upload_time_min"),
    seconds: _WFT("upload", "upload_time_sec")
}, SYNO.webfm.utils.FieldFind = function(e, t) {
    var r = e.findField(t);
    return r || (r = Ext.getCmp(t)), r
}, SYNO.webfm.utils.getRadioGroup = function(e, t) {
    for (var r = [], i = e.el.query("input[name=" + t + "]"), o = 0; o < i.length; o++) r.push(Ext.getCmp(i[o].id));
    return r
}, SYNO.webfm.utils.EnableCheckGroup = Ext.extend(Object, {
    constructor: function(e, t, r, i) {
        var o = SYNO.webfm.utils.FieldFind(e, t);
        i = void 0 !== i ? i : [], this.enable_fields = r, this.disable_fields = i, this.form = e, o.mon(o, "check", this.checkHandler, this), o.mon(o, "enable", this.enableHandler, this, {
            delay: 50
        }), o.mon(o, "disable", this.enableHandler, this, {
            delay: 50
        }), this.checkHandler(o, o.getValue())
    },
    setFieldStatus: function(e, t, r, i) {
        if ("radio" == t.inputType)
            for (var o = SYNO.webfm.utils.getRadioGroup(e, t.getName()), s = 0; s < o.length; s++) i ? r ? o[s].disable() : o[s].enable() : r ? o[s].enable() : o[s].disable();
        else {
            i ? r ? t.disable() : t.enable() : r ? t.enable() : t.disable()
        }
    },
    checkHandler: function(e, t) {
        var r, i;
        for (r = 0; r < this.enable_fields.length; r++) i = SYNO.webfm.utils.FieldFind(this.form, this.enable_fields[r]), this.setFieldStatus(this.form, i, t, !1);
        for (r = 0; r < this.disable_fields.length; r++) i = SYNO.webfm.utils.FieldFind(this.form, this.disable_fields[r]), this.setFieldStatus(this.form, i, t, !0)
    },
    enableHandler: function(e) {
        var t, r, i = !1 === e.disabled && !0 === e.getValue();
        for (t = 0; t < this.enable_fields.length; t++) r = SYNO.webfm.utils.FieldFind(this.form, this.enable_fields[t]), this.setFieldStatus(this.form, r, i, !1);
        for (t = 0; t < this.disable_fields.length; t++) r = SYNO.webfm.utils.FieldFind(this.form, this.disable_fields[t]), this.setFieldStatus(this.form, r, i, !0)
    }
}), SYNO.webfm.utils.getCmdCode = function() {
    var e = 224;
    return Ext.isWebKit ? e = [91, 93] : Ext.isOpera && (e = 17), e
}, SYNO.webfm.utils.setSpaceTooltip = function(e) {
    if (e && e.additional) {
        var t = e.additional.volume_status;
        t && t.totalSpace && t.freeSpace && (e.qtip = String.format("{0}<br>{1}", e.qtip, String.format(_T("filetable", "space_size"), Ext.util.Format.fileSize(t.freeSpace), Ext.util.Format.fileSize(t.totalSpace))))
    }
}, SYNO.webfm.utils.NodeActionEnable = function() {
    var e = function(e) {
            return !("fm_root" == e.id || "fm_local_root" == e.id || "fm_vd_root" === e.id || "fm_rf_root" === e.id || !e.parentNode || "fm_root" == e.parentNode.id || "fm_local_root" == e.parentNode.id || "fm_fav_root" === e.id || e.parentNode && "fm_fav_root" === e.parentNode.id && "broken" === e.attributes.status)
        },
        t = function(t) {
            if (!e(t)) return !1;
            var r = SYNO.webfm.utils.isLocalSource(t.attributes.type),
                i = t.attributes.type === SYNO.webfm.utils.source.remotev || "iso" === t.attributes.mountType || t.attributes.is_snapshot,
                o = i || t.parentNode && "fm_rf_root" === t.parentNode.id;
            return !(!r && t.parentNode && "fm_fav_root" == t.parentNode.id || o)
        },
        r = function(t) {
            if (!e(t)) return !1;
            var r = t.attributes.type === SYNO.webfm.utils.source.remotev || "iso" === t.attributes.mountType,
                i = r || t.parentNode && "fm_rf_root" === t.parentNode.id;
            return !SYNO.FileStation.Clipboard.isEmpty() && !i
        };
    return {
        isEnableCut: t,
        isEnableDelete: t,
        isEnableRename: t,
        isEnableCopy: function(t) {
            return !!e(t) && !(!SYNO.webfm.utils.isLocalSource(t.attributes.type) && t.parentNode && "fm_fav_root" == t.parentNode.id)
        },
        isEnablePaste: r
    }
}(), SYNO.webfm.utils.ShowHideMenu = function(e) {
    var t, r, i = !1,
        o = null;
    for (e.each(function(e) {
            e instanceof Ext.menu.Separator && e.show()
        }), t = 0, r = e.length; t >= 0 && t < r; t++) {
        var s = e.get(t);
        s instanceof Ext.menu.Separator && !s.hidden ? (i || 0 === t ? s.hide() : o = s, i = !0) : s.hidden || (i = !1, o = null)
    }
    o && o.hide()
}, SYNO.webfm.utils.GetIconvCodepageList = function() {
    var e = [
        ["BIG5", _WFT("codepage", "chinese_traditional") + " (BIG5)"],
        ["BIG5-HKSCS", _WFT("codepage", "chinese_traditional") + " (BIG5-HKSCS)"],
        ["GBK", _WFT("codepage", "chinese_simplified") + " (GBK)"],
        ["GB18030", _WFT("codepage", "chinese_simplified") + " (GB18030)"],
        ["EUC-JP", _WFT("codepage", "japanese") + " (EUC-JP)"],
        ["SHIFT_JIS", _WFT("codepage", "japanese") + " (SHIFT_JIS)"],
        ["ISO-2022-JP", _WFT("codepage", "japanese") + " (ISO-2022-JP)"],
        ["EUC-KR", _WFT("codepage", "korean") + " (EUC-KR)"],
        ["CP949", _WFT("codepage", "korean") + " (CP949)"],
        ["CP1258", _WFT("codepage", "vietnamese") + " (CP1258)"],
        ["VISCII", _WFT("codepage", "vietnamese") + " (VISCII)"],
        ["TIS-620", _WFT("codepage", "thai") + " (TIS-620)"],
        ["ISO-8859-11", _WFT("codepage", "thai") + " (ISO-8859-11)"],
        ["ISO-8859-2", _WFT("codepage", "central_european") + " (ISO-8859-2)"],
        ["CP1250", _WFT("codepage", "central_european") + " (CP1250)"],
        ["ISO-8859-10", _WFT("codepage", "nordic") + " (ISO-8859-10)"],
        ["ISO-8859-1", _WFT("codepage", "western") + " (ISO-8859-1)"],
        ["ISO-8859-15", _WFT("codepage", "western") + " (ISO-8859-15)"],
        ["CP1252", _WFT("codepage", "western") + " (CP1252)"],
        ["Macintosh", _WFT("codepage", "western") + " (Macintosh)"],
        ["CP1254", _WFT("codepage", "turkish") + " (CP1254)"],
        ["CP1255", _WFT("codepage", "hebrew") + " (CP1255)"],
        ["ISO-8859-8", _WFT("codepage", "hebrew") + " (ISO-8859-8)"],
        ["ISO-8859-7", _WFT("codepage", "greek") + " (ISO-8859-7)"],
        ["CP1253", _WFT("codepage", "greek") + " (CP1253)"],
        ["CP1256", _WFT("codepage", "arabic") + " (CP1256)"],
        ["ISO-8859-6", _WFT("codepage", "arabic") + " (ISO-8859-6)"],
        ["ISO-8859-4", _WFT("codepage", "baltic") + " (ISO-8859-4)"],
        ["ISO-8859-13", _WFT("codepage", "baltic") + " (ISO-8859-13)"],
        ["CP1257", _WFT("codepage", "baltic") + " (CP1257)"],
        ["ISO-8859-3", _WFT("codepage", "south_european") + " (ISO-8859-3)"],
        ["ISO-8859-5", _WFT("codepage", "cyrillic") + " (ISO-8859-5)"],
        ["CP1251", _WFT("codepage", "cyrillic") + " (CP1251)"],
        ["KOI8-R", _WFT("codepage", "cyrillic") + " (KOI8-R)"],
        ["KOI8-U", _WFT("codepage", "cyrillic") + " (KOI8-U)"],
        ["ISO-8859-14", _WFT("codepage", "celtic") + " (ISO-8859-14)"],
        ["ISO-8859-16", _WFT("codepage", "romanian") + " (ISO-8859-16)"],
        ["ARMSCII-8", _WFT("codepage", "armenian") + " (ARMSCII-8)"],
        ["Georgian-Academy", _WFT("codepage", "georgian") + " (Georgian-Academy)"],
        ["KOI8-T", _WFT("codepage", "tajik") + " (KOI8-T)"],
        ["CP1133", _WFT("codepage", "laotian") + " (CP1133)"],
        ["PT154", _WFT("codepage", "kazakh") + " (PT154)"]
    ];
    return e.sort(function(e, t) {
        return e[1].localeCompare(t[1])
    }), e.unshift(["UTF-16", _WFT("codepage", "unicode") + " (UTF-16)"]), e.unshift(["UTF-8", _WFT("codepage", "unicode") + " (UTF-8)"]), e
}, SYNO.webfm.utils.getLastModifiedTime = function(e) {
    return e.lastModifiedDate ? e.lastModifiedDate.getTime() : e.lastModified
}, Ext.apply(SYNO.webfm.utils, {
    icon_type: ["acc", "ai", "avi", "bmp", "doc", "exe", "fla", "folder", "gif", "htm", "indd", "iso", "jpg", "js", "misc", "mp3", "pdf", "png", "ppt", "psd", "rar", "swf", "tar", "ttf", "txt", "wma", "xls", "ico", "tif", "tiff", "ufo", "raw", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "jpe", "jpeg", "html", "3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "m4v", "mkv", "mp4", "mts", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "m3u", "aiff", "wpl", "aac", "flac", "m4a", "m4b", "aif", "ogg", "pcm", "wav", "cda", "mid", "mp2", "mka", "mpc", "ape", "ra", "ac3", "dts", "bin", "img", "mds", "nrg", "daa", "docx", "wri", "rtf", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw", "xlsx", "xlsm", "xlsb", "xltm", "xlam", "pptx", "pps", "ppsx", "ade", "adp", "adn", "accdr", "accdb", "accdt", "mdb", "mda", "mdn", "mdt", "mdw", "mdf", "mde", "accde", "mam", "maq", "mar", "mat", "maf", "flv", "f4v", "7z", "bz2", "gz", "zip", "tgz", "tbz", "ttc", "otf", "css", "actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "bkpi", "c", "cc", "php", "jsx", "xml", "xhtml", "mhtml", "cpp", "cs", "cxx", "odoc", "osheet", "oslides"],
    archive_type: ["zip", "gz", "tar", "tgz", "tbz", "bz2", "rar", "7z", "iso"],
    image_type: ["iso"],
    DocumentFileTypes: "docx,wri,rtf,xla,xlb,xlc,xld,xlk,xll,xlm,xlt,xlv,xlw,xlsx,xlsm,xlsb,xltm,xlam,pptx,pps,ppsx,pdf,txt,doc,xls,ppt,odt,ods,odp,odg,odc,odf,odb,odi,odm,ott,ots,otp,otg,otc,otf,oti,oth,potx,pptm,ppsm,potm,dotx,dot,pot,ppa,xltx,docm,dotm,eml,msgc,c,cc,cpp,cs,cxx,ada,coffee,cs,css,js,json,lisp,markdown,ocaml,pl,py,rb,sass,scala,r,tex,conf,csv,sub,srt,md,log",
    ImageFileTypes: "ico,tif,tiff,ufo,raw,arw,srf,sr2,dcr,k25,kdc,cr2,crw,nef,mrw,ptx,pef,raf,3fr,erf,mef,mos,orf,rw2,dng,x3f,jpg,jpg,jpeg,png,gif,bmp,psd",
    VideoFileTypes: "3gp,3g2,asf,dat,divx,dvr-ms,m2t,m2ts,m4v,mkv,mp4,mts,mov,qt,tp,trp,ts,vob,wmv,xvid,ac3,amr,rm,rmvb,ifo,mpeg,mpg,mpe,m1v,m2v,mpeg1,mpeg2,mpeg4,ogv,webm,flv,avi,swf,f4v",
    AudioFileTypes: "aac,flac,m4a,m4b,aif,ogg,pcm,wav,cda,mid,mp2,mka,mpc,ape,ra,ac3,dts,wma,mp3,mp1,mp2,mpa,ram,m4p,aiff,dsf,dff,m3u,wpl,aiff",
    WebPageFileTypes: "html,htm,css,actproj,ad,akp,applescript,as,asax,asc,ascx,asm,asmx,asp,aspx,asr,jsx,xml,xhtml,mhtml,cs,js",
    DiscFileTypes: "bin,img,mds,nrg,daa,iso",
    ZippedFileTypes: "7z,bz2,gz,zip,tgz,tbz,rar,tar"
}), SYNO.webfm.utils.DateTimeFormatter = function(e, t) {
    if (SYNO.SDS.DateTimeFormatter) return SYNO.SDS.DateTimeFormatter(e, t);
    if (!e || "[object Date]" !== Object.prototype.toString.call(e)) return "";
    var r, i = t && t.type;
    return r = "date" === i ? "Y-m-d" : "time" === i ? "H:i" : "timesec" === i ? "H:i:s" : "datetimesec" === i ? "Y-m-d H:i:s" : "datetimesecms" === i ? "Y-m-d H:i:s.u" : "Y-m-d H:i", e.format(r)
}, SYNO.webfm.utils.GetDateFormat = function() {
    return SYNO.SDS.DateTimeUtils && SYNO.SDS.DateTimeUtils.GetDateFormat ? SYNO.SDS.DateTimeUtils.GetDateFormat() : "Y-m-d"
}, SYNO.webfm.utils.showMessage = function(e, t) {
    e.toastBox = new SYNO.SDS.ToastBox({
        text: t,
        owner: e,
        delay: 2500
    }), e.toastBox.show()
}, SYNO.webfm.utils.buildSharingQRCodeMail = function(e, t) {
    var r = "",
        i = function(e, t) {
            return (t ? '<img src="' + t + '"></img>' : "") + "<div>" + Ext.util.Format.htmlEncode(e) + "</div>"
        };
    Ext.isArray(e) ? Ext.iterate(e, function(e, o) {
        r += i(e, t[o])
    }, this) : r = i(e, t), SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", {
        content: r
    })
}, SYNO.webfm.utils.getTicketID = function(e) {
    var t = e.api,
        r = e.methods;
    return SYNO.webfm.utils.tids[t] ? SYNO.webfm.utils.tids[t] : Ext.isArray(r) && 0 !== r.length ? (SYNO.API.Request({
        api: "SYNO.API.Auth.Key",
        version: 7,
        method: "grant",
        async: !1,
        timeout: 10,
        params: {
            allow_api: t,
            allow_methods: r
        },
        callback: function(e, r) {
            e && (SYNO.webfm.utils.tids[t] = r.tid)
        }
    }), SYNO.webfm.utils.tids[t]) : null
}, Ext.ns("SYNO.FileStation"), SYNO.FileStation.PathBar = Ext.extend(Ext.util.Observable, {
    constructor: function(e) {
        this.init(e), SYNO.FileStation.PathBar.superclass.constructor.apply(this, arguments), this.addEvents("updatepath")
    },
    init: function(e) {
        return this.webfm = e.webfm, this.pathEditable = e.pathEditable || !1, this.tbPanel = new SYNO.FileStation.PathButtonsPanel({
            cls: "ux-pathtoolbar",
            webfm: this.webfm,
            pathEditable: this.pathEditable,
            owner: this
        }), this.pathEditable && (this.pathEditArea = this.getPathEditArea(), this.mainPanel = new SYNO.ux.Panel({
            autoFlexcroll: !1,
            activeItem: 0,
            layout: "card",
            defaults: {
                border: !1
            },
            items: [this.tbPanel, this.pathEditArea]
        }), this.registerPathEditAreaEvent()), this
    },
    addPathButton: function(e, t, r, i, o, s) {
        return this.tbPanel.addButton(e, t, r, i, o, s, this.webfm)
    },
    updatePathButton: function(e, t, r, i, o) {
        return this.tbPanel.updateButton(e, t, r, i, o)
    },
    addPathButtons: function(e) {
        for (var t = Math.max(this.tbPanel.items.length, e.length), r = e.length - 1, i = 0; i < t; i++)
            if (i < this.tbPanel.items.length && i < e.length) this.updatePathButton(i, e[i].text, e[i].tooltip, e[i].path, i === r);
            else {
                if (!(i < e.length)) {
                    this.removePathButtons(i, t);
                    break
                }
                this.addPathButton(this.tbPanel.items.length, e[i].text, e[i].tooltip, e[i].path, 0 === i, i === r)
            } this.tbPanel.setActiveButton(this.tbPanel.items[this.tbPanel.items.length - 1]), this.fireEvent("updatepath", this)
    },
    removePathButtons: function(e, t) {
        this.tbPanel.removeButtons(e, t)
    },
    setWidth: function(e) {
        this.tbPanel.setWidth(e), this.pathEditable && this.pathEditArea.setWidth(e)
    },
    getPathStore: function() {
        var e = new Ext.data.JsonReader({
                root: "shares",
                id: "path"
            }, [{
                name: "path"
            }]),
            t = {
                node: "fm_root",
                filetype: "dir",
                sort_by: "name",
                enum_cluster: !0,
                additional: []
            },
            r = new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "path"
            }]),
            i = {
                offset: 0,
                limit: 1e3,
                sort_by: "name",
                sort_direction: "ASC",
                filetype: "dir",
                additional: []
            };
        return new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                timeout: SYNO.webfm.Cfg.timeout,
                api: "SYNO.FileStation.List",
                method: "list",
                version: 2,
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var r = e.activeRequest.read;
                        r && Ext.Ajax.abort(r)
                    }
                }
            }),
            reader: r,
            readerForDir: r,
            readerForShare: e,
            remoteSort: !0,
            baseParams: i,
            baseParamsForDir: i,
            baseParamsForShare: t,
            listeners: {
                scope: this,
                load: function(e, t, r) {
                    e.filter(this.pathEditArea.displayField, this.pathEditArea.typedQueryPath)
                }
            }
        })
    },
    getPathEditArea: function() {
        return new SYNO.ux.ComboBox({
            editable: !0,
            displayField: "path",
            mode: "remote",
            typeAhead: !0,
            typeAheadDelay: 10,
            store: this.getPathStore(),
            height: 26,
            autoSelect: !1,
            minChars: 0,
            triggerAction: "query",
            queryParam: "query_full_path",
            hideTrigger: !0,
            tpl: ['<tpl for=".">', '<div class="x-combo-list-item {[values.cls || ""]}" ', 'role="option" ', 'ext:qtip="{[Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(values.path))]}" ', 'aria-label="{[Ext.util.Format.htmlEncode(Ext.util.Format.stripTags(values.path))]}" ', 'id="{[Ext.id()]}">', "{[Ext.util.Format.htmlEncode(values.path)]}", "</div>", "</tpl>"].join(""),
            listeners: {
                scope: this,
                beforeQuery: function(e) {
                    var t = this.pathEditArea;
                    t.typedQueryPath = e.query;
                    var r = e.query.replace(/\/[^\/]*$/g, ""),
                        i = e.query.substr(e.query.lastIndexOf("/") + 1);
                    if (t.lastQuery) {
                        var o = t.lastQuery.replace(/\/[^\/]*$/g, ""),
                            s = t.lastQuery.substr(t.lastQuery.lastIndexOf("/") + 1);
                        if (t.store.getCount() < 1e3 && o === r && 0 === i.indexOf(s)) return e.query = t.lastQuery, void t.store.filter(t.displayField, t.typedQueryPath)
                    }
                    "" === r ? (t.store.proxy.method = "list_share", t.store.reader = t.store.readerForShare, t.store.baseParams = t.store.baseParamsForShare) : (t.store.proxy.method = "list", t.store.reader = t.store.readerForDir, t.store.baseParams = t.store.baseParamsForDir), t.store.baseParams.folder_path = r, t.store.baseParams.pattern = i + "*"
                }
            },
            select: function(e, t) {
                SYNO.ux.ComboBox.superclass.select.call(this, e, t);
                var r = this.store.getAt(e).data[this.displayField];
                this.setRawValue(r)
            },
            onKeyUp: function(e) {
                var t = e.getKey();
                SYNO.ux.ComboBox.superclass.onKeyUp.call(this, e), !1 === this.editable || !0 === this.readOnly || t != e.BACKSPACE && e.isSpecialKey() || this.view.clearSelections()
            }
        })
    },
    registerPathEditAreaEvent: function() {
        this.pathEditArea.on("blur", this.onPathEditAreaBlur, this), this.pathEditArea.on("select", function() {
            var e = this,
                t = this.webfm,
                r = this.pathEditArea;
            if (r.dqTask.cancel(), r.taTask.cancel(), r.store.suspendEvents(), r.collapse(), r.getValue() === r.currentDir) return void this.onPathEditAreaBlur();
            t.onGoToPathWithDirBySource(!0, r.getValue(), void 0, void 0, function(i) {
                i ? e.onPathEditAreaBlur() : (r.un("blur", e.onPathEditAreaBlur, e), t.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("error", "error_dest_no_path"), function() {
                    r.on("blur", e.onPathEditAreaBlur, e), r.store.resumeEvents(), r.markInvalid(_WFT("error", "error_dest_no_path"))
                }))
            })
        }, this), this.pathEditArea.on("specialkey", function(e, t) {
            var r;
            t.getKey() === t.ENTER && (r = this.pathEditArea.getRawValue(), r = r.replace(/^\s+|\s+$|\/+$/g, ""), -1 !== r.search(/^[^\/][^:\/\/]+$/g) && (r = this.pathEditArea.currentDir + "/" + r), this.pathEditArea.setValue(r), this.pathEditArea.fireEvent("select"))
        }, this)
    },
    onPathEditAreaBlur: function() {
        this.mainPanel.getLayout().setActiveItem(0), this.tbPanel.trigger.focus()
    }
}), SYNO.FileStation.PathButtonsPanel = Ext.extend(Ext.BoxComponent, {
    activeButton: null,
    enableScroll: !0,
    scrollRepeatInterval: 400,
    scrollDuration: .35,
    buttonWidthSet: !1,
    allowDomMove: !1,
    edgeMinWidth: 30,
    onRender: function() {
        SYNO.FileStation.PathButtonsPanel.superclass.onRender.call(this, arguments), this.mon(this, "resize", this.delegateUpdates), this.items = [], this.selMenu = new SYNO.ux.Menu({
            items: [],
            listeners: {
                click: {
                    fn: function(e, t) {
                        t.path && this.webfm.onGoToPathWithDir(t.path)
                    },
                    scope: this
                }
            }
        }), this.stripWrap = this.el.createChild({
            cls: "ux-pathbuttons-strip-wrap",
            cn: {
                tag: "ul",
                cls: "ux-pathbuttons-strip"
            }
        }), this.stripSpacer = this.el.createChild({
            cls: "ux-pathbuttons-strip-spacer"
        }), this.strip = new Ext.Element(this.stripWrap.dom.firstChild), this.edge = this.strip.createChild({
            tag: "li",
            cls: "ux-pathbuttons-edge"
        }), this.pathEditable && (this.trigger = this.el.createChild({
            cls: "ux-pathbuttons-trigger",
            tabIndex: -1
        }), this.mon(this.edge, "click", this.onClickTrigger, this), this.mon(this.trigger, "click", this.onClickTrigger, this), this.mon(this.trigger, "keydown", this.onKeyDownEdge, this)), this.strip.createChild({
            cls: "x-clear"
        })
    },
    addButton: function(e, t, r, i, o, s, n) {
        var a = this.strip.createChild({
                tag: "li"
            }, this.edge),
            l = new SYNO.FileStation.PathBar.PathButton(a, e, t, r, i, o, s, n);
        return this.items.push(l), this.buttonWidthSet || (this.lastButtonWidth = l.container.getWidth()), this.addManagedComponent(l), l
    },
    updateButton: function(e, t, r, i, o) {
        this.items[e].updateButton(t, r, i, o)
    },
    removeButtons: function(e, t) {
        for (var r, i, o = e; o < t; o++) i = this.items[o], r = document.getElementById(i.container.id), this.removeManagedComponent(i), i.destroy(), r.parentNode.removeChild(r);
        var s = [];
        for (o = 0; o < e; o++) s.push(this.items[o]);
        this.items = s, this.delegateUpdates()
    },
    setActiveButton: function(e) {
        this.activeButton = e, this.delegateUpdates()
    },
    delegateUpdates: function() {
        this.enableScroll && this.rendered && this.autoScroll()
    },
    autoScroll: function() {
        var e = this.items.length,
            t = this.el.dom.clientWidth,
            r = this.stripWrap,
            i = this.edge.getWidth(),
            o = this.strip.getWidth() - i,
            s = r.dom.offsetWidth,
            n = this.getScrollPos(),
            a = this.edge.getOffsetsTo(this.stripWrap)[0] + n;
        if (!(!this.enableScroll || e < 1 || s < 20)) {
            r.setWidth(t), this.pathEditable && (o < t - this.edgeMinWidth ? this.edge.setWidth(t - o) : this.edge.setWidth(this.edgeMinWidth));
            var l = 1 == this.items.length;
            a <= t || l ? (r.dom.scrollLeft = 0, this.showSelBtn && (this.showSelBtn = !1, this.el.removeClass("x-pathbuttons-selection-btn-displayed"), this.menuBtn.hide())) : (this.showSelBtn || this.el.addClass("x-pathbuttons-selection-btn-displayed"), t -= r.getMargins("lr"), r.setWidth(t > 20 ? t : 20), this.showSelBtn || (this.menuBtn ? this.menuBtn.show() : this.createMenuBtn()), this.showSelBtn = !0, this.updateScrollandSelMenu())
        }
    },
    createMenuBtn: function() {
        var e = this.el.dom.offsetHeight,
            t = this.el.insertFirst({
                cls: "ux-pathbuttons-selection-btn"
            });
        t.setHeight(e), t.addClassOnOver("ux-pathbuttons-selection-btn-over"), t.addClassOnClick("ux-pathbuttons-selection-btn-click"), this.leftRepeater = new Ext.util.ClickRepeater(t, {
            interval: this.scrollRepeatInterval,
            handler: this.onShowMenu,
            scope: this
        }), this.menuBtn = t
    },
    onShowMenu: function() {
        var e = this.menuBtn.getXY();
        this.selMenu.isVisible() ? this.selMenu.hide() : this.selMenu.showAt([e[0] + -5, e[1] + 28])
    },
    getScrollPos: function() {
        return parseInt(this.stripWrap.dom.scrollLeft, 10) || 0
    },
    updateScrollandSelMenu: function() {
        for (var e, t = this.items.length, r = t - 1, i = 0, o = this.stripWrap.getWidth(), s = r; s >= 0 && (e = this.items[s].el.child(".ux-pathbutton-center"), !((i += e.getWidth() + 14) > o)); s--);
        s == r && (s -= 1), this.selMenu.removeAll();
        for (var n = 0; n <= s; n++) this.selMenu.addItem({
            path: this.items[n].path,
            text: this.items[n].text,
            htmlEncode: !1
        });
        var a = this.items[s + 1],
            l = this.stripWrap.dom.scrollLeft,
            c = a.el.getOffsetsTo(this.stripWrap)[0] + l;
        this.stripWrap.scrollTo("left", c - 14)
    },
    onClickTrigger: function() {
        "remotesfm_search_root" !== this.webfm.getCurrentDir() && (this.owner.pathEditArea.currentDir = this.webfm.getCurrentDir(), this.owner.pathEditArea.clearInvalid(), this.owner.pathEditArea.setValue(this.owner.pathEditArea.currentDir), this.owner.pathEditArea.store.resumeEvents(), this.owner.mainPanel.getLayout().setActiveItem(1), this.owner.pathEditArea.focus(), this.owner.pathEditArea.selectText())
    },
    onKeyDownEdge: function(e) {
        e.getKey() === e.ENTER && this.onClickTrigger()
    }
}), SYNO.FileStation.PathBar.PathButton = function(e, t, r, i, o, s, n, a) {
    this.webfm = a;
    var l = s ? this.firstBtnCls : "",
        c = n ? this.lastBtnCls : "";
    SYNO.FileStation.PathBar.PathButton.superclass.constructor.call(this, {
        text: r,
        itemId: t,
        renderTo: e,
        tooltip: i,
        clickEvent: "mousedown",
        tabIndex: -1,
        listeners: {
            click: {
                fn: function() {
                    var e = this.getPath();
                    e && this.webfm.onGoToPathWithDir(e)
                },
                scope: this
            }
        },
        template: new Ext.Template('<table cellspacing="0" class="x-btn ' + l + " " + c + ' {3}"><tbody><tr>', '<td class="ux-pathbutton-left"></td>', '<td class="ux-pathbutton-center"><em class="{5} unselectable="on">', '<button class="x-btn-text {2}" type="{1}" style="height:18px;">{0}</button>', "</em></td>", '<td class="ux-pathbutton-right"></td>', "</tr></tbody></table>")
    }), this.setPath(o)
}, Ext.extend(SYNO.FileStation.PathBar.PathButton, Ext.Button, {
    firstBtnCls: "x-first-btn",
    lastBtnCls: "x-last-btn",
    setPath: function(e) {
        this.path = e
    },
    getPath: function() {
        return this.path
    },
    updateButton: function(e, t, r, i) {
        this.setPath(r), this.setText(e), this.setTooltip(t), i ? this.addClass(this.lastBtnCls) : this.removeClass(this.lastBtnCls)
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.FocusGridPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        e.mon(e, "click", function(e) {
            document.activeElement.id !== this.getView().focusEl.id && (Ext.isGecko ? this.getView().focusEl.focus() : this.getView().focusEl.focus.defer(1, this.getView().focusEl))
        }, e)
    }
}), SYNO.FileStation.FocusGridPluginInstance = new SYNO.FileStation.FocusGridPlugin, Ext.preg("focusgridplugin", SYNO.FileStation.FocusGridPlugin), Ext.ns("SYNO.FileStation"), SYNO.FileStation.GridPanelFlexcrollPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        var t = this;
        Ext.apply(e, {
            updateScrollbar: t.updateScrollbar
        }), e.mon(e, "beforerender", function() {
            e.cls = e.cls ? e.cls + " syno-webfm-scroll" : "syno-webfm-scroll", e.overCls = e.overCls ? e.overCls + " syno-webfm-scroll-over" : "syno-webfm-scroll-over"
        }, this), e.mon(e, "afterrender", function(e) {
            var t = e.getView().scroller;
            e.updateScrollbar(t.dom), e.mon(e, "resize", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getView(), "refresh", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "load", function() {
                this.updateScrollbar(t.dom, !0), this.fireEvent("afterUpdateScrollbar", this)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "clear", function() {
                this.updateScrollbar(t.dom, !0)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "datachanged", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            }), e.mon(e.getStore(), "update", function() {
                this.updateScrollbar(t.dom)
            }, e, {
                buffer: 500
            })
        }, this)
    },
    updateScrollbar: function(e, t) {
        e && e.fleXcroll ? (t && e.fleXcroll.setScrollPos(!1, 0), e.fleXcroll.updateScrollBars(), t || e.fleXcroll.setScrollPos(0, 0, !0)) : e && (fleXenv.fleXcrollMain(e), e.onfleXcroll = function() {
            this.isVisible() && this.getView().update && this.getView().update()
        }.createDelegate(this))
    }
}), SYNO.FileStation.GridPanelFlexcrollPluginInstance = new SYNO.FileStation.GridPanelFlexcrollPlugin, Ext.preg("gridpanelflexcrollplugin", SYNO.FileStation.GridPanelFlexcrollPlugin), SYNO.FileStation.BufferViewFlexcrollPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        var t = this;
        Ext.apply(e.getView(), {
            initTemplates: t.initTemplates,
            getVscrollerbarBase: t.getVscrollerbarBase,
            getContentwrapper: t.getContentwrapper,
            getVisibleRowCount: t.getVisibleRowCount,
            getVisibleRows: t.getVisibleRows
        })
    },
    initTemplates: function() {
        Ext.ux.grid.BufferView.prototype.initTemplates.apply(this, arguments);
        var e = this.templates;
        e.hcell = new Ext.Template('<td class="x-grid3-hd x-grid3-cell x-grid3-td-{id} {css}" style="{style}"><div class="x-grid3-hd-row-split"></div><div {tooltip} {attr} class="x-grid3-hd-inner webfm-x-grid3-hd x-grid3-hd-{id}" unselectable="on" style="{istyle}">', this.grid.enableHdMenu ? '<a class="x-grid3-hd-btn" href="#"></a>' : "", "{value}", '<img alt="" class="x-grid3-sort-icon" src="', Ext.BLANK_IMAGE_URL, '" />', "</div>", "</td>"), e.hcell.disableFormats = !0, e.hcell.compile()
    },
    getVscrollerbarBase: function() {
        return this.scrollerbarbase ? this.scrollerbarbase : this.scrollerbarbase = Ext.get(this.el.child("div.scrollerbarbase"))
    },
    getContentwrapper: function() {
        return this.vscrollerbar ? this.vscrollerbar : this.vscrollerbar = Ext.get(this.el.child("div.contentwrapper"))
    },
    getVisibleRowCount: function() {
        var e = this.getCalculatedRowHeight(),
            t = Ext.isEmpty(this.getVscrollerbarBase()) ? this.scroller.dom.clientHeight : this.getVscrollerbarBase().getHeight();
        return t < 1 ? 0 : Math.ceil(t / e)
    },
    getVisibleRows: function() {
        var e = this.getVisibleRowCount(),
            t = Ext.isEmpty(this.getContentwrapper()) ? this.scroller.dom.scrollTop : -1 * this.getContentwrapper().getTop(!0) + 1,
            r = 0 === t ? 0 : Math.floor(t / this.getCalculatedRowHeight()) - 1;
        return {
            first: Math.max(r, 0),
            last: Math.min(r + e + 3, this.ds.getCount() - 1)
        }
    }
}), SYNO.FileStation.BufferViewFlexcrollPluginInstance = new SYNO.FileStation.BufferViewFlexcrollPlugin, Ext.preg("bufferviewflexcrollplugin", SYNO.FileStation.BufferViewFlexcrollPlugin), Ext.ns("SYNO.FileStation"), SYNO.FileStation.SelectAllRowSelectionModel = Ext.extend(Ext.grid.RowSelectionModel, {
    constructor: function(e) {
        SYNO.FileStation.SelectAllRowSelectionModel.superclass.constructor.call(this, e), this.pageSelections = new Ext.util.MixedCollection(!1, function(e) {
            return e.id
        })
    },
    onRefresh: function() {
        var e, t, r = this.grid.store,
            i = this.getSelections(),
            o = 0,
            s = i.length;
        for (this.silent = this.silentMode && !0, this.clearSelections(!0); o < s; o++) t = i[o], -1 != (e = r.indexOfId(t.id)) && this.selectRow(e, !0);
        i.length != this.pageSelections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
    },
    maskGrid: function(e) {
        e.loadMask && e.loadMask.show()
    },
    unmaskGrid: function(e) {
        e.loadMask && e.loadMask.hide()
    },
    selectAllRow: function(e) {
        if (!this.isLocked()) {
            var t = this.grid,
                r = this.grid.store,
                i = this.grid.store.getCount();
            this.maskGrid(t), this.selections.clear();
            for (var o = 0; o < i; o++) this.selectRow(o, !0);
            if (r.storetype === SYNO.webfm.utils.source.remotes) return this.unmaskGrid(t), void(r.getTotalCount() !== r.getCount() && t.owner.findAppWindow().getToastBox.call(t, _WFT("search", "select_current_page_all"), !1, !1, {
                delay: 2500,
                offsetY: 32
            }));
            if (r.getTotalCount() === r.getCount()) return void this.unmaskGrid(t);
            r.suspendEvents(), r.load({
                params: {
                    offset: 0,
                    limit: r.getTotalCount()
                },
                callback: function() {
                    this.pageSelections.clear(), this.pageSelections.addAll(r.data.items), r.resumeEvents(), this.unmaskGrid(t), e.callback && e.callback.call(e.scope || this)
                },
                scope: this
            })
        }
    },
    clearSelections: function(e) {
        if (!this.isLocked()) {
            if (!0 !== e) {
                var t = this.grid.store,
                    r = this.selections;
                r.each(function(e) {
                    this.deselectRow(t.indexOfId(e.id))
                }, this), r.clear()
            } else this.selections.clear();
            this.last = !1
        }
    },
    clearAllSelections: function(e) {
        if (!this.isLocked())
            if (!0 !== e) {
                var t = this.grid.store,
                    r = this.pageSelections;
                r.each(function(e) {
                    this.deselectRow(t.indexOfId(e.id))
                }, this), r.clear()
            } else this.pageSelections.clear()
    },
    selectRow: function(e, t, r) {
        if (!(this.isLocked() || e < 0 || e >= this.grid.store.getCount() || t && this.isSelected(e))) {
            var i = this.grid.store.getAt(e);
            i && !1 !== this.fireEvent("beforerowselect", this, e, t, i) && (t && !this.singleSelect || (this.clearSelections(), this.clearAllSelections()), this.selections.add(i), this.pageSelections.add(i), this.last = this.lastActive = e, r || this.grid.getView().onRowSelect(e), this.silent || (this.fireEvent("rowselect", this, e, i), this.fireEvent("selectionchange", this)))
        }
    },
    selectRows: function(e, t) {
        t || (this.clearSelections(), this.clearAllSelections());
        for (var r = 0, i = e.length; r < i; r++) this.selectRow(e[r], !0)
    },
    selectRange: function(e, t, r) {
        var i;
        if (!this.isLocked())
            if (r || (this.clearSelections(), this.clearAllSelections()), e <= t)
                for (i = e; i <= t; i++) this.selectRow(i, !0);
            else
                for (i = e; i >= t; i--) this.selectRow(i, !0)
    },
    deselectRow: function(e, t) {
        if (!this.isLocked()) {
            this.last == e && (this.last = !1), this.lastActive == e && (this.lastActive = !1);
            var r = this.grid.store.getAt(e);
            r && (this.selections.remove(r), this.pageSelections.remove(r), t || this.grid.getView().onRowDeselect(e), this.fireEvent("rowdeselect", this, e, r), this.fireEvent("selectionchange", this))
        }
    },
    getSelections: function() {
        return [].concat(this.pageSelections.items)
    }
}), Ext.ns("SYNO.FileStation"), SYNO.FileStation.FocusComponentPlugin = Ext.extend(Ext.Component, {
    init: function(e) {
        e.mon(e, "afterrender", function() {
            this.onAfterRender(e)
        }, this)
    },
    onAfterRender: function(e) {
        e.getEl().on("click", function(e) {
            Ext.isGecko ? this.getEl().focus() : this.getEl().focus.defer(1, this.getEl())
        }, e)
    }
}), SYNO.FileStation.FocusComponentPluginInstance = new SYNO.FileStation.FocusComponentPlugin, Ext.preg("focuscomponentplugin", SYNO.FileStation.FocusComponentPlugin), SYNO.FileStation.DataViewSelectionModel = function(e) {
    var t = e,
        r = function() {
            return t.getSelectionCount() > 0
        },
        i = function() {
            return t.getSelectedRecords()
        };
    return {
        dataView: t,
        getSelected: function() {
            return i()[0]
        },
        getCount: function() {
            return t.getSelectionCount()
        },
        hasSelection: r,
        getSelections: i,
        selectAllRow: function(e) {
            t.selectAllRow(e)
        },
        clearAllSelections: function(e) {
            t.clearAllSelections(e)
        },
        clearSelections: function(e) {
            t.clearSelections(e)
        },
        selectRow: function(e, r) {
            t.select(e, r)
        },
        selectRecords: function(e, r) {
            var i = 0;
            if (!Ext.isEmpty(e))
                for (r || this.clearAllSelections(), i = 0; i < e.length; i++) this.selectRow(t.store.indexOf(e[i]), !0)
        }
    }
}, SYNO.FileStation.SelectAllDataView = Ext.extend(SYNO.SDS.Utils.DataView.LazyDataView, {
    constructor: function(e) {
        SYNO.FileStation.SelectAllDataView.superclass.constructor.call(this, e), this.selectAll = new Ext.util.MixedCollection(!1, function(e) {
            return e.id
        }), this.on("afterrender", this.protectFocus.createDelegate(this, [!0]), this)
    },
    protectFocus: function(e) {
        this.rendered && (this.el.dom.focusProtect = e)
    },
    getSelectionModel: function() {
        return this.selectionModel || (this.selectionModel = new SYNO.FileStation.DataViewSelectionModel(this))
    },
    getSelectionCount: function() {
        return this.selectAll.items.length
    },
    getSelectedNodes: function() {
        return [].concat(this.selectAll.items)
    },
    getSelectedRecords: function() {
        return [].concat(this.selectAll.items)
    },
    clearAllSelections: function(e, t) {
        (this.multiSelect || this.singleSelect) && this.selectAll.getCount() > 0 && (t || this.selected.removeClass(this.selectedClass), this.selected.clear(), this.selectAll.clear(), this.last = !1, e || this.fireEvent("selectionchange", this, this.selected.elements))
    },
    onContainerClick: function(e) {
        null === e.getTarget(".vscrollerbar") && null === e.getTarget(".hscrollerbar") && this.clearAllSelections()
    },
    selectAllRow: function(e) {
        var t = this,
            r = t.getStore(),
            i = r.getCount();
        t.getEl().mask(t.loadingText || "", "x-mask-loading"), t.clearAllSelections();
        for (var o = 0; o < i; o++) t.select(o, !0, !0);
        return r.storetype === SYNO.webfm.utils.source.remotes ? (t.getEl().unmask(), void(r.getTotalCount() !== r.getCount() && this.owner.findAppWindow().getToastBox.call(this, _WFT("search", "select_current_page_all"), !1, !1, {
            delay: 2500,
            offsetY: 32
        }))) : r.getTotalCount() === r.getCount() ? void t.getEl().unmask() : (r.suspendEvents(), void r.load({
            params: {
                offset: 0,
                limit: r.getTotalCount()
            },
            callback: function() {
                t.isDestroy || (this.selectAll.addAll(r.data.items), r.resumeEvents(), t.getEl().unmask(), e.callback && e.callback.call(e.scope || this))
            },
            scope: this
        }))
    },
    selectRange: function(e, t, r) {
        r || this.clearAllSelections(!0), this.select(this.getNodes(e, t), !0)
    },
    isSelected: function(e) {
        return this.selectAll.contains(this.getRecord(this.getNode(e)))
    },
    deselect: function(e) {
        this.isSelected(e) && (e = this.getNode(e), this.selected.removeElement(e), this.selectAll.remove(this.getRecord(this.getNode(e))), this.last == e.viewIndex && (this.last = !1), Ext.fly(e).removeClass(this.selectedClass), this.fireEvent("selectionchange", this, this.selected.elements))
    },
    select: function(e, t, r) {
        if (Ext.isArray(e)) {
            t || this.clearAllSelections(!0);
            for (var i = 0, o = e.length; i < o; i++) this.select(e[i], !0, !0);
            r || this.fireEvent("selectionchange", this, this.selected.elements)
        } else {
            var s = this.getNode(e);
            t || this.clearAllSelections(!0), s && !this.isSelected(s) && !1 !== this.fireEvent("beforeselect", this, s, this.selected.elements) && (Ext.fly(s).addClass(this.selectedClass), this.selected.add(s), this.selectAll.add(this.getRecord(this.getNode(s))), this.last = s.viewIndex, r || this.fireEvent("selectionchange", this, this.selected.elements))
        }
    },
    refresh: function() {
        SYNO.FileStation.SelectAllDataView.superclass.refresh.call(this);
        for (var e, t = this, r = t.getSelectedRecords(), i = 0, o = t.getStore(), s = r.length; i < s; i++) {
            var n = r[i]; - 1 != (e = o.indexOfId(n.id)) && this.select(e, !0, !0)
        }
    }
}), SYNO.FileStation.ThumbnailSizeManager = Ext.extend(Object, {
    constructor: function(e) {
        var t = this;
        e = e || {}, t.largeThumbCls = "syno-sds-fs-large-thumb", t.smallThumbCls = "syno-sds-fs-small-thumb", t.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM, Ext.apply(t, e)
    },
    resizeThumb: function(e) {
        var t = e.getWidth(),
            r = e.getHeight();
        e.removeClass("syno-sds-fs-large-thumb-width"), e.removeClass("syno-sds-fs-large-thumb-height"), t >= r ? e.addClass("syno-sds-fs-large-thumb-width") : e.addClass("syno-sds-fs-large-thumb-height")
    },
    getThumbSize: function() {
        return this.thumbSize
    },
    changeThumbSize: function(e, t) {
        var r = this;
        switch (e.removeClass(r.largeThumbCls), e.removeClass(r.smallThumbCls), t) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
                e.addClass(r.smallThumbCls), r.thumbSize = SYNO.webfm.utils.ThumbSize.SMALL;
                break;
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                r.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM;
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                e.addClass(r.largeThumbCls), r.thumbSize = SYNO.webfm.utils.ThumbSize.LARGE;
                break;
            default:
                r.thumbSize = SYNO.webfm.utils.ThumbSize.MEDIUM
        }
    }
}), Ext.define("SYNO.FileStation.ImageLoader", {
    extend: "Ext.Component",
    maxImageRequest: 24,
    constructor: function() {
        this.imageQueue = [], this.imageToDoQueue = [], this.callParent(arguments)
    },
    getTask: function() {
        return this.actionTask = this.actionTask || this.addTask({
            id: "task_set_image",
            interval: 17,
            run: this.setImage,
            scope: this
        }), this.actionTask
    },
    addImage: function(e) {
        this.innerAddImage(e)
    },
    innerAddImage: function(e) {
        var t = this,
            r = t.imageToDoQueue,
            i = t.getTask(); - 1 === r.indexOf(e) && -1 === t.imageQueue.indexOf(e) && (r.push(e), !1 === i.running && i.restart(!0))
    },
    removeImage: function(e) {
        var t = this,
            r = t.imageQueue;
        0 !== r.length && -1 !== r.indexOf(e) && (r.remove(e), 0 === r.length && t.getTask().stop())
    },
    removeAll: function() {
        var e = this;
        e.imageQueue = [], e.imageToDoQueue = [], e.getTask().stop()
    },
    setImage: function() {
        var e, t = this,
            r = 0,
            i = t.imageToDoQueue.concat(t.imageQueue),
            o = Math.min(t.maxImageRequest, i.length),
            s = [];
        for (t.imageToDoQueue = [], r = 0; r < o; r++) e = i[r], !1 === t.fireEvent("setimage", e) && s.push(e);
        i.splice(0, o), i = i.concat(s), t.imageQueue = i, 0 === i.length && t.getTask().stop()
    },
    stop: function() {
        this.getTask().stop()
    },
    destroy: function() {
        var e = this;
        e.imageQueue = null, e.imageToDoQueue = null, e.actionTask && (e.actionTask = null), e.callParent(arguments)
    }
}), Ext.define("SYNO.FileStation.ThumbnailsView", {
    delay: 100,
    extend: "SYNO.FileStation.SelectAllDataView",
    ieMaxURLLength: 2048,
    shadowCls: "syno-sds-fs-thumb-shadow",
    defaultSupportExt: ["jpg", "jpeg", "jpe", "bmp", "png", "tif", "tiff", "gif", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "raw", "heic", "heif"],
    defaultSupportVideoExt: ["3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "mk3d", "mka", "mks", "m4a", "m4v", "mkv", "mp4", "mts", "m4p", "m4b", "m4r", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "flv", "f4v", "avi", "swf", "vdr", "iso"],
    constructor: function(e) {
        this.supportExt = SYNO.SDS.Config && SYNO.SDS.Config.FnMap ? SYNO.SDS.Config.FnMap["SYNO.SDS.PhotoViewer.Application"].config.fb_extern[0].file || this.defaultSupportExt : this.defaultSupportExt, e = e || {}, e = Ext.apply({
            loadingText: _WFT("common", "loading"),
            cls: "syno-sds-fs-thumbnailsView",
            region: "center",
            multiSelect: !0,
            autoScroll: !0,
            itemMarginWidth: 12,
            itemSelector: "div.thumb-wrap",
            disableTextSelect: !0,
            itemCls: ".syno-sds-fs-thumbnailsView .thumb-wrap",
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap" id="{[this.htmlEncode(values.file_id)]}" role="option" aria-haspopup="true">', '<div ext:qtip="{[this.getTooltip(values)]}" class="thumb">', '<div class="thumb-hover thumb-loading" externalcss="{[this.getExternalCSS(values)]}">', '<img defaulticon="{icon}" draggable="false" class="{[this.hasThumbnail(values)]}" thumbnails="{[this.getThumbnailURL(values)]}" src="{[this.getDefaultSrc()]}" isvideo="{[this.getVideoType(values)]}">', "</div>", "<span>{[this.htmlEncode(values.filename)]}</span>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>', {
                compiled: !0,
                disableFormats: !0,
                getThumbnailURL: this.getThumbnailURL.createDelegate(this),
                hasThumbnail: this.hasThumbnail.createDelegate(this),
                getVideoType: this.getVideoType.createDelegate(this),
                getDefaultSrc: this.getDefaultSrc.createDelegate(this),
                getExternalCSS: this.getExternalCSS.createDelegate(this),
                getTooltip: this.getTooltip.createDelegate(this),
                htmlEncode: Ext.util.Format.htmlEncode
            }),
            prepareData: function(e) {
                return Ext.isEmpty(e.icon) && (e.icon = SYNO.webfm.utils.getThumbName(e)), e
            }.createDelegate(this)
        }, e), this.thumbSizeManager = new SYNO.FileStation.ThumbnailSizeManager, this.imageLoader = new SYNO.FileStation.ImageLoader, this.callParent([e]), this.mon(this.imageLoader, "setimage", this.setImgURL, this)
    },
    onStoreLoad: function() {
        this.updateScrollbar(this.trackResetOnLoad), this.trackResetOnLoad = !0, this.fireEvent("afterUpdateScrollbar", this)
    },
    convertFileName: function(e, t) {
        var r = e.is_snapshot && e.is_btrfs_subvol,
            i = Ext.util.Format.htmlEncode(e.filename);
        return r ? (i = i.replace(/-/g, " "), i = i.substr(0, 14).replace(/\./g, "-") + i.substr(14, i.length).replace(/\./g, ":"), t && "" !== e.snapshot_desc && (i += Ext.util.Format.htmlEncode(" - " + e.snapshot_desc)), i) : i
    },
    getThumbnailSize: function(e) {
        var t = "small";
        switch (e) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                t = "medium";
                break;
            default:
                t = "small"
        }
        return t
    },
    getSizeNumber: function(e) {
        var t = 128;
        switch (e) {
            case SYNO.webfm.utils.ThumbSize.SMALL:
                t = 64;
                break;
            case SYNO.webfm.utils.ThumbSize.MEDIUM:
                t = 128;
                break;
            case SYNO.webfm.utils.ThumbSize.LARGE:
                t = 256;
                break;
            default:
                t = 128
        }
        return t
    },
    resizeThumb: function(e) {},
    changeThumbSize: function(e) {
        this.thumbSizeManager.changeThumbSize(this.getEl(), e), this.onResize()
    },
    getTooltip: function(e) {
        var t = "{0}<br>{1}<br>{2}";
        return t = e.isdir ? String.format("{0}<br>{1}", _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        })) : String.format(t, _WFT("common", "common_filename") + _T("common", "colon") + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.filename)), Ext.util.Format.htmlEncode(_WFT("common", "common_filesize") + _T("common", "colon") + Ext.util.Format.fileSize(e.filesize)), Ext.util.Format.htmlEncode(_WFT("filetable", "filetable_mtime") + _T("common", "colon") + SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * e.mt)), {
            type: "datetimesec"
        }))
    },
    afterRender: function() {
        this.callParent(arguments), this.mun(this.getTemplateTarget(), "click", this.onClick, this), this.on("flexcrollInitDone", function() {
            this.mon(this.el.child(".mcontentwrapper"), "click", this.onClick, this)
        }, this, {
            single: !0
        }), this.keys && (this.keymap = new Ext.KeyMap(this.getEl(), this.keys))
    },
    getDefaultSrc: function() {
        return this.defaultSrc = this.RELURL + "../../../scripts/ext-3/resources/images/default/s.gif", this.defaultSrc
    },
    isSupportExt: function(e) {
        var t = !1;
        return Ext.each(this.supportExt, function(r) {
            e === r && (t = !0)
        }, this), t
    },
    isSupportVideoExt: function(e) {
        var t = !1;
        return Ext.each(this.defaultSupportVideoExt, function(r) {
            e === r && (t = !0)
        }, this), t
    },
    getExternalCSS: function(e) {
        var t, r = this.getStore().getById(e.file_id),
            i = this.thumbSizeManager.getThumbSize();
        return SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && (t = this.owner.getExternIcon(r, this.getSizeNumber(i))) ? (e.iconObj = t, t.css ? t.css : "") : ""
    },
    hasThumbnail: function(e) {
        return "remotefail" === e.mountType ? "" : this.isSupportExt(e.type.toLowerCase()) || this.isSupportVideoExt(e.type.toLowerCase()) || this.isSupportPluginExt(e) ? this.shadowCls : ""
    },
    getVideoType: function(e) {
        return this.isSupportVideoExt(e.type.toLowerCase())
    },
    isSupportPluginExt: function(e) {
        var t = !1;
        return Ext.each(this.owner.externThumbnailExts, function(r) {
            try {
                if (r.checkFn(e) && !1 !== r.shadow) return t = !0, !1
            } catch (e) {
                return !1
            }
        }), t
    },
    getExtThumbnailURL: function(e, t) {
        var r = !1;
        return Ext.each(this.owner.externThumbnailExts, function(i) {
            try {
                if (i.checkFn(e)) return r = i.getFn(t), !1
            } catch (e) {
                return !0
            }
        }), r
    },
    getDefaultIcon: function(e) {
        var t = window.location.pathname,
            r = "";
        return r = _S("standalone") && t ? t + "webman/modules/FileBrowser/" : "/webman/modules/FileBrowser/", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(r + "images/{1}/files_ext_256/" + e, "FileType", !0)
    },
    getThumbnailURL: function(e) {
        var t = this.getDefaultIcon(e.icon),
            r = this.isSupportVideoExt(e.type.toLowerCase()),
            i = t,
            o = {
                path: Ext.encode(e.path),
                mt: e.mt
            };
        return "remotefail" === e.mountType ? this.getDefaultIcon("remotefailmountpoint.png") : !1 !== (i = this.getExtThumbnailURL(e, o)) ? i : SYNO.webfm.utils.isRemoteSource(this.owner.getCurrentSource()) && e.iconObj && e.iconObj.url ? e.iconObj.url : ((this.isSupportExt(e.type.toLowerCase()) || r) && (i = Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.FileStation.Thumb", "get", 2), Ext.urlEncode(o))), SYNO.webfm.VFS.isVFSPath(this.owner.getCurrentDir()) || i.length > this.ieMaxURLLength ? t : i)
    },
    removeListeners: function(e) {
        Ext.get(e).removeAllListeners()
    },
    onImageLoad: function(e, t, r) {
        var i = Ext.get(t);
        i.parent().removeClass("thumb-loading"), i.parent().addClass(Ext.fly(t).parent().getAttribute("externalcss")), this.resizeThumb(i), i.addClass("fadein")
    },
    onImageError: function(e) {
        var t = e.getAttribute("defaulticon"),
            r = this.getDefaultIcon(t),
            i = Ext.get(e);
        i.removeClass(this.shadowCls), i.on("error", this.setDefaultIcon, this), e.src = r, e.loaded = void 0
    },
    onImageLoadEvent: function(e) {
        Ext.get(e).on("load", this.onImageLoad, this)
    },
    setDefaultIcon: function(e, t, r) {
        var i = this.getDefaultIcon("misc.png"),
            o = Ext.get(t);
        o.removeClass(this.shadowCls), this.onImageLoadEvent(t), t.src = i, o.un("error", this.setDefaultIcon, this)
    },
    errorHandler: function(e, t, r) {
        this.onImageError(t)
    },
    setImgURL: function(e) {
        var t, r, i, o, s = this.thumbSizeManager.getThumbSize();
        this.all.each(function(i) {
            if (i.id === e) return t = i, r = t.select("img"), !1
        }, this), r && r.elements.length > 0 && (i = r.elements[0], o = i.getAttribute("thumbnails"), this.onImageLoadEvent(i), "false" === o ? this.errorHandler(null, i) : (Ext.fly(i).on("error", this.errorHandler, this), "true" == i.getAttribute("isvideo") && (s = SYNO.webfm.utils.ThumbSize.LARGE), i.src = Ext.urlAppend(o, "size=" + this.getThumbnailSize(s))), i.loaded = s)
    },
    onLoadItem: function(e) {
        var t, r = e.select("img"),
            i = this.thumbSizeManager.getThumbSize();
        r.elements.length > 0 && (t = r.elements[0], t.loaded !== i && t.loaded !== SYNO.webfm.utils.ThumbSize.LARGE ? this.imageLoader.addImage(e.id) : this.resizeThumb(Ext.fly(t)))
    },
    onUnLoadItem: function(e) {
        this.imageLoader.removeImage(e.id)
    },
    removeEvents: function() {
        var e = this.getTemplateTarget();
        if (e)
            for (var t = Ext.query(".thumb-hover img", e.dom), r = 0; r < t.length; r++) this.removeListeners(t[r])
    },
    refresh: function() {
        this.removeEvents(), this.imageLoader.removeAll(), this.callParent(arguments)
    },
    destroy: function() {
        this.removeEvents(), this.imageLoader.destroy(), this.callParent(arguments)
    }
}), Ext.define("SYNO.FileStation.FolderSharingThumbnailsView", {
    extend: "SYNO.FileStation.ThumbnailsView",
    getExternalCSS: function() {
        return ""
    },
    getThumbnailURL: function(e) {
        var t = this.getDefaultIcon(e.icon),
            r = this.isSupportVideoExt(e.type.toLowerCase());
        if ("remotefail" === e.mountType) return this.getDefaultIcon("remotefailmountpoint.png");
        if (e.iconObj && e.iconObj.url) return e.iconObj.url;
        var i = this.isSupportExt(e.type.toLowerCase()) || r ? Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.FolderSharing.Thumb", "get", 2), Ext.urlEncode({
            path: Ext.encode(e.path),
            mt: e.mt,
            _sharing_id: Ext.encode(this.folderSharingURL)
        })) : t;
        return i.length > this.ieMaxURLLength ? t : i
    }
});