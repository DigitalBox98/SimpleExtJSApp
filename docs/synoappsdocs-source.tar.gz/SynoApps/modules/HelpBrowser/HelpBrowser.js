! function(e) {
    var t = {};

    function n(i) {
        if (t[i]) return t[i].exports;
        var o = t[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return e[i].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, i) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: i
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) n.d(i, o, function(t) {
                return e[t]
            }.bind(null, o));
        return i
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 29)
}([function(e, t) {
    e.exports = Vuex
}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {}, function(e, t, n) {
    "use strict";
    var i = n(1);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(2);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(3);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(4);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(5);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(6);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(7);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(8);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(9);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(10);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(11);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(12);
    n.n(i).a
}, function(e, t, n) {
    "use strict";
    var i = n(13);
    n.n(i).a
}, , , function(e, t, n) {
    "use strict";
    n.r(t);
    var i = {
            methods: {
                T: function(e, t) {
                    var n = _T(e, t);
                    return n && "" !== n ? n : "".concat(e, ":").concat(t)
                },
                D: function(e) {
                    var t = _D(e);
                    return t && "" !== t ? t : "".concat(e)
                },
                htmlEncode: function(e) {
                    return e ? String(e).replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/'/g, "&quot;").replace(/'/g, "&apos;") : e
                },
                urlEncode: function(e) {
                    var t = [];
                    for (var n in e) t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
                    return t.join("&")
                },
                formatUrl: function(e, t, n) {
                    var i = '<a href="{0}" target="_blank">';
                    return String.format(e, String.format(i, t), "</a>", String.format(i, n), "</a>")
                }
            }
        },
        o = n(0),
        r = n.n(o),
        a = {
            name: "TipCard",
            props: {
                title: {
                    type: String,
                    required: !0
                },
                desc: {
                    type: String,
                    required: !0
                },
                icon: {
                    type: String,
                    required: !0
                },
                showAllContent: Boolean
            },
            data: function() {
                return {}
            },
            computed: {
                cls: function() {
                    return ["tip-card", {
                        "hide-overflow": !this.showAllContent
                    }]
                }
            },
            methods: {
                onClick: function() {
                    this.$store.dispatch("TipModule/changeActiveCategory", this.icon)
                }
            }
        };
    n(14);

    function s(e, t, n, i, o, r, a, s) {
        var c, l = "function" == typeof e ? e.options : e;
        if (t && (l.render = t, l.staticRenderFns = n, l._compiled = !0), i && (l.functional = !0), r && (l._scopeId = "data-v-" + r), a ? (c = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), o && o.call(this, e), e && e._registeredComponents && e._registeredComponents.add(a)
            }, l._ssrRegister = c) : o && (c = s ? function() {
                o.call(this, (l.functional ? this.parent : this).$root.$options.shadowRoot)
            } : o), c)
            if (l.functional) {
                l._injectStyles = c;
                var p = l.render;
                l.render = function(e, t) {
                    return c.call(t), p(e, t)
                }
            } else {
                var u = l.beforeCreate;
                l.beforeCreate = u ? [].concat(u, c) : [c]
            } return {
            exports: e,
            options: l
        }
    }
    var c = s(a, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("div", {
            class: e.cls,
            on: {
                click: e.onClick
            }
        }, [n("div", {
            staticClass: "tip-card-title"
        }, [e._v(" " + e._s(e.title) + " ")]), e._v(" "), n("div", {
            staticClass: "tip-card-desc"
        }, [e._v(" " + e._s(e.desc) + " ")]), e._v(" "), n("div", {
            class: "tip-card-icon " + e.icon
        })])
    }), [], !1, null, null, null).exports;

    function l() {
        var e = SYNO.SDS.Packages.getAllPackages(),
            t = {};
        for (var n in e) n && e.hasOwnProperty(n) && SYNO.SDS.StatusNotifier.isAppEnabled(n) && (t[e[n].pkgId] = e[n].version);
        return t.DSM = _S("productversion"), t
    }

    function p(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function u(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var d, f, h = {
            name: "HelpSearchField",
            mixins: [i],
            props: {
                width: {
                    type: Number,
                    default: 350
                }
            },
            data: function() {
                return {
                    query: "",
                    search: ""
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        u(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)(["online"]), {
                searchApiObj: function() {
                    return this.online ? {
                        api: "SYNO.Core.Help",
                        method: "get_search_result",
                        version: 1,
                        params: {
                            dsm: _S("productversion") + "-" + _S("version"),
                            lang: SYNO.SDS.Utils.getHelpLanguage(),
                            treeNode: JSON.stringify(l()),
                            type: "help",
                            unique: _D("unique")
                        }
                    } : {
                        api: "SYNO.Core.UISearch",
                        method: "uisearch",
                        version: 1,
                        params: {
                            lang: SYNO.SDS.Utils.getHelpLanguage(),
                            type: "help"
                        }
                    }
                },
                displayField: function() {
                    return this.online ? "title" : "topic"
                },
                isTitleVisible: function() {
                    return this.$refs.search.currentOptions.length > 0
                }
            }),
            methods: {
                getIcon: function(e) {
                    return SYNO.SDS.Utils.GetAppIcon(e, "TreeIcon")
                },
                getAppTitle: function(e) {
                    return SYNO.SDS.Utils.GetAppTitle(e)
                },
                updateQuery: function(e) {
                    this.query = e
                },
                getOptions: (d = regeneratorRuntime.mark((function e() {
                    var t, n;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return (t = Object.assign({}, this.searchApiObj)).params.query = this.query, e.next = 4, synowebapi.promises.request(t);
                            case 4:
                                return n = e.sent, _S("rewriteApp") && (n.items = n.items.filter((function(e) {
                                    return "help" === e.type && e.owner === _S("rewriteApp")
                                }))), e.abrupt("return", n);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), f = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var o = d.apply(e, t);

                        function r(e) {
                            p(o, n, i, r, a, "next", e)
                        }

                        function a(e) {
                            p(o, n, i, r, a, "throw", e)
                        }
                        r(void 0)
                    }))
                }, function() {
                    return f.apply(this, arguments)
                }),
                onInput: function(e) {
                    this.$emit("itemselect", e)
                }
            }
        },
        g = (n(15), s(h, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-select", {
                ref: "search",
                staticClass: "help-search-field",
                attrs: {
                    "syno-id": "help-searchfield",
                    name: "help_search",
                    readonly: !1,
                    placeholder: e.T("log", "search"),
                    "hide-trigger": "",
                    "allow-clear": "",
                    search: "",
                    "min-search-char": 2,
                    "dropdown-width": e.width + "px",
                    "max-height": 424,
                    options: e.getOptions,
                    root: "items",
                    "display-field": e.displayField,
                    "value-field": "id",
                    width: e.width
                },
                on: {
                    "input-val": e.updateQuery,
                    input: e.onInput
                },
                scopedSlots: e._u([{
                    key: "before-options",
                    fn: function() {
                        return [n("div", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: e.isTitleVisible,
                                expression: "isTitleVisible"
                            }],
                            staticClass: "help-search-result-title"
                        }, [e._v(e._s(e.T("helpbrowser", "search_results")) + " ")])]
                    },
                    proxy: !0
                }, {
                    key: "inner-option",
                    fn: function(t) {
                        return [n("img", {
                            staticClass: "help-search-icon",
                            attrs: {
                                src: e.getIcon(t.option.owner)
                            }
                        }), e._v(" "), n("div", {
                            staticClass: "help-search-page-title"
                        }, [e._v(e._s(t.option[e.displayField]))]), e._v(" "), n("div", {
                            staticClass: "help-search-category"
                        }, [e._v(e._s(e.getAppTitle(t.option.owner)))])]
                    }
                }, {
                    key: "after-options",
                    fn: function() {},
                    proxy: !0
                }]),
                model: {
                    value: e.search,
                    callback: function(t) {
                        e.search = t
                    },
                    expression: "search"
                }
            })
        }), [], !1, null, null, null).exports);

    function b(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function S(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, o) {
                var r = e.apply(t, n);

                function a(e) {
                    b(r, i, o, a, s, "next", e)
                }

                function s(e) {
                    b(r, i, o, a, s, "throw", e)
                }
                a(void 0)
            }))
        }
    }

    function m(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var v, _, y = {
            name: "TipHome",
            components: {
                TipCard: c,
                HelpSearchField: g
            },
            mixins: [i],
            props: {
                winWidth: {
                    type: Number,
                    default: 1200
                },
                winHeight: {
                    type: Number,
                    default: 530
                },
                needShowTippy: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    isOutOfMaxHeight: !1,
                    isOutOfMaxWidth: !1,
                    isCardDisplayFullContent: !1,
                    isShowTippy: !1
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        m(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapGetters)("TipModule", ["rows", "first"]), {
                cls: function() {
                    return ["syno-help-tip-home", {
                        "is-normal-user": !this.isAdmin
                    }, {
                        "is-big-window": this.isOutOfMaxWidth && this.isOutOfMaxHeight
                    }]
                }
            }),
            watch: {
                winWidth: function(e) {
                    this.isOutOfMaxWidth = e > 1240, this.setTippySize()
                },
                winHeight: function(e) {
                    this.isOutOfMaxHeight = e > 868, this.isCardDisplayFullContent = e > 232 * this.rows.length + 294, this.setTippySize()
                },
                isShowTippy: (_ = S(regeneratorRuntime.mark((function e(t) {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!t) {
                                    e.next = 4;
                                    break
                                }
                                return e.next = 3, this.setTippySize();
                            case 3:
                                this.$refs["tippy-card"] && (this.$refs["tippy-card"].$el.classList.add("hover"), this.$refs["tippy-card"].$el.addEventListener("click", this.onCloseTippy));
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return _.apply(this, arguments)
                }),
                needShowTippy: function(e) {
                    this.isShowTippy = e
                }
            },
            created: function() {
                this.isAdmin = _S("is_admin")
            },
            methods: {
                gotoHelp: function() {
                    this.$store.dispatch("changeType", "help")
                },
                onSearchItemSelect: function(e) {
                    e && (this.gotoHelp(), this.$store.dispatch("HelpModule/changeTopic", e))
                },
                onCloseTippy: function() {
                    this.isShowTippy = !1
                },
                setTippySize: (v = S(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.isShowTippy) {
                                    e.next = 8;
                                    break
                                }
                                return e.next = 3, this.$nextTick();
                            case 3:
                                t = this.$el.getElementsByClassName("tip-card"), this.$refs["tippy-card"].$el.style.width = "".concat(t[0].offsetWidth - 30, "px"), this.$refs["tippy-card"].$el.style.height = "".concat(t[0].offsetHeight - 30, "px"), this.$refs.tooltip.style.width = "".concat(t[0].offsetWidth, "px"), this.$refs.tooltip.style.left = "".concat(t[0].offsetWidth + 32, "px");
                            case 8:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return v.apply(this, arguments)
                })
            }
        },
        w = (n(16), s(y, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                class: e.cls
            }, [n("div", {
                staticClass: "inner-wrapper"
            }, [n("div", {
                staticClass: "search-wrap"
            }, [n("help-search-field", {
                attrs: {
                    width: 480
                },
                on: {
                    itemselect: e.onSearchItemSelect
                }
            })], 1), e._v(" "), e._l(e.rows, (function(t, i) {
                return [n("div", {
                    key: i,
                    staticClass: "tip-card-row"
                }, e._l(t, (function(t) {
                    return n("tip-card", {
                        key: t.key,
                        attrs: {
                            title: t.title,
                            desc: t.desc,
                            icon: t.key,
                            "show-all-content": e.isCardDisplayFullContent
                        }
                    })
                })), 1)]
            })), e._v(" "), n("div", {
                staticClass: "other-info"
            }, [n("div", {
                staticClass: "goto-help-wrap"
            }, [n("div", {
                staticClass: "goto-help",
                attrs: {
                    tabindex: "0"
                },
                on: {
                    click: e.gotoHelp
                }
            }, [n("div", {
                staticClass: "help-icon"
            }), e._v(" "), n("div", {
                staticClass: "help-texts"
            }, [n("div", {
                staticClass: "help-title"
            }, [e._v(e._s(e.T("helpbrowser", "help_entry_title")))]), e._v(" "), n("div", {
                staticClass: "help-desc"
            }, [e._v(e._s(e.T("helpbrowser", "help_entry_desc")))])])])]), e._v(" "), n("div", {
                staticClass: "website-wrap"
            }, [n("a", {
                attrs: {
                    href: "https://www.synology.com/support",
                    target: "_blank"
                }
            }, [n("div", {
                staticClass: "website-item"
            }, [n("div", {
                staticClass: "website-icon tutorial"
            }), e._v(" "), n("div", {
                staticClass: "websiite-title"
            }, [e._v(e._s(e.T("helpbrowser", "tutorials_faq")))])])]), e._v(" "), n("a", {
                attrs: {
                    href: "https://www.synology.com/compatibility",
                    target: "_blank"
                }
            }, [n("div", {
                staticClass: "website-item"
            }, [n("div", {
                staticClass: "website-icon compatibility"
            }), e._v(" "), n("div", {
                staticClass: "websiite-title"
            }, [e._v(e._s(e.T("helpbrowser", "compatibility")))])])])])]), e._v(" "), e.isShowTippy ? n("div", {
                staticClass: "mask"
            }, [n("tip-card", {
                key: e.first.key,
                ref: "tippy-card",
                attrs: {
                    title: e.first.title,
                    desc: e.first.desc,
                    icon: e.first.key,
                    "show-all-content": e.isCardDisplayFullContent
                }
            }), e._v(" "), n("div", {
                ref: "tooltip",
                staticClass: "tip-tooltip"
            }, [n("span", {
                staticClass: "close-btn",
                on: {
                    click: e.onCloseTippy
                }
            }), e._v(" "), n("div", {
                staticClass: "tip-tooltip-body"
            }, [e._v("\n                " + e._s(e.T("helpbrowser", "select_topic")) + "\n            ")])])], 1) : e._e()], 2)])
        }), [], !1, null, null, null).exports),
        O = {
            name: "LeftTab",
            props: {
                desc: {
                    type: String,
                    default: ""
                },
                moreInfoUrl: {
                    type: String,
                    default: ""
                },
                isSet: {
                    type: Boolean,
                    default: !0
                },
                buttonSetText: {
                    type: String,
                    default: ""
                },
                buttonUnsetText: {
                    type: String,
                    default: ""
                },
                buttonAction: {
                    type: Function,
                    default: function() {}
                },
                loaded: {
                    type: Boolean,
                    default: !0
                },
                isButtonVisible: {
                    type: Boolean,
                    default: !0
                }
            }
        },
        C = (n(17), s(O, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-panel", {
                attrs: {
                    "syno-id": "components-left-tab-panel-0",
                    "has-fbar": !1,
                    "has-tbar": !1
                }
            }, [n("v-form", {
                staticClass: "tip-left",
                attrs: {
                    slot: "body",
                    "syno-id": "components-left-tab-form-0"
                },
                slot: "body"
            }, [e._t("before"), e._v(" "), n("v-form-item", {
                attrs: {
                    textonly: "",
                    "hide-label": ""
                }
            }, [n("div", [e._v("\n                " + e._s(e.desc) + "\n                "), e.moreInfoUrl ? n("a", {
                staticClass: "more-info",
                attrs: {
                    href: e.moreInfoUrl,
                    target: "_blank"
                }
            }, [e._v(e._s(e.$i18n("welcome", "know_more")))]) : e._e()])]), e._v(" "), e._t("middle"), e._v(" "), e.loaded && e.isButtonVisible ? n("v-button", {
                staticClass: "tip-btn",
                attrs: {
                    "syno-id": "components-left-tab-button-0",
                    color: e.isSet ? "grey" : "blue"
                },
                on: {
                    click: e.buttonAction
                }
            }, [e._v("\n            " + e._s(e.isSet ? e.buttonSetText || e.$i18n("common", "alt_edit") : e.buttonUnsetText || e.$i18n("helpbrowser", "enable_now")) + "\n        ")]) : e._e(), e._v(" "), e._t("after")], 2)], 1)
        }), [], !1, null, null, null).exports),
        T = {
            name: "TipLoadingIndicator"
        },
        A = (n(18), s(T, (function() {
            var e = this.$createElement,
                t = this._self._c || e;
            return t("div", {
                staticClass: "tip-loading-wrap"
            }, [this._m(0), this._v(" "), t("div", {
                staticClass: "loading-text"
            }, [this._v(this._s(this.$i18n("pkgmgr", "loading")))])])
        }), [function() {
            var e = this.$createElement,
                t = this._self._c || e;
            return t("div", {
                staticClass: "loading-icon"
            }, [t("i", {
                staticClass: "loading-icon-inner"
            }, [t("i", {
                staticClass: "loading-icon-center"
            })])])
        }], !1, null, null, null).exports);

    function k(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var x = s({
        name: "NotificationLeft",
        components: {
            LeftTab: C,
            TipLoadingIndicator: A
        },
        data: function() {
            return {
                isActiveInsightSet: !1,
                isEmailSet: !1,
                isMobileSet: !1,
                supportMib: "no" !== _D("support_mib"),
                loaded: !1
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    k(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"])),
        watch: {
            activeCategory: function(e) {
                "notification" !== e || this.supportMib || this.$store.dispatch("TipModule/changeActiveTab", "1"), "notification" !== e || this.loaded || this.loadSettings()
            }
        },
        methods: {
            loadSettings: function() {
                var e = this;
                synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    method: "request",
                    version: 1,
                    compound: {
                        params: [{
                            api: "SYNO.ActiveInsight.Package",
                            method: "get_status",
                            version: 1
                        }, {
                            api: "SYNO.Core.Notification.Mail.Conf",
                            method: "get",
                            version: 1
                        }, {
                            api: "SYNO.Core.Notification.Push.Mobile",
                            method: "list",
                            version: 1
                        }]
                    }
                }).then((function(t) {
                    e.loaded = !0, t.has_fail || (e.isActiveInsightSet = "disabled" !== SYNO.API.Response.GetValByAPI(t, "SYNO.ActiveInsight.Package", "get_status").status, e.isEmailSet = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Notification.Mail.Conf", "get").enable_mail, e.isMobileSet = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Notification.Push.Mobile", "list").list.length > 0)
                })).catch((function() {
                    e.loaded = !0
                }))
            },
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e)
            },
            onClickActiveInsight: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.SynologyAccount.Main"
                })
            },
            onClickEmail: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Notification.Main",
                    tab: "mailSettingTab"
                })
            },
            onClickMobile: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Notification.Main",
                    tab: "pushSettingTab"
                })
            }
        }
    }, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-tabs", {
            attrs: {
                "syno-id": "notification-left-tabs-0",
                "active-tab-key": e.activeTab,
                "has-fbar": !1
            },
            on: {
                change: e.onTabChange
            }
        }, [e.supportMib ? n("v-tab-pane", {
            attrs: {
                "syno-id": "notification-left-tab-pane-0",
                "tab-key": "0",
                tab: e.$i18n("helpbrowser", "active_insight_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "active_insight_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/tutorial/Service_Application",
                "is-set": e.isActiveInsightSet,
                "button-action": e.onClickActiveInsight,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isActiveInsightSet ? n("v-form-item", {
                        attrs: {
                            label: e.$i18n("helpbrowser", "active_insight_login_portal") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [n("a", {
                        staticClass: "link-style",
                        attrs: {
                            href: "https://insight.synology.com/",
                            target: "_blank"
                        }
                    }, [e._v("https://insight.synology.com/")])]) : e._e()]
                },
                proxy: !0
            }], null, !1, 2247409183)
        })], 1) : e._e(), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "notification-left-tab-pane-1",
                "tab-key": "1",
                tab: e.$i18n("helpbrowser", "email_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "email_desc"),
                "is-set": e.isEmailSet,
                "button-action": e.onClickEmail,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isEmailSet ? n("v-form-item", {
                        staticClass: "tip-form-item configured",
                        attrs: {
                            label: e.$i18n("common", "status") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.$i18n("personal_settings", "set")) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "notification-left-tab-pane-2",
                "tab-key": "2",
                tab: e.$i18n("helpbrowser", "mobile_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "mobile_desc"),
                "is-set": e.isMobileSet,
                "button-action": e.onClickMobile,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isMobileSet ? n("v-form-item", {
                        staticClass: "tip-form-item configured",
                        attrs: {
                            label: e.$i18n("common", "status") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.$i18n("personal_settings", "set")) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }])
        })], 1)], 1)
    }), [], !1, null, null, null).exports;

    function N(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function P(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var D, E = {
            name: "RightTab",
            props: {
                imgSrc: {
                    type: String,
                    default: ""
                },
                videoSrc: {
                    type: String,
                    default: ""
                },
                category: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    baseURL: SYNO.SDS.Config.FnMap["SYNO.SDS.HelpBrowser.Application"].config.jsBaseURL,
                    is2x: SYNO.SDS.UIFeatures.test("isRetina"),
                    playedList: {},
                    isVideoStopped: !0
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        P(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)("TipModule", ["activeCategory"]), Object(o.mapState)(["online", "onlineURL"]), {
                imgStyle: function() {
                    if (this.imgSrc && this.category === this.activeCategory) {
                        var e = this.is2x ? "2x" : "1x";
                        return {
                            backgroundImage: "url(./".concat(this.baseURL, "/images/").concat(e, "/").concat(this.imgSrc, ".png)")
                        }
                    }
                    return {}
                },
                fullVideoSrc: function() {
                    return this.videoSrc ? this.is2x && this.online ? "".concat(this.onlineURL, "getTipsMedia/DSM/").concat(this.videoSrc, ".mp4") : "./".concat(this.baseURL, "/videos/").concat(this.videoSrc, ".mp4") : null
                },
                tip: function() {
                    return {
                        disabled: !(this.videoSrc && this.isVideoStopped),
                        content: this.$i18n("helpbrowser", "click_to_replay")
                    }
                }
            }),
            watch: {
                fullVideoSrc: (D = function(e) {
                    return function() {
                        var t = this,
                            n = arguments;
                        return new Promise((function(i, o) {
                            var r = e.apply(t, n);

                            function a(e) {
                                N(r, i, o, a, s, "next", e)
                            }

                            function s(e) {
                                N(r, i, o, a, s, "throw", e)
                            }
                            a(void 0)
                        }))
                    }
                }(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$nextTick();
                            case 2:
                                this.play();
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return D.apply(this, arguments)
                }),
                activeCategory: function() {
                    this.play()
                }
            },
            methods: {
                replay: function() {
                    var e = this.$refs.video;
                    e && e.play()
                },
                play: function() {
                    if (this.fullVideoSrc && this.category === this.activeCategory) {
                        var e = this.$refs.video,
                            t = this.$refs.source;
                        e && t && (e.pause(), e.load(), this.playedList[this.fullVideoSrc] ? e.play() : (setTimeout((function() {
                            e.play()
                        }), 1e3), this.playedList[this.fullVideoSrc] = !0))
                    }
                },
                onVideoEnded: function() {
                    this.isVideoStopped = !0
                },
                onVideoPlay: function() {
                    this.isVideoStopped = !1
                },
                onError: function() {
                    this.fullVideoSrc && this.$store.dispatch("updateOnlineInfo", {
                        online: !1
                    })
                }
            }
        },
        $ = (n(19), s(E, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                staticClass: "tip-right"
            }, [n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.imgSrc,
                    expression: "imgSrc"
                }],
                staticClass: "tip-img",
                style: e.imgStyle
            }), e._v(" "), n("video", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.videoSrc,
                    expression: "videoSrc"
                }, {
                    name: "tooltip",
                    rawName: "v-tooltip",
                    value: e.tip,
                    expression: "tip"
                }],
                ref: "video",
                staticClass: "tip-video",
                on: {
                    click: e.replay,
                    ended: e.onVideoEnded,
                    play: e.onVideoPlay
                }
            }, [n("source", {
                ref: "source",
                attrs: {
                    type: "video/mp4",
                    src: e.fullVideoSrc
                },
                on: {
                    error: e.onError
                }
            })])])
        }), [], !1, null, null, null).exports);

    function R(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var j = s({
            name: "NotificationRight",
            components: {
                RightTab: $
            },
            props: {
                category: {
                    type: String,
                    default: ""
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        R(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"]), {
                imgSrc: function() {
                    switch (this.activeTab) {
                        case "0":
                            return "img_tutorial_active_insight";
                        case "1":
                            return "img_tutorial_notification";
                        case "2":
                            return "img_tutorial_notification_mobile";
                        default:
                            return null
                    }
                },
                videoSrc: function() {
                    return null
                }
            })
        }, (function() {
            var e = this.$createElement;
            return (this._self._c || e)("right-tab", {
                attrs: {
                    "img-src": this.imgSrc,
                    "video-src": this.videoSrc,
                    category: this.category
                }
            })
        }), [], !1, null, null, null).exports,
        M = {
            name: "TipPkg",
            props: {
                name: {
                    type: String,
                    required: !0
                },
                hasMobile: {
                    type: Boolean,
                    default: !1
                },
                iconCls: {
                    type: String,
                    required: !0
                }
            }
        },
        Y = (n(20), s(M, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                staticClass: "tip-pkg"
            }, [n("div", {
                class: "tip-pkg-icon " + e.iconCls
            }), e._v(" "), n("div", {
                staticClass: "tip-pkg-text-wrapper"
            }, [n("div", {
                staticClass: "tip-pkg-text"
            }, [e._v(e._s(e.name))]), e._v(" "), n("div", {
                staticClass: "tip-pkg-desc"
            }, [e._v("\n            " + e._s(e.hasMobile ? e.$i18n("helpbrowser", "dsm_package_with_mobile") : e.$i18n("helpbrowser", "dsm_package_without_mobile")) + "\n        ")])])])
        }), [], !1, null, null, null).exports);

    function I(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var L = s({
        name: "DataProtectLeft",
        components: {
            LeftTab: C,
            TipPkg: Y
        },
        data: function() {
            return {
                isAdmin: _S("is_admin")
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    I(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"])),
        methods: {
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e)
            },
            openDrive: function() {
                this.openPackageCenter("SynologyDrive")
            },
            openPhotos: function() {
                this.openPackageCenter("SynologyPhotos")
            },
            openCloudSync: function() {
                this.openPackageCenter("CloudSync")
            },
            openPackageCenter: function(e) {
                SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                    action: "open",
                    packages: [e]
                })
            }
        }
    }, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-tabs", {
            attrs: {
                "syno-id": "backup-left-tabs-0",
                "active-tab-key": e.activeTab,
                "has-fbar": !1
            },
            on: {
                change: e.onTabChange
            }
        }, [n("v-tab-pane", {
            attrs: {
                "syno-id": "backup-left-tab-pane-0",
                "tab-key": "0",
                tab: e.$i18n("helpbrowser", "backup_pc")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "backup_pc_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/tutorial/Collaboration/How_to_sync_files_between_Synology_NAS_and_your_computer_using_Drive_desktop",
                "is-set": !0,
                "button-set-text": e.$i18n("helpbrowser", "goto"),
                "button-action": e.openDrive,
                "is-button-visible": e.isAdmin
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helpbrowser", "drive"),
                            "icon-cls": "Drive",
                            "has-mobile": ""
                        }
                    })]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "backup-left-tab-pane-1",
                "tab-key": "1",
                tab: e.$i18n("helpbrowser", "backup_mobile")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "backup_mobile_desc"),
                "more-info-url": "https://synology.com/knowledgebase/DSM/help/SynologyPhotos/photos_desc",
                "is-set": !0,
                "button-set-text": e.$i18n("helpbrowser", "goto"),
                "button-action": e.openPhotos,
                "is-button-visible": e.isAdmin
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helpbrowser", "photos"),
                            "icon-cls": "photos",
                            "has-mobile": ""
                        }
                    })]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "backup-left-tab-pane-2",
                "tab-key": "2",
                tab: e.$i18n("helpbrowser", "backup_public_cloud")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "backup_public_cloud_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/help/CloudSync/cloudsync",
                "is-set": !0,
                "button-set-text": e.$i18n("helpbrowser", "goto"),
                "button-action": e.openCloudSync,
                "is-button-visible": e.isAdmin
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helpbrowser", "cloudsync"),
                            "icon-cls": "CloudSync"
                        }
                    })]
                },
                proxy: !0
            }])
        })], 1)], 1)
    }), [], !1, null, null, null).exports;

    function H(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var F = s({
        name: "BackupRight",
        components: {
            RightTab: $
        },
        props: {
            category: {
                type: String,
                default: ""
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    H(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"]), {
            imgSrc: function() {
                switch (this.activeTab) {
                    case "0":
                        return "img_tutorial_drive";
                    case "1":
                        return "img_tutorial_photo";
                    case "2":
                        return "img_tutorial_cloudsync";
                    default:
                        return null
                }
            },
            videoSrc: function() {
                return null
            }
        })
    }, (function() {
        var e = this.$createElement;
        return (this._self._c || e)("right-tab", {
            attrs: {
                "img-src": this.imgSrc,
                "video-src": this.videoSrc,
                category: this.category
            }
        })
    }), [], !1, null, null, null).exports;

    function B(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var U = s({
        name: "DataProtectLeft",
        components: {
            LeftTab: C,
            TipPkg: Y
        },
        data: function() {
            return {
                supportSR: !1,
                loaded: !1
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    B(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"])),
        watch: {
            activeCategory: function(e) {
                "data_protect" !== e || this.loaded || this.loadSettings()
            }
        },
        methods: {
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e)
            },
            openHyperBackup: function() {
                this.openPackageCenter("HyperBackup")
            },
            openSnapshotReplication: function() {
                this.openPackageCenter("SnapshotReplication")
            },
            openPackageCenter: function(e) {
                SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                    action: "open",
                    packages: [e]
                })
            },
            loadSettings: function() {
                var e = this;
                synowebapi.promises.request({
                    api: "SYNO.Core.Package.Server",
                    method: "list",
                    version: 2
                }).then((function(t) {
                    e.loaded = !0, e.supportSR = t.packages.some((function(e) {
                        return "SnapshotReplication" === e.package
                    })) || t.beta_packages.some((function(e) {
                        return "SnapshotReplication" === e.package
                    }))
                }))
            }
        }
    }, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-tabs", {
            attrs: {
                "syno-id": "data_protect-left-tabs-0",
                "active-tab-key": e.activeTab,
                "has-fbar": !1
            },
            on: {
                change: e.onTabChange
            }
        }, [n("v-tab-pane", {
            attrs: {
                "syno-id": "data_protect-left-tab-pane-0",
                "tab-key": "0",
                tab: e.$i18n("helpbrowser", "protect_data_hyper_backup")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "protect_data_hyper_backup_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/help/HyperBackup/BackupApp_desc",
                "is-set": !0,
                "button-set-text": e.$i18n("helpbrowser", "goto"),
                "button-action": e.openHyperBackup
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helpbrowser", "hyperbackup"),
                            "icon-cls": "HyperBackup"
                        }
                    })]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "data_protect-left-tab-pane-1",
                "tab-key": "1",
                tab: e.$i18n("helpbrowser", "protect_data_snapshot"),
                hidden: !e.supportSR
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "protect_data_snapshot_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/help/SnapshotReplication/data_protection_mgr",
                "is-set": !0,
                "button-set-text": e.$i18n("helpbrowser", "goto"),
                "button-action": e.openSnapshotReplication
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helpbrowser", "sr"),
                            "icon-cls": "SnapshotReplication"
                        }
                    })]
                },
                proxy: !0
            }])
        })], 1)], 1)
    }), [], !1, null, null, null).exports;

    function V(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var z = s({
        name: "DataProtectRight",
        components: {
            RightTab: $
        },
        props: {
            category: {
                type: String,
                default: ""
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    V(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"]), {
            imgSrc: function() {
                var e = null;
                switch (this.activeTab) {
                    case "0":
                        e = "img_tutorial_hyper_backup";
                        break;
                    case "1":
                        e = "img_tutorial_snapshot_replication"
                }
                return e
            }
        })
    }, (function() {
        var e = this.$createElement;
        return (this._self._c || e)("right-tab", {
            attrs: {
                "img-src": this.imgSrc,
                category: this.category
            }
        })
    }), [], !1, null, null, null).exports;

    function G(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var q = s({
        name: "ExternalAccessLeft",
        components: {
            LeftTab: C,
            TipLoadingIndicator: A
        },
        data: function() {
            return {
                isDDNSSet: !1,
                isQuickConnectSet: !1,
                quickconnectURL: "",
                quickconnectAlias: "",
                loaded: !1
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    G(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"]), {
            quickconnectDesc2: function() {
                return String.format(this.$i18n("helpbrowser", "quickconnect_desc2"), _D("upnpmodelname"))
            }
        }),
        watch: {
            activeCategory: function(e) {
                "external_access" !== e || this.loaded || this.loadSettings()
            }
        },
        methods: {
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e)
            },
            onClickQuickConnect: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                    tab: "SYNO.SDS.AdminCenter.PublicAccess.QuickConnectTab"
                })
            },
            onClickDDNS: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                    tab: "ddnstab"
                })
            },
            loadSettings: function() {
                var e = this;
                synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    method: "request",
                    version: 1,
                    compound: {
                        params: [{
                            api: "SYNO.Core.QuickConnect",
                            method: "get",
                            version: 2
                        }, {
                            api: "SYNO.Core.DDNS.Record",
                            method: "list",
                            version: 1
                        }]
                    }
                }).then((function(t) {
                    if (e.loaded = !0, !t.has_fail) {
                        var n = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.QuickConnect", "get");
                        e.isQuickConnectSet = n.enabled, e.isQuickConnectSet && (e.quickconnectURL = "".concat(n.server_alias, ".").concat(n.domain), e.quickconnectAlias = n.server_alias), e.isDDNSSet = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.DDNS.Record", "list").records.length > 0
                    }
                })).catch((function() {
                    e.loaded = !0
                }))
            }
        }
    }, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-tabs", {
            attrs: {
                "syno-id": "external_access-left-tabs-0",
                "active-tab-key": e.activeTab,
                "has-fbar": !1
            },
            on: {
                change: e.onTabChange
            }
        }, [n("v-tab-pane", {
            attrs: {
                "syno-id": "external_access-left-tab-pane-0",
                "tab-key": "0",
                tab: e.$i18n("helpbrowser", "quickconnect_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "quickconnect_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/tutorial/Network/What_are_the_differences_between_QuickConnect_and_DDNS",
                "is-set": e.isQuickConnectSet,
                "button-action": e.onClickQuickConnect,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isQuickConnectSet ? n("v-form-item", {
                        style: {
                            marginTop: "12px"
                        },
                        attrs: {
                            "hide-label": "",
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.quickconnectDesc2) + "\n                    ")]) : e._e(), e._v(" "), e.isQuickConnectSet ? n("v-form-item", {
                        staticClass: "blue-link selectabletext",
                        style: {
                            marginTop: "8px"
                        },
                        attrs: {
                            label: e.$i18n("welcome", "with_web_browsers") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.quickconnectURL) + "\n                    ")]) : e._e(), e._v(" "), e.isQuickConnectSet ? n("v-form-item", {
                        staticClass: "blue-link selectabletext",
                        style: {
                            marginBottom: "4px"
                        },
                        attrs: {
                            label: e.$i18n("welcome", "with_mobile_apps") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.quickconnectAlias) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "external_access-left-tab-pane-1",
                "tab-key": "1",
                tab: e.$i18n("helpbrowser", "ddns_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "ddns_desc"),
                "more-info-url": "https://www.synology.com/knowledgebase/DSM/help/DSM/AdminCenter/connection_ddns",
                "is-set": e.isDDNSSet,
                "button-action": e.onClickDDNS,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isDDNSSet ? n("v-form-item", {
                        staticClass: "tip-form-item configured",
                        attrs: {
                            label: e.$i18n("common", "status") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.$i18n("personal_settings", "set")) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }])
        })], 1)], 1)
    }), [], !1, null, null, null).exports;

    function W(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var Q = s({
        name: "ExternalAccessRight",
        components: {
            RightTab: $
        },
        props: {
            category: {
                type: String,
                default: ""
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    W(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"]), {
            imgSrc: function() {
                switch (this.activeTab) {
                    case "0":
                        return "img_tutorial_quickconnect";
                    case "1":
                        return "img_tutorial_ddns";
                    default:
                        return null
                }
            },
            videoSrc: function() {
                return null
            }
        })
    }, (function() {
        var e = this.$createElement;
        return (this._self._c || e)("right-tab", {
            attrs: {
                "img-src": this.imgSrc,
                "video-src": this.videoSrc,
                category: this.category
            }
        })
    }), [], !1, null, null, null).exports;

    function X(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var Z = s({
        name: "SecurityLeft",
        components: {
            TipPkg: Y,
            LeftTab: C,
            TipLoadingIndicator: A
        },
        data: function() {
            return {
                is2FASet: !1,
                isFirewallSet: !1,
                isSecurityScanSet: !1,
                isAdmin: _S("is_admin"),
                loaded: !1
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    X(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"])),
        watch: {
            activeCategory: function(e) {
                "security" !== e || this.loaded || this.loadSettings()
            }
        },
        methods: {
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e)
            },
            loadSettings: function() {
                var e = this,
                    t = [{
                        api: "SYNO.Core.NormalUser",
                        method: "get",
                        version: 1
                    }, {
                        api: "SYNO.API.Auth.Type",
                        method: "get",
                        version: 1,
                        params: {
                            account: _S("user")
                        }
                    }];
                _S("is_admin") && (t = t.concat([{
                    api: "SYNO.Core.Security.Firewall",
                    method: "get",
                    version: 1
                }, {
                    api: "SYNO.Core.SecurityScan.Conf",
                    method: "first_get",
                    version: 1
                }])), synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    method: "request",
                    version: 1,
                    compound: {
                        params: t
                    }
                }).then((function(t) {
                    if (e.loaded = !0, !t.has_fail) {
                        var n = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.NormalUser", "get").OTP_enable,
                            i = SYNO.API.Response.GetValByAPI(t, "SYNO.API.Auth.Type", "get"),
                            o = i.some((function(e) {
                                return "authenticator" === e.type
                            })),
                            r = i.some((function(e) {
                                return "fido" === e.type
                            }));
                        if (e.is2FASet = n || o || r, e.isFirewallSet = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Security.Firewall", "get").enable_firewall, _S("is_admin")) {
                            var a = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.SecurityScan.Conf", "first_get");
                            e.isSecurityScanSet = !a.firstLogAnalyzer && !a.firstScan
                        }
                    }
                })).catch((function() {
                    e.loaded = !0
                }))
            },
            onClickFirewall: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Security.Main",
                    tab: "FirewallTab"
                })
            },
            onClick2FA: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.App.PersonalSettings.Instance")
            },
            onClickSecScan: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.SecurityScan.Instance")
            }
        }
    }, (function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-tabs", {
            attrs: {
                "syno-id": "security-left-tabs-0",
                "active-tab-key": e.activeTab,
                "has-fbar": !1
            },
            on: {
                change: e.onTabChange
            }
        }, [n("v-tab-pane", {
            attrs: {
                "syno-id": "security-left-tab-pane-0",
                "tab-key": "0",
                tab: e.$i18n("helpbrowser", "2fa_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "2fa_desc"),
                "is-set": e.is2FASet,
                "button-action": e.onClick2FA,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.is2FASet ? n("v-form-item", {
                        staticClass: "tip-form-item configured",
                        attrs: {
                            label: e.$i18n("common", "status") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.$i18n("personal_settings", "set")) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }])
        })], 1), e._v(" "), e.isAdmin ? n("v-tab-pane", {
            attrs: {
                "syno-id": "security-left-tab-pane-1",
                "tab-key": "1",
                tab: e.$i18n("helpbrowser", "firewall_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "firewall_desc"),
                "is-set": e.isFirewallSet,
                "button-action": e.onClickFirewall,
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "middle",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isFirewallSet ? n("v-form-item", {
                        staticClass: "tip-form-item configured",
                        attrs: {
                            label: e.$i18n("common", "status") + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v("\n                        " + e._s(e.$i18n("personal_settings", "set")) + "\n                    ")]) : e._e()]
                },
                proxy: !0
            }], null, !1, 4283164350)
        })], 1) : e._e(), e._v(" "), e.isAdmin ? n("v-tab-pane", {
            attrs: {
                "syno-id": "security-left-tab-pane-2",
                "tab-key": "2",
                tab: e.$i18n("helpbrowser", "scan_title")
            }
        }, [n("left-tab", {
            attrs: {
                desc: e.$i18n("helpbrowser", "scan_desc"),
                "is-set": e.isSecurityScanSet,
                "button-action": e.onClickSecScan,
                "button-text": e.$i18n("helpbrowser", "goto"),
                loaded: e.loaded
            },
            scopedSlots: e._u([{
                key: "before",
                fn: function() {
                    return [e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.loaded ? n("tip-pkg", {
                        attrs: {
                            name: e.$i18n("helptoc", "securityscan"),
                            "icon-cls": "SecurityAdvisor"
                        }
                    }) : e._e()]
                },
                proxy: !0
            }], null, !1, 901117457)
        })], 1) : e._e()], 1)
    }), [], !1, null, null, null).exports;

    function K(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var J = s({
            name: "SecurityRight",
            components: {
                RightTab: $
            },
            props: {
                category: {
                    type: String,
                    default: ""
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        K(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)("TipModule", ["pages", "activeTab"]), {
                imgSrc: function() {
                    switch (this.activeTab) {
                        case "0":
                            return "img_tutorial_signin";
                        case "1":
                            return "img_tutorial_firewall";
                        case "2":
                            return "img_tutorial_security";
                        default:
                            return null
                    }
                },
                videoSrc: function() {
                    return null
                }
            })
        }, (function() {
            var e = this.$createElement;
            return (this._self._c || e)("right-tab", {
                attrs: {
                    "img-src": this.imgSrc,
                    "video-src": this.videoSrc,
                    category: this.category
                }
            })
        }), [], !1, null, null, null).exports,
        ee = {
            name: "TipExpandableCard",
            props: {
                title: {
                    type: String,
                    default: ""
                },
                collapsed: {
                    type: Boolean,
                    required: !0
                },
                buttonText: {
                    type: String,
                    default: ""
                },
                buttonAction: {
                    type: Function,
                    default: function() {}
                },
                buttonStyle: {
                    type: String,
                    default: "grey"
                }
            },
            computed: {
                collapseBtnCls: function() {
                    return ["card-collapse-btn", {
                        expanded: !this.collapsed
                    }]
                }
            },
            methods: {
                toggle: function(e) {
                    e && e.stopPropagation && e.stopPropagation(), this.$emit("toggled", !this.collapsed)
                }
            }
        };
    n(21);

    function te(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var ne = {
        name: "SharedFolderLeft",
        components: {
            TipExpandableCard: s(ee, (function() {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", {
                    staticClass: "tip-expandable-card"
                }, [n("div", {
                    staticClass: "card-tbar",
                    on: {
                        click: e.toggle
                    }
                }, [n("div", {
                    staticClass: "card-tbar-title"
                }, [e._v(e._s(e.title))]), e._v(" "), n("v-button", {
                    class: e.collapseBtnCls,
                    attrs: {
                        "syno-id": "components-expandable-card-button-0",
                        type: "styleless"
                    },
                    on: {
                        click: e.toggle
                    }
                })], 1), e._v(" "), n("v-slide-up-down", {
                    attrs: {
                        expand: !e.collapsed,
                        "syno-id": "expand-card-slide-updown"
                    }
                }, [n("div", {
                    staticClass: "inner-wrap"
                }, [e._t("default"), e._v(" "), n("v-button", {
                    staticClass: "tip-btn",
                    attrs: {
                        "syno-id": "components-expandable-card-button-1",
                        color: e.buttonStyle
                    },
                    on: {
                        click: e.buttonAction
                    }
                }, [e._v("\n                " + e._s(e.buttonText || e.$i18n("helpbrowser", "goto")) + "\n            ")])], 2)])], 1)
            }), [], !1, null, null, null).exports,
            TipPkg: Y,
            LeftTab: C,
            TipLoadingIndicator: A
        },
        data: function() {
            return {
                isAdmin: _S("is_admin"),
                isSMBEnabled: !1,
                isAFPEnabled: !1,
                macSMB: "",
                macAFP: "",
                winSMB: "",
                loaded: !1,
                fileActive: !1,
                afpActive: !1
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = null != arguments[t] ? Object(arguments[t]) : {},
                    i = Object.keys(n);
                "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                    return Object.getOwnPropertyDescriptor(n, e).enumerable
                })))), i.forEach((function(t) {
                    te(e, t, n[t])
                }))
            }
            return e
        }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"])),
        watch: {
            activeCategory: function(e) {
                "shared_folder" === e && !this.loade && _S("is_admin") && this.loadSettings()
            }
        },
        methods: {
            onTabChange: function(e) {
                this.$store.dispatch("TipModule/changeActiveTab", e), this.$store.dispatch("TipModule/changeActiveBlock", ""), this.fileActive = !1, this.afpActive = !1
            },
            openSharedFolder: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Share.Main"
                })
            },
            openSMB: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.FileService.Main",
                    tab: "win"
                })
            },
            openAFP: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.FileService.Main",
                    tab: "afp"
                })
            },
            openFileStation: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance")
            },
            onCollapseStateChange: function(e, t) {
                var n;
                switch (e) {
                    case "file":
                        t = !t;
                    case "share":
                        n = "fileActive";
                        break;
                    case "afp":
                        t = !t;
                    case "smb":
                        n = "afpActive"
                }
                this[n] = t, this.$store.dispatch("TipModule/changeActiveBlock", t ? n.replace("Active", "") : "")
            },
            isAppEnabled: function(e) {
                return SYNO.SDS.StatusNotifier.isAppEnabled(e)
            },
            loadSettings: function() {
                var e = this;
                synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    method: "request",
                    version: 1,
                    compound: {
                        params: [{
                            api: "SYNO.Core.FileServ.SMB",
                            method: "get",
                            version: 3
                        }, {
                            api: "SYNO.Core.FileServ.AFP",
                            method: "get",
                            version: 1
                        }, {
                            api: "SYNO.Core.Network",
                            method: "get",
                            version: 1
                        }]
                    }
                }).then((function(t) {
                    if (e.loaded = !0, !t.has_fail) {
                        e.isSMBEnabled = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.FileServ.SMB", "get").enable_samba, e.isAFPEnabled = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.FileServ.AFP", "get").enable_afp;
                        var n = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Network", "get").server_name;
                        e.isSMBEnabled && (e.winSMB = "\\\\".concat(n), e.macSMB = "smb://".concat(n)), e.isAFPEnabled && (e.macAFP = "afp://".concat(n, ".local"))
                    }
                }))
            }
        }
    };
    n(22);

    function ie(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function oe(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var re = {
            name: "TipPage",
            components: {
                NotificationLeft: x,
                NotificationRight: j,
                BackupLeft: L,
                BackupRight: F,
                DataProtectLeft: U,
                DataProtectRight: z,
                ExternalAccessLeft: q,
                ExternalAccessRight: Q,
                SecurityLeft: Z,
                SecurityRight: J,
                SharedFolderLeft: s(ne, (function() {
                    var e = this,
                        t = e.$createElement,
                        n = e._self._c || t;
                    return n("v-tabs", {
                        attrs: {
                            "syno-id": "shared_folder-left-tabs-0",
                            "active-tab-key": e.activeTab,
                            "has-fbar": !1
                        },
                        on: {
                            change: e.onTabChange
                        }
                    }, [n("v-tab-pane", {
                        attrs: {
                            "syno-id": "shared_folder-left-tab-pane-0",
                            "tab-key": "0",
                            tab: e.$i18n("helpbrowser", "file_management")
                        }
                    }, [e.isAdmin ? [n("div", {
                        staticClass: "tip-expandable-cards-wrapper"
                    }, [n("tip-expandable-card", {
                        ref: "share",
                        attrs: {
                            title: e.$i18n("helpbrowser", "file_management_create_share"),
                            collapsed: e.fileActive,
                            "button-action": e.openSharedFolder,
                            "button-style": "blue",
                            "button-text": e.$i18n("common", "create")
                        },
                        on: {
                            toggled: function(t) {
                                return e.onCollapseStateChange("share", t)
                            }
                        }
                    }, [n("div", {
                        staticClass: "desc"
                    }, [e._v(e._s(e.$i18n("helpbrowser", "file_management_create_share_desc")))])]), e._v(" "), n("tip-expandable-card", {
                        ref: "file",
                        attrs: {
                            title: e.$i18n("helpbrowser", "file_management_file_station"),
                            collapsed: !e.fileActive,
                            "button-action": e.openFileStation
                        },
                        on: {
                            toggled: function(t) {
                                return e.onCollapseStateChange("file", t)
                            }
                        }
                    }, [n("tip-pkg", {
                        attrs: {
                            name: "File Station",
                            "icon-cls": "FileStation"
                        }
                    }), e._v(" "), n("div", {
                        staticClass: "desc"
                    }, [e._v("\n                            " + e._s(e.$i18n("helpbrowser", "file_management_file_station_desc")) + "\n                            "), n("a", {
                        staticClass: "more-info",
                        attrs: {
                            href: "https://www.synology.com/knowledgebase/DSM/help/FileStation/FileBrowser_desc",
                            target: "_blank"
                        }
                    }, [e._v(e._s(e.$i18n("welcome", "know_more")))])])], 1)], 1)] : [n("left-tab", {
                        attrs: {
                            desc: e.$i18n("helpbrowser", "file_management_file_station"),
                            "more-info-url": "https://www.synology.com/knowledgebase/DSM/help/FileStation/FileBrowser_desc",
                            "is-set": !0,
                            "button-set-text": e.$i18n("helpbrowser", "goto"),
                            "button-action": e.openFileStation,
                            "is-button-visible": e.isAppEnabled("SYNO.SDS.App.FileStation3.Instance")
                        },
                        scopedSlots: e._u([{
                            key: "before",
                            fn: function() {
                                return [n("tip-pkg", {
                                    attrs: {
                                        name: "File Station",
                                        "icon-cls": "FileStation"
                                    }
                                })]
                            },
                            proxy: !0
                        }])
                    })]], 2), e._v(" "), e.isAdmin ? n("v-tab-pane", {
                        attrs: {
                            "syno-id": "shared_folder-left-tab-pane-1",
                            "tab-key": "1",
                            tab: e.$i18n("helpbrowser", "direct_access")
                        }
                    }, [n("div", {
                        staticClass: "tip-expandable-cards-wrapper"
                    }, [n("tip-expandable-card", {
                        ref: "smb",
                        attrs: {
                            title: e.$i18n("helpbrowser", "direct_access_smb"),
                            collapsed: e.afpActive,
                            "button-action": e.openSMB
                        },
                        on: {
                            toggled: function(t) {
                                return e.onCollapseStateChange("smb", t)
                            }
                        }
                    }, [n("div", {
                        staticClass: "desc"
                    }, [e._v(e._s(e.$i18n("helpbrowser", "direct_access_smb_afp")))]), e._v(" "), e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isSMBEnabled ? [n("v-form", {
                        style: {
                            paddingTop: "4px",
                            paddingBottom: "4px",
                            marginBottom: "6px"
                        },
                        attrs: {
                            "syno-id": "shared_folder-left-form-0"
                        }
                    }, [n("v-form-item", {
                        staticClass: "blue-link selectabletext",
                        attrs: {
                            label: e.$i18n("network", "share_access_prompt_pc") + " (" + e.$i18n("network", "windows_explorer") + ")" + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v(e._s(e.winSMB))]), e._v(" "), n("v-form-item", {
                        staticClass: "blue-link selectabletext",
                        attrs: {
                            label: e.$i18n("network", "share_access_prompt_mac") + " (" + e.$i18n("network", "mac_finder") + ")" + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v(e._s(e.macSMB))])], 1)] : e._e()], 2), e._v(" "), n("tip-expandable-card", {
                        ref: "afp",
                        attrs: {
                            title: e.$i18n("helpbrowser", "direct_access_afp"),
                            collapsed: !e.afpActive,
                            "button-action": e.openAFP
                        },
                        on: {
                            toggled: function(t) {
                                return e.onCollapseStateChange("afp", t)
                            }
                        }
                    }, [n("div", {
                        staticClass: "desc"
                    }, [e._v(e._s(e.$i18n("helpbrowser", "direct_access_smb_afp")))]), e._v(" "), e.loaded ? e._e() : n("tip-loading-indicator"), e._v(" "), e.isAFPEnabled ? [n("v-form", {
                        style: {
                            paddingTop: "4px",
                            paddingBottom: "4px",
                            marginBottom: "6px"
                        },
                        attrs: {
                            "syno-id": "shared_folder-left-form-1"
                        }
                    }, [n("v-form-item", {
                        staticClass: "blue-link selectabletext",
                        attrs: {
                            label: e.$i18n("network", "share_access_prompt_mac") + " (" + e.$i18n("network", "mac_finder") + ")" + e.$i18n("common", "colon"),
                            textonly: ""
                        }
                    }, [e._v(e._s(e.macAFP))])], 1)] : e._e()], 2)], 1)]) : e._e()], 1)
                }), [], !1, null, null, null).exports,
                SharedFolderRight: s({
                    name: "SharedFolderRight",
                    components: {
                        RightTab: $
                    },
                    props: {
                        category: {
                            type: String,
                            default: ""
                        }
                    },
                    data: function() {
                        return {
                            isMac: /Macintosh/.test(navigator.userAgent)
                        }
                    },
                    computed: function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? Object(arguments[t]) : {},
                                i = Object.keys(n);
                            "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                                return Object.getOwnPropertyDescriptor(n, e).enumerable
                            })))), i.forEach((function(t) {
                                ie(e, t, n[t])
                            }))
                        }
                        return e
                    }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeBlock"]), {
                        imgSrc: function() {
                            var e = this.activeTab,
                                t = this.activeBlock;
                            switch (e) {
                                case "0":
                                    return "file" === t ? "img_tutorial_file_2" : "img_tutorial_file_1";
                                case "1":
                                    return this.isMac || "afp" === t ? "img_tutorial_smb_mac" : "img_tutorial_smb_windows";
                                default:
                                    return null
                            }
                        },
                        videoSrc: function() {
                            return null
                        }
                    })
                }, (function() {
                    var e = this.$createElement;
                    return (this._self._c || e)("right-tab", {
                        attrs: {
                            "img-src": this.imgSrc,
                            "video-src": this.videoSrc,
                            category: this.category
                        }
                    })
                }), [], !1, null, null, null).exports
            },
            props: {
                winHeight: {
                    type: Number,
                    default: 530
                }
            },
            data: function() {
                return {
                    isOutOfMaxHeight: !1,
                    leftCls: {
                        left: !0,
                        wider: "nor" === _S("lang")
                    }
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        oe(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)("TipModule", ["pages", "activeTab", "activeCategory"]), Object(o.mapGetters)("TipModule", ["index", "activeTitle", "activeDesc"]), {
                hasPrevPage: function() {
                    return this.index > 0
                },
                hasNextPage: function() {
                    return this.index < this.pages.length - 1
                },
                cls: function() {
                    return ["tip-page", {
                        "is-big-window": this.isOutOfMaxHeight
                    }]
                }
            }),
            watch: {
                winHeight: function(e) {
                    this.isOutOfMaxHeight = e > 666
                }
            },
            methods: {
                clearCategory: function() {
                    this.$store.dispatch("TipModule/clearCategory")
                },
                gotoPrevCategory: function() {
                    this.$store.dispatch("TipModule/gotoPrevCategory")
                },
                gotoNextCategory: function() {
                    this.$store.dispatch("TipModule/gotoNextCategory")
                },
                getPageCls: function(e) {
                    return [{
                        active: this.activeCategory === e
                    }, {
                        inactive: this.activeCategory !== e
                    }]
                }
            }
        },
        ae = (n(23), s(re, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                class: e.cls
            }, [n("div", {
                staticClass: "tip-page-inner-wrapper"
            }, [n("v-panel", {
                class: e.leftCls,
                attrs: {
                    "syno-id": "pages-tip-page-panel-0",
                    "has-tbar": !0,
                    "has-fbar": !1,
                    "use-default-t-bar": !1
                }
            }, [n("template", {
                slot: "tbar"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "pages-tip-page-button-0",
                    icon: "help-home-btn"
                },
                on: {
                    click: e.clearCategory
                }
            }), e._v(" "), n("div", {
                staticClass: "tbar-right"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "pages-tip-page-button-1",
                    type: "styleless",
                    icon: "prev",
                    disabled: !e.hasPrevPage
                },
                on: {
                    click: e.gotoPrevCategory
                }
            }), e._v(" "), n("span", {
                staticClass: "paging"
            }, [e._v(e._s(e.index + 1 + "/" + e.pages.length))]), e._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "pages-tip-page-button-2",
                    type: "styleless",
                    icon: "next",
                    disabled: !e.hasNextPage
                },
                on: {
                    click: e.gotoNextCategory
                }
            })], 1)], 1), e._v(" "), n("template", {
                slot: "body"
            }, [n("div", {
                staticClass: "tip-page-title"
            }, [e._v(e._s(e.activeTitle))]), e._v(" "), n("div", {
                staticClass: "tip-page-desc"
            }, [e._v(e._s(e.activeDesc))]), e._v(" "), n("div", {
                staticClass: "tip-page-detail"
            }, [n("notification-left", {
                class: e.getPageCls("notification")
            }), e._v(" "), n("backup-left", {
                class: e.getPageCls("backup")
            }), e._v(" "), n("data-protect-left", {
                class: e.getPageCls("data_protect")
            }), e._v(" "), n("external-access-left", {
                class: e.getPageCls("external_access")
            }), e._v(" "), n("security-left", {
                class: e.getPageCls("security")
            }), e._v(" "), n("shared-folder-left", {
                class: e.getPageCls("shared_folder")
            })], 1)])], 2), e._v(" "), n("div", {
                staticClass: "right"
            }, [n("notification-right", {
                class: e.getPageCls("notification"),
                attrs: {
                    category: "notification"
                }
            }), e._v(" "), n("backup-right", {
                class: e.getPageCls("backup"),
                attrs: {
                    category: "backup"
                }
            }), e._v(" "), n("data-protect-right", {
                class: e.getPageCls("data_protect"),
                attrs: {
                    category: "data_protect"
                }
            }), e._v(" "), n("external-access-right", {
                class: e.getPageCls("external_access"),
                attrs: {
                    category: "external_access"
                }
            }), e._v(" "), n("security-right", {
                class: e.getPageCls("security"),
                attrs: {
                    category: "security"
                }
            }), e._v(" "), n("shared-folder-right", {
                class: e.getPageCls("shared_folder"),
                attrs: {
                    category: "shared_folder"
                }
            })], 1)], 1)])
        }), [], !1, null, null, null).exports);

    function se(e, t) {
        var n, i = e.base,
            o = e.id;
        if (Ext.isString(i)) {
            if ("/" === i.substr(0, 1)) return o = o.split("-")[0], n = SYNO.SDS.Config.FnMap[o], t && Ext.isObject(n) && n.config && n.config.helpSection ? n.config.helpSection : Ext.isObject(n) && n.config && n.config.jsBaseURL ? n.config.jsBaseURL + "/help/" : "3rdparty/" + (i = i.split("/")[3]) + "/help/";
            if (Ext.isString(o)) {
                if (o = o.split(":")[0], n = SYNO.SDS.Config.FnMap[o], t && Ext.isObject(n) && n.config && n.config.helpSection) return n.config.helpSection;
                if (Ext.isObject(n) && n.config && n.config.jsBaseURL) return n.config.jsBaseURL + "/" + i + "/"
            }
        }
        return "webman/help/"
    }
    var ce = {
        NORMAL: 100,
        LARGE: 125,
        EXTRA_LARGE: 150
    };

    function le(e) {
        return ce[e] || 100
    }

    function pe(e, t, n) {
        if (e) {
            var i = "font=".concat(le(t)),
                o = "font=".concat(le(n)),
                r = "/".concat(le(t), "/"),
                a = "/".concat(le(n), "/");
            return e.path = e.path.replace(i, o).replace(r, a), e.real_path && (e.real_path = e.real_path.replace(r, a)), e
        }
    }

    function ue(e, t) {
        var n, i, o = ["SYNO.SDS.App.PersonalSettings.Instance", "SYNO.SDS.AdminCenter.Application", "SYNO.SDS.PkgManApp.Instance", "SYNO.SDS.App.FileStation3.Instance", "SYNO.SDS.StorageManager.Instance", "SYNO.SDS.iSCSI.Application", "SYNO.SDS.HA.Instance", "SYNO.SDS.AHA.Instance", "SYNO.SDS.DisasterRecovery.Application", "SYNO.SDS.Backup.Application", "SYNO.SDS.ResourceMonitor.Instance", "SYNO.SDS.StorageReport.Application", "SYNO.SDS.LogCenter.Instance", "SYNO.SDS.LogCenter.BuiltIn", "SYNO.SDS.ACEEditor.Application", "SYNO.SDS.SecurityScan.Instance", "SYNO.SDS.SupportForm.Application", "SYNO.DSMMobile", "SYNO.SDS.HotkeyMgr.Instance", "SYNO.SDS.App.AboutFakeApp"];
        if (e && t) return n = o.indexOf(e.id), i = o.indexOf(t.id), parseInt(n - i, 10)
    }

    function de(e, t) {
        return e.text > t.text ? 1 : e.text < t.text ? -1 : 0
    }

    function fe(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function he(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, o) {
                var r = e.apply(t, n);

                function a(e) {
                    fe(r, i, o, a, s, "next", e)
                }

                function s(e) {
                    fe(r, i, o, a, s, "throw", e)
                }
                a(void 0)
            }))
        }
    }

    function ge(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var be, Se, me, ve = _S("productversion"),
        _e = {
            id: "SYNO.SDS.App.AboutFakeApp",
            link: "Home/legal_info.html",
            section: "DSM",
            text: _T("helptoc", "about"),
            topic: "Home/legal_info.html",
            version: ve,
            children: [{
                id: "SYNO.SDS.App.AboutFakeApp:Home/about.html",
                leaf: !0,
                link: "Home/about.html",
                section: "DSM",
                text: _T("helptoc", "synology_legal"),
                version: ve,
                topic: "Home/about.html"
            }, {
                id: "SYNO.SDS.App.AboutFakeApp:Home/license.html",
                leaf: !0,
                link: "Home/license.html",
                section: "DSM",
                text: _T("helptoc", "open_source_license"),
                version: ve,
                topic: "Home/license.html"
            }, {
                id: "SYNO.SDS.App.AboutFakeApp:Home/codec_licenses.html",
                leaf: !0,
                link: "Home/codec_licenses.html",
                section: "DSM",
                text: _T("helptoc", "codec_licenses"),
                version: ve,
                topic: "Home/codec_licenses.html"
            }]
        },
        ye = {
            name: "Help",
            components: {
                HelpSearchField: g
            },
            mixins: [i],
            data: function() {
                var e = /synology_([A-Za-z0-9]+)_([A-Za-z0-9\+]+)/.exec(_D("unique"));
                return {
                    curPlatform: null === e ? null : e[1].toLowerCase(),
                    curModel: null === e ? null : e[2].replace(/\+/g, "p").toLowerCase(),
                    isLoading: !1,
                    helpTree: [],
                    collapsed: !1,
                    dragging: !1,
                    isNotRewriteApp: !_S("rewriteApp")
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        ge(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)("HelpModule", ["currentIndex", "history", "fontSize", "currentTopic", "defaultTopic", "treeLoaded"]), Object(o.mapState)(["online"]), Object(o.mapGetters)("HelpModule", ["helpURL", "fontRatio"]), {
                currentPage: function() {
                    return this.history[this.currentIndex]
                },
                hasPrevPage: function() {
                    return this.currentIndex > 0
                },
                hasNextPage: function() {
                    return this.currentIndex >= 0 && this.currentIndex < this.history.length - 1
                },
                styleObj: function() {
                    return this.collapsed ? {
                        width: "34px",
                        minWidth: "0px"
                    } : {}
                },
                iframeShimCls: function() {
                    return ["iframe-shim", {
                        dragging: this.dragging
                    }]
                },
                helpTreeWrapCls: function() {
                    return ["help-tree-wrap", {
                        dragging: this.dragging
                    }, {
                        collapsed: this.collapsed
                    }]
                }
            }),
            watch: {
                helpURL: function(e) {
                    var t = this.$refs.tree,
                        n = t.getSelectedNodes()[0];
                    (!n || this.currentPage && n.id !== this.currentPage.id) && t.selectNode(this.currentPage.id, !0)
                },
                currentTopic: function(e) {
                    null !== e && this.treeLoaded && this.$refs.tree.selectNode(e, !0)
                },
                fontSize: function() {
                    this.changeFrameFontSize()
                },
                online: function(e, t) {
                    e !== t && !1 === e && this.reloadHelp()
                }
            },
            created: function() {
                this.$options.helpLoadingDefer = Promise.resolve()
            },
            mounted: function() {
                this.loadHelps(!1).catch(SYNO.Debug.warn), this.hookIframeMessage(), SYNO.SDS.StatusNotifier.on("jsconfigLoaded", this.reloadHelp.bind(this))
            },
            beforeDestroy: function() {
                this.handelMsgPost && window.removeEventListener("message", this.handelMsgPost, !1)
            },
            methods: {
                onError: function() {
                    this.$store.dispatch("updateOnlineInfo", {
                        online: !1
                    })
                },
                reloadHelp: (me = he(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.currentPage && (t = this.currentPage.id, this.$store.dispatch("HelpModule/changeTopic", t)), this.$store.dispatch("HelpModule/updateTreeLoaded", !1), this.$store.dispatch("HelpModule/clearHistory"), e.prev = 3, e.next = 6, this.loadHelps(!this.online);
                            case 6:
                                e.next = 11;
                                break;
                            case 8:
                                e.prev = 8, e.t0 = e.catch(3), SYNO.Debug.warn(e.t0);
                            case 11:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [3, 8]
                    ])
                }))), function() {
                    return me.apply(this, arguments)
                }),
                isFontSizeMatched: function(e) {
                    return this.fontSize === e
                },
                onResizeStart: function() {
                    this.setDragging(!0)
                },
                onResizeStop: function() {
                    this.setDragging(!1)
                },
                setDragging: function(e) {
                    this.dragging = e
                },
                goPrev: function() {
                    this.$store.dispatch("HelpModule/goPrevPage")
                },
                goNext: function() {
                    this.$store.dispatch("HelpModule/goNextPage")
                },
                goHome: function() {
                    this.$store.dispatch("changeType", "tip")
                },
                onNodeSelected: function(e) {
                    var t = e[0];
                    if (!this.currentPage || this.currentPage.id !== t.id) {
                        var n = Object.create(t);
                        this.$store.dispatch("HelpModule/pushHistory", {
                            historyObj: n
                        })
                    }
                },
                appendLegalNode: function(e) {
                    e && e[0] && (e[0].leaf && (e[0].leaf = !1, e[0].children = []), e[0].children.push(_e))
                },
                loadHelps: (Se = he(regeneratorRuntime.mark((function e(t) {
                    var n, i, o, r, a = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = _S("rewriteApp") ? Ext.urlDecode(window.location.search.substr(1)).launchParam : null, i = /topic=([^&]+)/, o = n ? i.exec(n) : null, r = o ? decodeURIComponent(o[1]).split(":")[0] : null, e.prev = 1, e.next = 4, this.$options.helpLoadingDefer;
                            case 4:
                                e.next = 9;
                                break;
                            case 6:
                                e.prev = 6, e.t0 = e.catch(1), SYNO.Debug.warn(e.t0);
                            case 9:
                                return e.abrupt("return", this.$options.helpLoadingDefer = synowebapi.promises.request({
                                    api: "SYNO.Core.Help",
                                    method: "get_tree",
                                    version: 1,
                                    params: {
                                        offline: t,
                                        unique: _D("unique"),
                                        dsm: _S("productversion") + "-" + _S("version"),
                                        treeNode: JSON.stringify(l()),
                                        lang: SYNO.SDS.Utils.getHelpLanguage(),
                                        node: "source",
                                        topic: r
                                    }
                                }).then((function(e) {
                                    if (!e) throw "no response";
                                    var t = e.tree,
                                        n = e.online,
                                        i = e.onlineURL;
                                    a.$store.dispatch("updateOnlineInfo", {
                                        online: n,
                                        onlineURL: i
                                    }), _S("rewriteApp") ? a.appendLegalNode(t) : t.forEach((function(e, t) {
                                        e.expanded = !0, e.selectable = !1, e.children.sort(0 === t ? ue : de), e.children.forEach((function(e) {
                                            e.icon = SYNO.SDS.Utils.GetAppIcon(e.id, "TreeIcon"), e.iconSize = SYNO.SDS.UIFeatures.IconSizeManager.TreeIcon
                                        }))
                                    })), a.helpTree = t, a.$store.dispatch("HelpModule/updateTreeLoaded", !0)
                                })).then((function() {
                                    var e = a.$refs.tree,
                                        t = a.currentTopic || a.defaultTopic,
                                        n = e.getSelectedNodes()[0];
                                    if (!n || n.id !== t) return e.selectNode(t, !0);
                                    a.$store.dispatch("HelpModule/pushHistory", {
                                        historyObj: Object.create(n)
                                    })
                                })));
                            case 10:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [1, 6]
                    ])
                }))), function(e) {
                    return Se.apply(this, arguments)
                }),
                hookIframeMessage: function() {
                    var e = this,
                        t = function(t) {
                            if (e.online && e.currentPage) {
                                var n = /^help_url:(.*)/.exec(t.data);
                                if (n && 2 === n.length) return void e.$store.dispatch("HelpModule/updateRealPath", n[1])
                            }
                            var i = /^goto_help:(.*)/.exec(t.data);
                            i && 2 === i.length && e.$refs.tree.selectNode(i[1], !0)
                        };
                    window.addEventListener && window.addEventListener("message", t, !1), e.handelMsgPost = t
                },
                toggleFontSize: function() {
                    switch (this.fontSize) {
                        case "NORMAL":
                            this.changeFontSize("LARGE");
                            break;
                        case "LARGE":
                            this.changeFontSize("EXTRA_LARGE");
                            break;
                        case "EXTRA_LARGE":
                            this.changeFontSize("NORMAL")
                    }
                },
                changeFontSize: function(e) {
                    this.$store.dispatch("HelpModule/changeFontSize", e)
                },
                onSearchItemSelect: function(e) {
                    e && this.$refs.tree.selectNode(e)
                },
                toggleTree: function() {
                    this.collapsed = !this.collapsed
                },
                getFrameBody: function() {
                    return this.$refs.frame.contentDocument.getElementsByTagName("body")[0]
                },
                changeFrameFontSize: function() {
                    if (!this.online) {
                        var e = this.getFrameBody();
                        e.style.fontSize = "".concat(this.fontRatio, "%"), e.fleXcroll && e.fleXcroll.updateScrollBars()
                    }
                },
                onLoad: (be = he(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.online) {
                                    e.next = 6;
                                    break
                                }
                                return e.next = 3, SYNO.SDS.HelpBrowser.Utils.checkOnline();
                            case 3:
                                return !1 === e.sent && this.onError(), e.abrupt("return");
                            case 6:
                                this.changeFrameFontSize(), (t = this.getFrameBody()).classList.add("model-".concat(this.curModel)), t.classList.add("platform-".concat(this.curPlatform)), t.classList.add("os-".concat(SYNO.SDS.isNSM ? "srm" : "dsm"));
                            case 11:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return be.apply(this, arguments)
                })
            }
        };
    n(24);

    function we(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function Oe(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, o) {
                var r = e.apply(t, n);

                function a(e) {
                    we(r, i, o, a, s, "next", e)
                }

                function s(e) {
                    we(r, i, o, a, s, "throw", e)
                }
                a(void 0)
            }))
        }
    }

    function Ce(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var Te, Ae = {
            name: "HelpBrowser",
            components: {
                TipHome: w,
                Help: s(ye, (function() {
                    var e = this,
                        t = e.$createElement,
                        n = e._self._c || t;
                    return n("v-panel", {
                        staticClass: "help-content-wrap",
                        attrs: {
                            "syno-id": "pages-help-panel-0",
                            "has-tbar": !0,
                            "has-fbar": !1
                        }
                    }, [n("template", {
                        slot: "tbar"
                    }, [n("v-button", {
                        ref: "prevBtn",
                        attrs: {
                            "syno-id": "pages-help-button-0",
                            disabled: !e.hasPrevPage,
                            icon: "help-prev-btn group-icon"
                        },
                        on: {
                            click: e.goPrev
                        }
                    }), e._v(" "), n("v-button", {
                        ref: "nextBtn",
                        attrs: {
                            "syno-id": "pages-help-button-1",
                            disabled: !e.hasNextPage,
                            icon: "help-next-btn group-icon"
                        },
                        on: {
                            click: e.goNext
                        }
                    }), e._v(" "), e.isNotRewriteApp ? n("v-button", {
                        ref: "homeBtn",
                        attrs: {
                            "syno-id": "pages-help-button-2",
                            icon: "help-home-btn"
                        },
                        on: {
                            click: e.goHome
                        }
                    }) : e._e(), e._v(" "), n("v-button", {
                        ref: "fontSizeBtn",
                        attrs: {
                            "syno-id": "pages-help-button-3",
                            icon: "help-size-btn"
                        },
                        on: {
                            click: e.toggleFontSize
                        }
                    }), e._v(" "), n("help-search-field", {
                        on: {
                            itemselect: e.onSearchItemSelect
                        }
                    })], 1), e._v(" "), n("template", {
                        slot: "body"
                    }, [n("div", {
                        staticClass: "help-content"
                    }, [n("v-draggable-resizable", {
                        ref: "treeResizer",
                        class: e.helpTreeWrapCls,
                        style: e.styleObj,
                        attrs: {
                            "syno-id": "pages-help-draggable-resizable-0",
                            draggable: !1,
                            resizable: "",
                            w: 250,
                            handles: ["mr"],
                            z: 10,
                            "max-width": 500,
                            "min-width": e.collapsed ? 0 : 250,
                            active: !e.collapsed,
                            "on-resize-start": e.onResizeStart,
                            "prevent-deactivation": !0
                        },
                        on: {
                            resizestop: e.onResizeStop
                        }
                    }, [n("div", {
                        staticClass: "help-tree-tbar"
                    }, [n("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.collapsed,
                            expression: "!collapsed"
                        }],
                        staticClass: "help-tree-title",
                        on: {
                            click: e.toggleTree
                        }
                    }, [e._v(e._s(e.T("helpbrowser", "hbtoc")))]), e._v(" "), n("v-button", {
                        attrs: {
                            "syno-id": "pages-help-button-4",
                            icon: e.collapsed ? "catalog-collapsed help-catalog-btn" : "catalog-expanded help-catalog-btn",
                            type: "styleless"
                        },
                        on: {
                            click: e.toggleTree
                        }
                    })], 1), e._v(" "), n("v-tree-panel", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !e.collapsed,
                            expression: "!collapsed"
                        }],
                        ref: "tree",
                        staticClass: "help-tree",
                        attrs: {
                            "syno-id": "syno-help-tree",
                            data: e.helpTree,
                            "params-info": {
                                title: "text",
                                children: "children",
                                id: "id"
                            },
                            "expand-on-select": !0
                        },
                        on: {
                            selected: e.onNodeSelected
                        }
                    })], 1), e._v(" "), n("iframe", {
                        ref: "frame",
                        staticClass: "help-iframe",
                        attrs: {
                            src: e.helpURL
                        },
                        on: {
                            load: e.onLoad,
                            onerror: e.onError
                        }
                    }), e._v(" "), n("div", {
                        class: e.iframeShimCls
                    })], 1)])], 2)
                }), [], !1, null, null, null).exports,
                TipPage: ae
            },
            mixins: [i],
            props: {},
            data: function() {
                return {
                    winWidth: 995,
                    winHeight: 500,
                    needShowTippy: !1
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        Ce(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)(["activeType", "online"]), Object(o.mapState)("TipModule", ["activeCategory"]), {
                isTipHomeActive: function() {
                    return "tip" === this.activeType && null === this.activeCategory
                },
                isHelpActive: function() {
                    return "help" === this.activeType
                },
                isRewriteApp: function() {
                    return !!_S("rewriteApp")
                },
                isTipPageActive: function() {
                    return "tip" === this.activeType && null !== this.activeCategory
                }
            }),
            watch: {
                online: function(e, t) {
                    e && !this.detectTask && this.createDetectNetworkTask()
                }
            },
            mounted: function() {
                var e = this;
                this.$watch("$refs.appWindow.currentHeight", this.onHeightChange.bind(this), {
                    immediate: !0
                }), this.$watch("$refs.appWindow.currentWidth", this.onWidthChange.bind(this), {
                    immediate: !0
                }), this.$nextTick((function() {
                    if (e.$refs.appInstance) {
                        var t = e.$refs.appInstance;
                        e.needShowTippy = !0 !== t.getUserSettings("hasBeenLaunched"), e.needShowTippy && t.setUserSettings("hasBeenLaunched", !0)
                    }
                }))
            },
            beforeDestroy: function() {
                this.isDestroying = !0, this.$store.dispatch("reset")
            },
            methods: {
                onHeightChange: function(e, t) {
                    this.winHeight = +e
                },
                onWidthChange: function(e, t) {
                    this.winWidth = +e
                },
                handleParam: (Te = Oe(regeneratorRuntime.mark((function e(t) {
                    var n, i = arguments;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = i.length > 1 && void 0 !== i[1] ? i[1] : {}, this.$store.dispatch("HelpModule/clearTopic"), this.$store.dispatch("HelpModule/clearAnchor"), e.next = 5, this.$nextTick();
                            case 5:
                                n.type && this.$store.dispatch("changeType", n.type), n.topic && (this.$store.dispatch("changeType", "help"), this.$store.dispatch("HelpModule/changeTopic", n.topic), this.$store.dispatch("HelpModule/changeAnchor", n.anchor));
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return Te.apply(this, arguments)
                }),
                getClass: function(e) {
                    return ["content-page", {
                        active: this["is".concat(e, "Active")] || !1
                    }]
                },
                createDetectNetworkTask: function() {
                    var e = this;
                    !this.detectTask && this.online && (this.detectTask = setTimeout(Oe(regeneratorRuntime.mark((function t() {
                        var n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (!e.isDestroying) {
                                        t.next = 3;
                                        break
                                    }
                                    return e.detectTask = null, t.abrupt("return");
                                case 3:
                                    return t.next = 5, SYNO.SDS.HelpBrowser.Utils.checkOnline();
                                case 5:
                                    n = t.sent, e.detectTask = null, n ? e.createDetectNetworkTask() : e.$store.dispatch("updateOnlineInfo", {
                                        online: n
                                    });
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    }))), 2e4))
                }
            }
        },
        ke = (n(25), s(Ae, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-app-instance", {
                ref: "appInstance",
                attrs: {
                    "class-name": "SYNO.SDS.HelpBrowser.Application",
                    "syno-id": "helpbrowser"
                },
                on: {
                    openparamchanged: e.handleParam
                }
            }, [n("v-app-window", {
                ref: "appWindow",
                staticClass: "syno-help-browser",
                attrs: {
                    resizable: !e.isRewriteApp,
                    width: "1033",
                    height: "580",
                    "min-width": "1033",
                    "min-height": "560",
                    "show-help": !1,
                    maximized: e.isRewriteApp,
                    "syno-id": "helpbrowser-appwindow",
                    "window-name": "SYNO.SDS.HelpBrowser.AppWindow"
                }
            }, [n("v-panel", {
                staticClass: "syno-help-panel",
                attrs: {
                    "syno-id": "src-help-browser-panel-0",
                    "has-tbar": !1,
                    "has-fbar": !1
                }
            }, [n("template", {
                slot: "body"
            }, [n("TipHome", {
                class: e.getClass("TipHome"),
                attrs: {
                    "win-width": e.winWidth,
                    "win-height": e.winHeight,
                    "need-show-tippy": e.needShowTippy
                }
            }), e._v(" "), n("Help", {
                class: e.getClass("Help")
            }), e._v(" "), n("TipPage", {
                class: e.getClass("TipPage"),
                attrs: {
                    "win-height": e.winHeight
                }
            })], 1)], 2)], 1)], 1)
        }), [], !1, null, null, null).exports);

    function xe(e, t, n, i, o, r, a) {
        try {
            var s = e[r](a),
                c = s.value
        } catch (e) {
            return void n(e)
        }
        s.done ? t(c) : Promise.resolve(c).then(i, o)
    }

    function Ne(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var Pe, De = {
            data: function() {
                var e = SYNO.SDS.Config.FnMap["SYNO.SDS.HelpBrowser.Application"].config.jsBaseURL;
                return {
                    title: _T("helpbrowser", "desktop_tip_title"),
                    body: _T("helpbrowser", "desktop_tip_desc"),
                    activeDuration: 0,
                    btnColor: "blue",
                    btnText: _T("helpbrowser", "explore"),
                    onClose: function() {
                        var e = SYNO.SDS.Desktop.getMsgBox();
                        e.alert("", _T("helpbrowser", "go_tip_later")), e.getDialog().maskEl.hide()
                    },
                    videoSrc: "video_noti_rocket",
                    fullVideoSrc: "./".concat(e, "/videos/").concat("video_noti_rocket", ".mp4")
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        Ne(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)(["online"])),
            mounted: (Pe = function(e) {
                return function() {
                    var t = this,
                        n = arguments;
                    return new Promise((function(i, o) {
                        var r = e.apply(t, n);

                        function a(e) {
                            xe(r, i, o, a, s, "next", e)
                        }

                        function s(e) {
                            xe(r, i, o, a, s, "throw", e)
                        }
                        a(void 0)
                    }))
                }
            }(regeneratorRuntime.mark((function e() {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (!SYNO.SDS.UIFeatures.test("isRetina")) {
                                e.next = 5;
                                break
                            }
                            return e.next = 3, SYNO.SDS.HelpBrowser.Utils.checkOnline();
                        case 3:
                            e.sent && (this.fullVideoSrc = "".concat(SYNO.SDS.HelpBrowser.Utils.onlineURL, "getTipsMedia/DSM/").concat(this.videoSrc, ".mp4"));
                        case 5:
                            this.play();
                        case 6:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return Pe.apply(this, arguments)
            }),
            methods: {
                onClickExplore: function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                        type: "tip"
                    }), SYNO.SDS._SystemTrayMsgMgr.unregister(this.$refs.notification)
                },
                play: function() {
                    if (this.fullVideoSrc) {
                        var e = this.$refs.video,
                            t = this.$refs.source;
                        e && t && !t.getAttribute("src") && (t.setAttribute("src", this.fullVideoSrc), e.load(), e.play())
                    }
                }
            }
        },
        Ee = (n(26), s(De, (function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", [n("v-notification", {
                ref: "notification",
                attrs: {
                    "active-duration": e.activeDuration,
                    "on-close": e.onClose
                },
                scopedSlots: e._u([{
                    key: "wrapper",
                    fn: function() {
                        return [n("div", {
                            staticClass: "syno-quick-tour-tray-wrapper"
                        }, [n("div", {
                            staticClass: "syno-quick-tour-tray-icon"
                        }), e._v(" "), n("div", {
                            staticClass: "syno-quick-tour-tray-title"
                        }, [e._v(e._s(e.title))]), e._v(" "), n("div", {
                            staticClass: "syno-quick-tour-tray-body"
                        }, [e._v(e._s(e.body))]), e._v(" "), n("div", {
                            staticClass: "syno-quick-tour-tray-footer"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "syno-quick-tour-explore-btn",
                                suffix: e.btnColor
                            },
                            on: {
                                click: e.onClickExplore
                            }
                        }, [e._v("\n                        " + e._s(e.btnText) + "\n                    ")])], 1)])]
                    },
                    proxy: !0
                }])
            })], 1)
        }), [], !1, null, null, null).exports);

    function $e(e) {
        e.real_path && e.real_path !== e.path && (e.path = e.real_path)
    }
    var Re = {
            namespaced: !0,
            state: {
                history: [],
                currentIndex: -1,
                onlineURL: "https://help.synology.com/cgi/knowledgebase/",
                offlineHomeURL: "webman/help/".concat(SYNO.SDS.Utils.getHelpLanguage(), "/MainMenu/get_started.html"),
                homeId: "SYNO.SDS.App.PersonalSettings.Instance",
                homeLink: "MainMenu/get_started.html",
                fontSize: "NORMAL",
                treeLoaded: !1,
                defaultTopic: _S("rewiteApp") || "SYNO.SDS.App.PersonalSettings.Instance",
                currentTopic: null,
                currentAnchor: null
            },
            getters: {
                helpURL: function(e) {
                    var t = e.history[e.currentIndex];
                    return t ? t.path : ""
                },
                fontRatio: function(e) {
                    var t = e.fontSize;
                    return ce[t]
                }
            },
            mutations: {
                ADD_HISTORY: function(e, t) {
                    var n = e.currentIndex + 1;
                    e.history.splice(n, 0, t), e.currentIndex = n
                },
                GO_NEXT: function(e) {
                    if (e.currentIndex < e.history.length - 1) {
                        var t = e.currentIndex + 1;
                        $e(e.history[t]), e.currentIndex = t
                    }
                },
                GO_PREV: function(e) {
                    if (e.currentIndex > 0) {
                        var t = e.currentIndex - 1;
                        $e(e.history[t]), e.currentIndex = t
                    }
                },
                UPDATE_ONLINE_URL: function(e, t) {
                    e.onlineURL = "".concat(t, "cgi/knowledgebase/")
                },
                CHANGE_FONT_SIZE: function(e, t) {
                    e.fontSize = t
                },
                CHANGE_CURRENT_FONT_SIZE_PATH: function(e, t) {
                    var n = t.newSize,
                        i = t.oldSize;
                    pe(e.history[e.currentIndex], i, n)
                },
                CHANGE_ALL_FONT_SIZE_PATH: function(e, t) {
                    var n = t.newSize,
                        i = t.oldSize;
                    e.history.map((function(e) {
                        return pe(e, i, n)
                    }))
                },
                UPDATE_HELP_TREE_LOADED: function(e, t) {
                    e.treeLoaded = t
                },
                GOTO_TOPIC: function(e, t) {
                    e.currentTopic = t
                },
                CLEAR_TOPIC: function(e) {
                    e.currentTopic = null
                },
                GOTO_ANCHOR: function(e, t) {
                    e.currentAnchor = t
                },
                CLEAR_ANCHOR: function(e) {
                    e.currentAnchor = null
                },
                UPDATE_REAL_PATH: function(e, t) {
                    e.history[e.currentIndex].real_path = t
                },
                CLEAR_HISTORY: function(e) {
                    e.history = [], e.currentIndex = -1
                }
            },
            actions: {
                pushHistory: function(e, t) {
                    var n = e.commit,
                        i = e.state,
                        o = e.rootState,
                        r = t.historyObj,
                        a = Object.create(r),
                        s = a.id.split(":")[0],
                        c = i.currentAnchor ? "#".concat(i.currentAnchor) : "",
                        l = se(r, !0).replace("help/", "").replace("3rdparty/", "").replace("webman/", "").replace("/", "") || "dsm",
                        p = "dsm" === l ? _S("productversion") : (SYNO.SDS.Packages.getInfo(s) || {}).version || _S("productversion");
                    if (o.online) {
                        var u = {
                            action: "findHelpFile",
                            dsm: _S("productversion") + "-" + _S("version"),
                            version: p,
                            section: l,
                            lang: SYNO.SDS.Utils.getHelpLanguage(),
                            unique: _D("unique"),
                            link: r.link,
                            font: le(i.fontSize)
                        };
                        a.path = "".concat(i.onlineURL, "?").concat(Ext.urlEncode(u)).concat(c)
                    } else {
                        var d = {
                            version: p
                        };
                        a.path = "".concat(se(r, !1)).concat(SYNO.SDS.Utils.getHelpLanguage(), "/").concat(r.topic, "?").concat(Ext.urlEncode(d)).concat(c)
                    }
                    n("ADD_HISTORY", a)
                },
                updateRealPath: function(e, t) {
                    var n = e.commit,
                        i = e.state;
                    i.history[i.currentIndex] && n("UPDATE_REAL_PATH", t)
                },
                goPrevPage: function(e) {
                    (0, e.commit)("GO_PREV")
                },
                goNextPage: function(e) {
                    (0, e.commit)("GO_NEXT")
                },
                gotoHome: function(e) {
                    var t = e.state;
                    (0, e.dispatch)("pushHistory", {
                        historyObj: {
                            link: t.homeLink,
                            id: t.homeId,
                            topic: t.homeLink
                        }
                    })
                },
                changeFontSize: function(e, t) {
                    var n = e.commit,
                        i = e.state.fontSize;
                    if (!ce[t]) throw "Unknown Font Size";
                    n("CHANGE_FONT_SIZE", t), n("CHANGE_CURRENT_FONT_SIZE_PATH", {
                        oldSize: i,
                        newSize: t
                    }), n("CHANGE_ALL_FONT_SIZE_PATH", {
                        oldSize: i,
                        newSize: t
                    })
                },
                updateTreeLoaded: function(e, t) {
                    (0, e.commit)("UPDATE_HELP_TREE_LOADED", t)
                },
                changeTopic: function(e, t) {
                    var n = e.commit,
                        i = e.state;
                    n("GOTO_TOPIC", t = t || i.defaultTopic)
                },
                changeAnchor: function(e, t) {
                    (0, e.commit)("GOTO_ANCHOR", t = t || "")
                },
                reset: function(e) {
                    e.commit;
                    var t = e.dispatch;
                    t("updateTreeLoaded", !1), t("changeTopic", null), t("clearHistory"), t("changeFontSize", "NORMAL")
                },
                clearHistory: function(e) {
                    (0, e.commit)("CLEAR_HISTORY")
                },
                clearTopic: function(e) {
                    (0, e.commit)("CLEAR_TOPIC")
                },
                clearAnchor: function(e) {
                    (0, e.commit)("CLEAR_ANCHOR")
                }
            }
        },
        je = {
            notification: {
                title: _T("helpbrowser", "tip_notification_title"),
                desc: _T("helpbrowser", "tip_notification_desc"),
                key: "notification"
            },
            shared_folder: {
                title: _T("helpbrowser", "tip_sharedfolder_title"),
                desc: _T("helpbrowser", "tip_sharedfolder_desc"),
                key: "shared_folder"
            },
            backup: {
                title: _T("helpbrowser", "tip_backup_title"),
                desc: _T("helpbrowser", "tip_backup_desc"),
                key: "backup"
            },
            external_access: {
                title: _T("helpbrowser", "tip_externalaccess_title"),
                desc: _T("helpbrowser", "tip_externalaccess_desc"),
                key: "external_access"
            },
            security: {
                title: _T("helpbrowser", "tip_security_title"),
                desc: _T("helpbrowser", "tip_security_desc"),
                key: "security"
            },
            data_protect: {
                title: _T("helpbrowser", "tip_dataprotect_title"),
                desc: _T("helpbrowser", "tip_dataprotect_desc"),
                key: "data_protect"
            }
        },
        Me = je.notification,
        Ye = je.shared_folder,
        Ie = je.backup,
        Le = je.external_access,
        He = je.security,
        Fe = je.data_protect,
        Be = {
            namespaced: !0,
            state: {
                activeCategory: null,
                activeTab: "0",
                activeBlock: _S("is_admin") ? "share" : "file",
                pages: _S("is_admin") ? [Me, Le, He, Ye, Ie, Fe] : [Ye, Ie, He]
            },
            getters: {
                rows: function(e) {
                    for (var t = e.pages, n = [], i = 0; i < t.length; i += 3) n.push([t[i], t[i + 1], t[i + 2]]);
                    return n
                },
                index: function(e) {
                    var t = e.activeCategory;
                    return e.pages.indexOf(je[t])
                },
                activeTitle: function(e) {
                    var t = e.activeCategory;
                    return je[t] ? je[t].title : ""
                },
                activeDesc: function(e) {
                    var t = e.activeCategory;
                    return je[t] ? je[t].desc : ""
                },
                first: function(e) {
                    return e.pages[0]
                }
            },
            mutations: {
                CHANGE_ACTIVE_CATEGORY: function(e, t) {
                    e.activeCategory = t
                },
                CHANGE_ACTIVE_TAB: function(e, t) {
                    e.activeTab = t
                },
                CLEAR_ACTIVE_CATEGORY: function(e) {
                    e.activeCategory = null
                },
                CHANGE_ACTIVE_BLOCK: function(e, t) {
                    e.activeBlock = t
                }
            },
            actions: {
                changeActiveCategory: function(e, t) {
                    var n = e.commit,
                        i = e.state;
                    if (i.activeCategory !== t) {
                        if (!(i.pages.indexOf(je[t]) >= 0)) throw "No Such Category";
                        n("CHANGE_ACTIVE_CATEGORY", t), n("CHANGE_ACTIVE_TAB", "0")
                    }
                },
                changeActiveTab: function(e, t) {
                    (0, e.commit)("CHANGE_ACTIVE_TAB", t)
                },
                changeActiveBlock: function(e, t) {
                    (0, e.commit)("CHANGE_ACTIVE_BLOCK", t)
                },
                clearCategory: function(e) {
                    var t = e.commit;
                    t("CLEAR_ACTIVE_CATEGORY"), t("CHANGE_ACTIVE_TAB", "0")
                },
                gotoPrevCategory: function(e) {
                    var t = e.dispatch,
                        n = e.getters,
                        i = e.state,
                        o = n.index;
                    if (0 !== o) {
                        var r = o - 1;
                        t("changeActiveCategory", i.pages[r].key)
                    }
                },
                gotoNextCategory: function(e) {
                    var t = e.dispatch,
                        n = e.getters,
                        i = e.state,
                        o = n.index;
                    if (o !== i.pages.length - 1) {
                        var r = o + 1;
                        t("changeActiveCategory", i.pages[r].key)
                    }
                },
                reset: function(e) {
                    var t = e.commit;
                    t("CLEAR_ACTIVE_CATEGORY"), t("CHANGE_ACTIVE_TAB", "0"), t("CHANGE_ACTIVE_BLOCK", _S("is_admin") ? "share" : "file")
                }
            }
        },
        Ue = ["tip", "help"];
    var Ve = {
            changeType: function(e, t) {
                var n = e.commit;
                e.dispatch;
                if (!Ue.includes(t)) throw "Unrecognized type";
                n("CHANGE_ACTIVE_TYPE", t)
            },
            reset: function(e) {
                var t = e.dispatch;
                t("TipModule/reset"), t("HelpModule/reset")
            },
            updateOnlineInfo: function(e, t) {
                var n = e.commit;
                if (n("UPDATE_ONLINE_STAUTS", t.online), t.online) {
                    var i = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                        return e.replace("http:", "https:")
                    }(t.onlineURL);
                    n("UPDATE_ONLINE_URL", i), n("HelpModule/UPDATE_ONLINE_URL", i)
                }
            }
        },
        ze = new r.a.Store({
            state: {
                activeType: "tip",
                online: !1,
                onlineURL: "https://help.synology.com/"
            },
            mutations: {
                CHANGE_ACTIVE_TYPE: function(e, t) {
                    e.activeType = t
                },
                UPDATE_ONLINE_STAUTS: function(e, t) {
                    e.online = t
                },
                UPDATE_ONLINE_URL: function(e, t) {
                    e.onlineURL = t
                }
            },
            actions: Ve,
            modules: {
                HelpModule: Re,
                TipModule: Be
            },
            strict: !0
        });
    Ext.namespace("SYNO.SDS.HelpBrowser"), // @require: SYNO.SDS.HelpBrowser.Utils
/**
 * @class SYNO.SDS.HelpBrowser.Application
 * HelpBrowser application class
 *
 */    
        SYNO.SDS.HelpBrowser.Application = Vue.extend({
            components: {
                HelpBrowser: ke
            },
            template: "<HelpBrowser/>",
            store: ze
        }), // @require: SYNO.SDS.HelpBrowser.Utils
        SYNO.SDS.HelpBrowser.QuickTourTray = Vue.extend({
            components: {
                QuickTourTray: Ee
            },
            template: "<QuickTourTray/>",
            store: ze
        })
}]);
