! function(e) {
    var t = {};

    function r(n) {
        if (t[n]) return t[n].exports;
        var o = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports
    }
    r.m = e, r.c = t, r.d = function(e, t, n) {
        r.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.t = function(e, t) {
        if (1 & t && (e = r(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) r.d(n, o, function(t) {
                return e[t]
            }.bind(null, o));
        return n
    }, r.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return r.d(t, "a", t), t
    }, r.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, r.p = "", r(r.s = 27)
}({
    27: function(e, t) {
        function r(e, t, r, n, o, i, u) {
            try {
                var a = e[i](u),
                    c = a.value
            } catch (e) {
                return void r(e)
            }
            a.done ? t(c) : Promise.resolve(c).then(n, o)
        }

        function n(e, t) {
            for (var r = 0; r < t.length; r++) {
                var n = t[r];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
            }
        }
        Ext.namespace("SYNO.SDS.HelpBrowser"); // @define SYNO.SDS.HelpBrowser.Utils
        var o = function() {
            function e() {
                ! function(e, t) {
                    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
                }(this, e)
            }
            var t, o, i, u, a;
            return t = e, o = null, i = [{
                key: "checkOnline",
                value: (u = regeneratorRuntime.mark((function e() {
                    var t, r, n;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this._req) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", this._req);
                            case 2:
                                if (t = this._online_url) {
                                    e.next = 16;
                                    break
                                }
                                return e.prev = 4, e.next = 7, synowebapi.promises.request({
                                    api: "SYNO.Core.Help",
                                    version: 1,
                                    method: "get_online_help_url"
                                });
                            case 7:
                                r = e.sent, this._online_url = r.online_help_url, t = this._online_url, e.next = 16;
                                break;
                            case 12:
                                e.prev = 12, e.t0 = e.catch(4), t = "http://help.synology.com/", SYNO.Debug.error("get online help url failed");
                            case 16:
                                return t = t.replace("http:", "https:"), e.next = 19, this.createScript(t);
                            case 19:
                                return n = e.sent, this._req = null, e.abrupt("return", n);
                            case 22:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [4, 12]
                    ])
                })), a = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, o) {
                        var i = u.apply(e, t);

                        function a(e) {
                            r(i, n, o, a, c, "next", e)
                        }

                        function c(e) {
                            r(i, n, o, a, c, "throw", e)
                        }
                        a(void 0)
                    }))
                }, function() {
                    return a.apply(this, arguments)
                })
            }, {
                key: "createScript",
                value: function(e) {
                    var t = this;
                    return e += "js/knowledgebase/checkNetWorkConnection.js", this._req = new Promise((function(r) {
                        if (!e) throw "url required";
                        var n = document.createElement("script");
                        n.type = "text/javascript", n.onload = function() {
                            document.body.removeChild(n), r(!0)
                        }, n.onerror = function() {
                            document.body.removeChild(n), r(!1)
                        }, n.src = "".concat(e, "?rand=").concat(Math.floor(1e3 * Math.random() + 1)), t._detectEl = n, document.body.appendChild(n)
                    })), this._req
                }
            }, {
                key: "onlineURL",
                get: function() {
                    return this._online_url.replace("http:", "https:")
                }
            }], o && n(t.prototype, o), i && n(t, i), e
        }();
        SYNO.SDS.HelpBrowser.Utils = o
    }
});