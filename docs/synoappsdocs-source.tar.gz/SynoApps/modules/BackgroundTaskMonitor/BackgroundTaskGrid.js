/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.FileTaskMonitor");
/**
 * @class SYNO.SDS.FileTaskMonitor.BKMonitorGrid
 * @extends SYNO.ux.GridPanel
 * FileTaskMonitor monitor grid class
 *
 */
SYNO.SDS.FileTaskMonitor.BKMonitorGrid = Ext.extend(SYNO.ux.GridPanel, {
    constructor: function(a) {
        if (!_S("standalone")) {
            this.BKToolbar = this.initToolbar()
        }
        this.gridCtxMenu = this.initCtxMenu(a.baseURL);
        this.fileds = ["cancelable", "id", "title", "progress", "processed_num", "processed_size", "total", "processing_path", "status"];
        SYNO.SDS.FileTaskMonitor.BKMonitorGrid.superclass.constructor.call(this, Ext.apply({
            enableHdMenu: false,
            autoExpandColumn: "status",
            store: new Ext.data.JsonStore({
                autoDestroy: true,
                idProperty: "id",
                fields: this.fileds
            }),
            colModel: this.initColumnModel(a.baseURL),
            sm: new Ext.grid.RowSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: this.onUpdateBtnStatus,
                        scope: this
                    }
                }
            }),
            listeners: {
                rowcontextmenu: {
                    scope: this,
                    fn: this.rowContextMenuHandle
                },
                rowclick: {
                    fn: function(b, d, c) {
                        if (c && d && !c.hasModifier()) {
                            b.getSelectionModel().selectRow(d)
                        }
                    }
                }
            },
            tbar: this.BKToolbar
        }, a));
        this.addClass("filemonitor-bkmonitor-grid")
    },
    initToolbar: function() {
        var a = new Ext.Toolbar({
            items: [{
                xtype: "syno_button",
                itemId: "gc_remove",
                text: _T("common", "remove"),
                handler: this.onClickCancels,
                scope: this,
                disabled: true
            }]
        });
        return a
    },
    onUpdateBtnStatus: function() {
        if (_S("standalone")) {
            return
        }
        var a = this.BKToolbar.get("gc_remove");
        var d = this.getSelectionModel();
        var c = d.getSelections();
        var b = true;
        Ext.each(c, function(e) {
            b = b && ("sds-progress-no-cancel" !== e.data.cancelable)
        }, this);
        if (c.length > 0 && b) {
            a.enable()
        } else {
            a.disable()
        }
    },
    initColumnModel: function(b) {
        var a = new Ext.grid.ColumnModel({
            columns: [{
                id: "status",
                header: _T("filetable", "filetable_file"),
                renderer: function(h, d, c, i, g, e) {
                    var f = Ext.util.Format.htmlEncode(c.data.title);
                    d.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(f) + '"';
                    return f
                }
            }, {
                header: _T("common", "progress"),
                width: 360,
                renderer: function(j, e, g, i, l, k) {
                    var f = g.data;
                    if ("NOT_STARTED" === f.status) {
                        return _T("background_task", "task_waiting")
                    } else {
                        if (f.progress > 0) {
                            var d = "";
                            if (f.total && 0 < f.total && (f.processed_num || f.processed_size)) {
                                if (Ext.isNumber(f.processed_size)) {
                                    d = "&nbsp;(" + Ext.util.Format.fileSize(f.processed_size || 0) + "/" + Ext.util.Format.fileSize(f.total) + ")"
                                } else {
                                    d = "&nbsp;(" + (f.processed_num || 0) + "/" + f.total + ")"
                                }
                            }
                            var c = g.data.progress * 100;
                            var h = new SYNO.SDS.Utils.ProgressBar({
                                barHeight: 6,
                                lineHeight: 16,
                                marginTop: 5,
                                fixed: false,
                                showExtraText: true,
                                showValueText: true
                            });
                            return h.fill(c.toFixed(1), d)
                        }
                    }
                    return _T("background_task", "task_processing")
                }
            }]
        });
        return a
    },
    initCtxMenu: function() {
        var a = new SYNO.ux.Menu({
            cls: "syno-sds-ctx-menu",
            items: [{
                itemId: "gc_remove",
                iconCls: "syno-sds-delete-icon",
                text: _T("common", "remove"),
                handler: this.onClickCancels,
                scope: this
            }]
        });
        this.addManagedComponent(a);
        return a
    },
    rowContextMenuHandle: function(b, h, d) {
        d.preventDefault();
        var f = b.getSelectionModel(),
            c, a = true;
        if (!f.isSelected(h)) {
            f.selectRow(h)
        }
        c = f.getSelections();
        Ext.each(c, function(e) {
            a = a && ("sds-progress-no-cancel" !== e.data.cancelable)
        }, this);
        if (false === a) {
            return
        }
        this.gridCtxMenu.showAt(d.getXY())
    },
    onClickCancel: function(b, e, d, c) {
        var a = SYNO.SDS.BackgroundTaskMgr.getTask(e.data.id);
        if (a) {
            a.cancel()
        }
        this.onRemove(e)
    },
    onClickCancels: function() {
        var b = this.getSelectionModel().getSelections();
        if (b.length < 1) {
            return
        }
        for (var a = 0; a < b.length; a++) {
            this.onClickCancel(this, b[a])
        }
    },
    localizeTpl: function(b) {
        for (var a = 0; a < b.length; a++) {
            b[a] = SYNO.SDS.UIString.GetLocalizedString(b[a])
        }
        return b
    },
    onAdd: function(b) {
        var a = this.getStore(),
            c = {};
        Ext.copyTo(c, b, this.fileds);
        c.title = b.title || b.id;
        if (!Ext.isArray(c.title)) {
            c.title = [c.title]
        }
        if (false === b.ajaxTaskConfig.cancelable) {
            c.cancelable = "sds-progress-no-cancel"
        } else {
            c.cancelable = "sds-progress-cancel"
        }
        c.progress = 0;
        c.title = String.format.apply(String, this.localizeTpl(c.title));
        a.add(new a.recordType(c, c.id))
    },
    onRemove: function(a) {
        this.getStore().remove(a)
    },
    onProgress: function(c, f, h, d, e) {
        var b = this.getStore(),
            g = b.getById(c.id);
        var a = this.fileds.slice();
        if (!g) {
            return
        }
        a.shift();
        if ("fail" === f || "cancel" === f) {
            this.onRemove(g)
        } else {
            if (h) {
                this.onRemove(g)
            } else {
                if (Ext.isNumber(d)) {
                    Ext.copyTo(g.data, e, a);
                    g.data.progress = d;
                    g.commit()
                }
            }
        }
    },
    initEvents: function() {
        var b, a;
        for (b in SYNO.SDS.BackgroundTaskMgr.tasks) {
            if (SYNO.SDS.BackgroundTaskMgr.tasks.hasOwnProperty(b)) {
                a = SYNO.SDS.BackgroundTaskMgr.getTask(b);
                if (a) {
                    this.onAdd(a)
                }
            }
        }
        this.mon(SYNO.SDS.BackgroundTaskMgr, "add", this.onAdd, this);
        this.mon(SYNO.SDS.BackgroundTaskMgr, "progress", this.onProgress, this);
        SYNO.SDS.FileTaskMonitor.BKMonitorGrid.superclass.initEvents.apply(this, arguments)
    }
});
