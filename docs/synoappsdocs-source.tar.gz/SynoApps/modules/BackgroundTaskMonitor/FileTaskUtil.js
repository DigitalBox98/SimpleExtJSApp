/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.FileTaskMonitor");
/**
 * @class SYNO.SDS.FileTaskMonitor.BasicTrayItem 
 * @extends SYNO.SDS.Tray.ArrowTray
 * FileTaskMonitor basic tray item class
 *
 */
SYNO.SDS.FileTaskMonitor.BasicTrayItem = Ext.extend(SYNO.SDS.Tray.ArrowTray, {
    panelAlign: "t-b",
    constructor: function(a) {
        this.appInstance = a.appInstance;
        SYNO.SDS.FileTaskMonitor.BasicTrayItem.superclass.constructor.call(this, Ext.apply({}, a));
        this.mon(this.panel.getStore(), "add", this.setPanelSize, this);
        this.mon(this.panel.getStore(), "remove", this.setPanelSize, this);
        this.mon(this.taskButton, "hide", this.hidePanel, this);
        this.mon(SYNO.SDS.StatusNotifier, "systemTrayNotifyMsg", this.hidePanel, this)
    },
    setPanelSize: function() {
        this.panel.setSize(304, this.panel.getStore().getCount() * 42 + 68);
        if (this.panel.getStore().getCount() === 0) {
            this.hidePanel.createDelegate(this).defer(200)
        }
    },
    initPanel: function() {
        this.panel = this.initPanelImpl();
        this.panel.el.anchorTo(this.taskButton.el, this.panelAlign, [6, 7]);
        return this.panel
    },
    initPanelImpl: function() {
        throw "not implmented"
    },
    onBeforeDestroy: function() {
        this.panel = null;
        SYNO.SDS.UploadTray.TrayItem.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onClick: function() {
        if (!this.taskButton.disabled) {
            if (this.panel.isVisible()) {
                this.hidePanel()
            } else {
                this.showPanel()
            }
        }
    },
    showPanel: function() {
        if (this.panel) {
            SYNO.SDS.StatusNotifier.fireEvent("taskBarPanelShow");
            this.panel.el.alignTo(this.taskButton.el, this.panelAlign, [6, 7]);
            this.panel.show()
        }
    },
    hidePanel: function() {
        if (this.panel) {
            this.panel.hide()
        }
    },
    setAnimIcon: function() {
        if (this.animIcon) {
            this.taskButton.setIconClass(this.animIcon)
        }
    },
    setStaticIcon: function() {
        if (this.staticIcon) {
            this.taskButton.setIconClass(this.staticIcon)
        }
    }
});
