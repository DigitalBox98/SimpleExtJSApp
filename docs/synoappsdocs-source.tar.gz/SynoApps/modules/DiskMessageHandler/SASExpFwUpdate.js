/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.App.SASExpFwUpdateApp");
/**
 * @class SYNO.SDS.App.SASExpFwUpdateApp.Instance
 * @extends SYNO.SDS.AppInstance
 * SASExpFwUpdateApp instance class
 *
 */
SYNO.SDS.App.SASExpFwUpdateApp.Instance = Ext.extend(SYNO.SDS.AppInstance, {
    initInstance: function(a) {
        if (!this.win) {
            this.win = new SYNO.SDS.App.SASExpFwUpdateApp.Window({
                appInstance: this
            });
            this.addInstance(this.win);
            this.win.setTitle(_T("update", "exp_fw_critical_update_title"))
        }
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Enclosure",
            method: _S("ha_running") ? "sha_exp_fw_update_list_get" : "exp_fw_update_list_get",
            version: 1,
            params: {},
            scope: this,
            callback: function(c, b) {
                if ((c) && (0 !== b.enclosures.length) && (0 !== b.update_sec) && (!b.is_firm_updating)) {
                    this.win.updateDesc(b.enclosures, b.update_sec, b.all_rollback_error);
                    if (true === this.win.hidden) {
                        this.win.show()
                    }
                }
            }
        });
        this.pollReg({
            webapi: {
                api: "SYNO.Storage.CGI.Enclosure",
                method: _S("ha_running") ? "sha_exp_fw_update_list_get" : "exp_fw_update_list_get",
                version: 1,
                params: {}
            },
            interval: 10,
            immediate: true,
            scope: this,
            status_callback: function(e, d, c, b) {
                if ((e) && (0 !== d.enclosures.length) && (0 !== d.update_sec) && (!d.is_firm_updating) && (d.need_notify)) {
                    this.win.updateDesc(d.enclosures, d.update_sec, d.all_rollback_error);
                    if (true === this.win.hidden) {
                        this.win.show()
                    }
                }
            }
        });
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Enclosure",
            method: _S("ha_running") ? "sha_exp_fw_update_status_get" : "exp_fw_update_status_get",
            version: 1,
            params: {},
            scope: this,
            callback: function(c, b) {
                if ((c) && (true !== b.finished)) {
                    SYNO.SDS.App.SASExpFwUpdateApp.SASFwUpdProgressBar.setBackgroudTask()
                }
            }
        })
    },
    onOpen: function(a) {
        this.initInstance(a)
    }
});
Ext.define("SYNO.SDS.App.SASExpFwUpdateApp.SASFwUpdProgressBar", {
    extend: "SYNO.SDS.ModalWindow",
    statics: {
        startFWUpdProgress: function(b, a) {
            var c = new SYNO.SDS.App.SASExpFwUpdateApp.SASFwUpdProgressBar({
                owner: b,
                updateMins: a
            });
            c.open()
        },
        setBackgroudTask: function() {
            SYNO.SDS.BackgroundTaskMgr.addWebAPITask({
                title: [_T("update", "updating") + ": " + _T("update", "exp_fw_critical_update_backgroud_desc")],
                query: {
                    api: "SYNO.Storage.CGI.Enclosure",
                    method: _S("ha_running") ? "sha_exp_fw_update_status_get" : "exp_fw_update_status_get",
                    version: 1,
                    cancelable: false,
                    params: {}
                }
            })
        }
    },
    constructor: function(a) {
        this.updateMins = a.updateMins;
        this.callParent([a])
    },
    onOpen: function() {
        this.callParent(arguments);
        this.hide(true);
        this.startPollingProgress()
    },
    startPollingProgress: function() {
        SYNO.SDS.Desktop.getMsgBox().show({
            buttons: false,
            progress: true,
            closable: false,
            minWidth: 480,
            progressText: ""
        });
        SYNO.SDS.App.SASExpFwUpdateApp.SASFwUpdProgressBar.setBackgroudTask();
        this.updatePollingId = this.pollReg({
            webapi: {
                api: "SYNO.Storage.CGI.Enclosure",
                method: _S("ha_running") ? "sha_exp_fw_update_status_get" : "exp_fw_update_status_get",
                version: 1,
                params: {}
            },
            interval: 5,
            immediate: true,
            scope: this,
            status_callback: function(f, e, d, c) {
                if (!f) {
                    this.stopPollingProgress();
                    SYNO.SDS.App.SASExpFWUpdFailApp.showAlertMsg(this);
                    return false
                }
                if (e.finished) {
                    this.stopPollingProgress();
                    return false
                } else {
                    var b = Math.floor(e.progress * 100);
                    var g = String.format('<b>{0}...<span class="syno-mb-progress-status">{1}&nbsp;&#37;</span></b>', _T("update", "updating"), b);
                    var a = String.format(_T("update", "exp_fw_updating_desc"), this.updateMins);
                    SYNO.SDS.Desktop.getMsgBox().updateProgress(e.progress, String.format('<div class="syno-enc-fw-upd-progress-message">{0}</div>', a), g, true);
                    SYNO.SDS.Desktop.getMsgBox().getDialog().progressStatus.removeClass("syno-mb-progress-status")
                }
            }
        })
    },
    stopPollingProgress: function() {
        this.pollUnreg(this.updatePollingId);
        this.updatePollingId = undefined;
        SYNO.SDS.Desktop.getMsgBox().hide();
        this.close()
    }
});
SYNO.SDS.App.SASExpFwUpdateApp.Window = Ext.extend(SYNO.SDS.AppWindow, {
    updProgressBox: null,
    updateMins: 0,
    updatePollingId: undefined,
    constructor: function(b) {
        var a;
        this.owner = b.owner;
        this.module = b.module;
        a = Ext.apply({
            width: 600,
            height: 340,
            minWidth: 600,
            minHeight: 340,
            padding: "16px 20px 12px 20px",
            dsmStyle: "v5",
            layout: "fit",
            maximizable: false,
            minimizable: false,
            showHelp: false,
            cls: "syno-disk-message-handler",
            items: [{
                xtype: "syno_formpanel",
                itemId: "form",
                border: false,
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "update_desc",
                    htmlEncode: false,
                    value: String.format(_T("update", "exp_fw_critical_update_desc"), 0, "")
                }, {
                    xtype: "syno_checkbox",
                    htmlEncode: false,
                    boxLabel: _T("update", "exp_fw_critical_update_comfirm"),
                    listeners: {
                        check: {
                            scope: this,
                            fn: this.onCheckboxCheck
                        }
                    }
                }]
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                btnStyle: "gray",
                handler: this.onClickCancel
            }, {
                text: _T("pkgmgr", "pkgmgr_pkg_upgrade"),
                itemId: "update",
                scope: this,
                disabled: true,
                btnStyle: "blue",
                handler: this.onClickUpdate
            }],
            listeners: {
                beforeclose: this.onBeforeClose
            }
        }, b);
        SYNO.SDS.App.SASExpFwUpdateApp.Window.superclass.constructor.call(this, a)
    },
    onCheckboxCheck: function(c, b) {
        var a = this.getFooterToolbar().getComponent("update");
        a.setDisabled(!b)
    },
    onClickUpdate: function() {
        this.cancelNotfiy();
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Enclosure",
            method: _S("ha_running") ? "sha_exp_fw_update" : "exp_fw_update",
            version: 1,
            params: {},
            scope: this,
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    if (504 == a.code) {
                        this.getMsgBox().alert("", _T("update", "exp_fw_upd_already_in_progress"));
                        this.hide()
                    } else {
                        this.getMsgBox().alert("", _T("common", "error_system"));
                        this.hide()
                    }
                } else {
                    SYNO.SDS.App.SASExpFwUpdateApp.SASFwUpdProgressBar.startFWUpdProgress(this, this.updateMins);
                    this.hide()
                }
            }
        })
    },
    onClickCancel: function() {
        this.close()
    },
    onBeforeClose: function() {
        this.cancelNotfiy();
        this.getMsgBox().alert("", _T("update", "exp_fw_critical_update_cancel_desc"));
        this.hide();
        return false
    },
    updateDesc: function(b, d, c) {
        var a = this.getComponent("form").getComponent("update_desc");
        this.updateMins = Math.ceil(d / 60);
        a.setValue(c ? String.format(_T("update", "exp_fw_rollback_error_update_desc"), b) : String.format(_T("update", "exp_fw_critical_update_desc"), this.updateMins, b))
    },
    cancelNotfiy: function() {
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Enclosure",
            method: _S("ha_running") ? "sha_exp_fw_update_cancel_notify" : "exp_fw_update_cancel_notify",
            version: 1,
            params: {},
            scope: this,
            callback: function(b, a) {}
        })
    }
});
