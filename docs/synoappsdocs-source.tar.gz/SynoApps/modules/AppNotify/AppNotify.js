/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.PollingTask.BadgeInfo", {
    statics: {
        getInfoOfApp: function(a) {
            if (this.data && this.data[a]) {
                return this.data[a].unread
            } else {
                return 0
            }
        },
        getInfoOfFn: function(b, a) {
            if (this.data && this.data[b] && this.data[b].fn[a]) {
                return this.data[b].fn[a].unread
            } else {
                return 0
            }
        },
        each: function(b, a) {
            if (this.data) {
                Ext.iterate(this.data, b, a || this)
            }
        },
        eachFnOfApp: function(b, c, a) {
            if (this.data && this.data[b] && this.data[b].fn) {
                Ext.iterate(this.data[b].fn, c, a || this)
            }
        }
    }
});
/**
 * @class SYNO.SDS.AppNotify.Instance
 * @extends SYNO.SDS.AppInstance
 * AppNotify application instance class
 *
 */
Ext.define("SYNO.SDS.AppNotify.Instance", {
    extend: "SYNO.SDS.AppInstance",
    badgeData: null,
    constructor: function() {
        this.customList = {};
        this.disabledAppMap = {};
        this.registerSocketEvent();
        this.callParent(arguments)
    },
    initInstance: function() {
        SYNO.SDS.StatusNotifier.fireEvent("appnotifyready");
        var a = new Ext.Component({
            appInstance: this
        });
        this.addInstance(a);
        this.startPollTask(true);
        this.mon(SYNO.SDS.StatusNotifier, "registerappnotify", this.onRegisterApp, this);
        this.mon(SYNO.SDS.StatusNotifier, "unregisterappnotify", this.unRegisterApp, this);
        this.mon(SYNO.SDS.StatusNotifier, "jsconfigLoaded", this.onJSConfigLoaded, this);
        this.mon(SYNO.SDS.StatusNotifier, "modifyHaveNtAppList", this.restartPollingTask, this);
        this.mon(SYNO.SDS.StatusNotifier, "apprecordupdated", this.restartPollingTask, this)
    },
    registerSocketEvent: function() {
        var a = {
            api: "SYNO.Core.AppNotify",
            version: 1,
            method: "get"
        };
        SYNO.SDS.SocketInst.register({
            api: a.api,
            version: a.version,
            method: a.method
        }, function(b) {
            this.onSocketReturn(b.success, b.data)
        }.bind(this), true)
    },
    onRegisterApp: function(d, a, e, c) {
        var b = (a) ? a.api + a.method : d;
        if (this.customList[b]) {
            return
        }
        this.customList[b] = {
            callback: e,
            webapi: a,
            className: d,
            scope: c
        };
        this.startPollTask(true)
    },
    unRegisterApp: function(a) {
        var b = a.api + a.method;
        if (this.customList[b]) {
            delete this.customList[b];
            this.startPollTask(true)
        }
    },
    restartPollingTask: function() {
        this.startPollTask(true)
    },
    onJSConfigLoaded: function(a, c) {
        var d, b = false;
        for (d in this.customList) {
            if (this.customList.hasOwnProperty(d) && this.customList[d].className && !SYNO.SDS.StatusNotifier.isAppEnabled(this.customList[d].className)) {
                delete this.customList[d];
                b = true
            }
        }
        if (b === true) {
            this.startPollTask(true)
        }
    },
    startPollTask: function(c) {
        var b = [],
            d, a;
        this.stopPollTask();
        for (d in this.customList) {
            if (this.customList.hasOwnProperty(d)) {
                a = this.customList[d].webapi;
                b.push(a)
            }
        }
        if (b.length === 0) {
            return
        }
        this.pollTaskId = this.pollReg({
            interval: 10,
            immediate: !!c,
            webapi: {
                api: "SYNO.Entry.Request",
                version: 1,
                method: "request",
                stopwhenerror: true,
                params: {
                    compound: b
                }
            },
            scope: this,
            status_callback: this.onAPIReturn
        })
    },
    stopPollTask: function() {
        if (Ext.isString(this.pollTaskId) && this.pollUnreg(this.pollTaskId)) {
            this.pollTaskId = null
        }
    },
    onSocketReturn: function(b, a) {
        if (!b) {
            return
        }
        this.badgeData = this.badgeData || {};
        Ext.apply(this.badgeData, a);
        this.addedBadgeAndFireEvent()
    },
    onAPIReturn: function(k, f, a) {
        if (!k && f.has_fail === false) {
            return
        }
        var g, j, b, e, h, d, c;
        this.badgeData = this.badgeData || {};
        for (g = 0; g < f.result.length; g++) {
            b = f.result[g];
            e = b.api + b.method;
            h = this.customList[e];
            if (h && h.callback) {
                j = h.callback.call(h.scope || window, f.result[g].data);
                Ext.apply(this.badgeData, j)
            }
        }
        d = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.DSMNotify.Setting.Application", "haveNtAppList");
        c = this.convertArrayToMap(d);
        Ext.iterate(this.badgeData, function(i, m, l) {
            if (false === c[i]) {
                delete this.badgeData[i]
            }
        }, this);
        this.addedBadgeAndFireEvent()
    },
    addedBadgeAndFireEvent: function() {
        SYNO.SDS.PollingTask.BadgeInfo.data = null;
        SYNO.SDS.PollingTask.BadgeInfo.data = this.badgeData;
        SYNO.SDS.StatusNotifier.fireEvent("badgenumget", SYNO.SDS.PollingTask.BadgeInfo);
        this.addBadgeToDesktopItems(this.badgeData)
    },
    convertArrayToMap: function(a) {
        var b = {};
        Ext.each(a, function(c) {
            if ("on" === c.badge || "disabled" === c.badge) {
                b[c.jsID] = true
            } else {
                b[c.jsID] = false
            }
        }, this);
        return b
    },
    addBadgeToDesktopItems: function(n) {
        var p = SYNO.SDS.Desktop.validIconItems;
        var f = {
            alignPos: "br-br",
            alignOffset: [4, 2]
        };
        var g = function(u, w) {
            var s = !u.param,
                j = u.param && u.param.fn,
                i = u.className,
                v = (j) ? u.param.fn : undefined,
                t = w[i] ? w[i].time || 0 : 0,
                r = w[i] ? w[i].lastView || 0 : 0;
            if (w[i] && (s === true)) {
                return t >= r ? w[i].unread : 0
            } else {
                if (w[i] && j && w[i].fn && w[i].fn[v]) {
                    return t >= r ? w[i].fn[v].unread : 0
                }
            }
            return 0
        };
        for (var h = 0; h < p.length; h++) {
            var d = p[h],
                q = SYNO.SDS.Desktop.getIconItemById(d.id).getNotifyBadgeWrap();
            if (d.className !== "SYNO.SDS.VirtualGroup") {
                var k = g(d, n);
                this.updateBadge(d, q, k, f)
            } else {
                var m = 0;
                var e = d.subItems;
                for (var c = 0; c < e.length; c++) {
                    var b = e[c],
                        a = g(e[c], n),
                        o = SYNO.SDS.Desktop.getIconItemById(b.id),
                        l = (o) ? o.getNotifyBadgeWrap() : null;
                    m += a;
                    if (l) {
                        this.updateBadge(l, l, a, f)
                    }
                }
                this.updateBadge(q, q, m, f)
            }
        }
    },
    updateBadge: function(a, b, e, d) {
        var c = {};
        d = d || {};
        Ext.applyIf(d, {
            alignPos: "br-br",
            alignOffset: [0, 0]
        });
        c = Ext.copyTo(c, d, ["alignPos", "alignOffset"]);
        c.alignOffset = d.alignOffset.slice(0);
        if (!(a.badge instanceof SYNO.SDS.Utils.Notify.Badge)) {
            a.badge = new SYNO.SDS.Utils.Notify.Badge({
                disableAnchor: true,
                renderTo: b,
                alignPos: c.alignPos,
                alignOffset: c.alignOffset
            });
            a.badge.setNum(e)
        } else {
            if (a.badge.badgeNum != e) {
                a.badge.setNum(e)
            }
        }
    }
});
