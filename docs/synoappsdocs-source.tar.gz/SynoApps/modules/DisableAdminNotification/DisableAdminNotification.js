! function(n) {
    var e = {};

    function t(i) {
        if (e[i]) return e[i].exports;
        var o = e[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return n[i].call(o.exports, o, o.exports, t), o.l = !0, o.exports
    }
    t.m = n, t.c = e, t.d = function(n, e, i) {
        t.o(n, e) || Object.defineProperty(n, e, {
            enumerable: !0,
            get: i
        })
    }, t.r = function(n) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(n, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(n, "__esModule", {
            value: !0
        })
    }, t.t = function(n, e) {
        if (1 & e && (n = t(n)), 8 & e) return n;
        if (4 & e && "object" == typeof n && n && n.__esModule) return n;
        var i = Object.create(null);
        if (t.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: n
            }), 2 & e && "string" != typeof n)
            for (var o in n) t.d(i, o, function(e) {
                return n[e]
            }.bind(null, o));
        return i
    }, t.n = function(n) {
        var e = n && n.__esModule ? function() {
            return n.default
        } : function() {
            return n
        };
        return t.d(e, "a", e), e
    }, t.o = function(n, e) {
        return Object.prototype.hasOwnProperty.call(n, e)
    }, t.p = "", t(t.s = 3)
}([function(n, e, t) {}, function(n, e) {
    n.exports = Vue
}, function(n, e, t) {
    "use strict";
    var i = t(0);
    t.n(i).a
}, function(n, e, t) {
    "use strict";
    t.r(e);
    var i = t(1),
        o = t.n(i),
        a = function() {
            var n = this.$createElement;
            return (this._self._c || n)("v-app-instance", {
                attrs: {
                    "class-name": "SYNO.SDS.App.DisableAdminNotification.Instance",
                    "syno-id": "disable-admin-app-instance",
                    "can-open": this.canOpen,
                    "should-launch": this.shouldLaunch
                }
            })
        };

    function r(n, e, t, i, o, a, r, s) {
        var d, c = "function" == typeof n ? n.options : n;
        if (e && (c.render = e, c.staticRenderFns = t, c._compiled = !0), i && (c.functional = !0), a && (c._scopeId = "data-v-" + a), r ? (d = function(n) {
                (n = n || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (n = __VUE_SSR_CONTEXT__), o && o.call(this, n), n && n._registeredComponents && n._registeredComponents.add(r)
            }, c._ssrRegister = d) : o && (d = s ? function() {
                o.call(this, this.$root.$options.shadowRoot)
            } : o), d)
            if (c.functional) {
                c._injectStyles = d;
                var l = c.render;
                c.render = function(n, e) {
                    return d.call(e), l(n, e)
                }
            } else {
                var u = c.beforeCreate;
                c.beforeCreate = u ? [].concat(u, d) : [d]
            } return {
            exports: n,
            options: c
        }
    }
    a._withStripped = !0;
    var s = r({
        mixins: [],
        data: function() {
            return {}
        },
        methods: {
            canOpen: function() {
                var n = SYNO.SDS.App.DisableAdminNotification.notified;
                return !(!_S("is_admin") || !0 === n) && (this.disableAdminInfoLoad(), !1)
            },
            disableAdminInfoLoad: function() {
                synowebapi.promises.request({
                    api: "SYNO.Core.DisableAdmin",
                    method: "get",
                    version: 1
                }).then((function(n) {
                    n.notify_disable_admin && (SYNO.SDS.App.DisableAdminNotification.notified = !0, SYNO.SDS.SystemTray.notifyVueCustomizeMsg("", new SYNO.SDS.App.DisableAdminNotification.DisableAdminTray({
                        data: {
                            isOnlyAdmin: n.is_only_admin
                        }
                    })))
                })).catch((function(n) {
                    SYNO.Debug.error(n)
                }))
            },
            shouldLaunch: function() {
                return !0
            }
        }
    }, a, [], !1, null, null, null);
    s.options.__file = "src/App.vue";
    var d = s.exports,
        c = function() {
            var n = this,
                e = n.$createElement,
                t = n._self._c || e;
            return t("div", [t("v-notification", {
                attrs: {
                    activeDuration: 0
                },
                scopedSlots: n._u([{
                    key: "wrapper",
                    fn: function() {
                        return [t("div", {
                            staticClass: "syno-disable-admin-tray-icon"
                        }), n._v(" "), t("div", {
                            staticClass: "syno-disable-admin-tray-info"
                        }, [t("div", {
                            staticClass: "syno-disable-admin-tray-title",
                            domProps: {
                                innerHTML: n._s(n.$i18n("disable_admin_notification", "info_title"))
                            }
                        }), n._v(" "), t("div", {
                            staticClass: "syno-disable-admin-tray-body",
                            domProps: {
                                innerHTML: n._s(n.body)
                            }
                        })])]
                    },
                    proxy: !0
                }])
            })], 1)
        };
    c._withStripped = !0;
    var l = {
            data: function() {
                return {}
            },
            computed: {
                body: function() {
                    var n = '<a id="open-user-page">' + _T("common", "here") + "</a>";
                    return "admin" !== _S("user").toLowerCase() || this.$parent.isOnlyAdmin ? this.$parent.isOnlyAdmin ? String.format(_T("disable_admin_notification", "info_desc_create_and_disable"), n) : String.format(_T("disable_admin_notification", "info_desc_disable"), n) : _T("disable_admin_notification", "info_desc_disable_by_another")
                }
            },
            mounted: function() {
                var n = this.$el.querySelector("#open-user-page");
                n && n.addEventListener("click", this.onClickLink)
            },
            methods: {
                onClickLink: function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                        fn: "SYNO.SDS.AdminCenter.User.Main",
                        tab: "user_tab"
                    })
                }
            }
        },
        u = (t(2), r(l, c, [], !1, null, null, null));
    u.options.__file = "src/disable-admin-tray.vue";
    var p = u.exports;
    Ext.namespace("SYNO.SDS.App.DisableAdminNotification"), // @require SYNO.SDS.App.DisableAdminNotification.DisableAdminTray
        SYNO.SDS.App.DisableAdminNotification.Instance = o.a.extend({
            template: "<App/>",
            components: {
                App: d
            }
        }), SYNO.SDS.App.DisableAdminNotification.DisableAdminTray = o.a.extend({
            template: "<DisableAdminTray/>",
            components: {
                DisableAdminTray: p
            }
        })
}]);