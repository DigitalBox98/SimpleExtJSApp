/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.DSMNotify.ShowAllDialog
 * @extends SYNO.SDS.AppWindow
 * DSMNotify show all dialog class
 *
 */
Ext.define("SYNO.SDS.DSMNotify.ShowAllDialog", {
    extend: "SYNO.SDS.AppWindow",
    itemsPerPage: 30,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.on("show", function() {
            this.grid.getStore().load({
                params: {
                    start: 0,
                    limit: this.itemsPerPage
                }
            })
        }, this), this.mon(SYNO.SDS.StatusNotifier, "notificationPanelClearAll", function() {
            this.paging.changePage(1)
        }, this)
    },
    fillConfig: function(t) {
        var e = {
            width: 740,
            height: 480,
            showHelp: !1,
            minimizable: !1,
            toggleMinimizable: !1,
            pinable: !1,
            cls: "sds-notify-showall-dialog",
            layout: "fit",
            items: [this.getGridPanel()],
            buttons: [{
                text: _T("common", "close"),
                xtype: "syno_button",
                btnStyle: "grey",
                scope: this,
                handler: this.close
            }]
        };
        return Ext.apply(e, t), e
    },
    getGridPanel: function() {
        var t = new SYNO.API.JsonStore({
            api: "SYNO.Core.DSMNotify",
            method: "notify",
            version: 1,
            baseParams: {
                action: "load"
            },
            appWindow: this,
            root: "items",
            totalProperty: "total",
            fields: ["title", "msg", "time", "className", "fn", "mailContent", "hasMail", "isEncoded", "mailType"],
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            listeners: {
                scope: this,
                load: function() {
                    _S("demo_mode") || Ext.getCmp(this.clearAllBtnId).setDisabled(0 === this.grid.getStore().getCount())
                }
            }
        });
        return this.paging = new SYNO.ux.PagingToolbar({
            store: t,
            displayInfo: !0,
            pageSize: this.itemsPerPage,
            refreshText: _T("log", "log_reload")
        }), this.grid = new SYNO.ux.GridPanel({
            title: _T("dsmnotify", "title"),
            loadMask: !0,
            stripeRows: !0,
            store: t,
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    width: 50,
                    sortable: !0
                },
                columns: [{
                    header: _T("notification", "category_title"),
                    dataIndex: "title",
                    renderer: this.titleRenderer.bind(this)
                }, {
                    width: 120,
                    header: _T("notification", "notification_title"),
                    dataIndex: "msg",
                    id: "msg",
                    renderer: this.msgRenderer.bind(this)
                }, {
                    header: _T("log", "log_time"),
                    dataIndex: "time",
                    renderer: this.timeRenderer
                }]
            }),
            autoExpandColumn: "msg",
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    rowselect: this.onRowSelect,
                    scope: this
                }
            }),
            bbar: this.paging,
            tbar: new Ext.Toolbar({
                defaultType: "syno_button",
                items: [{
                    text: _T("log", "log_reload"),
                    scope: this,
                    handler: function() {
                        this.paging.doRefresh()
                    }
                }, {
                    text: _T("dsmnotify", "clearall"),
                    scope: this,
                    handler: this.clearAll,
                    id: this.clearAllBtnId = Ext.id(),
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
                }, {
                    text: _T("notification", "view"),
                    itemId: "viewBtn",
                    scope: this,
                    disabled: !0,
                    handler: this.showDetailMsgDialog
                }]
            }),
            listeners: {
                rowdblclick: this.showDetailMsgDialog,
                scope: this
            }
        }), this.grid
    },
    clearAll: function() {
        this.grid.getStore().removeAll(), SYNO.API.Request({
            api: "SYNO.Core.DSMNotify",
            method: "notify",
            version: 1,
            params: {
                action: "apply",
                clean: "all"
            },
            scope: this,
            callback: function(t, e, i, s) {
                t && (this.paging.changePage(1), SYNO.SDS.StatusNotifier.fireEvent("checknotify"))
            }
        }), Ext.getCmp(this.clearAllBtnId).setDisabled(!0)
    },
    timeRenderer: function(t) {
        var e = new Date(1e3 * t).format("Y-m-d H:i:s");
        return '<div ext:qtip="' + e + '">' + e + "</div>"
    },
    getAndReplaceMsg: function(t, e, i) {
        var s = {};
        if (e.data.msg && 0 < e.data.msg.length) try {
            s = JSON.parse(e.data.msg[0])
        } catch (t) {}
        if (e && e.data && e.data.title in window.SYNO_Notification_Strings) {
            var n = window.SYNO_Notification_Strings[e.data.title].msg;
            n = SYNO.SDS.DSMNotify.Utils.concatControllerPrefix(n, s, e.data.className), t = SYNO.SDS.DSMNotify.Utils.replaceParams(n, e.data.msg, e.data.className)
        }
        return SYNO.SDS.DSMNotify.Utils.getMsg(t, i, e.data.className, e.data.fn)
    },
    msgRenderer: function(t, e, i) {
        var s = SYNO.SDS.DSMNotify.Utils.appendPeriod(this.getAndReplaceMsg(t, i, !0)),
            n = Ext.util.Format.htmlEncode(s);
        return String.format('<div class="{0}" ext:qtip="{1}">{2}</div>', SYNO.SDS.Utils.SelectableCLS, n, s)
    },
    getAndReplaceTitle: function(t, e, i) {
        return e && e.data && e.data.title in window.SYNO_Notification_Strings && (t = SYNO.SDS.DSMNotify.Utils.replaceParams(window.SYNO_Notification_Strings[e.data.title].title, e.data.msg)), SYNO.SDS.DSMNotify.Utils.getTitle(t, i, e.data.className)
    },
    titleRenderer: function(t, e, i) {
        var s = this.getAndReplaceTitle(t, i, !0),
            n = Ext.util.Format.htmlEncode(s);
        return String.format('<div class="{0}" ext:qtip="{1}">{2}</div>', SYNO.SDS.Utils.SelectableCLS, n, s)
    },
    onRowSelect: function() {
        this.grid.getTopToolbar().getComponent("viewBtn").setDisabled(!this.grid.getSelectionModel().getSelected())
    },
    showDetailMsgDialog: function() {
        var t = this.grid.getSelectionModel().getSelected(),
            e = this.getAndReplaceMsg(t.data.msg, t, !1),
            i = {
                values: {
                    category: Ext.util.Format.htmlEncode(this.getAndReplaceTitle(t.data.title, t, !1)),
                    event: t.data.isEncoded ? Ext.util.Format.htmlEncode(e) : e,
                    time: SYNO.SDS.DateTimeFormatter(new Date(1e3 * t.data.time), {
                        type: "datetimesec"
                    }),
                    isHtmlEncode: "html" != t.data.mailType
                }
            };
        t.data.hasMail ? (i.key = t.data.title, i.className = t.data.className, i.msgArray = t.data.msg) : t.data.mailContent && (i.values.desc = SYNO.SDS.DSMNotify.Utils.getMsg(t.data.mailContent, !1, t.data.className, t.data.fn)), this.appInstance.detailDailogWindow && !0 === this.appInstance.detailDailogWindow.hidden && (this.appInstance.detailDailogWindow.destroy(), this.appInstance.detailDailogWindow = null), this.appInstance.detailDailogWindow || (this.appInstance.detailDailogWindow = new SYNO.SDS.DSMNotify.DetailDialog), this.appInstance.detailDailogWindow.open(i)
    }
}), Ext.define("SYNO.SDS.DSMNotify.CustomEnableColumn", {
    extend: "SYNO.ux.EnableColumn",
    constructor: function(t) {
        this.callParent([Ext.apply({
            width: 180
        }, t)])
    },
    renderer: function(t, e, i) {
        return "disabled" === i.get(this.dataIndex) && (t = "disabled"), this.renderCheckBox(t, e, i)
    },
    isIgnore: function(t, e) {
        return "disabled" === e.get(this.dataIndex)
    },
    renderCheckBox: function(t, e, i) {
        var s = "disabled" === t ? "disabled" : "on" === t ? "checked" : "unchecked",
            n = "disabled" !== s && "checked" === s,
            a = i ? i.id + "_" + this.dataIndex : Ext.id(),
            o = "disabled" === s ? _T("common", "disabled") : _JSLIBSTR("uicommon", "enable_column_" + s),
            l = "disabled" === s;
        return (e = e || {}).cellAttr = String.format('aria-label="{0} {1}" aria-checked="{2}" aria-disabled="{3}" role="checkbox"', Ext.util.Format.stripTags(this.orgHeader), o, n, l), String.format('<div class="syno-ux-grid-enable-column-{0}" id="{1}"></div>', s, a)
    },
    toggleRec: function(t) {
        var e = t.get(this.dataIndex);
        "on" === e ? e = "off" : "off" === e && (e = "on"), t.set(this.dataIndex, e)
    },
    onSelectAll: function() {
        var t, e, i, s, n;
        if (this.box_el && this.box_el.dom) {
            for (t = this.getGrid().getStore(), n = this.box_el.hasClass("syno-ux-cb-checked") ? "on" : "off", this.enableFastSelectAll && t.suspendEvents(), e = 0, s = t.getCount(); e < s; e++) "gray" !== (i = t.getAt(e).get(this.dataIndex)) && i === n || this.isIgnore("all", t.getAt(e)) || this.toggleRec(t.getAt(e));
            this.enableFastSelectAll && (this.getGrid().getView().refresh(), t.resumeEvents()), this.commitChanges && t.commitChanges(), this.checkSelectAll(t)
        }
    },
    checkSelectAll: function(t) {
        var e, i, s, n = t.getCount(),
            a = n > 0,
            o = !0,
            l = !1;
        if (this.box_el && this.box_el.dom) {
            for (e = 0; e < n; e++) this.isIgnore("check", t.getAt(e)) || (o = !1, "gray" === (i = t.getAt(e).get(this.dataIndex)) || "off" === i ? a = !1 : l = !0);
            s = this.box_el.up("td"), a && !o ? (this.box_el.removeClass("syno-ux-cb-grayed"), this.box_el.addClass("syno-ux-cb-checked"), s.setARIA({
                checked: !0
            })) : a || o || !l ? (this.box_el.removeClass("syno-ux-cb-checked"), this.box_el.removeClass("syno-ux-cb-grayed"), s.setARIA({
                checked: !1
            })) : (this.box_el.removeClass("syno-ux-cb-checked"), this.box_el.addClass("syno-ux-cb-grayed"), s.setARIA({
                checked: "mixed"
            }))
        }
    }
}), Ext.define("SYNO.SDS.DSMNotify.Setting.GridPanel", {
    extend: "SYNO.ux.DDGridPanel",
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.addEvents("loadHaveNtAppList")
    },
    fillConfig: function(t) {
        this.createActions(), this.ctxMenu = new SYNO.ux.Menu({
            items: [this.getAction("up"), this.getAction("down")]
        });
        var e = {
            viewConfig: {
                ddGroup: "NtSettingGridDD",
                forceFit: !1
            },
            cm: this.getCM(),
            sm: this.getSM(),
            cls: "sds-notify-setting-grid without-dirty-red-grid",
            plugins: [this.notificationEnableCloumn, this.badgeEnableColumn],
            store: this.getDS(t),
            enableDragDrop: !0,
            enableColumnMove: !1,
            enableHdMenu: !1,
            region: "center",
            autoFlexScroll: !0,
            autoExpandColumn: this.titleID,
            listeners: {
                viewready: this.onGridViewReady,
                rowclick: this.onGridRowClick,
                rowcontextmenu: this.onRowCtxMenu,
                columnresize: this.onColumnResize,
                containercontextmenu: this.showCtxMenu
            }
        };
        return Ext.apply(e, t)
    },
    getDS: function(t) {
        var e = t.owner.findAppWindow();
        return new SYNO.API.JsonStore({
            api: "SYNO.Core.DSMNotify",
            method: "notify",
            version: 1,
            appWindow: e,
            baseParams: {
                action: "loadHaveNtAppList"
            },
            root: "items",
            totalProperty: "total",
            fields: ["app", "category", "category_enu", "dsmnotify"],
            pruneModifiedRecords: !0,
            listeners: {
                scope: this,
                beforeload: function() {
                    this.owner.el.isMasked || this.owner.setStatusBusy(null, null, 0)
                },
                load: function(t, e, i) {
                    this.isPriorityDirty = !1, this.fireEvent("loadHaveNtAppList", {
                        data: t.reader.jsonData
                    }), this.owner.clearStatusBusy(), t.suspendEvents();
                    for (var s = 0; s < e.length; s++) "dsm" !== e[s].get("app") && (SYNO.SDS.DSMNotify.Utils.isAppEnabled(e[s].get("app")) || t.remove(e[s]));
                    t.resumeEvents(), this.view.refresh()
                },
                exception: function() {
                    this.owner.clearStatusBusy(), this.owner.getMsgBox().alert("", "Fail to get the priority application list", this.owner.onHandleHide, this.owner)
                }
            }
        })
    },
    getCM: function() {
        return this.notificationEnableCloumn = new SYNO.SDS.DSMNotify.CustomEnableColumn({
            header: _T("dsmnotify", "title"),
            align: "center",
            dataIndex: "dsmnotify",
            menuDisabled: !0,
            sortable: !1
        }), this.badgeEnableColumn = new SYNO.SDS.DSMNotify.CustomEnableColumn({
            header: _T("dsmnotify", "badge"),
            dataIndex: "badge",
            hidden: !0,
            menuDisabled: !0,
            sortable: !1
        }), new Ext.grid.ColumnModel([{
            header: _T("dsmnotify", "service"),
            id: this.titleID = Ext.id(),
            dataIndex: "category",
            editable: !1,
            sortable: !1,
            menuDisabled: !0,
            renderer: this.titleRenderer
        }, this.notificationEnableCloumn, this.badgeEnableColumn])
    },
    getSM: function() {
        return new Ext.grid.RowSelectionModel
    },
    getTopTbar: function() {
        return new Ext.Toolbar({
            defaultType: "syno_button",
            items: [this.getAction("up"), this.getAction("down")]
        })
    },
    actions: null,
    createActions: function() {
        var t = function(t, e, i, s, n) {
            return new Ext.Action(Ext.apply({
                text: t,
                itemId: e,
                handler: i,
                scope: s
            }, n))
        };
        this.actions = {
            up: t(_T("common", "up"), "up", this.onClickUP, this),
            down: t(_T("common", "down"), "down", this.onClickDown, this)
        }
    },
    getAction: function(t) {
        return this.actions[t]
    },
    onGridRowClick: function(t, e, i) {
        i && e && !i.hasModifier() && t.getSelectionModel().selectRow(e)
    },
    onGridViewReady: function() {
        this.view.updateScroller()
    },
    onRowCtxMenu: function(t, e, i) {
        i.preventDefault();
        var s = t.getSelectionModel();
        s.isSelected(e) || s.selectRow(e), this.showCtxMenu(t, i)
    },
    showCtxMenu: function(t, e) {
        this.owner.isTime || this.ctxMenu.showAt(e.getXY())
    },
    sortSelectionComparator: function(t, e) {
        var i = this.getStore();
        return i.indexOf(t) > i.indexOf(e)
    },
    moveSelectedRow: function(t) {
        var e, i, s = this.getStore(),
            n = this.getSelectionModel().getSelections(),
            a = s.getCount(),
            o = -1;
        if (!Ext.isEmpty(n)) {
            for (n.sort(function(t, e) {
                    return s.indexOf(t) > s.indexOf(e)
                }), t ? (o = s.indexOf(n.first()) - 1) <= 0 && (o = 0) : (o = s.indexOf(n.last()) + 1) >= a - 1 && (o = a - 1), s.suspendEvents(), e = 0; e < n.length; e++) s.remove(n[e]), i = 0 === e ? o : this.store.indexOf(n[e - 1]) + 1, s.insert(i, n[e]), this.isPriorityDirty = !0;
            s.resumeEvents(), this.view.refresh(), this.view.focusEl.focus()
        }
    },
    onColumnResize: function() {
        this.getView().fitColumns()
    },
    onClickUP: function() {
        this.moveSelectedRow(!0)
    },
    onClickDown: function() {
        this.moveSelectedRow(!1)
    },
    titleRenderer: function(t, e, i) {
        var s = SYNO.SDS.DSMNotify.Utils.getTitle(t, !0, i.data.jsID, i.data.fn),
            n = Ext.util.Format.htmlEncode(s);
        return String.format('<div ext:qtip="{0}">{1}</div>', n, s)
    },
    getApplyData: function() {
        var t = [];
        return this.getStore().each(function(e) {
            var i = e.data;
            t.push(i)
        }, this), t
    },
    isDataDirty: function() {
        var t = this.getStore().getModifiedRecords();
        return this.isPriorityDirty || 0 !== t.length
    }
}), Ext.define("SYNO.SDS.DSMNotify.Setting.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.DSMNotify.Setting.Window",
    constructor: function(t) {
        this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.DSMNotify.Setting.Window", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.mon(this, "show", function() {
            this.grid.disableDD(), this.grid.getStore().load()
        }, this), this.mon(this, "beforeshow", function() {
            this.el.isMasked() || this.setStatusBusy(null, null, 0)
        }, this)
    },
    fillConfig: function(t) {
        this.northPanel = new SYNO.ux.FormPanel({
            height: 63,
            region: "north",
            margins: "8 12",
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_displayfield",
                value: _T("dsmnotify", "brief_desc"),
                height: 48,
                hideLabel: !0
            }]
        });
        var e = {
            width: 625,
            height: 580,
            minimizable: !1,
            maximizable: !1,
            toggleMinimizable: !1,
            pinable: !1,
            minWidth: 595,
            cls: "sds-notify-setting-dialog",
            closeAction: "onHandleHide",
            fbar: this.getFbar(),
            layout: "border",
            items: [this.northPanel, this.getGridPanel({
                region: "center",
                flex: 1,
                margins: "0 20",
                owner: this
            })]
        };
        return Ext.apply(e, t), e
    },
    getFbar: function() {
        return new Ext.ux.StatusBar({
            defaultType: "syno_button",
            cls: "x-statusbar",
            items: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                handler: this.onHandleHide,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "ok"),
                handler: this.onClickOK,
                scope: this
            }]
        })
    },
    getGridPanel: function(t) {
        return this.grid = new SYNO.SDS.DSMNotify.Setting.GridPanel(t), this.grid
    },
    onClickOK: function() {
        var t = this.grid.getApplyData(),
            e = {
                scope: this,
                callback: function() {
                    this.clearStatusBusy(), this.grid.getStore().commitChanges(), this.confirmLostChangeResolve && this.confirmLostChangeResolve()
                }
            };
        this.isDataDirty() && (this.setStatusBusy(), this.appInstance.setUserSettings("notifcationSettings", t), SYNO.SDS.UserSettings.syncSave(e), SYNO.SDS.StatusNotifier.fireEvent("modifyHaveNtAppList")), this.hide()
    },
    isDataDirty: function() {
        return this.grid.isDataDirty() || this.northPanel.getForm().isDirty()
    },
    onHandleHide: function() {
        this.isDataDirty() ? this.confirmLostChangePromise({
            save: function() {
                return new Promise(function(t, e) {
                    this.confirmLostChangeResolve = t, this.confirmLostChangeReject = e, this.onClickOK()
                }.bind(this))
            },
            cancel: Ext.emptyFn,
            dontSave: function() {
                this.hide()
            }
        }, this) : this.hide()
    }
}), Ext.define("SYNO.SDS.DSMNotify.DetailDialog", {
    extend: "SYNO.SDS.ModalWindow",
    title: _T("notification", "detail_window"),
    constructor: function(t) {
        this.formPanel = new SYNO.ux.FormPanel({
            padding: "0px",
            items: [{
                xtype: "syno_displayfield",
                name: "category",
                ref: "category",
                fieldLabel: _T("notification", "category_title")
            }, {
                xtype: "syno_displayfield",
                name: "event",
                ref: "event",
                fieldLabel: _T("notification", "notification_title"),
                htmlEncode: !1,
                listeners: {
                    afterrender: function() {
                        this.el.on("click", function(t) {
                            SYNO.SDS.Utils.Notify.BindEvent(t)
                        })
                    }
                }
            }, {
                xtype: "syno_displayfield",
                name: "time",
                ref: "time",
                fieldLabel: _T("log", "log_time")
            }, {
                xtype: "syno_displayfield",
                name: "desc",
                ref: "desc",
                fieldLabel: _T("notification", "description_title"),
                htmlEncode: !1,
                listeners: {
                    afterrender: function() {
                        this.el.on("click", function(t) {
                            SYNO.SDS.Utils.Notify.BindEvent(t)
                        })
                    }
                }
            }]
        });
        var e = {
            width: 640,
            height: 400,
            layout: "fit",
            modal: !1,
            items: [this.formPanel],
            cls: "sds-notify-detail-window",
            buttons: [{
                text: _T("common", "close"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        };
        Ext.apply(e, t), this.callParent([e])
    },
    onOpen: function(t) {
        this.setDetailMsg(t), this.callParent()
    },
    onRequest: function(t) {
        this.setDetailMsg(t), this.callParent()
    },
    setDetailMsg: function(t) {
        this.setAllFieldVisible(!1), t.key ? (this.setStatusBusy(), this.sendWebAPIPromise({
            api: "SYNO.Core.DSMNotify.MailContent",
            method: "get",
            version: 1,
            params: {
                title: t.key
            },
            scope: this
        }).then(function(e) {
            e && e.mailContent && 0 < e.mailContent.length ? t.values.desc = SYNO.SDS.DSMNotify.Utils.replaceParams(this.getDetailMsg(e.mailContent), t.msgArray, t.className) : t.values.desc = _T("dsmnotify", "error_msg"), this.setValues(t.values), this.setAllFieldVisible(!0), this.clearStatusBusy()
        }.bind(this), function(t) {
            var e = this;
            this.clearStatusBusy(), this.getMsgBox().alert("Title", _T("error", "error_error_system"), function() {
                e.hide()
            })
        }.bind(this))) : (this.setAllFieldVisible(!0), this.formPanel.desc.setVisible(!!t.values.desc), t.values.desc && (t.values.desc = this.getDetailMsg(t.values.desc)), this.setValues(t.values))
    },
    setAllFieldVisible: function(t) {
        this.formPanel.category.setVisible(t), this.formPanel.event.setVisible(t), this.formPanel.time.setVisible(t), this.formPanel.desc.setVisible(t)
    },
    setValues: function(t) {
        t.desc && t.isHtmlEncode && (t.desc = Ext.util.Format.htmlEncode(t.desc.replace(/<br>/gi, "\n")).replace(/(\r\n|\r|\n)/g, "<br>")), t.event && (t.event = SYNO.SDS.DSMNotify.Utils.appendPeriod(t.event)), this.formPanel.getForm().setValues(t), this.formPanel.updateFleXcroll()
    },
    getDetailMsg: function(t) {
        for (var e in t = t.replace(/(\r\n|\r|\n)/g, "<br>"), SYNO.SDS.DSMNotify.MailPhrase) {
            var i = SYNO.SDS.DSMNotify.MailPhrase[e].closing,
                s = new RegExp("%HOSTNAME%" + i + "|" + i + "%HOSTNAME%", "i");
            if (s.test(t)) {
                t = t.replace(s, "");
                break
            }
            var n = SYNO.SDS.DSMNotify.MailPhrase[e],
                a = new RegExp(n.salutation + "<br>", "i"),
                o = Ext.form.VTypes.netbiosNameMask.toString().slice(1, -1);
            if (s = new RegExp("<br>" + ("krn" === e ? o + "+" + n.closing : n.closing + o + "+"), "i"), a.test(t) && s.test(t)) {
                t = t.replace(a, "").replace(s, "");
                break
            }
        }
        return t.replace(/^(<br>|\s)*|(<br>|\s)+$/g, "")
    }
}), SYNO.SDS.DSMNotify.MailPhrase = {
    chs: {
        salutation: "亲爱的用户，您好：",
        closing: "来自 "
    },
    cht: {
        salutation: "親愛的使用者，您好：",
        closing: "來自 "
    },
    csy: {
        salutation: "Vážený uživateli,",
        closing: "Od "
    },
    dan: {
        salutation: "Kære bruger",
        closing: "Fra "
    },
    enu: {
        salutation: "Dear user,",
        closing: "From "
    },
    fre: {
        salutation: "Cher utilisateur,",
        closing: "De "
    },
    ger: {
        salutation: "Sehr geehrter Benutzer,",
        closing: "Von "
    },
    hun: {
        salutation: "Kedves Felhasználó!",
        closing: "Forrás: "
    },
    ita: {
        salutation: "Gentile utente,",
        closing: "Da "
    },
    jpn: {
        salutation: "お客様各位、",
        closing: "送信元 "
    },
    krn: {
        salutation: "사용자님께,",
        closing: "에서 보냄"
    },
    nld: {
        salutation: "Beste gebruiker,",
        closing: "Van "
    },
    nor: {
        salutation: "Kjære bruker",
        closing: "Fra "
    },
    plk: {
        salutation: "Szanowny Użytkowniku,",
        closing: "Od "
    },
    ptb: {
        salutation: "Prezado usuário,",
        closing: "De "
    },
    ptg: {
        salutation: "Caro utilizador,",
        closing: "De "
    },
    rus: {
        salutation: "Уважаемый пользователь!",
        closing: "Из "
    },
    spn: {
        salutation: "Estimado usuario:",
        closing: "Desde "
    },
    sve: {
        salutation: "Bäste användare,",
        closing: "Från "
    },
    tha: {
        salutation: "เรียนผู้ใช้",
        closing: "จาก "
    },
    trk: {
        salutation: "Sayın kullanıcı,",
        closing: "Geldiği yer: "
    }
}, Ext.define("SYNO.SDS.DSMNotify.Utils", {
    statics: {
        isAppEnabled: function(t) {
            return Ext.isEmpty(t) || !0 === SYNO.SDS.StatusNotifier.isAppEnabled(t)
        },
        getTitle: function(t, e, i, s) {
            if (!0 !== this.isAppEnabled(i)) return _T("dsmnotify", "error_title");
            var n = this.localizeMsg(t, e, i);
            return this.localizeMsgByFn(s, e, i, n) || n
        },
        getMsg: function(t, e, i, s) {
            if (!0 !== this.isAppEnabled(i)) return _T("dsmnotify", "error_msg");
            var n = this.localizeMsg(t, e, i);
            return this.localizeMsgByFn(s, e, i, n) || n
        },
        localizeMsgByFn: function(t, e, i, s) {
            var n, a, o = [];
            Ext.isArray(t) || (t = [t]);
            for (var l = 1; l < t.length; l++) o.push(SYNO.SDS.UIString.GetLocalizedString(t[l] + "", i));
            return o.push(s), a = Ext.isString(t[0]) ? Ext.getClassByName(t[0]) : "", Ext.isEmpty(a) || (n = a.apply(window, o)), e ? Ext.util.Format.stripTags(n) : n
        },
        localizeMsg: function(t, e, i) {
            var s, n = [];
            Ext.isArray(t) || (t = [t]);
            for (var a = 0; a < t.length; a++) n.push(SYNO.SDS.UIString.GetLocalizedString(t[a], i));
            if (n && 0 !== n.length) return s = String.format.apply(String, n), e ? Ext.util.Format.stripTags(s) : s
        },
        getLocalizedString: function(t, e) {
            return t ? SYNO.SDS.UIString.GetLocalizedString(t, e) : ""
        },
        replaceParams: function(t, e, i) {
            for (var s = e && 0 < e.length ? JSON.parse(e[0]) : {}, n = !0, a = function(t, e, i) {
                    /\{\d+\}/.test(e) && (e = window.escape(e));
                    var s = new RegExp(e, "g");
                    return s.test(t) ? (n = !0, t.replace(s, i)) : t
                }, o = 0; o < 5 && n; ++o)
                for (var l in n = !1, s) s.hasOwnProperty(l) && (t = a(t, l, SYNO.SDS.DSMNotify.Utils.getLocalizedString(s[l], i)));
            return t
        },
        concatControllerPrefix: function(t, e, i) {
            if (!_S("ha_support_node_notify")) return t;
            if (!e.hasOwnProperty("%HA_NOTIFY_PREFIX%")) return t;
            if ("SYNO.SDS.HA.Instance" === i) return t;
            if (!_S("ha_support_controller_notify") && new RegExp("%HOSTNAME%", "g").test(t)) return t;
            return "[%HA_NOTIFY_PREFIX%] " + t
        },
        appendPeriod: function(t) {
            if (!t || 0 == _T("common", "period").length) return t;
            t = t.trim();
            var e = new RegExp(".*\\" + _T("common", "period") + "$", "i");
            return t.match(e) || (t += _T("common", "period")), t
        }
    }
}), Ext.define("SYNO.SDS.DSMNotify.Application", {
    extend: "SYNO.SDS.AppInstance",
    trayItem: [],
    initInstance: function(t) {
        this.trayItem[0] || (this.trayItem[0] = new SYNO.SDS.DSMNotify.Tray({
            appInstance: this
        }), this.addInstance(this.trayItem), this.trayItem[0].open(t)), Ext.getCmp("sds-taskbar").doLayout()
    },
    onRequest: function(t) {
        "showPanel" == t.action && this.trayItem[0].onClick()
    }
}), Ext.define("SYNO.SDS.DSMNotify.Tray", {
    extend: "SYNO.SDS.AppTrayItem",
    panel: null,
    taskbarBtnId: "sds-taskbar-notification-button",
    constructor: function(t) {
        SYNO.SDS.DSMNotify.Tray.superclass.constructor.apply(this, arguments), this.panel = new SYNO.SDS.DSMNotify.Panel({
            module: this,
            baseURL: this.jsConfig.jsBaseURL
        }), this.addManagedComponent(this.panel), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(SYNO.SDS.StatusNotifier, "systemTrayNotifyMsg", this.panel.hide.createDelegate(this.panel, [!0], !1), this.panel), Ext.EventManager.onWindowResize(this.adjustPos, this), SYNO.SDS.TaskBar.rightTaskBar.buttons.push(this.taskButton), this.taskButton.disable()
    },
    onMouseDown: function(t) {
        t.within(this.taskButton.el) || this.panel.isVisible() && !t.within(this.panel.el) && this.panel.hideBox()
    },
    setTitle: function(t) {
        this.taskButton.setTooltip(t), this.taskButton.btnEl.setARIA({
            label: t,
            role: "button",
            tabindex: -1
        })
    },
    onBeforeDestroy: function() {
        this.panel = null, SYNO.SDS.DSMNotify.Tray.superclass.onBeforeDestroy.apply(this, arguments)
    },
    adjustPos: function() {
        this.panel.isVisible() && this.panel.alignPos(Ext.getBody(), this.taskbarBtnId)
    },
    onClick: function() {
        this.taskButton.disabled || (this.panel.isVisible() ? (this.panel.hideBox(), SYNO.SDS.TaskBar.rightTaskBar.toolbarEl.focus()) : (SYNO.SDS.StatusNotifier.fireEvent("taskBarPanelShow"), this.panel.show(), this.panel.alignPos(Ext.getBody(), this.taskbarBtnId), this.panel.dataview.getAriaEl().focus(300)))
    },
    getTaskBarBtnId: function() {
        return this.taskbarBtnId
    }
}), Ext.define("SYNO.SDS.DSMNotify.Panel", {
    statics: {
        OneWeekSeconds: 604800
    },
    extend: "Ext.Panel",
    storeId: "NotificationCenterTray",
    arrowCls: "sds-notify-panel-arrow",
    maxUnreadNum: 30,
    currentUnreadNum: 0,
    lastSeen: 0,
    lastRead: 0,
    pollTaskConfig: null,
    pollingInterval: 3e4,
    paddingBottom: 12,
    paddingRight: 12,
    badgeNumberId: Ext.id(),
    currentData: null,
    isFirstDataGetted: !1,
    tempData: null,
    badge: null,
    constructor: function(t) {
        var e = this,
            i = this;
        this.requestNewStrings().then(function() {
            return e.registerSocketEvent()
        }), SYNO.SDS.DSMNotify.Panel.superclass.constructor.call(this, Ext.apply({
            hidden: !0,
            floating: !0,
            shadow: !1,
            title: this.getTitleStr(),
            height: Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight() - this.paddingBottom,
            cls: "sds-notify-tray-panel sds-tray-panel",
            renderTo: Ext.getBody(),
            layout: "fit",
            bbar: [{
                xtype: "syno_button",
                btnStyle: "grey",
                ref: "../clearAllBtn",
                text: _T("dsmnotify", "clearall"),
                scope: this,
                handler: this.onClickClear,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
            }, {
                xtype: "tbfill"
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "show_all"),
                scope: this,
                handler: this.onClickShowAll,
                id: this.showAllBtnId = Ext.id()
            }],
            items: this.dataview = new SYNO.ux.FleXcroll.DataView({
                itemSelector: "div.item",
                setEmptyText: function() {
                    var t = Ext.getCmp("sds-notify-tray-panel-dataview"),
                        e = Ext.id();
                    return t.getAriaEl().setARIA({
                        describedby: e
                    }), String.format('<div class="sds-notify-empty-text" id="{2}" aria-label="{1}" style="line-height:{0}px">{1}</div>', Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight() - i.paddingBottom - 36 - 48, _T("dsmnotify", "empty_text"), e)
                },
                emptyText: this.setEmptyText,
                "aria-label": _T("dsmnotify", "title"),
                itemId: "dataview",
                singleSelect: !0,
                useARIA: !0,
                useDefaultKeyNav: !1,
                id: "sds-notify-tray-panel-dataview",
                cls: "sds-notify-tray-panel-dataview",
                refresh: function() {
                    this.tpl.msgDetailValues = [], this.emptyText = this.setEmptyText(), SYNO.ux.FleXcroll.DataView.superclass.refresh.call(this), Object.keys(this.tpl.msgDetailValues).forEach(function(t) {
                        Ext.get(t).on("click", function() {
                            var e = this.tpl.msgDetailValues[t],
                                i = {
                                    values: {
                                        category: this.tpl.localizeTitleNoTags(e.title, !0, e.className),
                                        event: this.tpl.getMsg(e),
                                        time: this.tpl.getMsgDate(e, !0),
                                        isHtmlEncode: "html" != e.mailType
                                    }
                                };
                            e.hasMail && e.key ? (i.key = e.key, i.className = e.className, i.msgArray = e.msgArray) : e.mailContent && (i.values.desc = e.mailContent), this.ownerCt.module.appInstance.detailDailogWindow && !0 === this.ownerCt.module.appInstance.detailDailogWindow.hidden && (this.ownerCt.module.appInstance.detailDailogWindow.destroy(), this.ownerCt.module.appInstance.detailDailogWindow = null), this.ownerCt.module.appInstance.detailDailogWindow || (this.ownerCt.module.appInstance.detailDailogWindow = new SYNO.SDS.DSMNotify.DetailDialog), this.ownerCt.module.appInstance.detailDailogWindow.open(i), this.ownerCt.hideBox()
                        }, this)
                    }.bind(this))
                },
                store: new Ext.data.JsonStore({
                    autoDestroy: !0,
                    storeId: this.storeId,
                    fields: ["title", "items", "className", "firstItem", "remainItems", "expanded", "unread"]
                }),
                tpl: new Ext.XTemplate('<div class="sds-notify-tray-panel-dataview-wrapper">', '<tpl for=".">', '<div class="{[this.getItemCls(values)]}" aria-label="{[this.getAriaSummary(values)]}" id="{[Ext.id()]}">', '<div class="title blue-status" ext:qtip="{[this.localizeTitleNoTags(values.title, true, values.className)]}">', '<div class="{[this.getItemLevelIconCls(values)]}"></div>', '<div class="{[this.getItemContentCls(values)]}" tabindex="-1" data-syno-app="{values.className}" data-syno-bind="{values.firstItem.bindEvt}" >{[this.getMsgTitle(values)]}</div>', '<tpl if="this.hasRemainItems(values)">', '<div class="expand-icon" data-xindex="{[xindex]}" is-expanded-icon></div>', "</tpl>", "</div>", '<div class="time" ext:qtip="{[this.getMsgDate(values.firstItem, true)]}">{[this.getMsgDate(values.firstItem, false)]}</div>', '<div class="msg {this.selectableCls}" ext:qtip="{[SYNO.SDS.DSMNotify.Utils.appendPeriod(this.localizeNoTags(values.firstItem.msg, true, values.firstItem.className, values.firstItem.fn))]}">', "{[this.getMsg(values.firstItem)]}", "{[this.getShowDetailLink(values.firstItem)]}", "</div>", '<div class="{[values.expanded === true ? "remain-items expanded" : "remain-items"]}" id="{[Ext.id()]}">', '<tpl for="values.remainItems">', '<div class="time" ext:qtip="{[this.getMsgDate(values, true)]}">{[this.getMsgDate(values, false)]}</div>', '<div class="msg {this.selectableCls}" ext:qtip="{[SYNO.SDS.DSMNotify.Utils.appendPeriod(this.localizeNoTags(values.msg, true, values.className, values.fn))]}">', "{[this.getMsg(values)]}", "{[this.getShowDetailLink(values)]}", "</div>", "</tpl>", "</div>", "</div>", "</tpl>", "</div>", {
                    compiled: !0,
                    disableFormats: !0,
                    hasRemainItems: function(t) {
                        return t.remainItems.length > 0
                    },
                    getItemCls: function(t) {
                        return "item " + (t.unread ? "unread" : "")
                    },
                    getItemLevelIconCls: function(t) {
                        var e = t.firstItem;
                        return "notification-level " + (e.level ? e.level.replace("NOTIFICATION_", "").toLowerCase() : "info")
                    },
                    getItemContentCls: function(t) {
                        var e = t.firstItem;
                        return !1 !== e.bindEvt && Ext.isBoolean(e.bindEvt) && e.className ? "content" : "content cursor-no-pointer"
                    },
                    getSuffixOfItemsCount: function(t) {
                        return t.length > 1 ? " (" + t.length + ")" : ""
                    },
                    getMsgTitle: function(t) {
                        return this.localizeTitleNoTags(t.title, !0, t.className) + this.getSuffixOfItemsCount(t.items)
                    },
                    getMsg: function(t) {
                        var e = "";
                        return e = !0 === t.isEncoded ? this.localizeNoTags(t.msg, !1, t.className, t.fn) : this.localize(t.msg, !1, t.className, t.fn), SYNO.SDS.DSMNotify.Utils.appendPeriod(e)
                    },
                    getMsgDate: function(t, e) {
                        var i, s, n = t.time;
                        return s = (i = this.getCurrentTime() - n) < 0, i > SYNO.SDS.DSMNotify.Panel.OneWeekSeconds || e || s ? SYNO.SDS.DateTimeFormatter(new Date(1e3 * t.time), {
                            type: "datetimesec"
                        }) : Ext.util.Format.relativeTime(1e3 * n)
                    },
                    getAriaSummary: function(t) {
                        var e = this.getMsgTitle(t),
                            i = this.getMsg(t),
                            s = this.getMsgDate(t.firstItem, !1),
                            n = String.format("{0} {1} {2}", e, i, s);
                        return n = Ext.util.Format.stripTags(n), n = Ext.util.Format.htmlEncode(n)
                    },
                    getShowDetailLink: function(t) {
                        if (t.mailContent || t.hasMail) {
                            var e = Ext.id();
                            return this.msgDetailValues[e] = t, ' <a id="' + e + '" class="link-font">' + _T("notification", "more") + "</a>"
                        }
                        return ""
                    },
                    localizeTitle: this.getTitle.createDelegate(this, [!1], !0),
                    localizeTitleNoTags: this.encodedTitle.createDelegate(this, [!0], !0),
                    localize: this.getMsg.createDelegate(this, [!1], !0),
                    localizeNoTags: this.encodedMsg.createDelegate(this, [!0], !0),
                    showUnreadTagLeft: this.showUnreadTag.createDelegate(this, [!0], !0),
                    showUnreadTagRight: this.showUnreadTag.createDelegate(this, [!1], !0),
                    selectableCls: SYNO.SDS.Utils.SelectableCLS,
                    getCurrentTime: this.getCurrentTime.createDelegate(this, [!1], !0),
                    msgDetailValues: []
                }),
                listeners: {
                    click: function(t, e, i, s) {
                        SYNO.SDS.Utils.Notify.BindEvent(s), this.bindExpandedEvent(s)
                    },
                    scope: this
                }
            })
        }, t)), this.createArrowElement(), Ext.StoreMgr.get(this.storeId).removeAll(), this.lastRead = SYNO.SDS.UserSettings.getProperty(this.module.jsConfig.jsID, "lastRead") || 0, this.lastSeen = this.lastRead, this.mon(Ext.get(this.settingId), "click", this.onClickSetting, this), this.mon(SYNO.SDS.StatusNotifier, "modifyHaveNtAppList", this.loadNotify, this), this.mon(SYNO.SDS.StatusNotifier, "jsconfigLoaded", this.loadNotify, this), SYNO.SDS.SocketInst.registerSDKEvent("load_notify", function(t) {
            t && "load" == t.action && t.username == _S("user") && e.loadNotify()
        }), this.keyNav = new Ext.KeyNav(this.el, {
            down: function(t) {
                this.dataview.selectNextItem()
            },
            up: function(t) {
                this.dataview.selectPreItem()
            },
            esc: function() {
                this.module.onClick()
            },
            scope: this
        })
    },
    requestNewStrings: function(t) {
        var e = this;
        return new Promise(function(i, s) {
            e.sendWebAPI({
                api: "SYNO.Core.DSMNotify.Strings",
                version: 1,
                method: "get",
                params: {
                    pkgName: t && t.pkgName ? t.pkgName : ""
                },
                callback: function(t, e, s) {
                    t && (window.SYNO_Notification_Strings ? Object.assign(window.SYNO_Notification_Strings, e) : window.SYNO_Notification_Strings = e), i()
                },
                scope: e
            })
        })
    },
    registerSocketEvent: function() {
        var t = this;
        SYNO.SDS.SocketInst.register({
            api: "SYNO.Core.DSMNotify",
            version: 1,
            method: "notify",
            params: {
                action: "load"
            }
        }, function(e) {
            t.isVisible() ? t.tempData = e.data : t.onHandleData(e.success, e.data)
        }, !0), SYNO.SDS.SocketInst.registerSDKEvent("libsynosysnotify_strings_changed", function(e) {
            return t.requestNewStrings(e)
        })
    },
    createArrowElement: function() {
        var t = this.getEl();
        this.arrowEl = t.createChild({
            tag: "div",
            cls: this.arrowCls
        })
    },
    alignPos: function(t, e) {
        this.getEl().alignTo(t, "tr-tr", [-this.paddingRight, SYNO.SDS.TaskBar.getHeight() + 2]), this.arrowEl.alignTo(Ext.get(e), "t-b", [0, -7])
    },
    bindExpandedEvent: function(t) {
        if (t && t.target && t.target.hasAttribute("is-expanded-icon")) {
            var e = t.target,
                i = parseInt(e.getAttribute("data-xindex"), 10) - 1,
                s = Ext.fly(e).parent(".item");
            this.expandRemainItems(s, this.groupedData[i])
        }
    },
    expandRemainItems: function(t, e) {
        var i = t.child(".remain-items"),
            s = t.child(".expand-icon");
        e.expanded = !e.expanded, i && (i.setVisibilityMode(Ext.Element.DISPLAY), e.expanded ? (i.slideIn("t", {
            duration: .25,
            callback: this.afterExpandAnim.bind(this)
        }), s.addClass("expanded")) : (i.slideOut("t", {
            duration: .25,
            callback: this.afterExpandAnim.bind(this)
        }), s.removeClass("expanded")))
    },
    afterExpandAnim: function() {
        this.dataview.updateFleXcroll()
    },
    loadNotify: function() {
        this.sendWebAPI({
            api: "SYNO.Core.DSMNotify",
            version: 1,
            method: "notify",
            params: {
                action: "load"
            },
            callback: this.onHandleData,
            scope: this
        })
    },
    getTitleStr: function() {
        this.settingId = Ext.id();
        return String.format('<div class="sds-notify-setting-btn" id="{0}">&nbsp;</div><span class="x-panel-header-text" >{1}</span>', this.settingId, _T("dsmnotify", "title"))
    },
    showUnreadTag: function(t, e) {
        return t ? "" : e ? "<b>" : "</b>"
    },
    getTitle: function(t, e, i, s) {
        return SYNO.SDS.DSMNotify.Utils.getTitle(t, e, i, s)
    },
    getMsg: function(t, e, i, s) {
        return SYNO.SDS.DSMNotify.Utils.getMsg(t, e, i, s)
    },
    encodedMsg: function(t, e, i, s) {
        return Ext.util.Format.htmlEncode(this.getMsg(t, e, i, s))
    },
    encodedTitle: function(t, e, i, s) {
        return Ext.util.Format.htmlEncode(this.getTitle(t, e, i, s))
    },
    sortMsg: function(t, e) {
        if (!Ext.isObject(t) || "time" !== t.sortBy) {
            var i = e || t.items,
                s = t.priorityMap;
            i.sort(function(t, e) {
                var i = t.className,
                    n = e.className;
                return Ext.isEmpty(s[i]) && Ext.isEmpty(s[n]) ? 0 : Ext.isEmpty(s[i]) ? 1 : Ext.isEmpty(s[n]) ? -1 : s[i] - s[n]
            })
        }
    },
    sendNotify: function(t) {
        if (Ext.isArray(t)) {
            var e = t[0].time;
            Ext.each(t, function(t) {
                var i = SYNO.SDS.AppMgr.getByAppName(t.className);
                t.time <= this.lastSeen || i.length > 0 && !1 === i[0].shouldNotifyMsg(t.tag, t) || t.time > e || !0 !== SYNO.SDS.DSMNotify.Utils.isAppEnabled(t.className) || (e = t.time, SYNO.SDS.SystemTray.notifyVueMsg(t.className, this.getTitle(t.title, !1, t.className), SYNO.SDS.DSMNotify.Utils.appendPeriod(this.getMsg(t.msg, !1, t.className, t.fn)), null, t.isEncoded))
            }, this)
        }
    },
    onClickSetting: function() {
        SYNO.SDS.AppLaunch("SYNO.SDS.DSMNotify.Setting.Application"), this.hideBox()
    },
    onClickClear: function() {
        Ext.StoreMgr.get(this.storeId).removeAll(), this.hideBox(), SYNO.API.Request({
            api: "SYNO.Core.DSMNotify",
            method: "notify",
            version: 1,
            params: {
                action: "apply",
                clean: "all"
            },
            scope: this,
            callback: function(t, e, i, s) {
                t && (SYNO.SDS.UserSettings.setProperty(this.module.jsConfig.jsID, "lastRead", 0), SYNO.SDS.StatusNotifier.fireEvent("notificationPanelClearAll"))
            }
        }), this.currentData = null
    },
    onClickShowAll: function() {
        this.showAllDialog && !0 === this.showAllDialog.hidden && (this.showAllDialog.destroy(), this.showAllDialog = null), this.showAllDialog || (this.showAllDialog = new SYNO.SDS.DSMNotify.ShowAllDialog({
            appInstance: this.module.appInstance
        })), this.showAllDialog.open(), this.hideBox()
    },
    getItemKey: function(t) {
        var e = t.className ? t.className : "",
            i = "";
        return Array.isArray(t.msg) && t.msg.length > 0 && (i = t.msg[0].hashCode()), e + ":" + t.title + ":" + (i || t.key)
    },
    getUnreadNum: function() {
        for (var t = 0, e = 0; e < this.currentData.total; e++) this.currentData.items[e].time > this.lastRead && t++;
        return t
    },
    getGroupedData: function() {
        var t = Object.create(null),
            e = [];
        if (!this.currentData || 0 === this.currentData.total) return this.clearAllBtn.setDisabled(!0), e;
        this.clearAllBtn.setDisabled(!1);
        for (var i = 0; i < this.currentData.total; i++) {
            var s = this.currentData.items[i],
                n = this.getItemKey(s);
            t[n] || (t[n] = {});
            var a = t[n];
            s.time > this.lastRead && (s.unread = !0, a.unread = !0), a.title = s.title, a.className = s.className, a.items || (a.items = []), a.items.push(s)
        }
        for (var o in t) e.push({
            className: t[o].className,
            title: t[o].title,
            firstItem: t[o].items[0],
            remainItems: t[o].items.slice(1, t[o].items.length),
            items: t[o].items,
            unread: t[o].unread
        });
        return e
    },
    onShow: function() {
        if (!this.isFirstDataGetted) return !1;
        this.groupedData = this.getGroupedData(), this.lastRead = this.lastSeen, SYNO.SDS.UserSettings.setProperty(this.module.jsConfig.jsID, "lastRead", this.lastRead), SYNO.SDS.DSMNotify.Panel.superclass.onShow.apply(this, arguments);
        var t = _T("common", "show_all");
        this.currentUnreadNum > this.maxUnreadNum && (t = _T("common", "unread").replace("{@}", this.currentUnreadNum - this.maxUnreadNum)), Ext.getCmp(this.showAllBtnId).setText(t), Ext.isEmpty(this.currentData) || Ext.StoreMgr.get(this.storeId).loadData(this.groupedData), this.setHeight(Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight() - this.paddingBottom), this.badge && this.badge.setNum(0)
    },
    onHandleData: function(t, e, i, s) {
        if (Ext.isArray(e.items) && e.items.length) {
            var n = !0,
                a = function(t, e, i) {
                    /\{\d+\}/.test(e) && (e = window.escape(e));
                    var s = new RegExp(e, "g");
                    return s.test(t) ? (n = !0, t.replace(s, i)) : t
                };
            e.items = e.items.map(function(t) {
                t.key = t.title, t.msgArray = t.msg;
                var e = {};
                window.SYNO_Notification_Strings[t.key] && (e = t.msg && 0 < t.msg.length ? JSON.parse(t.msg[0]) : {}, t.title = window.SYNO_Notification_Strings[t.key].title, t.msg = window.SYNO_Notification_Strings[t.key].msg, t.level = window.SYNO_Notification_Strings[t.key].level), n = !0, t.msg = SYNO.SDS.DSMNotify.Utils.concatControllerPrefix(t.msg, e, t.className);
                for (var i = 0; i < 5 && n; ++i)
                    for (var s in n = !1, e)
                        if (e.hasOwnProperty(s)) {
                            var o = SYNO.SDS.DSMNotify.Utils.getLocalizedString(e[s], t.className);
                            t.title = a(t.title, s, o), t.msg = a(t.msg, s, o), t.level = t.level ? t.level : "NOTIFICATION_INFO"
                        } return t
            })
        }
        this.isFirstDataGetted ? this.onPaddingData(t, e, i, s) : this.onFirstData(t, e, i, s)
    },
    onFirstData: function(t, e, i, s) {
        if (t) {
            var n = {
                data: e
            };
            if (this.isFirstDataGetted = !0, this.module.taskButton.enable(), this.currentData = n.data, Ext.isArray(n.data.items) && n.data.items.length) {
                this.lastSeen = n.data.newestMsgTime;
                var a = this.getUnreadNum();
                !_S("demo_mode") && a > 0 && Ext.defer(this.updateUnreadNumber, 500, this, [a])
            }
            this.updateGroupSettingsMTime(n.data)
        }
    },
    onPaddingData: function(t, e, i, s) {
        if (t) {
            var n = e;
            if (this.updateGroupSettingsMTime(n), Ext.isArray(n.items)) {
                if (0 === n.items.length) return Ext.StoreMgr.get(this.storeId).removeAll(), this.hideBox(!0), void(this.currentData = null);
                this.nowSec = (new Date).getTime() / 1e3, this.sendNotify(n.items), n.newestMsgTime > this.lastSeen && (this.lastSeen = n.newestMsgTime), this.currentData = n, this.isVisible() ? Ext.StoreMgr.get(this.storeId).loadData(this.getGroupedData()) : Ext.defer(this.updateUnreadNumber, 500, this, [this.getUnreadNum()])
            }
        }
    },
    getCurrentTime: function() {
        return Ext.isNumber(this.nowSec) ? this.nowSec : (new Date).getTime() / 1e3
    },
    updateGroupSettingsMTime: function(t) {
        t && t.admingrpsetmtime && SYNO.SDS.GroupSettings.reload(t.admingrpsetmtime)
    },
    updateUnreadNumber: function(t) {
        this.badge ? this.badge && this.badge.updateBadgePos() : (this.badge = new SYNO.SDS.Utils.Notify.Badge({
            disableAnchor: !0,
            badgeClassName: "sds-notify-badge-num badge-fix-position",
            renderTo: this.module.taskButton.btnEl
        }), this.module.taskButton.badge = this.badge), this.badge.badgeNum != t && this.badge.setNum(t)
    },
    hideBox: function(t) {
        this.module.taskButton.toggle(!1, !0), this.hide(), this.tempData && (this.onHandleData(!0, this.tempData), this.tempData = null)
    }
});
