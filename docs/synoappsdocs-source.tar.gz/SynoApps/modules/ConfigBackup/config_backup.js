/* eslint-disable */
/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.ConfigBackup
 * ConfigBackup class
 *
 */
 
Ext.define("SYNO.SDS.ConfigBackup", function(e) {
        function t(e) {
            var n = null;
            return Ext.isObject(e) && e.code ? t(e.code) : (Ext.iterate(i, function(t, i) {
                if (e === i[0]) return n = i[1], Ext.isObject(n) && (!n.text && n.text_param && (n.text = n.text_param), n.text || (n.text = _T("comon", "error_system"))), !1
            }), n)
        }

        function n(e, t) {
            var n = [],
                i = !1,
                o = e.text_param || e.text;
            return t ? Ext.isArray(t) && t.length > 0 ? String.format.apply(String, [o].concat(t)) : Ext.isObject(t) && (i = !0, Ext.each(e.replace_keys, function(e) {
                if (!t.hasOwnProperty(e)) return i = !1, !1;
                n.push(t[e])
            }), i) ? String.format.apply(String, [o].concat(n)) : e.text : e.text
        }
        var i = {
                ERR_INTERNAL_ERROR: [4401, _T("common", "error_system")],
                ERR_SNAPSHOT_RESTORING: [4407, _T("share", "share_snapshot_restore_running")],
                ERR_RESTORING: [4408, _T("backup", "is_restoring")],
                ERR_BACKING_UP_RESTORING: [4409, _T("backup", "is_backing_up_restoring")],
                ERR_CONFIG_OPERATE_ADMIN: [4416, _T("confbackup", "confbkp_operating_user")],
                ERR_CONFIG_VERSION_WRONG: [4428, _T("confbackup", "confbkp_failed_get_conf_file")],
                ERR_CONFIG_VERSION_FUTURE: [4429, _T("confbackup", "confbkp_error_version")],
                ERR_RESTORE_VOLUME_BUILDING: [4431, _T("common", "err_creating_volume")],
                ERR_CONFIG_NO_SPACE: [4436, _T("confbackup", "upload_err_no_space")],
                ERR_CONFIG_WRONG_FORMAT: [4437, _T("confbackup", "upload_err_format")],
                ERR_CONFIG_PORT_CONFLICT: [4438, _T("confbackup", "confbkp_port_conflict")],
                ERR_CONFIG_SERVICE_FAIL: [4439, _T("confbackup", "import_fail")],
                ERR_DATA_SESSION_EXPIRED: [4454, _T("confbackup", "session_expired")],
                ERR_AUTOCONF_NETWORK: [4455, _T("confbackup", "network_issue")],
                ERR_AUTOCONF_PASSWORD_INVALID: [4456, _T("confbackup", "invalid_password")],
                ERR_AUTOCONF_PRIKEY_INVALID: [4457, _T("confbackup", "invalid_encryption_key")],
                ERR_AUTOCONF_ACCOUNT_INVALID: [4458, _T("license", "license_result_login_fail")],
                ERR_CONFIG_VERSION_OTHER_OS: [4474, {
                    text_param: _T("confbackup", "confbkp_error_other_os"),
                    replace_keys: ["os_name"]
                }],
                ERR_USER_EXCEED_MAX: [4478, {
                    text: _T("confbackup", "confbkp_user_exceed_max"),
                    text_param: _T("confbackup", "confbkp_user_exceed_max_param"),
                    replace_keys: ["max_user_account"]
                }],
                ERR_GROUP_EXCEED_MAX: [4479, {
                    text: _T("confbackup", "confbkp_group_exceed_max"),
                    text_param: _T("confbackup", "confbkp_group_exceed_max_param"),
                    replace_keys: ["max_group_account"]
                }]
            },
            o = {};
        Ext.iterate(i, function(e, t) {
            o[e] = t[0]
        }), o.getErrorString = function(e, i) {
            if (Ext.isObject(e) && e.code) return o.getErrorString(e.code, e.errors);
            var r = t(e);
            return r ? Ext.isString(r) ? r : n(r, i) : _T("common", "error_system")
        }, o.isConfigError = function(e) {
            return !!t(e)
        }, o.converLanString = function(e, t) {
            var n, i = /^[.a-zA-Z0-9_-]+(:[a-zA-Z0-9_-]+){1,2}$/;
            return i.test(e) ? (n = e.split(":"), 2 === n.length ? _T(n[0], n[1]) : _TT(n[0], n[1], n[2])) : t || ""
        };
        var r = {
            err_not_support_enc: _T("backup", "err_not_support_enc"),
            err_not_support_acl: _T("backup", "err_not_support_acl"),
            err_not_valid_fs: _T("backup", "err_not_valid_fs"),
            err_share_not_writable: _T("backup", "err_share_not_writable"),
            err_share_unmounted: _T("backup", "err_share_unmounted"),
            err_share_acl_to_not_acl: _T("backup", "err_share_acl_to_not_acl"),
            err_share_source_conflict: _T("backup", "err_share_source_conflict"),
            err_peta_rename_same: _T("backup", "err_peta_share_rename_same"),
            err_peta_rename_different: _T("backup", "err_peta_share_rename_different")
        };
        o.getShareErrorString = function(e, t) {
            var n = r[e];
            return "err_peta_rename_same" == e && (n = String.format(n, "<b>" + t + "</b>")), n
        };
        var s = {
            warn_enc_current_not_exist: _T("backup", "warn_enc_current_not_exist"),
            warn_not_acl_to_acl: _T("backup", "warn_not_acl_to_acl"),
            warn_enc_current_not_enc: _T("backup", "warn_enc_current_not_enc"),
            warn_peta_current_not_exist: _T("backup", "warn_petashare_current_not_exist"),
            warn_peta_current_not_peta: _T("backup", "warn_petashare_current_not_peta"),
            warn_c2_current_not_exist: _T("backup", "warn_c2_current_not_exist"),
            warn_c2_to_not_c2: _T("backup", "warn_c2_to_not_c2"),
            warn_not_c2_to_c2: _T("backup", "warn_not_c2_to_c2")
        };
        return o.getShareWarningString = function(e) {
            var t = "";
            for (var n in e) e.hasOwnProperty(n) && s.hasOwnProperty(n) && (t += String.format(s[n], "<b>" + e[n].join(", ") + "</b>"), t += "<br/>");
            return "" !== t && (t += _T("backup", "are_you_sure_to_continue")), t
        }, o.ConfigurationField = {
            FILE_SHARING: "file_sharing",
            CONNECTIVITY: "connectivity",
            SYSTEM: "system",
            SERVICE: "service"
        }, o.getConfigurationFieldString = function(e) {
            switch (e) {
                case o.ConfigurationField.FILE_SHARING:
                    return _T("tree", "node_fileserv");
                case o.ConfigurationField.CONNECTIVITY:
                    return _T("tree", "node_connection");
                case o.ConfigurationField.SYSTEM:
                    return _T("tree", "node_server");
                case o.ConfigurationField.SERVICE:
                    return _T("tree", "services");
                default:
                    return ""
            }
        }, {
            statics: o
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.BasicTreePanel", {
        extend: "SYNO.ux.TreePanel",
        constructor: function(e) {
            var t = Ext.apply({
                useArrows: !0,
                autoScroll: !0,
                containerScroll: !0,
                bodyStyle: "overflow-x: hidden;overflow-y:auto;padding: 8px 12px 8px 8px;",
                enableDD: !1
            }, e);
            return this.callParent([t])
        },
        initEvents: function() {
            var e = this.callParent(arguments);
            return this.mon(this, "checkchange", this.onCheckChange, this), this.mon(this, "expandnode", this.onExpandNode, this), e
        },
        getCheckedSubTreeRoot: function(e) {
            var t = [],
                n = function(e) {
                    e.eachChild(function(e) {
                        var i = e.getUI() || {};
                        Ext.isFunction(i.getCheckValue) && (!0 === i.getCheckValue() ? t.push(e) : "gray" === i.getCheckValue() && n(e))
                    })
                };
            return n(e || this.root), t
        },
        onCheckChange: function(e, t) {
            var n, i, o, r = function(e) {
                    var t = 0,
                        n = 0,
                        i = 0;
                    return e.eachChild(function(e) {
                        var o = e.getUI() || {};
                        !o.checkbox || !Ext.isFunction(o.getCheckValue) || Ext.isFunction(o.isDisabled) && o.isDisabled() || (!0 === o.getCheckValue() ? n += 1 : !1 === o.getCheckValue() && (i += 1), t += 1)
                    }), 0 === t ? e.getUI().getCheckValue() : n === t || i !== t && "gray"
                },
                s = function(e) {
                    var t = Ext.apply({}, e.attributes.depend);
                    return Ext.applyIf(t, {
                        parent: !1,
                        children: !0
                    })
                };
            for (o = s(e), !0 === o.children && (!0 === t ? e.eachChild(function(e) {
                    var t = e.getUI();
                    !t || !Ext.isFunction(t.setCheckValue) || Ext.isFunction(t.isDisabled) && t.isDisabled() || t.setCheckValue(!0)
                }, this) : !1 === t && e.eachChild(function(e) {
                    var t = e.getUI();
                    !t || !Ext.isFunction(t.setCheckValue) || Ext.isFunction(t.isDisabled) && t.isDisabled() || t.setCheckValue(!1)
                }, this)), n = e.parentNode; n;) i = n.getUI(), i && Ext.isFunction(i.getCheckValue) ? (!0 === o.parent ? n.attributes.checked = r(n) : !0 === t && !1 === n.attributes.checked ? n.attributes.checked = "gray" : !1 === t && (n.attributes.checked = r(n)), i.syncCheckCssClass(), o = s(n), n = n.parentNode) : (o = s(n), n = n.parentNode)
        },
        onExpandNode: function(e) {
            var t = e.getUI(),
                n = Ext.apply({}, e.attributes.depend);
            Ext.applyIf(n, {
                parent: !1,
                children: !0
            }), t && Ext.isFunction(t.getCheckValue) && (!0 === n.children && !0 === t.getCheckValue() && e.eachChild(function(e) {
                (t = e.getUI()) && Ext.isFunction(t.isDisabled) && !t.isDisabled() && Ext.isFunction(t.setCheckValue) && t.setCheckValue(!0)
            }, this), !0 === n.children && !0 === e.attributes.network_category && e.eachChild(function(e) {
                var t = e.getUI();
                t && new Ext.Element(t.elNode).mask()
            }, this))
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.Restore.ShareConflictWindow", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(e) {
            var t = this.fillConfig(e);
            return this.callParent([t])
        },
        fillConfig: function(e) {
            var t = new SYNO.SDS.ConfigBackup.ConflictSharePanel({
                    owner: this,
                    conflict_share: e.conflict_share
                }),
                n = {
                    title: _T("confbackup", "confbkp_share_conflict_title"),
                    resizable: !1,
                    width: 600,
                    height: 450,
                    buttons: [{
                        xtype: "syno_button",
                        text: _T("common", "cancel"),
                        scope: this,
                        handler: this.close
                    }, {
                        xtype: "syno_button",
                        text: _T("common", "ok"),
                        btnStyle: "blue",
                        scope: this,
                        handler: function() {
                            e.nextFunc.apply(e.nextScope, e.nextParams), this.close()
                        }
                    }],
                    items: [t]
                };
            return Ext.apply(n, e), n
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.ConflictSharePanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            var t = this.fillConfig(e);
            return this.callParent([t])
        },
        createFieldSet: function(e, t, n, i) {
            var o = new Ext.XTemplate('<dl class="syno-config-backup-task-list-row">', String.format('<div class="syno-config-backup-task-list-column blue-status" style="width:50%">{0}</div>', n), String.format('<div class="syno-config-backup-task-list-column blue-status" style="width:50%">{0}</div>', i), '<div class="x-clear"></div>', "</dl>", '<tpl for=".">', '<dl class="syno-config-backup-task-list-row">', '<div class="syno-config-backup-task-list-column" style="width:50%">', '<tpl if="encrypted==\'true\'"><div class="syno-config-backup-share-enc-true"></div></tpl>', '<tpl if="encrypted==\'false\'"><div class="syno-config-backup-share-enc-false"></div></tpl>', "{name_current:htmlEncode}", "</div>", '<div class="syno-config-backup-task-list-column" style="width:50%">', '<tpl if="encrypted!=\'NA\'"><div class="syno-config-backup-share-enc-true"></div></tpl>', "{name_after:htmlEncode}", "</div>", '<div class="x-clear"></div>', "</dl>", "</tpl>"),
                r = new Ext.data.ArrayStore({
                    fields: ["name_current", "name_after", "encrypted"]
                }),
                s = [];
            return Ext.each(e, function(e) {
                var t = [];
                t.push(e.name_current), t.push(e.name_after), e.is_encryption && e.is_encrypted ? t.push("true") : e.is_encryption ? t.push("false") : t.push("NA"), s.push(t)
            }), r.loadData(s), new Ext.Container({
                title: t,
                items: [{
                    indent: 1,
                    xtype: "dataview",
                    store: r,
                    tpl: o,
                    autoHeight: !0
                }]
            })
        },
        fillConfig: function(e) {
            var t = e.conflict_share,
                n = [];
            return n.push({
                xtype: "syno_displayfield",
                hideLabel: !0,
                value: _T("confbackup", "confbkp_share_conflict_description")
            }), t && t.length > 0 && n.push(this.createFieldSet(t, _T("confbackup", "confbkp_share_conflict_list"), _T("confbackup", "confbkp_share_name_current"), _T("confbackup", "confbkp_share_name_after"))), Ext.apply({
                height: 334,
                bodyStyle: "padding: 0px",
                items: [n]
            }, e)
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.Restore.ConflictWindow", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(e) {
            var t = this.fillConfig(e);
            return this.callParent([t])
        },
        fillConfig: function(e) {
            var t = new SYNO.SDS.ConfigBackup.ConflictPanel({
                    owner: this,
                    conflict_user: e.conflict_user,
                    conflict_group: e.conflict_group
                }),
                n = {
                    title: _T("confbackup", "confbkp_user_group_conflict_title"),
                    resizable: !1,
                    width: 600,
                    height: 450,
                    buttons: [{
                        xtype: "syno_button",
                        text: _T("common", "cancel"),
                        scope: this,
                        handler: this.close
                    }, {
                        xtype: "syno_button",
                        text: _T("common", "ok"),
                        btnStyle: "blue",
                        scope: this,
                        handler: function() {
                            e.nextFunc.apply(e.nextScope, e.nextParams), this.close()
                        }
                    }],
                    items: [t]
                };
            return Ext.apply(n, e), n
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.ConflictPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            var t = this.fillConfig(e);
            return this.callParent([t])
        },
        createFieldSet: function(e, t, n, i) {
            var o = new Ext.XTemplate('<dl class="syno-config-backup-task-list-row">', String.format('<div class="syno-config-backup-task-list-column blue-status" style="width:50%">{0}</div>', n), String.format('<div class="syno-config-backup-task-list-column blue-status" style="width:50%">{0}</div>', i), '<div class="x-clear"></div>', "</dl>", '<tpl for=".">', '<dl class="syno-config-backup-task-list-row">', '<div class="syno-config-backup-task-list-column" style="width:50%">{name_current:htmlEncode}</div>', '<div class="syno-config-backup-task-list-column" style="width:50%">{name_after:htmlEncode}</div>', '<div class="x-clear"></div>', "</dl>", "</tpl>"),
                r = new Ext.data.ArrayStore({
                    fields: ["name_current", "name_after"]
                }),
                s = [];
            return Ext.each(e, function(e) {
                var t = [];
                t.push(e.name_current), t.push(e.name_after), s.push(t)
            }), r.loadData(s), new SYNO.ux.FieldSet({
                title: t,
                items: [{
                    indent: 1,
                    xtype: "dataview",
                    store: r,
                    tpl: o,
                    autoHeight: !0
                }]
            })
        },
        fillConfig: function(e) {
            var t = e.conflict_user,
                n = e.conflict_group,
                i = [];
            return i.push({
                xtype: "syno_displayfield",
                hideLabel: !0,
                value: _T("confbackup", "confbkp_user_group_conflict_desc")
            }), t && t.length > 0 && i.push(this.createFieldSet(t, _T("confbackup", "confbkp_user_conflict_list"), _T("confbackup", "confbkp_user_name_current"), _T("confbackup", "confbkp_user_name_after"))), n && n.length > 0 && i.push(this.createFieldSet(n, _T("confbackup", "confbkp_group_conflict_list"), _T("confbackup", "confbkp_group_name_current"), _T("confbackup", "confbkp_group_name_after"))), Ext.apply({
                height: 365,
                items: [i]
            }, e)
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.Restore.ConfigTreePanel", {
        extend: "SYNO.SDS.ConfigBackup.BasicTreePanel",
        constructor: function(e) {
            this.dss_version = e.dss_version, this.dss_path = e.dss_path, this.dss_id = e.dss_id, this.overwrite = e.overwrite;
            var t = Ext.apply({
                useGradient: !1,
                cls: "syno-config-backup-treepanel",
                bwrapStyle: "padding-top: 0px"
            }, e);
            return this.callParent([t])
        },
        getConfigRootText: function(e) {
            return "confbkp_v5" === e || "confbkp_v4" === e || "confbkp_v3" === e ? _T("confbackup", "confbkp_all") : "confbkp_v1" === e || "confbkp_v2" === e ? _T("confbackup", "confbkp_user_group") : ""
        },
        createConfigNodeFn: function(e) {
            var t = function(e, t, n) {
                var i = SYNO.SDS.ConfigBackup.converLanString(e[t]);
                i ? e[t] = i : e.hasOwnProperty(n) && (i = SYNO.SDS.ConfigBackup.converLanString(e[n]), i && (e[t] = i), delete e[n])
            };
            t(e, "text"), "children" in e || (e.leaf = !0), e.qtip = e.text, "info" === e.type ? (e.value_multi && (t(e, "value_multi", "value_multi_default"), e.value = e.value_multi), e.value && (e.qtip = e.text + " : " + e.value, e.text = e.text + ' : <element class="green-status">' + e.value + "</element>")) : e.checked = !1, !e.leaf && e.id && 0 <= e.id.indexOf("network_interface") && (e.network_category = !0)
        },
        getCheckedService: function(e) {
            var t = [],
                n = function(e) {
                    e.eachChild(function(e) {
                        var i = e.getUI() || {};
                        Ext.isFunction(i.getCheckValue) && (!0 === i.getCheckValue() ? "category" === e.attributes.type ? Ext.each(e.attributes.children, function(e) {
                            t.push(e)
                        }) : t.push(e) : "gray" === i.getCheckValue() && n(e))
                    })
                };
            return n(e || this.root), t
        },
        getRestoreServiceList: function() {
            var e = [];
            return !0 === this.root.getUI().getCheckValue() && this.dsm_version < 4980 ? e.push("all") : Ext.each(this.getCheckedService(), function(t) {
                e.push(t.id)
            }), e
        },
        isRestoreConfig: function() {
            return !1 !== this.getNodeById("config_root").getUI().getCheckValue()
        },
        showShareConflictWindow: function(e, t) {
            if (e && e.length > 0) {
                new SYNO.SDS.ConfigBackup.Restore.ShareConflictWindow({
                    conflict_share: e,
                    nextFunc: this.checkRenameLeaveAdmin,
                    nextScope: this,
                    nextParams: t
                }).open()
            } else this.checkRenameLeaveAdmin.apply(this, t)
        },
        showUGConflictWindow: function(e, t, n, i) {
            if (e && e.length > 0 || t && t.length > 0) {
                new SYNO.SDS.ConfigBackup.Restore.ConflictWindow({
                    conflict_user: e,
                    conflict_group: t,
                    nextFunc: this.showShareConflictWindow,
                    nextScope: this,
                    nextParams: [n, i]
                }).open()
            } else this.showShareConflictWindow(n, i)
        },
        checkUGConflict: function(e, t, n, i) {
            if (!1 === this.isRestoreConfig()) return void t.call(n);
            void 0 === i && (i = !1), n.setStatusBusy(), n.sendWebAPI({
                api: "SYNO.Backup.Config.Restore",
                method: "list_conflict",
                version: 1,
                params: {
                    types: i ? ["user", "group", "share"] : ["user", "group"],
                    dss_path: this.dss_path,
                    dss_id: this.dss_id,
                    overwrite: e,
                    category_or_service_ids: this.getRestoreServiceList()
                },
                callback: function(o, r) {
                    if (n.clearStatusBusy(), !o || !r) return void n.getMsgBox().alert(_T("tree", "leaf_bkp"), SYNO.SDS.ConfigBackup.getErrorString(r), function() {
                        SYNO.SDS.ConfigBackup.ERR_DATA_SESSION_EXPIRED === r.code && n.close()
                    });
                    this.showUGConflictWindow(r.user, r.group, r.share, [e, t, n, i])
                },
                scope: this
            })
        },
        checkRenameLeaveAdmin: function(e, t, n, i) {
            if (!1 !== this.isRestoreConfig()) {
                var o, r = this.getRestoreServiceList();
                o = i ? -1 !== r.indexOf("administration") || -1 !== r.indexOf("router_cp") || -1 !== r.indexOf("pctc") ? _T("confbackup", "upload_confirm_restart_network") : _T("confbackup", "upload_confirm_minutes") : _T("confbackup", "upload_confirm"), n.setStatusBusy(), n.sendWebAPI({
                    api: "SYNO.Backup.Config.Restore",
                    method: "check",
                    version: 1,
                    params: {
                        dss_path: this.dss_path,
                        dss_id: this.dss_id,
                        overwrite: e,
                        category_or_service_ids: this.getRestoreServiceList()
                    },
                    callback: function(e, i) {
                        n.clearStatusBusy(), e ? n.getMsgBox().confirmDelete(_T("tree", "leaf_bkp"), o, function(e) {
                            "yes" === e && t.call(n)
                        }, this, {
                            yes: {
                                text: _T("common", "yes"),
                                btnStyle: "red"
                            },
                            no: !0
                        }) : n.getMsgBox().alert(_T("tree", "leaf_bkp"), SYNO.SDS.ConfigBackup.getErrorString(i))
                    },
                    scope: this
                })
            }
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.TriTreeNodeUI", {
        extend: "Ext.tree.TreeNodeUI",
        renderElements: function(e, t, n, i) {
            this.indentMarkup = e.parentNode ? e.parentNode.ui.getChildIndent() : "";
            var o, r = '<img alt="" src="' + this.emptyIcon + '" class="syno-config-backup-tree-node-share-overwrite" ext:qtip="' + _T("confbackup", "confbkp_share_overwrite") + '"/>',
                s = '<img alt="" src="' + this.emptyIcon + '" class="syno-config-backup-tree-node-share-rename" ext:qtip="' + _T("confbackup", "confbkp_share_rename") + '"/>',
                a = '<img alt="" src="' + this.emptyIcon + '" class="syno-config-backup-tree-node-same-volume" ext:qtip="' + _T("backup", "warn_backup_same_volume") + '"/>',
                c = Ext.isBoolean(t.checked) || "gray" === t.checked,
                u = Ext.util.Format.htmlEncode,
                l = t.input,
                d = this.getHref(t.href),
                p = ['<li class="x-tree-node syno-config-backup-tri-tree-node"><div ext:tree-node-id="', u(e.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', t.cls, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', c ? '<img alt="" src="' + this.emptyIcon + '" class="syno-config-backup-tri-tree-node-cb syno-ux-checkbox-icon" />' : "", '<img alt="" src="', t.icon || this.emptyIcon, '" class="x-tree-node-icon', t.icon ? " x-tree-node-inline-icon" : "", t.iconCls ? " " + t.iconCls : "", '" unselectable="on" ', (t.icon || t.iconCls ? "" : 'style="display: none;"') + "/>", '<a hidefocus="on" class="x-tree-node-anchor" href="', d, '" tabIndex="1" ', t.hrefTarget ? ' target="' + t.hrefTarget + '"' : "", '><span unselectable="on">', e.text, "</span></a>", "rename" === t.shareConflict ? s : "", "overwrite" === t.shareConflict ? r : "", a, "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
            !0 !== i && e.nextSibling && (o = e.nextSibling.ui.getEl()) ? this.wrap = Ext.DomHelper.insertHtml("beforeBegin", o, p) : this.wrap = Ext.DomHelper.insertHtml("beforeEnd", n, p), this.elNode = this.wrap.childNodes[0], this.ctNode = this.wrap.childNodes[1];
            var h = this.elNode.childNodes,
                f = 0;
            this.indentNode = h[f++], this.ecNode = h[f++], c && (this.checkbox = h[f++]), this.iconNode = h[f++], this.anchor = h[f++], this.textNode = this.anchor.firstChild, "rename" === t.shareConflict && (this.renameNode = h[f++]), "overwrite" === t.shareConflict && (this.overwriteNode = h[f++]), this.volumeWarnNode = h[f++], l && (this.createInputField(l, t, this.elNode), f++), c && this.syncCheckCssClass(), e.on("disabledchange", this.onDisabled, this)
        },
        onIdChange: function(e) {
            var t = Ext.util.Format.htmlEncode;
            this.rendered && this.elNode.setAttribute("ext:tree-node-id", t(e))
        },
        createInputField: function(e, t, n) {
            var i = e;
            switch (Ext.isObject(e) ? (this.inputConfig = Ext.apply({}, e), i = e.xtype || "textfield", delete e.xtype) : this.inputConfig = {}, Ext.isDefined(t.value) && (this.inputConfig.value = t.value), this.inputConfig.renderTo = n, i) {
                case "textfield":
                    this.input = new SYNO.ux.TextField(this.inputConfig);
                    break;
                case "numberfield":
                    this.input = new SYNO.ux.NumberField(this.inputConfig)
            }
        },
        initEvent: function() {
            var e = this.callParent(arguments);
            return this.checkbox && this.initCheckEvent(), e
        },
        isChecked: function() {
            return this.getCheckValue()
        },
        isDisabled: function() {
            return !0 === this.node.disabled
        },
        toggleCheck: function() {
            var e = this.checkbox;
            !0 !== this.node.disabled && e && this.setCheckValue(!this.getCheckValue())
        },
        onClick: function(e) {
            if (!e.getTarget(".x-form-field")) return e.getTarget(".syno-config-backup-tri-tree-node-cb") && this.toggleCheck(), this.callParent(arguments)
        },
        onDblClick: function(e) {
            e.preventDefault(), this.disabled || !1 !== this.fireEvent("beforedblclick", this.node, e) && (!this.animating && this.node.isExpandable() && this.node.toggle(), this.fireEvent("dblclick", this.node, e))
        },
        onDisabled: function(e, t) {
            this.input && (t ? this.input.disable() : this.input.enable()), this.checkbox && (t ? this.checkbox.classList.add("syno-ux-cb-disabled") : this.checkbox.classList.remove("syno-ux-cb-disabled"))
        },
        onCheckChange: function() {
            this.syncCheckCssClass(), this.fireEvent("checkchange", this.node, this.getCheckValue())
        },
        isValid: function() {
            return !!this.node.disabled || !(this.input && !this.input.isValid())
        },
        getInputValue: function() {
            if (this.input && !this.disabled) return this.input.getValue()
        },
        setInputValue: function(e) {
            this.input && this.input.setValue(e)
        },
        getCheckValue: function() {
            return this.node.attributes.checked
        },
        setCheckValue: function(e) {
            this.node.disabled || e !== this.getCheckValue() && (e = "false" !== e && "off" !== e && "0" !== e && ("gray" === e ? "gray" : !!e), this.node.attributes.checked = e, this.onCheckChange())
        },
        syncCheckCssClass: function() {
            var e = this.getCheckValue();
            this.checkbox && (Ext.each(["checked", "grayed", "disabled"], function(e) {
                this.checkbox.classList.remove("syno-ux-cb-" + e)
            }, this), this.volumeWarnNode && this.volumeWarnNode.classList.remove("syno-ux-cb-selected"), !0 === e ? (this.checkbox.classList.add("syno-ux-cb-checked"), this.volumeWarnNode && this.volumeWarnNode.classList.add("syno-ux-cb-selected")) : "gray" === e && (this.checkbox.classList.add("syno-ux-cb-grayed"), this.volumeWarnNode && this.volumeWarnNode.classList.add("syno-ux-cb-selected")), this.node.disabled && this.checkbox.classList.add("syno-ux-cb-disabled"))
        },
        initCheckEvent: function() {
            this.checkbox.addListener("mouseover", this.onCheckMouseover, this), this.checkbox.addListener("mouseout", this.onCheckMouseout, this), this.checkbox.addListener("focus", this.onCheckIconfocus, this), this.checkbox.addListener("blur", this.onCheckIconblur, this)
        },
        onCheckMouseover: function() {
            this.checkbox.classList.add("syno-ux-cb-hover")
        },
        onCheckMouseout: function() {
            this.checkbox.classList.remove("syno-ux-cb-hover")
        },
        onCheckIconfocus: function() {
            this.checkbox.classList.add("syno-ux-cb-focus")
        },
        onCheckIconblur: function() {
            this.checkbox.classList.remove("syno-ux-cb-focus")
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.TriTreeDisableCheckNodeUI", {
        extend: "SYNO.SDS.ConfigBackup.TriTreeNodeUI",
        checkShareNode: function(e, t, n) {
            e.dependAppRows && 0 !== e.dependAppRows.length && Ext.each(e.dependAppRows, function(i) {
                i.get("checked") && (-1 === t.indexOf(e.id.substr(1)) && t.push(e.id.substr(1)), -1 === n.indexOf(i.get("name")) && (n.push(i.get("name")), this.node.appRowsToBeUnselected.push(i)), this.node.appGrid = e.dependGrid)
            }, this)
        },
        setCheckValue: function(e) {
            if (!0 !== e && !this.node.clickConfirmed) {
                this.node.appRowsToBeUnselected = [];
                var t, n = [],
                    i = [];
                if ("fm_root" === this.node.id) Ext.each(this.node.childNodes, function(e) {
                    this.checkShareNode(e, n, i)
                }, this);
                else {
                    var o = this.node.id.substr(1).split("/", 1)[0],
                        r = this.node.getOwnerTree().getNodeById("/" + o);
                    this.checkShareNode(r, n, i)
                }
                if (0 < i.length && 0 < n.length) return t = n[0].isBackup ? _T("backup", "unselect_share_alert_bkp") : _T("backup", "unselect_share_alert_restore"), t = String.format(t, n.join(", "), i.join(", ")), this.node.getOwnerTree().owner.getMsgBox().confirm("", t, function(e) {
                    "yes" === e && (this.node.clickConfirmed = !0, this.setCheckValue(!1))
                }, this), !1
            }
            this.node.clickConfirmed = !1, Ext.each(this.node.appRowsToBeUnselected, function(e) {
                e.set("checked", !1)
            }), this.node.appRowsToBeUnselected = [], this.node.appGrid && (this.node.appGrid.syncCheckedStatus(), delete this.node.appGrid), !e && this.node.disabled ? (this.node.disabled = !1, this.callParent(arguments), this.node.disabled = !0, this.syncCheckCssClass()) : this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.ConfigBackup.TreeLoader", {
        extend: "Ext.tree.TreeLoader",
        sendWebAPI: void 0,
        webapi: void 0,
        constructor: function() {
            var e = arguments[0];
            return e && e.webapi && (this.dataUrl = "dummy"), this.callParent(arguments)
        },
        requestData: function(e, t, n) {
            if (!1 !== this.fireEvent("beforeload", this, e, t))
                if (this.directFn) {
                    var i = this.getParams(e);
                    i.push(this.processDirectResponse.createDelegate(this, [{
                        callback: t,
                        node: e,
                        scope: n
                    }], !0)), this.directFn.apply(window, i)
                } else if (this.nodeData && -1 !== this.owner.fm_root_nodes.indexOf(e.id)) this.handleNodeData(e, this.nodeData, t, n);
            else if (Ext.isFunction(this.sendWebAPI)) {
                var o = Ext.apply({}, {
                    params: this.getParams(e),
                    argument: {
                        callback: t,
                        node: e,
                        scope: n
                    },
                    callback: this.handleWebAPIResponse,
                    scope: this
                }, this.webapi);
                this.transId = this.sendWebAPI(o)
            } else this.transId = Ext.Ajax.request({
                method: this.requestMethod,
                url: this.dataUrl || this.url,
                success: this.handleResponse,
                failure: this.handleFailure,
                scope: this,
                argument: {
                    callback: t,
                    node: e,
                    scope: n
                },
                params: this.getParams(e)
            });
            else this.runCallback(t, n || e, [])
        },
        handleNodeData: function(e, t, n, i) {
            Ext.isFunction(this.parseWebApiResponse) && (t = this.parseWebApiResponse.call(this, e, t)), e.beginUpdate();
            for (var o = 0, r = t.length; o < r; o++) {
                var s = this.createNode(t[o]);
                s && e.appendChild(s)
            }
            e.endUpdate(), this.runCallback(n, i || e, [e]), this.fireEvent("load", this, e, t)
        },
        handleWebAPIResponse: function(e, t, n, i) {
            var o = i.argument,
                r = o.node;
            if (this.transId = !1, e) {
                try {
                    Ext.isFunction(this.parseWebApiResponse) && (t = this.parseWebApiResponse.call(this, r, t)), r.beginUpdate();
                    for (var s = 0, a = t.length; s < a; s++)
                        if (!t[s].recycle) {
                            var c = this.createNode(t[s]);
                            c && r.appendChild(c)
                        } r.endUpdate(), this.runCallback(o.callback, o.scope || r, [r])
                } catch (e) {
                    return SYNO.Debug("tree loadexception"), this.fireEvent("loadexception", this, r, t), void this.runCallback(o.callback, o.scope || r, [r])
                }
                this.fireEvent("load", this, r, t)
            } else this.fireEvent("loadexception", this, r, t), this.runCallback(o.callback, o.scope || r, [r])
        },
        createNode: function(e) {
            if (e.uiProvider = "SYNO.SDS.ConfigBackup.TriTreeNodeUI", e.draggable = !1, !Ext.isFunction(this.createNodeFn) || !1 !== this.createNodeFn.call(this.createNodeScope || this, e)) {
                return this.callParent(arguments)
            }
        }
    }), SYNO.SDS.SystemConfigChecker = function() {
        return synowebapi.promises.request({
            api: "SYNO.Backup.Config.AutoBackup",
            version: 1,
            method: "list",
            params: {
                additional: ["volume_count", "installation_id"]
            }
        }).then(function(e) {
            var t = function() {
                    var e = _D("unique").split("_");
                    return 3 === e.length && 0 === e[2].indexOf("dva")
                }(),
                n = e.volume_count,
                i = !1;
            if (0 < e.total) {
                var o = function(e) {
                    var t = {},
                        n = e.split("@");
                    if (0 != n.length % 2) return t;
                    for (var i = 0; i < n.length;) t[n[i]] = n[i + 1], i += 2;
                    return t
                };
                Ext.each(e.versions, function(t) {
                    if (!t.error) {
                        if (o(t.name).id !== e.installation_id) return i = !0, !1
                    }
                })
            }
            return !t && n > 0 && i && SYNO.SDS.SystemTray.notifyVueCustomizeMsg("", new SYNO.SDS.ConfigBackup.SystemConfigTray), {
                isDVA: t,
                volume_count: n,
                has_config_data: i
            }
        }).catch(function(e) {})
    }, SYNO.SDS.SystemConfigChecker.register = function() {
        SYNO.SDS.ExecuteAfterFirstTime && SYNO.SDS.ExecuteAfterFirstTime.register("SYNO.SDS.SystemConfigChecker", SYNO.SDS.SystemConfigChecker)
    }, SYNO.SDS.SystemConfigChecker.register(),
    function(e) {
        function t(i) {
            if (n[i]) return n[i].exports;
            var o = n[i] = {
                i: i,
                l: !1,
                exports: {}
            };
            return e[i].call(o.exports, o, o.exports, t), o.l = !0, o.exports
        }
        var n = {};
        t.m = e, t.c = n, t.d = function(e, n, i) {
            t.o(e, n) || Object.defineProperty(e, n, {
                enumerable: !0,
                get: i
            })
        }, t.r = function(e) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(e, "__esModule", {
                value: !0
            })
        }, t.t = function(e, n) {
            if (1 & n && (e = t(e)), 8 & n) return e;
            if (4 & n && "object" == typeof e && e && e.__esModule) return e;
            var i = Object.create(null);
            if (t.r(i), Object.defineProperty(i, "default", {
                    enumerable: !0,
                    value: e
                }), 2 & n && "string" != typeof e)
                for (var o in e) t.d(i, o, function(t) {
                    return e[t]
                }.bind(null, o));
            return i
        }, t.n = function(e) {
            var n = e && e.__esModule ? function() {
                return e.default
            } : function() {
                return e
            };
            return t.d(n, "a", n), n
        }, t.o = function(e, t) {
            return Object.prototype.hasOwnProperty.call(e, t)
        }, t.p = "", t(t.s = 1)
    }([function(e, t) {
        e.exports = Vue
    }, function(e, t, n) {
        e.exports = n(8)
    }, function(e, t, n) {
        var i = n(3);
        "string" == typeof i && (i = [
            [e.i, i, ""]
        ]), i.locals && (e.exports = i.locals), (0, n(9).default)("3b654192", i, !1, {})
    }, function(e, t, n) {
        t = e.exports = n(4)(!1);
        var i = n(5),
            o = i(n(6)),
            r = i(n(7));
        t.push([e.i, ".syno-config-backup-tray-wrapper .syno-config-backup-tray-body{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.syno-config-backup-tray-wrapper .syno-config-backup-tray-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .syno-config-backup-tray-wrapper .syno-config-backup-tray-title,.syno-config-backup-tray-wrapper .syno-cjk .syno-config-backup-tray-title{font-weight:600}.syno-config-backup-tray-wrapper{position:relative;width:290px}.syno-config-backup-tray-wrapper .syno-config-backup-tray-icon{background-image:url(" + o + ");width:60px;height:60px;background-size:60px 60px;position:absolute;top:8px;left:12px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-config-backup-tray-wrapper .syno-config-backup-tray-icon{background-image:url(" + r + ');background-size:image-width("../images/1x/icn_noti_recovery.png") image-height("../images/1x/icn_noti_recovery.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-config-backup-tray-wrapper .syno-config-backup-tray-icon{background-image:url(' + r + ');background-size:image-width("../images/1x/icn_noti_recovery.png") image-height("../images/1x/icn_noti_recovery.png");outline:1px green dashed}}.syno-config-backup-tray-wrapper .syno-config-backup-tray-title{width:198px;padding-top:8px;padding-left:84px;color:#057FEB;line-height:20px}.syno-config-backup-tray-wrapper .syno-config-backup-tray-body{width:224px;padding-top:4px;padding-left:84px;font-size:13px;word-break:break-word;color:#414b55;line-height:20px}.syno-config-backup-tray-wrapper .syno-config-backup-tray-footer{padding-top:12px;padding-bottom:12px;height:28px;width:300px}.syno-config-backup-tray-wrapper .syno-config-backup-tray-footer .v-btn{float:right;border-radius:100px}\n', ""])
    }, function(e, t, n) {
        "use strict";
        e.exports = function(e) {
            var t = [];
            return t.toString = function() {
                return this.map(function(t) {
                    var n = function(e, t) {
                        var n = e[1] || "",
                            i = e[3];
                        if (!i) return n;
                        if (t && "function" == typeof btoa) {
                            var o = (r = i, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(r)))) + " */");
                            return [n].concat(i.sources.map(function(e) {
                                return "/*# sourceURL=" + i.sourceRoot + e + " */"
                            })).concat([o]).join("\n")
                        }
                        var r;
                        return [n].join("\n")
                    }(t, e);
                    return t[2] ? "@media " + t[2] + "{" + n + "}" : n
                }).join("")
            }, t.i = function(e, n) {
                "string" == typeof e && (e = [
                    [null, e, ""]
                ]);
                for (var i = {}, o = 0; o < this.length; o++) {
                    var r = this[o][0];
                    null != r && (i[r] = !0)
                }
                for (o = 0; o < e.length; o++) {
                    var s = e[o];
                    null != s[0] && i[s[0]] || (n && !s[2] ? s[2] = n : n && (s[2] = "(" + s[2] + ") and (" + n + ")"), t.push(s))
                }
            }, t
        }
    }, function(e, t, n) {
        "use strict";
        e.exports = function(e, t) {
            return "string" != typeof e ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), /["'() \t\n]/.test(e) || t ? '"' + e.replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"' : e)
        }
    }, function(e, t) {
        e.exports = "webman/modules/ConfigBackup/images/assets/178a9101aed15a8315de53ad69d299b3.png"
    }, function(e, t) {
        e.exports = "webman/modules/ConfigBackup/images/assets/084888b31a535e0ce975b6202b0dc4aa.png"
    }, function(e, t, n) {
        "use strict";
        n.r(t);
        var i = n(0),
            o = n.n(i),
            r = function() {
                var e = this,
                    t = e.$createElement,
                    n = e._self._c || t;
                return n("div", [n("v-notification", {
                    ref: "notification",
                    attrs: {
                        activeDuration: 0,
                        onClose: e.onClose
                    },
                    scopedSlots: e._u([{
                        key: "wrapper",
                        fn: function() {
                            return [n("div", {
                                staticClass: "syno-config-backup-tray-wrapper"
                            }, [n("div", {
                                staticClass: "syno-config-backup-tray-icon"
                            }), e._v(" "), n("div", {
                                staticClass: "syno-config-backup-tray-title",
                                domProps: {
                                    innerHTML: e._s(e.title)
                                }
                            }), e._v(" "), n("div", {
                                staticClass: "syno-config-backup-tray-body",
                                domProps: {
                                    innerHTML: e._s(e.body)
                                }
                            }), e._v(" "), n("div", {
                                staticClass: "syno-config-backup-tray-footer"
                            }, [n("v-button", {
                                attrs: {
                                    "syno-id": "syno-config-backup-restore-btn",
                                    type: "footbar",
                                    suffix: "blue"
                                },
                                on: {
                                    click: e.onClickRestore
                                }
                            }, [e._v(e._s(e.btnText))])], 1)])]
                        },
                        proxy: !0
                    }])
                })], 1)
            };
        r._withStripped = !0, n(2);
        var s = function(e, t, n, i, o, r, s, a) {
            var c, u = "function" == typeof e ? e.options : e;
            if (t && (u.render = t, u.staticRenderFns = n, u._compiled = !0), o && (c = o), c)
                if (u.functional) {
                    u._injectStyles = c;
                    var l = u.render;
                    u.render = function(e, t) {
                        return c.call(t), l(e, t)
                    }
                } else {
                    var d = u.beforeCreate;
                    u.beforeCreate = d ? [].concat(d, c) : [c]
                } return {
                exports: e,
                options: u
            }
        }({
            data: function() {
                return {
                    title: _T("confbackup", "autoconfbkp_restore_title"),
                    body: _T("confbackup", "autoconfbkp_restore_desc_short"),
                    onClose: function() {
                        new SYNO.SDS.MessageBoxV5({
                            maxWidth: 420,
                            modal: !1,
                            draggable: !1
                        }).getWrapper().confirm("", _T("confbackup", "autoconfbkp_restore_later_desc"), Ext.EmptyFn, this, {
                            ok: _T("welcome", "got_it")
                        })
                    },
                    btnText: _T("confbackup", "restore_now")
                }
            },
            methods: {
                onClickRestore: function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                        fn: "SYNO.SDS.AdminCenter.Update_Reset.Main",
                        tab: "ConfigTab",
                        open_wizard: !0,
                        is_login: !0
                    }), SYNO.SDS._SystemTrayMsgMgr.unregister(this.$refs.notification)
                }
            }
        }, r, [], 0, null);
        s.options.__file = "vue/system-config-tray.vue";
        var a = s.exports;
        Ext.ns("SYNO.SDS.ConfigBackup"), SYNO.SDS.ConfigBackup.SystemConfigTray = o.a.extend({
            components: {
                SystemConfigTray: a
            },
            template: "<SystemConfigTray/>"
        })
    }, function(e, t, n) {
        "use strict";

        function i(e, t) {
            for (var n = [], i = {}, o = 0; o < t.length; o++) {
                var r = t[o],
                    s = r[0],
                    a = {
                        id: e + ":" + o,
                        css: r[1],
                        media: r[2],
                        sourceMap: r[3]
                    };
                i[s] ? i[s].parts.push(a) : n.push(i[s] = {
                    id: s,
                    parts: [a]
                })
            }
            return n
        }

        function o(e, t, n, o) {
            g = n, k = o || {};
            var s = i(e, t);
            return r(s),
                function(t) {
                    for (var n = [], o = 0; o < s.length; o++) {
                        var a = s[o];
                        (c = p[a.id]).refs--, n.push(c)
                    }
                    for (t ? r(s = i(e, t)) : s = [], o = 0; o < n.length; o++) {
                        var c;
                        if (0 === (c = n[o]).refs) {
                            for (var u = 0; u < c.parts.length; u++) c.parts[u]();
                            delete p[c.id]
                        }
                    }
                }
        }

        function r(e) {
            for (var t = 0; t < e.length; t++) {
                var n = e[t],
                    i = p[n.id];
                if (i) {
                    i.refs++;
                    for (var o = 0; o < i.parts.length; o++) i.parts[o](n.parts[o]);
                    for (; o < n.parts.length; o++) i.parts.push(a(n.parts[o]));
                    i.parts.length > n.parts.length && (i.parts.length = n.parts.length)
                } else {
                    var r = [];
                    for (o = 0; o < n.parts.length; o++) r.push(a(n.parts[o]));
                    p[n.id] = {
                        id: n.id,
                        refs: 1,
                        parts: r
                    }
                }
            }
        }

        function s() {
            var e = document.createElement("style");
            return e.type = "text/css", h.appendChild(e), e
        }

        function a(e) {
            var t, n, i = document.querySelector('style[data-vue-ssr-id~="' + e.id + '"]');
            if (i) {
                if (g) return b;
                i.parentNode.removeChild(i)
            }
            if (x) {
                var o = _++;
                i = f || (f = s()), t = c.bind(null, i, o, !1), n = c.bind(null, i, o, !0)
            } else i = s(), t = u.bind(null, i), n = function() {
                i.parentNode.removeChild(i)
            };
            return t(e),
                function(i) {
                    if (i) {
                        if (i.css === e.css && i.media === e.media && i.sourceMap === e.sourceMap) return;
                        t(e = i)
                    } else n()
                }
        }

        function c(e, t, n, i) {
            var o = n ? "" : i.css;
            if (e.styleSheet) e.styleSheet.cssText = y(t, o);
            else {
                var r = document.createTextNode(o),
                    s = e.childNodes;
                s[t] && e.removeChild(s[t]), s.length ? e.insertBefore(r, s[t]) : e.appendChild(r)
            }
        }

        function u(e, t) {
            var n = t.css,
                i = t.media,
                o = t.sourceMap;
            if (i && e.setAttribute("media", i), k.ssrId && e.setAttribute("data-vue-ssr-id", t.id), o && (n += "\n/*# sourceURL=" + o.sources[0] + " */", n += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(o)))) + " */"), e.styleSheet) e.styleSheet.cssText = n;
            else {
                for (; e.firstChild;) e.removeChild(e.firstChild);
                e.appendChild(document.createTextNode(n))
            }
        }
        n.r(t), n.d(t, "default", function() {
            return o
        });
        var l = "undefined" != typeof document;
        if ("undefined" != typeof DEBUG && DEBUG && !l) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
        var d, p = {},
            h = l && (document.head || document.getElementsByTagName("head")[0]),
            f = null,
            _ = 0,
            g = !1,
            b = function() {},
            k = null,
            x = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase()),
            y = (d = [], function(e, t) {
                return d[e] = t, d.filter(Boolean).join("\n")
            })
    }]);
