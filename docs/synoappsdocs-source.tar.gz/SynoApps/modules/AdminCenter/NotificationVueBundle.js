/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _typeof2(e) {
    return (_typeof2 = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}! function(e) {
    var t = {};

    function r(n) {
        if (t[n]) return t[n].exports;
        var a = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(a.exports, a, a.exports, r), a.l = !0, a.exports
    }
    r.m = e, r.c = t, r.d = function(e, t, n) {
        r.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.t = function(e, t) {
        if (1 & t && (e = r(e)), 8 & t) return e;
        if (4 & t && "object" === _typeof2(e) && e && e.__esModule) return e;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var a in e) r.d(n, a, function(t) {
                return e[t]
            }.bind(null, a));
        return n
    }, r.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return r.d(t, "a", t), t
    }, r.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, r.p = "", r(r.s = 8)
}([function(e, t) {
    e.exports = Vuex
}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {}, function(e, t, r) {
    e.exports = r(16)
}, function(e, t, r) {
    "use strict";
    var n = r(1);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(2);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(3);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(4);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(5);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(6);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    var n = r(7);
    r.n(n).a
}, function(e, t, r) {
    "use strict";
    r.r(t);
    var n = {
            methods: {
                T: function(e, t) {
                    var r = _T(e, t);
                    return r && "" !== r ? r : "".concat(e, ":").concat(t)
                }
            }
        },
        a = r(0),
        i = r.n(a);

    function s(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function o(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var u = {
        mixins: [n],
        data: function() {
            return {
                selectedProvider: ""
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? Object(arguments[t]) : {},
                    n = Object.keys(r);
                "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                    return Object.getOwnPropertyDescriptor(r, e).enumerable
                }))), n.forEach(function(t) {
                    o(e, t, r[t])
                })
            }
            return e
        }({}, Object(a.mapState)(["type"])),
        watch: {
            selectedProvider: {
                handler: function(e, t) {
                    e && this.$emit("custom-footer-buttons", null)
                }
            }
        },
        mounted: function() {
            this.$store.dispatch("resetState")
        },
        methods: {
            prepareToNext: function() {
                return this.type !== this.selectedProvider && this.$store.dispatch("resetState"), this.$store.dispatch("selectType", this.selectedProvider), !0
            },
            onActivate: function() {
                var e, t = (e = regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.type ? this.selectedProvider = this.type : this.$emit("custom-footer-buttons", {
                                    next: {
                                        disabled: !0
                                    }
                                });
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }), function() {
                    var t = this,
                        r = arguments;
                    return new Promise(function(n, a) {
                        var i = e.apply(t, r);

                        function o(e) {
                            s(i, n, a, o, u, "next", e)
                        }

                        function u(e) {
                            s(i, n, a, o, u, "throw", e)
                        }
                        o(void 0)
                    })
                });
                return function() {
                    return t.apply(this, arguments)
                }
            }()
        }
    };
    r(9);

    function c(e, t, r, n, a, i, s, o) {
        var u, c = "function" == typeof e ? e.options : e;
        if (t && (c.render = t, c.staticRenderFns = r, c._compiled = !0), n && (c.functional = !0), i && (c._scopeId = "data-v-" + i), s ? (u = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), a && a.call(this, e), e && e._registeredComponents && e._registeredComponents.add(s)
            }, c._ssrRegister = u) : a && (u = o ? function() {
                a.call(this, this.$root.$options.shadowRoot)
            } : a), u)
            if (c.functional) {
                c._injectStyles = u;
                var d = c.render;
                c.render = function(e, t) {
                    return u.call(t), d(e, t)
                }
            } else {
                var p = c.beforeCreate;
                c.beforeCreate = p ? [].concat(p, u) : [u]
            } return {
            exports: e,
            options: c
        }
    }
    var d = c(u, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-wizard-step", {
                staticClass: "webhook-select-provider",
                attrs: {
                    "syno-id": "webhook-wizard-steps-select-provider-wizard-step-0",
                    "next-step-key": "provider-description",
                    "step-key": "select-provider",
                    headline: e.T("pushservice", "select_provider_type"),
                    "pre-enter-next-step": e.prepareToNext
                },
                on: {
                    activate: e.onActivate
                }
            }, [r("v-radio-group", {
                attrs: {
                    "syno-id": "webhook-wizard-steps-select-provider-radio-group-0"
                },
                model: {
                    value: e.selectedProvider,
                    callback: function(t) {
                        e.selectedProvider = t
                    },
                    expression: "selectedProvider"
                }
            }, [r("v-radio", {
                key: "chat",
                attrs: {
                    "syno-id": "webhook-wizard-steps-select-provider-radio-0",
                    value: "chat"
                }
            }, [r("div", {
                staticClass: "webhook-select-title"
            }, [e._v(e._s(e.T("pushservice", "chat")))]), e._v(" "), r("div", [e._v(e._s(e.T("pushservice", "chat_desc")))])]), e._v(" "), r("v-radio", {
                key: "custom",
                attrs: {
                    "syno-id": "webhook-wizard-steps-select-provider-radio-2",
                    value: "custom"
                }
            }, [r("div", {
                staticClass: "webhook-select-title"
            }, [e._v(e._s(e.T("pushservice", "custom")))]), e._v(" "), r("div", [e._v(e._s(e.T("pushservice", "custom_desc")))])])], 1)], 1)
        }, [], !1, null, null, null).exports,
        p = {
            methods: {
                parseURL: function(e) {
                    var t = {},
                        r = /^(http|https):\/\/([A-Za-z0-9.-]+)(:\d+)?[^?]*(\?.+)?/.exec(e);
                    if (!r || !r[1] || !r[2]) return _T("smsnotify", "url_err_invalid_param");
                    if ("http" === r[1].toLowerCase()) t.needssl = !1;
                    else {
                        if ("https" !== r[1].toLowerCase()) return _T("smsnotify", "url_err_invalid_param");
                        t.needssl = !0
                    }
                    return r[3] && 0 !== r[3].length ? t.port = parseInt(r[3].substring(1), 10) : t.needssl ? t.port = 443 : t.port = 80, t.queryParams = this.parseQuery(e), t
                },
                parseQuery: function(e) {
                    if ("string" != typeof e || 0 == e.length) return {};
                    var t = e.split("?").length > 0 ? e.split("?")[1] : e;
                    return void 0 === t ? {} : Ext.urlDecode(t)
                },
                parseHeader: function(e) {
                    var t, r = e.split("\r"),
                        n = /([^:]*):(.*)/,
                        a = {};
                    return r.forEach(function(e) {
                        null !== (t = n.exec(e)) && (a[t[1]] = t[2])
                    }, this), a
                }
            }
        };

    function l(e) {
        return (l = "function" == typeof Symbol && "symbol" === _typeof2(Symbol.iterator) ? function(e) {
            return _typeof2(e)
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : _typeof2(e)
        })(e)
    }

    function f(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function h(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise(function(n, a) {
                var i = e.apply(t, r);

                function s(e) {
                    f(i, n, a, s, o, "next", e)
                }

                function o(e) {
                    f(i, n, a, s, o, "throw", e)
                }
                s(void 0)
            })
        }
    }
    var m = {
            mixins: [n, p],
            props: {
                fields: {
                    type: Object,
                    default: function() {
                        return {
                            originalProvider: "",
                            provider: "",
                            prefix: "",
                            url: "",
                            req_method: ""
                        }
                    }
                },
                type: {
                    type: String,
                    default: ""
                }
            },
            data: function() {
                return {
                    rules: {
                        provider: {
                            required: !0,
                            validator: this.validateProvider,
                            usedProvider: []
                        },
                        prefix: {
                            required: !1
                        },
                        url: {
                            required: !0,
                            validator: this.validateUrl
                        },
                        req_method: {
                            required: !0
                        }
                    }
                }
            },
            watch: {
                "fields.originalProvider": {
                    handler: function(e, t) {
                        this.updateProviderList()
                    }
                },
                "fields.prefix": {
                    handler: function(e, t) {
                        this.$emit("on-change", !0)
                    }
                },
                "fields.req_method": {
                    handler: function(e, t) {
                        this.$emit("on-change", !0)
                    }
                }
            },
            mounted: function() {
                var e = h(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.updateProviderList();
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            methods: {
                validateProvider: function(e, t, r) {
                    this.$emit("on-change", this.$refs.form.isDirty());
                    try {
                        return t ? !(this.rules.provider.usedProvider.indexOf(t) >= 0) || new Error(this.T("smsnotify", "provider_name_repetition")) : new Error(_JSLIBSTR("extlang", "fieldblank"))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateUrl: function(e, t, r) {
                    this.$emit("on-change", this.$refs.form.isDirty());
                    try {
                        if ("" === t) return new Error(_JSLIBSTR("extlang", "fieldblank"));
                        var n = this.parseURL(t);
                        return "object" === l(n) ? (Object.assign(this.fields, n), !0) : new Error(n)
                    } catch (e) {
                        return new Error(this.T("smsnotify", "invalid_url"))
                    }
                },
                updateProviderList: function() {
                    var e = h(regeneratorRuntime.mark(function e() {
                        var t, r, n, a;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return t = [], e.prev = 1, this.$emit("set-status", "busy"), e.next = 5, synowebapi.promises.request({
                                        api: "SYNO.Core.Notification.Push.Webhook.Provider",
                                        method: "list",
                                        version: "1"
                                    });
                                case 5:
                                    for (r = e.sent, n = r.list, a = 0; a < n.length; ++a) n[a].provider !== this.fields.originalProvider && -1 === t.indexOf(n[a].provider) && t.push(n[a].provider);
                                    this.rules.provider.usedProvider = t, e.next = 14;
                                    break;
                                case 11:
                                    e.prev = 11, e.t0 = e.catch(1), SYNO.Debug.error(e.t0);
                                case 14:
                                    return e.prev = 14, this.$emit("set-status", "clear"), e.finish(14);
                                case 17:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this, [
                            [1, 11, 14, 17]
                        ])
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                setDescription: function() {
                    var e = h(regeneratorRuntime.mark(function e() {
                        var t, r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.form.validate();
                                case 2:
                                    for (r in t = [], this.fields.queryParams) t.push({
                                        parameter: r,
                                        value: this.fields.queryParams[r],
                                        select: "@@OTHER@@"
                                    });
                                    return e.next = 6, this.$store.dispatch("setDescription", this.fields);
                                case 6:
                                    return e.next = 8, this.$store.dispatch("setQueryParams", t);
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
            }
        },
        v = (r(10), c(m, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-form", {
                ref: "form",
                staticClass: "webhook-provider-description",
                attrs: {
                    "syno-id": "components-description-form-0",
                    model: e.fields,
                    rules: e.rules
                }
            }, [r("v-form-item", {
                ref: "name",
                attrs: {
                    prop: "provider",
                    label: e.T("pushservice", "provider_name") + e.T("common", "colon")
                }
            }, [r("v-input", {
                staticClass: "webhook-provider-provider",
                attrs: {
                    "syno-id": "components-description-input-0",
                    name: "provider",
                    maxlength: 32
                },
                model: {
                    value: e.fields.provider,
                    callback: function(t) {
                        e.$set(e.fields, "provider", t)
                    },
                    expression: "fields.provider"
                }
            })], 1), e._v(" "), r("v-form-item", {
                ref: "prefix",
                attrs: {
                    prop: "prefix",
                    label: e.T("pushservice", "subject_prefix") + e.T("common", "colon")
                }
            }, [r("v-input", {
                staticClass: "webhook-provider-prefix",
                attrs: {
                    "syno-id": "components-description-input-1",
                    name: "prefix",
                    type: "textarea",
                    maxlength: 256
                },
                model: {
                    value: e.fields.prefix,
                    callback: function(t) {
                        e.$set(e.fields, "prefix", t)
                    },
                    expression: "fields.prefix"
                }
            })], 1), e._v(" "), r("v-form-item", {
                ref: "url",
                attrs: {
                    prop: "url",
                    label: e.T("pushservice", "webhook_url") + e.T("common", "colon")
                }
            }, [r("v-input", {
                staticClass: "webhook-provider-url",
                attrs: {
                    "syno-id": "components-description-input-2",
                    name: "url",
                    type: "textarea",
                    maxlength: 500
                },
                model: {
                    value: e.fields.url,
                    callback: function(t) {
                        e.$set(e.fields, "url", t)
                    },
                    expression: "fields.url"
                }
            })], 1), e._v(" "), "custom" === e.type ? r("v-form-item", {
                attrs: {
                    prop: "req_method",
                    label: e.T("smsnotify", "http_method") + e.T("common", "colon")
                }
            }, [r("v-radio-group", {
                attrs: {
                    "syno-id": "components-description-radio-group-0"
                },
                model: {
                    value: e.fields.req_method,
                    callback: function(t) {
                        e.$set(e.fields, "req_method", t)
                    },
                    expression: "fields.req_method"
                }
            }, [r("v-radio", {
                attrs: {
                    "syno-id": "components-description-radio-0",
                    value: "get"
                }
            }, [e._v("GET")]), e._v(" "), r("v-radio", {
                attrs: {
                    "syno-id": "components-description-radio-1",
                    value: "post"
                }
            }, [e._v("POST")])], 1)], 1) : e._e()], 1)
        }, [], !1, null, null, null).exports);

    function y(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function b(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise(function(n, a) {
                var i = e.apply(t, r);

                function s(e) {
                    y(i, n, a, s, o, "next", e)
                }

                function o(e) {
                    y(i, n, a, s, o, "throw", e)
                }
                s(void 0)
            })
        }
    }

    function _(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? Object(arguments[t]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                return Object.getOwnPropertyDescriptor(r, e).enumerable
            }))), n.forEach(function(t) {
                g(e, t, r[t])
            })
        }
        return e
    }

    function g(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var w = {
            components: {
                description: v
            },
            mixins: [n, p],
            data: function() {
                return {
                    fields: {
                        originalProvider: "",
                        provider: "",
                        prefix: "",
                        url: "",
                        req_method: ""
                    },
                    noteContent: ""
                }
            },
            computed: _({}, Object(a.mapState)(["type", "url", "provider", "prefix", "req_method"]), {
                nextStepKey: function() {
                    return "chat" === this.type ? "" : "ifttt" === this.type ? "select-parameter" : "http-req-header"
                }
            }),
            methods: _({}, Object(a.mapGetters)(["getProvider"]), {
                prepareToNext: function() {
                    var e = b(regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.description.updateProviderList();
                                case 2:
                                    return e.next = 4, this.$refs.description.$refs.form.validate();
                                case 4:
                                    if (e.sent) {
                                        e.next = 6;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 6:
                                    return this.$refs.description.setDescription(), e.abrupt("return", !0);
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                prepareToPre: function() {
                    this.$store.dispatch("setTempDescription", this.fields)
                },
                finished: function() {
                    var e = b(regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.description.updateProviderList();
                                case 2:
                                    return e.next = 4, this.$refs.description.$refs.form.validate();
                                case 4:
                                    if (e.sent) {
                                        e.next = 6;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 6:
                                    return e.next = 8, this.$store.dispatch("setDescription", this.fields);
                                case 8:
                                    return e.prev = 8, e.next = 11, synowebapi.promises.request({
                                        api: "SYNO.Core.Notification.Push.Webhook.Provider",
                                        method: "create",
                                        version: 1,
                                        params: this.getProvider()
                                    });
                                case 11:
                                    e.sent, this.$emit("close"), e.next = 18;
                                    break;
                                case 15:
                                    e.prev = 15, e.t0 = e.catch(8), this.$emit("display-error", e.t0);
                                case 18:
                                    return e.prev = 18, e.abrupt("return", !1);
                                case 21:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this, [
                            [8, 15, 18, 21]
                        ])
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                setNoteContent: function() {
                    var e = b(regeneratorRuntime.mark(function e() {
                        var t, r, n, a;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (t = "chat" === this.type ? ' href="https://www.synology.com/knowledgebase/DSM/tutorial/Management/configure_webhooks_for_DSM_notifications" target="_blank"' : "", r = '<span class="note-font">' + this.T("common", "note") + this.T("common", "colon") + "</span>", n = String.format(this.T("pushservice", "learn_more_note"), '<a class="link-font"' + t + ">", "</a>"), this.noteContent = r + n, "chat" === this.type) {
                                        e.next = 9;
                                        break
                                    }
                                    return e.next = 7, this.$nextTick();
                                case 7:
                                    (a = this.$refs.note.querySelector(".link-font")) && a.addEventListener("click", function() {
                                        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                            topic: "SYNO.SDS.AdminCenter.Application:AdminCenter/system_notification_pushservice.html"
                                        }, !1)
                                    });
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                onActivate: function() {
                    var e = b(regeneratorRuntime.mark(function e() {
                        var t;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return this.fields.provider = -1 === this.$refs.description.rules.provider.usedProvider.indexOf("Chat") && "chat" === this.type && void 0 === this.provider ? "Chat" : this.provider, this.fields.prefix = this.prefix, this.fields.url = this.url, this.fields.req_method = this.req_method ? this.req_method : "custom" === this.type ? "get" : "post", e.next = 6, this.$nextTick();
                                case 6:
                                    (t = this.$refs.description.$refs).name.validateDebounced.cancel(), t.prefix.validateDebounced.cancel(), t.url.validateDebounced.cancel(), this.setNoteContent();
                                case 11:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
            })
        },
        x = (r(11), c(w, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-wizard-step", {
                staticClass: "webhook-provider-description",
                attrs: {
                    "syno-id": "webhook-wizard-steps-provider-description-wizard-step-0",
                    "step-key": "provider-description",
                    finished: e.finished,
                    headline: e.T("pushservice", "provider_description"),
                    "next-step-key": e.nextStepKey,
                    "pre-enter-next-step": e.prepareToNext,
                    "pre-enter-previous-step": e.prepareToPre
                },
                on: {
                    activate: e.onActivate
                }
            }, [r("description", {
                ref: "description",
                attrs: {
                    fields: e.fields,
                    type: e.type
                }
            }), e._v(" "), r("div", {
                ref: "note",
                staticClass: "note",
                domProps: {
                    innerHTML: e._s(e.noteContent)
                }
            })], 1)
        }, [], !1, null, null, null).exports);

    function S(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function T(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var P = {
            mixins: [n, p],
            data: function() {
                return {
                    currentStep: "header",
                    data: [],
                    addBtnDisabled: !1,
                    rules: {
                        required: !0,
                        validator: this.validateParameter
                    }
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var r = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(r);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                        return Object.getOwnPropertyDescriptor(r, e).enumerable
                    }))), n.forEach(function(t) {
                        T(e, t, r[t])
                    })
                }
                return e
            }({}, Object(a.mapState)(["req_method", "requestHeaders", "formData", "url"]), {
                loadData: function() {
                    return this.data
                },
                removeDisabled: function() {
                    return 0 === this.data.length
                },
                headline: function() {
                    return this.T("smsnotify", "header" === this.currentStep ? "header_req_header" : "header_req_parameter")
                },
                subtitle: function() {
                    return this.T("pushservice", "header" === this.currentStep ? "add_http_header" : "add_http_body")
                }
            }),
            methods: {
                onAdd: function() {
                    this.data.push({
                        parameter: "",
                        value: "",
                        select: "@@OTHER@@"
                    }), this.addBtnDisabled = !0
                },
                onRemove: function(e) {
                    this.data.splice(e, 1), this.addBtnDisabled = !this.checkAllValidate()
                },
                prepareToNext: function() {
                    var e, t = (e = regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.form.validate();
                                case 2:
                                    if (e.sent) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 4:
                                    if (1 !== this.data.length || this.data[0].parameter || (this.data = []), "get" !== this.req_method) {
                                        e.next = 10;
                                        break
                                    }
                                    return this.$store.dispatch("setHeader", this.data), e.abrupt("return", !0);
                                case 10:
                                    if ("header" !== this.currentStep) {
                                        e.next = 18;
                                        break
                                    }
                                    return this.currentStep = "body", this.$store.dispatch("setHeader", this.data), this.data = JSON.parse(JSON.stringify(this.formData)), 0 === this.data.length && this.onAdd(), e.abrupt("return", !1);
                                case 18:
                                    return this.$store.dispatch("setFormData", this.data), e.abrupt("return", !0);
                                case 20:
                                    return e.abrupt("return", !1);
                                case 21:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }), function() {
                        var t = this,
                            r = arguments;
                        return new Promise(function(n, a) {
                            var i = e.apply(t, r);

                            function s(e) {
                                S(i, n, a, s, o, "next", e)
                            }

                            function o(e) {
                                S(i, n, a, s, o, "throw", e)
                            }
                            s(void 0)
                        })
                    });
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                prepareToPre: function() {
                    return "header" === this.currentStep || (this.data = JSON.parse(JSON.stringify(this.requestHeaders)), 0 === this.data.length && this.onAdd(), this.currentStep = "header", !1)
                },
                onActivate: function() {
                    this.data = "header" === this.currentStep ? JSON.parse(JSON.stringify(this.requestHeaders)) : JSON.parse(JSON.stringify(this.formData)), 0 === this.data.length && this.onAdd()
                },
                validateParameter: function(e, t, r) {
                    try {
                        return t ? (this.addBtnDisabled = !this.checkAllValidate(), !0) : (this.addBtnDisabled = !0, 1 === this.data.length || new Error(_JSLIBSTR("extlang", "fieldblank")))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                checkAllValidate: function() {
                    var e = !0,
                        t = !0,
                        r = !1,
                        n = void 0;
                    try {
                        for (var a, i = this.data[Symbol.iterator](); !(t = (a = i.next()).done); t = !0) {
                            var s = a.value;
                            e = e && !!s.parameter
                        }
                    } catch (e) {
                        r = !0, n = e
                    } finally {
                        try {
                            t || null == i.return || i.return()
                        } finally {
                            if (r) throw n
                        }
                    }
                    return e
                }
            }
        },
        k = (r(12), c(P, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-wizard-step", {
                staticClass: "webhook-req-header",
                attrs: {
                    "syno-id": "webhook-wizard-steps-http-req-header-wizard-step-0",
                    "step-key": "http-req-header",
                    "next-step-key": "select-parameter",
                    headline: e.headline,
                    "pre-enter-next-step": e.prepareToNext,
                    "pre-enter-previous-step": e.prepareToPre
                },
                on: {
                    activate: e.onActivate
                }
            }, [r("div", {
                staticClass: "subtitle"
            }, [e._v(e._s(e.subtitle))]), e._v(" "), r("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "webhook-wizard-steps-http-req-header-form-0"
                }
            }, e._l(e.data, function(t, n) {
                return r("v-form-multiple-item", {
                    key: n,
                    attrs: {
                        "hide-label": !0
                    }
                }, [r("v-form-item", {
                    attrs: {
                        prop: "paramter",
                        "hide-label": !0,
                        rules: [e.rules]
                    }
                }, [r("v-input", {
                    staticClass: "parameter",
                    attrs: {
                        "syno-id": "webhook-wizard-steps-http-req-header-input-0",
                        name: "paramter",
                        placeholder: e.T("smsnotify", "request_parameter")
                    },
                    model: {
                        value: t.parameter,
                        callback: function(r) {
                            e.$set(t, "parameter", r)
                        },
                        expression: "header.parameter"
                    }
                })], 1), e._v(" "), r("v-form-item", {
                    attrs: {
                        prop: "value",
                        "hide-label": !0
                    }
                }, [r("v-input", {
                    staticClass: "value",
                    attrs: {
                        "syno-id": "webhook-wizard-steps-http-req-header-input-1",
                        name: "value",
                        placeholder: e.T("smsnotify", "request_value")
                    },
                    model: {
                        value: t.value,
                        callback: function(r) {
                            e.$set(t, "value", r)
                        },
                        expression: "header.value"
                    }
                })], 1), e._v(" "), r("v-button", {
                    attrs: {
                        "syno-id": "webhook-wizard-steps-http-req-header-button-0",
                        disabled: 1 === e.data.length
                    },
                    on: {
                        click: function(t) {
                            return e.onRemove(n)
                        }
                    }
                }, [e._v(e._s("-"))])], 1)
            }), 1), e._v(" "), r("v-button", {
                attrs: {
                    "syno-id": "webhook-wizard-steps-http-req-header-button-1",
                    disabled: e.addBtnDisabled
                },
                on: {
                    click: e.onAdd
                }
            }, [e._v(e._s(e.T("pushservice", "add_new_field")))])], 1)
        }, [], !1, null, null, null).exports);

    function O(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function q(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var E = c({
        mixins: [n],
        props: {
            type: {
                type: String,
                default: ""
            },
            fields: {
                type: Object,
                default: function() {
                    return {
                        value3: ""
                    }
                }
            },
            requestHeaders: {
                type: Array,
                default: function() {
                    return []
                }
            },
            formData: {
                type: Array,
                default: function() {
                    return []
                }
            }
        },
        data: function() {
            return {
                rules: {
                    value3: {
                        required: !1
                    }
                },
                data: []
            }
        },
        computed: function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var r = null != arguments[t] ? Object(arguments[t]) : {},
                    n = Object.keys(r);
                "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                    return Object.getOwnPropertyDescriptor(r, e).enumerable
                }))), n.forEach(function(t) {
                    q(e, t, r[t])
                })
            }
            return e
        }({}, Object(a.mapState)(["req_method", "queryParams", "selectedParams", "selectOptions"]), {
            loadData: function() {
                var e = [{
                    parameter: "value1",
                    category: this.T("pushservice", "subject_prefix"),
                    id: "value1"
                }, {
                    parameter: "value2",
                    category: this.T("pushservice", "url_param_content"),
                    id: "value2"
                }, {
                    parameter: this.T("pushservice", "value3_opt"),
                    category: this.fields.value3,
                    id: "value3"
                }];
                return "custom" === this.type ? this.data : e
            },
            columns: function() {
                return [{
                    title: this.T("smsnotify", "request_parameter"),
                    field: "parameter"
                }, {
                    title: this.T("smsnotify", "category"),
                    field: "custom" === this.type ? "value" : "category"
                }]
            }
        }),
        methods: {
            updateData: function() {
                this.data = [];
                var e = this,
                    t = "query",
                    r = function(t, r, n) {
                        var a = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : "@@OTHER@@";
                        e.data.push({
                            parameter: t,
                            value: a,
                            id: e.data.length,
                            type: r,
                            originalValue: n
                        })
                    },
                    n = function(n) {
                        var a = e.selectedParams.find(function(e) {
                            return e.type === t && e.parameter === n.parameter
                        });
                        a ? r(a.parameter, t, n.value, a.value) : r(n.parameter, t, n.value)
                    };
                t = "query", this.queryParams.forEach(n), t = "header", this.requestHeaders.forEach(n), "post" === this.req_method && (t = "form", this.formData.forEach(n))
            },
            saveSelectedParams: function() {
                var e, t = (e = regeneratorRuntime.mark(function e() {
                    var t, r, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (t = [], this.data.forEach(function(e, n) {
                                        "@@FULLTEXT@@" === e.value && (t.push(n), r = /[\w]{5}(.){1}[\w]{5}/.exec(e.originalValue))
                                    }), 1 === t.length && null !== r) {
                                    e.next = 14;
                                    break
                                }
                                e.t0 = t.length, e.next = 0 === e.t0 ? 6 : 1 === e.t0 ? 8 : 10;
                                break;
                            case 6:
                                return n = this.T("smsnotify", "url_err_need_message_content"), e.abrupt("break", 12);
                            case 8:
                                return n = this.T("smsnotify", "url_err_need_sep_char"), e.abrupt("break", 12);
                            case 10:
                                return n = this.T("smsnotify", "url_err_duplicated_type"), e.abrupt("break", 12);
                            case 12:
                                return this.$emit("alert-message-box", "", n), e.abrupt("return", !1);
                            case 14:
                                return e.next = 16, this.$store.dispatch("setSepChar", r[1]);
                            case 16:
                                return e.next = 18, this.$store.dispatch("setParameter", JSON.parse(JSON.stringify(this.data)));
                            case 18:
                                return e.next = 20, this.$store.dispatch("genTemp");
                            case 20:
                                return e.abrupt("return", !0);
                            case 21:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }), function() {
                    var t = this,
                        r = arguments;
                    return new Promise(function(n, a) {
                        var i = e.apply(t, r);

                        function s(e) {
                            O(i, n, a, s, o, "next", e)
                        }

                        function o(e) {
                            O(i, n, a, s, o, "throw", e)
                        }
                        s(void 0)
                    })
                });
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            onInput: function() {
                this.$emit("on-change", !0)
            }
        }
    }, function() {
        var e = this,
            t = e.$createElement,
            r = e._self._c || t;
        return r("v-data-table", {
            ref: "dataTable",
            attrs: {
                "syno-id": "components-select-params-data-table-0",
                columns: e.columns,
                "current-data": e.loadData,
                "show-paging-bar": !1
            },
            scopedSlots: e._u([{
                key: "category",
                fn: function(t) {
                    var n = t.row;
                    return ["value3" === n.id ? r("v-input", {
                        attrs: {
                            "syno-id": "components-select-params-input-0",
                            name: "value3"
                        },
                        model: {
                            value: e.fields.value3,
                            callback: function(t) {
                                e.$set(e.fields, "value3", t)
                            },
                            expression: "fields.value3"
                        }
                    }) : r("div", {
                        staticClass: "content-cell"
                    }, [e._v(e._s(n.category))])]
                }
            }, {
                key: "value",
                fn: function(t) {
                    var n = t.row;
                    return [r("v-select", {
                        attrs: {
                            "syno-id": "components-select-params-select-0",
                            options: e.selectOptions,
                            width: "auto"
                        },
                        on: {
                            input: e.onInput
                        },
                        model: {
                            value: n.value,
                            callback: function(t) {
                                e.$set(n, "value", t)
                            },
                            expression: "row.value"
                        }
                    })]
                }
            }])
        })
    }, [], !1, null, null, null).exports;

    function $(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function D(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise(function(n, a) {
                var i = e.apply(t, r);

                function s(e) {
                    $(i, n, a, s, o, "next", e)
                }

                function o(e) {
                    $(i, n, a, s, o, "throw", e)
                }
                s(void 0)
            })
        }
    }

    function R(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? Object(arguments[t]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                return Object.getOwnPropertyDescriptor(r, e).enumerable
            }))), n.forEach(function(t) {
                C(e, t, r[t])
            })
        }
        return e
    }

    function C(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var N = {
            components: {
                SelectProvider: d,
                ProviderDescription: x,
                HttpReqHeader: k,
                SelectParameter: c({
                    components: {
                        selectParams: E
                    },
                    mixins: [n, p],
                    data: function() {
                        return {
                            fields: {
                                value3: ""
                            },
                            data: []
                        }
                    },
                    computed: R({}, Object(a.mapState)(["type", "requestHeaders", "formData"])),
                    methods: R({}, Object(a.mapGetters)(["getProvider"]), {
                        createProvider: function() {
                            var e = D(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                                api: "SYNO.Core.Notification.Push.Webhook.Provider",
                                                method: "create",
                                                version: 1,
                                                params: this.getProvider()
                                            });
                                        case 3:
                                            e.sent, this.$emit("close"), e.next = 10;
                                            break;
                                        case 7:
                                            e.prev = 7, e.t0 = e.catch(0), this.$emit("display-error", e.t0);
                                        case 10:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this, [
                                    [0, 7]
                                ])
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        finished: function() {
                            var e = D(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if ("ifttt" !== this.type) {
                                                e.next = 4;
                                                break
                                            }
                                            return this.$store.dispatch("setValue3", this.fields.value3), this.createProvider(), e.abrupt("return", !1);
                                        case 4:
                                            return e.next = 6, this.$refs.selectParams.saveSelectedParams();
                                        case 6:
                                            if (e.t0 = e.sent, !1 !== e.t0) {
                                                e.next = 9;
                                                break
                                            }
                                            return e.abrupt("return", !1);
                                        case 9:
                                            return this.createProvider(), e.abrupt("return", !1);
                                        case 11:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }(),
                        prepareToPre: function() {
                            return this.$store.dispatch("setParameter", JSON.parse(JSON.stringify(this.$refs.selectParams.data))), !0
                        },
                        onActivate: function() {
                            this.$refs.selectParams.updateData()
                        },
                        onMessageBoxAlert: function(e, t, r) {
                            this.$emit("alert-message-box", e, t, r)
                        }
                    })
                }, function() {
                    var e = this,
                        t = e.$createElement,
                        r = e._self._c || t;
                    return r("v-wizard-step", {
                        attrs: {
                            "syno-id": "webhook-wizard-steps-select-parameter-wizard-step-0",
                            "next-step-key": "",
                            "step-key": "select-parameter",
                            headline: e.T("smsnotify", "provider_param_descript"),
                            finished: e.finished,
                            "pre-enter-previous-step": e.prepareToPre
                        },
                        on: {
                            activate: e.onActivate
                        }
                    }, [r("select-params", {
                        ref: "selectParams",
                        attrs: {
                            type: e.type,
                            data: e.data,
                            fields: e.fields,
                            formData: e.formData,
                            requestHeaders: e.requestHeaders
                        },
                        on: {
                            "alert-message-box": e.onMessageBoxAlert
                        }
                    })], 1)
                }, [], !1, null, null, null).exports
            },
            mixins: [n],
            data: function() {
                return {
                    customButtonsGroup: null,
                    loading: !1
                }
            },
            methods: {
                customFooterButtons: function(e) {
                    this.customButtonsGroup = e
                },
                displayError: function(e) {
                    var t = this.T("error", "error_error_system");
                    e && e.code && (t = SYNO.API.Errors.core[e.code] || this.T("error", "error_error_system")), this.$refs.window.getMsgBox().alert("", t)
                },
                onMessageBoxAlert: function(e, t, r) {
                    this.$refs.window.getMsgBox().alert(e, t).then(r)
                },
                onClose: function() {
                    this.$refs.window.close()
                },
                onSetStatus: function(e) {
                    "busy" === e ? (this.loading = !0, this.$refs.window.mask(.4)) : (this.loading = !1, this.$refs.window.unmask())
                }
            }
        },
        j = (r(13), c(N, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-wizard-window", {
                ref: "window",
                staticClass: "notify-webhook-wizard",
                attrs: {
                    "syno-id": "windows-webhook-wizard-wizard-window-0",
                    height: "480",
                    width: "590",
                    title: e.T("pushservice", "add_webhook")
                }
            }, [r("v-spin", {
                attrs: {
                    tip: e.T("common", "loading"),
                    spinning: e.loading
                }
            }, [r("v-wizard", {
                attrs: {
                    "syno-id": "windows-webhook-wizard-wizard-0",
                    "active-step-key": "select-provider",
                    "custom-buttons-group": e.customButtonsGroup
                }
            }, [r("select-provider", {
                on: {
                    "custom-footer-buttons": e.customFooterButtons
                }
            }), e._v(" "), r("provider-description", {
                on: {
                    close: e.onClose,
                    "display-error": e.displayError,
                    "set-status": e.onSetStatus
                }
            }), e._v(" "), r("http-req-header"), e._v(" "), r("select-parameter", {
                on: {
                    "alert-message-box": e.onMessageBoxAlert,
                    close: e.onClose
                }
            })], 1)], 1)], 1)
        }, [], !1, null, null, null).exports);

    function A(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }
    var H = {
            mixins: [n, p],
            props: {
                paramsString: {
                    type: String,
                    default: ""
                },
                type: {
                    type: String,
                    default: ""
                },
                data: {
                    type: Array,
                    default: function() {
                        return []
                    }
                },
                sepchar: {
                    type: String,
                    default: " "
                }
            },
            data: function() {
                return {
                    columns: [{
                        title: this.T("smsnotify", "request_parameter"),
                        field: "parameter"
                    }, {
                        title: this.T("smsnotify", "request_value"),
                        field: "value"
                    }]
                }
            },
            computed: {
                disabledBtn: function() {
                    return 0 === this.data.length || null === this.$refs.dataTable.selectIndex
                }
            },
            mounted: function() {
                var e, t = (e = regeneratorRuntime.mark(function e() {
                    var t, r, n, a, i;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if ("header" !== this.type) {
                                    e.next = 6;
                                    break
                                }
                                t = this.paramsString.split("\r"), r = /([^:]*):(.*)/, t.forEach(function(e) {
                                    null !== (n = r.exec(e)) && ("@@FULLTEXT@@" === n[2] ? this.addData(n[1], "hello" + this.sepchar + "world", "@@FULLTEXT@@") : this.addData(n[1], n[2]))
                                }, this), e.next = 16;
                                break;
                            case 6:
                                if ("body" !== this.type) {
                                    e.next = 16;
                                    break
                                }
                                a = {}, e.prev = 8, a = JSON.parse(this.paramsString), e.next = 15;
                                break;
                            case 12:
                                return e.prev = 12, e.t0 = e.catch(8), e.abrupt("return");
                            case 15:
                                for (i in a) void 0 !== a[i] && ("@@FULLTEXT@@" === a[i] ? this.addData(i, "hello" + this.sepchar + "world", "@@FULLTEXT@@") : this.addData(i, a[i]));
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }, e, this, [
                        [8, 12]
                    ])
                }), function() {
                    var t = this,
                        r = arguments;
                    return new Promise(function(n, a) {
                        var i = e.apply(t, r);

                        function s(e) {
                            A(i, n, a, s, o, "next", e)
                        }

                        function o(e) {
                            A(i, n, a, s, o, "throw", e)
                        }
                        s(void 0)
                    })
                });
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: {
                onAdd: function() {
                    this.$emit("edit-dialog", "", "", this.type, this.data.length), this.$refs.dataTable.clearSelection()
                },
                addData: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                        r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "@@OTHER@@",
                        n = this.data.length;
                    this.data.push({
                        parameter: e,
                        value: t,
                        select: r,
                        id: 0 === n ? 0 : this.data[n - 1].id + 1
                    })
                },
                onEdit: function() {
                    var e = this.$refs.dataTable.selectIndex;
                    e >= 0 && (this.$emit("edit-dialog", this.data[e].parameter, this.data[e].value, this.type, e), this.$refs.dataTable.clearSelection())
                },
                onRemove: function() {
                    var e = this.$refs.dataTable.selectIndex;
                    e >= 0 && (this.data.splice(e, 1), this.$refs.dataTable.clearSelection(), this.$emit("on-change", !0))
                }
            }
        },
        L = (r(14), c(H, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-fieldset", {
                ref: "field",
                staticClass: "request-edit-fieldset",
                attrs: {
                    "collapse-icon": "none",
                    collapsible: !1,
                    title: e.T("smsnotify", "header" === e.type ? "header_req_header" : "header_req_parameter")
                }
            }, [r("v-button", {
                attrs: {
                    "syno-id": "components-request-editor-button-0"
                },
                on: {
                    click: e.onAdd
                }
            }, [e._v(e._s(e.T("common", "add")))]), e._v(" "), r("v-button", {
                attrs: {
                    "syno-id": "components-request-editor-button-1",
                    disabled: e.disabledBtn
                },
                on: {
                    click: e.onEdit
                }
            }, [e._v(e._s(e.T("common", "alt_edit")))]), e._v(" "), r("v-button", {
                attrs: {
                    "syno-id": "components-request-editor-button-2",
                    disabled: e.disabledBtn
                },
                on: {
                    click: e.onRemove
                }
            }, [e._v(e._s(e.T("common", "remove")))]), e._v(" "), r("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "components-request-editor-form-0"
                }
            }, [r("v-data-table", {
                ref: "dataTable",
                attrs: {
                    "syno-id": "components-request-editor-data-table-0",
                    "current-data": e.data,
                    columns: e.columns,
                    "show-paging-bar": !1
                },
                on: {
                    rowdblclick: e.onEdit
                }
            })], 1)], 1)
        }, [], !1, null, null, null).exports),
        M = c({
            mixins: [n],
            props: {
                parameter: {
                    type: String,
                    default: ""
                },
                value: {
                    type: String,
                    default: ""
                },
                type: {
                    type: String,
                    default: ""
                },
                index: {
                    type: Number,
                    default: -1
                }
            },
            methods: {
                doConfirm: function() {
                    var e = this;
                    return new Promise(function(t, r) {
                        return e.$refs.form.validate().then(function(r) {
                            r && (e.$emit("update-param", e.parameter, e.value, e.type, e.index), t("confirm"), e.$refs.window.onClose())
                        }).catch(function(e) {
                            SYNO.Debug.error(e)
                        })
                    })
                }
            }
        }, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-message-box-window", {
                ref: "window",
                attrs: {
                    "syno-id": "components-edit-param-dialog-message-box-window-0",
                    "do-confirm": e.doConfirm
                },
                scopedSlots: e._u([{
                    key: "content",
                    fn: function() {
                        return [r("v-form", {
                            ref: "form",
                            attrs: {
                                "syno-id": "components-edit-param-dialog-form-0"
                            }
                        }, [r("v-form-item", {
                            attrs: {
                                prop: "paramter",
                                label: e.T("smsnotify", "request_parameter") + e.T("common", "colon"),
                                rules: [{
                                    required: !0
                                }]
                            }
                        }, [r("v-input", {
                            attrs: {
                                "syno-id": "components-edit-param-dialog-input-0",
                                name: "parameter"
                            },
                            model: {
                                value: e.parameter,
                                callback: function(t) {
                                    e.parameter = t
                                },
                                expression: "parameter"
                            }
                        })], 1), e._v(" "), r("v-form-item", {
                            attrs: {
                                label: e.T("smsnotify", "request_value") + e.T("common", "colon")
                            }
                        }, [r("v-input", {
                            attrs: {
                                "syno-id": "components-edit-param-dialog-input-1",
                                name: "value"
                            },
                            model: {
                                value: e.value,
                                callback: function(t) {
                                    e.value = t
                                },
                                expression: "value"
                            }
                        })], 1)], 1)]
                    },
                    proxy: !0
                }])
            })
        }, [], !1, null, null, null).exports;

    function B(e, t, r, n, a, i, s) {
        try {
            var o = e[i](s),
                u = o.value
        } catch (e) {
            return void r(e)
        }
        o.done ? t(u) : Promise.resolve(u).then(n, a)
    }

    function z(e) {
        return function() {
            var t = this,
                r = arguments;
            return new Promise(function(n, a) {
                var i = e.apply(t, r);

                function s(e) {
                    B(i, n, a, s, o, "next", e)
                }

                function o(e) {
                    B(i, n, a, s, o, "throw", e)
                }
                s(void 0)
            })
        }
    }

    function I(e) {
        for (var t = 1; t < arguments.length; t++) {
            var r = null != arguments[t] ? Object(arguments[t]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
                return Object.getOwnPropertyDescriptor(r, e).enumerable
            }))), n.forEach(function(t) {
                J(e, t, r[t])
            })
        }
        return e
    }

    function J(e, t, r) {
        return t in e ? Object.defineProperty(e, t, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = r, e
    }
    var V = Vue.extend(M),
        U = {
            components: {
                description: v,
                requestEditor: L,
                selectParams: E
            },
            mixins: [n, p],
            props: {
                selectedProvider: {
                    type: String,
                    required: !0
                }
            },
            data: function() {
                return {
                    activeTabKey: "provider",
                    customButtonsGroup: null,
                    fields: {
                        originalProvider: "",
                        provider: "",
                        prefix: "",
                        url: "",
                        req_method: "",
                        value3: ""
                    },
                    req_header: "",
                    req_param: "",
                    requestHeaders: [],
                    formData: [],
                    type: "",
                    isDirty: !1,
                    isUpdateSelectedOpt: !1,
                    sepchar: " "
                }
            },
            computed: I({}, Object(a.mapState)(["selectOptions"]), {
                title: function() {
                    return this.T("pushservice", "chat" === this.type ? "edit_chat" : "ifttt" === this.type ? "edit_ifttt" : "edit_custom")
                }
            }),
            mounted: function() {
                var e = z(regeneratorRuntime.mark(function e() {
                    var t, r, n, a, i, s, o, u, c, d, p, l, f = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (this.selectedProvider) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", this.onClose());
                            case 2:
                                return this.$refs.window.mask(.4), e.prev = 3, e.next = 6, synowebapi.promises.request({
                                    api: "SYNO.Core.Notification.Push.Webhook.Provider",
                                    method: "get",
                                    version: "1",
                                    params: {
                                        provider: this.selectedProvider
                                    }
                                });
                            case 6:
                                return t = e.sent, e.next = 9, this.$store.dispatch("resetState");
                            case 9:
                                return e.next = 11, this.$store.dispatch("selectType", t.type);
                            case 11:
                                if (this.type = t.type, this.fields.originalProvider = t.provider, this.req_header = t.req_header, this.req_param = t.req_param, this.req_method = t.req_method, this.sepchar = t.sepchar, Object.assign(this.fields, t), "ifttt" !== this.type) {
                                    e.next = 23;
                                    break
                                }
                                r = JSON.parse(t.req_param), this.fields.value3 = r.value3, e.next = 41;
                                break;
                            case 23:
                                if ("custom" !== this.type) {
                                    e.next = 41;
                                    break
                                }
                                for (u in n = [], a = this, i = function(e, r, i, s) {
                                        var o = a.selectOptions.find(function(e) {
                                            return e.value === r
                                        });
                                        n.push({
                                            parameter: e,
                                            value: o ? o.value : "@@OTHER@@",
                                            id: n.length,
                                            type: i,
                                            originalValue: o && "@@FULLTEXT@@" === o.value ? s || "hello" + t.sepchar + "world" : r
                                        })
                                    }, s = this.parseQuery(t.url), o = this.parseQuery(t.template)) i(u, o[u], "query", s[u]);
                                return e.next = 32, this.$store.dispatch("setQueryParams", JSON.parse(JSON.stringify(n)));
                            case 32:
                                for (d in c = this.parseHeader(t.req_header)) i(d, c[d], "header");
                                if ("post" === this.req_method)
                                    for (l in p = JSON.parse(t.req_param)) i(l, p[l], "form");
                                return e.next = 37, this.$store.dispatch("setParameter", n);
                            case 37:
                                return e.next = 39, this.$refs.description.setDescription();
                            case 39:
                                return e.next = 41, this.$refs.selectParams.updateData();
                            case 41:
                                e.next = 46;
                                break;
                            case 43:
                                e.prev = 43, e.t0 = e.catch(3), this.onMessageBoxAlert("", this.getErrMsg(e.t0), function() {
                                    f.onClose()
                                });
                            case 46:
                                return e.prev = 46, this.$refs.window.unmask(), e.finish(46);
                            case 49:
                            case "end":
                                return e.stop()
                        }
                    }, e, this, [
                        [3, 43, 46, 49]
                    ])
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            methods: I({}, Object(a.mapGetters)(["getProvider"]), {
                getErrMsg: function(e) {
                    return e && e.code ? SYNO.API.Errors.core[err.code] : this.T("error", "error_error_system")
                },
                onMessageBoxAlert: function(e, t, r) {
                    this.$refs.window.getMsgBox().alert(e, t).then(r)
                },
                onClose: function() {
                    var e = z(regeneratorRuntime.mark(function e() {
                        var t;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (!0 !== this.isDirty) {
                                        e.next = 12;
                                        break
                                    }
                                    return e.next = 3, this.$refs.window.getMsgBox().confirmLostChange();
                                case 3:
                                    if ("save" !== (t = e.sent)) {
                                        e.next = 9;
                                        break
                                    }
                                    return e.next = 7, this.onConfirm();
                                case 7:
                                    e.next = 10;
                                    break;
                                case 9:
                                    "dont_save" === t && this.$refs.window.close();
                                case 10:
                                    e.next = 13;
                                    break;
                                case 12:
                                    this.$refs.window.close();
                                case 13:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                onCancel: function() {
                    return this.onClose(), !0
                },
                onConfirm: function() {
                    var e = z(regeneratorRuntime.mark(function e() {
                        var t;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.isProviderValid();
                                case 2:
                                    if (e.sent) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 4:
                                    return e.next = 6, this.$store.dispatch("setDescription", this.fields);
                                case 6:
                                    if ("ifttt" !== this.type) {
                                        e.next = 11;
                                        break
                                    }
                                    return e.next = 9, this.$store.dispatch("setValue3", this.fields.value3);
                                case 9:
                                    e.next = 20;
                                    break;
                                case 11:
                                    if ("custom" !== this.type) {
                                        e.next = 20;
                                        break
                                    }
                                    return e.next = 14, this.updateSelectedParams();
                                case 14:
                                    return e.next = 16, this.$refs.selectParams.saveSelectedParams();
                                case 16:
                                    if (e.t0 = e.sent, !1 !== e.t0) {
                                        e.next = 20;
                                        break
                                    }
                                    return this.activeTabKey = "paramters", e.abrupt("return", !1);
                                case 20:
                                    return e.next = 22, this.getProvider();
                                case 22:
                                    return t = e.sent, this.fields.originalProvider !== this.fields.provider && (t.provider = this.fields.originalProvider, t.new_provider = this.fields.provider), e.prev = 24, this.$refs.window.mask(.4), e.next = 28, synowebapi.promises.request({
                                        api: "SYNO.Core.Notification.Push.Webhook.Provider",
                                        method: "set",
                                        version: 1,
                                        params: t
                                    });
                                case 28:
                                    e.sent, this.isDirty = !1, this.onClose(), e.next = 36;
                                    break;
                                case 33:
                                    e.prev = 33, e.t1 = e.catch(24), this.onMessageBoxAlert("", this.getErrMsg(e.t1), function() {});
                                case 36:
                                    return e.prev = 36, this.$refs.window.unmask(), e.finish(36);
                                case 39:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this, [
                            [24, 33, 36, 39]
                        ])
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                showEditDialog: function(e, t, r, n) {
                    var a = this,
                        i = this.$refs.window.openModalWindow(V, {
                            parameter: e,
                            value: t,
                            type: r,
                            index: n
                        }),
                        s = i.window,
                        o = i.component;
                    s.confirm(), o.$on("update-param", function(e, t, r, n) {
                        a.onChange(!0), "header" === r ? n === a.requestHeaders.length ? a.$refs.header.addData(e, t) : (a.requestHeaders[n].parameter = e, a.requestHeaders[n].value = t) : n === a.formData.length ? a.$refs.body.addData(e, t) : (a.formData[n].parameter = e, a.formData[n].value = t)
                    })
                },
                isProviderValid: function() {
                    var e = z(regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.description.updateProviderList();
                                case 2:
                                    return e.next = 4, this.$refs.description.$refs.form.validate();
                                case 4:
                                    if (e.sent) {
                                        e.next = 7;
                                        break
                                    }
                                    return this.activeTabKey = "provider", e.abrupt("return", !1);
                                case 7:
                                    return e.abrupt("return", !0);
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                updateSelectedParams: function() {
                    var e = z(regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.description.setDescription();
                                case 2:
                                    return e.next = 4, this.$store.dispatch("setParameter", JSON.parse(JSON.stringify(this.$refs.selectParams.data)));
                                case 4:
                                    return e.next = 6, this.$refs.selectParams.updateData();
                                case 6:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                onTabChange: function() {
                    var e = z(regeneratorRuntime.mark(function e(t) {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (e.t0 = "provider" !== t, !e.t0) {
                                        e.next = 5;
                                        break
                                    }
                                    return e.next = 4, this.isProviderValid();
                                case 4:
                                    e.t0 = !e.sent;
                                case 5:
                                    if (!e.t0) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 7:
                                    return e.next = 9, this.updateSelectedParams();
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                onChange: function(e) {
                    this.isDirty = this.isDirty || e
                }
            })
        },
        Y = (r(15), c(U, function() {
            var e = this,
                t = e.$createElement,
                r = e._self._c || t;
            return r("v-modal-window", {
                ref: "window",
                staticClass: "webhook-edit-dialog",
                attrs: {
                    "syno-id": "windows-webhook-edit-dialog-modal-window-0",
                    height: "480",
                    width: "540",
                    resizable: !1,
                    title: e.title
                }
            }, ["" !== e.type ? r("v-tabs", {
                class: {
                    "hide-bars": "chat" === e.type
                },
                attrs: {
                    "syno-id": "windows-webhook-edit-dialog-tabs-0"
                },
                on: {
                    cancel: e.onCancel,
                    change: e.onTabChange,
                    confirm: e.onConfirm
                },
                model: {
                    value: e.activeTabKey,
                    callback: function(t) {
                        e.activeTabKey = t
                    },
                    expression: "activeTabKey"
                }
            }, [r("v-tab-pane", {
                attrs: {
                    "syno-id": "windows-webhook-edit-dialog-tab-pane-0",
                    "tab-key": "provider",
                    tab: e.T("pushservice", "tab_provider")
                }
            }, [r("description", {
                ref: "description",
                attrs: {
                    fields: e.fields,
                    type: e.type
                },
                on: {
                    "on-change": e.onChange
                }
            })], 1), e._v(" "), "custom" === e.type ? r("v-tab-pane", {
                attrs: {
                    "syno-id": "windows-webhook-edit-dialog-tab-pane-1",
                    "tab-key": "request",
                    tab: e.T("pushservice", "tab_http_request")
                }
            }, [r("v-perfect-scrollbar", [r("request-editor", {
                ref: "header",
                attrs: {
                    data: e.requestHeaders,
                    "params-string": e.req_header,
                    type: "header",
                    sepchar: e.sepchar
                },
                on: {
                    "edit-dialog": e.showEditDialog,
                    "on-change": e.onChange
                }
            }), e._v(" "), "post" === e.fields.req_method ? r("request-editor", {
                ref: "body",
                attrs: {
                    data: e.formData,
                    "params-string": e.req_param,
                    type: "body",
                    sepchar: e.sepchar
                },
                on: {
                    "edit-dialog": e.showEditDialog,
                    "on-change": e.onChange
                }
            }) : e._e()], 1)], 1) : e._e(), e._v(" "), "chat" !== e.type ? r("v-tab-pane", {
                attrs: {
                    "syno-id": "windows-webhook-edit-dialog-tab-pane-2",
                    "tab-key": "parameters",
                    tab: e.T("pushservice", "tab_parameter")
                }
            }, [r("select-params", {
                ref: "selectParams",
                attrs: {
                    fields: e.fields,
                    type: e.type,
                    requestHeaders: e.requestHeaders,
                    formData: e.formData
                },
                on: {
                    "alert-message-box": e.onMessageBoxAlert,
                    "on-change": e.onChange
                }
            })], 1) : e._e()], 1) : e._e()], 1)
        }, [], !1, null, null, null).exports),
        F = function() {
            return {
                type: "",
                port: 0,
                template: "",
                req_method: "",
                req_header: "",
                req_param: "",
                needssl: !0,
                url: "",
                provider: void 0,
                prefix: _T("pushservice", "default_prefix"),
                sepchar: " ",
                value3: "",
                requestHeaders: [],
                queryParams: [],
                formData: [],
                selectedParams: [],
                selectOptions: [{
                    label: _T("pushservice", "url_param_content"),
                    value: "@@FULLTEXT@@"
                }, {
                    label: _T("smsnotify", "url_param_other"),
                    value: "@@OTHER@@"
                }]
            }
        },
        X = F(),
        G = {
            RESET_STATE: function(e, t) {
                Object.assign(e, F())
            },
            SELECT_TYPE: function(e, t) {
                e.type = t
            },
            SET_TEMP_DESCRIPTION: function(e, t) {
                e.provider = t.provider, e.prefix = t.prefix, e.url = t.url, e.req_method = t.req_method
            },
            SET_DESCRIPTION: function(e, t) {
                e.provider = t.provider, e.url = t.url, e.template = t.url, e.req_method = t.req_method, e.needssl = t.needssl, e.port = t.port, e.prefix = t.prefix, e.req_param = "chat" === e.type ? 'payload={"text": "@@FULLTEXT@@"}' : ""
            },
            SET_PARAMETER: function(e, t) {
                e.selectedParams = t
            },
            SET_HEADER: function(e, t) {
                e.requestHeaders = t
            },
            SET_QUERY_PARAMS: function(e, t) {
                e.queryParams = t
            },
            SET_FROM_DATA: function(e, t) {
                e.formData = t
            },
            SET_VALUE3: function(e, t) {
                e.value3 = t, e.req_param = '{"value1": "@@PREFIX@@", "value2": "@@TEXT@@", "value3": "'.concat(e.value3, '"}')
            },
            SET_SEPCHAR: function(e, t) {
                e.sepchar = t
            },
            GEN_TEMP: function(e, t) {
                var r = {};
                e.selectedParams.forEach(function(t) {
                    switch (t.type) {
                        case "query":
                            var n = p.methods.parseQuery(e.url),
                                a = "".concat(t.parameter, "=").concat(n[t.parameter]),
                                i = "@@OTHER@@" === t.value ? "".concat(encodeURIComponent(t.parameter), "=").concat(encodeURIComponent(t.originalValue)) : "".concat(t.parameter, "=").concat(t.value);
                            e.template = e.template.replace(a, i);
                            break;
                        case "header":
                            e.req_header += "".concat(t.parameter, ":").concat("@@OTHER@@" === t.value ? t.originalValue : t.value, "\r");
                            break;
                        case "form":
                            r[t.parameter] = "@@OTHER@@" === t.value ? t.originalValue : t.value
                    }
                }), e.req_param = JSON.stringify(r)
            }
        },
        Q = new i.a.Store({
            state: X,
            mutations: G,
            actions: {
                resetState: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("RESET_STATE", t)
                },
                selectType: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SELECT_TYPE", t)
                },
                setTempDescription: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_TEMP_DESCRIPTION", t)
                },
                setDescription: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_DESCRIPTION", t)
                },
                setParameter: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_PARAMETER", t)
                },
                setHeader: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_HEADER", t)
                },
                setQueryParams: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_QUERY_PARAMS", t)
                },
                setFormData: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_FROM_DATA", t)
                },
                setValue3: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_VALUE3", t)
                },
                setSepChar: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("SET_SEPCHAR", t)
                },
                genTemp: function(e, t) {
                    var r = e.commit;
                    e.dispatch, r("GEN_TEMP", t)
                }
            },
            getters: {
                getProvider: function(e) {
                    return {
                        type: e.type,
                        port: e.port,
                        template: e.template,
                        req_method: e.req_method,
                        req_header: e.req_header,
                        req_param: e.req_param,
                        needssl: e.needssl,
                        url: e.url,
                        provider: e.provider,
                        prefix: e.prefix,
                        sepchar: e.sepchar
                    }
                }
            },
            strict: !0
        }),
        W = Vue.extend({
            store: Q
        });
    Ext.namespace("SYNO.SDS.AdminCenter.Notification"), 
/**
 * @class SYNO.SDS.AdminCenter.Notification.WebhookWizard
 * AdminCenter webhook wizard
 *
 */
    SYNO.SDS.AdminCenter.Notification.WebhookWizard = W.extend(j), SYNO.SDS.AdminCenter.Notification.WebhookEditDialog = W.extend(Y)
}]);
