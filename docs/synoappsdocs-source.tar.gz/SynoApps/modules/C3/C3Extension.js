/* Copyright (c) 2020 Synology Inc. All rights reserved. */

if (SYNO.SDS.DataDrivenDocuments.DrawHelper && window.c3) {
    SYNO.SDS.DataDrivenDocuments.C3 = window.c3;
    window.c3 = undefined
};