/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.SMBService.Instance", {});
Ext.define("SYNO.SDS.SMBService.AppPrivilege.Instance", {});
/**
 * @class SYNO.SDS.SMBService.SMB.AdvancedSettingsDialog
 * @extends SYNO.SDS.ModalWindow
 * SMBService advanced settings dialog class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.AdvancedSettingsDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.module = a.module;
        this.smbApiMaxVersion = a.smbApiMaxVersion;
        this.enableSMBTimeMachine = false;
        this.tabPanel = this.initTabPanel();
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            title: _T("common", "adv_setting"),
            itemId: "advanced_settings_dialog",
            autoDestroy: true,
            resizable: false,
            width: 600,
            autoHeight: true,
            layout: "fit",
            border: false,
            closeAction: "cancelHandler",
            items: this.tabPanel,
            buttons: [{
                btnStyle: "grey",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "save"),
                scope: this,
                handler: this.applyHandler
            }]
        };
        b = Ext.apply(b, a);
        return b
    },
    initTabPanel: function() {
        var a = new SYNO.SDS.SMBService.SMB.AdvancedSettingsTabPanel({
            module: this.module,
            smbApiMaxVersion: this.smbApiMaxVersion
        });
        return a
    },
    onShow: function() {
        this.tabPanel.onShow()
    },
    applyHandler: function() {
        this.tabPanel.applyForms()
    },
    cancelHandler: function() {
        var a = {
            dontSave: function() {
                this.close()
            },
            cancel: Ext.emptyFn,
            save: function() {
                this.tabPanel.applyForms()
            }
        };
        if (this.tabPanel.isAnyFormDirty()) {
            this.confirmLostChangePromise(a, this)
        } else {
            this.close()
        }
    }
});
Ext.define("SYNO.SDS.SMBService.SMB.AdvancedSettingsTabPanel", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(a) {
        this.module = a.module;
        this.smbApiMaxVersion = a.smbApiMaxVersion;
        this.generalTab = new SYNO.SDS.SMBService.SMB.GeneralTab({
            module: this.module,
            smbApiMaxVersion: this.smbApiMaxVersion
        });
        this.macTab = new SYNO.SDS.SMBService.SMB.MacTab({
            module: this.module
        });
        this.othersTab = new SYNO.SDS.SMBService.SMB.OthersTab({
            module: this.module
        });
        this.smbConfig = this.fillSmbConfigTable();
        var b = {
            itemId: "advanced_settings_tabpanel",
            autoHeight: true,
            activeTab: 0,
            useDefaultBtn: false,
            items: [this.generalTab, this.macTab, this.othersTab]
        };
        b = Ext.apply(b, a);
        this.callParent([b])
    },
    onShow: function() {
        var b = {
            api: "SYNO.Core.FileServ.SMB",
            method: "get",
            version: this.smbApiMaxVersion
        };
        var a = {
            api: "SYNO.Core.FileServ.ServiceDiscovery",
            method: "get",
            version: 1
        };
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        this.sendWebAPI({
            scope: this,
            compound: {
                params: [b, a]
            },
            callback: function(h, f, e) {
                this.clearStatusBusy();
                if (h) {
                    var g = SYNO.API.Response.GetValByAPI(f, b.api, b.method);
                    var d = this.getAllForms();
                    for (var c = 0; c < d.length; ++c) {
                        d[c].setValues(g)
                    }
                    this.loadAllConfirmHook(g);
                    if (3 === this.smbApiMaxVersion) {
                        this.generalTab.updateSMBProtcolStatus()
                    }
                    this.enableSMBTimeMachine = SYNO.API.Response.GetValByAPI(f, a.api, a.method, "enable_smb_time_machine")
                }
            }
        })
    },
    loadAllConfirmHook: function(c) {
        var b = this.items.items;
        if (Ext.isObject(c)) {
            for (var a = 0; a < b.length; ++a) {
                if ("function" === typeof b[a].loadConfirmHook) {
                    b[a].loadConfirmHook(c)
                }
            }
        }
    },
    fillSmbConfigTable: function() {
        var a = {
            wins: {
                idx: 0
            },
            smb_max_protocol: {
                idx: 0
            },
            smb_min_protocol: {
                idx: 0
            },
            smb_encrypt_transport: {
                idx: 0
            },
            enable_server_signing: {
                idx: 0
            },
            enable_op_lock: {
                idx: 0
            },
            enable_smb2_leases: {
                idx: 0
            },
            enable_durable_handles: {
                idx: 0
            },
            enable_syno_catia: {
                idx: 1
            },
            enable_local_master_browser: {
                idx: 2
            },
            enable_dirsort: {
                idx: 2
            },
            enable_vetofile: {
                idx: 2
            },
            vetofile: {
                idx: 2
            },
            enable_delete_vetofiles: {
                idx: 2
            },
            enable_symlink: {
                idx: 2
            },
            enable_widelink: {
                idx: 2
            },
            enable_msdfs: {
                idx: 2
            },
            enable_reset_on_zero_vc: {
                idx: 2
            },
            enable_enhance_log: {
                idx: 2
            },
            enable_mask: {
                idx: 2
            },
            disable_strict_allocate: {
                idx: 2
            },
            syno_wildcard_search: {
                idx: 2
            }
        };
        return a
    },
    applyForms: function() {
        var d = this.getAllForms();
        var e = {};
        if (!this.isAnyFormDirty()) {
            this.ownerCt.close();
            return false
        }
        for (var a = 0; a < d.length; ++a) {
            if (!d[a].isValid()) {
                this.ownerCt.setStatusError({
                    text: _T("common", "forminvalid"),
                    clear: true
                });
                return false
            }
            e = Object.assign(e, d[a].getValues())
        }
        e.enable_smb2_leases = this.generalTab.getComponent("enable_smb2_leases").getValue();
        e.enable_widelink = this.othersTab.getComponent("enable_widelink").getValue();
        e.enable_delete_vetofiles = this.othersTab.getComponent("enable_delete_vetofiles").getValue();
        var c = this.isNeededConfirmBeforeSubmit();
        var b = this.isNeededConfirmTimeMachineBeforeSubmit();
        if (e.enable_samba && c) {
            if (b) {
                this.confirmSMBTimeMachineBeforeSubmit(e)
            } else {
                this.confirmBeforeSubmit(e)
            }
        } else {
            this.submit(e)
        }
        return true
    },
    isNeededConfirmBeforeSubmit: function() {
        var d = false;
        var b = ["wins", "enable_local_master_browser", "enable_op_lock", "enable_reset_on_zero_vc", "enable_vetofile", "vetofile", "disable_strict_allocate", "syno_wildcard_search", "enable_durable_handles", "enable_smb2_leases"];
        var c = ["smb_max_protocol", "smb_min_protocol", "smb_encrypt_transport"];
        var a = this.items.items;
        d = d || b.some(function(f) {
            var e = this.smbConfig[f].idx;
            return a[e].getComponent(f).isDirty()
        }, this);
        if (3 === this.smbApiMaxVersion) {
            d = d || c.some(function(f) {
                var e = this.smbConfig[f].idx;
                return a[e].getComponent(f).isDirty()
            }, this)
        }
        return d
    },
    isNeededConfirmTimeMachineBeforeSubmit: function() {
        var c = false;
        var b = ["enable_durable_handles", "enable_smb2_leases", "enable_op_lock", "smb_max_protocol"];
        var a = this.items.items;
        if (false === this.enableSMBTimeMachine) {
            return false
        }
        c = b.some(function(f) {
            var d = this.smbConfig[f].idx;
            if ("smb_max_protocol" === f) {
                var e = a[d].getComponent(f).getValue();
                if (3 > e) {
                    return true
                }
                return false
            }
            return !a[d].getComponent(f).checked
        }, this);
        return c
    },
    confirmSMBTimeMachineBeforeSubmit: function(a) {
        this.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "disable_smb_time_machine_mdns") + " " + _T("common", "ask_cont"), function(b, c) {
            if ("yes" === b) {
                this.enableSMBTimeMachine = false;
                this.confirmBeforeSubmit(a)
            }
        }, this)
    },
    confirmBeforeSubmit: function(a) {
        this.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "service_restart_warning") + " " + _T("common", "ask_cont"), function(d, c, b) {
            if ("yes" == d) {
                this.submit(a)
            }
        }, this)
    },
    submit: function(c) {
        var b = {
            api: "SYNO.Core.FileServ.SMB",
            method: "set",
            version: this.smbApiMaxVersion,
            params: c
        };
        var a = {
            api: "SYNO.Core.FileServ.ServiceDiscovery",
            method: "set",
            version: 1,
            params: {
                enable_smb_time_machine: this.enableSMBTimeMachine
            }
        };
        this.ownerCt.setStatusBusy();
        this.sendWebAPI({
            compound: {
                params: [b, a]
            },
            scope: this,
            callback: function(f, e, d) {
                this.ownerCt.clearStatusBusy();
                if (f) {
                    this.ownerCt.close();
                    this.module.panel.advTab.loadForm();
                    return true
                } else {
                    this.ownerCt.setStatusError()
                }
            }
        })
    }
});
