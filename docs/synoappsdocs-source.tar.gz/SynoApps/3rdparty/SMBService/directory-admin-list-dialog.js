/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.SMBService.Domain");
SYNO.SDS.SMBService.Domain.Error2Msg = function(a) {
    return SYNO.API.getErrorString(a)
};
SYNO.SDS.SMBService.Domain.Alert = function(b, g, c) {
    var f = _T("network", "domain_set_admin");
    var e = _T("common", "error_system");
    var d = -1;
    if (!b) {} else {
        if (typeof b === "string") {
            e = b
        } else {
            if (typeof b === "number") {
                d = b;
                e = SYNO.API.getErrorString(d)
            } else {
                if (b instanceof Array) {
                    for (var a = 0; a < b.length; a++) {
                        if (!b[a].success) {
                            d = b[a].error.code;
                            e = SYNO.API.getErrorString(d);
                            break
                        }
                    }
                }
            }
        }
    }
    this.getMsgBox().alert(f, e, g, c)
};
/**
 * @class SYNO.SDS.SMBService.Domain.DirectoryAdminDialog
 * @extends SYNO.SDS.ModalWindow
 * SMBService directory admin dialog class
 *
 */
Ext.define("SYNO.SDS.SMBService.Domain.DirectoryAdminDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.module = b.module;
        this.owner = b.owner;
        this.authType = b.authType;
        this.store = this.createStore(b);
        this.grid = this.createGridPanel();
        var a = this.fillConfig(b);
        this.callParent([a])
    },
    fillConfig: function(a) {
        return Ext.apply({
            width: 750,
            height: 570,
            title: _T("network", "domain_set_admin"),
            layout: "fit",
            items: [this.grid],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "close"),
                btnStyle: "blue",
                scope: this,
                handler: function() {
                    this.close()
                }
            }],
            listeners: {
                close: {
                    scope: this,
                    fn: function(b) {
                        this.store.removeAll()
                    }
                }
            }
        }, a)
    },
    createGridPanel: function() {
        this.actionRemove = this.createActionRemove();
        var a = {
            itemId: "grid",
            border: false,
            store: this.store,
            columns: [{
                id: "user_type",
                dataIndex: "type",
                width: 30,
                sortable: true,
                renderer: function(d, c, b) {
                    d = b.get("type");
                    if ("user" === d) {
                        return '<div class="acl-grid-item-user" style="width: 26px; height: 26px; margin-left: -4px;"> </div>'
                    } else {
                        return '<div class="acl-grid-item-group" style="width: 26px; height: 26px; margin-left: -4px;"> </div>'
                    }
                }
            }, {
                id: "username",
                header: _T("group", "grp_name"),
                dataIndex: "name",
                sortable: true,
                width: 500
            }],
            autoExpandColumn: "username",
            enableHdMenu: false,
            enableColumnMove: false,
            selModel: new Ext.grid.RowSelectionModel({
                single: true,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: function(c) {
                            var b = c.getCount();
                            this.actionRemove.setDisabled((b === 0))
                        }
                    }
                }
            }),
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                trackResetOnLoad: false,
                rowHeight: 27,
                scrollDelay: false,
                cacheSize: 50
            }),
            tbar: {
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "add"),
                    itemId: "add",
                    scope: this,
                    handler: this.addMembers
                }, new SYNO.ux.Button(this.actionRemove)]
            },
            bbar: new SYNO.ux.PageLessToolbar({
                store: this.store,
                displayInfo: true,
                showRefreshBtn: false
            })
        };
        return new SYNO.ux.GridPanel(a)
    },
    createActionRemove: function() {
        return new Ext.Action({
            text: _T("common", "delete"),
            itemId: "remove",
            scope: this,
            handler: this.removeMembers
        })
    },
    createStore: function(a) {
        return new SYNO.API.JsonStore({
            autoDestroy: true,
            appWindow: a.owner,
            api: "SYNO.Core.Group.ExtraAdmin",
            method: "get",
            version: 1,
            baseParams: {
                category: this.authType
            },
            idProperty: "name",
            totalProperty: "total",
            root: "list",
            fields: [{
                name: "name",
                sortType: "asNaturalUCString"
            }, "type"],
            listeners: {
                exception: this.onStoreException,
                beforeload: this.onBeforeLoad,
                load: this.onLoad,
                scope: this
            }
        })
    },
    addMembers: function() {
        var a = new SYNO.SDS.SMBService.Domain.UserChooser({
            owner: this,
            module: this.module,
            authType: this.authType
        });
        this.mon(a, "close", this.afterUserChooser, this);
        a.load()
    },
    afterUserChooser: function(b) {
        var a = b.getRecords();
        var c = [];
        var d = (0 === b.curUserType) ? "user" : "group";
        if (a.length > 0) {
            Ext.each(a, function(e) {
                c.push({
                    name: e.get("name"),
                    type: d
                });
                return true
            });
            this.applyAddMembers(c)
        }
        this.mun(b, "close", this.afterUserChooser, this)
    },
    applyAddMembers: function(a) {
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Core.Group.ExtraAdmin",
            method: "add",
            version: 1,
            params: {
                list: a,
                category: this.authType
            },
            scope: this,
            callback: this.afterAddMembers
        })
    },
    afterAddMembers: function(c, b, a) {
        this.clearStatusBusy();
        if (c) {
            this.store.load()
        } else {
            SYNO.SDS.SMBService.Domain.Alert.call(this, b.code)
        }
    },
    removeMembers: function() {
        var b = this.grid.getSelectionModel().getSelections();
        var d = this.getMsgBox();
        var c = [];
        var a = "";
        Ext.each(b, function(g, f, e) {
            c.push({
                name: g.get("name"),
                type: g.get("type")
            });
            if (a !== "") {
                a = a + ","
            }
            a = a + g.get("name")
        }, this);
        d.confirmDelete(_T("network", "domain_set_admin"), String.format(_T("network", "cfrm_remove_dir_adm") + "<br>{0}", a), function(e) {
            if (e === "yes") {
                this.position = this.grid.getBottomToolbar().cursor + this.store.indexOf(b[0]);
                this.applyRemoveMembers(c)
            }
        }, this)
    },
    applyRemoveMembers: function(a) {
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Core.Group.ExtraAdmin",
            method: "delete",
            version: 1,
            params: {
                list: a,
                category: this.authType
            },
            scope: this,
            callback: this.afterRemoveMembers
        })
    },
    afterRemoveMembers: function(c, b, a) {
        this.clearStatusBusy();
        if (c) {
            this.store.load({
                params: {
                    ingroup: true
                }
            })
        } else {
            SYNO.SDS.SMBService.Domain.Alert.call(this, b.code)
        }
    },
    onStoreException: function(d, e, f, c, b, a) {
        this.clearStatusBusy();
        if (b.code === 3105 || b.code === 3203) {
            this.grid.getEl().mask(_T("directory_service", "warr_db_not_ready"), "syno-ux-mask-info");
            return
        }
        SYNO.SDS.SMBService.Domain.Alert.call(this, b.code)
    },
    onBeforeLoad: function(a, b) {
        this.setStatusBusy()
    },
    onLoad: function(c, b, d) {
        this.clearStatusBusy();
        this.totalNum = c.totalLength;
        if (this.focusMembers && this.focusMembers.length) {
            var a = c.indexOfId(this.focusMembers[0]);
            if (a !== -1) {
                this.grid.getSelectionModel().selectRow(a);
                (function() {
                    this.grid.getView().focusRow(a)
                }).defer(100, this)
            }
        }
        if (c.getCount() > 0) {
            this.grid.getSelectionModel().selectFirstRow()
        } else {
            this.grid.getTopToolbar().getComponent("remove").disable()
        }
    },
    load: function() {
        this.store.load();
        this.show()
    }
});
Ext.define("SYNO.SDS.SMBService.Domain.UserChooser", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.module = a.module;
        this.authType = a.authType ? a.authType : "domain";
        this.curUserType = 1;
        this.pageSize = 50;
        if ("domain" === this.authType) {
            this.domainFilter = new SYNO.SDS.SMBService.Domain.Filter({
                module: this.module
            })
        }
        this.store = this.createGroupStore();
        this.grid = this.createGridPanel(a);
        this.domainFilter.grid = this.grid;
        var b = {
            module: this,
            title: _T("group", "add_groups"),
            autoDestroy: true,
            width: 750,
            height: 500,
            minWidth: 300,
            minHeight: 250,
            layout: "fit",
            items: [this.grid],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                itemId: "cancel",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelDialog
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                itemId: "add",
                text: _T("common", "add"),
                btnStle: "blue",
                scope: this,
                handler: this.collectSelected
            }]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createUserStore: function() {
        var b = ["description"];
        var a = [{
            name: "name",
            sortType: "asNaturalUCString"
        }, "description"];
        var c = {
            api: "SYNO.Core.User",
            method: "list",
            version: 1,
            appWindow: this,
            baseParams: {
                type: this.authType,
                offset: 0,
                limit: this.pageSize,
                additional: b
            },
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onStoreException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            root: "users",
            totalProperty: "total",
            id: "name",
            fields: a,
            remoteSort: true,
            defaultSortable: true,
            scope: this
        };
        return new SYNO.API.JsonStore(c)
    },
    createGroupStore: function() {
        var a = [{
            name: "name",
            sortType: "asNaturalUCString"
        }, "description"];
        var b = {
            api: "SYNO.Core.Group",
            method: "list",
            version: 1,
            appWindow: this,
            baseParams: {
                offset: 0,
                limit: this.pageSize,
                name_only: true,
                type: this.authType
            },
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onStoreException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            root: "groups",
            totalProperty: "total",
            id: "name",
            fields: a,
            remoteSort: true,
            defaultSortable: true,
            scope: this
        };
        return new SYNO.API.JsonStore(b)
    },
    createGridPanel: function(b) {
        var a = {
            border: false,
            store: this.store,
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: true
                },
                columns: [{
                    id: "name",
                    header: _T("user", "user_account"),
                    dataIndex: "name",
                    width: 200
                }, {
                    id: "description",
                    header: _T("user", "user_fullname"),
                    dataIndex: "description",
                    width: 150,
                    renderer: Ext.util.Format.htmlEncode
                }]
            }),
            autoExpandColumn: "description",
            enableHdMenu: false,
            enableColumnMove: false,
            tbar: this.configTopToolbar(),
            bbar: this.createBBar(),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: false,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: this.onSelectionChange
                    }
                }
            }),
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                trackResetOnLoad: false,
                rowHeight: 27,
                scrollDelay: false,
                cacheSize: 50
            })
        };
        return new SYNO.ux.GridPanel(a)
    },
    configTopToolbar: function() {
        this.findField = new SYNO.ux.TextFilter({
            iconStyle: "search",
            queryParam: "substr",
            itemId: "search",
            emptyText: _T("group", "search_group"),
            store: this.store,
            pageSize: this.pageSize
        });
        if (this.authType === "ldap") {
            return {
                items: ["->", this.findField]
            }
        } else {
            if (this.authType === "domain") {
                this.domainFilter.grid = this.grid;
                return {
                    items: [{
                        xtype: "syno_displayfield",
                        itemId: "filterName",
                        value: _T("helptoc", "directory_service_domain") + _T("common", "colon"),
                        style: "margin-right: 8px"
                    }, this.domainFilter, "->", this.findField]
                }
            }
        }
        return {
            items: []
        }
    },
    createBBar: function() {
        this.pageToolbar = new SYNO.ux.PagingToolbar({
            store: this.store,
            pageSize: this.pageSize,
            displayButtons: true,
            displayInfo: true
        });
        return this.pageToolbar
    },
    collectSelected: function() {
        this.records = this.grid.getSelectionModel().getSelections();
        this.close()
    },
    cancelDialog: function() {
        this.grid.getSelectionModel().clearSelections();
        this.close()
    },
    domainActivateLoad: function() {
        this.sendWebAPI({
            api: "SYNO.Core.Directory.Domain",
            version: 2,
            method: "get_domain_list",
            scope: this,
            callback: function(c, b, a) {
                if (c) {
                    this.domainFilter.updateList(b.domain_list);
                    this.store.baseParams.domain_name = this.module.currDomain
                }
                this.store.load()
            }
        })
    },
    load: function() {
        this.setBtnAddDisable(true);
        this.records = [];
        if ("domain" === this.authType) {
            this.domainActivateLoad()
        } else {
            this.store.load()
        }
        this.show()
    },
    setBtnAddDisable: function(a) {
        var b = this.getFooterToolbar();
        var c = b.getComponent("add");
        c.setDisabled(a)
    },
    getRecords: function() {
        return this.records
    },
    onSelectionChange: function(a) {
        var b = a.getCount();
        this.setBtnAddDisable((b === 0))
    },
    onStoreException: function(d, e, f, c, b, a) {
        var g;
        SYNO.Debug("Store exception: options:", d, e, f, c, b, a);
        this.clearStatusBusy();
        if (!b.code) {
            this.setStatusError();
            return
        }
        if (b.code === 3105 || b.code === 3203) {
            this.grid.getEl().mask(_T("directory_service", "warr_db_not_ready"), "syno-ux-mask-info");
            return
        }
        g = b.code;
        if (this.findField.getValue()) {
            this.findField.reset()
        }
        if (0 === this.curUserType) {
            SYNO.SDS.SMBService.Domain.Alert.call(this.appWin, _T("user", "failed_load_user"))
        } else {
            SYNO.SDS.SMBService.Domain.Alert.call(this.appWin, _T("group", "failed_load_group"))
        }
    },
    onBeforeLoad: function(a, b) {
        var c = [];
        if ("domain" === this.authType) {
            this.domainFilter.setValue(this.module.currDomain)
        }
        this.store.baseParams.domain_name = this.module.currDomain ? this.module.currDomain : "";
        this.grid.getColumnModel().getColumnsBy(function(d) {
            if (!d.hidden) {
                c.push(d.dataIndex)
            }
            return false
        });
        b.params.searchFields = c;
        this.setStatusBusy()
    },
    onLoad: function(c, a, b) {
        this.clearStatusBusy();
        this.grid.getSelectionModel().clearSelections()
    }
});
