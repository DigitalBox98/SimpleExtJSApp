/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.SMB.SMBProtocolComboBox
 * @extends SYNO.ux.ComboBox
 * SMBService SMBProtocol combobox class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.SMBProtocolComboBox", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(a) {
        var b, c;
        this.displayField = a.displayField || "display";
        c = 'ext:qtip="{' + this.displayField + ':htmlEncode}"';
        b = {
            tpl: new Ext.XTemplate('<tpl for=".">', "<div " + c + ' class="x-combo-list-item" role="option" aria-label="{' + this.displayField + '}" id="{[Ext.id()]}">', "<div " + c + ">{" + this.displayField + "}</div>", "</div>", "</tpl>")
        };
        SYNO.ux.StorageComboBox.superclass.constructor.call(this, Ext.apply(b, a))
    }
});
Ext.reg("synosamba_smb_protocol_combobox", SYNO.SDS.SMBService.SMB.SMBProtocolComboBox);
Ext.define("SYNO.SDS.SMBService.SMB.GeneralTab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.module = a.module;
        this.smbApiMaxVersion = a.smbApiMaxVersion;
        this.protocolList = [
            [_T("network", "cifs_smb1_enable"), 0],
            [_T("network", "cifs_smb2_enable"), 1],
            [_T("network", "cifs_smb2_large_mtu_enable"), 2],
            [_T("network", "cifs_smb3_enable"), 3]
        ];
        var b = Ext.apply(this.fillConfig(), a);
        this.callParent([b]);
        this.on("afterlayout", function() {
            this.enableOplockGroupDummy = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_op_lock", ["enable_smb2_leases"])
        }, this, {
            single: true
        })
    },
    loadConfirmHook: function(a) {
        this.mon(this.getComponent("enable_op_lock"), "check", this.confirmOpLock, this)
    },
    fillConfig: function() {
        var c = {
            autoscroll: true,
            title: _T("network", "smb_general"),
            border: false,
            itemId: "general_tab",
            trackResetOnLoad: true,
            height: 430,
            width: 250,
            padding: 8,
            labelWidth: 250,
            items: [{
                xtype: "syno_textfield",
                width: 200,
                name: "wins",
                maxlength: 15,
                itemId: "wins",
                fieldLabel: _T("network", "netif_wins"),
                vtype: "ip"
            }, {
                xtype: "syno_checkbox",
                name: "enable_op_lock",
                itemId: "enable_op_lock",
                boxLabel: _T("network", "cifs_oplock")
            }, {
                xtype: "syno_checkbox",
                name: "enable_smb2_leases",
                indent: 1,
                itemId: "enable_smb2_leases",
                boxLabel: _T("network", "enable_smb2_leases")
            }, {
                xtype: "syno_checkbox",
                name: "enable_durable_handles",
                itemId: "enable_durable_handles",
                boxLabel: _T("network", "enable_durable_handles")
            }, {
                xtype: "syno_button",
                itemId: "smb_clear_tdb",
                btnStyle: "default",
                text: _T("network", "smb_clear_tdb"),
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.clearTDB,
                scope: this
            }, {
                xtype: "syno_checkbox",
                name: "enable_samba",
                hidden: true
            }]
        };
        if (3 === this.smbApiMaxVersion) {
            var a = c.items;
            var b = [{
                xtype: "synosamba_smb_protocol_combobox",
                name: "smb_max_protocol",
                itemId: "smb_max_protocol",
                indent: 0,
                fieldLabel: _T("network", "smb_max_protocol"),
                displayField: "display",
                valueField: "value",
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    idIndex: 0,
                    data: this.protocolList
                }),
                listeners: {
                    select: this.updateSMBProtcolStatus,
                    scope: this
                }
            }, {
                xtype: "synosamba_smb_protocol_combobox",
                name: "smb_min_protocol",
                itemId: "smb_min_protocol",
                indent: 0,
                fieldLabel: _T("network", "smb_min_protocol"),
                displayField: "display",
                valueField: "value",
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    idIndex: 0,
                    data: this.protocolList
                }),
                listeners: {
                    select: this.updateSMBProtcolStatus,
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                name: "smb_enabled_protocol",
                itemId: "smb_enabled_protocol",
                htmlEncode: false,
                fieldLabel: _T("network", "smb_avail_protocol")
            }, {
                xtype: "syno_combobox",
                name: "smb_encrypt_transport",
                itemId: "smb_encrypt_transport",
                indent: 0,
                fieldLabel: _T("network", "smb_encrypt_transport"),
                displayField: "display",
                valueField: "value",
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    idIndex: 1,
                    data: [
                        [_T("ftp", "ftp_utf8_disabled"), 0],
                        [_T("network", "determined_by_client"), 1],
                        [_T("ftp", "ftp_utf8_forced"), 2]
                    ]
                }),
                listeners: {
                    select: this.enableEncryptAlert,
                    scope: this
                }
            }, {
                xtype: "syno_combobox",
                name: "enable_server_signing",
                itemId: "enable_server_signing",
                indent: 0,
                fieldLabel: _T("domain", "enable_domain_server_signing"),
                displayField: "display",
                valueField: "value",
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    idIndex: 1,
                    data: [
                        [_T("ftp", "ftp_utf8_disabled"), 0],
                        [_T("network", "determined_by_client"), 1],
                        [_T("ftp", "ftp_utf8_forced"), 2]
                    ]
                })
            }];
            var d = 1;
            a = a.slice(0, d).concat(b).concat(a.slice(d));
            c.items = a
        }
        return c
    },
    enableClearTDB: function(a) {
        var b = this.getComponent("smb_clear_tdb");
        b.setDisabled(!a)
    },
    clearTDB: function() {
        this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "service_restart_warning") + " " + _T("common", "ask_cont"), function(a, b) {
            if ("yes" === a) {
                this.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.Core.FileServ.SMB",
                    method: "clean_cache",
                    version: 1,
                    scope: this,
                    callback: function(e, d, c) {
                        this.clearStatusBusy();
                        if (e) {
                            this.enableClearTDB(false);
                            return true
                        }
                    }
                })
            }
        }, this)
    },
    confirmOpLock: function(a, b) {
        if (!b) {
            this.getComponent("enable_smb2_leases").setValue(false)
        }
    },
    updateSMBProtcolStatus: function(j) {
        var b = j ? j.name : "";
        var a = this.getComponent("smb_max_protocol");
        var l = this.getComponent("smb_min_protocol");
        var e = this.getComponent("smb_enabled_protocol");
        var c = a.getValue();
        var d = l.getValue();
        var g = "";
        var h = this.protocolList;
        for (var f = 0; f < h.length; f++) {
            var k = h[f];
            if (k[1] >= d && k[1] <= c) {
                if ("" !== g) {
                    g = g + ","
                }
                g = g + k[0]
            }
        }
        e.setValue(g);
        e.originalValue = e.getValue();
        if ("smb_min_protocol" !== b) {
            l.store.loadData(h.filter(function(i) {
                return i[1] <= c && i[1] < 3
            }))
        }
        if ("smb_max_protocol" !== b) {
            a.store.loadData(h.filter(function(i) {
                return i[1] >= d
            }))
        }
        this.updateSMBEncryptStatus()
    },
    updateSMBEncryptStatus: function() {
        var b = this.getComponent("smb_encrypt_transport");
        var c = this.getComponent("smb_max_protocol");
        var a = true;
        if (3 === c.getValue()) {
            a = false
        }
        b.setDisabled(a)
    },
    enableEncryptAlert: function() {
        var a = this.getComponent("smb_encrypt_transport");
        if (2 === a.getValue()) {
            this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "cifs_enable_encrypt_alert"), function(d, c, b) {
                if ("no" == d) {
                    a.reset()
                }
                if ("yes" == d) {
                    this.getComponent("enable_op_lock").setValue(false)
                }
            }, this)
        }
    }
});
