/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.LogCenter.ClientDestination
 * @extends SYNO.SDS.Utils.FormPanel
 * LogCenter client destination 
 *
 */  
Ext.define("SYNO.SDS.LogCenter.ClientDestination", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    EnableTestLogBtn: function(a) {
        if (!_S("demo_mode")) {
            this.btnTestLogSend.setDisabled(!a)
        }
    },
    EnableImportCABtn: function(a) {
        if (!_S("demo_mode")) {
            this.btnCaImport.setDisabled(!a)
        }
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function(a, c) {
            var d;
            d = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable", ["server", "port", "protocol", "format"]);
            var b = this.getForm();
            b.findField("protocol").on("select", function(g, h, e) {
                var f = g.getValue();
                var i = b.findField("ssl");
                if ("tcp" === f) {
                    i.setDisabled(false);
                    this.EnableImportCABtn(true)
                } else {
                    i.setDisabled(true);
                    i.setValue(false);
                    this.EnableImportCABtn(false)
                }
            }, this)
        }, this, {
            single: true
        })
    },
    storeLogTransModeGet: function() {
        var a = [
            ["tcp", "TCP"],
            ["udp", "UDP"]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    storeLogFormatGet: function() {
        var a = [
            ["bsd", "BSD (RFC 3164)"],
            ["ietf", "IETF (RFC 5424)"]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    fillConfig: function(a) {
        var c, b = [];
        this.btnCaImport = new SYNO.ux.Button({
            name: "ca_import",
            text: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_ca_import"),
            labelSeparator: "",
            handler: this.onCaImport,
            scope: this,
            indent: 2,
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
        });
        this.btnTestLogSend = new SYNO.ux.Button({
            name: "test_log",
            text: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_test"),
            handler: this.onTestLogSend,
            scope: this,
            labelSeparator: "",
            indent: 1,
            disabled: true,
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
        });
        b.push({
            name: "enable",
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_enable")
        }, {
            name: "server",
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_ip"),
            emptyText: SYNO.SDS.LogCenter.StringGet("logclient", "tip_ip"),
            allowBlank: false,
            vtype: "iporhostname",
            maxlength: 255,
            indent: 1
        }, {
            name: "port",
            xtype: "syno_numberfield",
            fieldLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_port"),
            emptyText: SYNO.SDS.LogCenter.StringGet("common", "tip_port_num"),
            value: 514,
            minValue: 1,
            maxValue: 65535,
            maxlength: 5,
            vtype: "port",
            allowBlank: false,
            indent: 1
        }, {
            name: "protocol",
            xtype: "syno_combobox",
            fieldLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_transmode"),
            store: this.storeLogTransModeGet(),
            editable: false,
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            value: "udp",
            indent: 1
        }, {
            name: "format",
            xtype: "syno_combobox",
            fieldLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_format"),
            store: this.storeLogFormatGet(),
            editable: false,
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            value: "ietf",
            indent: 1
        }, {
            name: "ssl",
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.LogCenter.StringGet("logclient", "setting_svr_ssl"),
            indent: 1
        }, this.btnCaImport, {
            xtype: "syno_displayfield",
            value: "",
            height: 0
        }, this.btnTestLogSend);
        c = {
            title: SYNO.SDS.LogCenter.StringGet("logclient", "tab_target"),
            trackResetOnLoad: true,
            hideMode: "offsets",
            items: b,
            webapi: {
                api: "SYNO.LogCenter.Client",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1
            }
        };
        Ext.apply(c, a);
        return c
    },
    onCaImport: function() {
        var a = new SYNO.SDS.LogCenter.ClientUploadWin({
            owner: this.module.appWin
        });
        a.open()
    },
    checkSerType: function(b) {
        var a = "";
        if (Ext.form.VTypes.netbiosName(b)) {
            a = "name"
        } else {
            if (Ext.form.VTypes.looseip(b)) {
                a = "ip"
            } else {
                if (Ext.form.VTypes.hostname(b)) {
                    a = "fqdn"
                }
            }
        }
        return a
    },
    onTestLogSendDone: function(d, b, c, a) {
        this.module.appWin.clearStatusBusy();
        if (!d) {
            this.module.appWin.setStatusError({
                text: "Delete server fail[" + b.code + "]"
            });
            return
        }
        this.module.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("logclient", "dlg_testlog_sent"))
    },
    onTestLogSend: function() {
        var a = this.getForm();
        if (!a.isValid()) {
            this.module.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), _T("common", "forminvalid"));
            return false
        }
        this.module.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.LogCenter.Client",
            version: 1,
            method: "test",
            params: {
                enable: false,
                server: a.findField("server").getValue(),
                port: a.findField("port").getValue(),
                protocol: a.findField("protocol").getValue(),
                ssl: a.findField("ssl").getValue(),
                server_type: this.checkSerType(a.findField("server").getValue()),
                format: a.findField("format").getValue()
            },
            callback: this.onTestLogSendDone,
            scope: this
        })
    },
    processReturnData: function(f, e, d) {
        var a;
        for (var b = 0; b < e.result.length; b++) {
            if (e.has_fail === true && e.result[b].api == "SYNO.LogCenter.Client" && e.result[b].method == "set") {
                var c;
                switch (e.result[b].error.code) {
                    case 5006:
                    case 5007:
                        c = SYNO.SDS.LogCenter.StringGet("logclient", "service_ca_copy_failed");
                        break;
                    default:
                        c = SYNO.API.getErrorString(e.result[b].error.code);
                        break
                }
                this.module.setStatusError({
                    text: c
                });
                return
            }
        }
        this.callParent(arguments);
        a = this.getForm().findField("enable");
        a.fireEvent("check", a, a.getValue())
    }
});
Ext.define("SYNO.SDS.LogCenter.ClientUploadWin", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b;
        var c = 650;
        var d = 200;
        this.uploadForm = new SYNO.SDS.LogCenter.ClientUploadForm({
            owner: this
        });
        b = {
            title: _T("service", "service_upload_ca"),
            resizable: false,
            width: c,
            height: d,
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.uploadCert,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
            }],
            items: [this.uploadForm]
        };
        Ext.apply(b, a);
        return b
    },
    uploadCert: function() {
        this.uploadForm.uploadCert()
    }
});
Ext.define("SYNO.SDS.LogCenter.ClientUploadForm", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            fileUpload: true,
            trackResetOnLoad: true,
            hideMode: "offsets",
            frame: false,
            border: false,
            height: 120,
            items: [{
                xtype: "syno_displayfield",
                value: _T("service", "service_ssl_crt_desc")
            }, {
                xtype: "syno_filebutton",
                width: 150,
                fieldLabel: _T("common", "file"),
                name: "upload_crt"
            }],
            webapi: {
                api: "SYNO.LogCenter.Client.CA",
                method: "upload",
                version: 1
            }
        };
        Ext.apply(b, a);
        return b
    },
    onApiSuccess: function() {
        this.owner.clearStatusBusy();
        this.owner.close()
    },
    onApiFailure: function(c, b, a) {
        this.owner.clearStatusBusy();
        this.owner.setStatusError({
            text: SYNO.API.Erros.core[b.code]
        })
    },
    uploadCert: function() {
        if (!this.getForm().findField("upload_crt").getValue()) {
            this.owner.setStatusError({
                text: _T("service", "service_ssl_no_file"),
                clear: true
            });
            return
        }
        this.owner.setStatusBusy();
        this.upload()
    }
});
Ext.define("SYNO.SDS.LogCenter.ClientSetting", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(a) {
        this.tabTarget = new SYNO.SDS.LogCenter.ClientDestination({
            module: this
        });
        this.tabFilter = new SYNO.SDS.LogCenter.ClientFilter({
            module: this
        });
        var b = Ext.apply({
            activeTab: 0,
            items: [this.tabTarget, this.tabFilter]
        }, a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function(a, c) {
            var b = this.tabTarget.getForm();
            b.findField("enable").on("check", function(d, e) {
                var f = b.findField("ssl");
                if (e && ("tcp" === b.findField("protocol").getValue())) {
                    f.setDisabled(false);
                    this.tabTarget.EnableImportCABtn(true)
                } else {
                    f.setDisabled(true);
                    this.tabTarget.EnableImportCABtn(false)
                }
                this.tabTarget.EnableTestLogBtn(e);
                this.tabFilter.setDisabled(!e)
            }, this)
        }, this, {
            single: true
        })
    },
    onGetUIConfigDone: function(d, b, c, a) {
        this.appWin.clearStatusBusy();
        this.loadAllForm()
    },
    getUIConfig: function() {
        this.appWin.setStatusBusy();
        this.onGetUIConfigDone()
    },
    onPageActivate: function() {
        this.getUIConfig();
        SYNO.SDS.LogCenter.ResizePanel(this)
    },
    onPageConfirmLostChangeSave: function() {
        return new Promise(function(b, a) {
            this.savePromise = {
                resolve: b,
                reject: a
            };
            this.applyHandler()
        }.bind(this))
    },
    onApiSuccess: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.resolve();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    onApiFailure: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.reject();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    getCompoundCfg: function(a) {
        return a === "set" ? {
            stopwhenerror: true
        } : {}
    }
});
Ext.define("SYNO.SDS.LogCenter.ArchiveSetting", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function(b, d) {
            var a, e;
            var c = this.getForm();
            a = new SYNO.ux.Utils.EnableCheckGroup(c, "enable_count", ["count"]);
            e = new SYNO.ux.Utils.EnableCheckGroup(c, "enable_time", ["time"])
        }, this, {
            single: true
        })
    },
    storeLogArchSizeGet: function() {
        var a = [
            [1024, "1 GB"],
            [3072, "3 GB"]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    storeLogArchCntGet: function() {
        var a = [
            [1000000, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_cnt_1_mil")],
            [3000000, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_cnt_3_mil")],
            [5000000, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_cnt_5_mil")],
            [10000000, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_cnt_10_mil")]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    storeLogArchTimeGet: function() {
        var b = 30 * 24 * 60 * 60;
        var a = [
            [b, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_time_1_mon")],
            [3 * b, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_time_3_mon")],
            [6 * b, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_time_6_mon")],
            [12 * b, SYNO.SDS.LogCenter.StringGet("archsetting", "arch_time_1_year")]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    storeLogArchFmtGet: function() {
        var a = [
            ["db", SYNO.SDS.LogCenter.StringGet("archsetting", "arch_fmt_db")],
            ["xml", SYNO.SDS.LogCenter.StringGet("archsetting", "arch_fmt_xml")],
            ["txt", SYNO.SDS.LogCenter.StringGet("archsetting", "arch_fmt_txt")]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    createArchDest: function() {
        return new SYNO.ux.FieldSet({
            title: SYNO.SDS.LogCenter.StringGet("archsetting", "fs_arch_dest"),
            collapsible: false,
            items: [{
                xtype: "syno_compositefield",
                items: [{
                    name: "path",
                    xtype: "syno_textfield",
                    fieldLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_dest"),
                    emptyText: SYNO.SDS.LogCenter.StringGet("svrsetting", "svr_dbloc_tip"),
                    width: 250,
                    allowBlank: true
                }, {
                    xtype: "syno_button",
                    text: SYNO.SDS.LogCenter.StringGet("archsetting", "btn_arch_dest"),
                    scope: this,
                    handler: this.ArchDestSelect
                }]
            }, {
                name: "archive",
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.LogCenter.StringGet("logclient", "cbx_arch_local_log"),
                listeners: {
                    scope: this,
                    click: function(a, b) {
                        if (b) {
                            if ("" === this.getForm().findField("path").getValue()) {
                                a.setValue(false);
                                this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("listpanel", "svr_setting"), SYNO.SDS.LogCenter.StringGet("archsetting", "cfm_select_arch_dest"))
                            }
                        }
                    }
                }
            }]
        })
    },
    createArchRule: function() {
        return new SYNO.ux.FieldSet({
            title: SYNO.SDS.LogCenter.StringGet("archsetting", "fs_arch_rules"),
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_desc")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    xtype: "syno_displayfield",
                    value: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_by_size"),
                    width: 290
                }, {
                    name: "size",
                    xtype: "syno_combobox",
                    indent: 1,
                    width: SYNO.SDS.LogCenter.WidthEditField,
                    mode: "local",
                    value: 1024,
                    editable: false,
                    store: this.storeLogArchSizeGet(),
                    forceSelection: true,
                    allowBlank: false,
                    displayField: "display",
                    valueField: "value",
                    typeAhead: true,
                    triggerAction: "all",
                    lazyRender: true
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    name: "enable_count",
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_by_count"),
                    width: 290
                }, {
                    name: "count",
                    xtype: "syno_combobox",
                    indent: 1,
                    width: SYNO.SDS.LogCenter.WidthEditField,
                    mode: "local",
                    value: 10000000,
                    editable: false,
                    store: this.storeLogArchCntGet(),
                    forceSelection: true,
                    allowBlank: false,
                    displayField: "display",
                    valueField: "value",
                    typeAhead: true,
                    triggerAction: "all",
                    lazyRender: true
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    name: "enable_time",
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_by_time"),
                    width: 290
                }, {
                    name: "time",
                    xtype: "syno_combobox",
                    indent: 1,
                    width: SYNO.SDS.LogCenter.WidthEditField,
                    mode: "local",
                    value: 2592000,
                    editable: false,
                    store: this.storeLogArchTimeGet(),
                    forceSelection: true,
                    allowBlank: false,
                    displayField: "display",
                    valueField: "value",
                    typeAhead: true,
                    triggerAction: "all",
                    lazyRender: true
                }]
            }]
        })
    },
    createArchFmt: function() {
        return new SYNO.ux.FieldSet({
            title: SYNO.SDS.LogCenter.StringGet("archsetting", "fs_arch_fmt"),
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_fmt")
            }, {
                name: "format",
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_fmt_txt")
            }, {
                name: "compress",
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_compress")
            }, {
                name: "by_device",
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.LogCenter.StringGet("archsetting", "arch_by_device")
            }]
        })
    },
    fillConfig: function(a) {
        var b = {
            labelAlign: "left",
            border: false,
            trackResetOnLoad: true,
            useDefaultBtn: true,
            items: [this.createArchDest(), this.createArchRule(), this.createArchFmt()],
            webapi: {
                api: "SYNO.LogCenter.Setting.Storage",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1
            }
        };
        Ext.apply(b, a);
        return b
    },
    setArchDbPath: function(d, b) {
        var c, a;
        a = this.getForm().findField("path");
        c = Ext.util.Format.ellipsis(d, 60);
        if (b) {
            a.setValue(c)
        } else {
            this.getForm().setValues({
                arch_folder: c
            })
        }
        a.el.dom.qtip = Ext.util.Format.htmlEncode(d)
    },
    ArchDestSelect: function() {
        var b = "SYNO.SDS.LogCenter.BuiltIn";
        var a = new SYNO.SDS.Utils.FileChooser.Chooser({
            parent: this,
            owner: this.appWin,
            usage: {
                type: "chooseDir"
            },
            title: _TT(b, "fb", "win_title"),
            folderToolbar: true,
            enumCluster: true,
            enumC2Share: true,
            enumColdStorage: true,
            listeners: {
                scope: this,
                choose: function(f, c, e) {
                    var d = c.fullpath;
                    if (!d) {
                        return _TT(b, "archsetting", "err_select_not_folder")
                    }
                    this.setArchDbPath(d, true);
                    f.close()
                }
            }
        });
        a.show()
    },
    onPageActivate: function() {
        this.loadForm();
        SYNO.SDS.LogCenter.ResizePanel(this)
    },
    onPageConfirmLostChangeSave: function() {
        return new Promise(function(b, a) {
            this.savePromise = {
                resolve: b,
                reject: a
            };
            this.applyHandler()
        }.bind(this))
    },
    onApiSuccess: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.resolve();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    onApiFailure: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.reject();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    onBeforeAction: function(b, d) {
        if ("get" === d) {
            return true
        }
        var a = this.getForm().findField("path");
        this.PathChanged = a.isDirty();
        if (this.checkFormDirty && !this.isFormDirty()) {
            var c = _T("error", "nochange_subject");
            this.setStatusError({
                text: c,
                clear: true
            });
            return false
        }
        if (!b.isValid()) {
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        return true
    },
    processReturnData: function(d, c, b) {
        this.callParent(arguments);
        if ("get" === d) {
            return true
        }
        for (var a = 0; a < c.result.length; a++) {
            if (c.result[a].api == "SYNO.LogCenter.Setting.Storage" && c.result[a].method == "set" && c.result[a].error) {
                switch (c.result[a].error.code) {
                    case 5011:
                        this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("archsetting", "warn_storage_removed"));
                        this.getForm().findField("path").markInvalid();
                        break;
                    case 5012:
                        this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("common", "error_nospace"));
                        this.getForm().findField("path").markInvalid();
                        break;
                    default:
                        this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.API.getErrorString(c.result[a].error.code));
                        break
                }
            }
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.ServiceLogPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        var b;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b])
    },
    initEvents: function() {
        this.mon(this.getStore(), "load", this.onAfterStoreLoad, this)
    },
    createStore: function() {
        var a = ["level", "time", "user", "event", "id"];
        var b = new SYNO.API.Store({
            appWindow: this.appWin,
            pruneModifiedRecords: true,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.History",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "id"
            }, a),
            baseParams: {
                offset: 0,
                limit: 25
            },
            listeners: {
                datachanged: function() {
                    var c = this.view.el.query(".contentwrapper");
                    if (0 === b.getCount()) {
                        c[0].style.height = "100%"
                    } else {
                        c[0].style.height = ""
                    }
                },
                scope: this
            }
        });
        this.addManagedComponent(b);
        return b
    },
    createToolBar: function() {
        var a = new Ext.Toolbar();
        this.btnClear = new SYNO.ux.Button({
            xtype: "syno_button",
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            text: SYNO.SDS.LogCenter.StringGet("logview", "btn_clear"),
            handler: this.onClear,
            scope: this
        });
        this.btnExport = new SYNO.ux.Button({
            xtype: "syno_button",
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            text: SYNO.SDS.LogCenter.StringGet("logview", "btn_export"),
            handler: this.onExport,
            scope: this
        });
        this.btnRefresh = new SYNO.ux.Button({
            xtype: "syno_button",
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            text: SYNO.SDS.LogCenter.StringGet("logview", "btn_refresh"),
            handler: this.onRefresh,
            scope: this
        });
        a.add(this.btnClear);
        a.add(this.btnExport);
        a.add(this.btnRefresh);
        return a
    },
    fillConfig: function(c) {
        var f, a, g, b, e, d;
        f = [{
            id: "level",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority"),
            dataIndex: "level",
            width: 120,
            renderer: SYNO.SDS.LogCenter.RenderLevelIcon
        }, {
            id: "time",
            header: SYNO.SDS.LogCenter.StringGet("logview", "datetime"),
            dataIndex: "time",
            width: 140
        }, {
            id: "user",
            header: SYNO.SDS.LogCenter.StringGet("logview", "col_user"),
            dataIndex: "user",
            width: 145
        }, {
            id: "event",
            header: SYNO.SDS.LogCenter.StringGet("logview", "col_event"),
            dataIndex: "event",
            hideable: false,
            menuDisabled: true,
            renderer: SYNO.SDS.LogCenter.RenderLogContent
        }];
        a = new Ext.grid.ColumnModel({
            columns: f,
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        b = this.createToolBar();
        g = this.createStore();
        e = new SYNO.ux.PagingToolbar({
            store: g,
            pageSize: 25,
            showRefreshBtn: true,
            displayInfo: true
        });
        d = {
            stripeRows: true,
            enableColLock: false,
            enableHdMenu: true,
            viewConfig: {
                forceFit: false,
                templates: {
                    cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="0" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                        selectableCls: SYNO.SDS.Utils.SelectableCLS
                    })
                },
                emptyText: ['<div class="syno-dataview">', '<div class="empty-text-wrap">', '<div class="empty-text-inner-wrap">', '<div class="empty-text-icon"></div>', '<div class="empty-text">', _T("log", "no_log_available"), "</div>", "</div>", "</div>", "</div>"].join("")
            },
            enableColumnMove: false,
            colModel: a,
            ds: g,
            tbar: b,
            bbar: e,
            autoExpandColumn: "event",
            loadMask: true,
            height: 515
        };
        Ext.apply(d, c);
        return d
    },
    applyClearDone: function(d, b, c, a) {
        this.appWin.clearStatusBusy();
        if (d) {
            this.getStore().load()
        } else {
            this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), _T("common", "error_system"))
        }
    },
    applyClear: function() {
        this.appWin.getMsgBox().confirmDelete(SYNO.SDS.LogCenter.StringGet("app", "app_name"), _T("log", "log_cfrm_clear"), function(a) {
            if ("yes" === a) {
                this.appWin.setStatusBusy();
                this.appWin.sendWebAPI({
                    api: "SYNO.LogCenter.History",
                    version: 1,
                    method: "clear",
                    callback: this.applyClearDone,
                    scope: this
                })
            }
        }, this)
    },
    applyExport: function() {
        this.appWin.downloadWebAPI({
            webapi: {
                api: "SYNO.LogCenter.History",
                version: 1,
                method: "export"
            }
        })
    },
    onClear: function() {
        this.applyClear()
    },
    onExport: function() {
        this.applyExport()
    },
    onRefresh: function() {
        this.getStore().load()
    },
    onPageActivate: function() {
        SYNO.SDS.LogCenter.ResizePanel(this);
        this.getStore().load()
    },
    onAfterStoreLoad: function() {
        var a = this.view.el.query(".contentwrapper");
        if (this.getStore().getCount() > 0) {
            a[0].style.height = "";
            this.btnClear.setDisabled(false);
            this.btnExport.setDisabled(false)
        } else {
            a[0].style.height = "100%";
            this.btnClear.setDisabled(true);
            this.btnExport.setDisabled(true)
        }
    }
});
Ext.ns("SYNO.SDS.LogCenter.Util");
SYNO.SDS.LogCenter.DEV_MAX = 3;
SYNO.SDS.LogCenter.LIST_LOGSTATUS = 0;
SYNO.SDS.LogCenter.LIST_LOGSEARCH = 1;
SYNO.SDS.LogCenter.LIST_SVR = 2;
SYNO.SDS.LogCenter.LIST_ARCH = 3;
SYNO.SDS.LogCenter.LIST_NOTIFY = 4;
SYNO.SDS.LogCenter.LIST_LOG = 5;
SYNO.SDS.LogCenter.SCALE_6MIN = 0;
SYNO.SDS.LogCenter.SCALE_1HR = 1;
SYNO.SDS.LogCenter.SCALE_6HR = 2;
SYNO.SDS.LogCenter.SCALE_1DAY = 3;
SYNO.SDS.LogCenter.ScaleMapping = [SYNO.SDS.LogCenter.StringGet("logstatus", "interval_6_mins"), SYNO.SDS.LogCenter.StringGet("logstatus", "interval_1_hour"), SYNO.SDS.LogCenter.StringGet("logstatus", "interval_6_hours"), SYNO.SDS.LogCenter.StringGet("logstatus", "interval_1_day")];
SYNO.SDS.LogCenter.WidthEditField = 200;
SYNO.SDS.LogCenter.LevelMapping = {
    emerg: "Emergency",
    alert: "Alert",
    crit: _T("log", "crit_level"),
    err: _T("log", "error_level"),
    warn: _T("log", "warn_level"),
    warning: _T("log", "warn_level"),
    notice: "Notice",
    info: _T("log", "info_level"),
    debug: "Debug",
    any: "Any"
};
SYNO.SDS.LogCenter.multiAttriWinTitle = function(b) {
    var a = {
        prio: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_prio"),
        prog: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_prog"),
        host: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_host"),
        fac: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_fac")
    };
    return a[b]
};
SYNO.SDS.LogCenter.logAttriStringGet = function(a) {
    if ("Any" === a) {
        return "any"
    }
    return a
};
SYNO.SDS.LogCenter.StringGet = function(c, a) {
    var b = _TT("SYNO.SDS.LogCenter.Application", c, a);
    if (undefined === b || null === b || "" === b) {
        return _T(c, a)
    }
    return b
};
SYNO.SDS.LogCenter.RenderLevelIcon = function(d, a) {
    var b = 0;
    var c = 1;
    if (b === parseInt(d, 10)) {
        return SYNO.SDS.LogCenter.LevelRenderer("info", a)
    } else {
        if (c === parseInt(d, 10)) {
            return SYNO.SDS.LogCenter.LevelRenderer("warning", a)
        } else {
            return SYNO.SDS.LogCenter.LevelRenderer("alert", a)
        }
    }
};
SYNO.SDS.LogCenter.LevelRenderer = function(b, a) {
    switch (b) {
        case "emerg":
        case "alert":
        case "crit":
        case "err":
            return '<span class="log-err">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        case "warn":
        case "warning":
        case "notice":
            return '<span class="log-warning">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        case "info":
        case "debug":
            return '<span style="log-info">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        default:
            return "Undefined"
    }
};
SYNO.SDS.LogCenter.RenderLogContent = function(b, a) {
    if (null !== a) {
        a.attr = 'ext:qtip="' + b + '"'
    }
    return b
};
SYNO.SDS.LogCenter.TransModeRenderer = function(a) {
    if ("udp" === a) {
        return "UDP"
    } else {
        return "TCP"
    }
};
SYNO.SDS.LogCenter.LogRenderer = function(c, b) {
    var a = Ext.util.Format.htmlEncode(c);
    b.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
    return a
};
SYNO.SDS.LogCenter.logRotateDayToStr = function(a) {
    var b = {
        "0": SYNO.SDS.LogCenter.StringGet("svrinfo", "rotate_never"),
        "182": SYNO.SDS.LogCenter.StringGet("svrinfo", "rotate_sixmonth"),
        "365": SYNO.SDS.LogCenter.StringGet("svrinfo", "rotate_oneyear"),
        "730": SYNO.SDS.LogCenter.StringGet("svrinfo", "rotate_twoyear"),
        "1095": SYNO.SDS.LogCenter.StringGet("svrinfo", "rotate_threeyear")
    };
    return b[a]
};
SYNO.SDS.LogCenter.pageRecordStoreGet = function() {
    var a = new Ext.data.SimpleStore({
        fields: ["value", "display"],
        data: [
            [25, 25],
            [50, 50],
            [75, 75],
            [100, 100],
            [150, 150],
            [200, 200],
            [300, 300]
        ]
    });
    return a
};
SYNO.SDS.LogCenter.runTimeFormat = function(d) {
    if (0 >= d) {
        return "0 hour(s) 0 min(s) 0 sec(s)"
    }
    var e = d,
        a = 0,
        b = 0,
        c = 0;
    a = Math.floor(d / 3600);
    e -= (a * 3600);
    b = Math.floor(e / 60);
    e -= (b * 60);
    c = e;
    return (a + " hour(s) " + b + " min(s) " + c + " sec(s)")
};
SYNO.SDS.LogCenter.TimeGet = function(e) {
    var c = new Date(e);
    var a = c.getHours().toString();
    var b = c.getMinutes().toString();
    if (1 === a.length) {
        a = "0" + a
    }
    if (1 === b.length) {
        b = "0" + b
    }
    return a + ":" + b
};
SYNO.SDS.LogCenter.Utils = {
    logTypeRenderer: function(b) {
        var a = "";
        switch (b) {
            case "syslog":
                a = _T("log", "log_link_system");
                break;
            case "connlog":
                a = _T("log", "log_link_connection");
                break;
            case "ftpxfer":
                a = _T("log", "log_ftp_xfer");
                break;
            case "dsmfmxfer":
                a = _T("log", "log_webdav_xfer");
                break;
            case "webdavxfer":
                a = _T("log", "log_link_connection");
                break;
            case "smbxfer":
                a = _T("log", "log_smb_xfer");
                break;
            case "afpxfer":
                a = _T("log", "log_afp_xfer");
                break;
            case "tftpxfer":
                a = _T("log", "log_tftp_xfer");
                break;
            case "bkplog":
                a = _T("log", "log_link_backup");
                break;
            case "copylog":
                a = _T("log", "log_link_copy");
                break;
            case "netbkplog":
                a = _T("log", "log_link_netbkp");
                break;
            case "cmslog":
                a = "CMS";
                break;
            default:
                a = _T("log", "log_link_system")
        }
        return a
    },
    htmlEncodeRender: function(c, b) {
        var a = Ext.util.Format.htmlEncode(c);
        b.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
        return a
    },
    isPackageInstall: function(a) {
        return SYNO.SDS.Packages.isPackage(a)
    },
    isPluginsAvailable: function() {
        return (SYNO.SDS.Packages.isStart("SYNO.SDS.LogCenter.Application") && SYNO.SDS.Config.FnMap.hasOwnProperty("SYNO.SDS.LogCenter.ExtReceiveLog"))
    }
};
Ext.define("SYNO.SDS.LogCenter.TodayTipDateFieldPlugin", {
    extend: "Ext.Component",
    todayTip: "{0}",
    init: function(a) {
        if (a.menu === null) {
            a.menu = new Ext.menu.DateMenu({
                hideOnClick: false,
                focusOnSelect: false
            });
            a.menu.picker.todayTip = this.todayTip
        }
    }
});
Ext.preg("todaytipdatefieldplugin", SYNO.SDS.LogCenter.TodayTipDateFieldPlugin);
Ext.define("SYNO.SDS.LogCenter.MenuTextColumnModelPlugin", {
    extend: "Ext.Component",
    init: function(a) {
        var c = a.getView(),
            b = a.getColumnModel();
        b.getColumnMenuText = this.getColumnMenuText;
        c.beforeColMenuShow = this.beforeColMenuShow
    },
    getColumnMenuText: function(a) {
        return this.config[a].menuText || this.config[a].header
    },
    beforeColMenuShow: function() {
        var e = this,
            b = e.cm,
            d = b.getColumnCount(),
            a = e.colMenu,
            c;
        a.removeAll();
        for (c = 0; c < d; c++) {
            if (b.config[c].hideable !== false) {
                a.add(new Ext.menu.CheckItem({
                    text: b.getColumnMenuText ? b.getColumnMenuText(c) : b.getColumnHeader(c),
                    itemId: "col-" + b.getColumnId(c),
                    checked: !b.isHidden(c),
                    disabled: b.config[c].hideable === false,
                    hideOnClick: false
                }))
            }
        }
    }
});
Ext.preg("menutextcolumnmodelplugin", SYNO.SDS.LogCenter.MenuTextColumnModelPlugin);
/**
 * @class SYNO.SDS.LogCenter.Application
 * @extends SYNO.SDS.AppInstance
 * LogCenter application instance class
 *
 */  
Ext.define("SYNO.SDS.LogCenter.Application", {
    extend: "SYNO.SDS.AppInstance",
    constructor: function() {
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtBaseLogUI", {
    extend: "Ext.Panel",
    itemsPerPage: 1000,
    logType: [
        ["syslog", _T("log", "log_link_system")]
    ],
    title: _T("tree", "leaf_log"),
    itemId: "logPanel",
    appInst: undefined,
    baseURL: undefined,
    topwin: undefined,
    store: undefined,
    columnModel: undefined,
    constructor: function(a) {
        Ext.copyTo(this, a, ["listeners", "baseURL", "topwin", "appInst", "logType", "title", "itemId", "jsConfig"]);
        this.store = a.ds;
        this.columnModel = a.cm;
        this.itemsPerPage = a.appInst.appInstance.getUserSettings(this.itemId + "-dsPageLimit") || this.itemsPerPage;
        this.emptyString = a.emptyString || _T("log", "no_log_available");
        Ext.apply(a, this);
        this.callParent([a])
    },
    getPageRecordStore: function() {
        var a = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [100, 100],
                [500, 500],
                [1000, 1000],
                [3000, 3000]
            ]
        });
        return a
    },
    initPageComboBox: function(a) {
        var b = new SYNO.ux.ComboBox({
            name: "page_rec",
            hiddenName: "page_rec",
            hiddenId: Ext.id(),
            store: a,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: this.itemsPerPage,
            editable: false,
            width: 70,
            mode: "local",
            listeners: {
                select: {
                    fn: this.onChangeDisplayRecord,
                    scope: this
                }
            }
        });
        return b
    },
    initPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.store,
            displayButtons: true,
            displayInfo: true,
            pageSize: this.itemsPerPage,
            smallVerticalPadding: true,
            showRefreshBtn: true,
            cls: "log-toolbar",
            items: [{
                xtype: "tbtext",
                style: "padding-right: 4px",
                text: _T("common", "items_perpage")
            }, this.initPageComboBox(this.getPageRecordStore())]
        });
        return a
    },
    initSearchForm: function() {
        var a = new SYNO.SDS.LogCenter.ExtSearchFormPanel({
            cls: "syno-syslog-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            jsConfig: this.jsConfig,
            hidden: true,
            owner: this,
            logType: this.logType
        });
        a.hideItems(["logType", "logTypeLabel"]);
        return a
    },
    initComponent: function() {
        this.searchPanel = this.initSearchForm();
        this.paging = this.initPagingToolbar();
        this.grid = new SYNO.ux.GridPanel({
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                scrollDelay: 30,
                borderHeight: 1,
                forceFit: false,
                templates: {
                    cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="0" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                        selectableCls: SYNO.SDS.Utils.SelectableCLS
                    })
                },
                emptyText: ['<div class="syno-dataview">', '<div class="empty-text-wrap">', '<div class="empty-text-inner-wrap">', '<div class="empty-text-icon"></div>', '<div class="empty-text">', this.emptyString, "</div>", "</div>", "</div>", "</div>"].join("")
            }),
            region: "center",
            plugins: "menutextcolumnmodelplugin",
            store: this.store,
            colModel: this.columnModel,
            bbar: this.paging,
            loadMask: true,
            autoExpandColumn: "descr",
            cls: "syno-syslog-remove-sort-icon",
            stripeRows: true
        });
        Ext.apply(this, {
            itemId: this.itemId,
            border: false,
            header: false,
            layout: "border",
            items: [this.grid]
        });
        this.callParent([this])
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtBaseLog", {
    extend: "SYNO.SDS.LogCenter.ExtBaseLogUI",
    searchBuffer: 200,
    constructor: function(a) {
        this.callParent([a]);
        this.searchBuffer = a.searchBuffer || this.searchBuffer
    },
    initEvents: function() {
        this.mon(this.searchPanel, "search", this.onSearch, this, {
            buffer: this.searchBuffer
        });
        this.mon(this, "activate", this.onActive, this);
        this.mon(this.grid.getStore(), "load", this.onAfterStoreLoad, this);
        this.mon(this.grid.getStore(), "beforeload", this.onBeforeStoreLoad, this);
        this.mon(this.grid.getStore(), "loadexception", this.onLoadException, this)
    },
    onChangeDisplayRecord: function(c, d, b) {
        var a = this.grid.getStore();
        if (this.itemsPerPage !== c.getValue()) {
            this.itemsPerPage = c.getValue();
            this.paging.pageSize = this.itemsPerPage;
            a.load({
                params: {
                    start: 0,
                    limit: this.itemsPerPage
                }
            });
            this.appInst.appInstance.setUserSettings(this.itemId + "-dsPageLimit", this.itemsPerPage)
        }
    },
    getLogTypes: function(a) {
        var b = [];
        this.logType.forEach(function(c) {
            b.push(c[0])
        });
        return b.join(a || ",")
    },
    isTheSame: function(b, a) {
        for (var c in a) {
            if (a[c] !== b[c]) {
                return false
            }
        }
        return true
    },
    onSearch: function(b, c) {
        var a = this.grid.getStore();
        if (!this.isTheSame(a.baseParams, c)) {
            Ext.apply(a.baseParams, c);
            this.loadData()
        }
    },
    onActive: function() {
        var a = this.grid.getStore(),
            b = {
                target: "LOCAL",
                logtype: this.getLogTypes(),
                date_from: 0,
                date_to: 0,
                keyword: "",
                level: ""
            };
        Ext.applyIf(a.baseParams, b);
        if (this.requestLogType) {
            Ext.apply(a.baseParams, {
                logtype: this.requestLogType
            })
        }
        this.loadData();
        delete this.requestLogType
    },
    loadData: function() {
        var a = this.grid.getStore(),
            b = {
                start: 0,
                limit: this.itemsPerPage
            };
        a.load({
            params: b
        })
    },
    onLoadException: function(a, c, e, b) {
        if (!e.items) {
            var d = SYNO.API.getErrorString(e.code);
            if (5008 == e.code) {
                d = _T("log", "no_active_log")
            }
            this.grid.getGridEl().mask(d)
        }
    },
    onBeforeStoreLoad: function(a, b) {
        this.grid.getGridEl().unmask()
    },
    onAfterStoreLoad: function(a, f, d) {
        var e, c;
        var b = this.grid.view.el.query(".contentwrapper");
        if (f.length < 1) {
            b[0].style.height = "100%";
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        } else {
            b[0].style.height = "";
            this.topwin.enableExportButton(true);
            this.topwin.enableClearButton(true)
        }
        e = a.reader.jsonData;
        c = '<div class="{0}" ext:qtip="{1}">{2}</div>';
        this.setPagingToolbar(a, this.grid, this.paging)
    },
    setPagingToolbar: function(a, b, c) {
        this.setPagingToolbarVisible(c, a.getTotalCount() > this.itemsPerPage)
    },
    setPagingToolbarVisible: function(b, c) {
        var a = 0;
        for (a = 0; a < 13; a++) {
            if (a === 9 || a === 10 || a === 11) {
                continue
            }
            b.items.items[a].setVisible(c)
        }
        b.setButtonsVisible(true)
    },
    setLogLevelText: function(b, a, c, e, d) {
        if (b) {
            d = d || "0";
            b.setText(String.format(a, c, e, d))
        }
    },
    onExportCSV: function() {
        this.onLogSave("csv")
    },
    onExportHtml: function() {
        this.onLogSave("html")
    },
    onLogSave: function(a) {
        if (_S("demo_mode")) {
            this.appInst.getMsgBox().alert(this.appInst.title, _JSLIBSTR("uicommon", "error_demo"));
            return
        }
        this.saveLog(a)
    },
    saveLog: function(b) {
        var a = this.grid.getStore();
        this.appInst.downloadWebAPI({
            webapi: {
                api: "SYNO.LogCenter.Log",
                version: 1,
                method: "export",
                params: {
                    target: a.baseParams.target,
                    logtype: a.baseParams.logtype,
                    level: a.baseParams.level,
                    sort: a.sortInfo.field,
                    dir: a.sortInfo.direction,
                    date_from: a.baseParams.date_from,
                    date_to: a.baseParams.date_to,
                    keyword: a.baseParams.keyword,
                    format: b
                }
            }
        })
    },
    onLogClear: function() {
        if (_S("demo_mode")) {
            this.appInst.getMsgBox().alert(this.appInst.title, _JSLIBSTR("uicommon", "error_demo"));
            return
        }
        this.topwin.getMsgBox().confirm(_T("tree", "leaf_log"), _T("log", "log_cfrm_clear"), function(a, b) {
            if (a === "yes") {
                this.clearLog()
            }
        }, this)
    },
    clearLog: function() {
        var a = this.grid.getStore();
        a.load({
            params: {
                action: "clear",
                logtype: this.getLogTypes()
            }
        })
    },
    destroy: function() {
        if (this.rowNav) {
            Ext.destroy(this.rowNav);
            this.rowNav = null
        }
        this.callParent([this])
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtGeneralLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["system", _T("log", "log_link_system")],
                ["netbackup", _T("log", "log_link_netbkp")],
                ["backupserver", _T("log", "log_link_backup_server")]
            ],
            h = _T("log", "general"),
            g = "ExtGeneral",
            c = "general";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.ExtBaseLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "level", "time", "who", "descr"]),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            c = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority"),
                menuText: _T("log", "logattr"),
                dataIndex: "level",
                width: 100,
                renderer: b
            }, {
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 90,
                renderer: c
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 140,
                renderer: c
            }, {
                header: _T("log", "log_account"),
                dataIndex: "who",
                width: 120,
                renderer: c
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "descr",
                css: "white-space:normal;",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: c
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtConnectionLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["connection", _T("log", "log_link_connection")]
            ],
            h = _T("log", "log_link_connection"),
            g = "ExtConnection",
            c = "log_link_connection";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.ExtBaseLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "level", "time", "who", "descr"]),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            c = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                menuText: _T("log", "logattr"),
                header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority"),
                dataIndex: "level",
                width: 100,
                renderer: b
            }, {
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 90,
                renderer: c
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 140,
                renderer: c
            }, {
                header: _T("log", "log_account"),
                dataIndex: "who",
                width: 120,
                renderer: c
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "descr",
                css: "white-space:normal;",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: c
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtFileTransferLog", {
    extend: "SYNO.SDS.LogCenter.ExtBaseLog",
    initSearchForm: function() {
        var a = new SYNO.SDS.LogCenter.ExtSearchFormPanel({
            cls: "syno-syslog-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            jsConfig: this.jsConfig,
            hidden: true,
            owner: this,
            logType: this.logType
        });
        a.hideItems(["logLevel", "logLevelLabel"]);
        return a
    },
    onLoadException: function(a, c, e, b) {
        if (!e.items) {
            var d = SYNO.API.getErrorString(e.code);
            if (5008 == e.code) {
                d = _T("log", "no_active_log")
            }
            this.grid.getGridEl().mask(d);
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        }
    },
    onAfterStoreLoad: function(a, d, c) {
        var b = this.grid.view.el.query(".contentwrapper");
        if (d.length < 1) {
            b[0].style.height = "100%";
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        } else {
            b[0].style.height = "";
            this.topwin.enableExportButton(true);
            this.topwin.enableClearButton(true)
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtFileTransferLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["ftp", _T("log", "log_ftp_xfer")],
                ["filestation", _T("log", "log_filebrowser_xfer")],
                ["webdav", _T("log", "log_webdav_xfer")],
                ["cifs", _T("log", "log_smb_xfer")],
                ["afp", _T("log", "log_afp_xfer")],
                ["tftp", _T("log", "log_tftp_xfer")]
            ],
            h = _T("log", "file_transfer"),
            g = "ExtFileTransfer",
            c = "file_transfer";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.ExtFileTransferLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "time", "ip", "username", "cmd", "filesize", "descr", "isdir"]),
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true,
            remoteSort: false
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var d = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var c = function(f, e) {
            f = (f === "true") ? _T("common", "folder") : _T("common", "file");
            return d(f, e)
        };
        var b = function(j, h, e, g, i, f) {
            if (e.get("isdir") === "true" || e.get("cmd") === "create" || e.get("cmd") === "AFP_CREATEFILE") {
                j = "NA"
            }
            return d(j, h)
        };
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 85,
                renderer: d
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 130,
                renderer: d
            }, {
                header: _T("pppoe", "pppoe_IP"),
                dataIndex: "ip",
                width: 105,
                renderer: d
            }, {
                header: _T("log", "log_account"),
                dataIndex: "username",
                width: 115,
                renderer: d
            }, {
                header: _T("log", "log_action"),
                dataIndex: "cmd",
                width: 100,
                renderer: d
            }, {
                header: _T("log", "log_file_folder"),
                dataIndex: "isdir",
                width: 123,
                renderer: c
            }, {
                header: _T("log", "log_filesize"),
                dataIndex: "filesize",
                width: 140,
                renderer: b
            }, {
                id: "descr",
                header: _T("log", "log_filename"),
                dataIndex: "descr",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: d
            }],
            defaults: {
                sortable: false,
                forceFit: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtReceiveLog", {
    extend: "SYNO.SDS.LogCenter.ExtBaseLog",
    maxSearchItem: -1,
    initSearchForm: function() {
        var a = new SYNO.SDS.LogCenter.ExtSearchFormPanel({
            cls: "syno-syslog-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            jsConfig: this.jsConfig,
            hidden: true,
            owner: this,
            logType: this.logType
        });
        a.hideItems(["logType", "logTypeLabel"]);
        a.hideItems(["logLevel", "logLevelLabel"]);
        return a
    },
    initPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.store,
            displayInfo: true,
            pageSize: this.itemsPerPage,
            showRefreshBtn: true,
            cls: "log-toolbar",
            smallVerticalPadding: true,
            items: [{
                xtype: "tbtext",
                style: "padding-right: 4px",
                text: _T("common", "items_perpage")
            }, this.initPageComboBox(this.getPageRecordStore())]
        });
        return a
    },
    onAfterStoreLoad: function(a, f, d) {
        var e = a.reader.jsonData;
        var c;
        var b = this.grid.view.el.query(".contentwrapper");
        if (e.isSupportFileTransferLog === false || f.length < 1) {
            b[0].style.height = "100%";
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        } else {
            b[0].style.height = "";
            this.topwin.enableExportButton(true);
            this.topwin.enableClearButton(true)
        }
        c = '<div class="{0}" ext:qtip="{1}">{2}</div>';
        this.setPagingToolbar(a, this.grid, this.paging);
        if (this.maxSearchItem >= 0) {
            this.paging.last.disable();
            if (this.store.getCount() > 0) {
                this.maxSearchItem = (this.paging.cursor + this.store.getCount() > this.maxSearchItem) ? this.paging.cursor + this.store.getCount() : this.maxSearchItem;
                this.paging.displayMsg = this.maxSearchItem.toString();
                this.paging.displayMsg += (this.store.getCount() == this.itemsPerPage) ? "+ item(s)" : " item(s)";
                this.paging.updateInfo()
            }
        }
    },
    saveLog: function(b) {
        var a = this.grid.getStore();
        var c = a.baseParams;
        this.topwin.downloadWebAPI({
            webapi: {
                api: "SYNO.LogCenter.Log",
                version: 1,
                method: "export",
                params: {
                    target: this.dbpath,
                    logtype: "all",
                    level: (c.level === undefined) ? "any" : c.level,
                    date_from: (c.date_from === undefined) ? 0 : c.date_from,
                    date_to: (c.date_to === undefined) ? 0 : c.date_to,
                    keyword: (c.keyword === undefined) ? "" : c.keyword,
                    hostname: (c.hostname === undefined) ? "any" : c.hostname,
                    program: (c.program === undefined) ? "any" : c.program,
                    category: (c.catrgory === undefined) ? "any" : c.category,
                    format: b
                }
            }
        })
    },
    onActive: function() {
        var a = this.grid.getStore();
        var c = a.baseParams;
        var b = {
            target: this.dbpath,
            logtype: "all",
            level: (c.prio === undefined) ? "any" : c.prio,
            date_from: (c.date_from === undefined) ? 0 : c.date_from,
            date_to: (c.date_to === undefined) ? 0 : c.date_to,
            keyword: (c.keyword === undefined) ? "" : c.keyword,
            hostname: (c.hostname === undefined) ? "any" : c.hostname,
            program: (c.program === undefined) ? "any" : c.program,
            category: (c.catrgory === undefined) ? "any" : c.category
        };
        Ext.applyIf(a.baseParams, b);
        if (this.requestLogType) {
            Ext.apply(a.baseParams, {
                logtype: this.requestLogType
            })
        }
        this.loadData();
        delete this.requestLogType
    },
    getDbPath: function() {
        return this.grid.getStore().baseParams.db_path
    },
    setDbPath: function(a) {
        this.grid.getStore().baseParams.db_path = a
    },
    onSearch: function(b, c) {
        this.maxSearchItem = 0;
        var a = this.grid.getStore();
        if (!this.isTheSame(a.baseParams, c)) {
            Ext.apply(a.baseParams, c);
            Ext.apply(a.baseParams, {
                counting_type: 1
            });
            this.loadData()
        }
    },
    initParams: function(b) {
        var a = {
            target: this.dbpath,
            logtype: "all",
            level: "any",
            date_from: 0,
            date_to: 0,
            keyword: "",
            hostname: "any",
            program: "any",
            category: "any",
            counting_type: 0
        };
        Ext.apply(a, b);
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtReceiveLogBuilder", {
    extend: "Object",
    create: function(e) {
        this.dbpath = "REMOTEARCH";
        var d = [
                ["recvlog", "Received logs"]
            ],
            h = "Received logs",
            g = "ExtReceiveLog",
            c = "receive_log";
        var b = this.getStore(e.topwin),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f,
                dbpath: this.dbpath,
                emptyString: _T("log", "no_ietf_log_available")
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.ExtReceiveLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.Log",
                method: "list",
                timeout: 600000,
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["id", "host", "ip", "fac", "prio", "llevel", "utcsec", "tzoffset", "ldate", "ltime", "prog", "msg"]),
            remoteSort: false,
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var b = [{
            dataIndex: "ldate",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_date"),
            width: 75
        }, {
            dataIndex: "ltime",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_time"),
            width: 75
        }, {
            dataIndex: "prio",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority"),
            width: 85,
            renderer: SYNO.SDS.LogCenter.LevelRenderer
        }, {
            dataIndex: "host",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_host"),
            width: 100
        }, {
            dataIndex: "fac",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_facility"),
            width: 95
        }, {
            dataIndex: "prog",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_program"),
            width: 105
        }, {
            dataIndex: "msg",
            name: "msg",
            id: "descr",
            header: SYNO.SDS.LogCenter.StringGet("logattr", "attr_msg"),
            width: 300,
            hideable: false,
            menuDisabled: true,
            renderer: SYNO.SDS.LogCenter.LogRenderer
        }];
        var a = new Ext.grid.ColumnModel({
            defaults: {
                sortable: false,
                menuDisabled: false
            },
            columns: b
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ClientFilter", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    storeLogLevelGet: function() {
        var a = [
            ["error", "Error"],
            ["error,warning", "Warning, Error"],
            ["error,warning,info", "Information, Warning, Error"]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    fillConfig: function(a) {
        var c, b = [],
            d = [];
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_link_system"),
            name: "system"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_link_connection"),
            name: "connection"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_ftp_xfer"),
            name: "ftp"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_webfm_xfer"),
            name: "filestation"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_webdav_xfer"),
            name: "webdav"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_smb_xfer"),
            name: "cifs"
        });
        d.push({
            xtype: "syno_checkbox",
            boxLabel: _T("log", "log_afp_xfer"),
            name: "afp"
        });
        if ("yes" === _D("netbkp", "no")) {
            d.push({
                xtype: "syno_checkbox",
                boxLabel: _T("log", "log_link_netbkp"),
                name: "netbackup"
            })
        }
        if (SYNO.SDS.LogCenter.Utils.isPackageInstall("SYNO.SDS.CMS.Application")) {
            d.push({
                xtype: "syno_checkbox",
                boxLabel: "CMS",
                name: "cms"
            })
        }
        b.push({
            xtype: "syno_displayfield",
            value: SYNO.SDS.LogCenter.StringGet("logclient", "lable_fac_filter") + ":"
        }, {
            xtype: "checkboxgroup",
            columns: 2,
            hideLabel: true,
            items: d
        }, {
            xtype: "syno_displayfield",
            value: ""
        }, {
            xtype: "syno_displayfield",
            value: SYNO.SDS.LogCenter.StringGet("logclient", "lable_sev_filter") + ":"
        }, {
            xtype: "syno_combobox",
            name: "level_filter",
            hideLabel: true,
            editable: false,
            store: this.storeLogLevelGet(),
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            width: 260,
            value: "error,warning,info"
        });
        c = {
            title: SYNO.SDS.LogCenter.StringGet("logclient", "tab_filter"),
            trackResetOnLoad: true,
            hideMode: "offsets",
            disabled: true,
            items: b,
            webapi: {
                api: "SYNO.LogCenter.Client",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1
            }
        };
        Ext.apply(c, a);
        return c
    },
    processParams: function(c, b) {
        if ("set" === c) {
            var a = {
                api: this.webapi.api,
                method: this.webapi.methods.set,
                version: this.webapi.version
            };
            Ext.each(b, function(e) {
                if (SYNO.ux.Utils.checkApiConsistency(a, e)) {
                    var d = {};
                    d.system = e.params.system;
                    d.connection = e.params.connection;
                    d.ftp = e.params.ftp;
                    d.filestation = e.params.filestation;
                    d.cifs = e.params.cifs;
                    d.afp = e.params.afp;
                    d.webdav = e.params.webdav;
                    d.netbackup = e.params.netbackup;
                    d.cms = e.params.cms;
                    e.params.app_filter = d;
                    e.params.level_filter = this.getForm().findField("level_filter").getValue()
                }
            }, this)
        }
        return b
    },
    processReturnData: function(d, c, b) {
        var a = {
            api: this.webapi.api,
            method: this.webapi.methods.get,
            version: this.webapi.version
        };
        Ext.each(c.result, function(f) {
            if (SYNO.ux.Utils.checkApiConsistency(a, f)) {
                var e = {};
                if (f.success) {
                    Ext.iterate(f.data.app_filter, function(g, h) {
                        e[g] = h
                    });
                    e.level_filter = f.data.level_filter;
                    this.getForm().setValues(e);
                    return false
                }
            }
        }, this)
    }
});
Ext.define("SYNO.SDS.LogCenter.Server.GridPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        var b;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this.getSelectionModel(), "rowselect", this.updateButtonStatus, this);
        this.mon(this.getSelectionModel(), "rowdeselect", this.updateButtonStatus, this)
    },
    updateButtonStatus: function(b) {
        if (_S("demo_mode")) {
            return
        }
        var a = (b === true) || (this.getSelectionModel().getCount() !== 1);
        this.btnEdit.setDisabled(a);
        this.btnDelete.setDisabled(a)
    },
    createStore: function() {
        var a = ["enable", "name", "format", "protocol", "port", "ssl"];
        var b = new SYNO.API.Store({
            appWindow: this.appWin,
            pruneModifiedRecords: true,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.RecvRule",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "name"
            }, a)
        });
        this.addManagedComponent(b);
        return b
    },
    createToolBar: function() {
        var a = new SYNO.ux.Toolbar({
            style: {
                "border-bottom": "none"
            }
        });
        this.btnCreate = new SYNO.ux.Button({
            text: _T("common", "create"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            disabled: _S("demo_mode"),
            handler: this.onCreate,
            scope: this
        });
        this.btnEdit = new SYNO.ux.Button({
            text: _T("common", "alt_edit"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            disabled: true,
            handler: this.onEdit,
            scope: this
        });
        this.btnDelete = new SYNO.ux.Button({
            text: _T("common", "delete"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            disabled: true,
            handler: this.onDelete,
            scope: this
        });
        this.btnExportCA = new SYNO.ux.Button({
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            name: "button_tls",
            ctCls: "syno-syslog-tab-btn",
            text: SYNO.SDS.LogCenter.StringGet("svrsetting", "svr_exportca"),
            scope: this,
            handler: this.caExport
        });
        a.add(this.btnCreate);
        a.add(this.btnEdit);
        a.add(this.btnDelete);
        a.add(this.btnExportCA);
        return a
    },
    fillConfig: function(b) {
        var e = new SYNO.ux.EnableColumn({
            id: "enable",
            header: SYNO.SDS.LogCenter.StringGet("custrule", "enable"),
            dataIndex: "enable",
            enableFastSelectAll: true,
            menuDisabled: false,
            sortable: false,
            align: "center"
        });
        var d = [e, {
            id: "name",
            dataIndex: "name",
            header: SYNO.SDS.LogCenter.StringGet("custrule", "rule_name"),
            width: 100
        }, {
            id: "format",
            dataIndex: "format",
            header: SYNO.SDS.LogCenter.StringGet("svrsetting", "log_format"),
            width: 200,
            renderer: SYNO.SDS.LogCenter.RenderFormat
        }, {
            id: "protocol",
            dataIndex: "protocol",
            header: SYNO.SDS.LogCenter.StringGet("svrinfo", "title_transmode"),
            width: 100,
            renderer: SYNO.SDS.LogCenter.RenderProtocol
        }, {
            id: "port",
            dataIndex: "port",
            header: SYNO.SDS.LogCenter.StringGet("svrinfo", "title_svrport"),
            width: 100
        }, {
            id: "ssl",
            dataIndex: "ssl",
            header: "SSL",
            width: 100,
            menuDisabled: true,
            renderer: SYNO.SDS.LogCenter.RenderEnable
        }];
        var a = new Ext.grid.ColumnModel({
            columns: d,
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        var c = {
            title: SYNO.SDS.LogCenter.StringGet("svrsetting", "tab_customized"),
            stripeRows: true,
            enableHdMenu: true,
            enableColumnMove: false,
            plugins: [e],
            colModel: a,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            ds: this.createStore(),
            tbar: this.createToolBar(),
            autoExpandColumn: "format",
            loadMask: true,
            padding: 0,
            height: 470
        };
        Ext.apply(c, b);
        return c
    },
    doReloadGrid: function() {
        this.getStore().load();
        this.updateButtonStatus(true)
    },
    caExport: function() {
        this.appWin.downloadWebAPI({
            webapi: {
                api: "SYNO.LogCenter.Client.CA",
                version: 1,
                method: "download"
            }
        })
    },
    reset: function() {
        this.doReloadGrid()
    },
    onCreate: function() {
        var a = new SYNO.SDS.LogCenter.RuleDialog({
            owner: this.appWin,
            mode: "create",
            rule_setting: {
                format: "bsd",
                protocol: "udp",
                port: 514
            }
        });
        this.mon(a, "close", this.doReloadGrid, this);
        a.open()
    },
    onEdit: function() {
        var b = this.getSelectionModel().getSelections()[0];
        var d = b.get("format");
        var c = "custom";
        if ("bsd" === d) {
            c = "bsd"
        } else {
            if ("ietf" === d) {
                c = "ietf"
            }
        }
        var a = new SYNO.SDS.LogCenter.RuleDialog({
            owner: this.appWin,
            mode: "edit",
            rule_setting: {
                name: b.get("name"),
                format: d,
                formatRadioChoice: c,
                protocol: b.get("protocol"),
                port: b.get("port"),
                ssl: b.get("ssl")
            }
        });
        this.mon(a, "close", this.doReloadGrid, this);
        a.open()
    },
    applyActionDone: function(d, b, c, a) {
        this.appWin.clearStatusBusy();
        if (d) {
            this.updateButtonStatus(true);
            this.doReloadGrid()
        } else {
            this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.API.getErrorString(b.code))
        }
    },
    onDelete: function() {
        this.appWin.getMsgBox().confirmDelete(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("custrule", "rule_cfrm_clear"), function(a) {
            if ("yes" === a) {
                var b = this.getSelectionModel().getSelections()[0];
                this.appWin.setStatusBusy();
                this.appWin.sendWebAPI({
                    api: "SYNO.LogCenter.RecvRule",
                    method: "delete",
                    version: 1,
                    params: {
                        name: b.get("name")
                    },
                    callback: this.applyActionDone,
                    scope: this
                })
            }
        }, this)
    },
    getApiSaveRules: function() {
        var a = [];
        Ext.each(this.getStore().getRange(), function(b) {
            a.push({
                api: "SYNO.LogCenter.RecvRule",
                method: b.data.enable ? "enable" : "disable",
                version: 1,
                params: {
                    name: b.data.name
                }
            })
        }, this);
        return a
    },
    processReturnData: function(c, b, a) {
        if ("set" === c && true !== b.has_fail) {
            this.doReloadGrid()
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.RuleDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(a) {
        var c, b;
        c = ("edit" === a.mode) ? SYNO.SDS.LogCenter.StringGet("custrule", "title_rule_edit") : SYNO.SDS.LogCenter.StringGet("custrule", "title_rule_add");
        this.RuleForm = new SYNO.SDS.LogCenter.RuleForm({
            owner: this
        });
        if ("edit" === a.mode) {
            this.orgin_name = a.rule_setting.name;
            this.RuleForm.getForm().findField("name").setValue(a.rule_setting.name);
            this.RuleForm.getForm().findField("protocol").setValue(a.rule_setting.protocol);
            this.RuleForm.getForm().findField("port").setValue(a.rule_setting.port);
            this.RuleForm.getForm().findField("ssl").setValue(a.rule_setting.ssl);
            this.RuleForm.getForm().findField("format").setValue(a.rule_setting.formatRadioChoice);
            if ("custom" === a.rule_setting.formatRadioChoice) {
                this.RuleForm.getForm().findField("format_text").setDisabled(false);
                this.RuleForm.getForm().findField("format_text").setValue(a.rule_setting.format)
            } else {
                this.RuleForm.getForm().findField("format_text").setDisabled(true)
            }
        }
        b = {
            title: c,
            resizable: false,
            width: 640,
            height: 440,
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreateEdit,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
            }],
            items: [this.RuleForm]
        };
        Ext.apply(b, a);
        return b
    },
    applyCreateEditDone: function(e, c, d, b) {
        this.clearStatusBusy();

        function a(f) {
            if ("yes" === f) {
                this.owner.selectPage("SYNO.SDS.LogCenter.ArchiveSetting");
                this.owner.pageCt.getComponent("SYNO.SDS.LogCenter.ArchiveSetting").getForm().findField("path").markInvalid();
                this.close()
            }
        }
        if (e) {
            this.close()
        } else {
            switch (c.code) {
                case 5011:
                case 5012:
                    this.owner.getMsgBox().confirm(SYNO.SDS.LogCenter.StringGet("listpanel", "svr_setting"), SYNO.SDS.LogCenter.StringGet("archsetting", "cfm_select_arch_dest"), a, this);
                    break;
                case 5013:
                    this.owner.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("custrule", "err_duplicated_name"));
                    this.setStatusError({
                        text: _T("common", "forminvalid"),
                        iconCls: "syno-ux-statusbar-error"
                    });
                    break;
                default:
                    this.owner.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.API.getErrorString(c.code));
                    break
            }
        }
    },
    onCreateEdit: function() {
        var e = this.RuleForm.getForm();
        var c = e.findField("name").getValue();
        var f = e.findField("format").getValue().inputValue;
        var d = e.findField("format_text").getValue();
        var g = e.findField("protocol").getValue();
        var b = e.findField("port").getValue();
        var a = e.findField("ssl").getValue();
        if (!e.isValid()) {
            return false
        }
        if (SYNO.SDS.Utils.isReservedPort("syslog", b, b)) {
            this.owner.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), SYNO.SDS.LogCenter.StringGet("common", "error_used_port"));
            return false
        }
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        this.owner.sendWebAPI({
            api: "SYNO.LogCenter.RecvRule",
            version: 1,
            method: ("create" === this.mode) ? "create" : "set",
            params: {
                origin_name: this.orgin_name,
                name: c,
                format: ("custom" === f) ? d : f,
                protocol: g,
                port: b,
                ssl: a
            },
            callback: this.applyCreateEditDone,
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.LogCenter.RuleForm", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    initEvents: function() {
        this.callParent(arguments);
        var a = this.getForm();
        var b = a.findField("protocol").getValue();
        a.findField("ssl").setDisabled(("udp" === b));
        a.findField("protocol").on("select", function(f, g, d) {
            var e = f.getValue();
            var c = a.findField("ssl");
            if ("tcp" === e) {
                c.setDisabled(false)
            } else {
                c.setDisabled(true);
                c.setValue(false)
            }
        }, this);
        this.mon(this, "afterlayout", function() {
            SYNO.ux.AddTip(this.getForm().findField("format_text").getEl(), SYNO.SDS.LogCenter.StringGet("custrule", "rule_format_tip"))
        }, this, {
            single: true
        })
    },
    fillConfig: function(a) {
        var b = {
            trackResetOnLoad: true,
            hideMode: "offsets",
            frame: false,
            border: false,
            height: 330,
            padding: 0,
            items: [{
                name: "name",
                xtype: "syno_textfield",
                width: SYNO.SDS.LogCenter.WidthEditField,
                fieldLabel: SYNO.SDS.LogCenter.StringGet("custrule", "rule_name"),
                emptyText: SYNO.SDS.LogCenter.StringGet("custrule", "rule_name_desc"),
                maskRe: /[\d\w]+/,
                regex: /^[\d\w]+$/,
                allowBlank: false
            }, {
                name: "format",
                xtype: "syno_radiogroup",
                hideLabel: false,
                fieldLabel: SYNO.SDS.LogCenter.StringGet("svrsetting", "log_format"),
                height: 100,
                items: [{
                    boxLabel: SYNO.SDS.LogCenter.StringGet("svrsetting", "bsd_format"),
                    inputValue: "bsd",
                    name: "format_type",
                    checked: true
                }, {
                    boxLabel: SYNO.SDS.LogCenter.StringGet("svrsetting", "ietf_format"),
                    inputValue: "ietf",
                    name: "format_type"
                }, {
                    boxLabel: SYNO.SDS.LogCenter.StringGet("svrsetting", "custom_format"),
                    inputValue: "custom",
                    name: "format_type",
                    listeners: {
                        check: function(c, d) {
                            this.getForm().findField("format_text").setDisabled(!d)
                        },
                        scope: this
                    }
                }]
            }, {
                name: "format_text",
                xtype: "syno_textarea",
                fieldLabel: SYNO.SDS.LogCenter.StringGet("custrule", "rule_format"),
                emptyText: SYNO.SDS.LogCenter.StringGet("custrule", "rule_format_desc"),
                allowBlank: false,
                maxLength: 640,
                anchor: "95%",
                disabled: true
            }, {
                name: "protocol",
                xtype: "syno_combobox",
                width: SYNO.SDS.LogCenter.WidthEditField,
                fieldLabel: SYNO.SDS.LogCenter.StringGet("svrinfo", "title_transmode"),
                store: new Ext.data.SimpleStore({
                    autoDestroy: true,
                    fields: ["value", "display"],
                    data: [
                        ["tcp", "TCP"],
                        ["udp", "UDP"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "udp",
                triggerAction: "all",
                editable: false,
                forceSelection: true,
                allowBlank: false,
                typeAhead: true,
                lazyRender: true
            }, {
                name: "port",
                xtype: "syno_numberfield",
                width: SYNO.SDS.LogCenter.WidthEditField,
                value: 514,
                minValue: 1,
                maxValue: 65535,
                fieldLabel: SYNO.SDS.LogCenter.StringGet("svrinfo", "title_svrport"),
                maxlength: 5,
                vtype: "port"
            }, {
                name: "ssl",
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.LogCenter.StringGet("svrsetting", "svr_enable_tls")
            }]
        };
        Ext.apply(b, a);
        return b
    }
});
SYNO.SDS.LogCenter.RenderEnable = function(a) {
    return a ? _T("common", "enabled") : _T("common", "disabled")
};
SYNO.SDS.LogCenter.RenderFormat = function(a) {
    if ("bsd" === a) {
        return "BSD"
    } else {
        if ("ietf" === a) {
            return "IETF"
        }
    }
    return a
};
SYNO.SDS.LogCenter.RenderProtocol = function(a) {
    return ("tcp" === a) ? "TCP" : "UDP"
};
Ext.define("SYNO.SDS.LogCenter.ServerSetting", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b = {
            border: false,
            autoScroll: false,
            useDefaultBtn: true,
            padding: 0,
            items: [this.gridpanel = new SYNO.SDS.LogCenter.Server.GridPanel(a)]
        };
        return this.callParent([Ext.apply(b, a)])
    },
    onPageActivate: function() {
        SYNO.SDS.LogCenter.ResizePanel(this)
    },
    isFormDirty: function() {
        return (this.gridpanel.getStore().getModifiedRecords().length > 0)
    },
    initEvents: function() {
        this.mon(this, "activate", this.gridpanel.doReloadGrid, this.gridpanel)
    },
    getApiArray: function(a) {
        return ("set" === a) ? [this.gridpanel.getApiSaveRules()] : []
    },
    getCompoundCfg: function(a) {
        return a === "set" ? {
            mode: "sequential"
        } : {}
    },
    processParams: function(b, a) {
        if ("set" === b) {
            return this.gridpanel.getApiSaveRules()
        }
        return []
    },
    onPageConfirmLostChangeSave: function() {
        return new Promise(function(b, a) {
            this.savePromise = {
                resolve: b,
                reject: a
            };
            this.applyHandler()
        }.bind(this))
    },
    onApiSuccess: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.resolve();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    onApiFailure: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.reject();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    processReturnData: function(c, b, a) {
        this.gridpanel.processReturnData(c, b, a)
    },
    cancelHandler: function(b, a) {
        this.gridpanel.reset()
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtAdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    validator: SYNO.SDS.LogCenter.KeywordValidator,
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() === Ext.EventObject.ENTER) {
                if (!this.validate()) {
                    return
                }
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof Ext.form.DateField) {
                    if (d.menu && c.within(d.menu.getEl())) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [6, 0]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtSearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        };
        this.dataRange = [
            [this.dateType.custom, _T("log", "date_custom")],
            [this.dateType.today, _T("log", "date_today")],
            [this.dateType.yesterday, _T("log", "date_yesterday")],
            [this.dateType.lastweek, _T("log", "date_lastweek")],
            [this.dateType.lastmonth, _T("log", "date_lastmonth")]
        ];
        this.logLevelType = {
            info: "info",
            warn: "warning",
            error: "err"
        };
        this.logLevel = [
            [this.logLevelType.info, _T("log", "info_level")],
            [this.logLevelType.warn, _T("log", "warn_level")],
            [this.logLevelType.error, _T("log", "error_level")]
        ];
        this.defaultAnimation = ["#000", 1, {
            duration: 0.35
        }];
        Ext.apply(this, a || {});
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.defineBehaviors();
        this.mon(this, "afterlayout", this.addToolTip, this, {
            single: true
        })
    },
    initComponent: function() {
        this.callParent([this]);
        this.addEvents("search")
    },
    getAllLogType: function(a) {
        var b = [];
        a.forEach(function(c) {
            b.push(c[0])
        });
        return b.join(",")
    },
    getAllLogDisplayText: function(a) {
        var b = [];
        a.forEach(function(c) {
            b.push(c[1])
        });
        return b.join(",")
    },
    fillConfig: function(h) {
        var d, j, e, l, a, g, f, b, k;
        var i = [];
        this.logType = h.logType;
        this.allLogType = this.getAllLogType(h.logType);
        this.allLogDisplayText = this.getAllLogDisplayText(h.logType);
        this.flagCustomOptionWindowShow = {};
        d = this.createKeyword();
        j = this.createFriendlyDate();
        e = this.createCustDate();
        l = this.createLevel();
        a = this.createType(h);
        g = this.createPrio();
        f = this.createHost();
        b = this.createProgram();
        k = this.createCategory();
        i.push(d);
        i.push(j);
        i.push(e);
        i.push(l);
        i.push(a);
        if (this.allLogType === "recvlog") {
            i.push(g);
            i.push(f);
            i.push(b);
            i.push(k)
        }
        i.push({
            xtype: "toolbar",
            border: false,
            itemId: "btns",
            toolbarCls: "syno-syslog-searchpanel-btn",
            style: "padding: 0px; padding-top: 12px;",
            items: [{
                xtype: "lctbtext",
                itemId: "search-loading",
                text: ""
            }, {
                xtype: "lctbtext",
                itemId: "msg",
                height: 26,
                style: "-webkit-text-size-adjust:none;font-size:11px;color:red;height:26px;overflow:hidden;",
                text: ""
            }, {
                xtype: "tbfill"
            }, {
                itemId: "btn_stop",
                xtype: "syno_button",
                btnStyle: "blue",
                cls: "syno-syslog-searchpanel-btn-reset",
                text: "Stop",
                hidden: true,
                handler: this.onStop,
                scope: this
            }, {
                xtype: "syno_button",
                cls: "syno-syslog-searchpanel-btn-reset",
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                itemId: "btn_search",
                xtype: "syno_button",
                btnStyle: "blue",
                cls: "syno-syslog-searchpanel-btn-search",
                text: _T("log", "search"),
                handler: this.onSearch,
                scope: this
            }]
        });
        var c = {
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            autoFlexcroll: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            items: i,
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.setMsg("");
                        this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        this.doLayout()
                    },
                    single: true
                },
                show: {
                    fn: this.doLayout,
                    single: true
                },
                beforehide: {
                    fn: function() {
                        if (Object.values(this.flagCustomOptionWindowShow).some(function(m) {
                                return m
                            })) {
                            return false
                        }
                    }
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    if (!this.isVisible()) {
                        return
                    }
                    if (!this.btnSearch.hidden && !this.btnSearch.disabled) {
                        this.onSearch()
                    } else {
                        if (!this.btnStop.hidden && !this.btnStop.disabled) {
                            this.onStop()
                        }
                    }
                },
                scope: this
            }]
        };
        return c
    },
    setComboBoxValue: function(b, a) {
        this.frameAnimation(b.el, this.defaultAnimation);
        if (b.setMultiValue) {
            b.setMultiValue(a.split(","))
        }
    },
    getComboBoxValue: function(b) {
        var a = this.getForm().findField(b);
        return a.getMultiValue ? a.getMultiValue().toString() : a.getValue()
    },
    multiSelect: function(c, e, a, d, b) {
        Ext.applyIf(c, {
            setMultiValue: function(f) {
                if (!Ext.isArray(f)) {
                    f = [f]
                }
                this.multiValue = f
            },
            getMultiValue: function() {
                return this.multiValue && this.multiValue.length > 0 ? this.multiValue : this.getValue().split(",")
            }
        });
        if ("more" === e.get("value")) {
            this.attriWin = new SYNO.SDS.LogCenter.ExtMultiSelectedDialog({
                title: d,
                combo: c,
                emptyValue: b,
                anim: this.defaultAnimation,
                owner: this.owner.appInst,
                parentPanel: this
            });
            this.attriWin.showUp();
            c.collapse();
            return false
        }
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText}">', "{displayText}", "</div>", "</tpl>")
    },
    logSelect: function(c, a, b) {
        this.setComboBoxValue(c, c.getValue())
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            msgTarget: "qtip",
            validateOnBlur: true,
            validationEvent: "blur",
            name: "keyword",
            style: "margin-bottom: 12px;",
            flex: 2,
            validator: SYNO.SDS.LogCenter.KeywordValidator,
            anchor: "91%"
        }]
    },
    setDate: function(c, b, a) {
        if (a === true) {
            this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation);
            this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)
        }
        this.form.findField("searchdatefrom").setMaxValue(b);
        this.form.findField("searchdateto").setMinValue(c);
        this.form.findField("searchdatefrom").setValue(c);
        this.form.findField("searchdateto").setValue(b)
    },
    getFromToDate: function(c) {
        var e, d, b = new Date();
        if (c === this.dateType.today) {
            e = b;
            d = b
        } else {
            if (c === this.dateType.yesterday) {
                e = b.add(Date.DAY, -1);
                d = e
            } else {
                if (c === this.dateType.lastweek) {
                    var a = b.getDay();
                    e = b.add(Date.DAY, -7 - a);
                    d = e.add(Date.DAY, 6)
                } else {
                    if (c === this.dateType.lastmonth) {
                        b = b.add(Date.MONTH, -1);
                        e = b.getFirstDateOfMonth();
                        d = b.getLastDateOfMonth()
                    }
                }
            }
        }
        return {
            from: e,
            to: d
        }
    },
    friendlyDateSelect: function(c, e, a) {
        var b = e.get("id"),
            d = this.getFromToDate(b);
        this.setDate(d.from, d.to, true)
    },
    getFriendlyDateStore: function() {
        var a = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    },
    createFriendlyDate: function() {
        this.FriendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "dateRange",
            tpl: this.createTpl(),
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            lazyRender: true,
            flex: 6,
            value: this.dateType.custom,
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.friendlyDateSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        this.DateFrom = new SYNO.ux.DateTimeField({
            name: "searchdatefrom",
            editable: false,
            format: "m/d/Y",
            emptyText: _T("log", "date_from"),
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdateto").setMinValue(a)
                }
            }
        });
        this.DateTo = new SYNO.ux.DateTimeField({
            name: "searchdateto",
            editable: false,
            format: "m/d/Y",
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdatefrom").setMaxValue(a)
                }
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    getLogLevelStore: function() {
        var a = this.logLevel.slice(0, this.logLevel.length);
        if (a.length > 1) {
            a.splice(0, 0, ["", _T("log", "log_all")]);
            a.push(["more", _T("log", "more_item") + "..."])
        }
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiLogLevelSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _T("log", "logattr"), "")
    },
    createLevel: function() {
        this.LogLevel = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            mode: "local",
            editable: false,
            name: "logLevel",
            tpl: this.createTpl(),
            store: this.getLogLevelStore(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: 3,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiLogLevelSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "logLevelLabel",
            value: _T("log", "logattr") + _T("common", "colon"),
            flex: 1
        }, this.LogLevel]
    },
    getLogTypeStore: function(a) {
        a = a.slice(0, a.length);
        if (a.length > 1) {
            a.splice(0, 0, ["", _T("log", "log_all")]);
            a.push(["more", _T("log", "more_item") + "..."])
        }
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiLogSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _T("tree", "leaf_log"), "")
    },
    getLogConfig: function(b, a) {
        this.LogTypeCombobox = new SYNO.ux.ComboBox({
            name: "logType",
            hiddenName: "logType",
            editable: false,
            tpl: this.createTpl(),
            mode: "local",
            store: this.getLogTypeStore(b),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: a || 3,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(c) {
                    delete c.combo.lastQuery
                },
                beforeselect: this.multiLogSelect,
                select: this.logSelect
            }
        });
        this.LogTypeLabel = new SYNO.ux.DisplayField({
            name: "logType",
            flex: a || 3,
            value: this.logType.length < 2 ? "" : this.allLogDisplayText
        });
        if (!Ext.isArray(b)) {
            b = [b]
        }
        return b.length < 2 ? this.LogTypeLabel : this.LogTypeCombobox
    },
    createType: function(a) {
        return [{
            xtype: "syno_displayfield",
            name: "logTypeLabel",
            value: this.logType.length < 2 ? "" : _T("tree", "leaf_log") + _T("common", "colon"),
            style: "margin-bottom: 12px;",
            flex: 3
        }, this.getLogConfig(a.logType, a.flex)]
    },
    priorStoreGet: function() {
        var a = [
            ["", _T("log", "log_all")],
            ["emerg", "Emergency"],
            ["alert", "Alert"],
            ["crit", "Critical"],
            ["err", "Error"],
            ["warning", "Warning"],
            ["notice", "Notice"],
            ["info", "Information"],
            ["debug", "Debug"],
            ["more", _T("log", "more_item") + "..."]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiAttrPrioSelect: function(b, c, a) {
        this.multiSelect(b, c, a, SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority"), "")
    },
    createPrio: function() {
        this.LogPrio = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "prio",
            editable: false,
            store: this.priorStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforeselect: this.multiAttrPrioSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "prioLabel",
            value: SYNO.SDS.LogCenter.StringGet("logattr", "attr_priority") + _T("common", "colon")
        }, this.LogPrio]
    },
    logAttriDbSet: function(a) {
        this.LogHost.getStore().baseParams.db_path = a;
        this.LogProgram.getStore().baseParams.db_path = a;
        this.LogCategory.getStore().baseParams.db_path = a
    },
    logAttriStoreGet: function(a) {
        return new SYNO.API.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.LogCenter.Log",
                method: "attr_enum",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "value"
            }, [{
                name: "value",
                mapping: "value"
            }, {
                name: "displayText",
                mapping: "displayText"
            }]),
            remoteSort: true,
            baseParams: {
                attr: a,
                db_path: "LOCALARCH"
            },
            pruneModifiedRecords: true,
            data: {
                total: 1,
                items: [{
                    value: "",
                    displayText: _T("log", "log_all")
                }]
            }
        })
    },
    hostNameStoreGet: function() {
        return this.logAttriStoreGet("host")
    },
    multiAttrHostSelect: function(b, c, a) {
        this.multiSelect(b, c, a, SYNO.SDS.LogCenter.StringGet("logattr", "attr_host"), "")
    },
    createHost: function() {
        this.LogHost = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "host",
            editable: false,
            mode: "remote",
            store: this.hostNameStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrHostSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "hostLabel",
            value: SYNO.SDS.LogCenter.StringGet("logattr", "attr_host") + _T("common", "colon")
        }, this.LogHost]
    },
    progStoreGet: function() {
        return this.logAttriStoreGet("prog")
    },
    multiAttrProgSelect: function(b, c, a) {
        this.multiSelect(b, c, a, SYNO.SDS.LogCenter.StringGet("logattr", "attr_program"), "")
    },
    createProgram: function() {
        this.LogProgram = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "prog",
            editable: false,
            mode: "remote",
            store: this.progStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrProgSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "progLabel",
            value: SYNO.SDS.LogCenter.StringGet("logattr", "attr_program") + _T("common", "colon")
        }, this.LogProgram]
    },
    facStoreGet: function() {
        return this.logAttriStoreGet("fac")
    },
    multiAttrFacSelect: function(b, c, a) {
        this.multiSelect(b, c, a, SYNO.SDS.LogCenter.StringGet("logattr", "attr_facility"), "")
    },
    createCategory: function() {
        this.LogCategory = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "fac",
            mode: "remote",
            editable: false,
            store: this.facStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrFacSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "facLabel",
            value: SYNO.SDS.LogCenter.StringGet("logattr", "attr_facility") + _T("common", "colon")
        }, this.LogCategory]
    },
    hideItems: function(b) {
        var c;
        if (!Ext.isArray(b)) {
            b = [b]
        }
        for (var a = b.length - 1; a >= 0; a--) {
            c = this.form.findField(b[a]);
            if (c) {
                c.setVisible(false)
            }
        }
    },
    showSearchIcon: function() {
        var b = this.get("btns"),
            a = b.get("search-loading");
        a.getEl().addClass("search-loading")
    },
    hideSearchIcon: function() {
        var b = this.get("btns"),
            a = b.get("search-loading");
        a.getEl().removeClass("search-loading")
    },
    frameAnimation: function(a, b) {
        if (a && a.isVisible()) {
            Ext.Element.prototype.frame.apply(a, b)
        }
    },
    defineBehaviors: function() {
        var a = this.get("btns");
        this.btnSearch = a.get("btn_search");
        this.btnStop = a.get("btn_stop")
    },
    setMsg: function(c) {
        var a = this.get("btns");
        var b = a.get("msg");
        b.setText(c);
        if (c.trim() !== "") {
            this.frameAnimation(b.el, this.defaultAnimation)
        }
    },
    setKeyWord: function(a) {
        var b = this.form.findField("keyword");
        if (b && Ext.isString(a)) {
            b.setValue(a)
        }
        b.focus("", 1)
    },
    onShowHideBtn: function(a) {
        if (a) {
            this.btnSearch.hide();
            this.btnStop.show()
        } else {
            this.btnSearch.show();
            this.btnStop.hide()
        }
    },
    onEnableDisableBtn: function(a) {
        if (a) {
            this.btnSearch.enable();
            this.btnStop.enable()
        } else {
            this.btnSearch.disable();
            this.btnStop.disable()
        }
    },
    isOwnerDestroyed: function() {
        return (this.owner && this.owner.isDestroyed)
    },
    showMsg: function(b, a) {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().alert(b, a)
        }
    },
    hideMsg: function() {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().hide()
        }
    },
    isFieldDirty: function(a) {
        return this.form.findField(a).isDirty()
    },
    validateForm: function() {
        if (!this.form.isValid()) {
            return false
        }
        return this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto") || this.isFieldDirty("keyword")
    },
    getIp: function(b) {
        var d = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){2}[.]([1-9][0-9]{0,1}|1[0-9]{2}|2[0-4][0-9]|25[0-4])$/,
            e = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){1}[.]([1-9][0-9]{0,1}|1[0-9]{2}|2[0-4][0-9]|25[0-4])$/,
            c = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){1}$/,
            a = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])$/;
        if (d.test(b)) {
            return b
        } else {
            if (e.test(b)) {
                return b + "/24"
            } else {
                if (c.test(b)) {
                    return b + "/16"
                } else {
                    if (a.test(b)) {
                        return b + "/8"
                    } else {
                        return ""
                    }
                }
            }
        }
    },
    onSearch: function(b, g) {
        var a, f, h, i, c, j;
        var d;
        a = this.getForm();
        f = a.findField("keyword").getValue();
        h = a.findField("searchdatefrom").getRawValue();
        i = a.findField("searchdateto").getRawValue();
        c = this.getComboBoxValue("logLevel");
        j = this.logType.length > 1 ? this.getComboBoxValue("logType") : this.allLogType;
        if (this.allLogType === "recvlog") {
            d = {
                keyword: f,
                date_from: h ? new Date(h + " 00:00:00").getTime() / 1000 : 0,
                date_to: i ? new Date(i + " 23:59:59").getTime() / 1000 : 0,
                level: this.getComboBoxValue("prio"),
                hostname: this.getComboBoxValue("host"),
                program: this.getComboBoxValue("prog"),
                category: this.getComboBoxValue("fac")
            }
        } else {
            d = {
                keyword: f,
                date_from: h ? new Date(h + " 00:00:00").getTime() / 1000 : 0,
                date_to: i ? new Date(i + " 23:59:59").getTime() / 1000 : 0,
                level: c,
                logtype: j || this.allLogType,
                ip: this.getIp(f)
            }
        }
        if (a.findField("keyword").isValid()) {
            this.fireEvent("search", this, d);
            a.findField("keyword").clearInvalid()
        }
    },
    onReset: function() {
        this.form.items.each(function(a) {
            if (a.isDirty()) {
                this.frameAnimation(a.el, this.defaultAnimation)
            }
        }, this);
        this.setMsg("");
        this.form.reset();
        this.form.findField("searchdatefrom").setMaxValue(null);
        this.form.findField("searchdateto").setMinValue(null);
        this.form.findField("logLevel").multiValue = "";
        this.form.findField("logType").multiValue = "";
        if (this.allLogType === "recvlog") {
            this.form.findField("prio").multiValue = "";
            this.form.findField("host").multiValue = "";
            this.form.findField("prog").multiValue = "";
            this.form.findField("fac").multiValue = ""
        }
        this.onSearch()
    },
    addToolTip: function() {
        SYNO.ux.AddTip(this.getForm().findField("keyword").getEl(), SYNO.SDS.LogCenter.StringGet("common", "opsearch_hint"))
    }
});
Ext.define("SYNO.SDS.LogCenter.Comp.TextItem", {
    extend: "Ext.Toolbar.TextItem",
    onRender: function(b, a) {
        this.autoEl = {
            cls: "xtb-text",
            html: this.text || "",
            "ext:qtip": this.text || ""
        };
        SYNO.SDS.LogCenter.Comp.TextItem.superclass.onRender.call(this, b, a)
    },
    setText: function(a) {
        SYNO.SDS.LogCenter.Comp.TextItem.superclass.setText.call(this, a);
        if (this.rendered) {
            this.el.set({
                "ext:qtip": a
            })
        }
    }
});
Ext.reg("lctbtext", SYNO.SDS.LogCenter.Comp.TextItem);
Ext.define("SYNO.SDS.LogCenter.ArchiveLog", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        Ext.apply(this, a);
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    storeLogTypeGet: function() {
        var a = [
            ["ExtReceiveLog", "All"],
            ["ExtGeneral", _T("log", "general")],
            ["ExtConnection", _T("log", "log_link_connection")],
            ["ExtFileTransfer", _T("log", "file_transfer")]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    enableExportButton: function(a) {
        this.ExportButton.setDisabled(!a)
    },
    enableClearButton: function(a) {
        this.ClearButton.setDisabled(!a)
    },
    enableChangeTypeCombo: function(a) {
        this.ChangeTypeCombo.setDisabled(!a)
    },
    initToolbar: function() {
        var a = new Ext.Toolbar({
            style: {
                border: "0px",
                padding: "0px"
            }
        });
        this.ClearButton = new SYNO.ux.Button({
            text: SYNO.SDS.LogCenter.StringGet("logview", "btn_clear"),
            handler: this.onClearLog,
            scope: this
        });
        this.ExportButton = new SYNO.ux.SplitButton({
            text: SYNO.SDS.LogCenter.StringGet("logview", "btn_export"),
            handler: this.onExportHtml,
            scope: this,
            menu: {
                items: [{
                    text: _T("log", "html_type"),
                    handler: this.onExportHtml,
                    scope: this
                }, {
                    text: _T("log", "csv_type"),
                    handler: this.onExportCSV,
                    scope: this
                }]
            }
        });
        this.ChangeSrcCombo = new SYNO.ux.Button({
            text: SYNO.SDS.LogCenter.StringGet("logsearch", "open_db"),
            handler: this.onOpenFileChooser,
            scope: this
        });
        this.ChangeTypeCombo = new SYNO.ux.ComboBox({
            name: "log_type",
            width: 130,
            editable: false,
            store: this.storeLogTypeGet(),
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            value: "ExtReceiveLog",
            listeners: {
                scope: this,
                select: this.onChangeLogType,
                beforeselect: this.onBeforeTypeSelect
            }
        });
        this.enableChangeTypeCombo(false);
        this.SearchField = new SYNO.SDS.LogCenter.ExtAdvancedSearchField({
            iconStyle: "filter",
            owner: this
        });
        this.SearchField.searchPanel = this.ExtReceiveLog.searchPanel;
        a.add(this.ClearButton);
        a.add(this.ExportButton);
        a.add("->");
        a.add(this.ChangeSrcCombo);
        a.add(this.ChangeTypeCombo);
        a.add(this.SearchField);
        return a
    },
    createPanelComponent: function(c) {
        var d, b;
        var a = {
            jsConfig: this.jsConfig,
            baseURL: this.jsConfig.jsBaseURL,
            topwin: this,
            appInst: this.appWin
        };
        switch (c) {
            case "ExtGeneral":
                d = new SYNO.SDS.LogCenter.ExtGeneralLogBuilder(Ext.apply({}, a));
                break;
            case "ExtConnection":
                d = new SYNO.SDS.LogCenter.ExtConnectionLogBuilder(Ext.apply({}, a));
                break;
            case "ExtFileTransfer":
                d = new SYNO.SDS.LogCenter.ExtFileTransferLogBuilder(Ext.apply({}, a));
                break;
            case "ExtReceiveLog":
                d = new SYNO.SDS.LogCenter.ExtReceiveLogBuilder(Ext.apply({}, a));
                break;
            default:
                d = new SYNO.SDS.LogCenter.ExtReceiveLogBuilder(Ext.apply({}, a));
                break
        }
        b = d.create(Ext.apply({}, a));
        return b
    },
    fillConfig: function(a) {
        this.ExtReceiveLog = this.createPanelComponent("ExtReceiveLog");
        Ext.apply(this.ExtReceiveLog.grid.getStore().baseParams, {
            target: ""
        });
        var b = {
            title: SYNO.SDS.LogCenter.StringGet("logsearch", "arch_db"),
            border: false,
            trackResetOnLoad: true,
            tbar: this.initToolbar(),
            layout: "card",
            activeItem: 0,
            items: [this.ExtReceiveLog]
        };
        Ext.apply(b, a);
        return b
    },
    doSwitchPage: function() {
        var b = this.ChangeTypeCombo.getValue();
        var c = this.dbpath;
        var a;
        switch (b) {
            case "ExtGeneral":
                a = this.ExtGeneralLog;
                break;
            case "ExtConnection":
                a = this.ExtConnectionLog;
                break;
            case "ExtFileTransfer":
                a = this.ExtFileTransferLog;
                break;
            case "ExtReceiveLog":
                a = this.ExtReceiveLog;
                Ext.apply(a.grid.getStore().baseParams, {
                    logtype: "all"
                });
                break;
            default:
                a = this.ExtReceiveLog;
                Ext.apply(a.grid.getStore().baseParams, {
                    logtype: "all"
                });
                break
        }
        if (a.dbpath != c) {
            a.paging.displayMsg = "{2} item(s)";
            a.maxSearchItem = -1;
            a.searchPanel.form.reset();
            this.SearchField.setValue("");
            a.dbpath = c;
            Ext.apply(a.grid.getStore().baseParams, a.initParams({
                target: c
            }))
        }
        a.searchPanel.logAttriDbSet(c);
        this.SearchField.searchPanel = a.searchPanel;
        this.getLayout().setActiveItem(b);
        a.onActive()
    },
    onChangeLogType: function(a) {
        this.doSwitchPage()
    },
    doExport: function(c) {
        var b = this.ChangeTypeCombo.getValue();
        var d = this.dbpath;
        var a;
        switch (b) {
            case "ExtGeneral":
                a = this.ExtGeneralLog;
                break;
            case "ExtConnection":
                a = this.ExtConnectionLog;
                break;
            case "ExtFileTransfer":
                a = this.ExtFileTransferLog;
                break;
            case "ExtReceiveLog":
                a = this.ExtReceiveLog;
                break;
            default:
                a = this.ExtReceiveLog;
                break
        }
        Ext.apply(a.grid.getStore().baseParams, {
            target: d
        });
        this.SearchField.searchPanel = a.searchPanel;
        a.onLogSave(c)
    },
    onExportHtml: function() {
        this.doExport("html")
    },
    onExportCSV: function() {
        this.doExport("csv")
    },
    onClickLatest: function(a) {
        this.dbpath = a;
        this.doSwitchPage()
    },
    onOpenFileChooser: function(c, d, a) {
        var b;
        b = new SYNO.SDS.Utils.FileChooser.Chooser({
            parent: this,
            owner: this.appWin,
            usage: {
                type: "open"
            },
            title: _T("texteditor", "Open"),
            folderToolbar: false,
            comboOption: [{
                label: _T("texteditor", "FileType"),
                value: "DB",
                data: [
                    ["DB", "Synology log DB"]
                ]
            }],
            enumCluster: true,
            enumC2Share: true,
            enumColdStorage: true,
            getFilterPattern: function(e, g, f) {
                return ["DB"].join()
            },
            listeners: {
                scope: this,
                choose: function(g, e, f) {
                    g.close();
                    this.enableChangeTypeCombo(true);
                    this.onClickLatest(e.fullpath)
                },
                cancel: function() {}
            }
        }).show()
    },
    getActivePage: function() {
        return this.getLayout().activeItem
    },
    onClearLogDone: function(d, b, c, a) {
        if (d) {
            this.getActivePage().loadData()
        } else {
            this.appWin.getMsgBox().alert(SYNO.SDS.LogCenter.StringGet("app", "app_name"), _T("common", "error_system"))
        }
        this.appWin.clearStatusBusy()
    },
    onClearLog: function() {
        var a = this.ExtReceiveLog.dbpath;
        this.appWin.getMsgBox().confirmDelete(SYNO.SDS.LogCenter.StringGet("app", "app_name"), _T("log", "log_cfrm_clear"), function(b) {
            if ("yes" === b) {
                this.appWin.setStatusBusy();
                this.appWin.sendWebAPI({
                    api: "SYNO.LogCenter.Log",
                    version: 1,
                    method: "clear",
                    params: {
                        category: "archive",
                        path: a
                    },
                    callback: this.onClearLogDone,
                    scope: this
                })
            }
        }, this)
    },
    onBeforeTypeSelect: function(d, a, b, c) {
        if ("ExtGeneral" === a.data.value && undefined === this.ExtGeneralLog) {
            this.ExtGeneralLog = this.createPanelComponent("ExtGeneral");
            this.add(this.ExtGeneralLog)
        } else {
            if ("ExtConnection" === a.data.value && undefined === this.ExtConnectionLog) {
                this.ExtConnectionLog = this.createPanelComponent("ExtConnection");
                this.add(this.ExtConnectionLog)
            } else {
                if ("ExtFileTransfer" === a.data.value && undefined === this.ExtFileTransferLog) {
                    this.ExtFileTransferLog = this.createPanelComponent("ExtFileTransfer");
                    this.add(this.ExtFileTransferLog)
                } else {
                    if ("ExtReceiveLog" === a.data.value && undefined === this.ExtReceiveLog) {
                        this.ExtReceiveLog = this.createPanelComponent("ExtReceiveLog");
                        this.add(this.ExtReceiveLog)
                    }
                }
            }
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.ExtMultiSelectedDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        Ext.apply(this, a);
        this.orginalValue = this.combo.getMultiValue ? this.combo.getMultiValue().toString() : this.combo.getValue();
        this.orginalDisplayValue = this.combo.getRawValue();
        this.attriFormPanel = this.createAttriFormPanel();
        var b = {
            width: 335,
            height: 410,
            resizable: false,
            title: a.title,
            comboName: a.combo.name,
            layout: "fit",
            closable: true,
            autoScroll: true,
            owner: a.owner,
            items: [this.attriFormPanel],
            buttons: [{
                text: _T("common", "cancel"),
                itemId: "cancel",
                handler: this.onCancel,
                scope: this
            }, {
                text: _T("common", "apply"),
                itemId: "apply",
                btnStyle: "blue",
                handler: this.onOk,
                scope: this
            }]
        };
        SYNO.SDS.LogCenter.ExtMultiSelectedDialog.superclass.constructor.call(this, b);
        this.initEvent()
    },
    initEvent: function() {
        this.mon(this, "close", this.onClose, this)
    },
    createAttriFormPanel: function() {
        var g = this.combo.getStore(),
            a = [],
            d = this.combo.displayField,
            c = this.combo.valueField,
            f, e;
        a.push({
            xtype: "syno_displayfield",
            indent: 0,
            value: _T("log", "title_select_desc") + _T("common", "colon")
        });
        g.each(function(i) {
            f = i.get(c);
            e = i.get(d);
            if (g.indexOf(i) === 0 || f === "more") {
                return true
            }
            var h = {
                xtype: "syno_checkbox",
                indent: 0,
                name: i.get(c),
                boxLabel: i.get(d)
            };
            a.push(h)
        }, this);
        var b = {
            labelWidth: 190,
            labelAlign: "left",
            border: false,
            autoHeight: true,
            trackResetOnLoad: true,
            items: a
        };
        return new Ext.form.FormPanel(b)
    },
    setCheckBox: function() {
        var d = this.attriFormPanel.getForm(),
            b = this.combo,
            e = b.getStore(),
            c = b.getMultiValue() || [],
            a = b.valueField;
        c = c.length > 0 ? c : [b.getValue()];
        e.each(function(g) {
            var f = g.get(a);
            if (c.indexOf(f) !== -1 && d.findField(f)) {
                d.findField(f).setValue(true)
            }
        }, this)
    },
    showUp: function() {
        if (this.getFlagCustomOptionWindowShow(this.comboName)) {
            return
        }
        this.setFlagCustomOptionWindowShow(this.comboName, true);
        this.setCheckBox();
        this.open();
        this.getEl().dom.style.zIndex = "11001"
    },
    onOk: function() {
        var f = this.attriFormPanel.getForm(),
            c = this.combo,
            g = c.getStore(),
            a = [],
            e = [],
            d = c.displayField,
            b = c.valueField;
        g.each(function(k) {
            var h = k.get(b),
                j = k.get(d),
                i = f.findField(h);
            if (i && i.getValue()) {
                a.push(j);
                e.push(h)
            }
        }, this);
        if (a.length === g.getCount() - 2) {
            c.setValue(this.emptyValue)
        } else {
            if (0 < a.length) {
                c.setRawValue(a.toString())
            } else {
                c.setValue(this.emptyValue)
            }
        }
        c.setMultiValue(e);
        this.isOK = true;
        Ext.Element.prototype.frame.apply(c.el, this.anim);
        this.close()
    },
    getFlagCustomOptionWindowShow: function(a) {
        return this.parentPanel.flagCustomOptionWindowShow[a]
    },
    setFlagCustomOptionWindowShow: function(b, a) {
        this.parentPanel.flagCustomOptionWindowShow[b] = a
    },
    onCancel: function() {
        this.close()
    },
    onClose: function() {
        var a = this.combo;
        if (!this.isOK) {
            a.setMultiValue(this.orginalValue);
            a.setRawValue(this.orginalDisplayValue)
        }
        this.setFlagCustomOptionWindowShow(this.comboName, false)
    }
});
