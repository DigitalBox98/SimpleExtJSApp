/* Copyright (c) 2020 Synology Inc. All rights reserved. */

var Swiff = Ext.extend(Ext.FlashComponent, {
    generateCallBacks: function(c) {
        this.instance = "Swiff_" + (+(new Date()));
        Swiff.CallBacks[this.instance] = {};
        var e = {},
            a = c.callBacks,
            b = this;
        for (var d in a) {
            if (a.hasOwnProperty(d)) {
                Swiff.CallBacks[this.instance][d] = (function(f) {
                    return function() {
                        return f.apply(b.el, arguments)
                    }
                })(a[d]);
                e[d] = "Swiff.CallBacks." + this.instance + "." + d
            }
        }
        return e
    },
    constructor: function(e) {
        Ext.apply(this.options, e || {});
        this.addEvents("onLoad");
        var a = this.options.callBacks || this;
        if (a.onLoad) {
            this.on("onLoad", a.onLoad, this)
        }
        if (!a.onBrowse) {
            a.onBrowse = function() {
                return this.options.typeFilter
            }
        }
        var d = {},
            b = this;
        Ext.each(["onBrowse", "onSelect", "onAllSelect", "onCancel", "onBeforeOpen", "onOpen", "onProgress", "onComplete", "onError", "onAllComplete", "onLog"], function(g) {
            var h = a[g] || Ext.emptyFn;
            d[g] = function() {
                return h.apply(b, arguments)
            }
        }, this);
        d.onLoad = (function() {
            this.load.createDelegate(this).defer(10)
        }).createDelegate(this);
        var f = this.generateCallBacks({
            callBacks: d
        });
        f.allowedDomain = "*";
        var c = this.options.url + "?v=" + _S("fullversion");
        if (Ext.isIE || Ext.isModernIE) {
            c += "&noCache=" + (new Date().getTime())
        }
        Swiff.superclass.constructor.call(this, Ext.apply(e, {
            id: "swfobject",
            url: c,
            wmode: "transparent",
            backgroundColor: "",
            flashParams: {
                swLiveConnect: "true"
            },
            flashVars: f,
            renderTo: document.body,
            style: {
                position: "absolute",
                visibility: "visible",
                zIndex: 99999
            },
            title: _WFT("upload", "upload_open_file"),
            alt: _WFT("upload", "upload_open_file")
        }));
        this.box = this.el;
        this.box.setBox({
            x: 0,
            y: 0,
            width: 15,
            height: 15
        });
        return this
    },
    setLowZindex: function() {
        if (this.box) {
            this.box.setStyle.createDelegate(this.box, ["zIndex", -1]).defer(500)
        }
    },
    setHighZindex: function() {
        if (this.box) {
            this.box.setStyle("zIndex", 99999)
        }
    },
    load: function() {
        this.remote("register", this.instance, this.options.multiple, this.options.queued);
        this.target = this.options.target;
        this.fireEvent("onLoad");
        this.setHighZindex()
    },
    reposition: function(a) {
        var b = this.target.getBox();
        if (a) {
            b.height = a
        }
        this.box.setBox(b)
    },
    setTarget: function(a) {
        this.target = a
    },
    browse: function(a) {
        this.options.typeFilter = a || this.options.typeFilter;
        if (!this.options.typeFilter) {
            this.options.typeFilter = null
        }
        return this.remote("browse")
    },
    upload: function(a) {
        var c = this.options;
        var b = {
            data: c.data,
            url: c.url,
            method: c.method,
            fieldName: c.fieldName
        };
        a = Ext.apply(b, a);
        if (Ext.type(a.data) == "element") {
            a.data = Ext.urlEncode(a.data)
        }
        return this.remote("upload", a)
    },
    removeFile: function(a) {
        if (a) {
            a = {
                name: a.name,
                size: a.size
            }
        }
        return this.remote("removeFile", a)
    },
    getFileList: function() {
        return this.remote("getFileList")
    },
    restartOneTask: function(a) {
        return this.remote("restartOneTask", {
            name: a.name
        })
    },
    setParameters: function(a) {
        if (a) {
            this.remote("setParameters", a)
        }
    }
});
Swiff.CallBacks = {};
var FlashUploader = Ext.extend(Swiff, {
    options: {
        limitSize: 2147482624,
        limitFiles: 1000,
        instantStart: true,
        multiple: true,
        queued: true,
        typeFilter: null,
        url: null,
        method: "post",
        fieldName: "Filedata",
        target: null,
        height: "100%",
        width: "100%",
        callBacks: null
    },
    taskSize: 0,
    taskOldSize: 0,
    taskUploadingIndex: 0,
    tasks: [],
    blSwiffyReady: false,
    nbExceedCount: 0,
    arrBigFile: [],
    arrZeroFile: [],
    flashParams: null,
    isSwiffyReady: function() {
        return this.blSwiffyReady
    },
    constructor: function(c, d, a, b) {
        FlashUploader.superclass.constructor.call(this, c);
        this.scope = d;
        this.taskUploadingIndex = 0;
        this.webfm = b
    },
    onBrowse: function() {},
    onLoad: function() {
        this.blSwiffyReady = true
    },
    onBeforeOpen: function(b, a) {
        while (this.taskUploadingIndex < this.taskSize && !this.tasks.hasOwnProperty(this.taskUploadingIndex)) {
            this.taskUploadingIndex++
        }
        return a
    },
    onOpen: function(b, c) {
        var a = {
            id: this.taskUploadingIndex
        };
        this.scope.onOpen(a)
    },
    onProgress: function(b, d, c) {
        var a = {
            id: this.taskUploadingIndex,
            timeLeft: d.timeLeft || 0,
            rate: d.rate,
            bytesTotal: d.bytesTotal,
            bytesLoaded: d.bytesLoaded,
            curname: b.name
        };
        Ext.apply(a, b);
        this.scope.onProgress(a)
    },
    unCompletedFileSize: function() {
        var e = this.scope.getStore();
        var b = e.getCount();
        var a;
        var d = 0;
        for (var c = 0; c < b; c++) {
            a = e.getAt(c).data.status;
            if (!(a == "SUCCESS" || a == "FAIL")) {
                d++
            }
        }
        return d
    },
    onSelect: function(c, b, e) {
        var f = [];
        if (0 === c.size) {
            f.push("size");
            this.arrZeroFile.push(c)
        } else {
            if (this.options.limitSize && (c.size > this.options.limitSize)) {
                f.push("size");
                this.arrBigFile.push(c)
            }
        }
        if (this.options.limitFiles && (this.unCompletedFileSize() >= this.options.limitFiles)) {
            f.push("length");
            this.nbExceedCount++
        }
        if (f.length) {
            var d = this.options.fileInvalid;
            if (d) {
                d.call(this, c, f)
            }
            return false
        }
        var a = {
            id: this.taskSize,
            timeLeft: -1,
            rate: 0,
            bytesTotal: 0,
            bytesLoaded: 0
        };
        Ext.apply(a, c);
        Ext.apply(c, this.params);
        this.scope.onSelect(a);
        this.tasks[this.taskSize] = c;
        this.taskSize++;
        this.scope.autoCleanOnePrecedingSuccessTask.call(this.scope);
        return true
    },
    onAllSelect: function(c, d, b) {
        var e = "";
        var a = 0;
        if (this.nbExceedCount) {
            e += (1 == this.nbExceedCount) ? _WFT("common", "common_unselect_file") : _WFT("common", "common_unselect_files");
            e += "<br>";
            if (1 < this.nbExceedCount) {
                e = e.replace("_NFILES_", this.nbExceedCount)
            }
            this.nbExceedCount = 0
        }
        if (this.arrBigFile && 0 < this.arrBigFile.length) {
            e += _WFT("upload", "upload_exceed_maximum_filesize") + ": <br>";
            for (a = 0;
                (a < this.arrBigFile.length && a < 5); a++) {
                e += this.arrBigFile[a].name + "<br>"
            }
            if (5 < this.arrBigFile.length) {
                e += "...<br>"
            }
            this.arrBigFile = []
        }
        if (this.arrZeroFile && 0 < this.arrZeroFile.length) {
            e += _WFT("upload", "upload_zerobyte_filesize") + " <br>";
            for (a = 0;
                (a < this.arrZeroFile.length && a < 5); a++) {
                e += this.arrZeroFile[a].name + "<br>"
            }
            if (5 < this.arrZeroFile.length) {
                e += "...<br>"
            }
            this.arrZeroFile = []
        }
        if (e) {
            this.webfm.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), e)
        }
        this.scope.onAllSelect(this.taskOldSize, this.taskSize);
        this.taskOldSize = this.taskSize;
        if (this.taskSize && this.options.instantStart) {
            this.flashUpload.createDelegate(this).defer(10)
        }
    },
    onComplete: function(c, b, d) {
        b = decodeURIComponent(b);
        var e = Ext.util.JSON.decode(b);
        var a;
        if (e && (e.success === true || (e.error && e.error.code === 414))) {
            a = {
                id: this.taskUploadingIndex,
                name: c.name,
                remotedir: c.remotedir,
                isSkip: d
            };
            this.scope.onComplete(a)
        } else {
            a = {
                id: this.taskUploadingIndex,
                curname: c.name,
                response: e
            };
            this.scope.onError(a)
        }
        this.taskUploadingIndex++
    },
    onError: function(c, b, d) {
        var a = {
            id: this.taskUploadingIndex,
            curname: c.name,
            response: b + " " + d
        };
        this.scope.onError(a);
        this.taskUploadingIndex++
    },
    onAllComplete: function(a) {
        this.scope.onAllComplete(a)
    },
    removeFile: function(b, a) {
        var c = this.tasks[b];
        if (c) {
            if (this.taskUploadingIndex == b) {
                this.taskUploadingIndex++
            }
            delete this.tasks[b];
            if (a != "SUCCESS") {
                FlashUploader.superclass.removeFile.call(this, c)
            }
        }
    },
    restartOneTask: function(a) {
        var b = this.tasks[a];
        if (b) {
            if (FlashUploader.superclass.restartOneTask.call(this, b)) {
                return true
            }
        }
        return false
    },
    flashUpload: function() {
        SYNO.FileStation.FlashUploader.flashUpload()
    },
    setParameters: function(a) {
        FlashUploader.superclass.setParameters.call(this, a)
    },
    onLog: function() {
        console.log(arguments)
    }
});
Ext.ns("SYNO.FileStation.FlashUploader");
Ext.apply(SYNO.FileStation.FlashUploader, {
    isFlashReservedPort: function(a) {
        var b = [1, 7, 9, 11, 13, 15, 17, 19, 20, 21, 22, 23, 25, 37, 42, 43, 53, 77, 79, 87, 95, 101, 102, 103, 104, 109, 110, 111, 113, 115, 117, 119, 123, 135, 139, 143, 179, 389, 465, 512, 513, 514, 515, 526, 530, 531, 532, 540, 556, 563, 587, 601, 636, 993, 995, 2049, 4045, 6000];
        if ("string" === typeof(a)) {
            a = parseInt(a, 10)
        }
        return (-1 !== b.indexOf(a))
    }
});
Ext.apply(SYNO.FileStation.FlashUploader, {
    blFlash: false,
    parentDir: null,
    swiffy: null,
    blOverwrite: false,
    browseFile: function() {
        if (this.swiffy && this.swiffy.isSwiffyReady()) {
            this.swiffy.browse()
        }
        return false
    },
    swiffyReposition: function(a) {
        if (!this.blFlash) {
            return false
        }
        if (this.swiffy && this.swiffy.isSwiffyReady()) {
            this.swiffy.reposition(a)
        }
        return false
    },
    setHighZindex: function() {
        if (!this.blFlash) {
            return false
        }
        if (this.swiffy && this.swiffy.isSwiffyReady()) {
            this.swiffy.setHighZindex()
        }
        return false
    },
    setLowZindex: function() {
        if (!this.blFlash) {
            return false
        }
        if (this.swiffy && this.swiffy.isSwiffyReady()) {
            this.swiffy.setLowZindex()
        }
        return false
    },
    flashUpload: function() {
        if (!this.swiffy || !this.swiffy.isSwiffyReady()) {
            return
        }
        if (Ext.isEmpty(this.swiffy.options.data)) {
            this.swiffy.options.data = {}
        }
        this.swiffy.options.data._sid = this.session;
        this.swiffy.options.url = this.Url;
        var a = {};
        if (_S("SynoToken")) {
            a.token = _S("SynoToken")
        }
        this.swiffy.upload(a);
        return false
    },
    reinit: function(a) {
        this.btnBrowse = a;
        this.swiffy.setTarget(a.getEl())
    },
    init: function(a, e, h, i, g, f) {
        var d = e.getEl();
        var c = SYNO.SDS.Utils.getPunyBaseURL();
        this.Url = SYNO.SDS.Utils.getPunyHost() + "webapi/_______________________________________________________entry.cgi";
        this.swiffy = new FlashUploader({
            url: c + a + "/Swiff.Uploader.swf",
            target: d
        }, h, g, f);
        this.swiffy.on("onLoad", function() {
            this.swiffyReposition(i)
        }, this);
        this.btnBrowse = e;
        var b = Ext.fly("swfobject");
        b.on("mousemove", function(l) {
            var k = this.btnBrowse.items.get(0);
            var m = this.btnBrowse.items.get(1);
            var j = l.getXY();
            if (SYNO.webfm.utils.checkPointInBox(k.getEl().getBox(), j[0], j[1])) {
                m.deactivate();
                k.activate()
            } else {
                k.deactivate();
                m.activate()
            }
        }, this);
        b.on("mouseout", function(k) {
            var j = this.btnBrowse.items.get(0);
            var l = this.btnBrowse.items.get(1);
            j.deactivate();
            l.deactivate()
        }, this);
        b.on("mousedown", function(l) {
            var k = this.btnBrowse.items.get(0);
            var j = l.getXY();
            var m = false;
            if (SYNO.webfm.utils.checkPointInBox(k.getEl().getBox(), j[0], j[1])) {
                m = false
            } else {
                m = true
            }
            SYNO.FileStation.FlashUploader.swiffy.setParameters({
                overwrite: m,
                dest: SYNO.FileStation.FlashUploader.uploadDir
            });
            return true
        }, this);
        return this.swiffy
    },
    restartOneTask: function(b, a) {
        return SYNO.FileStation.FlashUploader.swiffy.restartOneTask(b)
    },
    setParameters: function(a, b) {
        this.uploadDir = a;
        this.session = b
    },
    removeOneTask: function(b, a) {
        SYNO.FileStation.FlashUploader.swiffy.removeFile(b, a)
    }
});
Ext.ns("SYNO.FileStation.JavaUploader");
Ext.apply(SYNO.FileStation.JavaUploader, {
    removeOneTask: function(d, a) {
        var c = {
            action: "cancelupload",
            id: d
        };
        var b = AppletProgram.action(c);
        if (AppletProgram.checkResponse(b, a)) {
            return true
        }
        return false
    },
    restartOneTask: function(d, a) {
        var c;
        c = {
            action: "restartupload",
            id: d
        };
        var b = AppletProgram.action(c);
        if (AppletProgram.checkResponse(b, a)) {
            return true
        }
        return false
    }
});
Ext.ns("SYNO.FileStation.Action");
SYNO.FileStation.Action.FormUpload = Ext.extend(Object, {
    parentDir: null,
    taskCnt: 0,
    prefix: "formupload",
    taskSize: 0,
    taskTotal: 0,
    tasks: {},
    blUploading: false,
    taskInfo: function(a, f, b, e, c, g, h, i, d) {
        this.id = a;
        this.formpanel = f;
        this.form = b;
        this.blOverwrite = e;
        this.parentDir = c;
        this.formIndex = g;
        this.formLength = h;
        this.uploaderName = i;
        this.sharing_id = d
    },
    constructor: function(a) {
        Ext.apply(this, a.params)
    },
    getMonitorGrid: function() {
        return this.monitorGrid
    },
    makeCompactUpFormArr: function(j, m, h, f, o, q, g) {
        var k, e, l = 0;
        var b = this.taskSize;
        var p = 0;
        for (k = 0; k < m.length; k++) {
            e = m[k].form.findField("file").getValue();
            e = Ext.util.Format.trim(e);
            if (e) {
                p++
            }
        }
        var a = this.getMonitorGrid().getAvailableTaskNumber(p);
        var c = p - a;
        if (0 < c) {
            var n = _WFT("filetable", "filetable_select_max");
            n = n.replace("_MAXNO_", this.getMonitorGrid().getMaxTaskNumber()) + "<br>";
            if (1 == c) {
                n += _WFT("common", "common_unselect_file")
            } else {
                n += _WFT("common", "common_unselect_files");
                n = n.replace("_NFILES_", c)
            }
            j.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), n)
        }
        if (a <= 0) {
            return
        }
        for (k = 0; k < a; k++) {
            e = m[k].form.findField("file").getValue();
            e = Ext.util.Format.trim(e);
            if (e) {
                var d = this.prefix + new Date().getTime() + "_" + k;
                this.tasks[this.taskSize] = new this.taskInfo(d, j, m[k].form, h, f, l, o, q, g);
                this.getMonitorGrid().onSelect({
                    id: d,
                    name: this.getFileName(e)
                });
                l++;
                this.taskSize++
            }
        }
        this.getMonitorGrid().onAllSelect(b, this.taskSize)
    },
    onStartBgTask: function(b) {
        var c = b.taskid;
        var a = b.sharing_id;
        var d = SYNO.SDS.UploadTaskMgr.addWebAPITask({
            id: c,
            query: {
                api: "SYNO.FileStation.FormUpload",
                method: "status",
                version: 2,
                params: {
                    taskid: c,
                    sharing_id: a
                }
            },
            cancel: {
                api: "SYNO.FileStation.FormUpload",
                method: "cancel",
                version: 2,
                params: {
                    taskid: c,
                    sharing_id: a
                }
            }
        });
        d.addCallback(this.onTaskCallBack, this);
        this.bkTask = d
    },
    findTaskIndexById: function(d) {
        var c = false;
        var a;
        for (var b = this.taskCnt - 1; b < this.taskSize; b++) {
            a = this.tasks[b];
            if (a && (d === a.id)) {
                c = true;
                break
            }
        }
        return c ? b : -1
    },
    cancelEvent: function(a) {
        SYNO.FileStation.FormUploader.removeOneTask.call(SYNO.FileStation.FormUploader, a)
    },
    removeOneTask: function(g) {
        var f;
        if ((f = this.findTaskIndexById(g)) === -1) {
            return
        }
        var b = this.tasks[f];
        var e, a;
        var c = true;
        for (var d = 0; d < b.formLength; d++) {
            a = (d < b.formIndex) ? (f - d) : (f + d - b.formIndex);
            if (f === a) {
                continue
            }
            e = this.tasks[a];
            if ((e && (b.formpanel === e.formpanel))) {
                c = false;
                break
            }
        }
        if (c) {
            b.formpanel.close()
        }
        this.tasks[f] = null;
        if (this.bkTask && SYNO.SDS.UploadTaskMgr.getTask(g)) {
            this.bkTask.cancel();
            this.blUploading = false;
            this.submitForm()
        }
    },
    initForm: function(f, b, g, d, c, e, a) {
        this.makeCompactUpFormArr(f, b, g, d, c, e, a);
        if (!this.blUploading) {
            this.submitForm()
        }
    },
    destroy: function() {
        var a = this.tasks[this.taskCnt];
        var b = this.tasks[this.taskCnt - 1];
        if (b) {
            if (this.taskCnt >= this.taskSize || (a && (b.formpanel !== a.formpanel))) {
                b.formpanel.close()
            }
            this.tasks[this.taskCnt - 1] = null
        }
    },
    getFileName: function(a) {
        if (Ext.isWindows) {
            a = a.substr(a.lastIndexOf("\\") + 1)
        } else {
            if (Ext.isOpera) {
                a = a.replace("C:\\fake_path\\", "")
            } else {
                if (Ext.isWebKit) {
                    a = a.replace("C:\\fakepath\\", "")
                } else {
                    a = a.substr(a.lastIndexOf("/") + 1)
                }
            }
        }
        return a
    },
    submitForm: function() {
        this.destroy();
        if (this.taskCnt >= this.taskSize) {
            this.getMonitorGrid().onAllComplete();
            return
        }
        var a = this.tasks[this.taskCnt];
        if (Ext.isDefined(a) && a === null) {
            this.taskCnt++;
            this.submitForm();
            return
        }
        this.blUploading = true;
        var b = a.form.findField("file").getValue();
        this.getMonitorGrid().onOpen({
            id: a.id
        });
        if (a.blOverwrite) {
            this.sendFile(a, b)
        } else {
            b = this.getFileName(b);
            this.sendCheckInfo(a, b)
        }
        this.taskCnt++
    },
    sendCheckInfo: function(a, b) {
        var c = {
            task: a,
            name: b
        };
        SYNO.API.Request({
            api: "SYNO.FileStation.CheckPermission",
            method: "write",
            version: 3,
            params: {
                path: a.parentDir,
                filename: b,
                taskid: a.id,
                overwrite: a.blOverwrite,
                uploader_name: a.uploaderName,
                sharing_id: a.sharing_id
            },
            scope: this,
            callback: function(f, e, d) {
                if (f) {
                    this.onCheckDone(e, c)
                } else {
                    this.onCheckError(e)
                }
            }
        })
    },
    onCheckDone: function(b, a) {
        if (!b.blSkip) {
            this.sendFile(a.task, a.name)
        } else {
            this.onFinishTask(b);
            this.submitForm()
        }
    },
    setFormFieldValue: function(a) {
        var b = this.url;
        var c = a.form;
        c.url = b;
        if (a.blOverwrite) {
            c.findField("overwrite").setValue(true)
        } else {
            c.findField("overwrite").setValue(false)
        }
        c.findField("taskid").setValue(a.id);
        c.findField("path").setValue(a.parentDir);
        c.findField("uploader_name").setValue(a.uploaderName);
        c.findField("sharing_id").setValue(a.sharing_id)
    },
    sendFile: function(a, b) {
        this.setFormFieldValue(a);
        a.form.doAction("apply");
        this.onStartBgTask({
            taskid: a.id,
            sharing_id: a.sharing_id,
            pFile: b,
            url: this.url
        })
    },
    onCheckError: function(d) {
        var a = this.tasks[this.taskCnt - 1];
        var e = a.form.findField("file").getValue();
        var c = SYNO.webfm.utils.parseFullPathToFileName(e);
        var b = {};
        if (!d.error) {
            b = {
                error: d
            }
        } else {
            b = d
        }
        this.getMonitorGrid().onError({
            id: a.id,
            curname: c,
            response: b,
            status: "FORM_FAIL"
        });
        this.blUploading = false;
        this.submitForm()
    },
    onFinishTask: function(a) {
        this.blUploading = false;
        if ((a.result && a.result == "fail")) {
            this.onCheckError(a)
        } else {
            this.onCompleteTask(a)
        }
    },
    onCompleteTask: function(e) {
        var b = this.tasks[this.taskCnt - 1];
        var a = b.parentDir;
        var d = b.form.findField("file").getValue();
        var c = SYNO.webfm.utils.parseFullPathToFileName(d);
        this.getMonitorGrid().onComplete({
            id: b.id,
            remotedir: a,
            isSkip: e.blSkip,
            name: c
        })
    },
    onProgressTask: function(b, d) {
        if (b && d.pfile && 0 < b) {
            var a = SYNO.webfm.utils.parseFullPathToFileName(d.pfile);
            var c = (b * 100).toFixed(0);
            this.getMonitorGrid().onProgressWithTime({
                id: d.taskid,
                byteswrite: d.byteswrite,
                progress: c,
                name: a,
                curname: a,
                taskInfo: {
                    progress: c
                }
            })
        }
    },
    onCancelTask: function(b) {
        if (b.errno && b.errno.section && b.errno.key) {
            var a = b.errno;
            this.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT(a.section, a.key))
        }
    },
    onTaskCallBack: function(a, c, e, b, d) {
        if (!d) {
            return
        }
        if ("cancel" === c) {
            this.onCancelTask(d.data);
            this.blUploading = false;
            this.submitForm()
        } else {
            if (e) {
                this.onFinishTask(d.data);
                this.submitForm()
            } else {
                this.onProgressTask(b, d.data)
            }
        }
    }
});
SYNO.FileStation.FormUploader = null;
Ext.ns("SYNO.FileStation");
SYNO.FileStation.MonitorGrid = function(b) {
    this.maxTasks = 1000;
    this.progressInfoArray = [];
    this.RELURL = b.RELURL || "";
    this.gridCtxMenu = this.initCtxMenu();
    var a = this.initColumnModel();
    var c = {
        enableHdMenu: false,
        store: this.initDS(),
        cm: a,
        selModel: new Ext.grid.RowSelectionModel({
            singleSelect: false
        }),
        enableColumnMove: false,
        enableDragDrop: false,
        loadMask: true,
        enableColLock: false,
        border: false,
        viewConfig: {
            forceFit: true,
            listeners: {
                rowsinserted: {
                    scope: this,
                    fn: this.initProgress
                }
            }
        },
        listeners: {
            render: {
                scope: this,
                fn: function() {
                    this.getGridEl().addClass("without-dirty-red-grid")
                }
            },
            rowcontextmenu: {
                scope: this,
                fn: this.rowContextMenuHandle
            },
            rowclick: {
                fn: function(d, g, f) {
                    if (f && g && !f.hasModifier()) {
                        d.getSelectionModel().selectRow(g)
                    }
                }
            }
        }
    };
    Ext.apply(c, b || {});
    SYNO.FileStation.MonitorGrid.superclass.constructor.call(this, c);
    this.addEvents({
        cancel: true,
        restart: true
    })
};
Ext.extend(SYNO.FileStation.MonitorGrid, SYNO.ux.GridPanel, {
    taskRec: Ext.data.Record.create({
        name: "id",
        mapping: "id",
        type: "int"
    }, {
        name: "icon",
        mapping: "icon"
    }, {
        name: "event",
        mapping: "event"
    }, {
        name: "name",
        mapping: "name"
    }, {
        name: "rate",
        mapping: "rate"
    }, {
        name: "starttime",
        mapping: "starttime"
    }, {
        name: "lasttime",
        mapping: "lasttime"
    }, {
        name: "lefttime",
        mapping: "lefttime"
    }, {
        name: "lastwrite",
        mapping: "lastwrite"
    }, {
        name: "progress",
        mapping: "progress"
    }, {
        name: "status",
        mapping: "status"
    }),
    progressInfo: function(a) {
        var b = a;
        this.lastUpdate = 0;
        this.updateInterval = 500;
        this.update = function(i, n, d, e, o, l, c, j, h, m, g, p, k) {
            var f = (new Date()).getTime();
            this.rec = i;
            if (null === n && (f - this.lastUpdate) < this.updateInterval) {
                return
            }
            this.updateProgress(n, d, e, o, l, c, j, h, m);
            this.updateRecord(n, d, e, o, l, c, j, h, m, g, (p) ? f / 1000 : null, k);
            this.lastUpdate = f
        };
        this.getDuration = function() {
            var e, c, d;
            e = this.rec.data.starttime;
            c = new Date().getTime() / 1000;
            d = c - e;
            return d
        };
        this.getDurationGap = function() {
            var c, d, e, f = this.rec;
            f.data.lasttime = f.data.lasttime || f.data.starttime;
            d = f.data.lasttime;
            c = new Date().getTime() / 1000;
            e = c - d;
            return e
        };
        this.calcLeftTime = function(f, e) {
            var g = this.getDuration(),
                d, c = (e) ? e : f;
            d = Math.round(((g * (100 - c)) / c));
            d = String.format("{0}", (d > 1) ? SYNO.webfm.utils.fancyDuration(d) : SYNO.webfm.utils.fancyDuration(1));
            return d
        };
        this.updateWithLeftTime = function(g, k, d, e, l, i, c, h, f, j) {
            this.rec = g;
            l = null;
            if (c && c !== 100) {
                l = this.calcLeftTime(c)
            }
            this.update(g, k, d, e, l, i, c, h, f, j)
        };
        this.updateWithRate = function(j, p, d, e, q, o, c, k, g, n, h, l) {
            this.rec = j;
            var i, m = null,
                f = j.data.lastwrite || 0;
            f = (f > o) ? 0 : f;
            q = null;
            i = this.getDurationGap();
            if (i < 1) {
                return
            }
            if (c && c !== 100) {
                q = this.calcLeftTime(c, h.progress);
                m = i ? ((o - f) / i) : null;
                m = String.format("{0}/s", m ? Ext.util.Format.fileSize(m) : "- B")
            }
            if (h.isSubFile && m === null) {
                m = i ? ((o - f) / i) : null;
                m = String.format("{0}/s", m ? Ext.util.Format.fileSize(m) : "- B")
            }
            this.update(j, p, d, e, q, m, c, k, g, n, null, true, l);
            if (h.complete !== true) {
                this.updateByteWrite(o)
            }
        };
        this.updateProgress = function(o, d, e, p, l, c, j, h, m) {
            if (!b) {
                return
            }
            var n = Ext.util.Format.htmlEncode(e);
            var i = l || "&nbsp;";
            var k = p || "&nbsp;";
            var f = Math.floor(c) || 0;
            var g = n + "<br>" + f + "%&nbsp;" + i + "&nbsp;" + k + "<br>" + Ext.util.Format.htmlEncode(m);
            if (b.setAttributeNS) {
                b.setAttributeNS("ext", "qtip", g)
            } else {
                b.setAttribute("ext:qtip", g)
            }
        };
        this.updateRecord = function(n, e, f, o, l, c, j, h, m, g, d, k) {
            var i = this.rec;
            if (n) {
                i.data.icon = n
            }
            if (f) {
                i.data.name = f
            }
            if (e) {
                i.data.event = e
            }
            i.data.rate = l || "";
            i.data.totalbyte = k || 0;
            i.data.lefttime = o || "";
            if (c) {
                i.data.progress = c
            }
            i.data.status = j;
            i.data.statusText = h;
            i.data.statusQtip = m;
            if (g) {
                i.data.starttime = g
            }
            if (d) {
                i.data.lasttime = d
            }
            i.commit()
        };
        this.updateByteWrite = function(c) {
            var d = this.rec;
            d.data.lastwrite = c
        }
    },
    initProgress: function(a, d) {
        var c = this.getStore().getAt(d);
        var b = a.getRow(d);
        this.progressInfoArray[c.data.id] = new this.progressInfo(b)
    },
    setMaxTaskNumber: function(a) {
        this.maxTasks = a
    },
    getMaxTaskNumber: function() {
        return this.maxTasks
    },
    initColumnModel: function() {},
    iconRenderer: function(g, d, f, b, e, a) {
        var c = "1x";
        if (this.isRetina()) {
            c = "2x"
        }
        return String.format('<img width="20" height="20" src="' + this.RELURL + '../FileTaskMonitor/images/{0}/progress/{1}"/>', c, f.data.icon)
    },
    nameRenderer: function(g, d, f, c, e, a) {
        var b = Ext.util.Format.htmlEncode(f.data.name);
        d.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(b) + '"';
        return b
    },
    timeRenderer: function(f, c, e, b, d, a) {
        return String.format('<span class="progress-text-normal" style="display: inline;">{0}</span>', e.data.lefttime || "")
    },
    rateRenderer: function(f, c, e, b, d, a) {
        return String.format('<span class="progress-text-normal" style="display: inline;">{0}</span>', e.data.rate || "")
    },
    progressRenderer: function(c, h, d, j, b, i) {
        var e = d.data;
        if (e.progress === false) {
            return "..."
        }
        var k = Math.floor(e.progress);
        var a = "";
        if (k > 0) {
            if (e.total && 0 < e.total && (e.processed_num || e.processed_size)) {
                if (Ext.isNumber(e.processed_size)) {
                    a = "&nbsp;(" + Ext.util.Format.fileSize(e.processed_size || 0) + "/" + Ext.util.Format.fileSize(e.total) + ")"
                } else {
                    a = "&nbsp;(" + (e.processed_num || 0) + "/" + e.total + ")"
                }
            }
        }
        var f = new SYNO.SDS.Utils.ProgressBar({
            barHeight: 6,
            lineHeight: 16,
            marginTop: 5,
            showValueText: true,
            fixed: false
        });
        var g = new Ext.XTemplate("{progressBar}", '<span id="progressbartext" class="progress-text" style="display: inline;">{progresstext}</span>');
        return g.apply({
            progressBar: f.fill(k, null, d.get("status").indexOf("FAIL") >= 0),
            progresstext: a
        })
    },
    statusRenderer: function(b, f, d, i, a, h) {
        var e = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(d.data.statusQtip));
        var g = Ext.util.Format.htmlEncode(d.data.statusText);
        var c = (d.data.status.indexOf("FAIL") >= 0) ? "color:#E64040;" : "";
        return String.format('<div style="text-overflow: ellipsis; {0}" ext:qtip="{1}"><span style="display:inline;">{2}</span></div>', c, e, g)
    },
    initDS: function() {
        var a = new Ext.data.Store({
            autoDestroy: true,
            remoteSort: false,
            reader: new Ext.data.JsonReader({
                root: "files",
                id: "id"
            }, ["id", "icon", "event", "name", "rate", "starttime", "lefttime", "progress", "status", "processed_num", "processed_size", "total", "processing_path"])
        });
        return a
    },
    updateMenuStatus: function(a) {},
    rowContextMenuHandle: function(a, f, b) {
        b.preventDefault();
        var d = a.getSelectionModel();
        if (!d.isSelected(f)) {
            d.selectRow(f)
        }
        var c = this.getStore().getAt(f);
        this.updateMenuStatus(c);
        this.gridCtxMenu.showAt(b.getXY())
    },
    initCtxMenu: function() {
        var a = new SYNO.ux.Menu({
            items: [{
                itemId: "gc_remove",
                iconCls: "webfm-delete-icon",
                text: _WFT("upload", "upload_itm_remove"),
                handler: this.removeTasks,
                scope: this
            }, {
                itemId: "gc_restart",
                iconCls: "webfm-restart-icon",
                text: _WFT("common", "restart"),
                handler: this.restartTasks,
                scope: this
            }, "-", {
                itemId: "gc_clean",
                iconCls: "webfm-clear-icon",
                text: _WFT("upload", "upload_itm_clean"),
                handler: this.cleanAllSuccessTasks,
                scope: this
            }]
        });
        this.addManagedComponent(a);
        return a
    },
    pauseResumeTask: function() {
        return true
    },
    restartTasks: function() {
        var c = this.getSelectionModel().getSelections();
        if (c.length < 1) {
            return
        }
        var b;
        for (var a = 0; a < c.length; a++) {
            b = c[a].data;
            if (b.status == "FAIL") {
                if (!this.fireEvent("restart", b.id, b.name)) {
                    continue
                }
                this.removeOneTask(c[a])
            }
        }
    },
    removeOneTask: function(d, b) {
        if (!d) {
            return
        }
        var e = d.data.id;
        var a = d.data.status;
        var c;
        if (d.data.cancelEvent) {
            c = (b !== false) ? d.data.cancelEvent() : true
        } else {
            c = this.fireEvent("cancel", e, a)
        }
        this.getStore().remove(d);
        delete this.progressInfoArray[e];
        return c
    },
    removeTasks: function() {
        var b = this.getSelectionModel().getSelections();
        if (b.length < 1) {
            return
        }
        for (var a = 0; a < b.length; a++) {
            if (!this.removeOneTask(b[a])) {
                break
            }
        }
    },
    autoCleanOnePrecedingSuccessTask: function() {
        var c = this.getStore().data.items;
        if (c.length <= this.maxTasks) {
            return
        }
        var a;
        for (var b = 0; b < c.length; b++) {
            a = c[b].data.status;
            if (a == "SUCCESS") {
                this.removeOneTask(c[b]);
                break
            } else {
                if (a == "PROCESSING" || a == "NOT_STARTED") {
                    break
                }
            }
        }
    },
    cleanPrecedingSuccessTasks: function(a) {
        var d = this.getStore().data.items;
        var c = 0;
        for (var b = 0; b < d.length; b++) {
            if (d[b].data.status == "SUCCESS") {
                if (!this.removeOneTask(d[b])) {
                    break
                }
                d = this.getStore().data.items;
                b--;
                c++;
                if (c >= a) {
                    return true
                }
            }
        }
        return false
    },
    getNBSuccessTasks: function() {
        var c = this.getStore().data.items;
        var a = 0;
        for (var b = 0; b < c.length; b++) {
            if (c[b].data.status == "SUCCESS") {
                a++
            }
        }
        return a
    },
    cleanAllSuccessTasks: function() {
        var b = this.getStore().data.items;
        for (var a = 0; a < b.length; a++) {
            if (b[a].data.status == "SUCCESS") {
                if (!this.removeOneTask(b[a])) {
                    break
                }
                b = this.getStore().data.items;
                a--
            }
        }
    },
    onSelect: function(a, b) {
        if (_S("standalone") && this.ownerCt && this.ownerCt.ownerCt && Ext.isFunction(this.ownerCt.ownerCt.activeTabPanel)) {
            this.ownerCt.ownerCt.activeTabPanel(this.tabId)
        }
        this.getStore().add(new this.taskRec({
            id: a.id,
            icon: "file.png",
            event: a.event || "",
            name: a.name,
            rate: "",
            starttime: a.starttime || null,
            lefttime: "",
            progress: (a.progress === false) ? false : 0,
            status: a.status || "NOT_STARTED",
            statusText: _WFT("upload", "upload_task_waiting"),
            statusQtip: _WFT("upload", "upload_task_waiting"),
            cancelEvent: b || null,
            processed_num: a.processed_num,
            processed_size: a.processed_size,
            total: a.total,
            processing_path: a.processing_path
        }, a.id))
    },
    onOpen: function(b, a, c) {},
    onAllSelect: function(b, a) {},
    onAllComplete: function() {},
    onPause: function(a) {
        if (Ext.isEmpty(a) || Ext.isEmpty(a.id)) {
            return
        }
        var c = _WFT("common", "pause");
        var b = this.getStore().getById(a.id);
        this.progressInfoArray[a.id].update(b, "file.png", null, a.name, "", "", a.progress, a.status, c, c)
    },
    onResume: function(a) {
        if (Ext.isEmpty(a) || Ext.isEmpty(a.id)) {
            return
        }
        var c = _T("download", "download_task_downloading") + ": " + a.name;
        var b = this.getStore().getById(a.id);
        this.progressInfoArray[a.id].update(b, "file.png", null, a.name, "", "", a.progress, a.status, c, c)
    },
    onError: function() {},
    onFolderFail: function(c) {
        if (!this.progressInfoArray[c.id]) {
            return
        }
        var l, g = c.rootObj,
            k = g.errors,
            d = [],
            e = this.getStore().getById(c.id),
            a = Math.floor(g.uploadByte * 100 / g.totalByte),
            h, f;
        l = String.format(this.action_failed, g.name);
        for (h = 0; h < k.length; h++) {
            var b = false;
            for (f = 0; f < d.length; f++) {
                if (k[h].errStr === d[f]) {
                    b = true;
                    break
                }
            }
            if (!b) {
                d.push(k[h].errStr)
            }
        }
        l += d.join(" ");
        this.progressInfoArray[c.id].update(e, "failed.png", null, g.name, "", "", a, g.status, l, l)
    },
    onComplete: function(d) {
        if (d.rootObj && d.rootObj.errors) {
            this.onFolderFail(d);
            return
        }
        var f = _WFT("upload", "upload_task_completed");
        if (d.skipstatus) {
            var c = (Ext.isObject(d.skipstatus) && d.skipstatus.status) ? d.skipstatus.status : d.skipstatus;
            switch (c) {
                case "all":
                    f = _WFT("upload", "upload_task_skipped");
                    break;
                case "some":
                    f = _WFT("filetable", "filetable_skip_some");
                    break;
                default:
                    break
            }
        } else {
            if (Ext.isBoolean(d.isSkip)) {
                f = (d.isSkip && !d.isSubFile) ? _WFT("upload", "upload_task_skipped") : _WFT("upload", "upload_task_completed")
            } else {
                if (d && d.response && d.response.error && 414 === d.response.error.code) {
                    f = _WFT("upload", "upload_task_skipped")
                }
            }
        }
        var e = this.getStore().getById(d.id),
            a = (d.isSubFile || d.isSubFolder && d.rootObj) ? d.rootObj.name : e.data.name,
            b = (d.isSubFile || d.isSubFolder && d.rootObj) ? d.rootObj.status : d.status;
        if (this.progressInfoArray[d.id]) {
            this.progressInfoArray[d.id].update(e, "success.png", null, a, "", "", 100, b || "SUCCESS", f, f)
        }
    },
    onProgress: function() {},
    isProcessing: function() {
        var c = this.getStore().data.items,
            a;
        for (var b = 0; b < c.length; b++) {
            a = c[b].data.status;
            if (a === "NOT_STARTED" || a === "PROCESSING") {
                return true
            }
        }
        return false
    },
    startAvoidTimeout: function() {
        if (!this.PollTask || this.PollTask.removed) {
            this.PollTask = this.addWebAPITask({
                api: "SYNO.FileStation.Timeout",
                method: "avoid",
                version: 1,
                interval: _S("dsm_timeout") * 30000
            })
        }
        this.PollTask.start(false)
    },
    stopAvoidTimeout: function() {
        if (this.PollTask) {
            this.PollTask.stop()
        }
    },
    isRetina: function() {
        if (window.matchMedia) {
            var a = window.matchMedia("only screen and (min--moz-device-pixel-ratio: 1.3), only screen and (-o-min-device-pixel-ratio: 2.6/2), only screen and (-webkit-min-device-pixel-ratio: 1.3), only screen  and (min-device-pixel-ratio: 1.3), only screen and (min-resolution: 1.3dppx)");
            return (a && a.matches || (window.devicePixelRatio >= 1.3))
        }
        return false
    }
});
Ext.ns("SYNO.FileStation.MonitorQueue");
SYNO.FileStation.MonitorQueue.GridPanel = Ext.extend(SYNO.FileStation.MonitorGrid, {
    updateInterval: 30 * 1000,
    constructor: function(a, c) {
        this.updateDelay = 3000;
        this.updateTask = null;
        this.updateTaskArr = [];
        this.webfm = c;
        var b = {
            itemId: this.tabId,
            title: this.actionText,
            autoExpandColumn: "name",
            autoExpandMin: 160
        };
        Ext.apply(b, a || {});
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.constructor.call(this, b);
        this.updateTask = new Ext.util.DelayedTask(this.updateTaskFn, this);
        this.defineBehaviors()
    },
    defineBehaviors: function() {},
    getQueueSize: function() {
        return this.getStore().data.items.length
    },
    getAvailableTaskNumber: function(d) {
        var c = this.getNBSuccessTasks();
        var b = this.getQueueSize();
        var a;
        if (this.maxTasks < (d + b)) {
            if (0 < (a = (b - c + d - this.maxTasks))) {
                d -= a
            }
            this.cleanPrecedingSuccessTasks((d < c) ? d : c)
        }
        return d
    },
    updateMenuStatus: function(a) {
        if (false !== this.blRestart && a) {
            if (a.data.status == "FAIL") {
                this.gridCtxMenu.items.get("gc_restart").show()
            } else {
                this.gridCtxMenu.items.get("gc_restart").hide()
            }
        }
    },
    initColumnModel: function() {
        var a = new Ext.grid.ColumnModel([{
            dataIndex: "id",
            width: 43,
            align: "center",
            renderer: this.iconRenderer.createDelegate(this)
        }, {
            id: "name",
            header: _WFT("filetable", "filetable_file"),
            dataIndex: "name",
            renderer: this.nameRenderer
        }, {
            header: _WFT("upload", "upload_time_left"),
            dataIndex: "id",
            align: "left",
            width: 100,
            renderer: this.timeRenderer
        }, {
            header: _WFT("upload", "upload_rate"),
            dataIndex: "id",
            align: "left",
            width: 100,
            renderer: this.rateRenderer
        }, {
            header: _WFT("upload", "files_progress"),
            width: 310,
            dataIndex: "id",
            align: "left",
            renderer: this.progressRenderer.createDelegate(this)
        }, {
            header: _WFT("upload", "upload_list_status"),
            dataIndex: "id",
            align: "left",
            width: 210,
            renderer: this.statusRenderer
        }]);
        return a
    },
    getProgressStatusText: function(c, b) {
        var a = (c) ? c : b;
        var d = a;
        if (15 < a.length) {
            d = a.substring(0, 6) + "..." + a.substring(a.length - 10, a.length)
        }
        var e = this.actingText + ": ";
        return {
            text: e + d,
            qtipText: e + a
        }
    },
    onSelect: function(a, b) {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onSelect.call(this, a)
    },
    onAllSelect: function(b, a) {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onAllSelect.call(this, b, a);
        this.startAvoidTimeout()
    },
    onOpen: function(a) {
        if (!this.progressInfoArray[a.id]) {
            return
        }
        var b = this.actingText;
        var c = this.getStore().getById(a.id);
        this.progressInfoArray[a.id].update(c, "uploading.png", null, null, "", "", 0, a.status || "PROCESSING", b, b)
    },
    onProgress: function(b) {
        if (!this.progressInfoArray[b.id]) {
            return
        }
        var c = b.progress ? b.progress : ((b.bytesTotal === 0) ? 100 : b.bytesLoaded * 100 / b.bytesTotal);
        var d = String.format("{0}/s", b.rate ? Ext.util.Format.fileSize(b.rate) : "- B");
        var a = "";
        if (b.timeLeft > -1) {
            a = String.format("{0}", (b.timeLeft > 1) ? SYNO.webfm.utils.fancyDuration(b.timeLeft) : SYNO.webfm.utils.fancyDuration(1))
        }
        var e = this.getProgressStatusText(b.curname, b.name);
        var f = this.getStore().getById(b.id);
        this.progressInfoArray[b.id].update(f, null, null, b.name || null, a, d, c, b.status || "PROCESSING", e.text, e.qtipText)
    },
    onProgressWithTime: function(a) {
        if (!this.progressInfoArray[a.id]) {
            return
        }
        var c = this.getProgressStatusText(a.curname, a.name);
        var b = a.progress;
        var d = this.getStore().getById(a.id);
        this.progressInfoArray[a.id].updateWithRate(d, null, null, a.name || null, null, a.byteswrite, b, a.status || "PROCESSING", c.text, c.qtipText, a.taskInfo, a.bytestotal)
    },
    onCompleteRootFolder: function(a) {
        this.startUpdateTask(a)
    },
    onComplete: function(a) {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onComplete.call(this, a);
        this.startUpdateTask(a)
    },
    onAllComplete: function() {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onAllComplete.apply(this, arguments);
        this.stopAvoidTimeout()
    },
    onPause: function() {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onPause.apply(this, arguments)
    },
    onResume: function() {
        SYNO.FileStation.MonitorQueue.GridPanel.superclass.onResume.apply(this, arguments)
    },
    dirInTaskArr: function(c, b) {
        for (var a = 0; a < b.length; a++) {
            if (c == b[a].remotedir) {
                return true
            }
        }
        return false
    },
    getUpdateTask: function() {
        this.updateIntervalTask = this.updateIntervalTask || this.addTask({
            id: "file_upload_update_grid_task",
            interval: this.updateInterval,
            run: this.updateTaskFn,
            scope: this
        });
        return this.updateIntervalTask
    },
    startUpdateTask: function(a) {
        if (!this.dirInTaskArr(a.remotedir, this.updateTaskArr)) {
            this.updateTaskArr.push(a)
        }
        var b = this.getStore().data.last();
        if (a.id == b.data.id) {
            this.stopUpdateTask();
            this.getUpdateTask().stop();
            this.updateTaskFn()
        } else {
            this.updateTask.delay(this.updateDelay);
            if (!this.getUpdateTask().running) {
                this.getUpdateTask().start()
            }
        }
    },
    stopUpdateTask: function() {
        if (this.updateTask) {
            this.updateTask.cancel()
        }
    },
    updateTaskFn: Ext.emptyFn
});
Ext.ns("SYNO.FileStation.UploadGrid");
/**
 * @class SYNO.FileStation.UploadGrid.GridPanel
 * @extends SYNO.FileStation.MonitorQueue.GridPanel
 * FileTaskMonitor uploadgrid grid panel class
 *
 */
SYNO.FileStation.UploadGrid.GridPanel = Ext.extend(SYNO.FileStation.MonitorQueue.GridPanel, {
    constructor: function(b, c, a) {
        SYNO.FileStation.UploadGrid.GridPanel.superclass.constructor.apply(this, arguments)
    },
    defineBehaviors: Ext.emptyFn,
    onOpen: function(a) {
        if (!this.progressInfoArray[a.id]) {
            return
        }
        var c = new Date().getTime() / 1000;
        this.oldProgress = 0;
        var b = this.actingText;
        var d = this.getStore().getById(a.id);
        this.progressInfoArray[a.id].update(d, "uploading.png", null, d.get("name"), "", "", 0, a.status || "PROCESSING", b, b, c)
    },
    setFormUploader: function() {
        this.unHTML5Listener();
        this.unFlashListener();
        this.unJavaListener();
        this.onFormListener()
    },
    setFlashUploader: function() {
        this.unHTML5Listener();
        this.unFormListener();
        this.unJavaListener();
        this.onFlashListener()
    },
    setJavaUploader: function() {
        this.unHTML5Listener();
        this.unFormListener();
        this.unFlashListener();
        this.onJavaListener()
    },
    setHTML5Uploader: function() {
        this.unFormListener();
        this.unFlashListener();
        this.unJavaListener();
        this.onHTML5Listener()
    },
    onHTML5Listener: function() {
        if (SYNO.FileStation.HTMLUploaderTaskMgr) {
            this.mon(this, "cancel", SYNO.FileStation.HTMLUploaderTaskMgr.removeOneTask, SYNO.FileStation.HTMLUploaderTaskMgr);
            this.mon(this, "restart", SYNO.FileStation.HTMLUploaderTaskMgr.restartOneTask, SYNO.FileStation.HTMLUploaderTaskMgr)
        }
    },
    unHTML5Listener: function() {
        if (SYNO.FileStation.HTMLUploaderTaskMgr) {
            this.mun(this, "cancel", SYNO.FileStation.HTMLUploaderTaskMgr.removeOneTask, SYNO.FileStation.HTMLUploaderTaskMgr);
            this.mun(this, "restart", SYNO.FileStation.HTMLUploaderTaskMgr.restartOneTask, SYNO.FileStation.HTMLUploaderTaskMgr)
        }
    },
    onFormListener: function() {
        if (SYNO.FileStation.FormUploader) {
            this.mon(this, "cancel", SYNO.FileStation.FormUploader.cancelEvent)
        }
    },
    unFormListener: function() {
        if (SYNO.FileStation.FormUploader) {
            this.mun(this, "cancel", SYNO.FileStation.FormUploader.cancelEvent)
        }
    },
    JavaRemoveOneTask: function(a) {
        SYNO.FileStation.JavaUploader.removeOneTask(a, this.webfm)
    },
    JavaRestartOneTask: function(a) {
        SYNO.FileStation.JavaUploader.restartOneTask(a, this.webfm)
    },
    onJavaListener: function() {
        this.mon(this, "cancel", this.JavaRemoveOneTask, this);
        this.mon(this, "restart", this.JavaRestartOneTask, this)
    },
    unJavaListener: function() {
        this.mun(this, "cancel", this.JavaRemoveOneTask, this);
        this.mun(this, "restart", this.JavaRestartOneTask, this)
    },
    onFlashListener: function() {
        this.mon(this, "cancel", SYNO.FileStation.FlashUploader.removeOneTask);
        this.mon(this, "restart", SYNO.FileStation.FlashUploader.restartOneTask)
    },
    unFlashListener: function() {
        this.mun(this, "cancel", SYNO.FileStation.FlashUploader.removeOneTask);
        this.mun(this, "restart", SYNO.FileStation.FlashUploader.restartOneTask)
    }
});
