/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Drive.Store
 * @extends SYNO.API.Store
 * SynologyDrive API store class
 *
 */
Ext.define("SYNO.SDS.Drive.Store", {
        extend: "SYNO.API.Store",
        constructor: function() {
            SYNO.SDS.Drive.Store.superclass.constructor.apply(this, arguments)
        },
        sort: function() {
            this.sorting = !0, SYNO.SDS.Drive.Store.superclass.sort.apply(this, arguments)
        },
        loadRecords: function(e, t, i) {
            var n, s, o = this.sorting;
            if (this.sorting && (this.sorting = !1), !0 !== this.isDestroyed) {
                if (!e || !1 === i) return !1 !== i && this.fireEvent("load", this, [], t), void(t.callback && t.callback.call(t.scope || this, [], t, !1, e));
                var r, a = e.records,
                    l = e.totalRecords || a.length,
                    d = !1,
                    h = !1;
                if (t.add || o || l !== this.totalLength) d = !0;
                else {
                    for (n = 0, s = a.length; n < s; ++n) {
                        r = a[n];
                        var c = this.data.items[n];
                        if (!c) {
                            d = !0;
                            break
                        }
                        var u, p, S, f = c.data;
                        if (c.id !== r.id) {
                            d = !0;
                            break
                        }
                        h = !1;
                        for (S in f) f.hasOwnProperty(S) && (p = c.data[S], u = r.data[S], SYNO.ux.Utils.checkObjectConsistency(u, p) || (h = !0, c.data[S] = u));
                        h && c.commit()
                    }
                    t.callback && t.callback.call(t.scope || this, a, t, !0)
                }
                var m = SYNO.SDS.Drive.GetWindow().getEventMgr();
                d ? (t.add || m.fireEvent("enableviewmask"), SYNO.SDS.Drive.Store.superclass.loadRecords.apply(this, arguments)) : (m.fireEvent("disableviewmask"), this.fireEvent("load", this, a, t))
            }
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Base", {
        extend: "SYNO.SDS.Drive.Store",
        pageSize: 1e3,
        constructor: function(e) {
            this.appWindow = e.appWindow;
            var t = this.getAPIInfo(),
                i = {
                    autoLoad: !1,
                    proxy: new SYNO.API.Proxy({
                        api: t.api,
                        method: t.method,
                        version: t.version,
                        timeout: 3e5,
                        listeners: {
                            scope: this,
                            beforeload: function(e, t) {
                                var i = e.activeRequest.read;
                                i && Ext.Ajax.abort(i)
                            }
                        }
                    }),
                    remoteSort: !0,
                    reader: this.getReader(),
                    sortInfo: this.getSortInfo(),
                    baseParams: this.getBaseParams(),
                    listeners: {
                        scope: this,
                        beforeload: this.onBeforeNodeLoad,
                        load: this.onLoadStore,
                        exception: this.onExceptionStore
                    }
                };
            Ext.apply(i, e || {}), this.callParent([i])
        },
        convertOwner: function(e, t) {
            var i = Ext.isObject(t.owner) ? t.owner.display_name : "";
            return "#" === i.charAt(0) && (i = SYNO.SDS.Drive._T("common", "deleted_user")), i
        },
        convertExt: function(e, t) {
            return SYNO.SDS.Drive.Utils.getNtype(t.name, t.type)
        },
        convertLabels: function(e, t) {
            var i = [];
            return Ext.each(t.labels, function(e) {
                e.color = e.color.substr(1), i.push(e)
            }), i
        },
        onBeforeNodeLoad: function(e, t) {
            if (SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile && !window.getDriveFile()) return !1;
            var i = this.getLoadParam(t);
            if (!1 === i) return e.removeAll(), this.appWindow.getEventMgr().fireEvent("storeloaddone", e, []), !1;
            SYNO.SDS.Drive.Utils.apply(t.params, i), this.parseSortInfo(t), this.getFilter && this.getFilter() ? t.params.filter = this.getFilter() : delete t.params.filter;
            var n = this.appWindow.getEventMgr().fireEvent("storebeforeload", e, t);
            return this.parseSortInfo(t), n && (this.loading = !0), n
        },
        parseSortInfo: function(e) {
            if (e && e.params && e.params.sort_direction && (e.params.sort_direction = e.params.sort_direction.toLowerCase()), e && e.params && e.params.sort_by) switch (e.params.sort_by) {
                case "mtime":
                    e.params.sort_by = "modified_time";
                    break;
                case "owner_name":
                    e.params.sort_by = "owner"
            }
        },
        onLoadStore: function(e, t, i) {
            this.sorting = !1, this.loading = !1, i && i.add || this.appWindow.getEventMgr().fireEvent("storeloaddone", e, t, i)
        },
        onExceptionStore: function(e, t, i, n, s, o) {
            this.sorting = !1, this.loading = !1, n && n.add || this.appWindow.getEventMgr().fireEvent("storeloadfail", s)
        },
        getAPIInfo: Ext.emptyFn,
        getReader: Ext.emptyFn,
        getSortInfo: Ext.emptyFn,
        getBaseParams: function() {
            return {}
        },
        getLoadParam: function(e) {
            return {}
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Node", {
        extend: "SYNO.SDS.Drive.ViewStore.Base",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_files
        },
        getReaderFields: function() {
            return [{
                name: "file_id"
            }, {
                name: "parent_id"
            }, {
                name: "sync_id"
            }, {
                name: "name"
            }, {
                name: "path"
            }, {
                name: "display_path"
            }, {
                name: "mtime",
                mapping: "modified_time"
            }, {
                name: "ctime",
                mapping: "created_time"
            }, {
                name: "atime",
                mapping: "access_time"
            }, {
                name: "owner"
            }, {
                name: "labels",
                convert: this.convertLabels
            }, {
                name: "starred"
            }, {
                name: "hash"
            }, {
                name: "type"
            }, {
                name: "removed"
            }, {
                name: "starred"
            }, {
                name: "shared"
            }, {
                name: "permanent_link"
            }, {
                name: "size"
            }, {
                name: "hash"
            }, {
                name: "capabilities"
            }, {
                name: "shared_with"
            }, {
                name: "adv_shared"
            }, {
                name: "version_id"
            }, {
                name: "ntype",
                mapping: "name",
                convert: this.convertExt
            }, {
                name: "owner_name",
                convert: this.convertOwner
            }, {
                name: "encrypted"
            }, {
                name: "revisions"
            }, {
                name: "original_path"
            }, {
                name: "support_remote"
            }]
        },
        getReader: function() {
            return new Ext.data.JsonReader({
                root: "items",
                id: "file_id",
                fields: this.getReaderFields()
            })
        },
        getBaseParams: function() {
            return Ext.apply({
                path: SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile ? SYNO.SDS.Drive.Utils.getPathId(window.getDriveFile().file_id) : "/mydrive",
                offset: 0,
                limit: this.pageSize
            }, {
                filter: this.getFilter() || {}
            })
        },
        getLoadParam: function(e) {
            var t, i = this.appWindow.getNavigation(),
                n = {};
            return t = i.isRootPath() && SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile ? window.getDriveFile().file_id : i.getLastPathId(), i.isRootPath() || SYNO.SDS.Drive.Utils.apply(n, {
                path: SYNO.SDS.Drive.Utils.getPathId(t)
            }), n
        },
        setFilter: function(e) {
            this.filter = e
        },
        getFilter: function() {
            return this.filter
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.SharedWithMe", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_shared_with_me
        },
        getBaseParams: function() {
            return this.getFilter() ? {
                filter: this.getFilter()
            } : {}
        },
        getReaderFields: function() {
            var e = SYNO.SDS.Drive.ViewStore.SharedWithMe.superclass.getReaderFields.call(this);
            return e.push({
                name: "sync_to_device"
            }), e
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.SharingToOther", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_shared_with_others
        },
        getBaseParams: function() {
            return this.getFilter() ? {
                filter: this.getFilter()
            } : {}
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Backup", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_backup_tasks
        },
        getBaseParams: function() {
            return this.getFilter() ? {
                filter: this.getFilter()
            } : {}
        },
        getSortInfo: function() {
            return {
                field: "atime",
                direction: "ASC"
            }
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Recent", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_recent
        },
        getBaseParams: function() {
            return this.getFilter() ? {
                filter: this.getFilter()
            } : {}
        },
        getSortInfo: function() {
            return {
                field: "atime",
                direction: "ASC"
            }
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Search", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        infinite: !0,
        first_limit: 25,
        onBeforeNodeLoad: function() {
            this.resetLoadMore(), this.callParent(arguments), this.on("load", function(e, t, i) {
                i.params.content_snippet || this.loadSnippet(i.params)
            }, this, {
                single: !0
            })
        },
        getLimit: function() {
            return "tile" === SYNO.SDS.Drive.GetWindow().getViewModeMgr().getViewMode() ? 300 : this.first_limit
        },
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.search_files
        },
        getSortInfo: function() {
            return {
                field: "score",
                direction: "asc"
            }
        },
        getBaseParams: function() {
            return {
                content_snippet: !1
            }
        },
        getReaderFields: function() {
            var e = this.callParent(arguments);
            return e.push({
                name: "score"
            }, {
                name: "content_snippet"
            }), e
        },
        getLoadParam: function(e) {
            if (this.prevParams) return this.prevParams = SYNO.SDS.Drive.Utils.copyTo(this.prevParams, e.params, "sort_by,sort_direction"), e.params = this.prevParams, e.params.content_snippet = !1, e.params.limit = Math.max(this.getLimit(), this.getCount()), void(e.params.offset = 0);
            var t = {},
                i = e.params;
            this.fillSearchKeyword(i, t), this.fillSearchLabels(i, t), this.fillSearchDate(i, t), this.fillSearchType(i, t), this.fillSearchLocation(i, t), this.fillSearchOwner(i, t), this.fillSearchSize(i, t), this.fillSortField(i, t), t.limit = this.first_limit, t.offset = 0, t.content_snippet = !1, e.params = t, this.prevParams = t
        },
        cleanParams: function() {
            this.prevParams = null, this.resetLoadMore()
        },
        resetLoadMore: function() {
            this.reachEnd = !1, this.loadingMore = !1, this.loadMoreAjax && this.loadMoreAjax.conn && (this.loadMoreAjax.conn.abort(), this.loadMoreAjax = null), this.loadSnippetAjax && this.loadSnippetAjax.conn && (this.loadSnippetAjax.conn.abort(), this.loadSnippetAjax = null)
        },
        removeLeadingWildCard: function(e) {
            var t = [];
            return Ext.each(e.split(" "), function(e) {
                (e = e.replace(/^\*+/, "")) && t.push(e)
            }), t.join(" ")
        },
        removeColon: function(e) {
            return e.replace(":", " ")
        },
        fillSearchKeyword: function(e, t) {
            e.query && Ext.isString(e.query) && (t.keyword = this.removeLeadingWildCard(this.removeColon(e.query)))
        },
        fillSearchLabels: function(e, t) {
            e.tag && Ext.isArray(e.tag) && 0 !== e.tag.length && (t.labels = e.tag.map(function(e) {
                return e.label_id
            }))
        },
        fillSearchDate: function(e, t) {
            var i = e.datetype,
                n = e.searchdatefrom,
                s = e.searchdateto,
                o = e.searchdatefromformat,
                r = e.searchdatetoformat;
            "any" !== i && (n || s) && (n = n ? Date.parseDate(n + " 00:00:00", o + " H:i:s").getTime() / 1e3 : 0, s = s ? Date.parseDate(s + " 23:59:59", r + " H:i:s").getTime() / 1e3 : 2147483647, t.start_date = n, t.end_date = s, t.time = i)
        },
        fillSearchType: function(e, t) {
            if (e.ntype && "any" !== e.ntype) switch (e.ntype) {
                case "extension":
                    e.custom_file_type && (t.file_type = "custom", t.custom_file_type = e.custom_file_type);
                    break;
                default:
                    t.file_type = e.ntype
            }
        },
        fillSearchLocation: function(e, t) {
            if (e.parent_id) {
                var i = e.parent_id.split(":")[1];
                return t.location = "custom", void(t.custom_location = SYNO.SDS.Drive.Utils.getPathId(i))
            }
            if (e.location && "any" !== e.location) return void(t.location = e.location)
        },
        fillSearchOwner: function(e, t) {
            e.owner && "any" !== e.owner && (t.owner = e.owner, "custom" === e.owner && (t.custom_owner = {
                type: "user",
                name: e.custom_owner
            }))
        },
        fillSearchSize: function(e, t) {
            if (e.size && e.custom_size && !(e.custom_size < 0 || 1024 * e.custom_size * 1024 > SYNO.SDS.Drive.Define.MAX_INT_VALUE)) {
                var i = 1024 * e.custom_size * 1024;
                switch (e.size) {
                    case "greater":
                        t.min_size = i;
                        break;
                    case "equal":
                        0 === i ? (t.min_size = 0, t.max_size = 1) : (t.min_size = Math.max(parseInt(.95 * i), 0), t.max_size = Math.min(parseInt(1.05 * i), SYNO.SDS.Drive.Define.MAX_INT_VALUE));
                        break;
                    case "less":
                        t.max_size = i
                }
            }
        },
        fillSortField: function(e, t) {
            t.sort_by = this.sortInfo.field, t.sort_direction = this.sortInfo.direction.toLowerCase()
        },
        isloadMore: function() {
            return !(this.reachEnd || this.loadingMore || !this.prevParams || this.first_limit > this.getCount())
        },
        loadMore: function(e, t, i) {
            if (this.isloadMore()) {
                var n = this.prevParams;
                n.offset = this.getCount(), n.limit = this.getLimit(), n.content_snippet = !1, this.loadingMore = !0;
                var s = SYNO.SDS.Drive.GetWindow();
                this.loadMoreAjax = s.sendWebAPI(Ext.apply({
                    params: n,
                    timeout: 3e5,
                    callback: function(o, r, a) {
                        if (this.loadingMore = !1, !this.isDestroyed && "search" === s.getNavigation().getCategory()) {
                            if (!o) return void(this.reachEnd = !0);
                            if (this.prevParams) {
                                var l = a.content_snippet,
                                    d = SYNO.Util.copy(this.prevParams);
                                if (delete d.content_snippet, delete a.content_snippet, d.toString() === a.toString()) {
                                    var h = this.reader.readRecords(r);
                                    e && e.call(i), this.loadRecords(h, {
                                        add: !0
                                    }, !0), a.limit > h.totalRecords && (this.reachEnd = !0), t && t.call(i), l || this.loadSnippet(n)
                                }
                            }
                        }
                    },
                    scope: this
                }, this.getAPIInfo()))
            }
        },
        loadSnippet: function(e) {
            var t = SYNO.SDS.Drive.GetWindow();
            this.isDestroyed || "search" !== t.getNavigation().getCategory() || 0 === this.getCount() || (this.loadSnippetAjax = t.sendWebAPI(Ext.apply({
                params: Ext.apply(e, {
                    content_snippet: !0
                }),
                timeout: 3e5,
                callback: function(e, i, n) {
                    if (!this.isDestroyed && "search" === t.getNavigation().getCategory() && e) {
                        var s = this.reader.readRecords(i),
                            o = SYNO.SDS.Drive.GetWindow().getViewModeMgr().getViewMode(),
                            r = "snippet" === o;
                        Ext.each(s.records, function(e) {
                            var t = this.getById(e.id);
                            t && (r ? t.set("content_snippet", e.data.content_snippet) : t.data.content_snippet = e.data.content_snippet)
                        }, this)
                    }
                },
                scope: this
            }, this.getAPIInfo())))
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Tag", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_label_files
        },
        getBaseParams: function() {
            var e = {
                offset: 0,
                limit: this.pageSize
            };
            return this.getFilter() && (e = Ext.apply({
                filter: this.getFilter()
            })), e
        },
        getLoadParam: function(e) {
            var t = this.appWindow.getNavigation(),
                i = {};
            return SYNO.SDS.Drive.Utils.apply(i, {
                label_id: t.getCategory()
            }), i
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.TeamFolder", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_team_folders
        },
        getReaderFields: function() {
            var e = this.callParent(arguments);
            return e.push({
                name: "team_id"
            }), e
        },
        getBaseParams: function() {
            return this.getFilter() ? {
                filter: this.getFilter()
            } : {}
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Recycle", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_trash
        },
        getBaseParams: function() {
            return {}
        },
        getLoadParam: function(e) {
            var t = "node",
                i = {},
                n = this.appWindow.getNavigation();
            if (_S("is_admin")) {
                var s = n.getLastPath(),
                    o = this.appWindow.getDrivePanel().getRecycleBtn();
                if (!(t = o.getCheckedId()) && !s.display_path) return !1;
                if (s.display_path) {
                    var r = s.display_path.split("/");
                    "mydrive" !== r[2] && o.setCheckedName(r[3])
                }
            }
            if (!n.isRootPath()) return SYNO.SDS.Drive.Utils.apply(i, {
                path: SYNO.SDS.Drive.Utils.getPathId(n.getLastPathId())
            }), i;
            switch (t) {
                case "node":
                    SYNO.SDS.Drive.Utils.apply(i, {
                        path: "/mydrive"
                    });
                    break;
                default:
                    SYNO.SDS.Drive.Utils.apply(i, {
                        path: SYNO.SDS.Drive.Utils.getPathId(t)
                    })
            }
            return i
        }
    }), Ext.define("SYNO.SDS.Drive.ViewStore.Starred", {
        extend: "SYNO.SDS.Drive.ViewStore.Node",
        getAPIInfo: function() {
            return SYNO.SDS.Drive.WebAPIDesc.list_star_files
        },
        getBaseParams: function() {
            var e = {
                offset: 0,
                limit: this.pageSize
            };
            return this.getFilter() && (e = Ext.apply({
                filter: this.getFilter()
            })), e
        }
    }), Ext.define("SYNO.SDS.Drive.FileSystem.File", {
        constructor: function() {
            this.abortFlag = !1
        },
        abort: function() {
            this.abortFlag = !0
        },
        isAbort: function() {
            return this.abortFlag
        },
        write: function(e, t) {
            return Promise.reject()
        },
        fsync: function() {
            return Promise.reject()
        },
        toURL: function() {
            return ""
        },
        toBlob: function() {}
    }), Ext.define("SYNO.SDS.Drive.FileSystem.Utils", {
        singleton: !0,
        getEmptyBuffer: function() {
            return this.emptyBuffer ? this.emptyBuffer : (this.emptyBuffer = new Uint8Array(this.getEmptyBufferSize()), this.emptyBuffer)
        },
        getEmptyBufferSize: function() {
            return 1048576
        }
    }), Ext.define("SYNO.SDS.Drive.FileSystem.WriteEvent", {
        constructor: function(e, t, i, n, s) {
            this.offset = e, this.data = t, this.length = i, this.successCallbacks = n, this.failCallbacks = s, this.retryQuota = 3
        },
        notify: function(e) {
            var t = e ? this.successCallbacks : this.failCallbacks;
            Ext.each(t, function(e) {
                e()
            })
        }
    }), Ext.define("SYNO.SDS.Drive.FileSystem.PersistentFile", {
        extend: "SYNO.SDS.Drive.FileSystem.File",
        constructor: function(e) {
            this.callParent(arguments), this.file = e, this.writeEvents = [], this.isFlushing = !1, this.flushingObservers = []
        },
        write: function(e, t) {
            return this.isAbort() ? Promise.reject() : new Promise(function(i, n) {
                this.writeEvents.push(new SYNO.SDS.Drive.FileSystem.WriteEvent(e, [t], t.length, [i], [n]))
            }.bind(this))
        },
        fsync: function() {
            return this.isAbort() ? Promise.reject() : this.isFlushing ? new Promise(function(e, t) {
                this.flushingObservers.push({
                    resolve: e,
                    reject: t
                })
            }.bind(this)) : (this.isFlushing = !0, new Promise(function(e, t) {
                this.flushingObservers.push({
                    resolve: e,
                    reject: t
                }), this._flushToDisk()
            }.bind(this)))
        },
        toURL: function() {
            return this.isAbort() ? "" : this.file.fileEntry.toURL()
        },
        _fillEmpty: function(e, t, i, n) {
            for (var s = SYNO.SDS.Drive.FileSystem.Utils, o = t - e, r = s.getEmptyBuffer(), a = []; o >= r.length;) a.push(new SYNO.SDS.Drive.FileSystem.WriteEvent(t - o, [r], r.length, [i], [n])), o -= r.length;
            o > 0 && a.push(new SYNO.SDS.Drive.FileSystem.WriteEvent(t - o, [new Uint8Array(o)], o, [i], [n])), this.writeEvents = a.concat(this.writeEvents)
        },
        _flushToDisk: function() {
            if (!this.isAbort()) try {
                if (0 === this.writeEvents.length) return this.isFlushing = !1, void this._notifyAll(!0);
                var e = this.writeEvents[0];
                if (this.file.fileWriter.seek(e.offset), this.file.fileWriter.position < e.offset) return this._fillEmpty(this.file.fileWriter.position, e.offset, Ext.emptyFn, Ext.emptyFn), void this._flushToDisk();
                e = this._mergeWriteEvent(), this.file.fileWriter.write(new Blob(e.data)), this.file.fileWriter.onwriteend = function(t) {
                    this.writeEvents.shift(), e.notify(!0), this._flushToDisk()
                }.bind(this), this.file.fileWriter.onerror = function(t) {
                    e.retryQuota > 0 ? e.retryQuota = e.retryQuota - 1 : (this.isFlushing = !1, e.notify(!1), this._notifyAll(!1)), this._flushToDisk()
                }.bind(this)
            } catch (e) {
                this._notifyAll(!1)
            }
        },
        _mergeWriteEvent: function() {
            for (var e = this.writeEvents[0], t = 1, i = e.length, n = e.offset + e.length; t < this.writeEvents.length && t < 1024 && !(this.writeEvents[t].offset !== n || i + this.writeEvents[t].length > 10485760); t++) n += this.writeEvents[t].length, i += this.writeEvents[t].length;
            if (1 === t) return e;
            for (var s = e.offset, o = [], r = [], a = [], l = 0, d = 0; d < t; d++) o = o.concat(this.writeEvents[0].data), l += this.writeEvents[0].length, r = r.concat(this.writeEvents[0].successCallbacks), a = a.concat(this.writeEvents[0].failCallbacks), this.writeEvents.shift();
            var h = new SYNO.SDS.Drive.FileSystem.WriteEvent(s, o, l, r, a);
            return this.writeEvents.unshift(h), h
        },
        _notifyAll: function(e) {
            if (!this.isAbort()) {
                var t = this.flushingObservers.slice();
                this.flushingObservers = [], t.forEach(function(t) {
                    e ? t.resolve() : t.reject()
                })
            }
        }
    }), Ext.define("SYNO.SDS.Drive.FileSystem.FileManger", {
        singleton: !0,
        constructor: function() {
            this.fileSystem = void 0, this.driveFolder = void 0, this.askQuota = 107374182400, this.realQuota = 0, this.dirName = "drive"
        },
        isSupportFileSystemAPI: function() {
            return Ext.isFunction(window.webkitRequestFileSystem)
        },
        openFile: function(e, t, i) {
            var n = this;
            return new Promise(function(s, o) {
                n._initialize().then(function() {
                    return n._getQuotaInfo()
                }).then(function(e) {
                    if (e.grantedBytes - e.usedBytes <= t) return void o()
                }).then(function() {
                    var t = n.driveFolder.name + "/" + e;
                    return new Promise(function(e, s) {
                        n.fileSystem.root.getFile(t, {
                            create: i
                        }, function(t) {
                            e(t)
                        }, s)
                    })
                }).then(function(e) {
                    e.createWriter(function(t) {
                        var i = {
                                fileEntry: e,
                                fileWriter: t
                            },
                            n = new SYNO.SDS.Drive.FileSystem.PersistentFile(i);
                        s(n)
                    })
                }).catch(o)
            })
        },
        checkFileExist: function(e) {
            return new Promise(function(t, i) {
                this._initialize().then(function() {
                    var i = this.driveFolder.name + "/" + e;
                    this.fileSystem.root.getFile(i, {
                        create: !1
                    }, function(e) {
                        t(!0)
                    }, function() {
                        t(!1)
                    })
                }.bind(this)).catch(i)
            }.bind(this))
        },
        cleanupFileSystem: function(e) {
            return this._initialize().then(function() {
                this.driveFolder.createReader().readEntries(function(t) {
                    for (var i = 0; i < t.length; i++) {
                        var n = t[i];
                        n.isDirectory || e && -1 !== e.indexOf(n.name) || n.remove(Ext.emptyFn)
                    }
                })
            }.bind(this))
        },
        _initialize: function() {
            return void 0 !== this.fileSystem && void 0 !== this.driveFolder ? Promise.resolve() : this._initializeFileSystem().then(function() {
                return this._initializeDriveFolder()
            }.bind(this))
        },
        _initializeFileSystem: function() {
            return new Promise(function(e, t) {
                navigator.webkitPersistentStorage.requestQuota(this.askQuota, function(i) {
                    if (!i || 0 === i) return void t();
                    this.realQuota = i, window.webkitRequestFileSystem(window.PERSISTENT, this.realQuota, function(t) {
                        this.fileSystem = t, e(this.fileSystem)
                    }.bind(this), t)
                }.bind(this), t)
            }.bind(this))
        },
        _initializeDriveFolder: function() {
            return new Promise(function(e, t) {
                this.fileSystem.root.getDirectory(this.dirName, {
                    create: !0
                }, function(t) {
                    this.driveFolder = t, e(this.driveFolder)
                }.bind(this), function(e) {
                    t(e)
                })
            }.bind(this))
        },
        _getQuotaInfo: function() {
            return new Promise(function(e, t) {
                navigator.webkitPersistentStorage.queryUsageAndQuota(function(t, i) {
                    e({
                        usedBytes: t,
                        grantedBytes: i
                    })
                }, t)
            })
        },
        _deleteDriveFolder: function() {
            this._initialize().then(function() {
                this.driveFolder.removeRecursively(function() {
                    this.driveFolder = void 0
                }.bind(this), Ext.emptyFn)
            })
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.TaskDispatcher", {
        constructor: function(e) {
            this.appWindow = e.appWindow, this.offloadDownloader = e.offloadDownloader, this.currentRunningTask = void 0, this.waitingQueue = [], SYNO.SDS.Drive.FileSystem.FileManger.isSupportFileSystemAPI() && window.addEventListener("unload", this._suspendTask.bind(this)), SYNO.SDS.StatusNotifier.on("beforeunload", function() {
                return !this.currentRunningTask
            }.bind(this))
        },
        startTask: function(e) {
            this.currentRunningTask && SYNO.SDS.Drive.Utils.showToastMsg(this.appWindow, SYNO.SDS.Drive._T("task", "download_from_remote_queue"), 3e3), this.waitingQueue.push({
                task: e
            }), this._dispatchTask()
        },
        stopTask: function(e) {
            if (e.abort(), this.currentRunningTask === e) this.currentRunningTask = void 0, this._dispatchTask();
            else
                for (var t = 0; t < this.waitingQueue.length; t++)
                    if (this.waitingQueue[t].task === e) {
                        this.waitingQueue.splice(t, 1);
                        break
                    }
        },
        fallBackTask: function(e) {
            window.setTimeout(function() {
                this.offloadDownloader.download({
                    data: e.fileInfo.file
                }, !0)
            }.bind(this), 1e3), this.stopTask(e)
        },
        finishTask: function(e) {
            this.stopTask(e)
        },
        _dispatchTask: function() {
            if (!this.currentRunningTask && 0 !== this.waitingQueue.length) {
                var e = this.waitingQueue.shift().task;
                this.currentRunningTask = e, e.type === SYNO.SDS.Drive.HybridShare.DownloadTask.FILE_SYSTEM ? this._cleanFileSystem().then(e.start.bind(e)).catch(e.start.bind(e)) : e.start()
            }
        },
        _cleanFileSystem: function() {
            if (SYNO.SDS.Drive.FileSystem.FileManger.isSupportFileSystemAPI()) {
                for (var e = SYNO.SDS.Drive.HybridShare.FileInfo.fetchFileInfos(), t = 0; t < e.needRemoveList.length; t++) {
                    e.needRemoveList[t].delete()
                }
                for (var i = e.skippedList.concat(e.resumableList), n = [], s = 0; s < i.length; s++) n.push(i[s].tmpFileName);
                return SYNO.SDS.Drive.FileSystem.FileManger.cleanupFileSystem(n)
            }
            return Promise.resolve()
        },
        _suspendTask: function() {
            this.currentRunningTask && this.currentRunningTask.suspend()
        }
    }), Ext.define("SYNO.SDS.Drive.Define", {
        singleton: !0,
        TIME_FORMAT: "H:i",
        TIME_SEC_FORMAT: "H:i:s",
        DATE_FORMAT: "Y-m-d",
        TITLE_MAX_LENGTH: 256,
        TAG_MAX_LENGTH: 100,
        MAX_INT_VALUE: 0x7ffffffffffffc00,
        TagColor: ["DCE1E6", "FFCCCC", "FFD9B2", "FFEC8C", "DDF29D", "C4F5D4", "C2F2F2", "C8EDFA", "CCE6FF", "E2D9FF", "FFD9F2", "FFC0D2", "A0A5AA", "FA8282", "FA9C3E", "F2CA00", "94BF13", "4DBF73", "1DBFBF", "24BFF2", "499DF2", "A18AE6", "E67EC3", "F56496", "64696E", "E04343", "E67300", "CCAA00", "739900", "009933", "009999", "008FBF", "1470CC", "7052CC", "CC3D9C", "C81466"],
        TagTextColor: {
            DCE1E6: "50555A",
            FFCCCC: "C73232",
            FFD9B2: "BF6000",
            FFEC8C: "997F00",
            DDF29D: "567300",
            C4F5D4: "007326",
            C2F2F2: "007373",
            C8EDFA: "007399",
            CCE6FF: "0059B3",
            E2D9FF: "5536B3",
            FFD9F2: "B32483",
            FFC0D2: "A12A62",
            A0A5AA: "FFF",
            FA8282: "FFF",
            FA9C3E: "FFF",
            F2CA00: "FFF",
            "94BF13": "FFF",
            "4DBF73": "FFF",
            "1DBFBF": "FFF",
            "24BFF2": "FFF",
            "499DF2": "FFF",
            A18AE6: "FFF",
            E67EC3: "FFF",
            F56496: "FFF",
            "64696E": "FFF",
            E04343: "FFF",
            E67300: "FFF",
            CCAA00: "FFF",
            739900: "FFF",
            "009933": "FFF",
            "009999": "FFF",
            "008FBF": "FFF",
            "1470CC": "FFF",
            "7052CC": "FFF",
            CC3D9C: "FFF",
            C81466: "FFF"
        },
        ColorSelf: "#499DF2",
        AnonymousUID: 4294967295
    }), SYNO.SDS.Drive.Define.Info = {
        drive_id: "/mydrive"
    }, Ext.define("SYNO.SDS.Drive.ToastBox", {
        extend: "SYNO.SDS.ToastBox",
        constructor: function(e) {
            this.callParent(arguments), this.textActionId = e.textActionId
        },
        bindEvents: function() {
            this.callParent(arguments), this.textActionEl = Ext.get(this.textActionId), this.textActionEl && (this.textActionEl.on("click", this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this), this.textActionEl.addKeyListener(Ext.EventObject.ENTER, this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this), this.textActionEl.addKeyListener(Ext.EventObject.SPACE, this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this))
        },
        unbindEvents: function() {
            this.callParent(arguments), this.textActionEl && this.textActionEl.un("click", this.actionHandler.createSequence(this.destroyBox), this.actionHandlerScope || this)
        }
    }), Ext.define("SYNO.SDS.Drive.EventMgr", {
        extend: "Ext.util.Observable",
        constructor: function(e) {
            this.appWindow = e.appWindow, this.listeners = e.listeners, this.callParent([e])
        }
    }),
    function() {
        var e = ["3fr", "arw", "bmp", "cr2", "crw", "dcr", "dng", "erf", "gif", "jpe", "jpeg", "jpg", "k25", "kdc", "mef", "mos", "mrw", "nef", "orf", "pef", "png", "ptx", "raf", "raw", "rw2", "sr2", "srf", "tif", "tiff", "x3f", "heic", "heif"],
            t = {
                acc: ["acc", "accdb", "accde", "accdr", "accdt", "ade", "adn", "adp", "mam", "maf", "maq", "mar", "mat", "mda", "mdb", "mde", "mdf", "mdn", "mdt", "mdw"],
                image: e.concat(["ufo", "ico"]),
                audio: ["aac", "ac3", "aif", "ape", "cda", "dts", "flac", "m4a", "m4b", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "pcm", "ra", "wav", "wma", "mp1", "mpa", "ram", "m4p", "aiff", "dsf", "dff", "m3u", "wpl"],
                video: ["3g2", "3gp", "amr", "asf", "avi", "dat", "divx", "dvr-ms", "ifo", "m1v", "m2t", "m2ts", "m2v", "m4v", "mkv", "mov", "mpe", "mpeg", "mpeg1", "mpeg2", "mpeg4", "mpg", "mp4", "mts", "ogv", "qt", "rm", "rmvb", "tp", "trp", "ts", "vob", "webm", "wmv", "xvid", "vdr"],
                doc: ["doc", "docx", "rtf", "wri", "odt"],
                ppt: ["ppt", "pps", "ppsx", "pptx", "odp"],
                xls: ["xls", "xla", "xlam", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlsb", "xlsm", "xlsx", "xlt", "xltm", "xlv", "xlw", "xltx", "ods", "ots", "csv"],
                ai: ["ai"],
                psd: ["psd"],
                fla: ["fla"],
                pdf: ["pdf"],
                swf: ["swf", "f4v", "flv"],
                idn: ["idn", "indd"],
                txt: ["diff", "erl", "json", "lst", "markdown", "md", "mdown", "mkdn", "out", "patch", "sml", "txt"],
                htm: ["htm", "html"],
                code: ["actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "as3", "bat", "bkpi", "c", "cc", "cmake", "coffee", "cpp", "cs", "css", "cxx", "erb", "groovy", "gvy", "h", "haml", "hh", "hpp", "hxx", "java", "js", "jsx", "less", "m", "make", "mhtml", "ml", "mm", "php", "pl", "plist", "properties", "py", "rb", "sass", "scala", "scm", "script", "scss", "sh", "sql", "swift", "tsx", "vb", "vi", "vim", "xhtml", "xml", "xsd", "xsl", "yaml", "yml"],
                ttf: ["ttf", "otf", "ttc"],
                iso: ["iso", "bin", "daa", "img", "mds", "nrg"],
                zip: ["zip", "7z", "bz2", "gz", "rar", "tar", "tbz", "tgz", "txz"],
                exe: ["exe"],
                folder: ["folder", "dir"],
                synodoc: ["odoc"],
                synosheet: ["osheet"],
                synoslide: ["oslides"]
            },
            i = {
                image: e,
                video: [t.video].concat(t.swf).concat(["iso"])
            },
            n = Object.keys(t).reduce(function(e, i) {
                return t[i].forEach(function(t) {
                    e[t] = i
                }), e
            }, {}),
            s = {
                acc: "BUklEQVRIx82W0UvCUBTG9ycGQk8RgY/RvxBFECLSo2apQYEpRYQ9Rj2kPRQ9RW89RCkpznCR3tna+LrntongYrtzlzrwweGcs/vjfoexaQA0lRonJ+dXBhckleXS/OQHgEyYo0+cXjQIklMCoKhdXnuQvBJA/e5eWOVCdmIHtPW38T5cSCFWAMXD45MvJDaAdxOya2InpVgBk2FZX3DPCgY4vR6s2xuMzmowK2Wwg30hyqlGPUfXp54LBRhk0ugn5kKJZuUB6VR4AJ+VBgiL2q+wGnWY1QrYXhHD7awQ5VSjHs1EsoiVCrBbrcCl2i/PYMVdeYB3fSO5hI+1VQy3MmD5nBDlVKOeNycNcDodbsMhBqlNvK8sw1hcQH8+IUQ51ahnHh/B6XYjWMSvbTebwRbxmdkt2lj/Wa77HlBOtf9t0SzxZ4Ao3+TfZEwBlP9VqNI3GIeI1nh7X5MAAAAASUVORK5CYII=",
                ai: "BhElEQVRIx2P4//8/Awi/z2HAimHyODAjAXmEAUDDPgDxf1LwzyMzthCyBNmC/6TiX5c3//9xaNpmfJZQZMHP00uglkzF6ROKLPi+qRJsAdiSg5OxWkKRBR8bVf//urQRYcn+CVvRLaHIAhD+PMUN1ZJ9/Sg+odgCsE+a1P5/31zz/+eZ5RBL9vbCfUIVC7Bh6vgglxGCKbHg8yRHePh+7rNGyOWxADPaTCCehdUSoi34tq3h/4/Ty/7/PLf6/9eNlSgWfAda8J0SCz6U8gNTyIb/H5ak/f+4uvD/rwtr/38o4oLLP8lgBGImXEFI2ILP073AQfO6Svb/6yZdSDBNdkYpKkCYbAu+7+78//Psyv9fFsf//7w4Aeybb9uaqWPBh0oxoIGb4IbAMSjIgEFHsQWf54SANT9v0Pr/KI0BjF9PhgTZ5xk+lFvw/cAksA/eFHDCxd5USIAN/L67m3ILnqRDXP0OSextNkQMJAfiw3xGdiRTiOlvwQcqGv4BwwJaYZpbAAAF2ugy/92YbgAAAABJRU5ErkJggg==",
                audio: "A30lEQVRIx+2VuwrCMBhGs/gK6ivp6osoOPcxfBBRvC5eJquWeoFWKVSxIl5AK1Wrw2fUSQxFmrSLDgdCAucMf0gIABIkJLQAqY9aFAiixQpAJP9AcIFoQ0NCmUEy1shvbKjHM38gNZgjt9hBPpywvNw+4A5YDKnQAEsq7x3kzLW4QG1rQ9ItJDs64lUFpNgFKfXFBSKlHhVScUUFqQ3fzoQEWPuxpsYfYEmy0xXM85VvyF6SiePy3yIvSXo8h3Fyn2To2lfAU1Kmwy7ILx5rXzP4QvJ7r6nIL7Md/qcfFHf121Iu/iFqpQAAAABJRU5ErkJggg==",
                bkpi: "A/klEQVRIx93WywqCQBQGYJ/KaGuP0xv0HtH9FSKqneRCbedKghYFQZsgC+xGZuDJk5dER3JsZtOBHwYc5tMzIyoAgMAz8WAoq7YfoEzTj0AKCQCaujsPGM10RFpcAKyxMo+QNhdAM8x3q0KkyxzYWcd4P0KkxxTAWqw2aaTPFIieBNuV2JMBFaDtAeqGB5ISBMe6RZ7ruk8I1yoGdNYeVGVy8BqpCgN4l8kFG2YWwacrDWArkosdHMgAOKc0UFO+AziHGbC9Bcjy9IGkX4B0i8TJBcTxGSrTK5sW4QbmnSAmm8z9mEalEl400p2XBmjrf4Ey3+S82BmA+18Fr7wAhy2eUXVZMc0AAAAASUVORK5CYII=",
                code: "BKElEQVRIx2P4//8/Ay0xA90smLBk3RUg/k8lfAWbBf+piYepBdQCI9CCj7/+/U888B7OTz74/v8noBhVLDjx8ud/tZUv/7POeQoXA7FBYiA5si34/ff//6Zzn/6zz336X3PVy//HkQw7+uLnfw2gGEiuBajmzz8yLLDd9Brs0uLjH/9/+40ZHF+BYkXHP4DVgNSSbAHz7Kf/J1/5QjBCQWpAakm2wGDtq/8cc5/9bzjz6f+vv5g+AImB5EDBZAhUS7IFP4ABW3biIzgIjNe9+n/57S+43EUgG2QoSK785EewWrJT0f5nP/4rLHvxnxPoGxgAsRWXv/h/AChHlXzw/uff/9H73sH5sfvf/f8AFBuBRcWPX78oNhxkBi4LDlOxPjhC/0qfVhgAzyWF1blxPEQAAAAASUVORK5CYII=",
                doc: "AnklEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/CcFfP/x8/+GvUdAlkyniQUgsGnfUZglM2liweEzl8BBBbVkFtUteP76LTw+oJbMoaoFIHDl9n2sllDNAphPQMGFFCfzqGoBMvj16/d/qFm4LWCe/RQnJgYQtIBSMPAW4AsiYoJvNIhGg2g0iHBbQE6djAt/wLCA5q0KWmEAI9iiz+r986QAAAAASUVORK5CYII=",
                exe: "ASElEQVRIx2P4//8/Ay0xA90smLBk3Wkg/k8lfBibBf+piYepBdQCoxaMWjBqwagFI9uCH79+UWw4yAxcFhymYn1whP6VPq0wAHHUt1t6550TAAAAAElFTkSuQmCC",
                fla: "A/ElEQVRIx9XUuw4BQRSA4fV+6xZP4bK16EQnKomCWkRBw7pF5359ik1ENKwga7c5GIbBsuTsSBR/M5PMlzOZjAAAwqmVz2Ma3X+Rw2JfEBhAPQbfpDcbFSuEBeDbjOkE9o26/A5BAXq7dUFqLydBAVouSwCC1KqmCApYh/xgjEc3pCJXHxEUcGoTi94jcvluEjRAJpECoOVzoHc7Z6Rcuk5iC2AWagJ6HWiAHsT2n4DiEq99CtB/7CNgl0qSNpEwH4C2zaT5APR65h4nH+Dpk+v3yPpaCvIBlok4GMMBaMUCDmBfDtvC6wLFLcLMLeIAZL8HVBsPV58AXnEHDkK1OEqiHNphAAAAAElFTkSuQmCC",
                folder: "AYUlEQVRIx+3VIQ6AQAxE0bkl16tHIJpwgeVQKD4G2U02pGuaFV82z00FaGYqBJiE6cDEQDem7buJ6wDPIACm/Q9AQmcMeBoA3gMyC4CGi6RaBJDaAhawgKJA5hZdFX/ypF5TQR6NzVt+vQAAAABJRU5ErkJggg==",
                htm: "BsElEQVRIx8WWy0sCURTG/U9a9G7fLloURFQWBEGvZbu2QYtWbdu06YEStQlsk/Sy0FDLR0oUmAghFiZYRi8synzV170dxweOpBeHDnzMzL2X8zvnnnNnRgVApaSyN/pDW5QJFWqJSSUnOQAqsc94AltmB4csKwLgtmNxShCNIgD7mfd3qzIQbdUBkcfnbD0ykJWqArj5AkFZSNUAUiZ8u/Jqslo2IPkFrN8A3cdAnQFoYBp0ABshIPUtsz6ZQsbX34CHODluOQBqdoFmdq3dA7bDQA9bPuIC3lPFkLIAaRZd1xFQbyDnnVZAew2Y7nOZTZ6ThAB6FmVjxjkX35Z8e00CwycUgCcqAJg4BcZcOcCMt9DJ3CXQaqK5KY8AoI89LgQoykV2XQsCH2mae0kA835gyCmfXdkZaK4AYwQYd5OjATvgfyOYlBnXqEuwBh1WasVZX2EtYiwTXYgKz8c2w4Jd1M8inr4AEqxjmvZJ7iea52NtZqDdIthF0jnotZF4txhZi97F2Fv0ls6H2k7dJAzIP8lqWy4Lvk26Eie5YoCI/RtA5JtcStEigOJ/FUrpB2a8nVctAXG6AAAAAElFTkSuQmCC",
                idn: "BO0lEQVRIx73UzUsCQRjH8e3/TMGgS926RaeOWUJJRHSK8CD0QpAdKpSg0t5wNwNLyjoYlVA05vvs4efMyixa68o2sx2+sMvAfHiWh9UAaDwyFnVMnA9oZMi5pvUAhAUvtY9vE8OQXgBeM41ntFO5PTdECqCZe4EMnEQKaG6lLcBCkjeOiBTwPb0Bqj/ZSOvI2P+JSAG8WmS3HznU+yaRBsQkzZ0M6EWhixxk7UmUAE4pW1OeFOB2iS9AbW6brecZqrNx9QC/XLybetEVEP8xTwDbc9BsEeWZdbxNrakHTLbvjaSBj9AiPkNL6gF69YBW+g5kfBmViVX1QHXzpPvfOc2DnhfUA+XJFdQTl6DXj6jEUtY00kBpNGzFn7/Yd38NLqAUCOM9GMFLYN4++zMg0f8DROHl5BfgV74DHSGXs0o2HJE+AAAAAElFTkSuQmCC",
                image: "A80lEQVRIx2P4//8/Ay0xA90sWLf70GEg/k8lfBibBf+pBaBmjVpAqQVfX/7/uzsDjEFsqlvwd0/W/9+TeMEYxKa+BfvyEBbszaVBEH17AzQ4B4xBbLpF8s8/X/8vOJf9f+G5nP+//nyjvgV77kz/333YC4z33Z1JuQV33p74P+VEBJh+/vnW/54jPnALQOyXn++Qb8HD9xf+9x8NABs24Wjg/zlnUuGGw/Di8wX///37S7oFr77c+z/peCiGgdjwuWebSbPg/fen/6eeiCTKcBAGOeTzz7fEWzDvbAbRhsPw5usdo6Up5RZQs8o8Qv9Kn1YYALSDrkzwu1WwAAAAAElFTkSuQmCC",
                iso: "BZUlEQVRIx9WWPUsDQRCGDwQtVPCfGPDjZ/iFV+nvEUxjoVZqIagRIlY2xjLB2Brl9DyRC4oWikIak2p9ZxnCojt3u+AJFg93WWbnuezuzF2glAqKJPgzwcrusY1BEII98AA+QQdEPBZyzI+5LoJ5kACVQ8Kx+QK+DoBVh8TfKdNcM5ck0Mn3T+uqeRV7SzIFYIECK2cN9fz6rl7ePrTIU7IoCWizHimoeX2nkxOXSeoroBxDNsGSGVipNXTytcMT+n0LZsEoGOH7KEOybBNUheAbMAamwDZYBxM8JkmqNkEqBM+BEugZY10wDmaEOalN0BWCaUm2LOMbYFiY07MJOhmCzd8QxJ5LVPJdImmTI97QabDDTz6Zs8lHucfUIjGPKT15REeYjjIVpssx7ReaK637dr8gL1CcPP4kFVrAZe4sOKjVdXJqK8a/CJ2anSvnrdjsV2WXblpcuy78hVPoK/PfflV8AYFYH23XFM9oAAAAAElFTkSuQmCC",
                pdf: "BjklEQVRIx9XWzSsEYRwH8P1PlJQccFJycXBUkhAHe0HKwWmTvFxQmyIHWhZ5S+yWtiUlrVX2paW2hKXksOXiILVqXvaZeWa+Zqa12Xa0nllz8KtfTc9Tz2fm95t55nEAcNiZ+YtAKJLREozp0dJhlmYAWELMEgTDMR1ZsQXQ4/gi/oV4bQGiyTujVDlkrSxAOlyCHD0qGHt9e8/3I4dsWAb4wUYo6cei8dRz2hRhB4aaQPbmTOf0J9HL9a0nm8yAONFlIKVCkmTk1mIDyMEChJGWXzXfEiCf+8H31kDlPuwBhNE2A/ipD2UB9D5hLE6vz8B1VoLeXP4tIE47QbyTgKpAdA+A666CMNZuvLp8Xy2E4WZIAY81gKYS4DoqQLZmkF12gezPg+y6wfVUa4vXGSWjD1eQ4ycWAFU17pRszwIKLZzSmi2H/SDrU8iujkOOBNkA5eUJ0ukO+P4GqALHtEeVBGgybJSGd9aD3saYN8GSgORbhOBqhRzywUpY+g7+BWDln/xTZooA208VduUnLBO0P/hgGncAAAAASUVORK5CYII=",
                ppt: "A/klEQVRIx82WuwrCMBSG8wAqPpvP5aKCooiPIOoqOnjZnERQdHB0kEo3tZEec2Jbkppg2yTgDz+0IeQ7t9ASACAunTwMpwufGXK6zUxUVgEgj+6PJ4xmK4R0nABQk/k6hnSdAJabLS9VBOlZB1yuXtKPCNK3CkDtTmclxBogzgTLJfRkUAgQ3o7wGteANivaPUFAITpLD6B1Ipkf7h2AtqrSGoIQiGBRPwEq8chT0OSdgTEAIwBGqwUwYwCZAaoSKaHivkbJLANVFtYB6T5YL1Ho7aVJkpu8N88gHtfPXShz8zEVJsgYkEW5S5TV/5OBK0CRb7LO/hfA+V+FK78B8GN8HREMOxcAAAAASUVORK5CYII=",
                psd: "BwklEQVRIx2P4//8/AwgzdVzEimHyODAnAXkGBiQLvgDxf1Lwkivvbu65/5mfWAv+k4q33Pn4f8W197cOPPwsQBMLll19D7Zk1fX3t489+SpEdQuqDjwHWwDCa298uHPm+TcRqlqgPvPG/023P8ItWX/zw92Lr76LUc0CEHZbcRfFkg23Pt69+vq7BNUsgPmk4sCz/8uhcQLE94BmilHNAmyYqj4gywJYmEJTyP/OE6/+K02/Tn0LItbe/p+74wEwhXz8P/H0a7i84byb/4PWPfjvvvLef76+y+RbwNRyGohP/S/Z/QicWkBy3qvugeWWX333fyNQrO7Qc2y+INICIFtmyrX/sy+8+T8HiEH88n1PwXJ60y/8F+s+/V+05yz5FsDwxlsf/9stvAqW05t5GVQ8gMW7gHGjNuM6+RaErr71P3Dlzf8KE4CubIW6tO3cf8HOk+D4WXvzA9BnbykIopYzENx+AS5XtPfp/4LdT//7rbrzf/Hlt//nX3xDWRwgY5bOS/8j19/9P/Xsa3DKmnL61X/9GZdIt4Cp4RgEY0vnoJTVdPw/UyNQvukEOMhIt4ByTH8LvlLR8G8YFtAK09wCAMjp7vny80ipAAAAAElFTkSuQmCC",
                swf: "BK0lEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/CcFfP/x8/+GvUdAlkyniQUgsGnfUZglM2liweEzl8BBBbVkFtUteP76LTw+oJbMoaoFIHDl9n2sllDNAphPQMGFFCfzqGoBMvj16/d/qFnkW/B1/6b/zzO9/j/218IqT5EFXw9t+//IRx1s+MuScOpa8Pfr5/9PY63/Pw7S///z+jmc6si24POmRf8feav9fze9Ca868iz49+//83QPsAUw/O3UfupZ8P3CcRTDqW7Bq6p4sKE/Lp0kGJQkWfD347v/76bWgw1/VZtEVEoj2oJX9an/HwfogA1/lujw//eLx9S1AJQcX+QF/v+4bMr/v18+Ep0RKc7Jg9YCcupkXPgDhgU0b1XQCgMASxS7xEfmBGwAAAAASUVORK5CYII=",
                synodoc: "AZUlEQVRIx2P4//8/Ay0xnOHZ/ukwEP8nFVtm7ukH0gwwjM+C/+Rg89StKJbQxAJkS2hmAcwSmlqAzRKKLbDOPYzXEootwIVHLaDcAlLBaBCNBtFoEA0SCw5T0YIjGBbQvFVBKwwATH1zaSrH2OAAAAAASUVORK5CYII=",
                synosheet: "AbUlEQVRIx2P4//8/Ay0xnKG7vvYwEP8nFSt3JPYDaQYYxmfBf3KwUnMciiU0sQDZEppZALOEphZgs4RiC1R7U/FaQrEFuPCoBZRbQCogywJ8fEJyg8OC0SAa2CAazclUq5Nx4CMYFtC8VUErDAAnb+9US6gI2AAAAABJRU5ErkJggg==",
                synoslide: "AeklEQVRIx2P4//8/Ay0xnPFrOcNhIP5PKj7UxNAPpBlgGJ8F/8nBu2tRLaGJBciW0MwCmCU0tQCbJRRbcKodvyUUW4ALD7wF/14d/k8sAKkl2QJSAVkWkBAcoxYMVQtomopIygevjwzCnDwkLThMRQuOYFhA81YFrTAAsgBgVa11PRgAAAAASUVORK5CYII=",
                ttf: "A20lEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/CcFfP/x8/+GvUdAlkyniQUgsGnfUZglM2liweEzl8BBBbVkFtUteP76LTw+oJbMoaoFIHDl9n2sllDNAphPQMGFFCfzqGoBMvj16/d/qFnEWcDUcREvxgZIsoCl8+L/Tbc/olgGAhdfff8v2H+FcgsC1t7H8A0MRG16SLkF2IKLEBi1YIha8PnnX7gFH378oa4FObue/DdfeBtugdG8W/+Ttz2mfhARCwbMAnLqZFz4A4YFNG9V0AoDAEDutdS+0AUyAAAAAElFTkSuQmCC",
                txt: "Ao0lEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/IeBX6dP/ScEvv/4+X/D3iMgS6bTxAIQ2LTvKMySmTSx4PCZS+Cggloyi+oWPH/9Fh4fUEvmUNUCELhy+z5WS6hmAcwnoOBCipN5VLUAGfz69fs/1CzaWAACOC1oOPwCjBct3AVnk4NHfTDqg6Hsg1ELCFlATp2MC3/AsIDmrQpaYQDoZKjvCZXipQAAAABJRU5ErkJggg==",
                video: "BVElEQVRIx+1VQUsCQRj1/0aCUF36AV3SksxDl4pC1g5dOggZRa1gmFvawUXI3QlKI4ra1g55ec2bckNciHV3vdThwez3PeZ9+82bbxIAEnEiMTWBbLKuSyAi6H4CiBJ/SGAtZaC0ZaF1/oT7G1eBa8aYCyWwsdhAu/4MYTooFwSKaVOBa8aYI2ciAVbHDa71R+TnLsc2YIw5cnI+f/KrQGmzo6rMz39tfqQJNM+k2MLVj4jMiZajuIEF2Ge2Yvh9vGej7wzwcPuOYsb04oe7tuIGFujZfWhpc0yAcF8HqBzcqTg5XcmNVODt5QOn+8IToLMia1FPuNhZaiAzUw3XIvqcBzg85HLBgnHSRTZVxcpsbfSQJTewQO7bpk1pxXVpSVa8LLGavPBsSle1jQlt6nfR2G8tqos2Miq2LZg1OSo6rgLXjIUeFf/jOs4nszL9Rz8ufAKRCqBhtjRzkAAAAABJRU5ErkJggg==",
                xls: "An0lEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/CcFfP/x8/+GvUdAlkyniQUgsGnfUZglM2liweEzl8BBBbVkFtUteP76LTw+oJbMoaoFIHDl9n2sllDNAphPQMGFFCfzqGoBMvj16/d/qFm4LfBZH0AWhgGiLEAG6HxsYPBZMBpEo0E0yIOIUjBgFpBTJ+PCHzAsoHmrglYYAH1lbbVzIsaaAAAAAElFTkSuQmCC",
                xxx: "AjklEQVRIx2P4//8/Ay0xnLFu96EPQPyfRDwNiBmwYWwW/CcFfP/x8/+GvUdAlkyniQUgsGnfUZglM2liweEzl8BBBbVkFtUteP76LTw+oJbMoaoFIHDl9n2sllDNAphPQMGFFCfzqGoBMvj16/d/qFm0sQAERi0YtWDUglELKLCAnDoZF/6AYQHNWxW0wgCYa+spTTLHuQAAAABJRU5ErkJggg==",
                zip: "AgElEQVRIx2P4//8/Ay0xA90s2NQRoAvEL4H4Pzr++PQqVoxNLRC/AWIrbBbcxKGBVAtA+BY2CzAw0BAYxmUJWB6bXgwLzq8sOgzE/7FhXBbgUg8yC5sF/6lowf9RC0YtQMVPL2wG4k0YNNUsIAePWjBqwRC14DAVLThC/0qfVhgAzm2uYKFfmOkAAAAASUVORK5CYII="
            };
        Ext.define("SYNO.SDS.Drive.FileType", {
            statics: {
                SYNODOC: "odoc",
                SYNOSHEET: "osheet",
                SYNOSLIDE: "oslides",
                browser_display_image: ["image/gif", "image/jpeg", "image/pjpeg", "image/png", "image/bmp", "image/x-windows-bmp", "image/x-icon"],
                getMappingTypeCss: function(e, t) {
                    return String.format("syno-d-start-ntype {0}-s{1}", SYNO.SDS.Drive.FileType.getMappingType(e), t)
                },
                getMappingType: function(e) {
                    var t = n[e],
                        i = SYNO.SDS.Drive.GetWindow().getNavigation && SYNO.SDS.Drive.GetWindow().getNavigation();
                    return i && "folder" === t && "backup" === i.getCategory() && 1 === i.getPath().length && (t = "computer"), t || "xxx"
                },
                getIcon: function(e) {
                    return String.format("{0}.png", SYNO.SDS.Drive.FileType.getMappingType(e))
                },
                getBaseURL: function(e) {
                    var t = SYNO.SDS.UIFeatures.test("isRetina");
                    return e = e || 16, String.format("webman/3rdparty/SynologyDrive-Drive/images/_Asset/FileType/{0}", t ? 2 * e : e)
                },
                hasThumbnail: function(e) {
                    return -1 !== i.image.indexOf(e) || -1 !== i.video.indexOf(e)
                },
                getFileTypeIcon: function(e, t) {
                    var i = SYNO.SDS.Drive.FileType.getBaseURL(t),
                        n = SYNO.SDS.Drive.FileType.getIcon(e),
                        s = SYNO.SDS.Drive.Utils.getPackageVersion();
                    return String.format("{0}/{1}?version={2}", i, n, s)
                },
                getDefaultIcon: function() {
                    return "scripts/ext-3/resources/images/default/s.gif"
                },
                isImageMime: function(e) {
                    return -1 !== SYNO.SDS.Drive.FileType.browser_display_image.indexOf(e)
                },
                getBase64Img: function(e, t) {
                    return "iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAA" + ("dir" === e ? s.folder : s[SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(t))])
                }
            }
        })
    }(), Array.prototype.fill || Object.defineProperty(Array.prototype, "fill", {
        value: function(e) {
            if (null == this) throw new TypeError("this is null or not defined");
            for (var t = Object(this), i = t.length >>> 0, n = arguments[1], s = n >> 0, o = s < 0 ? Math.max(i + s, 0) : Math.min(s, i), r = arguments[2], a = void 0 === r ? i : r >> 0, l = a < 0 ? Math.max(i + a, 0) : Math.min(a, i); o < l;) t[o] = e, o++;
            return t
        }
    }), Ext.ns("SYNO.SDS.Drive"), window.SYNO.SDS.Drive._T = function(e, t) {
        try {
            return _TT("SYNO.SDS.Drive.Application", e, t) || _T(e, t) || e + ":" + t
        } catch (i) {
            return _T(e, t) || e + ":" + t
        }
    }, Ext.define("SYNO.SDS.Drive.Date", {
        statics: {
            DURATIONS: {
                days: 86400,
                hours: 3600,
                minutes: 60,
                seconds: 1
            },
            DURATION_ABBR: {
                days: SYNO.SDS.Drive._T("task", "time_day"),
                hours: SYNO.SDS.Drive._T("task", "time_hour"),
                minutes: SYNO.SDS.Drive._T("task", "time_min"),
                seconds: SYNO.SDS.Drive._T("task", "time_sec")
            },
            parseDuration: function(e) {
                var t, i = {},
                    n = SYNO.SDS.Drive.Date.DURATIONS;
                for (var s in n)
                    if (n.hasOwnProperty(s) && (t = Math.floor(e / n[s])) && (i[s] = Ext.isNumber(t) && t < Number.MAX_VALUE ? t : Number.MAX_VALUE, 0 >= (e -= t * n[s]))) break;
                return i
            },
            fancyDuration: function(e) {
                var t = [],
                    i = SYNO.SDS.Drive.Date.parseDuration(e);
                for (var n in i)
                    if (i.hasOwnProperty(n)) {
                        var s = i[n] > 9999 ? 9999 : i[n];
                        t.push(s + " " + SYNO.SDS.Drive.Date.DURATION_ABBR[n])
                    } return t.join(", ")
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Utils", {
        statics: {
            isDSM7OrAbove: function() {
                return _S("majorversion") >= 7
            },
            initErrorStr: function() {
                var e = SYNO.SDS.Drive._T;
                SYNO.SDS.Drive.ErrorString = {};
                var t = SYNO.SDS.Drive.ErrorString;
                t[401] = e("warning", "err_sys"), t[402] = e("warning", "err_admin_only"), t[403] = e("warning", "error_privilege_not_enough"), t[404] = e("warning", "err_get_download_link_fail"), t[405] = e("warning", "download_single_task"), t[406] = e("warning", "restore_single_task"), t[407] = e("warning", "delete_single_task"), t[408] = e("warning", "restore_conflict"), t[409] = e("warning", "restore_err_no_space"), t[500] = e("warning", "err_drive_disabled"), t[501] = e("warning", "err_drive_disabled"), t[502] = e("cstn", "drive_diskfull_desc"), t[503] = e("warning", "error_drive_repomove"), t[600] = e("warning", "not_enough_space"), t[601] = e("warning", "error_volume_not_found"), t[602] = e("warning", "error_volume_readonly"), t[603] = e("warning", "error_not_mounted"), t[604] = e("warning", "invalid_repo_path"), t[701] = e("warning", "user_key_conflict"), t[702] = e("warning", "invalid_user_key"), t[703] = e("warning", "no_such_user");
                var i = [e("error", "error_error_system"), e("error", "perm_op_fail"), e("error", "permission_not_enough"), e("error", "node_not_exist"), e("error", "not_in_recycle"), e("error", "dir_not_exist"), e("error", "tag_not_exist"), e("error", "tag_already_exist"), e("error", "dir_not_exist"), e("error", "move_to_child"), e("error", "copy_to_child"), e("error", "not_support"), e("error", "chat_no_such_user"), e("error", "chat_error"), e("error", "no_enough_space"), e("error", "space_not_enough"), e("error", "volume_quota_full"), e("error", "share_quota_full"), _S("is_admin") ? e("error", "volume_moving") : e("error", "maintenance"), _S("is_admin") ? e("error", "backuping") : e("error", "maintenance"), _S("is_admin") ? e("error", "backuping") : e("error", "maintenance"), e("error", "moving_data"), e("error", "filename_exist"), e("error", "autorename_max_limit"), e("error", "parent_path_conflict"), e("error", "file_type_conflict"), e("error", "office_install"), e("warning", "err_enable_homes"), e("warning", "no_such_user"), e("error", "no_such_group"), e("error", "chat_service_not_found"), e("error", "access_token_invalid"), e("error", "reserved_name"), e("error", "file_too_big"), e("error", "error_long_path"), e("error", "name_too_long"), e("error", "protection_shared_error"), e("error", "adv_share_password_error"), e("error", "adv_share_expired"), e("error", "view_user_disabled"), e("error", "public_sharing_disable"), e("error", "internal_sharing_disable"), e("error", "invite_sharing_disable"), e("error", "adv_sharing_need_password"), e("error", "adv_sharing_need_expire"), e("error", "request_access_disabled")],
                    n = [_T("common", "commfail"), e("error", "source_no_file"), e("error", "source_read_error")],
                    s = 0;
                for (s = 0; s < i.length; ++s) SYNO.SDS.Drive.ErrorString[1e3 + s] = i[s];
                for (s = 0; s < n.length; ++s) SYNO.SDS.Drive.ErrorString[1e4 + s] = n[s]
            },
            getErrorCode: function(e) {
                return Ext.isObject(e) ? e.code : e
            },
            getErrorStr: function(e) {
                var t = SYNO.SDS.Drive.Utils.getErrorCode(e);
                return Ext.isNumber(t) ? 102 === t ? SYNO.SDS.Drive._T("error", "drive_server_install") : t < 400 ? SYNO.API.Errors.common[t] || _T("error", "error_error") : t in SYNO.SDS.Drive.ErrorString ? SYNO.SDS.Drive.ErrorString[t] : SYNO.SDS.Office && t in SYNO.SDS.Office.ErrorString ? SYNO.SDS.Office.ErrorString[t] : t >= 57344 && t < 61439 ? SYNO.SDS.Drive._T("error", "office_install") : _T("error", "error_error") : Ext.isString(t) ? t : _T("error", "error_unknown")
            },
            showErrorMsg: function(e, t, i, n) {
                SYNO.SDS.Drive.Utils.showAlertMsg(e, SYNO.SDS.Drive.Utils.getErrorStr(t), i, n)
            },
            showAlertMsg: function(e, t, i, n) {
                var s = e.getMsgBox();
                Ext.isEmpty(s) || s.alert("", t, i, n)
            },
            showToastMsg: function(e, t, i, n, s) {
                this.getToastBox(t, n || !1, s, {
                    offsetX: 0,
                    offsetY: 10,
                    delay: i || 1500
                }, e).show()
            },
            getToastBox: function(e, t, i, n, s) {
                this.toastBox && !this.toastBox.isDestroyed && this.toastBox.destroy();
                var o = {
                    text: e,
                    closable: t,
                    owner: s
                };
                return Ext.isObject(i) && (Ext.isString(i.text) && (o.actionText = i.text), Ext.isFunction(i.fn) && (o.actionHandler = i.fn), Ext.isObject(i.scope) && (o.actionHandlerScope = i.scope), Ext.isString(i.textActionId) && (o.textActionId = i.textActionId)), Ext.isObject(n) && (Ext.isNumber(n.delay) && (o.delay = n.delay), Ext.isNumber(n.offsetY) && (o.offsetY = n.offsetY), Ext.isNumber(n.offsetX) && (o.offsetX = n.offsetX), Ext.isDefined(n.alignEl) && (o.alignEl = n.alignEl), o.alignBottom = !0 === n.alignBottom), this.toastBox = new SYNO.SDS.Drive.ToastBox(o), this.toastBox
            },
            getFormatDate: function(e) {
                return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
                    type: "date"
                }) : e.format(SYNO.SDS.Drive.Define.DATE_FORMAT)
            },
            getFormatDateTime: function(e) {
                return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
                    type: "datetimesec"
                }) : e.format(SYNO.SDS.Drive.Define.DATE_FORMAT + " " + SYNO.SDS.Drive.Define.TIME_SEC_FORMAT)
            },
            getFormatTime: function(e) {
                return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
                    type: "time"
                }) : e.format(SYNO.SDS.Drive.Define.TIME_FORMAT)
            },
            getDateFormat: function() {
                return SYNO.SDS.DateTimeUtils ? SYNO.SDS.DateTimeUtils.GetDateFormat() : SYNO.SDS.Drive.Define.DATE_FORMAT
            },
            getFormatTimeSec: function(e) {
                return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
                    type: "timesec"
                }) : e.format(SYNO.SDS.Drive.Define.TIME_SEC_FORMAT)
            },
            getPathId: function(e) {
                return Ext.isEmpty(e) && (e = SYNO.SDS.Drive.Define.Info.drive_id), "/" === e.charAt(0) ? e : String.format("id:{0}", e)
            },
            getPathIdByLink: function(e) {
                return String.format("link:{0}", e)
            },
            getAppURL: function() {
                var e, t = SYNO.SDS.Drive.WindowHelper.getBaseAppPath() + "/",
                    i = SYNO.SDS.Session.standaloneAppName;
                if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
                    var n = {
                            link: window.getDriveLink()
                        },
                        s = SYNO.SDS.Drive.Sharing.GetSharingLink();
                    s && (n.sharing_link = s), e = {
                        launchApp: i,
                        launchParam: Ext.urlEncode(n)
                    }
                } else -1 !== window.location.href.indexOf("launchApp") && (e = {
                    launchApp: i
                });
                return SYNO.SDS.JSDebug && (e = Ext.apply(e, {
                    jsDebug: SYNO.SDS.JSDebug
                })), Ext.urlAppend(t, Ext.urlEncode(e), !1) + window.location.hash || ""
            },
            openFileLink: function(e, t, i, n) {
                if (SYNO.SDS.Drive.Utils.isOfficeFile(e)) this.openOfficeLink(t, i, n);
                else {
                    var s = SYNO.SDS.Drive.Utils.getDriveLink(t);
                    SYNO.SDS.Drive.Utils.openURL(s, i, n)
                }
            },
            openOfficeLink: function(e, t, i) {
                var n;
                n = SYNO.SDS.Drive.WindowHelper.isAdvShare() ? SYNO.SDS.Drive.Sharing.GetURL(e, SYNO.SDS.Drive.Sharing.GetSharingLink()) : SYNO.SDS.Drive.Utils.getOfficeLink(e), SYNO.SDS.Drive.Utils.openURL(n, t, i)
            },
            openDriveLink: function(e, t, i) {
                var n = SYNO.SDS.Drive.Utils.getDriveLink(e);
                SYNO.SDS.Drive.Utils.openURL(n, t, i)
            },
            openByAnchor: function(e) {
                var t = document.createElement("a");
                return t.target = "_blank", t.rel = "noopener noreferrer", t.style.position = "absolute", t.style.top = "-9999px", t.style.left = "-9999px", t.href = e, document.body.appendChild(t), t.click(), document.body.removeChild(t), !0
            },
            openURL: function(e, t, i) {
                t && (e += "#" + t), !1 === i ? window.location.href = e : !1 === SYNO.SDS.Drive.Utils.openByAnchor(e) && window.open(e, "_blank")
            },
            getDriveLink: function(e) {
                var t = window.location.pathname.substr(0, window.location.pathname.lastIndexOf("/"));
                return t = t.replace("/d/f", ""), window.location.protocol + "//" + window.location.host + t + "/d/f/" + e
            },
            getOfficeLink: function(e) {
                var t = window.location.pathname.substr(0, window.location.pathname.lastIndexOf("/"));
                return t = t.replace("/d/f", ""), t = t.replace("/oo/r", ""), t = t.replace("/oo/sharing", ""), window.location.protocol + "//" + window.location.host + t + "/oo/r/" + e
            },
            isAppAuthorized: function() {
                return !1 !== _S("isLogined") && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Drive.Application")
            },
            isLogined: function() {
                return !1 !== _S("isLogined")
            },
            isAdvSharingPage: function() {
                return SYNO.SDS.Drive.Sharing && SYNO.SDS.Drive.Sharing.GetSharingLink()
            },
            getBaseName: function(e, t) {
                var i = t || "/";
                if (!Ext.isDefined(e)) return "";
                var n = "",
                    s = e.lastIndexOf(i);
                return -1 !== s && (n = e.substr(s + 1)), n
            },
            getExt: function(e) {
                var t = SYNO.SDS.Drive.Utils.getBaseName(e);
                e = t || e;
                var i = e.lastIndexOf(".");
                return -1 === i ? "" : e.substr(i + 1).toLowerCase()
            },
            getNtype: function(e, t) {
                return "dir" !== t && t ? this.getExt(e) : "dir"
            },
            getFileTypeMapping: function(e) {
                switch (e) {
                    case "dir":
                        return "dir";
                    case SYNO.SDS.Drive.FileType.SYNODOC:
                    case SYNO.SDS.Drive.FileType.SYNOSHEET:
                    case SYNO.SDS.Drive.FileType.SYNOSLIDE:
                        return "office";
                    default:
                        return "regular"
                }
            },
            getHashParam: function() {
                var e = location.hash.substr(1);
                return Ext.urlDecode(e)
            },
            isShared: function(e) {
                return !Ext.isEmpty(e)
            },
            hasUserShared: function(e, t) {
                var i = !1;
                return Ext.each(e, function(e) {
                    if ("user" === e.type && e.name.toLowerCase() === t.toLowerCase()) return i = !0, !1
                }), i
            },
            apply: function(e, t, i, n) {
                if (n = !1 !== n, i && Ext.apply(e, i), e && t && "object" == typeof t)
                    for (var s in t) t.hasOwnProperty(s) && (e[s] = n && Ext.isObject(e[s]) && Ext.isObject(t[s]) ? SYNO.SDS.Drive.Utils.apply(e[s], t[s]) : t[s]);
                return e
            },
            copyTo: function(e, t, i) {
                return "string" == typeof i && (i = i.split(/[,;\s]/)), Ext.each(i, function(i) {
                    t.hasOwnProperty(i) && Ext.isDefined(t[i]) && (e[i] && "object" == typeof t[i] ? SYNO.SDS.Drive.Utils.apply(e[i], t[i]) : e[i] = t[i])
                }), e
            },
            getAccount1stName: function(e) {
                e = e || "";
                var t = e.split("\\");
                return 1 < t.length ? t[1].charAt(0).toUpperCase() : e.charAt(0).toUpperCase()
            },
            updateAccountIcon: function(e, t, i) {
                var n = function(e) {
                    var n = !0;
                    2 > e.width && 2 > e.height && (n = !1), !0 === n ? (this.el.setStyle("background", "#FFF"), this.el.dom.lastChild.setAttribute("style", String.format("background-color: #FFF;background-image:url({0});", t))) : i ? (this.el.setStyle("background", i), this.el.dom.lastChild.removeAttribute("style")) : (this.el.dom.removeAttribute("style"), this.el.dom.lastChild.removeAttribute("style"))
                };
                SYNO.SDS.Drive.Utils.getImageLoader().load(t, {
                    load: function(t) {
                        this.rendered && this.el && this.el.dom ? n.call(e, t) : this.mon(this, "afterrender", function() {
                            n.call(e, t)
                        }, this, {
                            single: !0
                        })
                    }.bind(e)
                })
            },
            getImageLoader: function() {
                return SYNO.SDS.Drive.Utils.imageloader || (SYNO.SDS.Drive.Utils.imageloader = new SYNO.SDS.Drive.Utils.ImageLoad)
            },
            isEmpty: function(e) {
                if (!e) return !0;
                if (Ext.isObject(e)) {
                    for (var t in e)
                        if (e.hasOwnProperty(t)) return !1;
                    return !0
                }
                return Ext.isEmpty(e)
            },
            getParentIdFromResp: function(e) {
                var t;
                if (Ext.isArray(e.data)) {
                    t = [];
                    for (var i = e.data, n = 0; n < i.length; n++) t.push(i[n].parent_id)
                } else t = [e.parent_id];
                return t
            },
            getFileIdFromPathId: function(e) {
                if (!e) return "";
                var t = e.indexOf(":");
                return -1 === t ? e : e.substr(t + 1)
            },
            isCurrentPath: function(e, t) {
                for (var i = "root" === t, n = 0; n < e.length; n++)
                    if (i) {
                        if ("#00000000" === e[n].split("_", 2)[1]) return !0
                    } else if (e[n] === t) return !0;
                return !1
            },
            openOffice: function(e) {
                var t = SYNO.SDS.Drive.GetWindow();
                SYNO.SDS.Drive.Utils.hasOffice() ? SYNO.SDS.Drive.Utils.openOfficeLink(e) : SYNO.SDS.Drive.Define.Info.office_migration ? SYNO.SDS.Drive.Utils.showAlertMsg(t, SYNO.SDS.Drive._T("app", "migration_office")) : SYNO.SDS.Drive.Utils.showAlertMsg(t, SYNO.SDS.Drive._T("app", "install_office_alert"))
            },
            hasOffice: function() {
                return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Office.AppInstance")
            },
            doubleHtmlEncode: function(e) {
                return Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e))
            },
            getPackageVersion: function() {
                return SYNO.SDS.Config.FnMap["SYNO.SDS.Drive.Application"].config.version
            },
            getChannelName: function(e, t) {
                return 1 === e ? _TT("SYNO.SDS.Chat.Application", "channel", "name_general") || t : 2 === e ? _TT("SYNO.SDS.Chat.Application", "channel", "name_random") || t : t
            },
            stripExt: function(e) {
                var t = e.lastIndexOf(".");
                return -1 === t ? e : e.substr(0, t)
            },
            isOfficeFile: function(e) {
                return "office" === SYNO.SDS.Drive.Utils.getFileTypeMapping(SYNO.SDS.Drive.Utils.getExt(e))
            },
            isMsOfficeFile: function(e) {
                return ["doc", "ppt", "xls"].indexOf(SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(e))) >= 0
            },
            isImageFile: function(e) {
                return "image" === SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(e))
            },
            isMP4: function(e) {
                return "mp4" === SYNO.SDS.Drive.Utils.getExt(e)
            },
            isPDF: function(e) {
                return "pdf" === SYNO.SDS.Drive.Utils.getExt(e)
            },
            isPreviewable: function(e) {
                return this.isOfficeFile(e) || this.isImageFile(e) || SYNO.SDS.Drive.Utils.isAppAuthorized() && "pdf" === SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(e))
            },
            parseDisplayName: function(e) {
                return SYNO.SDS.Drive.Utils.isOfficeFile(e) ? SYNO.SDS.Drive.Utils.stripExt(e) : e
            },
            isDisplayPathUnderMyDrive: function(e) {
                var t = e.split("/");
                return 1 < t.length && "mydrive" === t[1]
            },
            parseDisplayPath: function(e, t) {
                var i = e,
                    n = e.split("/");
                if (1 < n.length) {
                    switch (n[1]) {
                        case "mydrive":
                            n[1] = SYNO.SDS.Drive._T("category", "node");
                            break;
                        case "team-folders":
                            n[1] = SYNO.SDS.Drive._T("category", "team_folder");
                            break;
                        case "shared-with-me":
                            n[1] = SYNO.SDS.Drive._T("category", "shared_with_me");
                            break;
                        case "recycle-bin":
                            switch (n[1] = SYNO.SDS.Drive._T("category", "recycle"), n[2]) {
                                case "mydrive":
                                    n[2] = SYNO.SDS.Drive._T("category", "node");
                                    break;
                                case "team-folders":
                                    n[2] = SYNO.SDS.Drive._T("category", "team_folder")
                            }
                            t && n.splice(1, 1)
                    }
                    var s = n[n.length - 1];
                    n[n.length - 1] = this.parseDisplayName(s), i = n.join("/")
                } else i = this.parseDisplayName(i);
                return i
            },
            isVisibleInDrive: function(e) {
                return "/" === e.charAt(0)
            },
            checkSharePrivilge: function(e, t) {
                if (!0 !== t) return !1;
                var i = SYNO.SDS.Drive.Define.Info || {},
                    n = SYNO.SDS.Drive.Utils.isDisplayPathUnderMyDrive(e.display_path || "");
                return !1 === i.disabled_all_sharing || (!(!e.adv_shared || !n) || !!(e.shared_with && e.shared_with.length > 0))
            },
            checkFileName: function(e) {
                switch (e) {
                    case ".":
                    case "..":
                        return !1;
                    default:
                        if (/[\/\\]/.test(e)) return !1
                }
                switch (e.toLowerCase()) {
                    case "@eaDir":
                    case "#recycle":
                    case "#snapshot":
                        return !1;
                    default:
                        return !0
                }
                return !0
            },
            onOpenMgr: function(e, t) {
                var i = new SYNO.SDS.WindowLauncher({
                        className: "SYNO.SDS.Drive.Application",
                        url: SYNO.SDS.Drive.WindowHelper.getStandaloneLaunchURL("SYNO.SDS.Drive.Application", e),
                        type: "standalone",
                        isOpenNewWindow: !0
                    }),
                    n = i.getLaunchURL();
                t && (n += "#" + Ext.urlEncode(t));
                var s = i.appConfig,
                    o = s.windowParam || "";
                return window.open(n, "SYNOSDSDriveApplication", o)
            },
            convertEpochTime: function(e, t) {
                var i, n, s = "";
                return Ext.isNumber(e) ? (i = new Date(e), n = new Date, i.format("Y-m-d") === n.format("Y-m-d") ? s += SYNO.SDS.Drive._T("date", "today") : i.getYear() === n.getYear() ? s += String.format(SYNO.SDS.Drive._T("date", "date_format"), SYNO.SDS.Drive._T("date", "mon_" + (i.getMonth() + 1)), i.getDate(), SYNO.SDS.Drive._T("date", "weekday_" + i.getDay())) : s += SYNO.SDS.Drive.Utils.getFormatDate(i), s += !1 !== t ? " " + SYNO.SDS.Drive.Utils.getFormatTimeSec(i) : " " + SYNO.SDS.Drive.Utils.getFormatTime(i)) : s
            },
            is1stSharedWithMe: function(e) {
                if (!e) return !1;
                var t = e.split("/", 4);
                return 3 === t.length && "shared-with-me" === t[1]
            },
            jsLoad: function() {
                SYNO.SDS.JSLoad("SYNO.SDS.Profile.Panel"), SYNO.SDS.JSLoad("SYNO.Personal.Mail.MailForm", function() {
                    Ext.getClassByName("SYNO.Personal.Mail.Config") && (SYNO.Personal.Mail.Config.btnStyle = "grey", SYNO.Personal.Mail.Config.emailWizardStyle = {})
                }), SYNO.SDS.JSLoad("SYNO.Personal.Mail.EmailAccountWizard", function() {
                    Ext.getClassByName("SYNO.Personal.Mail.EmailAccountWizard") && (SYNO.Personal.Mail.EmailAccountWizard.prototype.WIZRAD_HEIGHT = 480)
                })
            },
            getSupportedCodepage: function() {
                var e = SYNO.SDS.Utils.getSupportedLanguageCodepage();
                return e.push(["unicode", SYNO.SDS.Drive._T("common", "unicode")]), e
            },
            isConflictPath: function(e, t, i) {
                var n = "";
                if (t.length < e.length) {
                    var s = e.lastIndexOf("/");
                    return n = e.substring(s), t + n === e
                }
                if (t.length === e.length) return t === e;
                if (i) {
                    var o = t.substring(0, e.length);
                    return n = t.substring(e.length), o === e && "/" === n.charAt(0)
                }
                return !1
            },
            getDragItem: function(e, t, i) {
                if (t) {
                    if (e.length === t.length) return t[i];
                    var n, s = -1;
                    for (n = 0; n < t.length; ++n)
                        if ("file" === t[n].kind && (++s, i === s)) return t[n];
                    return t[i]
                }
            },
            isDriveAppWindow: function(e) {
                return Ext.getClassByName("SYNO.SDS.Drive.MainWindow") && e instanceof SYNO.SDS.Drive.MainWindow
            },
            isDrivePage: function() {
                var e = _S("standaloneAppName");
                return "SYNO.SDS.Drive.Application" === e || "SYNO.SDS.Drive.PublicApplication" === e
            },
            getHelpURL: function(e) {
                return SYNO.SDS.Drive.WindowHelper.getStandaloneLaunchURL("SYNO.SDS.HelpBrowser.Application", e ? {
                    launchParam: "topic=" + e
                } : null)
            },
            getAlignToXY: function(e, t, i, n) {
                if (!(t = Ext.get(t)) || !t.dom) throw "Element.alignToXY with an element that doesn't exist";
                n = n || [0, 0], i = (i && "?" !== i ? /-/.test(i) || "" === i ? i || "tl-bl" : "tl-" + i : "tl-bl?").toLowerCase();
                var s, o, r, a, l, d, h, c, u, p, S, f, m, g = Ext.lib.Dom.getViewWidth() - 10,
                    v = Ext.lib.Dom.getViewHeight() - 10,
                    D = document,
                    y = D.documentElement,
                    w = D.body,
                    _ = (y.scrollLeft || w.scrollLeft || 0) + 5,
                    x = (y.scrollTop || w.scrollTop || 0) + 5,
                    b = !1,
                    N = "",
                    O = "",
                    E = i.match(/^([a-z]+)-([a-z]+)(\?)?$/);
                if (!E) throw "Element.alignTo with an invalid alignment " + i;
                N = E[1], O = E[2], b = !!E[3], s = e.getAnchorXY(N, !0), o = t.getAnchorXY(O, !1), r = o[0] - s[0] + n[0], a = o[1] - s[1] + n[1];
                var T = {
                    left: !1,
                    right: !1,
                    top: !1,
                    bottom: !1
                };
                return b && (l = e.getWidth(), d = e.getHeight(), h = t.getRegion(), c = N.charAt(0), u = N.charAt(N.length - 1), p = O.charAt(0), S = O.charAt(O.length - 1), f = "t" === c && "b" === p || "b" === c && "t" === p, m = "r" === u && "l" === S || "l" === u && "r" === S, r + l > g + _ && (r = m ? h.left - l : g + _ - l, T.right = !0), r < _ && (r = m ? h.right : _, T.left = !0), a + d > v + x && (a = f ? h.top - d - n[1] : v + x - d - n[1], T.bottom = !0), a < x && (a = f ? h.bottom : x, T.top = !0)), {
                    xy: [r, a],
                    viewportReachBoundry: T
                }
            },
            prepareRequestParams: function(e) {
                return e.path || e.files ? e : (e.permanent_link ? (Ext.isArray(e.permanent_link) ? (e.files = [], Ext.each(e.permanent_link, function(t) {
                    e.files.push(SYNO.SDS.Drive.Utils.getPathIdByLink(t))
                })) : e.path = SYNO.SDS.Drive.Utils.getPathIdByLink(e.permanent_link), delete e.permanent_link) : e.file_id && (Ext.isArray(e.file_id) ? (e.files = [], Ext.each(e.file_id, function(t) {
                    e.files.push(SYNO.SDS.Drive.Utils.getPathId(t))
                })) : e.path = SYNO.SDS.Drive.Utils.getPathId(e.file_id), delete e.file_id), e)
            },
            isiOS: function() {
                return Ext.isBoolean(this.isiOS_) ? this.isiOS_ : this.isiOS_ = /(iPad|iPhone|iPod)/.test(navigator.platform) || "MacIntel" === navigator.platform && navigator.maxTouchPoints > 1
            },
            isAndroid: function() {
                return Ext.isBoolean(this.isAndroid_) ? this.isAndroid_ : this.isAndroid_ = /Android/i.test(navigator.userAgent)
            },
            isMobile: function() {
                return Ext.isBoolean(this.isMobile_) ? this.isMobile_ : this.isMobile_ = SYNO.SDS.Drive.Utils.isiOS() || SYNO.SDS.Drive.Utils.isAndroid() || /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g|nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0, 4))
            }
        }
    }), SYNO.SDS.Drive.Utils.ImageLoad = Ext.extend(Object, {
        list: [],
        intervalId: null,
        tick: function() {
            for (var e = 0; e < this.list.length; e++) this.list[e].end ? this.list.splice(e--, 1) : this.list[e]();
            this.list.length || this.stop()
        },
        stop: function() {
            clearInterval(this.intervalId), this.intervalId = null, this.clean()
        },
        clean: function() {
            for (var e = 0; e < this.list.length; e++) this.list[e].img && (this.list[e].img.onload = this.list[e].img.onerror = null);
            this.list = []
        },
        load: function(e, t) {
            var i = new Image;
            i.src = e, this.loadImg(i, t, !0)
        },
        loadImg: function(e, t) {
            this.loadfn(e, t, !1)
        },
        loadfn: function(e, t, i) {
            t = t || {};
            var n, s, o, r, a, l = t.beforeload,
                d = t.ready,
                h = t.load,
                c = t.error;
            if (e.complete) return Ext.isFunction(d) && d(e), void(Ext.isFunction(h) && h(e));
            s = e.width, o = e.height, e.onerror = function() {
                Ext.isFunction(c) && c(e), n.end = !0, e.onload = e.onerror = null, !1 !== i && (e = null)
            }, n = function() {
                r = e.width, a = e.height, (r !== s || a !== o || r * a > 1024) && (Ext.isFunction(d) && d(e), n.end = !0)
            }, n(), e.onload = function() {
                n.end || n(), Ext.isFunction(h) && h(e), e.onload = e.onerror = null, !1 !== i && (e = null)
            }, n.img = e, n.end || (this.list.push(n), null === this.intervalId && (this.intervalId = setInterval(this.tick.createDelegate(this), 100))), Ext.isFunction(l) && l(e)
        }
    }), SYNO.SDS.Drive.Utils.initErrorStr(), SYNO.SDS.Drive.GetWindow = function() {
        return SYNO.SDS.Drive.Window || (SYNO.SDS.Drive.Window = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window), SYNO.SDS.Drive.Window
    }, Ext.ns("SYNO.SDS.Drive.HybridShare.Status"), SYNO.SDS.Drive.HybridShare.Status.PROGESSING = 1, SYNO.SDS.Drive.HybridShare.Status.DONE = 2, SYNO.SDS.Drive.HybridShare.Status.ERROR = 3, Ext.define("SYNO.SDS.Drive.HybridShare.DownloadTask", {
        statics: {
            FILE_SYSTEM: 1,
            MEMORY: 2
        },
        constructor: function(e) {
            this.appWindow = e.appWindow, this.fileInfo = e.fileInfo, this.observers = [], this.isAbort = !1, this.placeholder = void 0, this.persistentDownloadProgress = !1
        },
        start: function() {
            this.isAbort || (this.fileInfo.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_NEW, this.persistentDownloadProgress), this.placeholder = this._createPlaceholder(this._callback.bind(this)), this.placeholder.fill())
        },
        suspend: function() {
            this.isAbort = !0, this.placeholder && this.placeholder.abort(), this.fileInfo.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_PAUSE, this.persistentDownloadProgress)
        },
        abort: function() {
            this.isAbort = !0, this.placeholder && this.placeholder.abort(), this.fileInfo.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DELETE, this.persistentDownloadProgress)
        },
        addObserver: function(e) {
            this.observers.push(e)
        },
        getProgress: function() {
            return this.placeholder.getProgress()
        },
        _createPlaceholder: function() {},
        _refreshChunkInfo: function() {
            var e = this.fileInfo;
            return new Promise(function(t, i) {
                SYNO.SDS.Drive.WebAPICore.sendPromise("download_files", {
                    files: [SYNO.SDS.Drive.Utils.getPathId(e.file.file_id)],
                    json_error: !0,
                    c2_offload: "force"
                }).then(function(n) {
                    return n && n.file && n.chunks && 0 !== n.chunks.length && n.file.hash === e.file.hash && SYNO.SDS.Drive.HybridShare.ChunkInfo.updateChunkInfosByWebapiResponse(e.chunkInfos, n.chunks) ? void t() : void i()
                }).catch(i)
            })
        },
        _callback: function(e, t) {
            this.isAbort || (e === SYNO.SDS.Drive.HybridShare.Status.PROGESSING ? (this.fileInfo.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DOWNLOADING, this.persistentDownloadProgress, this.placeholder.downloadChunkCount), this._notifyDownLoadProgress()) : e === SYNO.SDS.Drive.HybridShare.Status.DONE ? (this.fileInfo.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DOWNLOADED, this.persistentDownloadProgress), this.placeholder.triggerDownload().then(this._notifyDownLoadDone.bind(this)).catch(this._notifyDownLoadError.bind(this, !1))) : e === SYNO.SDS.Drive.HybridShare.Status.ERROR && this._notifyDownLoadError(t))
        },
        _notify: function(e) {
            this.observers.forEach(function(t) {
                t(this, e)
            })
        },
        _notifyDownLoadProgress: function() {
            this.isAbort || this._notify(SYNO.SDS.Drive.HybridShare.Status.PROGESSING)
        },
        _notifyDownLoadDone: function() {
            this.isAbort || this._notify(SYNO.SDS.Drive.HybridShare.Status.DONE)
        },
        _notifyDownLoadError: function(e) {
            if (!this.isAbort) return e ? void this._refreshChunkInfo().then(this.placeholder.resume.bind(this.placeholder)).catch(this._notify.bind(this, SYNO.SDS.Drive.HybridShare.Status.ERROR)) : void this._notify(SYNO.SDS.Drive.HybridShare.Status.ERROR)
        }
    }), Ext.ns("SYNO.SDS.Drive.Crypto"), Ext.define("SYNO.SDS.Drive.Crypto.Utils", {
        statics: {
            isCryptoSupport: function() {
                var e = window.crypto || window.msCrypto;
                return !!e && !!e.subtle
            },
            incrementNonce: function(e, t) {
                for (var i = new Uint8Array(e.slice(0)), n = i.length - 1; t > 0 && n >= i.length - 2; n--) {
                    var s = t + i[n];
                    i[n] = s % 256, t = Math.floor(s / 256)
                }
                return i.buffer
            },
            importAes256GcmKey: function(e) {
                return window.msCrypto ? new Promise(function(t, i) {
                    try {
                        var n = window.msCrypto.subtle.importKey("raw", e, {
                            name: "AES-GCM",
                            length: 256
                        }, !1, ["decrypt"]);
                        n.oncomplete = function(e) {
                            t(e.target.result)
                        }, n.onerror = function(e) {
                            i()
                        }
                    } catch (e) {
                        i()
                    }
                }) : window.crypto.subtle.importKey("raw", e, {
                    name: "AES-GCM",
                    length: 256
                }, !1, ["decrypt"])
            },
            _decryptAes256Gcm: function(e, t, i) {
                var n = {
                    name: "AES-GCM",
                    iv: i,
                    tagLength: 128
                };
                return window.msCrypto ? new Promise(function(i, s) {
                    try {
                        var o = e.subarray(e.length - 16);
                        n = Ext.apply(n, {
                            tag: o
                        });
                        var r = window.msCrypto.subtle.decrypt(n, t, e.subarray(0, e.length - 16));
                        r.oncomplete = function(e) {
                            i(e.target.result)
                        }, r.onerror = function(e) {
                            s()
                        }
                    } catch (e) {
                        s()
                    }
                }) : window.crypto.subtle.decrypt(n, t, e)
            },
            decryptAes256Gcm: function(e, t, i) {
                return new Promise(function(n, s) {
                    SYNO.SDS.Drive.Crypto.Utils._decryptAes256Gcm(e, t, i).then(function(e) {
                        n(e)
                    }).catch(function() {
                        s()
                    })
                })
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Crypto.HybridShareChunk", {
        DECRYPTED_MINI_CHUNK_MAX_LEN: 8192,
        ENCRYPTED_MINI_CHUNK_MAX_LEN: 8208,
        ABYTES: 16,
        constructor: function(e, t, i) {
            this.ciphertext = e, this.key = t, this.nonce = i, this.miniChunkCount = Math.ceil(e.length / parseFloat(this.ENCRYPTED_MINI_CHUNK_MAX_LEN)), this.processedCount = 0
        },
        getExpectDecryptedChunkSize: function() {
            if (this.ciphertext.length % this.ENCRYPTED_MINI_CHUNK_MAX_LEN == 0) return this.DECRYPTED_MINI_CHUNK_MAX_LEN * this.miniChunkCount;
            var e = this.ciphertext.length % this.ENCRYPTED_MINI_CHUNK_MAX_LEN - this.ABYTES;
            return e < 0 ? -1 : this.DECRYPTED_MINI_CHUNK_MAX_LEN * this.miniChunkCount + e
        },
        hasDecryptNext: function() {
            return this.processedCount < this.miniChunkCount
        },
        decryptNext: function() {
            if (!this.hasDecryptNext()) return Promise.reject();
            var e = this.processedCount,
                t = e * this.ENCRYPTED_MINI_CHUNK_MAX_LEN,
                i = e * this.DECRYPTED_MINI_CHUNK_MAX_LEN,
                n = this.ciphertext.subarray(t, t + this.ENCRYPTED_MINI_CHUNK_MAX_LEN),
                s = this.key,
                o = SYNO.SDS.Drive.Crypto.Utils.incrementNonce(this.nonce, e);
            return this.processedCount++, SYNO.SDS.Drive.Crypto.Utils.decryptAes256Gcm(n, s, o).then(function(e) {
                return {
                    data: e,
                    offset: i
                }
            })
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.ChunkDownloader", {
        constructor: function(e, t) {
            this.chunkInfo = e, this.file = t, this.processedSize = 0
        },
        download: function(e) {
            var t = this._base64ToArrayBuffer(this.chunkInfo.chunkKey),
                i = this._base64ToArrayBuffer(this.chunkInfo.chunkNonce),
                n = this.chunkInfo.chunkUrl,
                s = this.file,
                o = this.chunkInfo.fileOffset;
            return this.processedSize = 0, this._downloadEncryptedChunk(n, e).then(function(e) {
                return this._decryptChunk(e, t, i, s, o)
            }.bind(this))
        },
        _downloadEncryptedChunk: function(e, t) {
            return new Promise(function(i, n) {
                var s = new XMLHttpRequest;
                s.open("GET", e, !0), s.responseType = "blob", s.onload = function(e) {
                    if (200 !== e.target.status) return void n(!0);
                    if (e.target.response.arrayBuffer) e.target.response.arrayBuffer().then(function(e) {
                        i(e)
                    }).catch(function() {
                        n(!1)
                    });
                    else {
                        var t = new FileReader;
                        t.onload = function(e) {
                            var t = e.target.result;
                            i(t)
                        }, t.onerror = function() {
                            n(!1)
                        }, t.readAsArrayBuffer(e.target.response)
                    }
                };
                var o = 0;
                s.onprogress = function(e) {
                    this.processedSize = .9 * e.loaded;
                    var i = (new Date).getTime();
                    i - o > 500 && (o = i, t())
                }.bind(this), s.onerror = function() {
                    n(!0)
                };
                try {
                    s.send()
                } catch (e) {
                    n(!0)
                }
            }.bind(this))
        },
        _decryptChunk: function(e, t, i, n, s) {
            return new Promise(function(o, r) {
                SYNO.SDS.Drive.Crypto.Utils.importAes256GcmKey(t).then(function(t) {
                    var a = new SYNO.SDS.Drive.Crypto.HybridShareChunk(new Uint8Array(e), t, i),
                        l = a.getExpectDecryptedChunkSize(),
                        d = function(e) {
                            if (e && e.data) {
                                n.write(e.offset + s, new Uint8Array(e.data)).catch(r)
                            }
                            a.hasDecryptNext() ? a.decryptNext().then(d).catch(r) : n.fsync().then(function() {
                                o(l)
                            }).catch(r)
                        };
                    d()
                }).catch(r)
            })
        },
        _base64ToArrayBuffer: function(e) {
            for (var t = window.atob(e), i = t.length, n = new Uint8Array(i), s = 0; s < i; s++) n[s] = t.charCodeAt(s);
            return n.buffer
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.Placeholder", {
        constructor: function(e, t) {
            this.fileInfo = e, this.observer = t, this.chunkInfos = e.chunkInfos, this.downloadChunkCount = 0, this.currentChunkDownloader = void 0, this.remainTotal = e.file.size, this.remainProcessed = 0, this.isAbort = !1, this.file = void 0, this.fileInfo.finishedChunkCount && (this.downloadChunkCount = this.fileInfo.finishedChunkCount, this.remainTotal = e.file.size - this.fileInfo.chunkInfos[this.downloadChunkCount].fileOffset)
        },
        fill: function() {
            this.isAbort || this._createFile().then(function(e) {
                this.isAbort || (this.file = e, this._dispatchDownload())
            }.bind(this)).catch(function() {
                this.observer(SYNO.SDS.Drive.HybridShare.Status.ERROR)
            }.bind(this))
        },
        resume: function() {
            this._dispatchDownload()
        },
        getProgress: function() {
            var e = this.remainProcessed + this._getDownloadingChunkProgress(),
                t = this.fileInfo.file.size || 1,
                i = t - this.remainTotal + e,
                n = 100 * i / t;
            return {
                progress: n < 0 ? 0 : n,
                remainTotal: this.remainTotal,
                remainProcessed: e > this.remainTotal ? this.remainTotal : e,
                total: t,
                totalProcessed: i > t ? t : i
            }
        },
        abort: function() {
            this.isAbort = !0, this.file && this.file.abort()
        },
        triggerDownload: function() {
            return Promise.reject()
        },
        _dispatchDownload: function() {
            if (!this.isAbort) {
                if (this.downloadChunkCount < this.chunkInfos.length) {
                    var e = this.chunkInfos[this.downloadChunkCount];
                    this.currentChunkDownloader = new SYNO.SDS.Drive.HybridShare.ChunkDownloader(e, this.file), this.currentChunkDownloader.download(function() {
                        this.observer(SYNO.SDS.Drive.HybridShare.Status.PROGESSING)
                    }.bind(this)).then(function(e) {
                        this.downloadChunkCount++, this.remainProcessed = this.remainProcessed + e, this.currentChunkDownloader = void 0, this.observer(SYNO.SDS.Drive.HybridShare.Status.PROGESSING), this._dispatchDownload()
                    }.bind(this)).catch(function(t) {
                        if (this.currentChunkDownloader = void 0, e.errorCount++, !0 === t && e.errorCount < 3) return void this.observer(SYNO.SDS.Drive.HybridShare.Status.ERROR, !0);
                        this.observer(SYNO.SDS.Drive.HybridShare.Status.ERROR, !1)
                    }.bind(this))
                }
                this.downloadChunkCount === this.chunkInfos.length && this.observer(SYNO.SDS.Drive.HybridShare.Status.DONE)
            }
        },
        _getDownloadingChunkProgress: function() {
            return this.currentChunkDownloader && this.currentChunkDownloader.processedSize > 0 ? this.currentChunkDownloader.processedSize : 0
        },
        _createFile: function() {}
    }), Ext.define("SYNO.SDS.Drive.FileSystem.BlobHelper", {
        singleton: !0,
        constructor: function() {
            this.worker = void 0, this.requestMap = {}, this.requestId = 1
        },
        _getWorker: function() {
            return this.worker ? this.worker : (this.worker = new Worker("webman/3rdparty/SynologyDrive-Drive/blob_worker.js"), this.worker.onmessage = this.onmessage.bind(this), this.worker)
        },
        onmessage: function(e) {
            var t = e.data.requestId;
            t && t in this.requestMap && (e.data.success ? this.requestMap[t].resolve(new Blob([e.data.buffer])) : this.requestMap[t].reject(), delete this.requestMap[t])
        },
        concatBlob: function(e) {
            var t = this.requestId++;
            return new Promise(function(i, n) {
                for (var s = [], o = 0; o < e.length; o++) s.push(e[o].buffer);
                this.requestMap[t] = {
                    resolve: i,
                    reject: n
                }, this._getWorker().postMessage({
                    requestId: t,
                    graduallyConcat: Ext.isIE || Ext.isIE11 || Ext.isIE12,
                    blobArray: e
                }, s)
            }.bind(this))
        }
    }), Ext.define("SYNO.SDS.Drive.FileSystem.MemoryFile", {
        extend: "SYNO.SDS.Drive.FileSystem.File",
        constructor: function() {
            this.callParent(arguments), this.fileChunks = [], this.wholeFile = void 0, this.currentLen = 0
        },
        write: function(e, t) {
            if (this.isAbort()) return Promise.reject();
            try {
                if (e === this.currentLen) this.fileChunks.push(t), this.currentLen = e + t.length;
                else if (e > this.currentLen) this.fileChunks.push(new Uint8Array(e - this.currentLen)), this.fileChunks.push(t), this.currentLen = e + t.length;
                else {
                    for (var i = 0, n = 0, s = 0; s < this.fileChunks.length; s++) {
                        var o = this.fileChunks[s];
                        if (o.length + n > e)
                            if (0 === i && t.length === o.length) this.fileChunks[s] = t, i = t.length;
                            else
                                for (var r = n > e ? 0 : e - n, a = i, l = 0; a + l < t.length && r + l < o.length; l++) o[r + l] = t[a + l], i++;
                        if (n += o.length, i >= t.length) break
                    }
                    if (i < t.length) {
                        for (var d = new Uint8Array(t.length - i), h = i; h < t.length; h++) d[h] = t[t.length - i + h];
                        this.fileChunks.push(d), this.currentLen = this.currentLen + t.length - i
                    }
                }
            } catch (e) {
                return Promise.reject()
            }
            return Promise.resolve()
        },
        fsync: function() {
            return Promise.resolve()
        },
        toBlob: function() {
            if (!this.isAbort()) return SYNO.SDS.Drive.FileSystem.BlobHelper.concatBlob(this.fileChunks)
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.Memory.Placeholder", {
        extend: "SYNO.SDS.Drive.HybridShare.Placeholder",
        constructor: function(e, t) {
            return this.callParent(arguments)
        },
        _createFile: function() {
            if (!this.isAbort) {
                var e = new SYNO.SDS.Drive.FileSystem.MemoryFile(this.chunkInfos.length);
                return Promise.resolve(e)
            }
        },
        triggerDownload: function() {
            var e = this.fileInfo.file.name,
                t = this.file;
            return new Promise(function(i, n) {
                t.toBlob().then(function(t) {
                    if (navigator.msSaveBlob) return navigator.msSaveBlob(t, e), void i();
                    var n = document.createElement("a");
                    n.href = window.URL.createObjectURL(t), n.download = e, document.getElementsByTagName("BODY")[0].appendChild(n), n.click(), i()
                }).catch(n)
            })
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.Memory.DownloadTask", {
        extend: "SYNO.SDS.Drive.HybridShare.DownloadTask",
        constructor: function(e) {
            this.callParent([e]), this.type = SYNO.SDS.Drive.HybridShare.DownloadTask.MEMORY
        },
        _createPlaceholder: function(e) {
            return new SYNO.SDS.Drive.HybridShare.Memory.Placeholder(this.fileInfo, e)
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.FileSystem.Placeholder", {
        extend: "SYNO.SDS.Drive.HybridShare.Placeholder",
        constructor: function(e, t) {
            return this.callParent(arguments)
        },
        _createFile: function() {
            if (!this.isAbort) {
                var e = this.fileInfo.finishedChunkCount > 0;
                return SYNO.SDS.Drive.FileSystem.FileManger.openFile(this.fileInfo.tmpFileName, this.fileInfo.file.size, !e)
            }
        },
        triggerDownload: function() {
            var e = document.createElement("a");
            return e.href = this.file.toURL(), e.download = this.fileInfo.file.name, document.getElementsByTagName("BODY")[0].appendChild(e), e.click(), Promise.resolve()
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.ChunkInfo", {
        statics: {
            convertToChunkInfos: function(e) {
                for (var t = [], i = 0; i < e.length; i++) t.push(new SYNO.SDS.Drive.HybridShare.ChunkInfo(i, e[i]));
                return t
            },
            updateChunkInfosByWebapiResponse: function(e, t) {
                if (e.length !== t.length) return !1;
                for (var i = 0; i < e.length; i++) {
                    if (e[i].chunkId !== t[i].chunk_id) return !1;
                    e[i].chunkUrl = t[i].chunk_url
                }
                return !0
            }
        },
        constructor: function(e, t) {
            this.index = e, this.chunkId = t.chunk_id, this.chunkKey = t.chunk_key, this.chunkNonce = t.chunk_nonce, this.chunkUrl = t.chunk_url, this.dependentIdxs = t.dependent_idxs, this.fileOffset = t.file_offset, this.errorCount = 0
        },
        toString: function() {
            var e = {
                index: this.index,
                chunkId: this.chunkId,
                chunkKey: this.chunkKey,
                chunkNonce: this.chunkNonce,
                chunkUrl: this.chunkUrl,
                dependentIdxs: this.dependentIdxs,
                fileOffset: this.fileOffset,
                errorCount: this.errorCount
            };
            return JSON.stringify(e)
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.FileInfo", {
        statics: {
            FORMAT_VERSION: 1,
            PREFIX: "drive-",
            STATUS_NEW: 1,
            STATUS_DOWNLOADING: 2,
            STATUS_DOWNLOADED: 3,
            STATUS_PAUSE: 4,
            STATUS_DELETE: 5,
            get: function(e) {
                var t = new SYNO.SDS.Drive.HybridShare.FileInfo;
                if (t.parse(window.localStorage.getItem(e))) return t.key = e, t
            },
            getByFileName: function(e) {
                return SYNO.SDS.Drive.HybridShare.FileInfo.get(SYNO.SDS.Drive.HybridShare.FileInfo.PREFIX + e)
            },
            isFileInfo: function(e) {
                var t = SYNO.SDS.Drive.HybridShare.FileInfo.PREFIX;
                return e.substring(0, t.length) === t
            },
            remove: function(e) {
                return window.localStorage.removeItem(e)
            },
            fetchFileInfos: function() {
                for (var e = [], t = [], i = [], n = (new Date).getTime(), s = 0; s < window.localStorage.length; s++) {
                    var o = window.localStorage.key(s);
                    if (SYNO.SDS.Drive.HybridShare.FileInfo.isFileInfo(o)) {
                        var r = SYNO.SDS.Drive.HybridShare.FileInfo.get(o);
                        if (!r) continue;
                        var a = n - r.lastUpdateTime;
                        r.status === SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_PAUSE && r.finishedChunkCount > 2 ? t.push(r) : a < 5e3 ? e.push(r) : r.status === SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DOWNLOADED && a < 6e4 ? e.push(r) : r.status === SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DOWNLOADING && a < 3e5 ? e.push(r) : i.push(r)
                    }
                }
                return {
                    skippedList: e,
                    resumableList: t,
                    needRemoveList: i
                }
            }
        },
        constructor: function(e, t, i, n, s, o) {
            this.formatVersion = SYNO.SDS.Drive.HybridShare.FileInfo.FORMAT_VERSION, this.key = SYNO.SDS.Drive.HybridShare.FileInfo.PREFIX + e, this.tmpFileName = e, this.file = t, this.lastUpdateTime = s || (new Date).getTime(), this.finishedChunkCount = n || 0, this.status = o || SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_NEW, this.chunkCount = i ? i.length : 0, this.chunkInfos = i, this.lastPersistTime = 0, this.skipPersistentCount = 0
        },
        persistent: function() {
            this.lastPersistTime = (new Date).getTime(), this.skipPersistentCount = 0;
            var e = !0;
            try {
                window.localStorage.setItem(this.key, this.serialize())
            } catch (t) {
                e = !1
            }
            return e
        },
        lazyPersistent: function() {
            return this.lastUpdateTime - this.lastPersistTime > 1e3 || this.skipPersistentCount > 10 ? this.persistent() : (this.skipPersistentCount = this.skipPersistentCount + 1, !0)
        },
        serialize: function() {
            return JSON.stringify([this.formatVersion, this.tmpFileName, this.file, this.chunkCount, this.status, this.finishedChunkCount, this.lastUpdateTime])
        },
        parse: function(e) {
            try {
                var t = JSON.parse(e);
                if (t[0] === SYNO.SDS.Drive.HybridShare.FileInfo.FORMAT_VERSION) return this.formatVersion = t[0], this.tmpFileName = t[1], this.file = t[2], this.chunkCount = t[3], this.status = t[4], this.finishedChunkCount = t[5], this.lastUpdateTime = t[6], !0
            } catch (e) {}
            return !1
        },
        delete: function() {
            return SYNO.SDS.Drive.HybridShare.FileInfo.remove(this.key)
        },
        updateProgress: function(e, t, i) {
            var n = !0;
            this.status = e, this.lastUpdateTime = (new Date).getTime();
            var s = e === SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DOWNLOADING;
            return s && (this.finishedChunkCount = i), t && (n = s ? this.lazyPersistent() : this.persistent()), n
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.FileSystem.DownloadTask", {
        extend: "SYNO.SDS.Drive.HybridShare.DownloadTask",
        constructor: function(e) {
            this.callParent([e]), this.type = SYNO.SDS.Drive.HybridShare.DownloadTask.FILE_SYSTEM, this.persistentDownloadProgress = !0
        },
        _createPlaceholder: function(e) {
            return new SYNO.SDS.Drive.HybridShare.FileSystem.Placeholder(this.fileInfo, e)
        }
    }), Ext.define("SYNO.SDS.Drive.Task.Base", {
        extend: "Ext.Component",
        type: "base",
        constructor: function(e) {
            this.appWindow = e.appWindow;
            var t = {
                action: e.action,
                taskid: Ext.id(void 0, this.type + "_"),
                starttime: (new Date).getTime(),
                title: "",
                name: "",
                prevProgress: 0,
                hasProgress: !1,
                showProgress: !1,
                delayProgress: 1e3,
                showToast: !0,
                showStartToast: !0,
                total: -1,
                status: "wait",
                statusText: SYNO.SDS.Drive._T("task", "task_waiting")
            };
            Ext.apply(t, e || {}), Ext.apply(this, t), this.callParent(arguments)
        },
        start: function() {
            return this.starttime = (new Date).getTime(), this.status = "processing", this.statusText = SYNO.SDS.Drive._T("task", "task_processing"), this._showToast("start"), this._showProgress.defer(this.delayProgress, this), new Promise(function(e, t) {
                this.resolve = e, this.reject = t, this._start()
            }.bind(this))
        },
        stop: function() {
            this.status = "stopped", this._stop(), this.reject && this.reject("stop"), this._cleanup()
        },
        clone: function() {
            return null
        },
        _start: function(e, t) {},
        _stop: function() {},
        _cleanup: function() {
            this.resolve = null, this.reject = null, this.progressbox && this.progressbox.hide()
        },
        _onFinished: function(e, t) {
            e ? this._onSuccess(t) : this._onError(t), this.fireEvent("onfinish", this, e, t), this._cleanup()
        },
        _onProgress: function(e) {
            this.prevProgress = e, this.hasProgress && (!0 === this.showProgress && this._onUpdateProgress(e), this.fireEvent("onprogress", this, e))
        },
        _onError: function(e) {
            "error" !== this.status && "partial_error" !== this.status && (this.status = "error", this.statusText = SYNO.SDS.Drive.Utils.getErrorStr(e)), this._showToast("error", e), this._onUpdateProgress(0, !0, !1, e), this.fireEvent("onerror", this, e);
            try {
                this.reject(e)
            } catch (e) {
                SYNO.Debug.error(e)
            }
        },
        _onSuccess: function(e) {
            this.status = "success", this.statusText = SYNO.SDS.Drive._T("task", "task_completed"), this._showToast("success", e), this._onUpdateProgress(100, !0, !0, e), this.fireEvent("onsuccess", this, e);
            try {
                this.resolve(e)
            } catch (e) {
                SYNO.Debug.error(e)
            }
        },
        _showToast: function(e, t) {
            if (this.showToast && this.appWindow && (this.showStartToast || "start" !== e)) {
                var i = this._getToastMessage(e, t),
                    n = i.action;
                SYNO.SDS.Drive.Utils.showToastMsg(this.appWindow, i.text, n ? 5e3 : 3e3, !!n, n)
            }
        },
        _getToastMessage: function(e, t) {
            var i = SYNO.SDS.Drive._T;
            if ("success" !== e && "error" !== e) return {
                text: this._getTitleText(e)
            };
            if (!t || !t.result) return {
                text: this._getTitleText(e)
            };
            var n = t.result,
                s = this.title,
                o = "",
                r = n && !Ext.isEmpty(n.skips),
                a = r && 1 === n.skips.length,
                l = n && !Ext.isEmpty(n.errors),
                d = l && 1 === n.errors.length;
            if (r && !l && a) return o = SYNO.SDS.Drive.Utils.parseDisplayName(n.skips[0].context.name), {
                text: String.format(i("task", "success_skip"), o)
            };
            if (l && !r && d) return s = String.format("{0}_error", s), o = SYNO.SDS.Drive.Utils.parseDisplayName(n.errors[0].context.name), {
                text: String.format(i("task", s), o)
            };
            if (!r && !l) {
                var h, c = SYNO.SDS.Drive.GetWindow();
                if (n)
                    if ("restore" === n.action && n.names && n.params && !n.params.to_parent_folder && 1 === n.names.length && 0 === c.modalWin.length && n.targets && 1 === n.targets.length) h = {
                        text: i("action", "goto_folder"),
                        fn: function() {
                            c.getAction().onGotoPath({
                                path: SYNO.SDS.Drive.Utils.getPathIdByLink(n.targets[0].permanent_link)
                            }, void 0, void 0, !1)
                        }
                    };
                    else if ("convert_office" === n.action && this._isConvertFolder(n)) return {
                    text: this._getConvertFolderText(e, n.names)
                };
                return {
                    action: h,
                    text: this._getTitleText(e)
                }
            }
            var u = [];
            return u.push(SYNO.SDS.Drive._T("task", "task_completed")), r && u.push(String.format(i("task", "skipped_items"), n.skips.length)), l && u.push(String.format(i("task", "error_items"), n.errors.length)), {
                text: u.join(", ")
            }
        },
        _isConvertFolder: function(e) {
            var t = e.names;
            if (Ext.isEmpty(t)) return !0;
            var i = Ext.isString(this.name) ? [this.name] : this.name,
                n = !1;
            return Ext.each(t, function(e) {
                if (-1 === i.indexOf(e)) return n = !0, !1
            }), n
        },
        _getConvertFolderText: function(e, t) {
            var i, n, s, o = this.name;
            return s = t ? 1 === t.length ? 1 : t.length : 0, Ext.isArray(o) && o.length > 1 ? (i = 0 === s ? "convert_multi_folder_none_success" : 1 === s ? "convert_multi_folder_one_success" : "convert_multi_folder_multi_success", n = String.format(SYNO.SDS.Drive._T("task", i), o.length, s)) : (i = 0 === s ? "convert_folder_none_success" : 1 === s ? "convert_folder_one_success" : "convert_folder_multi_success", n = String.format(SYNO.SDS.Drive._T("task", i), o.toString(), s)), Ext.util.Format.htmlEncode(n)
        },
        _getTitleText: function(e, t) {
            var i, n, s = e ? String.format("_{0}", e) : "";
            return t = t || this._getTitleSourceText(), Ext.isArray(t) && t.length > 1 ? (i = String.format("{0}_multi{1}", this.title, s), n = String.format(SYNO.SDS.Drive._T("task", i), t.length, this._getDestinationName())) : (i = String.format("{0}{1}", this.title, s), n = SYNO.SDS.Drive._T("task", i), n = String.format(n, SYNO.SDS.Drive.Utils.parseDisplayName(t.toString()), this._getDestinationName())), Ext.util.Format.htmlEncode(n)
        },
        _showProgress: function() {
            if (this.showProgress && this.appWindow && !this.progressbox && ("processing" === this.status || "task_error" === this.status)) {
                var e = {
                        ok: _T("common", "hide"),
                        cancel: _T("common", "cancel")
                    },
                    t = {
                        title: "",
                        cls: "syno-d-bgtask-message-progress",
                        width: 340,
                        progress: this.hasProgress,
                        progressText: this.hasProgress ? "<center>0&#37;</center>" : "",
                        closable: !1,
                        buttons: e,
                        fn: function(e) {
                            switch (e) {
                                case "ok":
                                    this.hideProgress = !0;
                                    break;
                                case "cancel":
                                    this.taskmgr.removeTask(this.taskid)
                            }
                        },
                        hideDlg: !0,
                        scope: this
                    };
                this.progressbox = this.appWindow.getMsgBox(), this.progressbox.show(t), this.progressbox.updateText(this._getProgressTitle()), 0 < this.prevProgress && this._onUpdateProgress(this.prevProgress)
            }
        },
        _onUpdateProgress: function(e, t, i, n) {
            this.progressbox && this.progressbox.isVisible() && !this.hideProgress && (!0 === t ? i ? (this.progressbox.updateProgress(1, this._getProgressText(100), this._getProgressTitle()), this.progressbox.hide.defer(2e3, this)) : SYNO.SDS.Drive.Utils.showAlertMsg(this.appWindow, this._getToastMessage("error", n).text) : this.progressbox.updateProgress(e / 100, this._getProgressText(e), this._getProgressTitle()))
        },
        _getProgressTitle: function() {
            var e = Ext.isArray(this.name) ? this.name : [this.name];
            e = e.map(function(e) {
                return SYNO.SDS.Drive.Utils.parseDisplayName(e)
            }).join(", "), e = Ext.util.Format.htmlEncode(e);
            var t = String.format('<span style="font-weight: bold;">{0}: </span><span class="syno-d-bgtask-progress-title" ext:qtip="{1}">{2}</span>', this._getTitleText(), Ext.util.Format.htmlEncode(e), e),
                i = String.format('<span style="float:right; color:#7E8082">{0}</span>', this.statusText);
            return this.hasProgress ? t : t + i
        },
        _getProgressText: function(e) {
            if (!this.hasProgress) return "";
            if (0 >= e || 0 >= this.total) return String.format("<center>{0}&#37;</center>", 0 < e ? e : 0);
            var t, i, n = ["<div>", '<div class="syno-d-bgtask-progress-info">', '<span style="float:left;">{0}% ({1}/{2})</span>', '<span style="float:right;">{3}/' + SYNO.SDS.Drive._T("task", "time_s") + "</span>", "</div>", '<div class="syno-d-bgtask-progress-info">', "{4}: {5}", "</div>", "</div>"].join(""),
                s = this._getTimeSpeedInfo(e),
                o = String.format("1 {0}", SYNO.SDS.Drive._T("task", "time_sec")),
                r = Math.round(100 * s.speed) / 100;
            return "delete" === this.action || "convert_office" === this.action ? (r += " " + SYNO.SDS.Drive._T("task", "file_number"), t = this.total + " " + SYNO.SDS.Drive._T("task", "file_number"), i = s.processed.toFixed(0)) : (r = Ext.util.Format.fileSize(r), t = Ext.util.Format.fileSize(this.total), i = Ext.util.Format.fileSize(s.processed.toFixed(0))), String.format(n, Math.round(100 * e) / 100, i, t, r, SYNO.SDS.Drive._T("task", "left_time"), SYNO.SDS.Drive.Date.fancyDuration(s.leftTime) || o)
        },
        _getTimeSpeedInfo: function(e) {
            var t = this.total * (e / 100),
                i = ((new Date).getTime() - this.starttime) / 1e3;
            return {
                processed: t,
                speed: t / i,
                leftTime: i * ((100 - e) / e)
            }
        },
        getTrayTitle: function() {
            if (Ext.isArray(this.name) && this.name.length > 1) {
                var e = String.format("{0}_multi", this.title);
                return String.format(SYNO.SDS.Drive._T("task", e), this.name.length, Ext.util.Format.htmlEncode(this._getDestinationName()))
            }
            return String.format(SYNO.SDS.Drive._T("task", this.title), Ext.util.Format.htmlEncode(this.name), Ext.util.Format.htmlEncode(this._getDestinationName()))
        },
        getTrayTitleTooltip: function() {
            return this.getTrayTitle()
        },
        _getDestinationName: function() {
            return ""
        },
        getTrayNames: function() {
            var e;
            return e = Ext.isArray(this.name) && this.name.length > 1 ? this.name : [this.name], e = e.map(function(e) {
                return SYNO.SDS.Drive.Utils.parseDisplayName(e)
            }).join(", ")
        },
        _getTitleSourceText: function() {
            return this.name
        },
        onClickAction: function() {}
    }), Ext.define("SYNO.SDS.Drive.Task.Upload", {
        extend: "SYNO.SDS.Drive.Task.Base",
        type: "upload",
        buffer: 1e3,
        lastTime: 0,
        constructor: function(e) {
            this.callParent(arguments), this._init()
        },
        initFiles: function() {
            return Promise.resolve(this)
        },
        updateParentPath: function(e) {
            this.path = e, this.uploadPath = String.format("{0}/{1}", this.path, this.name)
        },
        clone: function() {
            return new SYNO.SDS.Drive.Task.Upload({
                appWindow: this.appWindow,
                path: this.path,
                file: this.file,
                showToast: !1
            })
        },
        _start: function() {
            var e = {
                path: this.uploadPath,
                type: this.uploadType,
                modified_time: this.uploadMtime,
                conflict_action: "version",
                file: this.file
            };
            this.apiId = SYNO.SDS.Drive.WebAPICore.send("upload_files", e, {
                callback: this._onFinished.createDelegate(this),
                progress: this._onProgress.createDelegate(this)
            }, this)
        },
        _stop: function() {
            if (this.apiId) try {
                this.apiId.conn.abort()
            } catch (e) {
                SYNO.Debug.error(e)
            }
        },
        _init: function() {
            this.uploadPath = String.format("{0}/{1}", this.path, this.file.name), this.uploadType = "file", this.uploadMtime = this.file.lastModifiedDate ? this.file.lastModifiedDate.getTime() : this.file.lastModified, this.uploadMtime /= 1e3, this.uploadSize = this.file.size, this.name = this._getFileName(this.file.name), this.total = this.uploadSize, this.title = this.type, this.hasProgress = !0
        },
        _cleanup: function() {
            this.callParent(arguments), this.apiId = null, this.lastTime = 0
        },
        _onProgress: function(e, t) {
            if (!(e.timeStamp - this.lastTime < this.buffer)) {
                var i = 0 === e.total ? 1 : e.loaded / e.total;
                i = (100 * i).toFixed(0), this.lastTime = e.timeStamp, this.callParent([i])
            }
        },
        _onFinished: function(e, t) {
            if (!e && t && 0 === t.status) {
                var i = 1e4;
                switch (t.statusText) {
                    case "communication failure":
                        i = 10001
                }
                return void this.callParent([!1, {
                    code: i
                }])
            }
            this.callParent(arguments)
        },
        _onSuccess: function(e) {
            e && this.appWindow && this.appWindow.getEventMgr().fireEvent("createnodedone", !0, e, {}, 1500), this.callParent(arguments)
        },
        _onError: function(e) {
            e && e.code && (this.status = "error", this.statusText = SYNO.SDS.Drive.Utils.getErrorStr(e), this.errors = e.errors = [this._getErrObject(e.code)]), this.callParent(arguments)
        },
        _getErrObject: function(e) {
            return {
                code: e,
                context: {
                    name: this.name,
                    file_type: "file"
                }
            }
        },
        _getFileName: function(e) {
            if (Ext.isWindows) return e.substr(e.lastIndexOf("\\") + 1);
            var t = /fakepath\\(.+)$/.exec(e);
            return null !== t && (e = t[1]), e
        }
    }), Ext.define("SYNO.SDS.Drive.Task.UploadDir", {
        extend: "SYNO.SDS.Drive.Task.Upload",
        blInit: !1,
        blUploadDir: !0,
        initFiles: function() {
            return this.blInit ? Promise.resolve(this) : new Promise(function(e, t) {
                this.blInit = !0, this.reader = this.directory.createReader(), this._readEntries(e, t)
            }.bind(this))
        },
        clone: function() {
            return new SYNO.SDS.Drive.Task.UploadDir({
                appWindow: this.appWindow,
                path: this.path,
                directory: this.directory,
                showToast: !1
            })
        },
        _readEntries: function(e, t) {
            this.reader.readEntries(this._readEntriesCb.createDelegate(this, [e, t], !0), this._readEntriesErrCb.createDelegate(this, [e, t], !0))
        },
        _readEntriesCb: function(e, t, i) {
            var n = [],
                s = this.path + "/" + this.name;
            if (!e.length) return void t(this);
            Ext.each(e, function(e) {
                n.push(SYNO.SDS.Drive.TaskFactory.createUploadTaskByEntry(e, {
                    appWindow: this.appWindow,
                    path: s,
                    showToast: !1,
                    showProgress: !1
                }).then(function(e) {
                    return e.initFiles()
                }))
            }, this), Promise.all(n).then(function(e) {
                this.total += e.reduce(function(e, t) {
                    return e + t.total
                }, 0), this.subTasks = this.subTasks.concat(e), this._readEntries(t, i)
            }.bind(this)).catch(function(e) {
                SYNO.Debug.error("Failed to initFiles: " + e), i(e)
            })
        },
        _readEntriesErrCb: function(e, t, i) {
            SYNO.Debug.error(String.format("Failed to read entries: {0}, reason: {1}", this.name, e)), t(SYNO.SDS.Drive.TaskFactory.createErrTask({
                name: this.name,
                file_type: "dir"
            }))
        },
        _start: function(e, t) {
            Promise.resolve().then(this.initFiles.bind(this)).then(this._startUpload.bind(this)).catch(this._onError.bind(this))
        },
        _stop: function() {
            this.curTask && this.curTask.stop()
        },
        _init: function() {
            this.title = this.type, this.name = this._getFileName(this.directory.name), this.hasPorgress = !0, this.total = 0, this.loaded = 0, this.subTasks = [], this.errors = []
        },
        _cleanup: function() {
            this.curTask = null, this.subTasks = null, this.loaded = 0, this.subTasks = []
        },
        _startUpload: function() {
            return Promise.resolve().then(this._createFolder.bind(this)).then(this._updateSubTask.bind(this)).then(this._uploadSubTasks.bind(this))
        },
        _createFolder: function() {
            return SYNO.SDS.Drive.WebAPICore.sendPromise("create_files", {
                type: "folder",
                path: this.path + "/" + this.name,
                conflict_action: "autorename"
            }).then(function(e) {
                return this.appWindow.getEventMgr().fireEvent("createnodedone", !0, e, {}, 1500), Promise.resolve(e)
            }.bind(this)).catch(function(e) {
                return this.errors.push({
                    context: {
                        name: this.name,
                        file_type: "dir"
                    },
                    code: e.code
                }), Promise.reject(e)
            }.bind(this))
        },
        _updateSubTask: function(e) {
            return Ext.each(this.subTasks, function(t) {
                t.updateParentPath(SYNO.SDS.Drive.Utils.getPathId(e.file_id))
            }), Promise.resolve()
        },
        _uploadSubTasks: function() {
            return this.curTask = this.subTasks.shift(), this.curTask ? this.curTask.blErrTask ? (this.errors = this.errors.concat(this.curTask.errors), this._uploadSubTasks()) : (this.mon(this.curTask, "onprogress", this._onProgress, this), this.mon(this.curTask, "onsuccess", this._onTaskSuccess, this), Promise.resolve().then(this.curTask.start.bind(this.curTask)).then(this._uploadSubTasks.bind(this)).catch(this._onSubTaskErr.bind(this))) : (this._onFinished(), Promise.resolve())
        },
        _onSubTaskErr: function(e) {
            return "stop" === e ? Promise.reject("stop") : e.errors ? (this.errors = this.errors.concat(e.errors), this._uploadSubTasks()) : Promise.reject(e)
        },
        _onTaskSuccess: function(e, t) {
            this.loaded += e.total
        },
        _onProgress: function(e, t) {
            var i = this.loaded + e.total * (t / 100),
                n = (100 * i / this.total).toFixed(0);
            0 < this.errors.length && (this.status = "task_error", this.statusText = SYNO.SDS.Drive._T("task", this.status)), this.fireEvent("onprogress", this, n)
        },
        _onSetSuccess: function() {},
        _onFinished: function() {
            0 === this.errors.length ? this._onSuccess() : this._onError(), this._cleanup()
        },
        _onError: function(e) {
            "stop" !== e && (this.status = "partial_error", this.statusText = SYNO.SDS.Drive._T("task", this.status), this.callParent([{
                errors: this.errors
            }]))
        }
    }), Ext.define("SYNO.SDS.Drive.Task.Background.Base", {
        extend: "SYNO.SDS.Drive.Task.Base",
        type: "background",
        immediate: !0,
        interval: [{
            time: 0,
            interval: 1
        }, {
            time: 3,
            interval: 3
        }],
        pollingOnly: !1,
        constructor: function(e) {
            this.callParent(arguments), this._init(e)
        },
        _start: function() {
            var e = Promise.resolve();
            this.pollingOnly || (e = SYNO.SDS.Drive.WebAPICore.sendPromise(this.webapi, this.params)), e.then(this._startPolling.bind(this)).catch(this._onError.bind(this))
        },
        _stop: function() {
            this.pollId && SYNO.SDS.Drive.WebAPICore.send("delete_task", {
                task_id: this.async_task_id
            })
        },
        _init: function(e) {
            this.webapi = e.webapi, this.params = e.params, this.title = e.title, this.name = e.name, this.progress = e.progress || 0, this.total = e.total || -1, this.async_task_id = e.async_task_id
        },
        _cleanup: function() {
            this.callParent(arguments), this.pollId && this.pollUnreg(this.pollId), this.pollId = null
        },
        _startPolling: function(e) {
            this.pollingOnly || (this.async_task_id = e.async_task_id);
            var t = SYNO.SDS.Drive.WebAPIDesc.get_task;
            this.pollId = this.pollReg({
                webapi: Ext.apply({
                    params: {
                        task_id: this.async_task_id
                    }
                }, t),
                interval: this.interval,
                immediate: !!this.immediate,
                status_callback: this._onStatusCb.bind(this),
                scope: this
            })
        },
        _onStatusCb: function(e, t, i, n) {
            if ("finished" === t.status || !e) return t.result && Ext.isArray(t.result.errors) && 0 < t.result.errors.length && (e = !1), void this._onFinished(e, t);
            this._onProgress(t)
        },
        _onError: function(e) {
            e && e.result && Ext.isArray(e.result.errors) && 0 < e.result.errors.length ? ("download" === e.result.action && 0 < e.result.processed_size ? (this.status = "partial_error", this.statusText = SYNO.SDS.Drive._T("task", this.status)) : e.result.names && 1 === e.result.names.length || !e.result.names && e.result.context && 1 === e.result.errors.length ? (this.status = "error", this.statusText = SYNO.SDS.Drive.Utils.getErrorStr(e.result.errors[0])) : (this.status = "partial_error", this.statusText = SYNO.SDS.Drive._T("task", this.status)), this.errors = e.result.errors) : (this.status = "error", this.statusText = SYNO.SDS.Drive.Utils.getErrorStr(e.result)), this.callParent(arguments)
        },
        _onProgress: function(e) {
            if (!(0 > e.progress)) {
                e.result && Ext.isArray(e.result.errors) && 0 < e.result.errors.length && (this.status = "task_error", this.statusText = SYNO.SDS.Drive._T("task", this.status), this.errors = e.result.errors), e.result && (this.total = e.result.total_size || -1);
                var t = e.progress;
                if (0 < e.progress && !this.progressbox) {
                    var i = this._getTimeSpeedInfo(e.progress / 100);
                    this.delayProgress < i.leftTime / 1e3 && this._showProgress()
                }
                this.callParent([t.toFixed(0)])
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Task.Background.MVCP", {
        extend: "SYNO.SDS.Drive.Task.Background.Base",
        constructor: function(e) {
            this.callParent([e]), this.to_parent_folder_name = e.params.to_parent_folder_name, this.title = String.format("task_{0}", this.title), this.finishedResult = void 0
        },
        _getToastMessage: function(e, t) {
            if ("success" !== e || !t || !t.result) return this.callParent(arguments);
            var i = t.result,
                n = i && !Ext.isEmpty(i.skips),
                s = i && !Ext.isEmpty(i.errors);
            if (!n && !s) {
                var o = Ext.id();
                return {
                    action: {
                        fn: this.onClickAction.bind(this),
                        textActionId: o
                    },
                    text: this._getSuccussToastText(o)
                }
            }
            return this.callParent(arguments)
        },
        _onSuccess: function(e) {
            return e && e.result ? (this.finishedResult = e.result, this.callParent(arguments)) : this.callParent(arguments)
        },
        getTrayTitle: function() {
            return this._getTrayTitle()
        },
        getTrayTitleTooltip: function() {
            return this._getTrayTitle(!0)
        },
        _getTrayTitle: function(e) {
            var t;
            if ("processing" === this.status || "wait" === this.status) return Ext.isArray(this.name) && this.name.length > 1 ? (t = String.format("action_{0}_multi_start", this.title), String.format(SYNO.SDS.Drive._T("task", t), this.name.length, Ext.util.Format.htmlEncode(this._getDestinationName()))) : (t = String.format("action_{0}_start", this.title), String.format(SYNO.SDS.Drive._T("task", t), Ext.util.Format.htmlEncode(this.name), Ext.util.Format.htmlEncode(this._getDestinationName())));
            if (!e && "success" === this.status) {
                var i = '<a class="syno-d-bgtask-action">';
                return Ext.isArray(this.name) && this.name.length > 1 ? (t = String.format("action_{0}_multi_success", this.title), String.format(SYNO.SDS.Drive._T("task", t), this.name.length, Ext.util.Format.htmlEncode(this._getDestinationName()), i, "</a>")) : (t = String.format("action_{0}_success", this.title), String.format(SYNO.SDS.Drive._T("task", t), Ext.util.Format.htmlEncode(this.name), Ext.util.Format.htmlEncode(this._getDestinationName()), i, "</a>"))
            }
            return Ext.isArray(this.name) && this.name.length > 1 ? (t = String.format("action_{0}_multi_done", this.title), String.format(SYNO.SDS.Drive._T("task", t), this.name.length, Ext.util.Format.htmlEncode(this._getDestinationName()))) : (t = String.format("action_{0}_done", this.title), String.format(SYNO.SDS.Drive._T("task", t), Ext.util.Format.htmlEncode(this.name), Ext.util.Format.htmlEncode(this._getDestinationName())))
        },
        onClickAction: function() {
            var e = SYNO.SDS.Drive.GetWindow(),
                t = this.finishedResult.targets;
            t && 1 === t.length ? e.getAction().onGotoPath({
                path: SYNO.SDS.Drive.Utils.getPathIdByLink(t[0].permanent_link)
            }, void 0, void 0, !1) : e.getAction().onGotoPath({
                path: this.finishedResult.params.to_parent_folder
            })
        },
        _getParentFolderName: function() {
            return this.to_parent_folder_name ? this.to_parent_folder_name : SYNO.SDS.Drive._T("category", "node")
        },
        _getDestinationName: function() {
            return this._getParentFolderName()
        },
        _getSuccussToastText: function(e) {
            var t, i, n = String.format('<span id={0} class="action-text" role="button" tabIndex="0">', e),
                s = this._getTitleSourceText();
            return Ext.isArray(s) && s.length > 1 ? (t = String.format("{0}_multi_success_toast", this.title), i = String.format(SYNO.SDS.Drive._T("task", t), s.length, Ext.util.Format.htmlEncode(this._getDestinationName()), n, "</span>")) : (t = String.format("{0}_success_toast", this.title), i = SYNO.SDS.Drive._T("task", t), i = String.format(i, Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(s.toString())), Ext.util.Format.htmlEncode(this._getDestinationName()), n, "</span>")), i
        }
    }), Ext.define("SYNO.SDS.Drive.Task.Background.ConvertOffice", {
        extend: "SYNO.SDS.Drive.Task.Background.Base",
        constructor: function(e) {
            this.callParent([e])
        },
        _getToastMessage: function(e, t) {
            if ("error" !== e || !t || !t.result) return this.callParent(arguments);
            var i = this.callParent(arguments),
                n = {
                    action: {
                        text: SYNO.SDS.Drive._T("task", "check_detail"),
                        fn: function() {
                            SYNO.SDS.Drive.GetWindow().getLeftPanel().getBackgroundTray().onViewDetail()
                        }
                    }
                };
            return Ext.applyIf(i, n)
        }
    }), Ext.define("SYNO.SDS.Drive.Task.HybridShareDownload", {
        extend: "SYNO.SDS.Drive.Task.Base",
        type: "background",
        constructor: function(e) {
            this.appWindow = e.appWindow, this.task = e.downloadTask, this.downloadDispatcher = e.downloadDispatcher, this.task.addObserver(this._taskCallback.bind(this)), this.callParent(arguments)
        },
        _start: function() {
            this.downloadDispatcher.startTask(this.task)
        },
        _stop: function() {
            this.downloadDispatcher.stopTask(this.task)
        },
        _onFinished: function(e) {
            e ? this.downloadDispatcher.finishTask(this.task) : this.downloadDispatcher.fallBackTask(this.task), this.callParent([!0])
        },
        _taskCallback: function(e, t) {
            t === SYNO.SDS.Drive.HybridShare.Status.PROGESSING ? this._updateProgress() : t === SYNO.SDS.Drive.HybridShare.Status.DONE ? this._onFinished(!0) : t === SYNO.SDS.Drive.HybridShare.Status.ERROR && this._onFinished(!1)
        },
        _updateProgress: function() {
            var e = this.task.getProgress();
            this.total = e.remainTotal, this.process = e.remainProcessed, this.totalSize = e.total, this.totalProcessed = e.totalProcessed;
            var t = e.progress,
                i = ((new Date).getTime() - this.starttime) / 1e3;
            this.speed = this.process / i, this.leftTime = (this.total - this.process) / this.speed,
                this._onProgress(t.toFixed(1))
        },
        _getProgressText: function(e) {
            if (!this.hasProgress) return "";
            if (0 >= e || 0 >= this.total) return String.format("<center>{0}&#37;</center>", 0 < e ? e : 0);
            var t = ["<div>", '<div class="syno-d-bgtask-progress-info">', '<span style="float:left;">{0}% ({1}/{2})</span>', '<span style="float:right;">{3}/' + SYNO.SDS.Drive._T("task", "time_s") + "</span>", "</div>", '<div class="syno-d-bgtask-progress-info">', "{4}: {5}", "</div>", "</div>"].join(""),
                i = String.format("1 {0}", SYNO.SDS.Drive._T("task", "time_sec")),
                n = Ext.util.Format.fileSize(this.speed),
                s = Ext.util.Format.fileSize(this.totalSize),
                o = Ext.util.Format.fileSize(this.totalProcessed.toFixed(0));
            return String.format(t, Math.round(100 * e) / 100, o, s, n, SYNO.SDS.Drive._T("task", "left_time"), SYNO.SDS.Drive.Date.fancyDuration(this.leftTime) || i)
        }
    }), Ext.define("SYNO.SDS.Drive.TaskFactory", {
        statics: {
            createErrTask: function(e) {
                return {
                    blErrTask: !0,
                    total: 0,
                    stop: Ext.emptyFn,
                    start: Ext.emptyFn,
                    initFiles: function() {
                        return Promise.resolve(this)
                    },
                    updateParentPath: Ext.emptyFn,
                    errors: [{
                        code: 10002,
                        context: e
                    }]
                }
            },
            createHybridShareDownloadTask: function(e, t, i, n) {
                return new SYNO.SDS.Drive.Task.HybridShareDownload({
                    title: "download_from_remote",
                    name: t,
                    appWindow: e,
                    downloadTask: i,
                    downloadDispatcher: n,
                    showProgress: !0,
                    hasProgress: !0,
                    delayProgress: 500
                })
            },
            createUploadTask: function(e, t, i) {
                if (t) {
                    if (t.isFile || t.isDirectory) return SYNO.SDS.Drive.TaskFactory.createUploadTaskByEntry(t, i);
                    var n = t.webkitGetAsEntry();
                    return n ? SYNO.SDS.Drive.TaskFactory.createUploadTaskByEntry(n, i) : Promise.resolve(new SYNO.SDS.Drive.Task.Upload(Ext.apply({
                        showToast: !1,
                        file: e
                    }, i || {})))
                }
                return Promise.resolve(new SYNO.SDS.Drive.Task.Upload(Ext.apply({
                    showToast: !1,
                    file: e
                }, i || {})))
            },
            createUploadTaskByEntry: function(e, t) {
                return new Promise(function(i, n) {
                    var s = null;
                    e.isDirectory ? (s = new SYNO.SDS.Drive.Task.UploadDir(Ext.apply({
                        action: "upload",
                        showToast: !1,
                        directory: e
                    }, t || {})), i(s)) : e.file(function(e) {
                        s = new SYNO.SDS.Drive.Task.Upload(Ext.apply({
                            action: "upload",
                            showToast: !1,
                            file: e
                        }, t || {})), i(s)
                    }, function(t) {
                        SYNO.Debug.error(t);
                        var n = {
                            name: e.name,
                            file_type: "file"
                        };
                        i(SYNO.SDS.Drive.TaskFactory.createErrTask(n))
                    })
                })
            },
            addUploadTasks: function(e, t, i, n) {
                for (var s = [], o = 0; o < i.length; ++o) s.push(this.createUploadTask(i[o], SYNO.SDS.Drive.Utils.getDragItem(i, n, o), {
                    appWindow: e,
                    path: t
                }));
                Promise.all(s).then(function(t) {
                    var i;
                    if (1 < t.length) i = String.format(SYNO.SDS.Drive._T("task", "upload_multi_start"), t.length);
                    else {
                        var n = Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(t[0].name).toString());
                        i = String.format(SYNO.SDS.Drive._T("task", "upload_start"), String.format('"{0}"', n))
                    }
                    SYNO.SDS.Drive.Utils.showToastMsg(e, i), e.getTaskMgr().addTasks(t)
                }).catch(function(t) {
                    SYNO.Debug.error(t), SYNO.SDS.Drive.Utils.showAlertMsg(e, _T("error", "error_error"))
                })
            },
            createUploadFromNasTask: function(e, t, i) {
                var n = this.creatBackgroundTaskInstance({
                        action: "upload_from_dsm",
                        title: "upload",
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: "upload_files_from_nas",
                        showProgress: !0,
                        hasProgress: !0,
                        delayProgress: 3e3,
                        params: {
                            path: e,
                            dsm_paths: t,
                            conflict_action: "version"
                        },
                        name: i
                    }),
                    s = function(e, t, i) {
                        n.appWindow.getEventMgr().fireEvent("createnodedone", t, i, e.params), n.un("onfinish", s)
                    };
                return n.on("onfinish", s), n
            },
            createEmptyRecycleTask: function(e, t) {
                var i = this.creatBackgroundTaskInstance({
                        action: "empty_recycle_bin",
                        title: "empty_recycle_bin",
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: "empty_recycle_bin",
                        showProgress: !0,
                        hasProgress: !1,
                        delayProgress: 3e3,
                        params: {
                            path: e
                        },
                        name: t
                    }),
                    n = function(e, t) {
                        i.appWindow.getEventMgr().fireEvent("cleannodedone", !0, t, e.params), i.un("onsuccess", n)
                    };
                return i.on("onsuccess", n), i
            },
            createBgTask: function(e, t) {
                var i = String.format("{0}_files", e.title),
                    n = String.format("{0}nodedone", e.title);
                "move" === e.title && e.params && e.params.change_name && (e.title = "rename");
                var s = Ext.apply({
                        action: e.title,
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: i,
                        showProgress: !0,
                        hasProgress: !0,
                        delayProgress: 3e3
                    }, e || {}),
                    o = this.creatBackgroundTaskInstance(s),
                    r = function(e, i, s) {
                        o.appWindow.getEventMgr().fireEvent(n, i, s, e.params, t), o.un("onfinish", r)
                    };
                return o.on("onfinish", r), o
            },
            creatBackgroundTaskInstance: function(e) {
                return "move" === e.action || "copy" === e.action ? new SYNO.SDS.Drive.Task.Background.MVCP(e) : "convert_office" === e.action ? new SYNO.SDS.Drive.Task.Background.ConvertOffice(e) : new SYNO.SDS.Drive.Task.Background.Base(e)
            },
            createDownloadBgTask: function(e, t, i) {
                var n = this.creatBackgroundTaskInstance(Ext.apply({
                        action: e.title,
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: t,
                        showProgress: !0,
                        hasProgress: !0,
                        delayProgress: 3e3
                    }, e || {})),
                    s = function(e, t) {
                        t && t.task_id && t.result && (SYNO.SDS.Drive.WebAPICore.download("download_files", {
                            task_id: t.task_id
                        }, t.result.archive_name), n.un("onsuccess", s), n.un("onerror", s))
                    };
                return n.on("onsuccess", s), n.on("onerror", s), n
            },
            createConvertBgTask: function(e) {
                var t = this.creatBackgroundTaskInstance(Ext.apply({
                        action: "convert_office",
                        title: "convert_office",
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: "convert_office",
                        showProgress: !0,
                        hasProgress: !0,
                        delayProgress: 3e3
                    }, e)),
                    i = function(e, n) {
                        t.appWindow.getEventMgr().fireEvent("convertofficedone", !0, n, e.params, e.name[0]), t.un("onsuccess", i)
                    };
                return t.on("onsuccess", i), t
            },
            createRestoreBgTask: function(e) {
                var t = this.creatBackgroundTaskInstance(Ext.apply({
                        action: "restore",
                        title: "restore",
                        appWindow: SYNO.SDS.Drive.GetWindow(),
                        webapi: "restore_revisions",
                        showProgress: !0,
                        hasProgress: !0,
                        delayProgress: 3e3
                    }, e)),
                    i = function(e, n) {
                        t.appWindow.getEventMgr().fireEvent("restorenodedone", !0, n, e.params, e.name[0]), t.un("onsuccess", i)
                    };
                return t.on("onsuccess", i), t
            }
        }
    }), Ext.define("SYNO.SDS.Drive.HybridShare.OffloadDownloader", {
        statics: {
            FILE_SIZE_HARD_LIMIT: 5368709120,
            FILE_SIZE_DEFAULT_LIMIT: 1073741824,
            FILE_SIZE_DEFAULT_LIMIT_FOR_IE: 104857600,
            FILE_SIZE_THRESHOLD_FOR_USING_FILE_SYSTEM: 1073741824,
            TYPE_NONE: 0,
            TYPE_MEM: 1,
            TYPE_FS: 2,
            CHARACTERS: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
        },
        constructor: function(e) {
            this.appWindow = e.appWindow, this.dispatcher = new SYNO.SDS.Drive.HybridShare.TaskDispatcher(Ext.apply(e, {
                offloadDownloader: this
            })), this._checkResumableTask()
        },
        download: function(e, t) {
            var i = {};
            i.files = [SYNO.SDS.Drive.Utils.getPathId(e.data.file_id)], i.force_download = !0, i.json_error = !0, t || (i.c2_offload = Ext.isIE || Ext.isIE11 ? "force" : "allow");
            var n = function() {
                this.download(e, !0)
            }.bind(this);
            if (SYNO.SDS.Drive.Utils.showToastMsg(this.appWindow, SYNO.SDS.Drive._T("common", "preparing_download"), 3e3), t || !Ext.isIE && !Ext.isIE11) return void SYNO.SDS.Drive.WebAPICore.download("download_files", i, e.data.name, function(e, i) {
                var s;
                try {
                    s = Ext.decode(i.contentDocument.body.firstChild.textContent).data
                } catch (e) {}
                if (!(s = s || e) || !s.file || !s.chunks || 0 === s.chunks.length) return void(t ? SYNO.SDS.Drive.Utils.showErrorMsg(this.appWindow, s) : n());
                this._startDownloadTask(s.file, s.chunks) || n()
            }.bind(this));
            SYNO.SDS.Drive.WebAPICore.sendPromise("download_files", i).then(function(e) {
                if (!e || !e.file || !e.chunks || 0 === e.chunks.length) return void n();
                this._startDownloadTask(e.file, e.chunks) || n()
            }.bind(this)).catch(n)
        },
        isOffloadSupport: function(e) {
            if (SYNO.SDS.Drive.Utils.isMobile()) return !1;
            if (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) return !1;
            if (Ext.isIE || Ext.isIE11) return !1;
            if (!SYNO.SDS.Drive.Crypto.Utils.isCryptoSupport()) return !1;
            if (1 !== e.length) return !1;
            var t = !1,
                i = !1,
                n = !1;
            return Ext.each(e, function(e) {
                return "dir" === e.data.type ? (t = !0, !1) : SYNO.SDS.Drive.Utils.isOfficeFile(e.data.name) ? (i = !0, !1) : e.data.removed ? (n = !0, !1) : void 0
            }), !(t || i || n) && this._checkDownloadType(e[0].data.size) !== SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_NONE
        },
        _checkResumableTask: function() {
            setTimeout(function() {
                if (!SYNO.SDS.Drive.WindowHelper.isPublicShare() && this._isSupportFileSystemAPI()) {
                    var e = SYNO.SDS.Drive.HybridShare.FileInfo.fetchFileInfos();
                    if (e.resumableList.length > 0) {
                        var t = e.resumableList[0];
                        this._resumeDownload(t)
                    }
                }
            }.bind(this), 1500)
        },
        _resumeDownload: function(e) {
            var t = function() {
                    e.updateProgress(SYNO.SDS.Drive.HybridShare.FileInfo.STATUS_DELETE, !0)
                },
                i = this._startResumeDownloadTask.bind(this),
                n = this.appWindow;
            SYNO.SDS.Drive.FileSystem.FileManger.checkFileExist(e.tmpFileName).then(function(i) {
                if (!i) return void t();
                var n = {};
                return n.files = [SYNO.SDS.Drive.Utils.getPathId(e.file.file_id)], n.force_download = !0, n.json_error = !0, n.c2_offload = "force", SYNO.SDS.Drive.WebAPICore.sendPromise("download_files", n)
            }).then(function(s) {
                return s && s.file && s.chunks && 0 !== s.chunks.length ? e.file.hash !== s.file.hash || e.file.name !== s.file.name ? void t() : void n.getMsgBox({
                    preventDelay: !0
                }).confirm("", String.format(SYNO.SDS.Drive._T("task", "download_from_remote_resume"), Ext.util.Format.htmlEncode(e.file.name)), function(n) {
                    "yes" === n ? (e.file = s.file, e.chunkInfos = SYNO.SDS.Drive.HybridShare.ChunkInfo.convertToChunkInfos(s.chunks), i(e)) : t()
                }) : void t()
            }).catch(t)
        },
        _startResumeDownloadTask: function(e) {
            var t = this._requestDownloadTask(e, SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_FS),
                i = SYNO.SDS.Drive.TaskFactory.createHybridShareDownloadTask(this.appWindow, e.file.name, t, this.dispatcher);
            this.appWindow.getTaskMgr().addTask(i)
        },
        _isSupportFileSystemAPI: function() {
            return SYNO.SDS.Drive.FileSystem.FileManger.isSupportFileSystemAPI()
        },
        _startDownloadTask: function(e, t) {
            var i = this._genRandomStr(),
                n = SYNO.SDS.Drive.HybridShare.ChunkInfo.convertToChunkInfos(t),
                s = new SYNO.SDS.Drive.HybridShare.FileInfo(i, e, n),
                o = this._requestDownloadTask(s);
            if (!o) return !1;
            var r = SYNO.SDS.Drive.TaskFactory.createHybridShareDownloadTask(this.appWindow, e.name, o, this.dispatcher);
            return this.appWindow.getTaskMgr().addTask(r), !0
        },
        _requestDownloadTask: function(e, t) {
            var i = t || this._checkDownloadType(e.file.size);
            return i === SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_MEM ? new SYNO.SDS.Drive.HybridShare.Memory.DownloadTask({
                appWindow: this.appWindow,
                fileInfo: e
            }) : i === SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_FS ? new SYNO.SDS.Drive.HybridShare.FileSystem.DownloadTask({
                appWindow: this.appWindow,
                fileInfo: e
            }) : void 0
        },
        _checkDownloadType: function(e) {
            var t = this.appWindow.appInstance.getUserSettings("offload_setting");
            if (t && -1 !== ["disable", "file_system", "memory"].indexOf(t)) return "disable" === t ? SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_NONE : "file_system" === t && this._isSupportFileSystemAPI() ? SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_FS : SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_MEM;
            if (e >= SYNO.SDS.Drive.HybridShare.OffloadDownloader.FILE_SIZE_HARD_LIMIT) return SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_NONE;
            var i = Ext.isIE || Ext.isIE11 ? SYNO.SDS.Drive.HybridShare.OffloadDownloader.FILE_SIZE_DEFAULT_LIMIT_FOR_IE : SYNO.SDS.Drive.HybridShare.OffloadDownloader.FILE_SIZE_DEFAULT_LIMIT,
                n = navigator.deviceMemory;
            return n && n > 0 && (i = 1024 * n * 1024 * 1024 * .25), e > i && !this._isSupportFileSystemAPI() ? SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_NONE : e > SYNO.SDS.Drive.HybridShare.OffloadDownloader.FILE_SIZE_THRESHOLD_FOR_USING_FILE_SYSTEM && this._isSupportFileSystemAPI() ? SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_FS : SYNO.SDS.Drive.HybridShare.OffloadDownloader.TYPE_MEM
        },
        _genRandomStr: function() {
            for (var e = "", t = SYNO.SDS.Drive.HybridShare.OffloadDownloader.CHARACTERS, i = t.length, n = 0; n < 10; n++) e += t.charAt(Math.floor(Math.random() * i));
            return e
        }
    }), Ext.ns("SYNO.SDS.Drive"), Ext.define("SYNO.SDS.Drive.PasswordPanel", {
        extend: "Ext.Container",
        constructor: function(e) {
            var t = e.title,
                i = e.prompt,
                n = {
                    cls: "syno-d-passwd-background",
                    xtype: "container",
                    layout: {
                        type: "vbox",
                        align: "center",
                        pack: "center"
                    },
                    items: [{
                        xtype: "container",
                        cls: "syno-d-passwd-container",
                        items: [new Ext.BoxComponent({
                            cls: "syno-d-passwd-title",
                            html: t
                        }), {
                            xtype: "container",
                            layout: "border",
                            cls: "syno-d-passwd-container-panel",
                            items: [{
                                region: "north",
                                border: !1,
                                cls: "syno-d-passwd-north-box",
                                layout: {
                                    type: "vbox",
                                    align: "center",
                                    pack: "center"
                                },
                                items: [{
                                    xtype: "box",
                                    cls: "syno-d-passwd-icon",
                                    width: 128,
                                    height: 128
                                }, {
                                    xtype: "syno_displayfield",
                                    cls: "syno-d-passwd-desc",
                                    value: i
                                }]
                            }, this.form = new Ext.form.FormPanel({
                                region: "center",
                                xtype: "form",
                                cls: "syno-d-passwd-form",
                                border: !1,
                                layout: {
                                    type: "vbox",
                                    align: "center",
                                    pack: "center"
                                },
                                items: [this.getPassField(), {
                                    xtype: "box",
                                    cls: "syno-d-passwd-margin-box"
                                }, this.getSubmitBtn()]
                            }), this.errMsgBox = new Ext.BoxComponent({
                                region: "south",
                                cls: "syno-d-passwd-error",
                                height: 24
                            })]
                        }]
                    }]
                };
            Ext.apply(n, e), this.callParent([n]), this.mon(this, "afterlayout", this.afterApplyLayout, this, {
                single: !0
            }), this.owner && this.mon(this.owner, "show", this.afterShow, this, {
                single: !0
            })
        },
        getPassField: function() {
            return this.passField ? this.passField : (this.passField = new SYNO.ux.TextField({
                cls: "syno-d-passwd-pass",
                emptyText: _T("common", "password"),
                textType: "password",
                enableKeyEvents: !0,
                hideLabel: !0,
                listeners: {
                    scope: this,
                    keydown: this.onKeyDown
                }
            }), this.passField)
        },
        onKeyDown: function(e, t) {
            Ext.EventObject.ENTER === t.getKey() && this.onSubmit()
        },
        afterApplyLayout: function() {
            this.items.items[0].addClass("syno-d-passwd-container-anim")
        },
        afterShow: function() {
            this.passField.focus(!1, 300)
        },
        validateAsync: function() {
            return Promise.resolve()
        },
        getSubmitBtn: function(e) {
            return this.submitBtn || (this.submitBtn = new SYNO.ux.Button({
                cls: "syno-d-passwd-btn",
                xtype: "syno_button",
                btnStyle: "default",
                text: _T("common", "enter"),
                scope: this,
                disabled: e,
                handler: this.onSubmit
            }))
        },
        setFormDisabled: function(e) {
            this.passField.setDisabled(e), this.submitBtn.setDisabled(e)
        },
        setError: function(e) {
            this.errMsgBox.show(), this.errMsgBox.update(e), this.doLayout();
            var t = this.passField;
            t.markInvalid(), t.focus(), t.selectText(0, t.getValue().length)
        },
        setPassword: function(e) {
            this.passField.setRawValue(e)
        },
        onValidateError: Ext.emptyFn,
        onValidateSuccess: Ext.emptyFn,
        onSubmit: function() {
            this.errMsgBox.hide(), this.setFormDisabled(!0), this.passField.clearInvalid(), this.validateAsync().then(this.onValidateSuccess.bind(this)).catch(this.onValidateError.bind(this))
        }
    }), Ext.define("SYNO.SDS.Drive.Share.AdvancedPasswordPanel", {
        extend: "SYNO.SDS.Drive.PasswordPanel",
        constructor: function(e) {
            this.callParent([Ext.apply({
                title: SYNO.SDS.Drive._T("share", "protected_title"),
                prompt: SYNO.SDS.Drive._T("share", "protected_prompt")
            }, e)])
        },
        validateAsync: function() {
            return new Promise(function(e, t) {
                this.findAppWindow().getWebAPI().checkAdvSharingPassword({
                    params: {
                        sharing_link: window.getDriveSharingLink(),
                        password: this.passField.getValue()
                    },
                    callback: function(i, n) {
                        (i ? e : t)(n)
                    },
                    scope: this
                })
            }.bind(this))
        },
        onValidateError: function(e) {
            this.setFormDisabled(!1), this.setError(SYNO.SDS.Drive.Utils.getErrorStr(e))
        },
        onValidateSuccess: function(e) {
            location.reload(!0)
        }
    }), Ext.define("SYNO.SDS.Drive.ModalWindow", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(e) {
            var t = Ext.isString(e.cls) ? e.cls + " syno-d-modal-window" : "syno-d-modal-window";
            e.cls = t;
            var i = [{
                key: Ext.EventObject.ENTER,
                scope: this,
                fn: this.onEnter
            }];
            e.keys ? Ext.isArray(e.keys) ? e.keys = e.keys.concat(i) : Ext.isObject(e.keys) && (e.keys = i.push(e.keys)) : e.keys = i, this.callParent([Ext.apply(this.fillWindowPadding({
                owner: SYNO.SDS.Drive.GetWindow(),
                closable: !0,
                closeAction: "onCancel",
                bodyBorder: !1,
                border: !1,
                width: 560
            }), e)]), this.mon(this, "show", this.onWinShow, this)
        },
        afterShow: function() {
            SYNO.SDS.ModalWindow.superclass.afterShow.apply(this, arguments), !0 !== this.avoidMasked && !this.ownerMasked && this.owner && (this.owner.modalWin.push(this), this.owner.mask(), this.ownerMasked = !0)
        },
        checkEnterTarget: function(e) {
            return "TEXTAREA" === e.getTarget().tagName
        },
        onEnter: function(e, t) {
            this.maskCnt || this.checkEnterTarget(t) || (t.stopEvent(), this.onApply())
        },
        setStatus: function(e) {
            e.duration && window.setTimeout(function() {
                this.clearStatus()
            }.bind(this), e.duration), this.callParent(arguments)
        },
        onApply: Ext.emptyFn,
        onCancel: function() {
            this.close()
        },
        onWinShow: function() {}
    }), Ext.ns("SYNO.SDS.Drive.Mail"), Ext.define("SYNO.SDS.Drive.Mail.Template", {
        statics: {
            get: function(e, t, i, n, s, o) {
                var r = "",
                    a = i;
                return o || (o = ""), r = "<html><head><style>.syno-o-file:hover{color:#0B8BE5;}.syno-o-file:active{color:#007ED9;}.syno-o-btn:hover{border-color:#13ACBA;background-color:#2AC6D4;}.syno-o-btn:active{border-color:#0093A1;background-color:#13ACBA;}</style></head><body>", r += "<div style='width:95%;width:calc(100% - 64px);min-width:704px;padding:24px 32px 16px 32px;background-color:#ECEEF0;text-align:center;'><div style='display:inline-block;max-width:720px;min-width:640px;text-align:left;font-family:Arial,Verdana,Helvetica,sans-serif;box-shadow:0 1px 4px rgba(0,0,0,0.1);'>\r\n<div style='padding:28px;background:#fff;'><div style='font-size:13px;line-height:20px;color:#2E3032;'><b>", r += e, r += "</b>&nbsp;" + t, r += "</div><div style='height:12px;'></div><div style='font-size:18px;display:table;'><div style='display:table-row;height:30px;'><span style='display:table-cell;vertical-align:middle;'>\r\n<img src='data:image/png;base64,", n && (r += n), r += "' style='vertical-align:middle;height:24px;width:24px;'/></span>\r\n<span style='display:table-cell;padding-left:8px;vertical-align:middle;'><a class='syno-o-file' href='", r += i, r += "' style='color:#30A1F2;vertical-align:middle;text-decoration:none;'>", r += "{0}", r += "</a></span></div></div>\r\n", o ? (r += "<div style='height:24px;'></div><div style='border-left:3px solid #CED0D2;' dir='ltr'><span style='display:inline-block;padding-left:8px;'>", r += "{1}", r += "</span></div>\r\n") : r += "{1}", r += "\r\n<div style='height:32px;'></div><div><a class='syno-o-btn' href='", r += a, r += "' target='_blank' style='background-color:#1EB9C7;border:1px solid #09A0AD;border-radius:3px;color:white;display:inline-block;font-family:Arial,Verdana,Helvetica,sans-serif;font-size:13px;height:28px;line-height:28px;min-width:50px;outline:0px;padding:0 14px;text-align:center;text-decoration:none'>", r += "{2}", r += "</a>\r\n</div></div></div><div style='padding:16px 8px 0 8px;width:100%;text-align:center;font-size:13px;color:#7E8082;line-height:24px;'>", r += "{3}", r += "</div></div></body></html>", String.format(r, Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(s)), Ext.util.Format.htmlEncode(o), SYNO.SDS.Drive._T("action", "open"), SYNO.SDS.Drive._T("drive", "displayname"))
            }
        }
    }), Ext.define("SYNO.SDS.Drive.MailDialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            this.contactCacheData = {};
            var t = this.fillConfig(e);
            this.callParent([t]), this.mon(this, "afterlayout", this.onLoadData, this, {
                single: !0
            })
        },
        fillConfig: function(e) {
            var t = {
                width: 600,
                height: 412,
                title: _T("mail", "application_title"),
                cls: "syno-d-mail-dlg",
                buttons: [{
                    text: _T("common", "cancel"),
                    handler: this.onClose,
                    scope: this
                }, {
                    btnStyle: "default",
                    itemId: "submit_button",
                    text: _T("common", "send"),
                    handler: this.onBeforeConfirm,
                    scope: this
                }],
                items: this.initPanel(),
                listeners: {
                    beforeclose: this.onClose,
                    scope: this
                }
            };
            return SYNO.SDS.CSTN.IsDSM7OrAbove() || t.buttons.reverse(), Ext.apply(t, e)
        },
        initPanel: function() {
            this.store = new Ext.data.JsonStore({
                fields: ["name", "address"],
                data: [],
                sortInfo: {
                    field: "address",
                    direction: "ASC"
                }
            }), this.addManagedComponent(this.store);
            var e = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item" style="height: 53px"><div style="margin-left:10px"><tpl if="name!=address;"><div style="height:20px;margin-top:4px;font-weight:bold;">{name:htmlEncode}</div></tpl><div class="syno-mail-contactaccount">{address:htmlEncode}</div></div></div></tpl>'),
                t = new Ext.XTemplate('<tpl if"name!=null && name!=&quot;&quot;";>{name:htmlEncode}</tpl><tpl if="name==null || name==&quot;&quot;">{address:htmlEncode}</tpl>'),
                i = function(e) {
                    var t = new RegExp("^" + e.query + "|\\s+" + e.query, "gi");
                    return this.store.filterBy(function(e) {
                        return !(!e.data.name || null === e.data.name.match(t)) || !(!e.data.address || null === e.data.address.match(t))
                    }), e.combo.onLoad(), !1
                },
                n = function(e, t) {
                    "" !== t && e.validateValue(t) && e.addNewItem({
                        name: t,
                        address: t
                    }, !0)
                },
                s = [{
                    xtype: "syno_superboxselect",
                    fieldLabel: _T("mail", "mail_to_desc"),
                    expandBtnCls: "syno-d-mail-dlg-superboxselect-expand",
                    itemId: "mail_to_field",
                    hideTrigger: !0,
                    typeAhead: !1,
                    allowBlank: !1,
                    displayField: "name",
                    displayFieldTpl: t,
                    valueField: "address",
                    allowAddNewData: !0,
                    addNewDataOnBlur: !0,
                    mode: "local",
                    tpl: e,
                    vtype: "email",
                    blankText: _JSLIBSTR("extlang", "emailText"),
                    listeners: {
                        newitem: n,
                        beforequery: i,
                        scope: this
                    },
                    store: this.store
                }, {
                    xtype: "syno_superboxselect",
                    fieldLabel: _T("mail", "mail_cc_desc"),
                    itemId: "mail_cc_field",
                    expandBtnCls: "syno-d-mail-dlg-superboxselect-expand",
                    hideTrigger: !0,
                    typeAhead: !0,
                    displayField: "name",
                    displayFieldTpl: t,
                    valueField: "address",
                    allowAddNewData: !0,
                    addNewDataOnBlur: !0,
                    mode: "local",
                    tpl: e,
                    vtype: "email",
                    blankText: _JSLIBSTR("extlang", "emailText"),
                    listeners: {
                        newitem: n,
                        beforequery: i,
                        scope: this
                    },
                    store: this.store
                }, {
                    xtype: "syno_textfield",
                    fieldLabel: _T("mail", "mail_subject"),
                    itemId: "mail_subject"
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-mail-dlg-shared-file",
                    fieldLabel: SYNO.SDS.Drive._T("mail", "shared_file"),
                    htmlEncode: !1,
                    itemId: "shared_file",
                    listeners: {
                        scope: this,
                        single: !0,
                        render: function(e) {
                            var t = e.getEl();
                            this.mon(e.getEl(), "click", function(e) {
                                t.hasClass("x-item-disabled") || window.open(this.url, "_blank")
                            }, this)
                        }
                    }
                }, {
                    xtype: "syno_textarea",
                    fieldLabel: SYNO.SDS.Drive._T("mail", "additional_msg"),
                    itemId: "texteditor",
                    height: 130,
                    grow: !0,
                    growMin: 130,
                    growMax: 130
                }],
                o = {
                    trackResetOnLoad: !0,
                    autoHeight: !0,
                    defaults: {
                        anchor: "100%"
                    },
                    items: s
                },
                r = new SYNO.ux.FormPanel(o);
            return this.panel = r, r
        },
        onSetData: function(e, t) {
            this.data = e, this.url = t;
            var i = e.name,
                n = String.format('<span class="{0}"></span>', SYNO.SDS.Drive.FileType.getMappingTypeCss("dir" === e.type ? "folder" : SYNO.SDS.Drive.Utils.getExt(i), 16));
            i = SYNO.SDS.Drive.Utils.parseDisplayName(e.name);
            var s = Ext.util.Format.htmlEncode(i),
                o = Ext.util.Format.htmlEncode(s);
            this.panel.getForm().setValues({
                shared_file: n + '<span class="syno-d-file-name" ext:qtip="' + o + '">' + s + "</span>",
                mail_subject: String.format(SYNO.SDS.Drive._T("mail", "subject"), i)
            })
        },
        onBeforeConfirm: function() {
            return "" === this.panel.getComponent("mail_to_field").getValue() ? void this.getMsgBox().alert("", _T("mail", "mailto_alert")) : "" === this.panel.getComponent("mail_subject").getValue() ? void this.getMsgBox().confirm("", _T("mail", "mail_subject_alert"), function(e) {
                "yes" === e && this.onConfirm()
            }, this) : void this.onConfirm()
        },
        onConfirm: function() {
            var e = this.panel.getComponent("mail_to_field").getValue().split(","),
                t = this.panel.getComponent("mail_cc_field").getValue(),
                i = this.panel.getComponent("mail_subject").getValue(),
                n = this.panel.getComponent("texteditor").getValue(),
                s = this.getTemplate(this.url, this.data, n),
                o = {
                    to: Ext.encode(e),
                    subject: i,
                    body: s
                };
            Ext.isEmpty(t) || (o.cc = Ext.encode(t.split(","))), this.onSendMail(o)
        },
        onSendMail: function(e) {
            this.setStatusBusy(), this.sendWebAPI({
                api: "SYNO.Personal.MailAccount.Mail",
                method: "send",
                version: 1,
                params: Ext.apply(e, {
                    background: !1
                }),
                callback: function(e, t, i) {
                    if (this.clearStatusBusy(), e) this.doClose();
                    else {
                        var n = SYNO.SDS.Drive.MailDialog.Utils.APIErrorGet(t.code);
                        this.getMsgBox().alert("", n)
                    }
                },
                scope: this
            })
        },
        onLoadData: function() {
            var e = [];
            e.push({
                api: "SYNO.Personal.MailAccount",
                method: "get",
                version: 1
            }), e.push({
                api: "SYNO.Personal.MailAccount.Contacts",
                method: "list",
                version: 1
            }), this.setStatusBusy(), this.sendWebAPI({
                params: {},
                compound: {
                    params: e
                },
                scope: this,
                callback: function(e, t, i, n) {
                    if (this.clearStatusBusy(), !e) return void this.getMsgBox().alert("", SYNO.SDS.Drive.MailDialog.Utils.APIErrorGet(SYNO.API.Util.GetFirstError(t)), function() {
                        this.doClose()
                    }, this);
                    this.setAccountData(t.result)
                }
            })
        },
        setAccountData: function(e) {
            var t, i;
            if (e[0].error) {
                var n = SYNO.SDS.Drive.MailDialog.Utils.APIErrorGet(e[0].error.code);
                return void this.getMsgBox().alert("", n, function() {
                    this.doClose()
                }, this)
            }
            if (t = e[0].data.data, 0 === t.length) return void this.getMsgBox().alert("", SYNO.SDS.Drive._T("mail", "setup_up"), function(e) {
                this.doClose()
            }, this);
            e[1].error || (i = e[1].data.result, this.contactCacheData[this.alias] = i, this.store.loadData(i, !0))
        },
        onClose: function() {
            return this.panel.getForm().isDirty() ? (this.getMsgBox().confirm("", _T("mail", "mail_leave_desc"), function(e) {
                "yes" === e && this.doClose()
            }, this), !1) : void this.doClose()
        },
        getTemplate: function(e, t, i) {
            var n, s = t.name,
                o = t.type,
                r = SYNO.SDS.Drive._T;
            if ("dir" === o) n = r("mail", "share_dir");
            else if (SYNO.SDS.Drive.Utils.isOfficeFile(s)) switch (SYNO.SDS.Drive.Utils.getExt(s)) {
                case SYNO.SDS.Drive.FileType.SYNODOC:
                    n = r("mail", "share_doc");
                    break;
                case SYNO.SDS.Drive.FileType.SYNOSHEET:
                    n = r("mail", "share_sheet");
                    break;
                case SYNO.SDS.Drive.FileType.SYNOSLIDE:
                    n = r("mail", "share_slide");
                    break;
                default:
                    n = r("mail", "share_file")
            } else n = r("mail", "share_file");
            return SYNO.SDS.Drive.Mail.Template.get(_S("user"), n, e, SYNO.SDS.Drive.FileType.getBase64Img(o, s), s, i)
        }
    }), Ext.ns("SYNO.SDS.Drive.MailDialog.Utils"), Ext.apply(SYNO.SDS.Drive.MailDialog.Utils, {
        APIErrorGet: function(e) {
            switch (e) {
                case 116:
                    return _JSLIBSTR("uicommon", "error_demo");
                case 8001:
                case 8002:
                case 8003:
                case 8004:
                    return _T("error", "error_error_system");
                case 8005:
                    return _T("error", "error_privilege_not_enough");
                case 8006:
                case 8007:
                case 8008:
                case 8009:
                case 8010:
                case 8011:
                    return _T("error", "error_error_system");
                case 8012:
                    return _T("mail", "sync_expire");
                case 8013:
                default:
                    return _T("error", "error_error_system")
            }
        }
    }),
    function() {
        var e = function(e) {
            var t = this.activeTarget;
            if (t) {
                if (this.rendered || (this.render(Ext.getBody()), this.activeTarget = t), t.width ? (this.setWidth(t.width), this.measureWidth = !1) : (this.setWidth("auto"), this.body.setWidth("auto")), this.setTitle(t.title || ""), Ext.isString(t.tipContents)) t.width && this.body.setWidth(this.adjustBodyWidth(t.width)), this.body.setStyle("max-width", this.maxWidth + "px"), this.body.hasClass("text-only") || this.body.addClass("text-only"), this.body.update(t.tipContents), this.mon(this, "beforehide", this.removeStyle, this, {
                    single: !0
                });
                else if (Ext.isArray(t.tipContents)) this.body.update(""), Ext.each(t.tipContents, function(e) {
                    e.rendered ? this.body.appendChild(e.el) : e.render(this.body), e.show(), this.mon(this, "beforehide", this.moveItemToBody.bind(this, e), this, {
                        single: !0
                    })
                }, this);
                else if (Ext.isObject(t.tipContents)) {
                    this.body.update("");
                    var i = t.tipContents;
                    i.rendered ? this.body.appendChild(i.el) : i.render(this.body), i.show(), this.mon(this, "beforehide", this.moveItemToBody.bind(this, i), this, {
                        single: !0
                    })
                }
                this.autoHide = t.autoHide, this.dismissDelay = t.dismissDelay || this.dismissDelay, this.lastCls && (this.el.removeClass(this.lastCls), delete this.lastCls), t.cls && (this.el.addClass(t.cls), this.lastCls = t.cls), this.anchor ? this.constrainPosition = !1 : t.align ? (this.el.show(), e = this.el.getAlignToXY(t.el, t.align), this.constrainPosition = !1) : this.constrainPosition = !0
            }
            Ext.QuickTip.superclass.showAt.call(this, e)
        };
        Ext.isDefined(SYNO.ux.WhiteQuickTip) ? SYNO.ux.WhiteQuickTip.prototype.showAt = e : (Ext.define("SYNO.ux.WhiteQuickTip", {
            extend: "Ext.QuickTip",
            xtype: "syno_whitequicktip",
            floating: {
                shadow: !1,
                shim: !0,
                useDisplay: !0,
                constrain: !1
            },
            tagConfig: {
                namespace: "ext",
                attribute: "wtip",
                width: "wwidth",
                target: "target",
                title: "qtitle",
                hide: "hide",
                cls: "iclass",
                align: "qalign",
                anchor: "anchor"
            },
            dismissDelay: 0,
            initComponent: function() {
                this.callParent(arguments), this.addEvents("click")
            },
            onRender: function() {
                this.callParent(arguments), this.mon(this.el, "mouseover", this.onSelfMouseOver, this), this.mon(this.el, "mouseout", this.onSelfMouseOut, this), this.mon(this.el, "mousemove", this.onSelfMouseMove, this), this.mon(this.el, "click", this.fireClickEvent, this);
                var e = this.field;
                e instanceof SYNO.ux.DisplayField && e.initValue()
            },
            fireClickEvent: function() {
                this.fireEvent("click", [this].concat(arguments))
            },
            onSelfMouseOver: function(e) {
                this.clearTimer("hide")
            },
            onSelfMouseOut: function() {
                this.clearTimer("show"), !1 !== this.autoHide && this.delayHide(1)
            },
            onSelfMouseMove: function() {
                this.clearTimer("hide")
            },
            delayHide: function(e) {
                this.hidden || this.hideTimer || (this.hideTimer = this.hide.defer(e || this.hideDelay, this))
            },
            getTipCfg: function(e) {
                var t, i, n = e.getTarget();
                if (this.interceptTitles && n.title && Ext.isString(n.title)) t = n.title, n.wtip = t, n.removeAttribute("title"), e.preventDefault();
                else if (i = this.tagConfig, t = n.wtip || Ext.fly(n).getAttribute(i.attribute, i.namespace), Ext.isEmpty(t) && n.wtip_items || Ext.fly(n).getAttribute("wtip_items", i.namespace)) {
                    var s = n.id,
                        o = Ext.getCmp(s);
                    t = o ? o.tipItems : void 0
                }
                return t
            },
            doAutoWidth: Ext.emptyFn,
            onTargetOver: function(e) {
                if (!this.disabled) {
                    this.targetXY = e.getXY();
                    var t = e.getTarget();
                    if (t && 1 === t.nodeType && t != document && t != document.body) {
                        if (this.activeTarget && (t == this.activeTarget.el || Ext.fly(this.activeTarget.el).contains(t))) return this.clearTimer("hide"), void this.show();
                        if (t && this.targets[t.id]) return this.activeTarget = this.targets[t.id], this.activeTarget.el = t, this.anchor = this.activeTarget.anchor, this.anchor && (this.anchorTarget = t), void this.delayShow();
                        var i = this.getTipCfg(e),
                            n = Ext.fly(t),
                            s = this.tagConfig,
                            o = s.namespace;
                        if (i) {
                            var r = n.getAttribute(s.hide, o);
                            this.activeTarget = {
                                el: t,
                                tipContents: i,
                                width: n.getAttribute(s.width, o),
                                autoHide: "user" != r && "false" !== r,
                                title: n.getAttribute(s.title, o),
                                cls: n.getAttribute(s.cls, o),
                                align: n.getAttribute(s.align, o)
                            }, this.anchor = n.getAttribute(s.anchor, o), this.anchor && (this.anchorTarget = t), this.delayShow()
                        }
                    }
                }
            },
            showAt: e,
            removeStyle: function() {
                this.body.setStyle("max-width", "none"), this.body.removeClass("text-only")
            },
            moveItemToBody: function(e) {
                e.el.appendTo(Ext.getBody()), e.hide()
            }
        }), SYNO.ux.WhiteQuickTips = function() {
            var e, t = !1;
            return {
                init: function(i) {
                    if (!e) {
                        if (!Ext.isReady) return void Ext.onReady(function() {
                            SYNO.ux.WhiteQuickTips.init(i)
                        });
                        e = new SYNO.ux.WhiteQuickTip({
                            baseCls: "x-tip-white",
                            elements: "header,body",
                            disabled: t
                        }), !1 !== i && e.render(Ext.getBody())
                    }
                },
                ddDisable: function() {
                    e && !t && e.disable()
                },
                ddEnable: function() {
                    e && !t && e.enable()
                },
                enable: function() {
                    e && e.enable(), t = !1
                },
                disable: function() {
                    e && e.disable(), t = !0
                },
                isEnabled: function() {
                    return void 0 !== e && !e.disabled
                },
                getQuickTip: function() {
                    return e
                },
                register: function() {
                    e.register.apply(e, arguments)
                },
                unregister: function() {
                    e.unregister.apply(e, arguments)
                },
                tips: function() {
                    e.register.apply(e, arguments)
                }
            }
        }(), SYNO.ux.WhiteQuickTips.init(!0), Ext.define("SYNO.ux.WhiteTipIcon", {
            extend: "Ext.BoxComponent",
            constructor: function(e) {
                var t, i;
                if (e = e || {}, !(t = e.field)) throw "need field as render target!";
                var n = {
                    renderTo: Ext.getBody()
                };
                this.callParent([Ext.apply(n, e)]), this.addClass("syno-ux-whitetip-icon"), this.relayEvents(this.getTip(), ["click"]), i = t.rendered, i ? this.renderToField() : this.mon(t, "afterrender", this.renderToField, this)
            },
            renderToField: function() {
                var e = this.field,
                    t = this.getRenderTargetByField(e);
                t.isInsertBefore ? t.parent.insertBefore(this.el.dom, t.dom) : t.parent.appendChild(this.el.dom)
            },
            lookupComponent: function(e) {
                return Ext.isString(e) ? Ext.ComponentMgr.get(e) : e.events ? e : this.createComponent(e)
            },
            createComponent: function(e, t) {
                if (e.render) return e;
                var i = Ext.create(Ext.apply({
                    ownerCt: this
                }, e), t || this.defaultType);
                return delete i.initialConfig.ownerCt, delete i.ownerCt, i
            },
            getRenderTargetByField: function(e) {
                var t = {
                    isInsertBefore: !1,
                    dom: null,
                    parent: null
                };
                return e instanceof SYNO.ux.DisplayField ? t.parent = e.el : e instanceof SYNO.ux.Button && Ext.getDom(e.el).nextSibling ? (t.isInsertBefore = !0, t.parent = e.el.parent().dom, t.dom = e.el.dom.nextSibling) : e instanceof SYNO.ux.TextArea ? t.parent = e.el.dom.parentNode.parentNode : t.parent = e.el.dom.parentNode, t
            },
            adjustStyleForButton: function() {
                var e = this.field,
                    t = e.el.getStyle("margin-right");
                e.el.dom.nextSibling && "0px" !== t && (e.el.dom.style += " margin-right: 0px !important;", this.el.dom.style += " margin-right: 6px !important;")
            },
            addAriaAttr: function() {
                var e = this.field;
                e.el.set({
                    "aria-describedby": e.el.dom.getAttribute("aria-describedby") + " " + this.id
                })
            },
            onRender: function() {
                this.callParent(arguments), this.el.set({
                    "ext:wtip": this.message || "",
                    draggable: !1,
                    "ext:wwidth": this.tipWidth || ""
                }), Ext.isEmpty(this.tipItems) || (Ext.isArray(this.tipItems) ? this.tipItems = this.tipItems.map(function(e) {
                    return this.lookupComponent(e)
                }.bind(this)) : this.tipItems = this.lookupComponent(this.tipItems), this.el.set({
                    "ext:wtip_items": !0
                })), this.field instanceof SYNO.ux.Button && this.adjustStyleForButton(), this.addAriaAttr()
            },
            getTip: function() {
                return SYNO.ux.WhiteQuickTips.getQuickTip()
            },
            beforeDestroy: function() {
                Ext.isArray(this.tipItems) ? Ext.each(this.tipItems, function(e) {
                    e.destroy && e.destroy()
                }) : this.tipItems && this.tipItems.destroy && this.tipItems.destroy(), this.tipItems = null, this.field = null
            }
        }), SYNO.ux.AddWhiteTipWithMsg = function(e, t, i) {
            return new SYNO.ux.WhiteTipIcon({
                field: e,
                message: t,
                tipWidth: i
            })
        }, SYNO.ux.AddWhiteTipWithItem = function(e, t, i) {
            return new SYNO.ux.WhiteTipIcon({
                field: e,
                tipItems: t,
                tipWidth: i
            })
        }, SYNO.ux.AddTip = function(e, t, i) {
            var n = Ext.getCmp(e.id);
            return SYNO.ux.AddWhiteTipWithMsg(n, t, i || 480).el.dom
        })
    }(), Ext.define("SYNO.SDS.Drive.WhiteQuickTip", {
        extend: "Ext.BoxComponent",
        constructor: function(e) {
            var t = {
                cls: "syno-d-info-icon" + (e.lightIcon ? " syno-d-info-icon-light" : "") + (e.warningIcon ? " syno-d-info-icon-warning" : ""),
                tipItems: e.tipItems,
                width: 24
            };
            Ext.apply(t, e), this.callParent([t])
        },
        onRender: function() {
            this.callParent(arguments);
            var e = {
                draggable: !1,
                "ext:wtip_items": !0
            };
            this.tipWidth && (e["ext:wwidth"] = this.tipWidth), this.attrs && Ext.apply(e, this.attrs), this.el.set(e)
        }
    }), Ext.define("SYNO.SDS.Drive.Share.SharingInfo", {
        extend: "SYNO.ux.Panel",
        constructor: function(e) {
            e = e || {};
            var t = {
                cls: "syno-d-share-sharing-info",
                items: [{
                    xtype: "box",
                    html: String.format("<h2>{0}</h2>", SYNO.SDS.Drive._T("share", "role_permission_title"))
                }, new SYNO.SDS.Drive.Share.SharingInfoGrid]
            };
            Ext.apply(t, e), this.callParent([t])
        }
    }), Ext.define("SYNO.SDS.Drive.Share.SharingInfoGrid", {
        extend: "SYNO.ux.GridPanel",
        constructor: function(e) {
            var t = this,
                i = "preview,comment,download,upload,edit,delete,share".split(","),
                n = {
                    autoHeight: !0,
                    cls: "syno-d-share-sharing-info-grid",
                    enableHdMenu: !1,
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["role"].concat(i),
                        data: [
                            ["previewer", !0],
                            ["preview_commenter", !0, !0],
                            ["viewer", !0, !1, !0],
                            ["commenter"].concat(new Array(3).fill(!0)), ["editor"].concat(new Array(5).fill(!0)), ["manager"].concat(new Array(7).fill(!0))
                        ]
                    }),
                    view: new Ext.grid.GridView({
                        autoFill: !0,
                        disableTextSelect: !0
                    }),
                    cm: new Ext.grid.ColumnModel({
                        defaults: {
                            align: "center",
                            width: 85,
                            menuDisabled: !0,
                            sortable: !1,
                            resizable: !1
                        },
                        columns: [{
                            align: "left",
                            width: 180,
                            dataIndex: "role",
                            header: SYNO.SDS.Drive._T("share", "role"),
                            renderer: t._roleRenderer
                        }].concat(i.map(function(e) {
                            return {
                                dataIndex: e,
                                header: SYNO.SDS.Drive._T("perm", e),
                                tooltip: SYNO.SDS.Drive._T("perm", e),
                                renderer: t._checkRenderer
                            }
                        }))
                    })
                };
            Ext.apply(n, e), this.callParent([n])
        },
        _roleRenderer: function(e, t, i, n, s, o) {
            var r = SYNO.SDS.Drive._T("perm", e);
            return t.attr = 'ext:qtip="' + r + '"', r
        },
        _checkRenderer: function(e, t, i, n, s, o) {
            return e ? '<div class="syno-d-icon-check"></div>' : ""
        }
    }), Ext.define("SYNO.SDS.Drive.Share.FormPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            this.path = e.path, this.share_user = e.share_user, this.capabilities = e.capabilities, this.name = e.name, this.type = e.type, this.callParent([this.fillConfig(e)]), this.mon(this, "afterlayout", this.onLoadData, this, {
                single: !0
            })
        },
        fillConfig: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("share", "permission"),
                cls: "syno-d-share-formpanel",
                layout: "border",
                hideMode: "offsets",
                items: [this.getLinkFieldSet(), this.getShareToDsmUserCfg()],
                objectRole: {}
            };
            return Ext.apply(t, e)
        },
        getLinkRoleBtn: function() {
            if (this.linkRoleBtn) return this.linkRoleBtn;
            var e = this,
                t = SYNO.SDS.Drive._T,
                i = t("perm", "limit_desc");
            SYNO.SDS.Drive.Define.Info.sharing_permission.invite_sharing || (i = t("perm", "limit_you_desc"));
            var n = [{
                itemId: "na",
                text: "<b>" + t("perm", "limit") + "</b> - " + i
            }, "-", {
                itemId: "internal_viewer",
                text: "<b>" + t("perm", "app") + "</b> - " + t("perm", "app_ro_desc")
            }, {
                itemId: "internal_commenter",
                text: "<b>" + t("perm", "app") + "</b> - " + t("perm", "app_commenter_desc")
            }, {
                itemId: "internal_editor",
                text: "<b>" + t("perm", "app") + "</b> - " + t("perm", "app_rw_desc")
            }];
            return n.push({
                itemId: "public_viewer",
                text: "<b>" + t("perm", "public") + "</b> - " + t("perm", "public_ro_desc"),
                hidden: !0
            }, {
                itemId: "public_commenter",
                text: "<b>" + t("perm", "public") + "</b> - " + t("perm", "public_commenter_desc"),
                hidden: !0
            }, {
                itemId: "public_editor",
                text: "<b>" + t("perm", "public") + "</b> - " + t("perm", "public_rw_desc"),
                hidden: !0
            }), this.linkRoleBtn = new SYNO.ux.Button({
                ori_value: {
                    type: null,
                    role: null
                },
                displayRole: "na",
                htmlEncode: !1,
                height: 30,
                width: 504,
                hideLabel: !0,
                btnStyle: "grey",
                cls: "syno-d-combo-btn syno-d-link-role",
                text: n[0].text,
                menu: new SYNO.ux.Menu({
                    minWidth: 504,
                    defaults: {
                        htmlEncode: !1,
                        checked: !1
                    },
                    items: n,
                    listeners: {
                        scope: this,
                        itemclick: function(e) {
                            this.getLinkRoleBtn().setDisplayRole(e.itemId)
                        },
                        beforeshow: function(e) {
                            var t = this.getLinkRoleBtn().displayRole,
                                i = e.items;
                            i.each(function(e) {
                                e.setChecked && e.setChecked(e.itemId === t)
                            }), SYNO.SDS.Drive.Define.Info.sharing_permission.internal_link_sharing || (i.get("internal_editor").hide(), i.get("internal_viewer").hide(), i.get("internal_commenter").hide(), i.items[e.items.length - 7].hide())
                        },
                        show: function(e) {
                            var t = e.layout.container,
                                i = t.getEl();
                            t.getLayoutTarget().getWidth() + i.getFrameWidth("lr") < e.minWidth && t.setWidth(e.minWidth)
                        }
                    }
                }),
                initValue: function(t) {
                    var i = !1,
                        n = t.role;
                    t.role.match(/preview/) && (i = !0, n = {
                        previewer: "viewer",
                        preview_commenter: "commenter"
                    } [t.role]), this.ori_value = t, e.getLinkField().focus(!1, 2), this.setDisplayRole(("public" === t.type ? "public_" : "internal_") + n), e.getPreviewCheckbox().setValue(!i), e.getPreviewCheckbox().originalValue = !i
                },
                setDisplayRole: function(t) {
                    this.displayRole = t, this.menu.items.each(function(e) {
                        if (e.itemId === t) return this.setText(e.text), !1
                    }, this), e.doLayout(!1), t.match(/(viewer)|(commenter)/) ? e.getPreviewCheckbox().show() : (e.getPreviewCheckbox().setValue(!0), e.getPreviewCheckbox().hide()), e.doLayout(!1)
                },
                getOriValue: function() {
                    return this.ori_value
                },
                getValue: function() {
                    var t = this.displayRole;
                    if ("na" === t) return {
                        type: null,
                        role: null
                    };
                    var i = t.replace(/(public_)|(internal_)/, "");
                    return e.getPreviewCheckbox().getValue() || ("commenter" === i ? i = "preview_commenter" : "viewer" === i && (i = "previewer")), {
                        type: t.match(/public_/) ? "public" : "internal",
                        role: i
                    }
                },
                isDirty: function() {
                    var e = this.getValue();
                    return e.type !== this.ori_value.type || e.role !== this.ori_value.role
                },
                hideForOffice: function() {
                    this.menu && (this.menu.items.get("internal_commenter").hide(), this.menu.items.get("public_commenter").hide())
                }
            })
        },
        getShareLinkComposite: function() {
            return this.shareLinkComposite || (this.shareLinkComposite = new SYNO.SDS.Utils.ClipBoardComposite({
                cls: "syno-d-link-composite-field",
                disableWhenEmpty: !1,
                hideLabel: !0,
                textFieldCfg: {
                    cls: "syno-d-share-link-text selectabletext allowDefCtxMenu",
                    readOnly: !0,
                    selectOnFocus: !0,
                    width: 456
                },
                btnCfg: {
                    tooltip: SYNO.SDS.Drive._T("info", "copy_url"),
                    width: 40,
                    cls: "syno-d-copy-btn",
                    iconCls: "syno-d-copy-btn-icon",
                    btnStyle: "grey"
                },
                listeners: {
                    clipsucceed: function(e) {
                        this.findWindow().setStatusOK({
                            text: SYNO.SDS.Drive._T("share", "copy_url_done")
                        })
                    },
                    clipfailed: function(e) {
                        this.findWindow().setStatusError({
                            text: SYNO.SDS.Drive._T("error", "copy_share_link")
                        })
                    },
                    scope: this
                }
            }))
        },
        getShareMailBox: function() {
            var e = SYNO.SDS.Drive._T,
                t = "dir" === this.type ? e("share", "mail_directory_link") : e("share", "mail_file_link");
            return this.shareMailBox || (this.shareMailBox = new SYNO.ux.DisplayField({
                htmlEncode: !1,
                hideLabel: !0,
                value: '<span class="syno-d-text-btn syno-d-share-email-text">' + t + "</span>",
                scope: this,
                cls: "syno-d-share-email",
                listeners: {
                    scope: this,
                    single: !0,
                    render: function(e) {
                        var t = e.getEl();
                        this.mon(t, "click", function(e) {
                            if (!t.hasClass("x-item-disabled") && e.within(t.dom.firstChild)) {
                                var i = new SYNO.SDS.Drive.MailDialog({
                                    owner: this.findWindow()
                                });
                                i.onSetData(this.data, this.getLinkField().getValue()), i.show()
                            }
                        }, this)
                    }
                }
            }))
        },
        getUserGroupCombo: function() {
            if (this.share_name) return this.share_name;
            var e = new SYNO.SDS.Drive.Share.QueryStore({
                    autoLoad: !1,
                    listeners: {
                        scope: this,
                        load: function() {
                            this.isDestroyed || this.fireEvent("sharestoreloaddone")
                        }
                    }
                }),
                t = new SYNO.SDS.Drive.Share.FillStore({
                    autoLoad: !1,
                    listeners: {
                        scope: this,
                        load: function() {
                            this.isDestroyed || (this.getUserGroupCombo().bindStore(t), t.setCombo(this.share_name), e.query_str && t.setQuery(e.query_str), this.fireEvent("sharestoreloaddone"))
                        }
                    }
                });
            return this.share_name = new SYNO.ux.SuperBoxSelect({
                    supportPlaceHolder: !1,
                    itemMaxWidth: 65,
                    ctCls: "syno-d-share-user-group",
                    labelAlign: "top",
                    typeAhead: !1,
                    addNewDataOnBlur: !0,
                    allowAddNewData: !0,
                    allowDeleteData: !0,
                    allowQueryAll: !1,
                    removeValuesFromStore: !1,
                    lazyInit: !1,
                    emptyText: SYNO.SDS.Drive._T("share", "user_group"),
                    listEmptyText: SYNO.SDS.Drive._T("common", "no_data"),
                    editable: !0,
                    width: 290,
                    store: e,
                    minChars: 1,
                    valueField: "id",
                    displayField: "displayname",
                    queryParam: "query",
                    mode: "remote",
                    enableKeyEvents: !0,
                    tpl: new Ext.XTemplate('<tpl for=".">{[this.insertBefore(values, xindex, parent)]}<div class="x-combo-list-item {[values.cls || ""]}" role="option" aria-label="{[Ext.util.Format.htmlEncode(Ext.util.Format.stripTags(values.displayname))]}" id="{[Ext.id()]}" ext:qtip="{[Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(values.displayname))]}">{[Ext.util.Format.htmlEncode(values.displayname)]}</div></tpl></tpl>', {
                        insertBefore: function(e, t, i) {
                            return t > 1 && i[t - 2].type !== e.type ? '<div class="syno-d-menu-sep">&nbsp;</div>' : ""
                        }
                    }),
                    validator: function(e) {
                        var t = e.split("@");
                        return t.shift(), e = t.join("@"), Ext.isEmpty(e) || -1 !== this.findIndexUserGroup(e)
                    }.bind(this),
                    initScrollbarEvent: Ext.emptyFn,
                    onBlur: function() {
                        this.onBlurCall = !0, this.beforeBlur(), this.outerWrapEl.removeClass(this.focusClass), this.autoSize(), this.clearCurrentFocus(), SYNO.ux.SuperBoxSelect.superclass.onBlur.call(this)
                    },
                    onStoreLoad: function(e, t, i) {
                        var n = 0;
                        Ext.each(t, function(e) {
                            var t = e.get(this.displayField),
                                i = Ext.util.TextMetrics.measure(this.el, t);
                            n = Math.max(n, i.width + 100)
                        }.bind(this));
                        var s = n > this.width ? n : this.width;
                        s = s > 456 ? 456 : s, this.doResize(s), SYNO.ux.SuperBoxSelect.prototype.onStoreLoad.bind(this)(e, t, i)
                    },
                    listeners: {
                        scope: this,
                        beforeselect: function(e, t) {
                            var i = t.data.name;
                            e.hasValue(i) && e.collapse()
                        },
                        beforeadditem: function(e, t, i) {
                            return !Ext.isEmpty(t) && -1 !== this.findIndexUserGroup(i.data.name)
                        },
                        additem: function(e) {
                            if (window.event) {
                                var t = new Ext.EventObjectImpl(window.event);
                                e.itemDelimiterKey === t.getKey() && (this.blViewAddUser = !0, function() {
                                    this.blViewAddUser = !1
                                }.defer(80, this))
                            }
                        },
                        newitem: function(e, t) {
                            var i = this.findUserGroup(t);
                            if (i) {
                                e.getStore().clearFilter();
                                var n = i.data;
                                e.addItem(n)
                            }
                        },
                        autosize: function(e, t) {
                            "" === e.el.dom.value && e.items.getCount() > 0 && e.el.setWidth(5)
                        },
                        keydown: function(e, t, i) {
                            if (e.itemDelimiterKey === t.getKey() && !this.blViewAddUser) {
                                "" !== e.el.dom.value || e.isExpanded() || this.onAddSharePriv()
                            }
                        },
                        beforequery: function(e) {
                            if (e && this.getUserGroupCombo().isVisible()) {
                                var t = this.getUserGroupCombo().outerWrapEl.dom;
                                t.scrollTop = t.scrollHeight
                            }
                        }
                    }
                }), e.setCombo(this.share_name),
                function() {
                    this.mon(this, "beforedestroy", function() {
                        e.destroy(), t.destroy()
                    })
                }.defer(100, this), this.share_name
        },
        getSharePrivCombo: function() {
            var e = [{
                role: "previewer",
                display: SYNO.SDS.Drive._T("perm", "previewer"),
                tip: SYNO.SDS.Drive._T("perm", "previewer_description")
            }, {
                role: "preview_commenter",
                display: SYNO.SDS.Drive._T("perm", "preview_commenter"),
                tip: SYNO.SDS.Drive._T("perm", "preview_commenter_description")
            }, {
                role: "viewer",
                display: SYNO.SDS.Drive._T("perm", "viewer"),
                tip: SYNO.SDS.Drive._T("perm", "viewer_description")
            }, {
                role: "commenter",
                display: SYNO.SDS.Drive._T("perm", "commenter"),
                tip: SYNO.SDS.Drive._T("perm", "commenter_description")
            }, {
                role: "editor",
                display: SYNO.SDS.Drive._T("perm", "editor"),
                tip: SYNO.SDS.Drive._T("perm", "editor_description")
            }, {
                role: "organizer",
                display: SYNO.SDS.Drive._T("perm", "manager"),
                tip: SYNO.SDS.Drive._T("perm", "organizer_description")
            }];
            return new SYNO.ux.ComboBox({
                store: this.sharePrivComboStore = new Ext.data.JsonStore({
                    idProperty: "role",
                    autoDestroy: !0,
                    fields: ["role", "display", "tip"],
                    data: e
                }),
                displayField: "display",
                valueField: "role",
                width: 158,
                value: "viewer",
                cls: "syno-d-share-user-group-combobox",
                tpl: '<tpl for="."><div ext:qtip="{[Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.doubleHtmlEncode(values.tip))]}" class="x-combo-list-item" role="option" aria-label="{[Ext.util.Format.htmlEncode(values.display)]}">{[Ext.util.Format.htmlEncode(values.display)]}</div></tpl>',
                initList: function() {
                    var e = 0;
                    this.getStore().each(function(t) {
                        var i = t.get(this.displayField),
                            n = Ext.util.TextMetrics.measure(this.el, i);
                        e = Math.max(e, n.width + 60)
                    }.bind(this)), this.listWidth = e > this.width ? e : this.width, SYNO.ux.ComboBox.prototype.initList.bind(this)()
                },
                listeners: {
                    afterrender: function(e) {
                        Ext.QuickTips.register({
                            target: e.getEl(),
                            text: e.rawValue
                        })
                    },
                    select: function(e) {
                        Ext.QuickTips.register({
                            target: e.getEl(),
                            text: e.rawValue
                        })
                    }
                }
            })
        },
        getAddBtn: function() {
            return this.add_btn || (this.add_btn = new SYNO.ux.Button({
                btnStyle: "grey",
                cls: "syno-d-share-add",
                width: 40,
                listeners: {
                    click: function() {
                        this.onAddSharePriv()
                    },
                    scope: this
                }
            }))
        },
        onAddSharePriv: function() {
            var e = this.getUserGroupUnAdded();
            if (e) {
                var t = this.share_priv.getValue(),
                    i = this.getShareStore(),
                    n = 0,
                    s = null;
                Ext.each(e, function(e) {
                    if (e) {
                        var o = e.data.name,
                            r = o.toLowerCase(),
                            a = e.data.type,
                            l = e.data.nickname;
                        n = i.findBy(function(e) {
                            return e.data.name.toLowerCase() === r && e.data.type === a
                        }, this), -1 === n ? i.insert(0, new Ext.data.Record({
                            name: o,
                            type: a,
                            role: t,
                            nickname: l
                        })) : (s = i.getAt(n), t !== s.data.role && (s.beginEdit(), s.set("name", o), s.set("type", a), s.set("role", t), s.set("nickname", l), s.endEdit()))
                    }
                }, this), this.share_name.clearValue()
            }
        },
        findIndexUserGroup: function(e) {
            var t = this.share_name.getStore(),
                i = t.createFilterFn("name", e, !1, !1, !0);
            return (t.snapshot || t.data).findIndexBy(i)
        },
        findUserGroup: function(e) {
            var t = this.share_name.getStore(),
                i = t.createFilterFn("name", e, !1, !1, !0);
            return (t.snapshot || t.data).find(i)
        },
        isUserGroupVaild: function() {
            return this.share_name.validate()
        },
        isUserGroupUnAdded: function() {
            var e = this.getUserGroupUnAdded();
            if (!e) return !1;
            var t, i = this.share_priv.getValue(),
                n = !1;
            return Ext.each(e, function(e) {
                if (e) return -1 === (t = this.getShareStore().findBy(function(t) {
                    var i = t.data.name.toLowerCase() === e.data.name.toLowerCase(),
                        n = t.data.type === e.data.type;
                    return i && n
                }, this)) || i !== this.getShareStore().getAt(t).data.role ? (n = !0, !1) : void 0
            }, this), n
        },
        getUserGroupUnAdded: function() {
            return this.share_name.getStore().clearFilter(), this.share_name.getSelectedRecords()
        },
        getLinkFieldSet: function() {
            var e = SYNO.SDS.Drive._T;
            return this.linkFieldset || (this.linkFieldset = new SYNO.ux.FieldSet({
                itemId: "link_fieldset",
                cls: "syno-d-no-bottom-margin",
                collapsible: !1,
                region: "north",
                title: "dir" === this.type ? e("share", "directory_link") : e("share", "file_link"),
                items: [this.getShareLinkComposite(), this.getShareMailBox()]
            }))
        },
        getLinkField: function() {
            return this.getShareLinkComposite().textField
        },
        getShareToDsmUserCfg: function() {
            this.share_priv = this.getSharePrivCombo(), this.shareCompositeField = new SYNO.ux.CompositeField({
                xtype: "syno_compositefield",
                hideLabel: !0,
                region: "north",
                hidden: !SYNO.SDS.Drive.Define.Info.sharing_permission.invite_sharing,
                defaults: {
                    margins: "0 8 0 0"
                },
                items: [this.getUserGroupCombo(), this.share_priv, this.getAddBtn()]
            }), this.shareEditorGrid = new SYNO.ux.EditorGridPanel({
                itemId: "sharegrid",
                cls: "syno-d-share-gridpanel",
                clicksToEdit: 1,
                hideHeaders: !0,
                region: "center",
                margins: {
                    top: 8,
                    bottom: 8,
                    left: 0,
                    right: 9
                },
                viewConfig: {
                    markDirty: !1,
                    autoFill: !0,
                    deferEmptyText: !1,
                    emptyText: SYNO.SDS.Drive._T("empty", "share"),
                    scrollOffset: 0
                },
                sm: new Ext.grid.RowSelectionModel({
                    listeners: {
                        beforerowselect: function() {
                            return !1
                        }
                    }
                }),
                listeners: {
                    viewready: function(e) {
                        e.getView().updateScroller()
                    }
                },
                colModel: new Ext.grid.ColumnModel({
                    defaults: {
                        menuDisabled: !0,
                        fixed: !0,
                        align: "left"
                    },
                    columns: [{
                        dataIndex: "name",
                        width: 293,
                        renderer: this.displaynameRenderer.createDelegate(this)
                    }, {
                        dataIndex: "role",
                        width: 159,
                        renderer: this.roleRenderer.createDelegate(this)
                    }, {
                        xtype: "actioncolumn",
                        css: "syno-d-actioncolumn",
                        width: 50,
                        items: [{
                            iconCls: "syno-d-share-delete-icon",
                            handler: function(e, t, i) {
                                e.getStore().removeAt(t)
                            }
                        }]
                    }]
                }),
                store: this.getShareStore()
            });
            var e = String.format("<p>{0}</p>", SYNO.SDS.Drive._T("info_tip", "public_sharing_warning_disabled_content"));
            if (SYNO.SDS.Drive.Define.Info.sharing_permission.public_sharing) {
                e = String.format("<p>{0}<br /> {2}{1}{3}.</p>", SYNO.SDS.Drive._T("info_tip", "public_sharing_warning_content"), SYNO.SDS.Drive._T("info_tip", "adv_sharing_learn_more"), '<a target="_blank" rel="noreferrer" href="https://www.synology.com/knowledgebase/DSM/help/SynologyDrive/drive_file_management">', "</a>")
            }
            return this.publicDeprecatedWarning = new SYNO.SDS.Drive.WhiteQuickTip({
                style: {
                    marginTop: "3px"
                },
                tipWidth: 320,
                tipItems: new Ext.BoxComponent({
                    html: e
                }),
                warningIcon: !0,
                hidden: !0
            }), {
                xtype: "container",
                region: "center",
                layout: "border",
                cls: "syno-d-share-perm-fieldset syno-ux-fieldset syno-ux-fieldset-default",
                items: [{
                    xtype: "syno_compositefield",
                    region: "north",
                    cls: "x-fieldset-header",
                    height: 30,
                    items: [{
                        xtype: "container",
                        html: SYNO.SDS.Drive._T("share", "privacy_setting"),
                        cls: "x-fieldset-header-text"
                    }, this.publicDeprecatedWarning]
                }, {
                    xtype: "syno_fieldset",
                    collapsible: !1,
                    itemId: "sharefieldset",
                    cls: "syno-ux-formpanel",
                    region: "center",
                    layout: "border",
                    items: [{
                        xtype: "container",
                        region: "north",
                        layout: "form",
                        labelAlign: "top",
                        defautls: {
                            height: 30
                        },
                        items: [this.getLinkRoleBtn(), this.getPreviewCheckbox(), {
                            xtype: "syno_compositefield",
                            items: [{
                                xtype: "syno_displayfield",
                                value: SYNO.SDS.Drive._T("share", "invite") + ":"
                            }, new SYNO.SDS.Drive.WhiteQuickTip({
                                style: {
                                    marginTop: "3px"
                                },
                                tipItems: new SYNO.SDS.Drive.Share.SharingInfo
                            })]
                        }, this.shareCompositeField],
                        doLayout: function() {
                            this.setHeight(""), Ext.Container.prototype.doLayout.apply(this, arguments)
                        }
                    }, this.shareEditorGrid]
                }]
            }
        },
        getPreviewCheckbox: function() {
            return this.previewCheckbox || (this.previewCheckbox = new SYNO.ux.Checkbox({
                name: "preview_checkbox",
                itemId: "preview_checkbox",
                boxLabel: SYNO.SDS.Drive._T("share", "allow_download"),
                checked: !0,
                hidden: !0
            })), this.previewCheckbox
        },
        onLoadData: function() {
            if (this.findWindow().setStatusBusy(), this.findAppWindow().getWebAPI().getShardLinkAndInfo({
                    params: {
                        path: this.path
                    },
                    callback: this.onLoadDataDone,
                    scope: this
                }), this.capabilities && !this.capabilities.can_share) {
                var e = [this.linkRoleBtn, this.share_name, this.share_priv, this.add_btn, this.shareEditorGrid, this.getPreviewCheckbox()];
                Ext.each(e, function(e) {
                    e.setDisabled(!0)
                })
            }
            this.share_user && _S("user") !== this.share_user && (this.findWindow().setStatusBusy(), this.share_name.addValue(this.share_user), this.mon(this, "sharestoreloaddone", function() {
                if (!this.isDestroyed && (this.findWindow().clearStatusBusy(), !this.share_name.getRawValue())) {
                    var e = this.findUserGroup(this.share_user);
                    e && this.share_name.setValueEx(e.data), this.share_priv.collapse(), this.share_name.collapse(), this.share_name.getRawValue() ? this.share_priv.focus() : this.share_name.focus()
                }
            }, this, {
                buffer: 80,
                single: !0
            }))
        },
        onLoadDataDone: function(e, t, i, n) {
            if (!this.isDestroyed) {
                if (this.findWindow().clearStatusBusy(), !e || t.has_fail) {
                    var s = SYNO.API.Util.GetFirstError(t);
                    return void this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(s), function() {
                        this.findWindow().close()
                    }, this)
                }
                var o = SYNO.SDS.Drive.WebAPIDesc.get_file_link,
                    r = SYNO.API.Util.GetValByAPI(t, o.api, o.method, "url");
                this.getLinkField().setValue(r), o = SYNO.SDS.Drive.WebAPIDesc.get_file;
                var a = SYNO.API.Util.GetValByAPI(t, o.api, o.method);
                this.data = a;
                var l = [];
                if (this.objectRole = {
                        user: {},
                        group: {}
                    }, !Ext.isEmpty(this.data) && Ext.isArray(this.data.shared_with)) {
                    if (a.removed) return void this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive._T("file", "in_recycle"), function() {
                        this.findWindow().close()
                    }, this);
                    this.findWindow().fireEvent("load", a), Ext.each(this.data.shared_with, function(e) {
                        switch (e.type) {
                            case "public":
                                this.getLinkRoleBtn().initValue(e), this.publicDeprecatedWarning.setVisible(!0), this.doLayout();
                                break;
                            case "internal":
                                this.getLinkRoleBtn().initValue(e);
                                break;
                            case "user":
                                this.objectRole.user[e.name] = e.role, l.push(e);
                                break;
                            case "group":
                                this.objectRole.group[e.name] = e.role, l.push(e)
                        }
                    }, this), Ext.isEmpty(l) || this.getShareStore().loadData(l), SYNO.SDS.Drive.Utils.isOfficeFile(this.data.name) || (this.sharePrivComboStore.remove(this.sharePrivComboStore.getById("commenter")), this.sharePrivComboStore.remove(this.sharePrivComboStore.getById("preview_commenter")), this.getLinkRoleBtn().hideForOffice());
                    var d = SYNO.SDS.Drive.Define.Info.sharing_permission.invite_sharing;
                    d !== this.shareCompositeField.isVisible() && (this.shareCompositeField.ownerCt.setHeight("auto"), this.shareCompositeField.setVisible(d), this.doLayout())
                }
            }
        },
        getShareStore: function() {
            return this.shareStore ? this.shareStore : (this.shareStore = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: [{
                    name: "id"
                }, {
                    name: "name",
                    sortType: function(e) {
                        return e ? e.toLowerCase() : ""
                    }
                }, "role", "type", "nickname", {
                    name: "order",
                    convert: function(e, t) {
                        switch (t.type) {
                            case "user":
                                return 1;
                            case "group":
                                return 2;
                            default:
                                return 100
                        }
                    }
                }],
                hasMultiSort: !0,
                multiSortInfo: {
                    sorters: [{
                        field: "order",
                        direction: "asc"
                    }, {
                        field: "type",
                        direction: "asc"
                    }, {
                        field: "name",
                        direction: "asc"
                    }, {
                        field: "nickname",
                        direction: "asc"
                    }],
                    direction: "asc"
                }
            }), this.shareStore)
        },
        displaynameRenderer: function(e, t, i) {
            var n, s = e;
            return n = "group" === i.data.type ? "syno-d-share-group" : "syno-d-share-user", i.data.nickname && (s += " (" + i.data.nickname + ")"), String.format('<div ext:qtip="{0}"><span class="{1}"></span>{2}</div>', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(s)), n, Ext.util.Format.htmlEncode(s))
        },
        roleRenderer: function(e, t, i) {
            var n = Ext.id();
            return Ext.defer(this.createStatusButton, 25, this, [e, n, i]), '<div id="' + n + '";</div>'
        },
        changeRoleStatus: function(e, t, i) {
            e.setText(t.text), e.setTooltip(t.text), i.data.role = t.value
        },
        createStatusButton: function(e, t, i) {
            if (!Ext.isEmpty(Ext.get(t))) {
                var n = [{
                        text: SYNO.SDS.Drive._T("perm", "previewer"),
                        value: "previewer",
                        tip: SYNO.SDS.Drive._T("perm", "previewer_description")
                    }, {
                        itemId: "preview_commenter",
                        text: SYNO.SDS.Drive._T("perm", "preview_commenter"),
                        value: "preview_commenter",
                        tip: SYNO.SDS.Drive._T("perm", "preview_commenter_description")
                    }, {
                        text: SYNO.SDS.Drive._T("perm", "viewer"),
                        value: "viewer",
                        tip: SYNO.SDS.Drive._T("perm", "viewer_description")
                    }, {
                        itemId: "commenter",
                        text: SYNO.SDS.Drive._T("perm", "commenter"),
                        value: "commenter",
                        tip: SYNO.SDS.Drive._T("perm", "commenter_description")
                    }, {
                        text: SYNO.SDS.Drive._T("perm", "editor"),
                        value: "editor",
                        tip: SYNO.SDS.Drive._T("perm", "editor_description")
                    }, {
                        text: SYNO.SDS.Drive._T("perm", "manager"),
                        value: "organizer",
                        tip: SYNO.SDS.Drive._T("perm", "organizer_description")
                    }],
                    s = SYNO.SDS.Drive._T("perm", "organizer" === e ? "manager" : e),
                    o = new SYNO.ux.Button({
                        disabled: !SYNO.SDS.Drive.Define.Info.sharing_permission.invite_sharing,
                        btnStyle: "default",
                        text: s,
                        tooltip: s,
                        renderTo: t,
                        cls: "syno-d-share-status-btn",
                        menu: new SYNO.ux.Menu({
                            items: n,
                            listeners: {
                                scope: this,
                                beforeshow: function(e) {
                                    e.items.items.forEach(function(e) {
                                        e.tip && (new Ext.ToolTip({
                                            target: e.getEl(),
                                            html: Ext.util.Format.htmlEncode(e.tip)
                                        }), e.tip = void 0)
                                    }), SYNO.SDS.Drive.Utils.isOfficeFile(this.data.name) || (e.items.get("preview_commenter").hide(), e.items.get("commenter").hide())
                                }
                            }
                        })
                    });
                o.menu.items.each(function(e, t, n) {
                    e.setHandler(this.changeRoleStatus.createDelegate(this, [o, e, i]))
                }, this), this.addManagedComponent(o), this.statusBtn = o
            }
        },
        isShareLinkRoleDirty: function() {
            return this.getLinkRoleBtn().isDirty() || this.getPreviewCheckbox().isDirty()
        },
        calculateRole: function(e, t, i, n) {
            var s = {},
                o = !1,
                r = Ext.apply({}, t);
            return Ext.iterate(e, function(e, t) {
                if (r.hasOwnProperty(e)) {
                    if (r[e] === t) return void delete r[e];
                    i.push({
                        action: "update",
                        member: {
                            type: n ? "group" : "user",
                            name: e
                        },
                        role: t
                    }), delete r[e], o = !0
                } else i.push({
                    action: "update",
                    member: {
                        type: n ? "group" : "user",
                        name: e
                    },
                    role: t
                }), o = !0
            }, this), Ext.iterate(r, function(e, t) {
                i.push({
                    action: "delete",
                    member: {
                        type: n ? "group" : "user",
                        name: e
                    }
                }), o = !0
            }, this), !0 === o && s
        },
        hasModifiedRole: function() {
            if (this.isShareLinkRoleDirty()) return !0;
            var e, t, i = function(e) {
                for (var t in e)
                    if (e.hasOwnProperty(t)) return !1;
                return !0
            };
            return e = Ext.apply({}, this.objectRole.user), t = Ext.apply({}, this.objectRole.group), this.getShareStore().each(function(i, n, s) {
                var o = i.data.role;
                "group" === i.data.type ? t[i.data.name] === o ? delete t[i.data.name] : t[i.data.name] = o : "user" === i.data.type && (e[i.data.name] === o ? delete e[i.data.name] : e[i.data.name] = o)
            }, this), !i(e) || !i(t)
        },
        onBeforeApply: function() {
            return this.isDirty() && this.isUserGroupUnAdded() ? new Promise(function(e, t) {
                var i, n = this.getUserGroupUnAdded(),
                    s = !0,
                    o = [];
                Ext.each(n, function(e) {
                    e && ("group" !== e.data.type && (s = !1), o.push(e.data.name))
                }, this), i = o.join(", ");
                var r = SYNO.SDS.Drive._T,
                    a = String.format(s ? r("share", "prompt_addedit_group") : r("share", "prompt_addedit_user"), i);
                this.findWindow().getMsgBox().confirm("", a, function(i) {
                    "yes" === i ? (this.onAddSharePriv(), e()) : t()
                }, this)
            }.bind(this)) : Promise.resolve()
        },
        onApply: function() {
            return this.hasModifiedRole() ? this.onSetRole(this.getParams()) : Promise.resolve()
        },
        onSetRole: function(e) {
            return new Promise(function(t, i) {
                this.findAppWindow().getAction().setNodePerm(e, function(e, n) {
                    e ? t(n) : i(n)
                }, this)
            }.bind(this))
        },
        isDirty: function() {
            return this.hasModifiedRole() || this.isUserGroupUnAdded()
        },
        isValid: function() {
            return this.form.isValid()
        },
        getParams: function() {
            var e, t = {
                path: this.path
            };
            return e = this.getModifiedRole(), Ext.isObject(e) && Ext.apply(t, e), t
        },
        getModifiedRole: function() {
            var e = [],
                t = {},
                i = {};
            if (this.isShareLinkRoleDirty()) {
                var n = this.getLinkRoleBtn().getOriValue(),
                    s = this.getLinkRoleBtn().getValue();
                n.type && n.type !== s.type && e.push({
                    action: "delete",
                    member: {
                        type: n.type
                    }
                }), s.role && e.push({
                    action: "update",
                    member: {
                        type: s.type
                    },
                    role: s.role
                })
            }
            return this.getShareStore().each(function(e, n, s) {
                "group" === e.data.type ? i[e.data.name] = e.data.role : "user" === e.data.type && (t[e.data.name] = e.data.role)
            }, this), this.calculateRole(t, this.objectRole.user, e, !1), this.calculateRole(i, this.objectRole.group, e, !0), !Ext.isEmpty(e) && {
                path: this.path,
                permissions: e
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Share.QueryStore", {
        extend: "SYNO.API.Store",
        constructor: function(e) {
            this.callParent([this.fillConfig(e)])
        },
        destroy: function() {
            this.combo && this.combo.un("beforequery", this.onBeforeQuery, this), this.callParent()
        },
        setCombo: function(e) {
            this.combo = e, this.combo.on("beforequery", this.onBeforeQuery, this)
        },
        fillConfig: function(e) {
            var t = {
                appWindow: this,
                autoDestroy: !0,
                pruneModifiedRecords: !0,
                baseParams: {
                    query: "",
                    limit: 500,
                    additional: ["nickname"]
                },
                proxy: this.getProxy(),
                reader: this.getJsonReader()
            };
            return Ext.apply(t, e)
        },
        getProxy: function() {
            return new SYNO.API.Proxy(Ext.apply({
                listeners: {
                    scope: this,
                    beforeload: this.onProxyBeforeLoad
                }
            }, SYNO.SDS.Drive.WebAPIDesc.list_app_priv))
        },
        onProxyBeforeLoad: function(e, t) {
            var i = e.activeRequest.read;
            i && Ext.Ajax.abort(i)
        },
        onBeforeQuery: function(e) {
            if (this.isDestroyed) return !1;
            var t = e.query.toLowerCase();
            return this.query_str = t, "" !== t && void 0
        },
        add: function(e) {
            this.suspendEvents(!1), SYNO.API.Store.prototype.add.call(this, e), this.resumeEvents()
        },
        doUpdate: function(e) {
            this.suspendEvents(!1), SYNO.API.Store.prototype.doUpdate.call(this, e), this.resumeEvents()
        },
        load: function(e) {
            SYNO.API.Store.prototype.load.call(this, Ext.apply(e || {}, {
                add: !0,
                callback: function(e) {
                    this.isDestroyed || (this.sort([{
                        field: "type",
                        direction: "ASC"
                    }, {
                        field: "name",
                        direction: "ASC"
                    }]), this.filterStore(this.query_str))
                }
            }))
        },
        getJsonReader: function() {
            return new Ext.data.JsonReader({
                root: "list",
                idProperty: function(e) {
                    return e.type + "@" + e.name
                },
                fields: [{
                    name: "id",
                    convert: function(e, t) {
                        return t.type + "@" + t.name
                    }
                }, {
                    name: "name",
                    sortType: function(e) {
                        return e ? e.toLowerCase() : ""
                    }
                }, {
                    name: "nickname",
                    sortType: function(e) {
                        return e ? e.toLowerCase() : ""
                    }
                }, {
                    name: "displayname",
                    convert: function(e, t) {
                        return t.nickname ? t.name + " (" + t.nickname + ")" : t.name
                    }
                }, {
                    name: "type",
                    sortType: function(e) {
                        return "user" === e ? 0 : 1
                    }
                }, "role", {
                    name: "cls",
                    convert: function(e, t) {
                        return "group" === t.type ? "syno-d-combo-share-group" : "syno-d-combo-share-user"
                    }
                }]
            })
        },
        filterStore: function(e) {
            if (this.combo) {
                this.clearFilter();
                var t = this.combo,
                    i = [];
                Ext.isEmpty(e) || i.push({
                    fn: function(t) {
                        return this.createFilterFn("name", e, !0, !1, !1)(t) || this.createFilterFn("nickname", e, !0, !1, !1)(t)
                    }.bind(this)
                }), i.push({
                    fn: function(e) {
                        var i = !1;
                        return Ext.each(t.getSelectedRecords(), function(t) {
                            if (t && t.get("name").toLowerCase() === e.get("name").toLowerCase() && t.get("type") === e.get("type")) return i = !0, !1
                        }), !i
                    }
                }), this.filter(i), t.selectedIndex = -1, t.onLoad()
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Share.FillStore", {
        extend: "SYNO.SDS.Drive.Share.QueryStore",
        setQuery: function(e) {
            this.query_str = e, this.filterStore(e)
        },
        onProxyBeforeLoad: function(e, t) {
            var i = e.activeRequest.read;
            i && Ext.Ajax.abort(i)
        },
        onBeforeQuery: function(e) {
            return !this.isDestroyed && (this.blQueryFillStore ? (this.filterStore(e.query), !1) : void delete e.query)
        },
        load: function(e) {
            SYNO.API.Store.prototype.load.call(this, Ext.apply(e || {}, {
                callback: function(e) {
                    this.isDestroyed || (this.blQueryFillStore || (this.blQueryFillStore = !0), this.filterStore(this.query_str))
                }
            }))
        }
    }), Ext.define("SYNO.SDS.Drive.FancyPasswordField", {
        extend: "Ext.form.TriggerField",
        constructor: function(e) {
            var t = {
                cls: "syno-ux-textfield syno-d-fancy-password-field",
                inputType: "password",
                triggerClass: "syno-d-fancy-password-trigger syno-d-fancy-password-invalid",
                inputVisible: !1
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        onTriggerClick: function(e) {
            this.inputVisible ? (this.el.dom.setAttribute("type", "password"), this.trigger.addClass("syno-d-fancy-password-invalid")) : (this.el.dom.setAttribute("type", "text"), this.trigger.removeClass("syno-d-fancy-password-invalid")), this.inputVisible = !this.inputVisible
        },
        markInvalid: function(e) {
            this.trigger && this.trigger.addClass("syno-ux-trigger-invalid"), this.callParent(arguments)
        },
        clearInvalid: function() {
            this.trigger && this.trigger.removeClass("syno-ux-trigger-invalid"), this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.Drive.Share.AdvancedPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            SYNO.Assert(e.path, "need path"), this.path = e.path, this.name = e.name || "";
            var t = {
                title: SYNO.SDS.Drive._T("share", "protection_share_title"),
                cls: "syno-d-advance-share",
                items: [this.getAdvSharingCheckbox(), this.getPrivacySettingFieldSet(), this.getPasswordFieldSet(), this.getLinkExpireFieldSet(), this.getProtectLinkFieldSet()]
            };
            Ext.apply(t, e || {}), this.callParent([t]), this.mon(this, "afterlayout", this._onAfterLayout, this, {
                single: !0
            })
        },
        getAdvSharingCheckbox: function() {
            return this.advSharingCheckbox ? this.advSharingCheckbox : (this.advSharingCheckbox = new SYNO.ux.Checkbox({
                name: "adv_sharing_checkbox",
                itemId: "adv_sharing_checkbox",
                boxLabel: SYNO.SDS.Drive._T("share", "enable_protection_sharing"),
                checked: !1,
                listeners: {
                    scope: this,
                    check: this._onAdvSharingCheckboxClick
                }
            }), this.advSharingCheckbox)
        },
        getPrivacySettingFieldSet: function() {
            if (this.privacySettingFieldSet) return this.privacySettingFieldSet;
            var e = SYNO.SDS.Drive._T;
            return this.privacySettingFieldSet = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Drive._T("share", "privacy_setting"),
                name: "privacy_setting",
                itemId: "privacy_setting",
                collapsible: !1,
                items: [{
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [this.getLinkRoleBtn(), new SYNO.SDS.Drive.WhiteQuickTip({
                        style: {
                            marginTop: "3px"
                        },
                        tipWidth: 320,
                        tipItems: new Ext.BoxComponent({
                            html: String.format("<p>{0}<br /> {2}{1}{3}.</p>", e("info_tip", "adv_sharing_content"), e("info_tip", "adv_sharing_learn_more"), '<a target="_blank" rel="noreferrer" href="https://www.synology.com/knowledgebase/DSM/help/SynologyDrive/drive_file_management">', "</a>")
                        })
                    })]
                }, this._getPreviewCheckbox()]
            }), this.privacySettingFieldSet
        },
        getPasswordFieldSet: function() {
            return this.passwordFieldSet ? this.passwordFieldSet : (this.passwordFieldSet = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Drive._T("share", "password_field_title"),
                name: "passwd_fieldset",
                itemId: "passwd_fieldset",
                items: [this.getPasswordComposite()]
            }), this.passwordFieldSet)
        },
        getLinkExpireFieldSet: function() {
            return this.expireFieldSet ? this.expireFieldSet : (this.expireFieldSet = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Drive._T("share", "expire_field_title"),
                name: "expiration_fieldset",
                itemId: "expiration_fieldset",
                items: [this.getExpirationComposite()]
            }), this.expireFieldSet)
        },
        getProtectLinkFieldSet: function() {
            return this.protectLinkFieldSet ? this.protectLinkFieldSet : (this.protectLinkFieldSet = new SYNO.ux.FieldSet({
                name: "link_fieldset",
                itemId: "link_fieldset",
                cls: "syno-d-no-bottom-margin",
                collapsible: !1,
                title: SYNO.SDS.Drive._T("share", "protect_link_title"),
                margins: {
                    top: 0,
                    bottom: 8,
                    left: 0,
                    right: 0
                },
                items: [this.getShareLinkComposite(), this.getShareMailBox()]
            }), this.protectLinkFieldSet)
        },
        getShareLinkComposite: function() {
            return this.shareLinkComposite ? this.shareLinkComposite : (this.shareLinkComposite = new SYNO.SDS.Utils.ClipBoardComposite({
                itemId: "share_link_composite",
                disableWhenEmpty: !1,
                hideLabel: !0,
                textFieldCfg: {
                    name: "url",
                    itemId: "url",
                    cls: "syno-d-share-link-text selectabletext allowDefCtxMenu",
                    readOnly: !0,
                    selectOnFocus: !0,
                    width: 456
                },
                btnCfg: {
                    tooltip: SYNO.SDS.Drive._T("info", "copy_url"),
                    width: 40,
                    cls: "syno-d-copy-btn",
                    iconCls: "syno-d-copy-btn-icon",
                    btnStyle: "grey"
                },
                listeners: {
                    clipsucceed: function(e) {
                        this.findWindow().setStatusOK({
                            text: SYNO.SDS.Drive._T("share", "copy_url_done")
                        })
                    },
                    clipfailed: function(e) {
                        this.findWindow().setStatusError({
                            text: SYNO.SDS.Drive._T("error", "copy_share_link")
                        })
                    },
                    scope: this
                }
            }), this.shareLinkComposite)
        },
        getLinkRoleBtn: function() {
            if (this.linkRoleBtn) return this.linkRoleBtn;
            var e = this,
                t = SYNO.SDS.Drive._T,
                i = [{
                    itemId: "viewer",
                    text: t("perm", "public_ro_desc")
                }, {
                    itemId: "commenter",
                    text: t("perm", "public_commenter_desc")
                }, {
                    itemId: "editor",
                    text: t("perm", "public_rw_desc")
                }];
            return this.linkRoleBtnId = Ext.id(), this.linkRoleBtn = new SYNO.ux.Button({
                id: this.linkRoleBtnId,
                htmlEncode: !1,
                height: 30,
                width: 472,
                hideLabel: !0,
                btnStyle: "grey",
                cls: "syno-d-combo-btn",
                text: i[0].text,
                menu: this.getRoleMenu(i),
                setValue: function(t, i) {
                    this.menu.items.each(function(e) {
                        if (e.itemId === t) return this.value = t, this.setText(e.text), !1
                    }, this), i && (this.ori_value = t, e.getLinkField().focus(!1, 2)), -1 !== ["viewer", "commenter"].indexOf(t) ? e._getPreviewCheckbox().show() : (e._getPreviewCheckbox().setValue(!0), e._getPreviewCheckbox().hide())
                },
                getOriValue: function() {
                    return this.ori_value
                },
                getValue: function() {
                    return this.value || "viewer"
                },
                isDirty: function() {
                    return this.value !== this.ori_value
                }
            })
        },
        getRoleMenu: function(e) {
            return this.roleMenu ? this.roleMenu : (this.roleMenu = new SYNO.ux.Menu({
                minWidth: 504,
                defaults: {
                    htmlEncode: !1,
                    checked: !1
                },
                items: e,
                listeners: {
                    scope: this,
                    itemclick: function(e) {
                        var t = e.itemId,
                            i = this.getLinkRoleBtn();
                        i.getValue() !== t && i.setValue(t)
                    },
                    beforeshow: function(e) {
                        var t = this.getLinkRoleBtn().getValue(),
                            i = e.items;
                        i.each(function(e) {
                            e.setChecked && e.setChecked(e.itemId === t)
                        }), SYNO.SDS.Drive.Utils.isOfficeFile(this.name) || i.get("commenter").hide()
                    },
                    show: function(e) {
                        var t = e.layout.container,
                            i = t.getEl();
                        t.getLayoutTarget().getWidth() + i.getFrameWidth("lr") < e.minWidth && t.setWidth(e.minWidth)
                    }
                }
            }), this.roleMenu)
        },
        getLinkField: function() {
            return this.getShareLinkComposite().textField
        },
        getShareMailBox: function() {
            return this.shareMailBox ? this.shareMailBox : (this.shareMailBox = new SYNO.ux.DisplayField({
                itemId: "share_mailbox",
                htmlEncode: !1,
                hideLabel: !0,
                value: '<span class="syno-d-text-btn syno-d-share-email-text">' + SYNO.SDS.Drive._T("share", "mail_protection_link") + "</span>",
                scope: this,
                cls: "syno-d-share-email",
                listeners: {
                    scope: this,
                    single: !0,
                    render: function(e) {
                        var t = e.getEl();
                        this.mon(t, "click", function(e) {
                            if (!t.hasClass("x-item-disabled") && e.within(t.dom.firstChild)) {
                                var i = new SYNO.SDS.Drive.MailDialog({
                                    owner: this.findWindow()
                                });
                                i.onSetData(this, this.getLinkField().getValue()), i.show()
                            }
                        }, this)
                    }
                }
            }), this.shareMailBox)
        },
        getPasswordComposite: function() {
            return this.passwordComposite ? this.passwordComposite : (this.passwordCheckbox = new SYNO.SDS.Drive.Share.CustomizedCheckBox({
                name: "enable_passwd_checkbox",
                itemId: "enable_passwd_checkbox",
                width: 230,
                boxLabel: SYNO.SDS.Drive._T("share", "enable_password"),
                checked: !1
            }), this.passwordTextField = new SYNO.SDS.Drive.FancyPasswordField({
                name: "passwd_text_field",
                itemId: "passwd_text_field",
                width: 180,
                allowBlank: !1,
                maxLength: 32,
                selectWhenFocus: !1,
                listeners: {
                    focus: function() {
                        !0 === this.selectWhenFocus && this.el.dom.select(), this.selectWhenFocus = !1
                    }
                }
            }), this.passwordComposite = new SYNO.ux.CompositeField({
                itemId: "passwd_composite_field",
                hideLabel: !0,
                items: [this.passwordCheckbox, this.passwordTextField]
            }), this.passwordComposite)
        },
        getExpirationComposite: function() {
            if (this.expirationComposite) return this.expirationComposite;
            var e = SYNO.SDS.Drive._T,
                t = new Date((new Date).getTime() + 864e5);
            this.expirationCheckbox = new SYNO.SDS.Drive.Share.CustomizedCheckBox({
                name: "enable_expiration_checkbox",
                itemId: "enable_expiration_checkbox",
                width: 230,
                boxLabel: e("share", "enable_expiration"),
                checked: !1,
                handler: function(e, i) {
                    !0 === i && this.expirationDateField.setValue(t)
                }.bind(this)
            });
            var i = SYNO.SDS.Drive.Define.Info.sharing_permission.public_force_expiration_days,
                n = null;
            return i > 0 && (n = new Date((new Date).getTime() + 864e5 * i)), this.expirationDateField = new SYNO.SDS.Drive.DateField({
                name: "expiration_datefield",
                itemId: "expiration_datefield",
                width: 180,
                editable: !0,
                showToday: !1,
                format: SYNO.SDS.Drive.Utils.getDateFormat(),
                minValue: t,
                maxValue: n,
                invalidText: e("share", "invalid_time"),
                validator: function(i) {
                    if (this.disabled) return !0;
                    var n = this.parseDate(i);
                    if (!this.formatDate(n)) return this.invalidText;
                    var s = new Date,
                        o = new Date(n);
                    return !(o.getYear() < s.getYear() || s.getYear() === o.getYear() && o.getDayOfYear() - s.getDayOfYear() < 1) || String.format(e("share", "date_period_error"), SYNO.SDS.Drive.Utils.getFormatDate(t))
                }
            }), this.expirationComposite = new SYNO.ux.CompositeField({
                name: "expiration_composite_field",
                itemId: "expiration_composite_field",
                hideLabel: !0,
                items: [this.expirationCheckbox, this.expirationDateField]
            }), this.expirationComposite
        },
        isDirty: function() {
            return this.form.isDirty() || this.getLinkRoleBtn().isDirty() || this._getPreviewCheckbox().isDirty()
        },
        isValid: function() {
            return !this.rendered || !this.isDirty() || this.form.isValid()
        },
        onBeforeApply: function() {
            return Promise.resolve()
        },
        onApply: function() {
            return this.isDirty() ? this._onSaveLink() : Promise.resolve()
        },
        _onClearDirty: function() {
            this.form.trackResetOnLoad = !0, this.form.setValues(this.form.getValues()), this.form.trackResetOnLoad = !1
        },
        _onAfterLayout: function() {
            new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_passwd_checkbox", ["passwd_text_field"]), new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_expiration_checkbox", ["expiration_datefield"]), new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "adv_sharing_checkbox", ["share_link_composite", this.linkRoleBtnId, "share_mailbox", "enable_passwd_checkbox", "passwd_composite_field", "enable_expiration_checkbox", "expiration_composite_field"]), this._onInit()
        },
        _onInit: function() {
            this._doAction(this._onGetLink())
        },
        _doAction: function(e) {
            return Promise.resolve().then(function() {
                this.findWindow().setStatusBusy()
            }.bind(this)).then(function() {
                return e.promise
            }).then(function() {
                this._onClearDirty(), this.findWindow().clearStatusBusy(), e.statusAction && e.statusAction(this.findWindow())
            }.bind(this)).catch(function(e) {
                SYNO.Debug.error(e), this.findWindow().setStatusError(SYNO.SDS.Drive.Utils.getErrorStr(e))
            }.bind(this))
        },
        _showRemoveMsgBox: function() {
            var e = SYNO.SDS.Drive._T,
                t = ['<div class="syno-d-advance-share-remove-title"> {0} </div>', "<div> {1} </div>"].join(""),
                i = "";
            i = SYNO.SDS.Drive.Define.Info.sharing_permission.public_sharing ? String.format(t, e("share", "remove_link_title"), e("share", "remove_link_desc")) : String.format(t, e("share", "remove_link_title"), e("share", "remove_link_warn_desc"));
            var n = {
                title: "",
                msg: i,
                width: 340,
                closable: !1,
                buttons: {
                    ok: _T("common", "remove"),
                    cancel: _T("common", "cancel")
                },
                fn: function(e) {
                    switch (e) {
                        case "ok":
                            this._doAction(this._onRemoveLink()), SYNO.SDS.Drive.Define.Info.sharing_permission.public_sharing || this.setDisabled(!0);
                            break;
                        case "cancel":
                            this._onAdvSharingCheckboxSetValue(!0)
                    }
                },
                scope: this
            };
            this.findWindow().getMsgBox().show(n)
        },
        _onAdvSharingCheckboxClick: function(e, t) {
            this.skipAdvSharingCheck || (t ? this._doAction(this._onCreateLink()) : this._showRemoveMsgBox())
        },
        _onAdvSharingCheckboxSetValue: function(e) {
            this.skipAdvSharingCheck = !0, this.advSharingCheckbox.setValue(e), this.skipAdvSharingCheck = !1
        },
        _onSetDisabledEdit: function(e) {
            this._onAdvSharingCheckboxSetValue(!e), this.privacySettingFieldSet.setDisabled(e), this.passwordFieldSet.setDisabled(e), this.expireFieldSet.setDisabled(e), this.protectLinkFieldSet.setDisabled(e), this.previewCheckbox.setDisabled(e), e && (this.passwordCheckbox.setValue(!1), this.expirationCheckbox.setValue(!1), this.form.findField("url").setValue(""), this.previewCheckbox.setValue(!1))
        },
        _getPreviewCheckbox: function() {
            return this.previewCheckbox || (this.previewCheckbox = new SYNO.ux.Checkbox({
                name: "preview_checkbox",
                itemId: "preview_checkbox",
                boxLabel: SYNO.SDS.Drive._T("share", "allow_download"),
                checked: !1,
                hidden: !0
            })), this.previewCheckbox
        },
        _onSetLinkInfo: function(e) {
            this.sharingLinkInfo = e;
            var t = !1,
                i = e.role;
            i.match(/preview/) && (i = {
                previewer: "viewer",
                preview_commenter: "commenter"
            } [i], t = !0), this.linkRoleBtn.setValue(i, !0), this._getPreviewCheckbox().setValue(!t), this._getPreviewCheckbox().originalValue = !t, this.form.findField("url").setValue(e.url), this._isForcePassword() && (this.passwordCheckbox.setValue(!0), this.passwordCheckbox.setReadOnly(!0)), this._isForceExpire() && (this.expirationCheckbox.setValue(!0), this.expirationCheckbox.setReadOnly(!0), this.expirationDateField.setValue(null)), Ext.isEmpty(e.protect_password) || (this.passwordCheckbox.setValue(!0), this.passwordTextField.setValue(e.protect_password)), e.due_date > 0 && (this.expirationCheckbox.setValue(!0), this.expirationDateField.setValue(new Date(1e3 * e.due_date)))
        },
        _onGetLink: function() {
            var e = this.findAppWindow(),
                t = {
                    path: this.path
                };
            return {
                promise: e.getWebAPI().getAdvSharingLinkPromise(t).then(function(e) {
                    this._onSetDisabledEdit(!1), this._onSetLinkInfo(e)
                }.bind(this)).catch(function(e) {
                    if (this._onSetDisabledEdit(!0), !e.code || 1036 !== e.code) return SYNO.Debug.error(e), Promise.reject(e)
                }.bind(this))
            }
        },
        _onCreateLink: function() {
            var e = this.findAppWindow(),
                t = {
                    path: this.path
                },
                i = {
                    promise: e.getWebAPI().createAdvSharingLinkPromise(t).then(function(e) {
                        var t = SYNO.SDS.Drive.Utils.getFileIdFromPathId(this.path);
                        this.findAppWindow().getEventMgr().fireEvent("setnodepermdone", !0, void 0, {
                            file_id: t
                        }), this._onSetDisabledEdit(!1), this._onSetLinkInfo(e), this.passwordTextField.inputVisible || this.passwordTextField.onTriggerClick(), this.passwordTextField.selectWhenFocus = !0, i.statusAction = function(e) {
                            e.setStatusOK({
                                text: SYNO.SDS.Drive._T("share", "protection_sharing_activated")
                            })
                        }
                    }.bind(this)).catch(function(e) {
                        SYNO.Debug.error(e), this._onSetDisabledEdit(!0)
                    }.bind(this))
                };
            return i
        },
        _onRemoveLink: function() {
            var e = this.findAppWindow(),
                t = {
                    path: this.path,
                    sharing_link: this.sharingLinkInfo.sharing_link
                },
                i = {
                    promise: e.getWebAPI().removeAdvSharingLinkPromise(t).then(function(e) {
                        var t = SYNO.SDS.Drive.Utils.getFileIdFromPathId(this.path);
                        this.findAppWindow().getEventMgr().fireEvent("setnodepermdone", !0, void 0, {
                            file_id: t
                        }), this._onSetDisabledEdit(!0), i.statusAction = function(e) {
                            e.setStatusOK({
                                text: SYNO.SDS.Drive._T("share", "protection_sharing_deactivated")
                            })
                        }
                    }.bind(this)).catch(function(e) {
                        SYNO.Debug.error(e), this._onAdvSharingCheckboxSetValue(!0)
                    }.bind(this))
                };
            return i
        },
        _onSaveLink: function() {
            var e = this.findAppWindow(),
                t = {
                    path: this.path,
                    sharing_link: this.sharingLinkInfo.sharing_link,
                    role: this._getRole()
                };
            return this.passwordCheckbox.getValue() ? t.protect_password = this.passwordTextField.getValue() : t.protect_password = "", this.expirationCheckbox.getValue() ? t.due_date = this.expirationDateField.getValue().getTime() / 1e3 : t.due_date = 0, e.getWebAPI().updateAdvSharingLinkPromise(t)
        },
        _getRole: function() {
            var e = this.linkRoleBtn.getValue();
            return this._getPreviewCheckbox().getValue() ? e : {
                viewer: "previewer",
                commenter: "preview_commenter"
            } [e]
        },
        _isForceExpire: function() {
            return SYNO.SDS.Drive.Define.Info.sharing_permission.public_force_expiration_days > 0
        },
        _isForcePassword: function() {
            return !0 === SYNO.SDS.Drive.Define.Info.sharing_permission.public_force_password
        }
    }), Ext.define("SYNO.SDS.Drive.Share.CustomizedCheckBox", {
        extend: "SYNO.ux.Checkbox",
        constructor: function(e) {
            this.callParent([e])
        },
        setCheckedDisabledClass: function() {
            this.checkIcon && (this.checked ? this.checkIcon.addClass("syno-ux-cb-checked") : this.checkIcon.removeClass("syno-ux-cb-checked")), this.disabled ? (this.checkIcon && this.checkIcon.addClass("syno-ux-cb-disabled"), this.boxlabelEl && this.boxlabelEl.addClass("syno-ux-cb-disabled")) : this.readOnly ? (this.checkIcon && this.checkIcon.addClass("syno-ux-cb-disabled"), this.boxlabelEl && this.boxlabelEl.removeClass("syno-ux-cb-disabled")) : (this.checkIcon && this.checkIcon.removeClass("syno-ux-cb-disabled"), this.boxlabelEl && this.boxlabelEl.removeClass("syno-ux-cb-disabled"))
        }
    }), Ext.define("SYNO.SDS.Drive.AddEditWindow", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        nameItemId: "title",
        maxNameLength: SYNO.SDS.Drive.Define.TAG_MAX_LENGTH,
        constructor: function(e) {
            e.mode && (this.mode = e.mode || "edit");
            var t = {
                title: "add" === this.mode ? _T("common", "create") : _T("common", "alt_edit"),
                items: this.getFormPanel(),
                buttons: [{
                    itemId: "cancel",
                    text: _T("common", "cancel"),
                    scope: this,
                    handler: this.onCancel
                }, {
                    itemId: "ok",
                    text: _T("common", "ok"),
                    btnStyle: "default",
                    scope: this,
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    handler: this.onApply
                }]
            };
            SYNO.SDS.CSTN.IsDSM7OrAbove() || t.buttons.reverse();
            var i = Ext.apply(t, e);
            this.callParent([i]), this.mon(this, "afterlayout", this.onAfterLayout, this, {
                single: !0
            }), this.mon(this, "show", this.onDelayShow, this, {
                single: !0,
                buffer: 300
            })
        },
        onAfterLayout: function() {
            this.center()
        },
        onDelayShow: function() {
            var e = this.getForm().findField(this.nameItemId);
            e && (e.focus(), e.selectText(0, e.getValue().length))
        },
        getForm: function() {
            return this.getFormPanel().getForm()
        },
        getFormPanel: Ext.emptyFn,
        getParams: function() {
            return this.getForm().getFieldValues(!0)
        },
        onApplyDone: Ext.emptyFn,
        isValid: function() {
            return this.getForm().isValid()
        },
        onApply: function() {
            if (!this.isValid()) {
                var e = this.getForm().findField(this.nameItemId);
                if (!e) return;
                var t = e.getActiveError();
                return void(Ext.isEmpty(t) || this.getMsgBox().alert("", t))
            }
            if (!this.isDirty()) return void this.close();
            var i = this.getParams();
            i && (this.setStatusBusy({
                text: _T("common", "loading")
            }), this.onAction(i))
        },
        onAction: Ext.emptyFn,
        onApplyCb: function(e, t, i, n) {
            if (this.clearStatusBusy(), e) return this.onApplyDone(t, i, n), void this.close();
            this.setStatusError({
                text: SYNO.SDS.Drive.Utils.getErrorStr(t)
            }), this.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t), this.onErrorCb.createDelegate(this, [t]), this)
        },
        onErrorCb: Ext.emptyFn,
        onCancel: function() {
            if ("edit" !== this.mode || !this.isDirty()) return void this.close();
            var e = function(e) {
                "yes" === e && this.close()
            };
            this.getMsgBox().confirm(this.title, _T("common", "confirm_lostchange"), e, this)
        },
        isDirty: function() {
            return !!this.getForm() && this.getForm().isDirty()
        },
        nameValidator: function(e) {
            var t = e.trim();
            return 0 === t.length ? this.getForm().findField(this.nameItemId).blankText : t.length > 0 && t.length < this.maxNameLength
        }
    }), Ext.define("SYNO.SDS.Drive.Share.Window", {
        extend: "SYNO.SDS.Drive.AddEditWindow",
        constructor: function(e) {
            var t = e.display_path || "",
                i = SYNO.SDS.Drive.Utils.isDisplayPathUnderMyDrive(t);
            this.enable_public_sharing = e.adv_shared && i || SYNO.SDS.Drive.Define.Info.sharing_permission.public_sharing;
            var n = this.fillConfig(e);
            this.callParent([n]), this.mon(this, "beforeclose", this.onBeforeClose, this)
        },
        fillConfig: function(e) {
            this.owner = e.owner, this.path = e.path, this.closeCheck = !0;
            var t = {
                title: SYNO.SDS.Drive._T("common", "share"),
                width: 560,
                height: 601,
                layout: "fit",
                resizeHandles: "n s",
                items: this.getTabPanel(e),
                buttons: [{
                    itemId: "ok",
                    text: SYNO.SDS.Drive._T("btn", "save"),
                    btnStyle: "default",
                    scope: this,
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    handler: this.onApply
                }]
            };
            return Ext.apply(t, e)
        },
        getTabPanel: function(e) {
            if (this.tabPanel) return this.tabPanel;
            var t = [this.getFormPanel(e)];
            return this.enable_public_sharing && t.push(this.getAdvancedPanel(e)), this.tabPanel = new SYNO.ux.TabPanel({
                activeTab: 0,
                items: t
            }), this.tabPanel
        },
        getFormPanel: function(e) {
            return this.shareFormPanel || (this.shareFormPanel = new SYNO.SDS.Drive.Share.FormPanel(e))
        },
        getAdvancedPanel: function(e) {
            return this.shareAdvancedPanel || (this.shareAdvancedPanel = new SYNO.SDS.Drive.Share.AdvancedPanel(e))
        },
        isValid: function() {
            return this.shareFormPanel.isValid() && (!this.shareAdvancedPanel || this.shareAdvancedPanel.isValid())
        },
        isDirty: function() {
            return this.shareFormPanel.isDirty() || this.shareAdvancedPanel && this.shareAdvancedPanel.isDirty()
        },
        onBeforeApply: function() {
            var e = [this.shareFormPanel.onBeforeApply()];
            return this.enable_public_sharing && e.push(this.shareAdvancedPanel.onBeforeApply()), Promise.all(e)
        },
        onApply: function() {
            return this.isDirty() ? this.isValid() ? void Promise.resolve().then(function() {
                return this.onBeforeApply()
            }.bind(this)).catch(function() {
                return Promise.reject()
            }).then(function() {
                this.setStatusBusy();
                var e = [this.shareFormPanel.onApply()];
                return this.enable_public_sharing && e.push(this.shareAdvancedPanel.onApply()), Promise.all(e)
            }.bind(this)).then(function() {
                this._close()
            }.bind(this)).catch(function(e) {
                Ext.isEmpty(e) || (SYNO.Debug.error(e), this.clearStatusBusy(), this.setStatusError({
                    text: SYNO.SDS.Drive.Utils.getErrorStr(e)
                }))
            }.bind(this)) : void this.setStatusError({
                text: _T("common", "forminvalid"),
                duration: 3e3
            }) : void this._close()
        },
        onCancel: function() {
            if (!this.isDirty()) return void this._close();
            var e = function(e) {
                "yes" === e && this._close()
            };
            this.getMsgBox().confirm(this.title, _T("common", "confirm_lostchange"), e, this)
        },
        onBeforeClose: function() {
            if (this.closeCheck) return this.onCancel(), !1
        },
        _close: function() {
            this.closeCheck = !1, this.close()
        }
    }), Ext.define("SYNO.SDS.Drive.ArrowMenu", {
        extend: "SYNO.ux.Menu",
        constructor: function(e) {
            this.callParent([Ext.apply({
                cls: "syno-d-arrow-menu " + (e.cls || ""),
                resizable: !1,
                autoHeight: !0,
                enableScrolling: !1
            }, e)]), this.mon(this, "hide", this.destroy, this), this.mon(this, "beforedestroy", this.destroyArrow, this)
        },
        open: function(e) {
            if (!this.isDestroyed && !this.destroying) {
                this.el || (this.render(), this.doLayout(!1, !0));
                var t = Ext.get(e),
                    i = this.getDefaultLayout(),
                    n = SYNO.SDS.Drive.Utils.getAlignToXY(this.el, t, i.position, i.offset),
                    s = n.viewportReachBoundry;
                i = this.getLayout(s), n = SYNO.SDS.Drive.Utils.getAlignToXY(this.el, t, i.position, i.offset), this.showAt(n.xy), i = this.getArrowLayout(s), this.showArrow(e, i)
            }
        },
        showArrow: function(e, t) {
            this.arrows = [], this.arrows.push(Ext.DomHelper.append(Ext.getBody(), '<div class="syno-d-arrow syno-d-arrow-white"></div>', !0)), this.arrows.push(Ext.DomHelper.append(Ext.getBody(), '<div class="syno-d-arrow syno-d-arrow-black"></div>', !0)), Ext.each(this.arrows, function(i) {
                i.alignTo(e, t.position, t.offset)
            })
        },
        destroyArrow: function() {
            this.arrows && Ext.each(this.arrows, function(e) {
                e.remove()
            })
        },
        getDefaultLayout: function() {
            return {
                position: "tl-bl?",
                offset: [0, 10]
            }
        },
        getLayout: function(e) {
            return this.getDefaultLayout()
        },
        getArrowLayout: function(e) {
            return {
                position: e.bottom ? "b-t" : "t-b",
                offset: [0, 0]
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Share.GetLink.FieldSet.Base", {
        extend: "SYNO.ux.FieldSet",
        constructor: function(e) {
            SYNO.Assert(e.file_info, "need file_info"), this.callParent([Ext.apply({
                collapsible: !1,
                items: [this.getShareLinkComposite(), this.getPermissionInfo()]
            }, e)]), this.addEvents("copy_url_done", "copy_url_failed")
        },
        getShareLinkComposite: function() {
            return this.shareLinkComposite || (this.shareLinkComposite = new SYNO.SDS.Utils.ClipBoardComposite({
                cls: "syno-d-link-composite-field",
                disableWhenEmpty: !1,
                hideLabel: !0,
                defaultMargins: "0 8 0 0",
                textFieldCfg: {
                    cls: "syno-d-share-link-text selectabletext allowDefCtxMenu",
                    readOnly: !0,
                    selectOnFocus: !0,
                    width: 312
                },
                btnCfg: {
                    tooltip: SYNO.SDS.Drive._T("info", "copy_url"),
                    cls: "syno-d-copy-btn",
                    iconCls: "syno-d-copy-btn-icon",
                    btnStyle: "grey",
                    width: 40
                },
                listeners: {
                    clipsucceed: function(e) {
                        this.fireEvent("copy_url_done")
                    },
                    clipfailed: function(e) {
                        this.fireEvent("copy_url_failed")
                    },
                    scope: this
                }
            }))
        },
        copyToClipBoard: function() {
            this.getShareLinkComposite().btn.btnEl.dom.click()
        },
        getLinkField: function() {
            return this.shareLinkComposite.textField
        },
        getPermissionInfo: function() {
            return {
                cls: "syno-d-getlink-permission-info",
                itemId: "permission_info",
                xtype: "box",
                html: ""
            }
        },
        updatePermissionInfo: function(e) {
            var t = this.getComponent("permission_info");
            t.rendered ? t.update(e) : t.html = e
        }
    }), Ext.define("SYNO.SDS.Drive.WebAPIDesc", {
        statics: {
            get_file: {
                api: "SYNO.SynologyDrive.Files",
                method: "get",
                version: 3
            },
            update_file: {
                api: "SYNO.SynologyDrive.Files",
                method: "update",
                version: 2
            },
            star_file: {
                api: "SYNO.SynologyDrive.Files",
                method: "star",
                version: 2
            },
            delete_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "delete",
                version: 2
            },
            share_file: {
                api: "SYNO.SynologyDrive.Sharing",
                method: "update",
                version: 1
            },
            request_access: {
                api: "SYNO.SynologyDrive.Files",
                method: "request_access",
                version: 2
            },
            copy_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "copy",
                version: 2
            },
            move_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "move",
                version: 2
            },
            get_file_link: {
                api: "SYNO.SynologyDrive.Sharing",
                method: "create_link",
                version: 1
            },
            get_base_url: {
                api: "SYNO.SynologyDrive.Sharing",
                method: "get_base_url",
                version: 2
            },
            list_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "list",
                version: 2
            },
            list_shared_with_me: {
                api: "SYNO.SynologyDrive.Files",
                method: "shared_with_me",
                version: 2
            },
            list_shared_with_others: {
                api: "SYNO.SynologyDrive.Files",
                method: "shared_with_others",
                version: 2
            },
            list_recent: {
                api: "SYNO.SynologyDrive.Files",
                method: "recent",
                version: 2
            },
            list_label_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "list_labelled",
                version: 2
            },
            list_star_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "list_starred",
                version: 2
            },
            list_team_folders: {
                api: "SYNO.SynologyDrive.TeamFolders",
                method: "list",
                version: 1
            },
            list_team_folders_members: {
                api: "SYNO.SynologyDrive.TeamFolders",
                version: 1,
                method: "list_members"
            },
            list_labels: {
                api: "SYNO.SynologyDrive.Labels",
                method: "list",
                version: 1
            },
            list_trash: {
                api: "SYNO.SynologyDrive.Trash",
                method: "list",
                version: 1
            },
            list_trash_ancestor: {
                api: "SYNO.SynologyDrive.Trash",
                method: "list_ancestor",
                version: 1
            },
            list_node_ancestor: {
                api: "SYNO.SynologyDrive.Files",
                method: "list_ancestor",
                version: 2
            },
            create_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "create",
                version: 2
            },
            list_revisions: {
                api: "SYNO.SynologyDrive.Revisions",
                method: "list",
                version: 1
            },
            restore_revisions: {
                api: "SYNO.SynologyDrive.Revisions",
                method: "restore",
                version: 1
            },
            list_office_revisions: {
                api: "SYNO.Office.Node.Version",
                method: "list",
                version: 1
            },
            restore_office_revisions: {
                api: "SYNO.Office.Node.Version",
                method: "restore",
                version: 1
            },
            download_revisions: {
                api: "SYNO.SynologyDrive.Revisions",
                method: "download",
                version: 1
            },
            upload_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "upload",
                version: 2,
                uploadAttr: "file"
            },
            upload_files_from_nas: {
                api: "SYNO.SynologyDrive.Files",
                method: "upload_from_dsm",
                version: 2
            },
            download_files: {
                api: "SYNO.SynologyDrive.Files",
                method: "download",
                version: 2
            },
            search_files: {
                api: "SYNO.SynologyDrive.Files",
                version: 2,
                method: "search"
            },
            list_app_priv: {
                api: "SYNO.SynologyDrive.Share.Priv",
                method: "list",
                version: 1
            },
            list_tasks: {
                api: "SYNO.SynologyDrive.Tasks",
                method: "list",
                version: 1
            },
            get_task: {
                api: "SYNO.SynologyDrive.Tasks",
                method: "get",
                version: 1
            },
            delete_task: {
                api: "SYNO.SynologyDrive.Tasks",
                method: "delete",
                version: 1
            },
            info: {
                api: "SYNO.SynologyDrive.Info",
                version: 2,
                method: "get"
            },
            get_quota: {
                api: "SYNO.SynologyDrive.Info",
                version: 2,
                method: "quota"
            },
            get_setting: {
                api: "SYNO.SynologyDrive.Settings",
                version: 2,
                method: "list"
            },
            update_setting: {
                api: "SYNO.SynologyDrive.Settings",
                version: 2,
                method: "update"
            },
            get_user_setting: {
                api: "SYNO.SynologyDrive.Users",
                version: 1,
                method: "get"
            },
            update_user_setting: {
                api: "SYNO.SynologyDrive.Users",
                version: 1,
                method: "update"
            },
            get_dsm_setting: {
                api: "SYNO.SynologyDrive.DSM",
                version: 1,
                method: "get"
            },
            list_notifications: {
                api: "SYNO.SynologyDrive.Notifications",
                method: "list",
                version: 1
            },
            create_notification: {
                api: "SYNO.SynologyDrive.Notifications",
                method: "create",
                version: 1
            },
            set_labels: {
                api: "SYNO.SynologyDrive.Files",
                version: 2,
                method: "label"
            },
            create_labels: {
                api: "SYNO.SynologyDrive.Labels",
                version: 1,
                method: "create"
            },
            update_labels: {
                api: "SYNO.SynologyDrive.Labels",
                version: 1,
                method: "update"
            },
            delete_labels: {
                api: "SYNO.SynologyDrive.Labels",
                version: 1,
                method: "delete"
            },
            list_chat_channels: {
                api: "SYNO.SynologyDrive.Services.SynologyChat",
                version: 1,
                method: "list"
            },
            bind_chat_channels: {
                api: "SYNO.SynologyDrive.Services.SynologyChat",
                version: 1,
                method: "bind"
            },
            convert_office: {
                api: "SYNO.SynologyDrive.Files",
                version: 2,
                method: "convert_office"
            },
            get_thumbnail: {
                api: "SYNO.SynologyDrive.Files",
                version: 2,
                method: "get_thumbnail"
            },
            get_dsm_thumbnail: {
                api: "SYNO.Core.File.Thumbnail",
                version: 1,
                method: "get"
            },
            get_metadata: {
                api: "SYNO.SynologyDrive.Photos",
                version: 1,
                method: "get_metadata"
            },
            create_vs_link: {
                api: "SYNO.SynologyDrive.Services.VideoStation",
                version: 1,
                method: "create"
            },
            doc_convert: {
                api: "SYNO.SynologyDrive.Services.DocumentViewer",
                version: 1,
                method: "create"
            },
            sync_to_device: {
                api: "SYNO.SynologyDrive.Sharing",
                method: "sync_to_device",
                version: 1
            },
            office_status: {
                api: "SYNO.SynologyDrive.Office",
                method: "status",
                version: 1
            },
            plugin_string: {
                api: "SYNO.SynologyDrive.String",
                method: "get",
                version: 1
            },
            empty_recycle_bin: {
                api: "SYNO.SynologyDrive.Trash",
                method: "empty",
                version: 1
            },
            auth_adv_sharing: {
                api: "SYNO.SynologyDrive.AdvanceSharing.Public",
                method: "auth",
                version: 1
            },
            get_adv_sharing: {
                api: "SYNO.SynologyDrive.AdvanceSharing",
                method: "get",
                version: 1
            },
            create_adv_sharing: {
                api: "SYNO.SynologyDrive.AdvanceSharing",
                method: "create",
                version: 1
            },
            update_adv_sharing: {
                api: "SYNO.SynologyDrive.AdvanceSharing",
                method: "update",
                version: 1
            },
            remove_adv_sharing: {
                api: "SYNO.SynologyDrive.AdvanceSharing",
                method: "delete",
                version: 1
            },
            list_backup_tasks: {
                api: "SYNO.SynologyDrive.Files",
                method: "list_backup_tasks",
                version: 3
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Sharing", {
        singleton: !0,
        GetURL: function(e, t) {
            var i, n = window.location.pathname;
            n = n.replace(/\/d\/s\/([A-Za-z0-9]+)\/([^\/]+)/, ""), SYNO.SDS.JSDebug && (i = Ext.apply(i || {}, {
                jsDebug: SYNO.SDS.JSDebug
            })), n && "/" === n.charAt(n.length - 1) || (n += "/");
            var s = n + "d/s/" + e + "/" + t;
            return i && (s = Ext.urlAppend(s, Ext.urlEncode(i), !1)), s
        },
        GetSharingLink: function() {
            if (this.sharing_link) return this.sharing_link;
            var e = /\/d\/s\/([A-Za-z0-9]+)\/([^\/]+)$/g.exec(location.pathname);
            if (e && 3 === e.length) this.sharing_link = e[2];
            else {
                var t = Ext.urlDecode(window.location.search.substr(1));
                t && t.sharing_link && (this.sharing_link = t.sharing_link)
            }
            return this.sharing_link
        },
        GetSharingToken: function() {
            if (this.sharing_token) return this.sharing_token;
            var e = this.GetSharingLink();
            if (e) {
                var t = Ext.util.Cookies.get("drive-sharing-" + e);
                t && (this.sharing_token = t)
            }
            return this.sharing_token
        },
        AddSharingToken: function(e, t, i) {
            if (e) {
                var n = this.GetSharingToken();
                if (n) {
                    var s = e.api || t;
                    if (/^SYNO\.SynologyDrive\.|^SYNO\.Office\./.test(s)) e.sharing_token = i ? Ext.encode(n) : n;
                    else if ("SYNO.Entry.Request" === s && e.compound) {
                        var o, r = e.compound,
                            a = !1;
                        Ext.isString(r) ? (a = !0, o = Ext.decode(r) || []) : o = r.params || [];
                        for (var l = 0; l < o.length; ++l) this.AddSharingToken(o[l]);
                        a && (e.compound = Ext.encode(o))
                    }
                }
            }
        },
        Override: function() {
            Ext.Ajax.on("beforerequest", function(e, t) {
                this.AddSharingToken(t.params, void 0, !0)
            }, this), Ext.ori_urlAppend = Ext.urlAppend, Ext.urlAppend = function(e, t, i) {
                if (i = void 0 === i || i) {
                    var n, s = Ext.urlDecode(t);
                    if (Ext.isObject(s) && !s.sharing_token && s.api && (n = SYNO.SDS.Drive.Sharing.GetSharingToken()) && /^SYNO\.SynologyDrive\.|^SYNO\.Office\./.test(s.api)) return s.sharing_token = n, Ext.ori_urlAppend(e, Ext.urlEncode(s), i)
                }
                return Ext.ori_urlAppend(e, t, i)
            }, SYNO.API.currentManager.getBaseURL && (SYNO.API.currentManager.ori_getBaseURL = SYNO.API.currentManager.getBaseURL, SYNO.API.currentManager.getBaseURL = function(e, t, i, n, s) {
                if (Ext.isObject(e)) return SYNO.SDS.Drive.Sharing.GetSharingToken() && (e.params || (e.params = {}), SYNO.SDS.Drive.Sharing.AddSharingToken(e.params, e.api)), SYNO.API.currentManager.ori_getBaseURL(e, t, i, n, s);
                var o = {
                    api: e,
                    method: t,
                    version: i
                };
                return SYNO.SDS.Drive.Sharing.GetSharingToken() && (o.params = {}, SYNO.SDS.Drive.Sharing.AddSharingToken(o.params, o.api)), SYNO.API.currentManager.ori_getBaseURL(o, n, s)
            })
        }
    }), Ext.override(SYNO.SDS.Utils.IFrame, {
        createIFrame: function(e, t) {
            var i = Ext.id(),
                n = e.createElement("iframe");
            return n.setAttribute("src", ""), n.setAttribute("id", i), n.setAttribute("name", i), t && n.setAttribute("src", t), n.setAttribute("frameBorder", "0"), n.setAttribute("style", "border:0px none;width:0;height:0;position:absolute;top:-100000px"), e.body.appendChild(n), n
        }
    }), Ext.ns("SYNO.SDS.Drive"), SYNO.SDS.Drive.Override = function() {
        SYNO.SDS.Drive.isRunOverride || (SYNO.SDS.Drive.isRunOverride = !0, SYNO.SDS.Utils.Logout.redirect = function(e) {
            var t = SYNO.SDS.Drive.WindowHelper.getBaseAppPath() + "/",
                i = SYNO.SDS.Drive.Utils.getAppURL();
            this.logoutTriggered = !0;
            var n = function() {
                window.location.href === window.location.origin + i ? window.location.reload() : window.location.href = i
            };
            !1 === e ? n() : function() {
                var e = t + "webman/logout.cgi";
                Ext.Ajax.request({
                    method: "POST",
                    url: e,
                    callback: function() {
                        n()
                    }
                })
            }()
        }, SYNO.SDS.Strings["SYNO.SDS.Drive.MainWindow"] = SYNO.SDS.Strings["SYNO.SDS.Drive.PublicApplication"] = SYNO.SDS.Strings["SYNO.SDS.Drive.BasicInstance"] = SYNO.SDS.Strings["SYNO.SDS.Drive.BasicApp"] = SYNO.SDS.Strings["SYNO.SDS.Drive.Application"], SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"] || (SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"] = SYNO.SDS.Strings["SYNO.SDS.Drive.Application"]), "SYNO.SDS.Drive.PublicApplication" === _S("standaloneAppName") && SYNO.SDS.Drive.Sharing.Override())
    }, SYNO.SDS.Drive.updatePrototype = function(e) {
        for (var t, i = document.getElementsByTagName("script"), n = 0; n < i.length; ++n) {
            var s = i[n].src;
            if (-1 !== s.indexOf("prototype.js")) return void(e && e()); - 1 !== s.indexOf("ext-base.js") && (t = s.replace(/ext-3\/adapter\/ext\/ext-base.js/, "prototype-1.7.2/prototype.js"))
        }
        if (t) {
            var o = document.createElement("script");
            o.type = "text/javascript", o.src = t, e && (o.onload = e), document.head.appendChild(o)
        }
    }, "SYNO.SDS.Drive.Application" !== _S("standaloneAppName") && "SYNO.SDS.Drive.PublicApplication" !== _S("standaloneAppName") && "SYNO.SDS.Drive.BasicInstance" !== _S("standaloneAppName") || (SYNO.SDS.Drive.Override(), _S("majorversion") <= 6 && SYNO.SDS.Drive.updatePrototype()), Ext.define("SYNO.SDS.Drive.WebAPICore", {
        statics: {
            getApiConfig: function(e, t) {
                var i = Object.create(SYNO.SDS.Drive.WebAPIDesc[e]);
                return i.params = Ext.apply(i.baseParams || {}, t), i
            },
            formatApiObj: function(e, t, i, n, s, o) {
                var r = this.getApiConfig(e, t);
                return i && (r.callback = i), n && (r.progress = n), s && (r.scope = s), r.uploadAttr && (o = Ext.apply(o || {}, {
                    timeout: 864e5
                }), Ext.apply(r, o), r.processApiObj = function(e, t) {
                    return function(t) {
                        return t.html5upload = !1, t.params[t.uploadAttr] && (t.html5upload = !0, t.uploadData = new FormData, Ext.iterate(t.params, function(e, i) {
                            (e === t.uploadAttr || Ext.isString(i)) && (!(i instanceof File) && i instanceof Blob ? t.uploadData.append(e, i, i.name) : t.uploadData.append(e, i), delete t.params[e])
                        })), Ext.isFunction(e) ? e(t) : t
                    }
                }(r.processApiObj, r.uploadAttr)), r.processApiObj && (r = r.processApiObj(r)), r
            },
            send: function(e, t, i, n, s, o) {
                var r = {};
                Ext.isFunction(i) ? r.callback = i : Ext.isObject(i) && (r = i);
                var a = SYNO.SDS.Drive.GetWindow() || n,
                    l = this;
                if (Ext.isArray(e)) {
                    t = t || [];
                    var d, h = [];
                    for (d = 0; d < e.length; d++) h.push(l.formatApiObj(e[d], t[d]));
                    return a.sendWebAPI({
                        compound: Ext.apply({
                            mode: "parallel",
                            params: h,
                            stopwhenerror: !0
                        }, s),
                        scope: n || window,
                        callback: r.callback
                    })
                }
                return a.sendWebAPI(l.formatApiObj(e, t, r.callback, r.progress, n, o))
            },
            sendPromise: function(e, t, i, n) {
                return new Promise(function(s, o) {
                    this.send(e, t, function(e, t, i, n) {
                        e && !t.has_fail ? s(t) : (this._handleCompoundLogout(t), o(t))
                    }.bind(this), null, i, n)
                }.bind(this))
            },
            _handleCompoundLogout: function(e) {
                e.result && Ext.isArray(e.result) && Ext.each(e.result, function(e) {
                    var t, i;
                    if (e.error && e.error.code && (t = e.error.code) >= 105 && t <= 107) return i = SYNO.API.Errors.common[t], SYNO.SDS.Utils.Logout.action(!0, i, !0), !1
                })
            },
            download: function(e, t, i, n, s) {
                var o = SYNO.SDS.Drive.GetWindow() || s;
                t = Ext.apply(t, {
                    _dc: (new Date).getTime()
                }), o.downloadWebAPI({
                    webapi: this.getApiConfig(e, t),
                    filename: i,
                    callback: function(e, t, i, r) {
                        if (SYNO.SDS.Drive.Utils.isMobile() && SYNO.SDS.Drive.Utils.isiOS() && "load" === e) return void window.open(t.src, "_self");
                        "timeout" === e || Ext.isGecko && !Ext.isObject(r) || (Ext.isFunction(n) ? Ext.callback(n, s, [r, t], 1) : SYNO.SDS.Drive.Utils.showErrorMsg(o, r))
                    }
                })
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Share.GetLink.FieldSet.ShareLink", {
        extend: "SYNO.SDS.Drive.Share.GetLink.FieldSet.Base",
        statics: {
            getPermissionText: function(e) {
                var t = SYNO.SDS.Drive._T,
                    i = t("perm", "limit"),
                    n = t("perm", "limit_desc");
                return SYNO.SDS.Drive.Define.Info.sharing_permission.invite_sharing || (n = t("perm", "limit_you_desc")), Ext.each(e.shared_with, function(e) {
                    switch (e.type) {
                        case "public":
                            i = t("perm", "public"), n = {
                                previewer: t("perm", "public_previewer_desc"),
                                viewer: t("perm", "public_ro_desc"),
                                commenter: t("perm", "public_commenter_desc"),
                                editor: t("perm", "public_rw_desc"),
                                preview_commenter: t("perm", "public_preview_commenter_desc")
                            } [e.role];
                            break;
                        case "internal":
                            i = t("perm", "app"), n = {
                                previewer: t("perm", "app_previewer_desc"),
                                viewer: t("perm", "app_ro_desc"),
                                commenter: t("perm", "app_commenter_desc"),
                                editor: t("perm", "app_rw_desc"),
                                preview_commenter: t("perm", "app_preview_commenter_desc")
                            } [e.role]
                    }
                }, this), String.format("<b>{0}</b> - {1}", i, n)
            }
        },
        constructor: function(e) {
            var t = SYNO.SDS.Drive._T;
            this.callParent([Ext.apply({
                title: "dir" === e.file_info.file_type ? t("share", "directory_link") : t("share", "file_link")
            }, e)]), this.readyPromise = this.initQuerySharing(), this.updatePermissionInfo(SYNO.SDS.Drive.Share.GetLink.FieldSet.ShareLink.getPermissionText(e.file_info))
        },
        getReadyPromise: function() {
            return this.readyPromise
        },
        initQuerySharing: function() {
            var e = this;
            return SYNO.SDS.Drive.WebAPICore.sendPromise("get_file_link", {
                path: this.file_info.path
            }).then(function(t) {
                e.updateSharingResult(t)
            }).catch(function(e) {
                SYNO.Debug.error(e, e.stack)
            })
        },
        updateSharingResult: function(e) {
            this.getLinkField().setValue(e.url)
        }
    }), Ext.define("SYNO.SDS.Drive.Share.GetLink.FieldSet.AdvanceSharingLink", {
        extend: "SYNO.SDS.Drive.Share.GetLink.FieldSet.Base",
        statics: {
            getPermissionText: function(e) {
                var t = SYNO.SDS.Drive._T,
                    i = t("perm", "public"),
                    n = {
                        accesser: t("perm", "public_access_desc"),
                        previewer: t("perm", "public_previewer_desc"),
                        viewer: t("perm", "public_ro_desc"),
                        commenter: t("perm", "public_commenter_desc"),
                        editor: t("perm", "public_rw_desc"),
                        preview_commenter: t("perm", "public_preview_commenter_desc")
                    } [e.role];
                return String.format("<b>{0}</b> - {1}", i, n)
            }
        },
        constructor: function(e) {
            this.fileInfo = e.file_info;
            var t = SYNO.SDS.Drive._T,
                i = !this.fileInfo.capabilities.can_share && !SYNO.SDS.Drive.Utils.isAdvSharingPage();
            this.callParent([Ext.apply({
                title: t("share", "public_protection_link"),
                hidden: i
            }, e)]), this.readyPromise = i ? Promise.resolve() : this.initQueryAdvSharing()
        },
        getReadyPromise: function() {
            return this.readyPromise
        },
        initQueryAdvSharing: function() {
            var e = this;
            return this.fileInfo.capabilities.can_share ? SYNO.SDS.Drive.WebAPICore.sendPromise("get_adv_sharing", {
                path: this.file_info.path
            }).then(function(t) {
                e.updateAdvSharingResult(t)
            }).catch(function(t) {
                t.code && 1036 === t.code || SYNO.Debug.error(t), e.hide()
            }) : SYNO.SDS.Drive.Utils.isAdvSharingPage() ? SYNO.SDS.Drive.WebAPICore.sendPromise("get_base_url", {}).then(function(t) {
                var i = t.base_url + window.location.pathname,
                    n = {
                        url: i,
                        role: "accesser"
                    };
                e.updateAdvSharingResult(n)
            }).catch(function() {
                e.hide()
            }) : (e.hide(), Promise.resolve())
        },
        updateAdvSharingResult: function(e) {
            this.getLinkField().setValue(e.url), this.updatePermissionInfo(SYNO.SDS.Drive.Share.GetLink.FieldSet.AdvanceSharingLink.getPermissionText(e))
        }
    }), Ext.define("SYNO.SDS.Drive.Share.GetLink.Panel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            SYNO.Assert(e.file_info, "need file info"), SYNO.Assert(e.file_info.path, "need path"), SYNO.Assert(e.file_info.capabilities, "need capabilities"), SYNO.Assert(e.file_info.shared_with, "need shared_with"), SYNO.Assert(void 0 !== e.file_info.file_type, "need file_type"), this.callParent([{
                title: SYNO.SDS.Drive._T("share", "get_link"),
                cls: "syno-d-share-getlink-formpanel",
                layout: "anchor",
                autoFlexcroll: !1,
                items: [this.share_link = new SYNO.SDS.Drive.Share.GetLink.FieldSet.ShareLink({
                    file_info: e.file_info
                }), this.adv_share_link = new SYNO.SDS.Drive.Share.GetLink.FieldSet.AdvanceSharingLink({
                    file_info: e.file_info
                }), this.getShareSettingButton(e.file_info)]
            }]), this.addEvents("open_share_setting", "copy_url_done", "copy_url_failed"), this.relayEvents(this.share_link, ["copy_url_done", "copy_url_failed"]), this.relayEvents(this.adv_share_link, ["copy_url_done", "copy_url_failed"])
        },
        isAdvanceSharingLinkShown: function() {
            return !this.adv_share_link.hidden
        },
        copySharedLink: function() {
            this.share_link.copyToClipBoard()
        },
        getReadyPromise: function() {
            return this.readyPromise || (this.readyPromise = Promise.all([this.share_link.getReadyPromise(), this.adv_share_link.getReadyPromise()]))
        },
        getShareSettingButton: function(e) {
            var t = SYNO.SDS.Drive._T,
                i = !SYNO.SDS.Drive.Utils.checkSharePrivilge(e, e.capabilities.can_share);
            return {
                xtype: "button",
                text: t("share", "sharing_settings"),
                handler: this.onOpenShareSetting,
                scope: this,
                hidden: i,
                buttonSelector: "div:first-child",
                iconCls: "syno-d-text-btn",
                template: new Ext.Template('<div id="{4}">', "<div></div>", "</div>")
            }
        },
        onOpenShareSetting: function() {
            this.fireEvent("open_share_setting")
        }
    }), Ext.define("SYNO.SDS.Drive.Share.GetLink.Menu", {
        extend: "SYNO.SDS.Drive.ArrowMenu",
        constructor: function(e) {
            SYNO.Assert(e.file_info, "need file info"), SYNO.Assert(e.file_info.path, "need path"), SYNO.Assert(e.file_info.capabilities, "need capabilities"), SYNO.Assert(e.file_info.shared_with, "need shared_with"), SYNO.Assert(void 0 !== e.file_info.file_type, "need file_type");
            var t = e.file_info;
            delete e.file_info, this.callParent([Ext.apply({
                cls: "syno-d-getlink-menu",
                title: SYNO.SDS.Drive._T("share", "get_link"),
                items: this.panel = new SYNO.SDS.Drive.Share.GetLink.Panel({
                    owner: this,
                    file_info: t
                })
            }, e)]), this.mon(this.panel, "open_share_setting", this.onOpenShareSetting, this), this.mon(this.panel, "copy_url_done", this.onCopyUrlDone, this)
        },
        onCopyUrlDone: function() {
            SYNO.SDS.Drive.Utils.showToastMsg(this.findAppWindow(), SYNO.SDS.Drive._T("share", "url_copied"))
        },
        onOpenShareSetting: function() {
            this.hide(), this.getAction().shareNode()
        },
        setAction: function(e) {
            this.action = e
        },
        getAction: function() {
            return this.action || SYNO.SDS.Drive.GetWindow().getAction()
        },
        open: function(e, t) {
            this.panelType = e, this.panel.getReadyPromise().then(function() {
                SYNO.SDS.Drive.ArrowMenu.prototype.open.call(this, t), this.panel.isAdvanceSharingLinkShown() || this.panel.copySharedLink()
            }.bind(this))
        },
        getDefaultLayout: function() {
            return this.getLayout()
        },
        getLayout: function(e) {
            var t, i, n, s = {
                position: "tl-bl?",
                offset: [0, 0]
            };
            switch (this.panelType) {
                case "toolbar":
                    s.offset = [-20, 16];
                    break;
                case "menu_pathbar":
                    s.offset = [-50, 10], s.position = "tl-b?";
                    break;
                case "thumbnail":
                    s.offset = [-1, 10], e && (t = "{0}{1}-{2}{1}?", i = "l", n = "tb".split(""), e.right && (i = "r", s.offset[0] = 1), e.bottom && (n = "bt".split(""), s.offset[1] = -18), s.position = String.format(t, n[0], i, n[1]));
                    break;
                case "detail":
                case "list":
                    s.offset = [12, 6];
                    break;
                case "tile":
                    s.offset = [-10, 8], e && (t = "{0}{1}-{2}{1}?", i = "l", n = "tb".split(""), e.right && (i = "r", s.offset[0] = 0), e.bottom && (n = "bt".split(""), s.offset[1] = -8), s.position = String.format(t, n[0], i, n[1]));
                    break;
                case "snippet":
                    s.offset = [5, 4], e && e.bottom && (s.offset = [5, 7])
            }
            return s
        },
        getArrowLayout: function(e) {
            var t = {
                position: e.bottom ? "bl-tl" : "tl-bl",
                offset: [0, 0]
            };
            switch (this.panelType) {
                case "toolbar":
                    t.offset = [6, 6];
                    break;
                case "menu_pathbar":
                    t.offset = [-24, 0], t.position = "tl-b?";
                    break;
                case "thumbnail":
                    t.position = e.bottom ? "b-t" : "t-b", t.offset = e.bottom ? [-3, -10] : [-3, 0];
                    break;
                case "detail":
                    t.offset = e.bottom ? [45, 3] : [45, -4];
                    break;
                case "list":
                    t.offset = e.bottom ? [38, 3] : [38, -4];
                    break;
                case "tile":
                    t.offset = e.bottom ? [7, 0] : [7, -2];
                    break;
                case "snippet":
                    t.offset = e.bottom ? [30, 2] : [30, -6]
            }
            return e.bottom && (t.offset[1] -= 5), t
        }
    }), Ext.ns("SYNO.SDS.Drive.Log"), SYNO.SDS.Drive.Log.STATUS_COL_WIDTH = 150, SYNO.SDS.Drive.Log.LOG_PAGE_LIMIT = 1e3, SYNO.SDS.Drive.Log.LOG_COL_WIDTH = 250, Ext.define("SYNO.SDS.Drive.Log.Panel", {
        extend: "SYNO.ux.EditorGridPanel",
        constructor: function(e) {
            this.owner = e.owner || e.appWin;
            var t = this.fillConfig(e);
            this.callParent([t])
        },
        initEvents: function() {
            this.callParent(), this.mon(this.searchPanel, "search", this.onSearch, this, {
                buffer: this.searchBuffer
            })
        },
        fillConfig: function(e) {
            this.pageSize = SYNO.SDS.Drive.Log.LOG_PAGE_LIMIT;
            var t = [{
                    id: "log",
                    header: SYNO.SDS.Drive._T("func", "mgr_log"),
                    dataIndex: "log",
                    align: "left",
                    renderer: function(e, t, i, n) {
                        return i.ridx = n, SYNO.SDS.CSTN.RenderLog(i)
                    },
                    width: SYNO.SDS.Drive.Log.LOG_COL_WIDTH
                }, {
                    id: "time",
                    header: SYNO.SDS.Drive._T("common", "time"),
                    dataIndex: "time",
                    align: "left",
                    renderer: function(e, t) {
                        return SYNO.SDS.CSTN.RenderTime(e, t)
                    },
                    width: SYNO.SDS.Drive.Log.STATUS_COL_WIDTH
                }],
                i = new Ext.grid.ColumnModel({
                    columns: t
                }),
                n = this.createStore();
            this.ds_share = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["share_name", "share_type"],
                data: [{
                    share_name: SYNO.SDS.Drive._T("log", "log_title_all"),
                    share_type: "all"
                }]
            }), this.searchPanel = new SYNO.SDS.Drive.Log.SearchPanel({
                itemId: "search"
            }), this.findField = new SYNO.SDS.Drive.Log.AdvancedSearchField({
                searchPanel: this.searchPanel,
                iconStyle: "filter",
                owner: this
            }), this.selected_index = 0, this.combo_share = new SYNO.ux.ComboBox({
                name: "combo_share",
                mode: "local",
                hideLabel: !1,
                editable: !1,
                store: this.ds_share,
                displayField: "share_name",
                valueField: "share_name",
                triggerAction: "all",
                value: "all",
                hidden: !1,
                listeners: {
                    scope: this,
                    select: function(e, t, i) {
                        this.selected_index = i, this.getStore().load()
                    }
                }
            });
            var s = new Ext.Toolbar;
            s.add(this.combo_share), s.add("->"), s.add(this.findField);
            var o = new SYNO.ux.PagingToolbar({
                    store: n,
                    pageSize: this.pageSize,
                    displayInfo: !0,
                    displayMsg: "",
                    moveLast: function() {
                        this.store.setBaseParam("get_all", !0), this.store.load()
                    },
                    listeners: {
                        change: function() {
                            var e = Math.floor(this.store.totalLength / this.pageSize);
                            this.store.totalLength % this.pageSize != 0 && e++;
                            var t = this.getPageData().pages;
                            !0 === this.store.baseParams.get_all && (this.setFocusPage(e), this.cursor = (e - 1) * this.pageSize, this.first.setDisabled(1 === e), this.prev.setDisabled(1 === e), this.next.setDisabled(e === t), this.last.setDisabled(e === t), this.store.setBaseParam("get_all", !1))
                        }
                    }
                }),
                r = {
                    itemId: "log",
                    tbar: s,
                    view: new SYNO.ux.FleXcroll.grid.GridView({
                        listeners: {
                            refresh: {
                                scope: this,
                                fn: function() {}
                            }
                        }
                    }),
                    stripeRows: !0,
                    enableColLock: !1,
                    enableHdMenu: !1,
                    enableColumnMove: !1,
                    colModel: i,
                    ds: n,
                    autoExpandColumn: "log",
                    loadMask: !0,
                    bbar: o,
                    sm: new Ext.grid.RowSelectionModel({
                        singleSelect: !1
                    }),
                    listeners: {
                        rowdblclick: {
                            fn: this.rowDoubleClick,
                            scope: this
                        },
                        afterlayout: {
                            single: !0,
                            fn: this.onActivate,
                            scope: this
                        }
                    }
                };
            return SYNO.LayoutConfig.fill(r), Ext.apply(r, e), r
        },
        canShowVer: function(e) {
            var t = String(e.get("type")),
                i = SYNO.SDS.CSTN.LogType;
            return (t === i.restore_node || t === i.add_event || t === i.remove_event || t === i.modify_event || t === i.version_rotate || t === i.rename_event) && "" !== e.get("p1")
        },
        rowDoubleClick: function(e, t) {
            var i = this.getStore().getAt(t);
            this.canShowVer(i) && this.showDialogVersion(i.get("target"), i.get("s1"), i.get("p1"))
        },
        showDialogVersion: function(e, t, i) {
            this.findAppWindow().getAction().showVersion({
                name: t.substring(t.lastIndexOf("/") + 1),
                file_id: i
            }, this.findWindow())
        },
        createStore: function() {
            var e = ["type", "username", "target", "share_name", "share_type", "time", "accessable", "filestation_link_prefix", "s1", "s2", "s3", "s4", "s5", "p1", "p2", "p3", "p4", "p5", "target_share_name", "target_share_type", "target_accessable", "target_link_prefix"],
                t = new SYNO.API.Store({
                    pruneModifiedRecords: !0,
                    autoDestroy: !0,
                    autoLoad: !1,
                    proxy: new SYNO.API.Proxy({
                        api: SYNO.SDS.CSTN.WebAPI.Log.api,
                        version: 1,
                        method: "list"
                    }),
                    reader: new Ext.data.JsonReader({
                        root: "items",
                        totalProperty: "total",
                        idProperty: "id"
                    }, e),
                    paramNames: {
                        start: "offset",
                        limit: "limit",
                        sort: "sort_by",
                        dir: "sort_direction"
                    },
                    baseParams: {
                        share_type: "all",
                        offset: 0,
                        limit: this.pageSize,
                        view_role: _S("user"),
                        get_all: !1
                    },
                    listeners: {
                        scope: this,
                        beforeload: function() {
                            var e = this.combo_share.getStore().getAt(this.selected_index);
                            this.getStore().setBaseParam("share_type", e.get("share_type")), "share" === e.get("share_type") ? this.getStore().setBaseParam("target", "@" + e.get("share_name")) : this.getStore().setBaseParam("target", "user")
                        }
                    }
                });
            return this.addManagedComponent(t), t
        },
        getShareCombo: function() {
            SYNO.SDS.CSTN.WebAPI.Share.listActive.call(this.owner, {}, function(e, t, i, n) {
                if (e) {
                    for (var s = [{
                            share_name: SYNO.SDS.Drive._T("log", "log_title_all"),
                            share_type: "all"
                        }], o = 0; o < t.total; o++) s = "home" === t.items[o].type ? s.concat([{
                        share_name: SYNO.SDS.Drive._T("category", "node"),
                        share_type: t.items[o].type
                    }]) : s.concat([{
                        share_name: t.items[o].name,
                        share_type: t.items[o].type
                    }]);
                    this.ds_share.loadData(s)
                }
                SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
                    success: SYNO.SDS.CSTN.cbLoad,
                    failure: SYNO.SDS.CSTN.webapiErrHdlMain
                })
            }, this)
        },
        clearSearchParam: function() {
            var e = {
                keyword: "",
                datefrom: 0,
                dateto: 0,
                log_type: []
            };
            Ext.apply(this.getStore().baseParams, e), this.combo_share.setValue(SYNO.SDS.Drive._T("log", "log_title_all")), this.selected_index = 0, this.searchPanel.rendered && this.searchPanel.onReset(), this.findField.setValue("")
        },
        onSearch: function(e, t) {
            Ext.apply(this.getStore().baseParams, t), this.getStore().load()
        },
        onPageActivate: function() {
            this.clearSearchParam(), this.owner.setStatusBusy(), this.getShareCombo()
        },
        onActivate: function() {
            this.onPageActivate()
        }
    }), Ext.define("SYNO.SDS.Drive.Log.AdvancedSearchField", {
        extend: "SYNO.ux.SearchField",
        constructor: function(e) {
            this.searchPanel = e.searchPanel, this.callParent(arguments)
        },
        initEvents: function() {
            this.callParent(arguments), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(this, "keydown", function(e, t) {
                t.getKey() === Ext.EventObject.ENTER && (this.searchPanel.setKeyWord(this.getValue()), this.searchPanel.onSearch())
            }, this)
        },
        checkInnerComponent: function(e, t) {
            var i = !1;
            return t.items.each(function(t) {
                if (t instanceof Ext.form.ComboBox) {
                    if (t.view) {
                        if (e.within(t.view.getEl())) return i = !0, !1;
                        !e.within(t.getEl()) && t.view.isVisible() && t.view.hide()
                    }
                } else if (t instanceof Ext.form.DateField) {
                    if (t.menu) {
                        if (e.within(t.menu.getEl())) return i = !0, !1;
                        !e.within(t.wrap) && t.menu.isVisible() && t.menu.hide()
                    }
                } else if (t instanceof Ext.form.CompositeField && this.checkInnerComponent(e, t)) return i = !0, !1
            }, this), i
        },
        checkHideMenu: function(e) {
            var t = this.getMenu(),
                i = this.searchPanel;
            return !(!i || !t.isVisible() || t.isDestroyed || e.within(t.getEl()) || i.attriWin && i.attriWin.isVisible() || this.checkInnerComponent(e, this.searchPanel.getForm()))
        },
        onMouseDown: function(e) {
            e.within(this.searchtrigger) || (this.checkHideMenu(e) ? this.hideMenu() : window.event || (this.tmp_mouse_event = e))
        },
        onTriggerClick: function() {
            this.callParent(), this.searchPanel.onReset(), this.searchPanel.onSearch()
        },
        getMenu: function() {
            return this.menu || (this.menu = new SYNO.ux.Menu({
                cls: "syno-d-log-search-menu",
                owner: this,
                enableScrolling: !1,
                defaultOffsets: [0, 2],
                items: [this.searchPanel],
                listeners: {
                    scope: this,
                    afterlayout: {
                        single: !0,
                        fn: function(e) {
                            this.mon(e.getEl(), "click", function(e) {
                                this.checkInnerComponent(e, this.searchPanel.getForm())
                            }, this)
                        },
                        scope: this
                    },
                    beforehide: function() {
                        var e = window.event || this.tmp_mouse_event;
                        return this.tmp_mouse_event && delete this.tmp_mouse_event, !e || "click" !== e.type && "mousedown" !== e.type || this.checkHideMenu(new Ext.EventObjectImpl(e))
                    }
                }
            }), this.searchPanel.owner = this.menu, this.owner.addManagedComponent(this.menu)), this.menu
        },
        showMenu: function() {
            return this.rendered && this.getMenu() && (this.getMenu().isVisible() && this.hideMenu(), this.getMenu().ownerCt = this, this.getMenu().show(this.wrap, "tr-br?")), this.searchPanel.setKeyWord(this.getValue()), this
        },
        hideMenu: function() {
            this.getMenu().hide()
        }
    }), Ext.define("SYNO.SDS.Drive.DateField", {
        extend: "SYNO.ux.DateField",
        constructor: function() {
            this.callParent(arguments)
        },
        onTriggerClick: function() {
            if (Ext.isEmpty(this.menu) && (this.menu = new SYNO.ux.DateMenu({
                    hideOnClick: !1,
                    focusOnSelect: !1,
                    allowOtherMenus: !0
                })), this.menu.isVisible()) return void this.menuEvents("hide");
            SYNO.SDS.Drive.DateField.superclass.onTriggerClick.apply(this, arguments)
        }
    }), Ext.ns("SYNO.SDS.Drive.Log"), Ext.define("SYNO.SDS.Drive.Log.SearchPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            this.dateType = {
                custom: 1,
                today: 2,
                yesterday: 4,
                lastweek: 8,
                lastmonth: 16
            }, this.dataRange = [
                [this.dateType.custom, SYNO.SDS.Drive._T("log", "date_custom")],
                [this.dateType.today, SYNO.SDS.Drive._T("log", "date_today")],
                [this.dateType.yesterday, SYNO.SDS.Drive._T("log", "date_yesterday")],
                [this.dateType.lastweek, SYNO.SDS.Drive._T("log", "date_lastweek")],
                [this.dateType.lastmonth, SYNO.SDS.Drive._T("log", "date_lastmonth")]
            ], this.logType = SYNO.SDS.CSTN.LogType, this.logDescAdmin = [
                [this.logType.cloudstn_save, SYNO.SDS.Drive._T("log", "log_type_drive_save")],
                [this.logType.priv_save, SYNO.SDS.Drive._T("log", "log_type_priv_save")],
                [this.logType.share_save, SYNO.SDS.Drive._T("log", "log_type_share_save")],
                [this.logType.client_unlink, SYNO.SDS.Drive._T("log", "log_type_client_unlink")],
                [this.logType.restore_node, SYNO.SDS.Drive._T("log", "log_type_restore_node")],
                [this.logType.delfile_forever, SYNO.SDS.Drive._T("log", "log_type_delfile_forever")],
                [this.logType.rotate_set, SYNO.SDS.Drive._T("log", "log_type_rotate_set")],
                [this.logType.volume_set, SYNO.SDS.Drive._T("log", "log_type_volume_set")],
                [this.logType.log_rotate_cnt_set, SYNO.SDS.Drive._T("log", "log_type_log_rotate_cnt_set")],
                [this.logType.log_rotate_span_set, SYNO.SDS.Drive._T("log", "log_type_log_rotate_span_set")],
                [this.logType.log_delete, SYNO.SDS.Drive._T("log", "log_type_log_delete")],
                [this.logType.client_link, SYNO.SDS.Drive._T("log", "log_type_client_link")],
                [this.logType.add_event, SYNO.SDS.Drive._T("log", "log_type_add_event")],
                [this.logType.remove_event, SYNO.SDS.Drive._T("log", "log_type_remove_event")],
                [this.logType.modify_event, SYNO.SDS.Drive._T("log", "log_type_modify_event")],
                [this.logType.rename_event, SYNO.SDS.Drive._T("log", "log_type_rename_event")],
                [this.logType.version_rotate, SYNO.SDS.Drive._T("log", "log_type_version_rotate")]
            ], this.logDesc = [
                [this.logType.cloudstn_save, SYNO.SDS.Drive._T("log", "log_type_drive_save")],
                [this.logType.client_unlink, SYNO.SDS.Drive._T("log", "log_type_client_unlink")],
                [this.logType.restore_node, SYNO.SDS.Drive._T("log", "log_type_restore_node")],
                [this.logType.delfile_forever, SYNO.SDS.Drive._T("log", "log_type_delfile_forever")],
                [this.logType.client_link, SYNO.SDS.Drive._T("log", "log_type_client_link")],
                [this.logType.add_event, SYNO.SDS.Drive._T("log", "log_type_add_event")],
                [this.logType.remove_event, SYNO.SDS.Drive._T("log", "log_type_remove_event")],
                [this.logType.modify_event, SYNO.SDS.Drive._T("log", "log_type_modify_event")],
                [this.logType.rename_event, SYNO.SDS.Drive._T("log", "log_type_rename_event")],
                [this.logType.version_rotate, SYNO.SDS.Drive._T("log", "log_type_version_rotate")]
            ], this.defaultAnimation = ["#000", 1, {
                duration: .35
            }], Ext.apply(this, e || {});
            var t = this.fillConfig(e);
            this.callParent([t])
        },
        fillConfig: function() {
            var e, t, i, n, s = [];
            e = this.createKeyword(), t = this.createFriendlyDate(), i = this.createCustDate(), n = this.createType(), s.push(e), s.push(t), s.push(i), s.push(n);
            var o = {
                    xtype: "toolbar",
                    border: !1,
                    itemId: "btns",
                    items: [{
                        xtype: "tbfill"
                    }]
                },
                r = [{
                    xtype: "syno_button",
                    btnStyle: "grey",
                    minWidth: 80,
                    text: _T("common", "reset"),
                    handler: this.onReset,
                    scope: this
                }, {
                    xtype: "syno_button",
                    text: _T("log", "search"),
                    itemId: "btn_search",
                    handler: this.onSearch,
                    scope: this
                }];
            return SYNO.SDS.CSTN.IsDSM7OrAbove() || r.reverse(), o.items.push.apply(o.items, r), s.push(o), {
                width: 368,
                heigh: 480,
                labelAlign: "top",
                trackResetOnLoad: !0,
                border: !1,
                cls: "syno-d-log-search-panel",
                autoFlexcroll: !1,
                defaults: {
                    anchor: "100%"
                },
                items: s,
                keys: [{
                    key: [Ext.EventObject.ENTER],
                    scope: this,
                    fn: function() {
                        this.owner.isVisible() && this.onSearch()
                    }
                }]
            }
        },
        setComboBoxValue: function(e, t) {
            this.frameAnimation(e.el, this.defaultAnimation), e.setMultiValue && e.setMultiValue(t)
        },
        getComboBoxValue: function(e) {
            var t = this.getForm().findField(e);
            return t.getMultiValue ? t.getMultiValue() : [t.getValue()]
        },
        multiSelect: function(e, t, i, n, s) {
            if ("more" === t.get("value")) return this.attriWin = new SYNO.SDS.Drive.Log.MultiSelectedDialog({
                title: n,
                combo: e,
                emptyValue: s,
                anim: this.defaultAnimation,
                owner: this.owner.findWindow()
            }), this.attriWin.showUp(), e.collapse(), !1
        },
        logSelect: function(e) {
            this.setComboBoxValue(e, e.getValue())
        },
        createKeyword: function() {
            return [{
                fieldLabel: SYNO.SDS.Drive._T("log", "attr_keyword"),
                xtype: "syno_textfield",
                name: "keyword",
                vaule: ""
            }]
        },
        setDate: function(e, t, i) {
            !0 === i && (this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation), this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)), this.form.findField("searchdatefrom").setMaxValue(t), this.form.findField("searchdateto").setMinValue(e), this.form.findField("searchdatefrom").setValue(e), this.form.findField("searchdateto").setValue(t)
        },
        getFromToDate: function(e) {
            var t, i, n = new Date;
            if (e === this.dateType.today) t = n, i = n;
            else if (e === this.dateType.yesterday) t = n.add(Date.DAY, -1), i = t;
            else if (e === this.dateType.lastweek) {
                var s = n.getDay();
                t = n.add(Date.DAY, -7 - s), i = t.add(Date.DAY, 6)
            } else e === this.dateType.lastmonth && (n = n.add(Date.MONTH, -1), t = n.getFirstDateOfMonth(), i = n.getLastDateOfMonth());
            return {
                from: t,
                to: i
            }
        },
        friendlyDateSelect: function(e, t) {
            var i = t.get("id"),
                n = this.getFromToDate(i);
            this.setDate(n.from, n.to, !0)
        },
        getFriendlyDateStore: function() {
            var e = this.dataRange;
            return new Ext.data.ArrayStore({
                autoDestroy: !0,
                fields: ["id", "displayText"],
                data: e
            })
        },
        createFriendlyDate: function() {
            return this.FriendlyDate = new SYNO.ux.ComboBox({
                fieldLabel: SYNO.SDS.Drive._T("log", "date_range"),
                mode: "local",
                editable: !1,
                name: "dateRange",
                store: this.getFriendlyDateStore(),
                displayField: "displayText",
                valueField: "id",
                triggerAction: "all",
                value: this.dateType.custom,
                listeners: {
                    scope: this,
                    beforeselect: this.friendlyDateSelect
                }
            }), [this.FriendlyDate]
        },
        createCustDate: function() {
            return this.DateFrom = new SYNO.SDS.Drive.DateField({
                name: "searchdatefrom",
                editable: !1,
                format: SYNO.SDS.Drive.Utils.getDateFormat(),
                emptyText: _T("log", "date_from"),
                value: "",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.form.findField("searchdateto").setMinValue(t)
                    }
                }
            }), this.DateTo = new SYNO.SDS.Drive.DateField({
                name: "searchdateto",
                editable: !1,
                format: SYNO.SDS.Drive.Utils.getDateFormat(),
                emptyText: _T("log", "date_to"),
                value: "",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.form.findField("searchdatefrom").setMaxValue(t)
                    }
                }
            }), [{
                xtype: "syno_compositefield",
                fieldLabel: SYNO.SDS.Drive._T("time", "time_date"),
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [this.DateFrom, this.DateTo]
            }]
        },
        getLogTypeStore: function() {
            var e;
            return e = _S("is_admin") ? this.logDescAdmin.slice(0, this.logDescAdmin.length) : this.logDesc.slice(0, this.logDesc.length), e.length > 1 && e.splice(0, 0, ["all", SYNO.SDS.Drive._T("log", "log_title_all")], ["more", SYNO.SDS.Drive._T("log", "more_item") + "..."]), new Ext.data.ArrayStore({
                autoDestroy: !0,
                multiValue: [],
                fields: ["value", "displayText"],
                data: e
            })
        },
        multiLogTypeSelect: function(e, t, i) {
            this.multiSelect(e, t, i, SYNO.SDS.Drive._T("log", "log_type"), "all")
        },
        createType: function() {
            return this.logTypeCombo = new SYNO.ux.ComboBox({
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.Drive._T("log", "log_type"),
                mode: "local",
                editable: !1,
                name: "logType",
                store: this.getLogTypeStore(),
                displayField: "displayText",
                valueField: "value",
                triggerAction: "all",
                value: "all",
                listeners: {
                    scope: this,
                    beforeselect: this.multiLogTypeSelect,
                    select: this.logSelect,
                    expand: {
                        fn: function() {
                            this.inEl = !0
                        },
                        scope: this
                    },
                    collapse: {
                        fn: function() {
                            this.inEl = !1
                        },
                        scope: this
                    }
                },
                getMultiValue: function() {
                    return this.multiValue
                },
                setMultiValue: function(e) {
                    Ext.isArray(e) ? this.multiValue = e : "all" === e ? this.multiValue = [] : "more" !== e && (this.multiValue = [e])
                }
            }), [this.logTypeCombo]
        },
        frameAnimation: function(e, t) {
            e && e.isVisible() && Ext.Element.prototype.frame.apply(e, t)
        },
        setKeyWord: function(e) {
            var t = this.form.findField("keyword");
            t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
        },
        onSearch: function() {
            var e, t, i, n, s, o;
            e = this.getForm(), t = e.findField("keyword").getValue(), i = e.findField("searchdatefrom"), n = e.findField("searchdateto"), s = this.getComboBoxValue("logType"), o = {
                keyword: t,
                datefrom: i.getRawValue() ? Date.parseDate(i.getRawValue() + " 00:00:00", i.format + " H:i:s").getTime() / 1e3 : 0,
                dateto: n.getRawValue() ? Date.parseDate(n.getRawValue() + " 23:59:59", n.format + " H:i:s").getTime() / 1e3 : 0,
                log_type: s
            }, this.fireEvent("search", this, o), this.owner.hide()
        },
        onReset: function() {
            this.form.items.each(function(e) {
                e.isDirty() && this.frameAnimation(e.el, this.defaultAnimation)
            }, this), this.form.reset(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null), this.form.findField("logType").setMultiValue("all")
        }
    }), Ext.define("SYNO.SDS.Drive.Log.MultiSelectedDialog", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(e) {
            Ext.apply(this, e), this.orginalValue = this.combo.getMultiValue ? this.combo.getMultiValue() : this.combo.getValue(), this.orginalDisplayValue = this.combo.getRawValue(), this.attriFormPanel = this.createAttriFormPanel();
            var t = {
                width: 450,
                height: 500,
                resizable: !1,
                title: e.title,
                layout: "fit",
                closable: !0,
                owner: e.owner,
                items: [this.attriFormPanel],
                buttons: [{
                    text: _T("common", "cancel"),
                    itemId: "cancel",
                    handler: this.onCancel,
                    scope: this
                }, {
                    text: _T("common", "apply"),
                    btnStyle: "default",
                    itemId: "apply",
                    handler: this.onOk,
                    scope: this
                }],
                listeners: {
                    scope: this,
                    show: function(e) {
                        var t = this.combo.ownerCt.owner,
                            i = parseInt(e.getEl().getStyle("z-index"), 10);
                        t.el.setZIndex(i - 3);
                        var n = t.el.mask();
                        n.setOpacity(0), n.setStyle("z-index", i - 1)
                    },
                    beforehide: function() {
                        this.combo.ownerCt.owner.el.unmask()
                    }
                }
            };
            SYNO.SDS.CSTN.IsDSM7OrAbove() || t.buttons.reverse(), SYNO.SDS.Drive.Log.MultiSelectedDialog.superclass.constructor.call(this, t), this.initEvent()
        },
        initEvent: function() {
            this.mon(this, "close", this.onClose, this)
        },
        createAttriFormPanel: function() {
            var e, t, i = this.combo.getStore(),
                n = [],
                s = this.combo.displayField,
                o = this.combo.valueField;
            n.push({
                xtype: "syno_displayfield",
                indent: 0,
                value: _T("log", "title_select_desc")
            }), i.each(function(r) {
                if (e = r.get(o), t = r.get(s), 0 === i.indexOf(r) || "more" === e) return !0;
                var a = {
                    xtype: "syno_checkbox",
                    indent: 1,
                    name: "" + r.get(o),
                    boxLabel: r.get(s)
                };
                n.push(a)
            }, this);
            var r = {
                labelWidth: 190,
                labelAlign: "left",
                border: !1,
                autoScroll: !0,
                trackResetOnLoad: !0,
                items: n
            };
            return new SYNO.ux.FormPanel(r)
        },
        setCheckBox: function() {
            var e = this.attriFormPanel.getForm(),
                t = this.combo,
                i = t.getStore(),
                n = t.getMultiValue() || [],
                s = t.valueField;
            n = n.length > 0 ? n : [t.getValue()], i.each(function(t) {
                var i = t.get(s); - 1 !== n.indexOf(i) && e.findField("" + i) && e.findField("" + i).setValue(!0)
            }, this)
        },
        showUp: function() {
            this.setCheckBox(), this.open()
        },
        onOk: function() {
            var e = this.attriFormPanel.getForm(),
                t = this.combo,
                i = t.getStore(),
                n = [],
                s = [],
                o = t.displayField,
                r = t.valueField;
            i.each(function(t) {
                var i = t.get(r),
                    a = t.get(o),
                    l = e.findField("" + i);
                l && l.getValue() && (n.push(a), s.push(i))
            }, this), n.length === i.getCount() - 2 ? t.setValue(this.emptyValue) : 0 < n.length ? t.setRawValue(n.toString()) : t.setValue(this.emptyValue), t.setMultiValue(s), this.isOK = !0, Ext.Element.prototype.frame.apply(t.el, this.anim), this.close()
        },
        onCancel: function() {
            this.close()
        },
        onClose: function() {
            var e = this.combo;
            this.isOK || (e.setMultiValue(this.orginalValue), e.setRawValue(this.orginalDisplayValue))
        }
    }), Ext.ns("SYNO.SDS.Drive.Log"), Ext.define("SYNO.SDS.Drive.Log.Dialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = this.fillConfig(e);
            this.callParent([t])
        },
        fillConfig: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("func", "mgr_log"),
                width: 800,
                height: 600,
                layout: "fit",
                items: this.getPanel(e),
                buttons: [{
                    xtype: "syno_button",
                    text: _T("common", "close"),
                    scope: this,
                    handler: this.close
                }]
            };
            return Ext.apply(t, e)
        },
        getPanel: function(e) {
            return this.panel || (this.panel = new SYNO.SDS.Drive.Log.Panel(e))
        }
    }), Ext.define("SYNO.SDS.Drive.MenuCheckItem", {
        extend: "Ext.menu.CheckItem",
        xtype: "syno_drive_menucheckitem",
        selectPartialCls: "select-partial",
        constructor: function(e) {
            this.itemTpl = this.getTpl(), this.callParent([e]), this.mon(this, "checkchange", function(e, t) {
                e.removeClass(e.selectPartialCls), e.parentMenu && (Ext.fly(e.getId()).removeClass(e.parentMenu.selectPartialCls || e.selectPartialCls), e.parentMenu.fireEvent("checkchange", e, t))
            })
        },
        getTpl: function() {
            return new Ext.XTemplate('<a class="x-menu-list-item" hidefocus="true" unselectable="on" href="{href}"', '<tpl if="hrefTarget">', ' target="{hrefTarget}"', "</tpl>", ">", '<div id="{id}" class="{cls} x-unselectable">', '<img alt="{altText}" src="{icon}" class="x-menu-item-icon {iconCls}"/>', '<span class="x-menu-item-text">{text}</span>', '<tpl if="color">', '<div class="syno-d-color" style="background-color:#{color}; color:#FFF;"></div>', "</tpl>", "</div>", "</a>")
        },
        getTemplateArgs: function() {
            return {
                id: this.id,
                cls: this.itemCls + (this.menu ? " x-menu-item-arrow" : "") + (this.cls ? " " + this.cls : ""),
                href: this.href || "#",
                hrefTarget: this.hrefTarget,
                icon: this.icon || Ext.BLANK_IMAGE_URL,
                iconCls: this.iconCls || "",
                text: this.itemText || this.text || "&#160;",
                altText: this.altText || "",
                color: this.color || ""
            }
        }
    }), Ext.define("SYNO.SDS.Drive.ColorPalette", {
        extend: "Ext.Container",
        xtype: "syno_drive_colorpalette",
        rowLength: 12,
        selected: [],
        defaultColor: null,
        colors: [],
        constructor: function(e) {
            this.colors = SYNO.SDS.Drive.Define.TagColor;
            var t, i = [];
            for (t = 0; t < this.colors.length; t++) i.push({
                xtype: "container",
                cls: "color-item",
                color: this.colors[t],
                items: [{
                    xtype: "container",
                    cls: t < this.rowLength ? "light" : "dark",
                    style: "background-color: #" + this.colors[t] + ";"
                }]
            });
            var n = {
                defaults: {
                    select: function() {
                        return this.addClass("color-selected"), this
                    },
                    deselect: function() {
                        return this.removeClass("color-selected"), this
                    },
                    listeners: {
                        scope: this,
                        single: !0,
                        afterrender: function(e) {
                            this.mon(e.el, "click", function(t, i, n) {
                                this.select(e)
                            }, this)
                        }
                    }
                },
                items: i
            };
            this.callParent([Ext.apply(n, e)]), this.addEvents("select"), this.addClass("syno-d-colorpalette"), null !== this.defaultColor && this.select(this.items.get(this.defaultColor))
        },
        select: function(e) {
            var t;
            for (t = 0; t < this.selected.length; ++t) this.selected[t].deselect();
            this.selected = [e.select()], this.fireEvent("select", e.color)
        },
        getSelectedNode: function() {
            if (this.selected.length) return {
                color: this.selected[0].color
            }
        }
    }), Ext.define("SYNO.SDS.Drive.ColorMenu", {
        extend: "SYNO.ux.Menu",
        constructor: function(e) {
            this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            var t = {
                cls: "syno-d-color-menu",
                items: [{
                    xtype: "menutextitem",
                    text: SYNO.SDS.Drive._T("tag", "select_color")
                }, this.colorPalette = new SYNO.SDS.Drive.ColorPalette({
                    itemId: "ctn",
                    listeners: {
                        scope: this,
                        select: function(e) {
                            this.color !== e && (this.rec.set("color", e), this.fireEvent("colorchange", this.rec.id, e, this.rec)), this.hide()
                        }
                    }
                })]
            };
            return Ext.apply(t, e)
        },
        show: function(e, t, i, n) {
            if (n) {
                this.el || this.render(), this.showAt(this.el.getAlignToXY(e, t || this.defaultAlign, this.defaultOffsets), i);
                var s = n.get("color");
                this.rec = n, this.getComponent("ctn").items.each(function(e) {
                    e.color === s ? (this.color = s, e.select()) : e.deselect()
                }, this);
                this.el.getBottom() >= Ext.getBody().getBottom() && this.el.setTop(this.el.getTop() - 25)
            }
        }
    }), Ext.define("SYNO.SDS.Drive.AddTag", {
        extend: "SYNO.SDS.Drive.AddEditWindow",
        mode: "add",
        maxNameLength: SYNO.SDS.Drive.Define.TAG_MAX_LENGTH,
        constructor: function(e) {
            this.initName = e.initName, this.callParent([Ext.apply({
                width: 547,
                height: 254
            }, e)])
        },
        getFormPanel: function() {
            return this.formPanel = this.formPanel || new SYNO.ux.FormPanel({
                cls: "syno-d-add-edit-form",
                border: !1,
                autoHeight: !0,
                items: [{
                    itemCls: "tag-title",
                    xtype: "syno_textfield",
                    fieldLabel: _T("common", "name"),
                    itemId: this.nameItemId,
                    name: this.nameItemId,
                    width: 330,
                    validator: this.nameValidator.createDelegate(this),
                    value: this.initName ? this.initName : void 0
                }, {
                    itemCls: "tag-color",
                    xtype: "syno_drive_colorpalette",
                    fieldLabel: SYNO.SDS.Drive._T("tag", "color"),
                    itemId: "color",
                    defaultColor: 0,
                    width: 336
                }]
            }), this.formPanel
        },
        isDirty: function() {
            return !0
        },
        getParams: function() {
            var e, t = this.getForm(),
                i = {},
                n = t.getFieldValues();
            n.title && (e = n.title.trim()) && (i.name = e);
            var s = this.formPanel.getComponent("color").getSelectedNode();
            return i.color = "#" + s.color, i.name ? i : (t.markInvalid({
                title: _JSLIBSTR("extlang", "fieldblank")
            }), !1)
        },
        nameValidator: function(e) {
            var t = e.trim();
            return 0 === t.length ? this.getForm().findField(this.nameItemId).blankText : !(t.length > 0 && t.length > this.maxNameLength) || SYNO.SDS.Drive._T("error", "label_name_too_long")
        },
        onAction: function(e) {
            this.findAppWindow().getAction().createTag(e, this.onApplyCb, this)
        },
        onApplyDone: function(e, t, i) {
            this.fireEvent("apply", "add", e.label_id, t.name, t.color, t.type)
        }
    }), Ext.define("SYNO.SDS.Drive.EditTag", {
        extend: "SYNO.SDS.Drive.AddEditWindow",
        mode: "edit",
        maxNameLength: SYNO.SDS.Drive.Define.TAG_MAX_LENGTH,
        constructor: function(e) {
            this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            var t = e.targetRec;
            if (!t) throw "no target";
            this.rec = t, delete e.targetRec;
            var i = {
                width: 547,
                height: 254
            };
            return Ext.apply(i, e)
        },
        getFormPanel: function() {
            return this.formPanel = this.formPanel || new SYNO.ux.FormPanel({
                cls: "syno-d-add-edit-form",
                autoHeight: !0,
                border: !1,
                items: [{
                    itemCls: "tag-title",
                    xtype: "syno_textfield",
                    fieldLabel: _T("common", "name"),
                    itemId: this.nameItemId,
                    name: this.nameItemId,
                    value: this.rec.get("name"),
                    width: 330,
                    validator: this.nameValidator.createDelegate(this)
                }, {
                    itemCls: "tag-color",
                    xtype: "syno_drive_colorpalette",
                    fieldLabel: SYNO.SDS.Drive._T("tag", "color"),
                    itemId: "color",
                    defaultColor: this.getColorIndex(this.rec.get("color")),
                    width: 336
                }]
            }), this.formPanel
        },
        isDirty: function() {
            var e = this.formPanel.getComponent("color").getSelectedNode();
            return this.getForm().isDirty() || this.rec.get("color") !== e.color
        },
        getParams: function() {
            var e = this.getForm(),
                t = {},
                i = e.getFieldValues(),
                n = i.title.trim(),
                s = this.formPanel.getComponent("color").getSelectedNode();
            return !!this.rec.get("label_id") && (n === this.rec.get("title") && this.rec.get("color") === s.color ? void this.onCancel() : (t.label_id = this.rec.get("label_id"), i.title && n !== this.rec.get("title") && (t.name = n), s.color !== this.rec.get("color") && (t.color = "#" + s.color), t))
        },
        nameValidator: function(e) {
            var t = e.trim();
            return 0 === t.length ? this.getForm().findField(this.nameItemId).blankText : !(t.length > 0 && t.length > this.maxNameLength) || SYNO.SDS.Drive._T("error", "label_name_too_long")
        },
        onAction: function(e) {
            this.findAppWindow().getAction().setTag(e, this.onApplyCb, this)
        },
        onApplyDone: function(e, t, i) {
            this.fireEvent("apply", "edit", t.label_id, t.title, t.color)
        },
        getColorIndex: function(e) {
            var t = SYNO.SDS.Drive.Define.TagColor.indexOf(e);
            return -1 !== t && t
        }
    }), Ext.define("SYNO.SDS.Drive.TagButton", {
        extend: "SYNO.ux.Button",
        selectedTags: [],
        originalValue: [],
        constructor: function(e) {
            var t = {};
            e.hasOwnProperty("menuCfg") && (t = e.menuCfg, delete e.menuCfg), e.hasOwnProperty("text") ? this.defaultText = e.text : this.defaultText = SYNO.SDS.Drive._T("search", "all_tags");
            var i = {
                cls: "syno-d-combo-btn",
                text: this.defaultText,
                btnStyle: "grey",
                menu: new SYNO.SDS.Drive.SearchTagMenu(Ext.apply({
                    ownerBtn: this
                }, t))
            };
            Ext.apply(i, e), this.callParent([i]), this.addEvents("change"), this.mon(this.menu, "apply", this.selectTags, this)
        },
        selectTags: function(e, t, i) {
            this.setValue(i), this.fireEvent("change", this.selectedTags)
        },
        setValue: function(e) {
            this.selectedTags = e || [], this.setTagText(this.selectedTags), this.menu.setItem([{
                data: {
                    labels: this.selectedTags
                }
            }])
        },
        setTagText: function(e) {
            var t = [];
            e.forEach(function(e, i, n) {
                t.push(e.name)
            }, this), this.setText(t.length > 0 ? t.join(", ") : this.defaultText)
        },
        getTagIds: function() {
            var e = [];
            return this.selectedTags.forEach(function(t, i, n) {
                e.push(t.file_id)
            }, this), e
        },
        isTagSelected: function(e) {
            var t;
            for (t = 0; t < this.selectedTags.length; ++t)
                if (e === this.selectedTags[t].id) return !0;
            return !1
        },
        reset: function() {
            this.setText(this.defaultText), this.selectedTags = [], this.menu.setItem([{
                data: {
                    labels: this.selectedTags
                }
            }]), this.fireEvent("change", this.selectedTags)
        },
        getValue: function() {
            return this.getTagIds()
        },
        getRawValue: function() {
            return this.selectedTags
        },
        setOriginalValue: function(e) {
            var t, i = [];
            for (t = 0; t < e.length; ++t) i.push(e[t].id);
            this.originalValue = i
        },
        isDirty: function() {
            if (this.originalValue.length !== this.selectedTags.length) return !0;
            var e;
            for (e = 0; e < this.selectedTags.length; ++e)
                if (-1 === this.originalValue.indexOf(this.selectedTags[e].id)) return !0;
            return !1
        }
    }), Ext.define("SYNO.SDS.Drive.SearchListMenu", {
        extend: "SYNO.ux.Menu",
        contentMaxHeight: 224,
        constructor: function(e) {
            e.selector && (this.selector = e.selector, delete e.selector);
            var t = 284;
            e.width && (t = e.width - 16);
            var i = {
                width: 300,
                autoFlexcroll: !1,
                maxHeight: void 0,
                items: []
            };
            Ext.apply(i, e), i.items.unshift(this.selector), e.disableSearch || (this.searchfield = new SYNO.TextFilter({
                width: t,
                itemId: "searchfield",
                listeners: {
                    scope: this,
                    keyup: {
                        fn: this.onKeyUp,
                        buffer: 300
                    },
                    afterrender: {
                        scope: this,
                        single: !0,
                        fn: function(e) {
                            e.mon(e.trigger, "click", function() {
                                this.onKeyUp(e)
                            }, this), e.wrap.addClass("syno-d-searchlist-searchfield")
                        }
                    }
                }
            }), i.items.unshift(this.searchfield)), this.callParent([i]), this.addClass("syno-d-search-menu syno-d-checkbox-menu"), this.mon(this, "show", this.loadList, this), this.mon(this, {
                scope: this,
                show: function() {
                    this.setFocus(50)
                },
                hide: function(e, t) {
                    e.reset()
                }
            })
        },
        setFocus: function(e) {
            this.searchfield && this.searchfield.focus(!1, e || 0)
        },
        focus: function(e, t) {
            return t ? (this.focusTask = new Ext.util.DelayedTask(this.focus, this, [e, !1]), this.focusTask.delay(Ext.isNumber(t) ? t : 10), this) : (this.rendered && !this.isDestroyed && this.setFocus(), this)
        },
        reset: function() {
            this.searchText = "", this.searchfield && this.searchfield.reset(), this.match([], !1)
        },
        onKeyUp: function(e, t) {
            var i = e.getValue().trim();
            if (this.searchText = i, !this.searchText) return void this.match([], !1);
            var n = -1 < this.filter_store.findExact("name", i);
            this.filter_store.filter("name", i, !0);
            var s = this.filter_store.getRange();
            this.filter_store.clearFilter(), this.match(s, n)
        },
        match: Ext.emptyFn
    }), Ext.define("SYNO.SDS.Drive.SearchCheckItemMenu", {
        extend: "SYNO.SDS.Drive.SearchListMenu",
        selectPartialCls: "select-partial",
        constructor: function(e) {
            if (!Ext.isString(this.createDialogName)) throw "should define a create dialog class";
            this.hideCreate = !0 === e.hideCreate;
            var t = {
                selector: new SYNO.ux.Menu({
                    cls: "syno-d-menu syno-d-scrollbar-fix",
                    floating: !1,
                    maxHeight: 250,
                    autoFlexcroll: !0,
                    listeners: {
                        scope: this,
                        checkchange: this.onCheckChange
                    }
                }),
                cls: "syno-d-tag-searchlist",
                items: [{
                    itemId: "no-label",
                    text: SYNO.SDS.Drive._T("common", "no_label"),
                    cls: "syno-d-tag-btn-ct",
                    hidden: !0,
                    disabled: !0
                }, {
                    itemId: "sep",
                    xtype: "menuseparator",
                    hidden: this.hideCreate
                }, {
                    itemId: "create",
                    text: SYNO.SDS.Drive._T("common", "create"),
                    cls: "syno-d-tag-btn-ct",
                    hidden: this.hideCreate,
                    scope: this,
                    handler: function() {
                        new SYNO.SDS.Drive[this.createDialogName]({
                            initName: this.searchText,
                            owner: this.findAppWindow(),
                            listeners: {
                                scope: this,
                                apply: this.onCreate
                            }
                        }).open()
                    }
                }, {
                    itemId: "apply",
                    text: SYNO.SDS.Drive._T("common", "commit"),
                    scope: this,
                    cls: "syno-d-tag-btn-ct",
                    hidden: !0,
                    handler: this.onApply
                }]
            };
            this.callParent([Ext.apply(t, e)]), this.filter_store || (this.filter_store = new Ext.data.JsonStore({
                idProperty: "label_id",
                autoDestroy: !0,
                fields: ["label_id", "name", "color"]
            })), this.addEvents("apply"), this.itemTags = {}, this.itemRecords = [], this.mon(this, "show", function() {
                this.firstChecked = !1
            }, this)
        },
        adjustContentHeight: function() {
            var e, t = this.selector.el.query(".contentwrapper"),
                i = this.contentMaxHeight;
            e = t.length ? Ext.fly(t[0]).getHeight() : this.selector.getHeight(), i = e > i ? i : e, this.selector.setHeight(i || 1), this.doLayout(!0), this.selector.ul.setHeight(i ? i + 1 : 2), this.selector.updateScroller()
        },
        getCheckedResult: function() {
            var e = {};
            this.selector.items.each(function(t, i, n) {
                t.checked && (e[t.data.label_id] = t)
            }, this);
            var t = {
                add: [],
                remove: [],
                checkedList: []
            };
            return Ext.iterate(this.itemTags, function(i, n, s) {
                e.hasOwnProperty(i) || t.remove.push({
                    label_id: i
                })
            }, this), Ext.iterate(e, function(e, i, n) {
                t.checkedList.push(i.data), this.itemTags.hasOwnProperty(e) && (i.el.hasClass(this.selectPartialCls) || this.itemTags[e] === this.itemRecords.length) || t.add.push(i.data)
            }, this), this.checkResult = t, t
        },
        match: function(e, t) {
            var i, n = [],
                s = !this.searchText;
            for (i = 0; i < e.length; ++i) n.push(e[i].id);
            this.selector.items.each(function(e, t, i) {
                s || -1 < n.indexOf(e.data.label_id) ? e.show() : e.hide()
            }, this), this.completeMatch = t;
            var o = !this.hideCreate && !t;
            this.getComponent("create").setVisible(o).setText(this.searchText ? String.format(SYNO.SDS.Drive._T("common", "create_sth"), this.searchText) : SYNO.SDS.Drive._T("common", "create")), this.getComponent("sep").setVisible(o || this.getComponent("apply").isVisible()), this.adjustContentHeight()
        },
        onCheckChange: function(e, t) {
            this.firstChecked = !0;
            var i = this.getCheckedResult(),
                n = i.add.length || i.remove.length;
            this.getComponent("apply").setVisible(n);
            var s = !this.hideCreate && !this.completeMatch;
            this.getComponent("create").setVisible(s && !n), this.getComponent("sep").setVisible(s || n), this.adjustContentHeight()
        },
        reset: function() {
            this.getComponent("apply").setVisible(!1), SYNO.SDS.Drive.SearchCheckItemMenu.superclass.reset.apply(this, arguments)
        },
        onApply: function() {
            (this.checkResult.add.length || this.checkResult.remove.length) && this.fireEvent("apply", this.checkResult.add, this.checkResult.remove, this.checkResult.checkedList), this.hide(!0)
        },
        onCreate: Ext.emptyFn
    }), Ext.define("SYNO.SDS.Drive.SearchTagMenu", {
        extend: "SYNO.SDS.Drive.SearchCheckItemMenu",
        constructor: function(e) {
            this.createDialogName = "AddTag", e.store && (this.store = e.store, delete e.store), this.callParent([e]), this.store && this.mon(this.store, "load", function() {
                this.isVisible() && this.loadList()
            }, this)
        },
        onCreate: function(e, t, i, n) {
            this.getCheckedResult();
            var s = {
                label_id: t,
                name: i,
                color: n,
                type: "personal_label"
            };
            this.checkResult.add.push(s), this.checkResult.checkedList.push(s), this.onApply()
        },
        setItem: function(e) {
            var t = {};
            Ext.each(e, function(e, i, n) {
                Ext.each(e.labels || e.data.labels, function(e, i, n) {
                    t.hasOwnProperty(e.label_id) || (t[e.label_id] = 0), t[e.label_id]++
                })
            }, this), this.itemRecords = e, this.itemTags = t
        },
        loadList: function() {
            this.filter_store.clearData(), this.checkResult = {
                add: [],
                remove: [],
                checkedList: []
            }, this.getComponent("apply").setVisible(!1), this.getComponent("sep").setVisible(!this.hideCreate), this.selector.ul.dom && this.selector.ul.dom.fleXcroll && this.selector.ul.dom.fleXcroll.setScrollPos(!1, 0), this.GetSeletions && this.setItem(this.GetSeletions());
            var e, t = [],
                i = {},
                n = [],
                s = [];
            this.store.each(function(o) {
                e = o.data, "label" === e.category && (i = {
                    xtype: "syno_drive_menucheckitem",
                    hideOnClick: !1,
                    data: e,
                    color: e.color,
                    text: Ext.util.Format.htmlEncode(e.name),
                    listeners: {
                        scope: this,
                        click: function(e, t) {
                            Ext.fly(t.getTarget()).hasClass("x-menu-item-text") && !this.firstChecked && (!0 === e.checked ? e.checked = !1 : e.checked = !0, this.onCheckChange(), this.onApply())
                        }
                    }
                }, this.itemTags.hasOwnProperty(e.label_id) && (i.checked = !0, i.cls = this.itemTags[e.label_id] !== this.itemRecords.length ? this.selectPartialCls : ""), i.checked ? n.push(i) : t.push(i), s.push(o.data))
            }, this), this.selector.suspendEvents(), this.selector.removeAll(), this.selector.add(n.concat(t)), this.getComponent("no-label").setVisible(0 === this.selector.items.length), this.searchfield && this.searchfield.setVisible(0 !== this.selector.items.length), this.selector.resumeEvents(), this.selector.doLayout(), this.filter_store.loadData(s), this.adjustContentHeight()
        }
    }), Ext.define("SYNO.SDS.Drive.RenameWindow", {
        extend: "SYNO.SDS.Drive.AddEditWindow",
        mode: "edit",
        maxNameLength: SYNO.SDS.Drive.Define.TITLE_MAX_LENGTH,
        constructor: function(e) {
            this.initName = e.initName, this.blDir = e.blDir, this.callParent([Ext.apply({
                title: e.title || SYNO.SDS.Drive._T("action", "rename"),
                width: 456,
                height: 190
            }, e)])
        },
        getFormPanel: function() {
            return this.formPanel = this.formPanel || new SYNO.ux.FormPanel({
                cls: "syno-d-add-edit-form",
                autoHeight: !0,
                border: !1,
                fieldWidth: 400,
                labelAlign: "top",
                items: [{
                    xtype: "syno_textfield",
                    fieldLabel: SYNO.SDS.Drive._T("file", "new_name"),
                    itemId: this.nameItemId,
                    name: this.nameItemId,
                    value: this.initName,
                    validator: this.nameValidator.createDelegate(this)
                }]
            }), this.formPanel
        },
        onDelayShow: function() {
            var e = this.getForm().findField(this.nameItemId);
            if (e) {
                var t = e.getValue().lastIndexOf(".");
                e.focus(), e.selectText(0, this.ext || -1 === t || this.blDir ? e.getValue().length : t)
            }
        },
        onAction: function(e) {
            e[this.nameItemId] = e[this.nameItemId].trim(), this.fireEvent("apply", this, this.getForm(), e)
        }
    }), Ext.define("SYNO.SDS.Drive.NodeEditWindow", {
        extend: "SYNO.SDS.Drive.RenameWindow",
        onErrorCb: function(e) {
            var t = SYNO.SDS.Drive.Utils.getErrorCode(e);
            1022 !== t && 1032 !== t && 1034 !== t && 1035 !== t && this.close()
        },
        nameValidator: function(e) {
            var t = e.trim();
            return 0 === t.length ? this.getForm().findField(this.nameItemId).blankText : t.length > 0 && unescape(encodeURIComponent(t)).length >= this.maxNameLength - (this.ext ? this.ext.length + 1 : 0) ? SYNO.SDS.Drive._T("error", "name_too_long") : !!SYNO.SDS.Drive.Utils.checkFileName(t) || SYNO.SDS.Drive._T("error", "reserved_name")
        }
    }), Ext.define("SYNO.SDS.Drive.RenameNodeWindow", {
        extend: "SYNO.SDS.Drive.NodeEditWindow",
        constructor: function(e) {
            var t = SYNO.SDS.Drive.Utils.parseDisplayName(e.initName);
            t !== e.initName && (this.ext = SYNO.SDS.Drive.Utils.getExt(e.initName), e.initName = t), this.callParent([e])
        },
        onAction: function(e) {
            var t = e[this.nameItemId].trim();
            this.ext && (t += "." + this.ext), e[this.nameItemId] = t, this.callParent([e])
        }
    }), Ext.define("SYNO.SDS.Drive.DownloadClient.Window", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = {
                width: 680,
                height: 509,
                cls: "syno-d-prompt-window syno-d-download-client-window",
                layout: "fit",
                header: !1,
                elements: "body",
                useStatusBar: !1,
                resizable: !1,
                closable: !1,
                draggable: !1,
                padding: void 0,
                items: this.getContent()
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getContent: function() {
            var e = SYNO.SDS.Drive._T;
            return {
                xtype: "container",
                layout: "vbox",
                layoutConfig: {
                    align: "center"
                },
                items: [{
                    xtype: "spacer",
                    height: 20
                }, {
                    xtype: "container",
                    cls: "syno-d-download-client-image"
                }, {
                    xtype: "spacer",
                    height: 20
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-prompt-window-title",
                    value: e("common", "prompt_tip")
                }, {
                    xtype: "spacer",
                    height: 12
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-prompt-window-desc",
                    value: e("common", "prompt_desc")
                }, {
                    xtype: "spacer",
                    flex: 1
                }, {
                    xtype: "container",
                    layout: "hbox",
                    layougConfig: {
                        pack: "center"
                    },
                    items: [{
                        xtype: "syno_button",
                        width: 200,
                        cls: "syno-d-prompt-window-btn",
                        text: e("common", "pc_client"),
                        scope: this,
                        handler: this.onPCClientClick
                    }, {
                        xtype: "spacer",
                        width: 16
                    }, {
                        xtype: "syno_button",
                        width: 200,
                        cls: "syno-d-prompt-window-btn",
                        text: e("common", "mobile_app"),
                        scope: this,
                        handler: this.onMobileAppClick
                    }]
                }, {
                    xtype: "spacer",
                    height: 36
                }],
                listeners: {
                    scope: this,
                    afterrender: {
                        single: !0,
                        fn: this.onAfterRender
                    },
                    close: this.onWinClose
                }
            }
        },
        onAfterRender: function() {
            this.closeBtn = new SYNO.ux.Panel({
                renderTo: this.el,
                floating: !0,
                shadow: !1,
                items: {
                    xtype: "box",
                    autoEl: {
                        tag: "img",
                        src: SYNO.SDS.Drive.FileType.getDefaultIcon()
                    },
                    cls: "syno-d-prompt-window-close"
                }
            }), this.mon(this.closeBtn.el, "click", this.onCloseBtnClick, this), this.closeBtn.el.alignTo(this.el, "tr-tr", [14, -14]), this.addManagedComponent(this.closeBtn)
        },
        onCloseBtnClick: function() {
            this.close()
        },
        getOS: function() {
            return Ext.isMac ? "Mac" : Ext.isWindows ? "Windows" : Ext.isLinux ? "Linux" : "default"
        },
        onPCClientClick: function() {
            SYNO.SDS.CSTN.WebAPI.getClientLink.call(this, this.getOS(), window.navigator.platform, "drive", function(e, t, i, n) {
                var s = SYNO.SDS.Drive._T("warning", "err_get_download_link_fail");
                e ? SYNO.SDS.Utils.IFrame.request(t.download_link, function(e, t, i, n) {
                    "timeout" === e || Ext.isGecko && !Ext.isObject(n) || this.getMsgBox().alert("", s)
                }, this, null, null, !0) : this.getMsgBox().alert("", s)
            }, this)
        },
        onMobileAppClick: function() {
            new SYNO.SDS.Drive.DownloadClient.QrcodeWindow({
                owner: this,
                module: this
            }).show()
        },
        afterShow: function() {
            this.callParent(arguments);
            var e = this.owner.el.query(".sds-window-mask")[0];
            Ext.fly(e).addClass("syno-d-prompt-window-mask")
        },
        onWinClose: function() {
            var e = this.owner.el.query(".sds-window-mask")[0];
            Ext.fly(e).removeClass("syno-d-prompt-window-mask")
        }
    }), Ext.define("SYNO.SDS.Drive.DownloadClient.Qrcode", {
        extend: "Ext.Container",
        xtype: "synodrive_qrcode",
        constructor: function(e) {
            var t = {
                xtype: "container",
                items: {
                    xtype: "container",
                    cls: "syno-d-download-qrcode-content",
                    layout: "vbox",
                    layoutConfig: {
                        pack: "center",
                        align: "center"
                    },
                    items: [{
                        xtype: "container",
                        cls: e.qrcodeCls
                    }, {
                        xtype: "syno_displayfield",
                        cls: "syno-d-download-qrcode-content-text",
                        value: e.text
                    }],
                    listeners: {
                        scope: this,
                        afterrender: {
                            single: !0,
                            fn: function(t) {
                                this.mon(t.getEl(), "click", function() {
                                    window.open(e.storeURL, "_blank")
                                }, this)
                            }
                        }
                    }
                }
            };
            this.callParent([t])
        }
    }), Ext.define("SYNO.SDS.Drive.DownloadClient.QrcodeWindow", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = {
                width: 600,
                height: 421,
                cls: "syno-d-prompt-window syno-d-download-qrcode-window",
                layout: "fit",
                header: !1,
                elements: "body",
                useStatusBar: !1,
                resizable: !1,
                closable: !1,
                draggable: !1,
                padding: void 0,
                items: this.getContent()
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getContent: function() {
            var e = SYNO.SDS.Drive._T;
            return [{
                xtype: "container",
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [{
                    xtype: "spacer",
                    height: 32
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-download-qrcode-title",
                    value: e("common", "mobile_tip")
                }, {
                    xtype: "spacer",
                    height: 8
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-download-qrcode-desc",
                    value: e("common", "mobile_desc")
                }, {
                    xtype: "container",
                    flex: 1,
                    layout: "hbox",
                    layoutConfig: {
                        pack: "center",
                        align: "middle"
                    },
                    items: [{
                        xtype: "synodrive_qrcode",
                        text: _T("common", "ios"),
                        qrcodeCls: "syno-d-download-qrcode-content-ios",
                        storeURL: "https://itunes.apple.com/us/app/synology-drive/id1267275421?ls=1&mt=8"
                    }, {
                        xtype: "spacer",
                        width: 60
                    }, {
                        xtype: "synodrive_qrcode",
                        text: _T("common", "android"),
                        qrcodeCls: "syno-d-download-qrcode-content-android",
                        storeURL: "https://play.google.com/store/apps/details?id=com.synology.dsdrive"
                    }]
                }, {
                    xtype: "spacer",
                    height: 30
                }],
                listeners: {
                    scope: this,
                    afterrender: {
                        single: !0,
                        fn: this.onAfterRender
                    },
                    close: this.onWinClose
                }
            }]
        },
        onAfterRender: function() {
            this.closeBtn = new SYNO.ux.Panel({
                renderTo: this.el,
                floating: !0,
                shadow: !1,
                items: {
                    xtype: "box",
                    autoEl: {
                        tag: "img",
                        src: SYNO.SDS.Drive.FileType.getDefaultIcon()
                    },
                    cls: "syno-d-prompt-window-close"
                }
            }), this.mon(this.closeBtn.el, "click", this.onCloseBtnClick, this), this.closeBtn.el.alignTo(this.el, "tr-tr", [14, -14]), this.addManagedComponent(this.closeBtn)
        },
        onCloseBtnClick: function() {
            this.close()
        },
        afterShow: function() {
            this.callParent(arguments);
            var e = this.owner.el.query(".sds-window-mask")[0],
                t = Ext.fly(e);
            t.addClass("syno-d-qrcode-mask"), t.setStyle("position", "fixed")
        },
        onWinClose: function() {
            var e = this.owner.el.query(".sds-window-mask")[0];
            Ext.fly(e).removeClass("syno-d-qrcode-mask")
        }
    }), Ext.define("SYNO.SDS.Drive.DownloadClient.PromptToast", {
        extend: "SYNO.ux.Panel",
        WIDTH: 340,
        constructor: function(e) {
            this.progressIndicator = new Ext.Container({
                cls: "progress-indicator",
                width: 24,
                margins: "0 12 0 10"
            });
            var t = {
                cls: "syno-d-prompt-toast",
                width: this.WIDTH,
                floating: !0,
                shadow: !1,
                layout: "auto",
                items: [{
                    border: !1,
                    data: {},
                    tpl: this.createContentTemplate()
                }, {
                    xtype: "container",
                    layout: "hbox",
                    height: 34,
                    layoutConfig: {
                        align: "stretch"
                    },
                    items: [{
                        xtype: "syno_checkbox",
                        cls: "syno-d-prompt-checkbox",
                        boxLabel: SYNO.SDS.Drive._T("common", "prompt_dont_show_again"),
                        flex: 1,
                        scope: this,
                        checked: !1,
                        handler: this.onCheck
                    }, this.progressIndicator]
                }],
                listeners: {
                    scope: this,
                    afterrender: {
                        single: this,
                        fn: this.onAfterRender
                    }
                }
            };
            Ext.apply(t, e || {}), this.appWindow = e.appWindow, this.callParent([t])
        },
        onAfterRender: function() {
            var e = 0,
                t = this.el.child("span.syno-d-prompt-tip"),
                i = t.getTextWidth();
            i > 228 && (e = this.WIDTH + (i - 228));
            var n = this.el.child("span.syno-d-prompt-link"),
                s = Ext.fly(n.dom.firstChild).getTextWidth();
            s > 228 && (e = Math.max(e, this.WIDTH + (s - 228))), e && this.setWidth(e), n.on("click", this.onShowDownloadClient, this), this.closeBtn = new SYNO.ux.Panel({
                renderTo: this.el,
                floating: !0,
                shadow: !1,
                width: 32,
                height: 32,
                items: {
                    xtype: "box",
                    autoEl: {
                        tag: "img",
                        src: SYNO.SDS.Drive.FileType.getDefaultIcon()
                    },
                    cls: "syno-d-prompt-close"
                }
            }), this.mon(this.closeBtn.el, "click", this.onCloseBtnClick, this), this.closeBtn.el.alignTo(this.el, "tr-tr", [14, -14]), this.addManagedComponent(this.closeBtn)
        },
        onCheck: function(e, t) {
            this.appWindow.appInstance.setUserSettings("hide_prompt_toast", t)
        },
        onCloseBtnClick: function() {
            this.hidePanel()
        },
        onShowDownloadClient: function() {
            new SYNO.SDS.Drive.DownloadClient.Window({
                owner: this.appWindow,
                module: this.appWindow
            }).show()
        },
        alignPanel: function() {
            this.el.alignTo(this.alignTargetEl, "bl-br", [-14, -20])
        },
        createContentTemplate: function() {
            var e = SYNO.SDS.Drive._T;
            return new Ext.XTemplate('<div class="syno-d-prompt-wrapper">', '<div class="syno-d-prompt-icon"></div>', '<span class="syno-d-prompt-tip">' + e("common", "prompt_tip") + "</span><br>", '<span class="syno-d-prompt-link"><a>' + e("common", "prompt_tip_link") + "</a></span>", "</div>")
        },
        slideIn: function() {
            var e = {
                    opacity: {
                        to: 1,
                        from: 0
                    },
                    left: {
                        by: -12 - this.getWidth(),
                        unit: "px"
                    }
                },
                t = this.el;
            t.animate(e, .5, function() {
                var e = t.getRight(),
                    i = t.getBottom();
                t.setStyle({
                    top: "",
                    left: "",
                    right: Ext.lib.Dom.getViewWidth(!0) - e - 1 + "px",
                    bottom: Ext.lib.Dom.getViewHeight(!0) - i - 1 + "px"
                })
            }, "easeOut")
        },
        showPanel: function() {
            this.alignPanel(), this.slideIn()
        },
        hidePanel: function(e) {
            if (!1 === e) return void this.hide();
            var t = {
                left: {
                    by: 12 + this.getWidth(),
                    unit: "px"
                },
                opacity: {
                    from: 1,
                    to: 0
                }
            };
            this && this.el && this.el.animate(t, .5, null, "easeOut")
        }
    }), Ext.define("SYNO.SDS.Drive.WindowHelper", {
        singleton: !0,
        SHAREMODE: Ext.isFunction(window.getDriveShareMode) ? window.getDriveShareMode() : "",
        getBaseAppPath: function() {
            var e = window.location.pathname,
                t = /\/oo\/r\/[A-Za-z0-9]+$/,
                i = /\/oo\/t\/[A-Za-z0-9_.]+$/,
                n = /\/d\/f\/[A-Za-z0-9]+$/,
                s = /\/d\/s\/([A-Za-z0-9]+)\/([^\/]+)$/;
            return t.test(e) ? e = e.replace(t, "") : i.test(e) ? e = e.replace(i, "") : n.test(e) ? e = e.replace(n, "") : s.test(e) && (e = e.replace(s, "")), e.lastIndexOf("/") === e.length - 1 && (e = e.slice(0, -1)), e
        },
        getBaseAppURL: function() {
            return window.location.protocol + "//" + window.location.host + this.getBaseAppPath()
        },
        getStandaloneLaunchURL: function(e, t) {
            var i = SYNO.SDS.Config.FnMap[e];
            if (i) {
                t = Ext.apply({
                    launchApp: e
                }, t), SYNO.SDS.JSDebug && !Ext.isDefined(t.jsDebug) && (t = Ext.apply(t, {
                    jsDebug: SYNO.SDS.JSDebug
                }));
                return Ext.urlAppend(this.getBaseAppURL(), Ext.urlEncode(t), !0 !== i.config.allowURLNoSynoToken)
            }
        },
        isPublicFileShare: function() {
            return this.isPublicShare() && window.getDriveFile && "file" === window.getDriveFile().type
        },
        isPublicShare: function() {
            return "public" === SYNO.SDS.Drive.WindowHelper.SHAREMODE
        },
        isAdvShare: function() {
            return window.getDriveSharingLink && !Ext.isEmpty(window.getDriveSharingLink())
        }
    }), Ext.define("SYNO.SDS.Drive.Env", {
        singleton: !0,
        constructor: function() {
            this.isPulicMode = SYNO.SDS.Drive.WindowHelper.isPublicShare(), this.supported = ["file_id", "isPulicMode", "permanent_link", "shared_with", "labels"]
        },
        init: function(e) {
            e.file_id ? this.file_id = e.file_id : this.isPulicMode && Ext.isFunction(window.getDriveFile) && window.getDriveFile() && SYNO.SDS.Drive.Env.set(window.getDriveFile())
        },
        set: function(e, t) {
            Ext.isObject(e) ? Ext.copyTo(this, e, this.supported) : -1 < this.supported.indexOf(e) && (this[e] = t)
        },
        get: function(e, t) {
            return this.hasOwnProperty(e) ? this[e] : t
        }
    }), Ext.define("SYNO.SDS.Drive.RoundButton", {
        extend: "Ext.Button",
        template: new Ext.Template('<em class="{2} {3} syno-d-round-button" style="{5}" unselectable="on"><button type="{0}"></button><div class="syno-d-round-img"></div></em>').compile(),
        getMenuClass: function() {
            return ""
        },
        getTemplateArgs: function() {
            var e = [this.type, "x-btn-" + this.scale + " x-btn-icon-" + this.scale + "-" + this.iconAlign, this.getMenuClass(), this.cls, this.id];
            return this.color ? e.push("background-color:" + this.color + ";") : e.push(""), this.updateAccountIcon(), e
        },
        updateAccountIcon: function() {
            this.rendered && this.el && this.el.dom && this.color && this.el.setStyle("background", this.color)
        }
    }), Ext.reg("synodrive_round_button", SYNO.SDS.Drive.RoundButton), Ext.define("SYNO.SDS.Drive.SimpleButton", {
        extend: "Ext.Button",
        template: new Ext.Template('<em class="{2} syno-d-simple-button" unselectable="on"><button type="{0}"></button></em>').compile(),
        getMenuClass: function() {
            return ""
        }
    }), Ext.reg("synodrive_simple_button", SYNO.SDS.Drive.SimpleButton), Ext.define("SYNO.SDS.Drive.SearchList", {
        extend: "SYNO.ux.Menu",
        enableScrolling: !1,
        minChars: 0,
        lastQuery: null,
        assetHeight: 0,
        maxHeight: 423,
        width: 300,
        selectedClass: "x-combo-selected",
        listEmptyText: "",
        constructor: function(e) {
            this.callParent([this.fillConfig(e)]), this.mon(this, "afterlayout", function() {
                this.focusEl = this.getSearchField().getEl(), this.bindStore(this.store, !0)
            }, this, {
                single: !0
            })
        },
        fillConfig: function(e) {
            Ext.apply(this, e);
            var t = "x-combo-list",
                i = Ext.apply({
                    autoRender: !0,
                    cls: t + " syno-ux-combobox-list x-layer",
                    items: [this.getSearchField(e), {
                        xtype: "container",
                        height: 4
                    }, this.getView(t)]
                }, e);
            return this.store = e.store, i
        },
        onDestroy: function() {
            this.bindStore(null), Ext.destroy(this.view, this.getSearchField(), this.store), SYNO.SDS.Drive.SearchList.superclass.onDestroy.call(this)
        },
        initComponent: function() {
            SYNO.SDS.Drive.SearchList.superclass.initComponent.call(this), this.addEvents("expand", "collapse", "beforeselect", "select", "beforequery"), this.selectedIndex = -1
        },
        getView: function(e) {
            return this.view ? this.view : (this.tpl || (!0 === this.tplHtmlEncode ? this.tpl = '<tpl for="."><div class="' + e + '-item {[values.cls || ""]}" role="option" aria-label="{[Ext.util.Format.htmlEncode(Ext.util.Format.stripTags(values.' + this.displayField + '))]}" id="{[Ext.id()]}">{[Ext.util.Format.htmlEncode(values.' + this.displayField + ")]}</div></tpl>" : this.tpl = '<tpl for="."><div class="' + e + '-item {[values.cls || ""]}" role="option" aria-label="{' + this.displayField + '}" id="{[Ext.id()]}">{' + this.displayField + "}</div></tpl>"), this.view = new SYNO.ux.FleXcroll.DataView({
                tpl: this.tpl,
                singleSelect: !0,
                useDefaultKeyNav: !0,
                overClass: this.selectedClass,
                selectedClass: this.selectedClass,
                itemSelector: this.itemSelector || "." + e + "-item",
                emptyText: this.listEmptyText,
                deferEmptyText: !1,
                listeners: {
                    containerclick: this.onViewClick,
                    click: this.onViewClick,
                    scope: this
                }
            }), this.view)
        },
        getSearchField: function(e) {
            return this.searchfield || (this.searchfield = new SYNO.TextFilter({
                width: (e.width || this.width) - 16,
                itemId: "searchfield",
                listeners: {
                    scope: this,
                    keyup: {
                        fn: function(e) {
                            this.doQuery(e.getValue())
                        },
                        buffer: 300
                    },
                    afterrender: {
                        scope: this,
                        single: !0,
                        fn: function(e) {
                            e.mon(e.trigger, "click", function() {
                                this.doQuery(e.getValue())
                            }, this)
                        }
                    }
                }
            }))
        },
        getStore: function() {
            return this.store
        },
        bindStore: function(e, t) {
            this.store && !t && (this.store !== e && this.store.autoDestroy ? this.store.destroy() : (this.store.un("beforeload", this.onBeforeLoad, this), this.store.un("load", this.onLoad, this), this.store.un("exception", this.collapse, this)), e || (this.store = null, this.view && this.view.bindStore(null))), e && (t || (this.lastQuery = null), this.store = Ext.StoreMgr.lookup(e), this.store.on({
                scope: this,
                beforeload: this.onBeforeLoad,
                load: this.onLoad,
                exception: this.onLoadException
            }), this.view && this.view.bindStore(e))
        },
        doQuery: function(e, t) {
            e = Ext.isEmpty(e) ? "" : e.trim();
            var i = {
                query: e,
                forceAll: t,
                combo: this,
                cancel: !1
            };
            if (!1 === this.fireEvent("beforequery", i) || i.cancel) return !1;
            e = i.query, (!0 === (t = i.forceAll) || e.length >= this.minChars) && (this.lastQuery !== e ? (this.lastQuery = e, "local" === this.mode ? (this.selectedIndex = -1, t ? this.store.clearFilter() : this.store.filter(this.displayField, e), this.onLoad()) : 0 !== this.store.getTotalCount() && this.blQueryEmpty && !1 !== this.onBeforeQuery(e) ? this.restrictHeight() : (this.store.baseParams[this.queryParam] = e, this.store.load({
                params: this.getParams(e),
                callback: function() {
                    this.lastQuery || this.blQueryEmpty || (this.blQueryEmpty = !0)
                },
                scope: this
            }))) : (this.selectedIndex = -1, this.onLoad()))
        },
        onBeforeQuery: function(e) {
            return this.store.filter(this.displayField, e, !0, !1, !1), !0
        },
        getParams: function(e) {
            return {}
        },
        isExpanded: function() {
            return this.isVisible()
        },
        collapse: function() {
            this.isExpanded() && this.hide()
        },
        expand: function(e, t) {
            this.isExpanded() || (this.parentEl = e || this.parentEl, this.show(e, t), this.assetHeight || this.items.each(function(e) {
                e !== this.getView() && (this.assetHeight += e.getHeight())
            }, this), null === this.lastQuery ? this.doQuery("", !0) : this.restrictHeight())
        },
        onBeforeLoad: function() {
            this.selectedIndex = -1
        },
        onLoad: function() {
            this.restrictHeight()
        },
        onLoadException: function() {},
        onViewClick: function() {
            var e = this.view.getSelectedIndexes()[0],
                t = this.store,
                i = t.getAt(e);
            i ? this.onSelect(i, e) : this.collapse()
        },
        onSelect: function(e, t) {
            if (!1 !== this.fireEvent("beforeselect", this, e, t)) {
                var i = this.getValue(),
                    n = this.getStore();
                this.setValue(e.data[this.valueField || this.displayField]), this.collapse(), this.fireEvent("select", this, e, t);
                var s = n.findExact("name", i); - 1 !== s ? n.getAt(s).commit() : n.getAt(0).commit(), e.commit()
            }
        },
        setValue: function(e) {
            this.value = e
        },
        getValue: function() {
            return this.value || ""
        },
        restrictHeight: function() {
            var e = this.view.getTemplateTarget().dom,
                t = this.el.getFrameWidth("tb") + this.assetHeight,
                i = Math.max(e.clientHeight, e.offsetHeight, e.scrollHeight),
                n = this.owner.getPosition()[1] - Ext.getBody().getScroll().top,
                s = Ext.lib.Dom.getViewHeight(!0) - n - this.owner.getHeight(),
                o = Math.max(n, s, this.minHeight || 0) - t - 5;
            i = Math.min(i, o, this.maxHeight), this.setHeight(i + t), this.ul.setHeight(i + this.assetHeight), this.view.setHeight(i + 1), this.view.updateFleXcroll(), this.show(this.parentEl)
        },
        select: function(e, t) {
            var i = this;
            if (i.callParent(arguments), !1 !== t) {
                var n = i.view.getNode(e);
                n && i.view.fleXcrollTo(n)
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Info.Panel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            this.owner = e.owner, this.module = e.module;
            var t = this.fillConfig(e);
            this.callParent([t])
        },
        fillConfig: function(e) {
            var t = this,
                i = {
                    trackResetOnLoad: !0,
                    autoHeight: !0,
                    items: [{
                        xtype: "syno_textfield",
                        cls: "syno-d-info-title-textfield",
                        fieldLabel: SYNO.SDS.Drive._T("file", "title"),
                        name: "name",
                        validator: function(e) {
                            var i = e.trim();
                            return 0 === i.length ? this.blankText : i.length > 0 && unescape(encodeURIComponent(i)).length >= SYNO.SDS.Drive.Define.TITLE_MAX_LENGTH - (t.ext ? t.ext.length + 1 : 0) ? SYNO.SDS.Drive._T("error", "name_too_long") : !!SYNO.SDS.Drive.Utils.checkFileName(e) || SYNO.SDS.Drive._T("error", "reserved_name")
                        },
                        allowBlank: !1
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("file", "title"),
                        name: "name_readonly",
                        hidden: !0
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("file", "type"),
                        name: "ntype"
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("info", "created"),
                        name: "ctime_readonly"
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("info", "modified"),
                        name: "mtime"
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("file", "owner"),
                        name: "owner"
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("file", "size"),
                        name: "size"
                    }, {
                        xtype: "syno_displayfield",
                        itemCls: SYNO.SDS.Utils.SelectableCLS,
                        fieldLabel: SYNO.SDS.Drive._T("file", "location"),
                        name: "location",
                        cls: "syno-d-info-location",
                        htmlEncode: !1,
                        listeners: {
                            scope: this,
                            single: !0,
                            render: function(e) {
                                this.mon(e.getEl(), "click", this.onGotoPath, this)
                            }
                        }
                    }]
                };
            return Ext.apply(i, e)
        },
        onGotoPath: function(e, t, i) {
            if (Ext.fly(t).is("a"))
                if ("SYNO.SDS.Drive.PublicApplication" === _S("standaloneAppName") || "SYNO.SDS.Drive.Application" === _S("standaloneAppName")) {
                    var n = this.findAppWindow().getNavigation().getCategory();
                    if ("node" === n || "team_folder" === n) return void this.owner.close();
                    this.findAppWindow().getAction().onGotoPath(this.data.file_id), this.owner.close()
                } else SYNO.SDS.Drive.Utils.onOpenMgr({}, {
                    file_id: this.data.file_id
                })
        },
        updateData: function(e) {
            var t, i = this.getForm();
            this.data = e, e = SYNO.Util.copy(e);
            var n = e.ctime || e.created_time,
                s = e.mtime || e.modified_time;
            if (Ext.isNumber(n) && (e.ctime_readonly = SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * n))), "dir" === e.type ? e.ntype = SYNO.SDS.Drive._T("file", "dir") : e.ntype && "office" === SYNO.SDS.Drive.Utils.getFileTypeMapping(e.ntype) ? (t = e.ntype, "oslides" === t && (t = "oslide"), e.ntype = SYNO.SDS.Drive._T("file", t)) : SYNO.SDS.Drive.Utils.isOfficeFile(e.name) && (t = SYNO.SDS.Drive.Utils.getExt(e.name), "oslides" === t && (t = "oslide"), e.ntype = SYNO.SDS.Drive._T("file", t)), "dir" === e.type) e.size = "-";
            else {
                var o = Ext.util.Format.number(e.size, "0,000");
                e.size = String.format("{0} ({1} Bytes)", Ext.util.Format.fileSize(e.size), o)
            }
            var r = SYNO.SDS.Drive.Utils.parseDisplayName(e.name);
            if (r !== e.name && (this.ext = SYNO.SDS.Drive.Utils.getExt(e.name)), e.name = r, e.name_readonly = r, Ext.isNumber(s) && (e.mtime = SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * s))), Ext.isObject(e.owner)) {
                var a = e.owner.display_name,
                    l = e.owner.name,
                    d = e.owner.nickname;
                Ext.isString(a) && (e.owner = a), Ext.isString(l) && (e.owner_name = l), Ext.isString(d) && (e.owner_nickname = d)
            }
            var h = SYNO.SDS.Drive.Utils.parseDisplayPath(e.display_path),
                c = '<span class="syno-d-info-path" ext:qtip="{0}">{1}</span>';
            SYNO.SDS.Drive.Utils.isVisibleInDrive(e.display_path) && (c += '<span class="syno-d-info-goto">(<a>{2}</a>)</span>');
            var u = Ext.util.Format.htmlEncode(h),
                p = Ext.util.Format.htmlEncode(u);
            if (e.location = String.format(c, p, u, SYNO.SDS.Drive._T("common", "goto")), this.updatePermUI(e), i.setValues(e), SYNO.SDS.Drive.Define.Info.use_nickname) {
                var S = e.owner_name;
                e.owner_nickname && (S += " (" + e.owner_nickname + ")"), new Ext.ToolTip({
                    target: i.findField("owner").getEl(),
                    html: Ext.util.Format.htmlEncode(S)
                })
            }
        },
        updatePermUI: function(e) {
            if (!e.capabilities.can_delete || SYNO.SDS.Drive.Utils.is1stSharedWithMe(e.display_path)) {
                var t = this.getForm();
                t.findField("name_readonly").show(), t.findField("name").hide();
                var i = this.owner.getFooterToolbar().items;
                i.get("ok").hide(), i.get("cancel").hide(), i.get("close") || this.owner.addButton({
                    itemId: "close",
                    text: _T("common", "close"),
                    scope: this.owner,
                    handler: this.owner.close
                }), this.owner.doLayout()
            }
        },
        updateForm: function(e) {
            this.updateData(e.data)
        },
        updateFormByNode: function(e) {
            this.updateData(e)
        },
        isDirty: function() {
            return this.getForm().isDirty()
        }
    }), Ext.define("SYNO.SDS.Drive.Info.Window", {
        extend: "SYNO.SDS.Drive.AddEditWindow",
        mode: "edit",
        maxNameLength: SYNO.SDS.Drive.Define.TITLE_MAX_LENGTH,
        nameItemId: "name",
        constructor: function(e) {
            this.owner = e.owner, e.path ? this.path = e.path : this.rec = e.rec, this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("file", "info"),
                resizable: !1,
                autoHeight: !0,
                listeners: {
                    single: !0,
                    beforeshow: function() {
                        if (this.path) this.onLoadData(e);
                        else {
                            var t = this.getFormPanel();
                            t.updateForm(this.rec), t.getForm().clearInvalid()
                        }
                    },
                    scope: this
                }
            };
            return Ext.apply(t, e)
        },
        getFormPanel: function() {
            return Ext.isEmpty(this.infoFormPanel) && (this.infoFormPanel = new SYNO.SDS.Drive.Info.Panel({
                owner: this,
                module: this
            })), this.infoFormPanel
        },
        isDirty: function() {
            return this.getFormPanel().isDirty()
        },
        getParams: function() {
            var e = this.getForm().getFieldValues(!0) || {};
            return this.rec ? e.path = SYNO.SDS.Drive.Utils.getPathId(this.rec.id) : e.path = this.path, e.ctime && Ext.isDate(e.ctime) && (e.created_time = e.ctime.valueOf() / 1e3, delete e.ctime), e
        },
        onAction: function(e) {
            if (e.name) {
                var t = this.getFormPanel().ext;
                t && (e.name += "." + t)
            }
            this.findAppWindow().getAction().setNodeTitle(e, this.onApplyCb, this)
        },
        onLoadData: function(e) {
            if (e) {
                this.getFormPanel().updatePermUI(e)
            }
            this.setStatusBusy(), this.findAppWindow().getWebAPI().getNode({
                params: {
                    path: this.path
                },
                callback: this.onLoadDataDone,
                scope: this
            })
        },
        onLoadDataDone: function(e, t, i, n) {
            if (!this.isDestroyed) {
                if (this.clearStatusBusy(), !e) {
                    var s = SYNO.API.Util.GetFirstError(t);
                    return void this.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(s), function() {
                        this.close()
                    }, this)
                }
                var o = SYNO.SDS.Drive.WebAPIDesc.get_file,
                    r = SYNO.API.Util.GetValByAPI(t, o.api, o.method);
                this.getFormPanel().updateFormByNode(r)
            }
        }
    }), Ext.ns("SYNO.SDS.Drive.Setting"), Ext.define("SYNO.SDS.Drive.Setting.GeneralPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            this.owner = e.owner, this.module = e.module, this.callParent([this.fillConfig(e)])
        },
        createForm: function() {
            var e = Ext.applyIf({
                appWindow: this,
                listeners: {}
            }, this.initialConfig);
            return new SYNO.API.Form.BasicForm(null, e)
        },
        fillConfig: function(e) {
            var t;
            return this.appPortalDesc = new SYNO.ux.DisplayField({
                ctCls: "syno-d-setting-portal-desc",
                value: ""
            }), this.appPortalLink = new SYNO.ux.DisplayField({
                htmlEncode: !1,
                hidden: !0
            }), this.appPortalBtn = new SYNO.ux.Button({
                btnStyle: "grey",
                text: SYNO.SDS.Drive._T("setting", "launch_app_portal"),
                hidden: !0,
                handler: function() {
                    var e = "SYNO.SDS.AdminCenter.AppPortal.Main";
                    SYNO.SDS.Drive.Utils.isDSM7OrAbove() && (e = "SYNO.SDS.AdminCenter.Login.Main");
                    var t = new SYNO.SDS.WindowLauncher(SYNO.SDS.WindowLauncher.Util.parseOptions("SYNO.SDS.AdminCenter.Application", Ext.apply({
                            fn: e
                        }, this.findAppWindow().openConfig))),
                        i = Ext.urlDecode(window.location.search.substr(1)) || {};
                    return t.url = Ext.urlAppend(window.location.protocol + "//" + window.location.host, Ext.urlEncode(Ext.apply(i, {
                        launchApp: "SYNO.SDS.AdminCenter.Application"
                    })), !0), t.openNewWindow(void 0, t.getLaunchURL())
                },
                scope: this
            }), t = {
                cls: "syno-d-setting-general",
                trackResetOnLoad: !0,
                border: !1,
                frame: !1,
                autoScroll: !0,
                header: !1,
                useDefaultBtn: !1,
                title: SYNO.SDS.Drive._T("setting", "general"),
                items: [{
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("setting", "notification"),
                    items: [{
                        xtype: "checkboxgroup",
                        fieldLabel: SYNO.SDS.Drive._T("setting", "notification_by"),
                        columns: 1,
                        defaultType: "syno_checkbox",
                        items: [{
                            name: "enable_email_notification",
                            boxLabel: _T("notification", "notification_email")
                        }, {
                            name: "enable_chat_notification",
                            boxLabel: SYNO.SDS.Drive._T("notification", "notification_chat"),
                            hidden: !SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Chat.Application")
                        }]
                    }]
                }, {
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("setting", "app_portal"),
                    items: [this.appPortalDesc, this.appPortalLink, this.appPortalBtn]
                }, {
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("setting", "lang_codepage"),
                    items: [this.getCodepageTitle(), this.getCodepageCombo()]
                }]
            }, Ext.apply(t, e)
        },
        getCodepageTitle: function() {
            return this.codepageTitle ? this.codepageTitle : (this.codepageTitle = new SYNO.ux.DisplayField({
                value: SYNO.SDS.Drive._T("setting", "download_codepage_desc")
            }), this.codepageTitle)
        },
        getCodepageCombo: function() {
            return this.codepageCombo ? this.codepageCombo : (this.codepageStore = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: SYNO.SDS.Drive.Utils.getSupportedCodepage()
            }), this.codepageCombo = new SYNO.ux.ComboBox({
                name: "archive_codepage",
                fieldLabel: SYNO.SDS.Drive._T("setting", "lang_codepage"),
                store: this.codepageStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                editable: !1,
                value: "unicode",
                mode: "local"
            }), this.codepageCombo)
        },
        loadData: function() {
            return SYNO.SDS.Drive.WebAPICore.sendPromise(["get_user_setting", "get_dsm_setting"]).then(function(e) {
                this.handleSetting(e.result[0].success, e.result[0].data || e.result[0].error), this.handleAppPortal(e.result[1].success, e.result[1].data || e.result[1].error)
            }.bind(this))
        },
        handleSetting: function(e, t) {
            if (this.rendered) this.getForm().setValues(t);
            else {
                var i = function() {
                    this.getForm().setValues(t)
                }.bind(this);
                this.mun(this, "activate", i, this), this.mon(this, "activate", i, this, {
                    single: !0
                })
            }
        },
        handleAppPortal: function(e, t) {
            var i;
            return e ? (t && (i = this.makeAppPortalURL(t.app_portal)), i ? (this.appPortalDesc.setValue(SYNO.SDS.Drive._T("setting", "app_portal_link_desc")), this.appPortalLink.setValue(i), this.appPortalLink.show(), void this.appPortalLink.setHeight("auto")) : void(this._S("is_admin") ? this.showAppPortalBtn() : this.hideAppPortalBtn())) : (this.appPortalLink.hide(), void this.showAppPortalBtn())
        },
        showAppPortalBtn: function() {
            this.appPortalDesc.setValue(SYNO.SDS.Drive._T("setting", "app_portal_enable_desc")), this.appPortalBtn.show(), this.appPortalBtn.setText(SYNO.SDS.Drive._T("setting", "launch_app_portal"))
        },
        hideAppPortalBtn: function() {
            this.appPortalDesc.setValue(SYNO.SDS.Drive._T("setting", "app_portal_admin_desc")), this.appPortalBtn.hide()
        },
        makeAppPortalURL: function(e) {
            var t, i, n, s = [],
                o = !1,
                r = '<a href="{0}" rel="noreferrer" target="_blank"> {0} </a>';
            return Ext.isObject(e) ? e.fqdn && window.location.hostname.toLowerCase() === e.fqdn.toLowerCase() ? (t = Ext.form.VTypes.netbiosName(e.fqdn) ? "http" : "https", n = String.format("{0}://{1}", t, e.fqdn), String.format(r, n)) : (t = window.location.protocol, i = this.getDsmHost() || window.location.hostname, this.getDsmHttpPort() || parseInt(window.location.port, 10), [".quickconnect.to", ".quickconnect.cn"].forEach(function(e) {
                i.toLowerCase().substr(-1 * e.length) === e && (o = !0)
            }), "alias" in e && (n = t + "//" + i + "/" + e.alias + "/", s.push(String.format(r, n))), o || ("http_port" in e && (n = "http://" + i + ":" + e.http_port, s.push(String.format(r, n))), "https_port" in e && (n = "https://" + i + ":" + e.https_port, s.push(String.format(r, n)))), e.fqdn && (t = Ext.form.VTypes.netbiosName(e.fqdn) ? "http" : "https", n = String.format("{0}://{1}", t, e.fqdn), s.push(String.format(r, n))), s.join("<br>")) : ""
        },
        applyForm: function(e, t) {
            return this.getForm().isDirty() ? (this.sendWebAPI({
                compound: {
                    stopwhenerror: !1,
                    params: [Ext.apply({
                        params: this.getForm().getValues()
                    }, SYNO.SDS.Drive.WebAPIDesc.update_user_setting)]
                },
                callback: function(i, n) {
                    if (!i || n.has_fail) return void t(n);
                    e()
                },
                scope: this
            }), !0) : (e(), !1)
        }
    }), Ext.ns("SYNO.SDS.Drive.Setting"), Ext.define("SYNO.SDS.Drive.Setting.DateTimePanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(e) {
            this.owner = e.owner, this.module = e.module, this.callParent([this.fillConfig(e)])
        },
        createForm: function() {
            var e = Ext.applyIf({
                appWindow: this,
                listeners: {}
            }, this.initialConfig);
            return new SYNO.API.Form.BasicForm(null, e)
        },
        fillConfig: function(e) {
            var t;
            return t = {
                trackResetOnLoad: !0,
                border: !1,
                frame: !1,
                autoScroll: !0,
                header: !1,
                useDefaultBtn: !1,
                title: SYNO.SDS.Drive._T("setting", "display"),
                items: [{
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("common", "language"),
                    items: [this.getLangTitle(), this.getLangCombo()]
                }, {
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("common", "time"),
                    items: [this.getTimeTitle(), this.getDateCombo(), this.getTimeCombo()]
                }, {
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.Drive._T("setting", "displayname"),
                    items: [this.getDisplayNameTitle(), this.getDisplayNameCombo()]
                }]
            }, Ext.apply(t, e)
        },
        getLangTitle: function() {
            return this.langTitle ? this.langTitle : (this.langTitle = new SYNO.ux.DisplayField({
                value: SYNO.SDS.Drive._T("setting", "language_desc")
            }), this.langTitle)
        },
        getTimeTitle: function() {
            return this.timeTitle ? this.timeTitle : (this.timeTitle = new SYNO.ux.DisplayField({
                value: SYNO.SDS.Drive._T("setting", "time_desc")
            }), this.timeTitle)
        },
        getDisplayNameTitle: function() {
            return this.displayNameTitle ? this.displayNameTitle : (this.displayNameTitle = new SYNO.ux.DisplayField({
                value: SYNO.SDS.Drive._T("setting", "displayname_des")
            }), this.displayNameTitle)
        },
        getDisplayNameCombo: function() {
            if (this.displayNameCombo) return this.displayNameCombo;
            var e = SYNO.SDS.Drive._T("common", "sys_default_setting") || SYNO.SDS.Drive._T("common", "lang_dsm") || SYNO.SDS.Drive._STR("common", "lang_dsm"),
                t = new Ext.data.JsonStore({
                    fields: ["display", "value"],
                    data: [{
                        display: e,
                        value: "default"
                    }, {
                        display: SYNO.SDS.Drive._T("common", "usrname"),
                        value: "username"
                    }, {
                        display: SYNO.SDS.Drive._T("common", "nickname"),
                        value: "nickname"
                    }]
                });
            return this.displayNameCombo = new SYNO.ux.ComboBox({
                name: "displayname_setting",
                fieldLabel: SYNO.SDS.Drive._T("setting", "displayname_field"),
                store: t,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                value: "system"
            }), this.displayNameCombo
        },
        getLangCombo: function() {
            return this.langCombo ? this.langCombo : (this.langStore = this.createLangStore(), this.langCombo = new SYNO.ux.ComboBox({
                name: "lang_combo",
                fieldLabel: SYNO.SDS.Drive._T("common", "language"),
                store: this.langStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                editable: !1,
                mode: "local"
            }), this.langCombo)
        },
        getDateCombo: function() {
            return this.dateCombo ? this.dateCombo : (this.dateStore = this.createDateFormatStore(), this.dateCombo = new SYNO.ux.ComboBox({
                name: "date_combo",
                fieldLabel: _STR("personal_settings", "date_format"),
                store: this.dateStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                editable: !1,
                mode: "local"
            }), this.dateCombo)
        },
        getTimeCombo: function() {
            return this.timeCombo ? this.timeCombo : (this.timeStore = this.createTimeFormatStore(), this.timeCombo = new SYNO.ux.ComboBox({
                name: "time_combo",
                fieldLabel: _STR("personal_settings", "time_format"),
                store: this.timeStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                editable: !1,
                mode: "local"
            }), this.timeCombo)
        },
        loadData: function() {
            if (this.langCombo.value = SYNO.SDS.UserSettings.getProperty("Personal", "lang") || "def", SYNO.SDS.DateTimeUtils.GetTimeFormat) this.timeCombo.value = SYNO.SDS.DateTimeUtils.GetTimeFormat(), this.dateCombo.value = SYNO.SDS.DateTimeUtils.GetDateFormat();
            else {
                var e = SYNO.SDS.UserSettings.getProperty("Personal", "timeFormat");
                e && e.length > 0 && (this.timeCombo.value = e);
                var t = SYNO.SDS.UserSettings.getProperty("Personal", "dateFormat");
                t && t.length > 0 && (this.dateCombo.value = t)
            }
            return SYNO.SDS.Drive.WebAPICore.sendPromise("get_user_setting").then(function(e) {
                this.displayNameCombo.setValue(e.displayname_setting)
            }.bind(this))
        },
        applyForm: function(e, t) {
            return this.getForm().isDirty() ? (SYNO.SDS.UserSettings.setProperty("Personal", "lang", this.langCombo.value), SYNO.SDS.DateTimeUtils.SetUserFormat ? (SYNO.SDS.DateTimeUtils.SetUserFormat("date", this.dateCombo.value), SYNO.SDS.DateTimeUtils.SetUserFormat("time", this.timeCombo.value)) : (this.timeCombo.value && this.timeCombo.value.length > 0 && SYNO.SDS.UserSettings.setProperty("Personal", "timeFormat", this.timeCombo.value), this.dateCombo.value && this.dateCombo.value.length > 0 && SYNO.SDS.UserSettings.setProperty("Personal", "dateFormat", this.dateCombo.value)), this.sendWebAPI({
                compound: {
                    stopwhenerror: !1,
                    params: [Ext.apply({
                        params: this.getForm().getValues()
                    }, SYNO.SDS.Drive.WebAPIDesc.update_user_setting)]
                },
                callback: function(i, n) {
                    if (!i || n.has_fail) return void t(n);
                    e()
                },
                scope: this
            }), !0) : (e(), !1)
        },
        createLangStore: function() {
            var e = SYNO.SDS.Utils.getSupportedLanguage(),
                t = _T("common", "sys_default_setting") || _T("common", "lang_dsm") || _STR("common", "lang_dsm");
            return e.unshift(["def", t]), new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: e
            })
        },
        createDateTimeStore: function(e) {
            var t = e.map(function(e, t) {
                return [e, (new Date).format(e)]
            });
            return new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: t
            })
        },
        createTimeFormatStore: function() {
            if (SYNO.SDS.DateTimeUtils.CreateTimeFormatStore) return SYNO.SDS.DateTimeUtils.CreateTimeFormatStore(!0);
            var e = SYNO.SDS.DateTimeUtils.SupportedTimeFormats;
            return this.createDateTimeStore(e)
        },
        createDateFormatStore: function() {
            if (SYNO.SDS.DateTimeUtils.CreateDateFormatStore) return SYNO.SDS.DateTimeUtils.CreateDateFormatStore(!0);
            var e = SYNO.SDS.DateTimeUtils.SupportedDateFormats;
            return this.createDateTimeStore(e)
        },
        onSave: function() {
            this.getForm().isDirty() && (SYNO.SDS.UserSettings.save(), setTimeout(function() {
                SYNO.SDS.Drive.GetWindow().getMsgBox({
                    preventDelay: !0
                }).confirm("", SYNO.SDS.Drive._T("personal_settings", "refresh_confirm"), function(e) {
                    "yes" === e && location.reload(!0)
                })
            }, 500))
        }
    }), Ext.ns("SYNO.SDS.Drive.Setting"), Ext.define("SYNO.SDS.Drive.Setting.Window", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            this.owner = e.owner, this.module = e.module;
            var t = this.fillConfig(e);
            this.callParent([t]), this.onLoadData()
        },
        fillConfig: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("common", "setting"),
                width: 640,
                height: 572,
                layout: "fit",
                cls: "syno-d-setting-win",
                items: this.getSettingPanel(),
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.Drive._T("common", "cancel"),
                    scope: this,
                    handler: this.onClickCancel
                }, {
                    xtype: "syno_button",
                    btnStyle: "default",
                    text: SYNO.SDS.Drive._T("common", "ok"),
                    handler: this.onClickOk,
                    scope: this
                }]
            };
            return SYNO.SDS.CSTN.IsDSM7OrAbove() || t.buttons.reverse(), Ext.apply(t, e)
        },
        getGeneralSettingPanel: function() {
            return new SYNO.SDS.Drive.Setting.GeneralPanel({
                owner: this.owner,
                module: this
            })
        },
        getDateTimeSettingPanel: function() {
            return new SYNO.SDS.Drive.Setting.DateTimePanel({
                owner: this.owner,
                module: this
            })
        },
        getOfficeSettingPanel: function() {
            return new SYNO.SDS.Office.Setting.Panel({
                owner: this.owner,
                module: this
            })
        },
        getSettingPanel: function() {
            if (this.settingPanel) return this.settingPanel;
            var e = [];
            Ext.getClassByName("SYNO.SDS.Profile.Panel") && (SYNO.SDS.Avatar.Dialog.prototype.EDITOR_WIDTH = 420, SYNO.SDS.Avatar.Dialog.prototype.EDITOR_HEIGHT = 420, SYNO.SDS.Avatar.Editor.prototype.blConstraintMask = !0, this.profile_panel = new SYNO.SDS.Profile.Panel({
                title: SYNO.SDS.Drive._T("common", "title_profile"),
                useDefaultBtn: !1,
                avatarCtCfg: {
                    width: 200
                },
                profileCfg: {
                    tzHidden: !0,
                    padding: void 0,
                    descHeight: 50
                },
                avatarDlgCfg: {
                    closable: !0,
                    width: 476,
                    height: 588,
                    padding: "12px 27px 0 27px"
                },
                processProfileGetSuccess: function(e) {
                    this.onProfileGetSuccess.apply(this, arguments)
                }.bind(this),
                processProfileGetFailed: function() {
                    this.onProfileGetFailed.apply(this, arguments)
                }.bind(this),
                listeners: {
                    scope: this,
                    applysucceed: function(e, t) {
                        this.module.updateAccountIcon(!0, t ? SYNO.API.Util.GetValByAPI(t, "SYNO.Personal.Profile", "set") : null), this.onProfileSetSuccess.apply(this, arguments)
                    },
                    applyfailed: function() {
                        this.onProfileSetFailed.apply(this, arguments)
                    },
                    deletesucceed: function() {
                        this.module.updateAccountIcon(!0)
                    }
                }
            }), this.profile_panel.profileForm.getLangField().hide(), e.push(this.profile_panel)), this.general_panel = this.getGeneralSettingPanel(), e.push(this.general_panel), this.datatime_panel = this.getDateTimeSettingPanel(), e.push(this.datatime_panel);
            try {
                window.SYNO_WebManager_Strings.mail.mail_account = SYNO.SDS.Drive._T("mail", "mail_account")
            } catch (e) {}
            return Ext.getClassByName("SYNO.Personal.Mail.MailForm") && e.push(new SYNO.Personal.Mail.MailForm({
                module: this,
                dialogButtonCfg: {
                    confirm: {
                        btnStyle: "default"
                    }
                }
            })), SYNO.SDS.Drive.Utils.hasOffice() && (this.office_panel = this.getOfficeSettingPanel(), e.push(this.office_panel)), this.settingPanel = new SYNO.ux.TabPanel({
                activeTab: 0,
                items: e
            }), this.settingPanel
        },
        onLoadData: function() {
            var e = [];
            this.profile_panel && e.push(new Promise(function(e, t) {
                this.onProfileGetSuccess = e, this.onProfileGetFailed = t
            }.bind(this))), e.push(this.general_panel.loadData()), this.datatime_panel.loadData(), this.office_panel && e.push(new Promise(function(e, t) {
                this.office_panel.onLoadData(e, t)
            }.bind(this))), this.setStatusBusy(), Promise.all(e).then(function() {
                this.clearStatusBusy()
            }.bind(this), function(e) {
                this.clearStatusBusy();
                var t = function() {
                    this.close()
                };
                SYNO.SDS.Drive.Utils.showErrorMsg(this, e, t, this)
            }.bind(this))
        },
        onClickCancel: function() {
            this.close()
        },
        onClickOk: function() {
            this.applySetting()
        },
        applySetting: function() {
            var e = [];
            if (this.profile_panel) {
                if (!this.profile_panel.isValid()) return this.settingPanel.setActiveTab(this.profile_panel), !1;
                e.push(new Promise(function(e, t) {
                    this.onProfileSetSuccess = e, this.onProfileSetFailed = t
                }.bind(this)))
            }
            e.push(new Promise(function(e, t) {
                this.general_panel.applyForm(e, t)
            }.bind(this))), e.push(new Promise(function(e, t) {
                this.datatime_panel.applyForm(e, t)
            }.bind(this))), this.office_panel && e.push(new Promise(function(e, t) {
                this.office_panel.applyForm(e, t)
            }.bind(this))), this.setStatusBusy(), Promise.all(e).then(function() {
                this.notClose || this.close()
            }.bind(this), function() {
                this.clearStatusBusy(), this.setStatusError({
                    text: SYNO.SDS.Drive._T("error", "save"),
                    clear: !0
                })
            }.bind(this)), this.profile_panel && this.profile_panel.onSave(), this.datatime_panel.onSave()
        }
    }), Ext.define("SYNO.SDS.Drive.Utils.DocumentVisibility", {
        extend: Ext.util.Observable,
        singleton: !0,
        supportVisibilityChange: !1,
        documentHiddenKey: void 0,
        constructor: function() {
            this.addEvents("onPageVisible", "onPageInvisible");
            var e;
            void 0 !== document.hidden ? (this.documentHiddenKey = "hidden", e = "visibilitychange") : void 0 !== document.msHidden ? (this.documentHiddenKey = "msHidden", e = "msvisibilitychange") : void 0 !== document.webkitHidden && (this.documentHiddenKey = "webkitHidden", e = "webkitvisibilitychange"), void 0 === document.addEventListener || void 0 === this.documentHiddenKey ? this.supportVisibilityChange = !1 : (this.supportVisibilityChange = !0, document.addEventListener(e, function() {
                document[this.documentHiddenKey] ? this.fireEvent("onPageInvisible") : this.fireEvent("onPageVisible")
            }.bind(this), !1))
        },
        doesSupport: function() {
            return this.supportVisibilityChange
        },
        isVisible: function() {
            return !this.supportVisibilityChange || !document[this.documentHiddenKey]
        }
    }), Ext.ns("SYNO.SDS.Drive.Notification"), Ext.define("SYNO.SDS.Drive.Notification.Menu", {
        extend: "SYNO.ux.Menu",
        lastRead: 0,
        userObj: {},
        DEFAULT_POLL_INTERVAL: 3e4,
        BGTASK_POLL_INTERVAL: 3e3,
        statics: {
            OneWeekSeconds: 604800
        },
        autoFlexcroll: !1,
        enableScrolling: !1,
        constructor: function(e) {
            this.currentData = [], this.callParent([this.fillConfig(e)]), this.onInitPollingTask(), this.onRegEvent()
        },
        fillConfig: function(e) {
            return Ext.apply({
                cls: "syno-d-notification-menu",
                width: 400,
                items: [this.getGrid()],
                listeners: {
                    scope: this,
                    show: this.onShowMenu,
                    hide: this.onHideMenu
                }
            }, e)
        },
        lastUpdateTime: 0,
        pendingStart: !1,
        onRegEvent: function() {
            var e = this.findAppWindow().getEventMgr();
            this.mon(e, {
                scope: this,
                buffer: 100,
                bgtask_update: this.onBgTaskUpdate
            }), SYNO.SDS.Drive.Utils.DocumentVisibility.on("onPageVisible", this.onPageVisible.bind(this, !0)), SYNO.SDS.Drive.Utils.DocumentVisibility.on("onPageInvisible", this.onPageVisible.bind(this, !1))
        },
        onPageVisible: function(e) {
            void 0 === this.pollTask || this.pollTask.removed || (e && this.pendingStart ? this.resuemPolling() : !e && this.pollTask.running && this.pausePolling())
        },
        onBgTaskUpdate: function(e) {
            var t = this.getPollingTask();
            e && t.interval !== this.BGTASK_POLL_INTERVAL && (this.removePollingTask(), this.getPollingTask(this.BGTASK_POLL_INTERVAL), this.startPolling(!0)), e || t.interval === this.DEFAULT_POLL_INTERVAL || (this.removePollingTask(), this.getPollingTask(this.DEFAULT_POLL_INTERVAL), this.startPolling(!0))
        },
        onMsgRender: function(e, t, i, n, s, o) {
            var r = i.data,
                a = "";
            i.id === this.readItemId && (a = '<h1 class="syno-d-notification-read"><span class="syno-d-notification-read-text">' + SYNO.SDS.Drive._T("notification", "old") + "</span></h1>");
            var l = this.getMsgContent(r);
            return a + '<table class="syno-d-notification-ct ' + this.getCursorCss(r) + '" border="0" cellspacing="0" cellpadding="0"><tr><td class="syno-d-account-icon-ct" rowspan="3">' + this.getNotificationIcon(r, n) + '</td><td class="syno-d-notification-msg" ext:qtip="' + Ext.util.Format.stripTags(l) + '">' + l + '</td></tr><tr><td ext:qtip="' + this.getMsgDate(r, !0) + '" class="syno-d-notification-time">' + this.getMsgDate(r, !1) + '</td></tr><tr><td class="syno-d-notification-file">' + this.getFile(r) + "</td></tr></table>"
        },
        getCursorCss: function(e) {
            return this.isFileAction(e.type) && (e.content.success || !e.content.names || Ext.isArray(e.content.errors) && 1 >= e.content.names.length) ? "" : "cursor"
        },
        getNotificationIcon: function(e, t) {
            return this.isFileAction(e.type) ? this.getSystemInfoIcon() : this.getAccount(e, t)
        },
        getSystemInfoIcon: function() {
            return '<div class="system-info-icon"></div>'
        },
        getAccount: function(e, t) {
            var i = e.sender;
            if (!i) return "";
            var n, s, o = i.uid,
                r = this.userObj[o];
            r ? (n = i.display_name, s = o === SYNO.SDS.Drive.Define.Info.uid ? SYNO.SDS.Drive.Define.ColorSelf : r.color) : (n = i.display_name, s = SYNO.SDS.Drive.Define.ColorSelf);
            var a = '<em class="syno-d-account-icon-l syno-d-round-button" style="background-color:' + s + ';" unselectable="on"><button class="x-btn-text" ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(n)) + '" type="button">' + SYNO.SDS.Drive.Utils.getAccount1stName(n) + "</button>",
                l = "";
            return e.use_image && (l = String.format('style="background-color: #FFF;background-image:url({0})"', this.getAccountURL(o))), a += String.format('<div class="syno-d-round-img" {0}>', l) + "</div></em>"
        },
        getAccountURL: function(e) {
            return this.getBaseURL({
                api: "SYNO.SynologyDrive.SCIM.Photo",
                version: 1,
                method: "get",
                params: {
                    size: "S",
                    retina: SYNO.SDS.UIFeatures.test("isRetina"),
                    type: "other",
                    uid: e
                }
            }, !0, e + ".png")
        },
        updateAccountIcon: function(e, t, i, n) {
            var s = this.getStore(),
                o = this.getGrid().getView(),
                r = function(r) {
                    var a = s.getAt(e),
                        l = a.data;
                    if (l.sender.uid === t) {
                        var d = o.getRow(e);
                        if (this.isRowRendered(d)) {
                            l.rendered = !0;
                            var h = Ext.fly(d).child("em.syno-d-round-button"),
                                c = !0;
                            2 > r.width && 2 > r.height && (c = !1), l.use_image = c, !0 === c ? (h.setStyle("background", "#FFF"), h.dom.lastChild.setAttribute("style", String.format("background-color: #FFF;background-image:url({0});", i))) : n ? (h.setStyle("background", n), h.dom.lastChild.removeAttribute("style")) : (h.dom.removeAttribute("style"), h.dom.lastChild.removeAttribute("style"))
                        }
                    }
                }.bind(this);
            SYNO.SDS.Drive.GetWindow().getImageLoader().load(i, {
                load: function(e) {
                    r(e)
                }
            })
        },
        isRowRendered: function(e) {
            return e && e.childNodes.length > 0
        },
        isFileAction: function(e) {
            switch (e) {
                case "drive#upload_task":
                case "drive#background_task":
                    return !0;
                default:
                    return !1
            }
        },
        onUpdateUserIcon: function() {
            for (var e, t, i = this.getStore(), n = i.getCount(), s = this.getGrid().getView(), o = 0; o < n; ++o)
                if (e = i.getAt(o), t = e.data, !t.rendered && !this.isFileAction(t.type)) {
                    var r = s.getRow(o);
                    if (this.isRowRendered(r) && t.sender) {
                        var a, l, d = t.sender.uid;
                        (a = this.userObj[d]) && (l = d === SYNO.SDS.Drive.Define.Info.uid ? SYNO.SDS.Drive.Define.ColorSelf : a.color, this.updateAccountIcon(o, d, this.getAccountURL(d), l))
                    }
                }
        },
        getMsgByFileType: function(e, t, i) {
            var n = {};
            if (n[SYNO.SDS.Drive.FileType.SYNODOC] = "doc", n[SYNO.SDS.Drive.FileType.SYNOSHEET] = "sheet", n[SYNO.SDS.Drive.FileType.SYNOSLIDE] = "slide", "file" === e && SYNO.SDS.Drive.Utils.isOfficeFile(t)) {
                var s = SYNO.SDS.Drive.Utils.getExt(t);
                return String.format("notification:{0}_{1}", i, n[s])
            }
            return String.format("notification:{0}_{1}", i, "dir" === e ? "dir" : "file")
        },
        getBackgroundTaskMsg: function(e) {
            if (!e.names) return "";
            var t = e.names.length > 1,
                i = e.success,
                n = String.format("{0}{1}_{2}", e.action, t ? "_multi" : "", i ? "success" : "error"),
                s = Ext.util.Format.htmlEncode(e.names[0].toString()),
                o = Ext.util.Format.htmlEncode(s);
            return String.format(SYNO.SDS.Drive._T("task", n), t ? e.names.length : String.format('<b ext:qtip="{0}">{1}</b>', o, s))
        },
        getMsgFromNotificationType: function(e) {
            var t;
            switch (e.type) {
                case "drive#create":
                    t = "create";
                    break;
                case "drive#share_with_me":
                    t = "share";
                    break;
                case "drive#request":
                    t = "request";
                    break;
                case "drive#change_owner":
                    t = "owner";
                    break;
                case "drive#comment":
                    return "notification:comment_add_doc";
                case "drive#comment_reply":
                    return "notification:comment_reply";
                case "drive#mention":
                    return "notification:comment_mention_doc";
                case "drive#upload_task":
                case "drive#background_task":
                    return this.getBackgroundTaskMsg(e.content);
                case "drive#request_office_template":
                    return "notification:request_office_template";
                default:
                    return ""
            }
            return this.getMsgByFileType(e.content.file_type, e.content.name, t)
        },
        getMsgContent: function(e) {
            if (!e.content) return "";
            var t = this.getMsgFromNotificationType(e),
                i = SYNO.SDS.Drive.Define.AnonymousUID === e.sender.uid ? String.format(SYNO.SDS.Drive._T("common", "guest"), "") : e.sender.display_name;
            return 1 === e.extra_info.group.length && e.extra_info.multiple_comment ? t += "_multiple" : 2 === e.extra_info.group.length ? (i = String.format(SYNO.SDS.Drive._T("notification", "comment_grouping_another_person"), i), t += "_plural") : 2 < e.extra_info.group.length && (i = String.format(SYNO.SDS.Drive._T("notification", "comment_grouping"), i, e.extra_info.group.length - 1), t += "_plural"), String.format(SYNO.SDS.Utils.GetLocalizedString(t, "SYNO.SDS.Drive.Application"), "<b>" + i + "</b>")
        },
        getFile: function(e) {
            return e.content ? this.isFileAction(e.type) ? this.getTaskFileTemplate(e.content) : this.getDefaultFileTemplate(e) : ""
        },
        getTaskFileTemplate: function(e) {
            if (e.success) {
                if (!e.names || 1 === e.names.length) return "";
                var t = Ext.util.Format.htmlEncode(e.names.toString()),
                    i = Ext.util.Format.htmlEncode(t);
                return String.format('<div class="bgtask-filename" ext:qtip="{0}">{1}</div>', i, t)
            }
            if (Ext.isArray(e.errors)) {
                if (e.names && 1 === e.names.length) {
                    var n = SYNO.SDS.Drive.Utils.getErrorStr(e.errors[0].code);
                    return String.format('<div class="error" ext:qtip="{0}">{1}</div>', n, n)
                }
                return String.format('<div class="error underline">{0}</div>', SYNO.SDS.Drive._T("task", "partial_error"))
            }
            return ""
        },
        getDefaultFileTemplate: function(e) {
            var t, i;
            if ("drive#request_office_template" === e.type) return t = Ext.util.Format.htmlEncode(e.content.name), i = Ext.util.Format.htmlEncode(t), String.format('<div class="icon {0}"></div><div class="filename" ext:qtip="{1}">{2}</div>', SYNO.SDS.Drive.FileType.getMappingTypeCss(e.content.file_extension, 16), i, t);
            var n = SYNO.SDS.Drive.Utils.getNtype(e.content.name, e.content.file_type);
            return t = Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e.content.name)), i = Ext.util.Format.htmlEncode(t), String.format('<div class="icon {0}"></div><div class="filename" ext:qtip="{1}">{2}</div>', SYNO.SDS.Drive.FileType.getMappingTypeCss(n, 16), i, t)
        },
        getGrid: function() {
            return this.grid || (this.grid = new SYNO.ux.GridPanel({
                title: SYNO.SDS.Drive._T("notification", "title"),
                header: !0,
                cls: "syno-d-notification-grid",
                border: !1,
                width: 376,
                boxMaxHeight: 480,
                store: this.getStore(),
                hideHeaders: !0,
                disableSelection: !0,
                useNewStyle: !1,
                colModel: new Ext.grid.ColumnModel({
                    defaults: {
                        menuDisabled: !0,
                        fixed: !0,
                        align: "left"
                    },
                    columns: [{
                        width: 376,
                        dataIndex: "message",
                        renderer: this.onMsgRender.createDelegate(this)
                    }]
                }),
                view: new SYNO.SDS.Drive.Notification.GridView({
                    forceFit: !0,
                    disableTextSelect: !0,
                    deferEmptyText: !1,
                    rowOverCls: "",
                    emptyText: '<div class="syno-d-empty-panel-container"><div class="syno-d-empty-panel-img"></div><div class="syno-d-empty-panel-text">' + SYNO.SDS.Drive._T("notification", "empty") + "</div></div></div>",
                    scrollOffset: 0,
                    rowSelectorDepth: 11
                }),
                listeners: {
                    scope: this,
                    viewready: this.onUpdateGridView,
                    rowclick: this.onRowClick
                }
            }))
        },
        onUpdateGridView: function() {
            var e = this.grid;
            if (e.getView().hasRows()) {
                var t = this.grid.getView().mainBody.getHeight();
                this.grid.getHeight() + 36 !== t && this.grid.setHeight(t + 36)
            } else e.setHeight(302);
            e.ownerCt.doLayout(), this.onUpdateUserIcon()
        },
        getStore: function() {
            return this.store || (this.store = new Ext.data.JsonStore({
                autoDestroy: !0,
                totalProperty: "total",
                idProperty: "notification_id",
                fields: ["notification_id", "type", "time", "content", "sender", "recipient", "extra_info", {
                    name: "rendered",
                    convert: function() {
                        return !1
                    }
                }]
            }))
        },
        onShowMenu: function() {
            Ext.isEmpty(this.currentGroupData) || (this.stopPolling(), this.currentGroupData.length !== this.getStore().getTotalCount() || this.currentGroupData[0].notification_id !== this.getStore().getAt(0).id ? (this.onUpdataData(), this.currentGroupData.length && SYNO.SDS.UserSettings.setProperty("SYNO.SDS.Drive.Application", "lastRead", this.currentGroupData[0].time + 1)) : this.readItemId && (this.readItemId = void 0, this.grid.getView().refresh(), this.onUpdateGridView(), this.grid.getView().updateScroller()))
        },
        onUpdataData: function() {
            this.getStore().loadData(this.currentGroupData), this.grid.ownerCt.doLayout(), this.onUpdateUserIcon()
        },
        onHideMenu: function() {
            var e = this.getPollingTask();
            e.reqId || e.restart(!1), Ext.isArray(this.currentGroupData) && (this.findAppWindow().getEventMgr().fireEvent("notification_update", 0, this.currentGroupData.length), this.groupingData())
        },
        onStoreLoad: function(e, t) {
            this.findAppWindow().getEventMgr().fireEvent("notification_update", t.length)
        },
        onExceptionStore: function() {},
        onInitPollingTask: function() {
            this.getPollingTask().start(!0)
        },
        getPollingTask: function(e) {
            return this.pollTask || (this.pollTask = this.findAppWindow().addWebAPITask(Ext.apply({
                interval: e || this.DEFAULT_POLL_INTERVAL,
                params: {
                    limit: 100
                },
                scope: this,
                callback: this.onUpdatePolling
            }, SYNO.SDS.Drive.WebAPIDesc.list_notifications)))
        },
        removePollingTask: function() {
            this.pollTask && (this.pollTask.remove(), this.pollTask = null, this.lastUpdateTime = 0)
        },
        groupingData: function() {
            if (!Ext.isEmpty(this.currentData)) {
                var e;
                this.lastRead = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.Drive.Application", "lastRead") || SYNO.SDS.UserSettings.getProperty("SYNO.SDS.Office.Application", "lastRead") || 0, this.currentGroupData = [];
                for (var t = 0; t < this.currentData.length; ++t)
                    if (e = this.currentData[t], e.content) {
                        var i = !1;
                        if ("drive#comment" === e.type || "drive#mention" === e.type || "drive#comment_reply" === e.type)
                            for (var n = 0; n < this.currentGroupData.length; ++n) {
                                var s = this.currentGroupData[n];
                                if ((s.time > this.lastRead && e.time > this.lastRead || s.time <= this.lastRead && e.time <= this.lastRead) && s.content.link_id === e.content.link_id && s.type === e.type && s.time - e.time <= 600) {
                                    s.extra_info.multiple_comment = !0, -1 === s.extra_info.group.indexOf(e.sender.uid) && s.extra_info.group.push(e.sender.uid), i = !0;
                                    break
                                }
                            }
                        if (!i) {
                            this.currentGroupData.push(this.currentData[t]);
                            var o = this.currentGroupData[this.currentGroupData.length - 1];
                            o.extra_info = {
                                group: []
                            }, o.extra_info.multiple_comment = !1, o.extra_info.group.push(o.sender.uid)
                        }
                    }
            }
        },
        onUpdatePolling: function(e, t, i) {
            if (this.lastUpdateTime = (new Date).getTime(), this.findAppWindow().isDestroyed) return void this.stopPolling();
            if (t && t.items && 0 !== t.items.length && (this.previousData = this.currentData, this.currentData = t.items, this.currentData.length !== this.previousData.length || this.currentData[0].notification_id !== this.previousData[0].notification_id)) {
                this.lastRead = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.Drive.Application", "lastRead") || SYNO.SDS.UserSettings.getProperty("SYNO.SDS.Office.Application", "lastRead") || 0;
                var n, s = 0;
                this.groupingData();
                for (var o = 0; o < this.currentGroupData.length; ++o) {
                    if (n = this.currentGroupData[o], n.time <= this.lastRead) {
                        this.readItemId = n.notification_id;
                        break
                    }++s
                }
                0 === s && (this.readItemId = void 0), this.onUpdateUser(), this.findAppWindow().getEventMgr().fireEvent("notification_update", s, this.currentGroupData.length), this.isVisible() && this.onUpdataData()
            }
        },
        resuemPolling: function() {
            var e = (new Date).getTime();
            this.pendingStart = !1, this.lastUpdateTime && e - this.lastUpdateTime >= this.pollTask.interval ? this.startPolling(!0) : this.startPolling(!1)
        },
        pausePolling: function() {
            this.pollTask && (this.pendingStart = !0, this.pollTask.stop())
        },
        stopPolling: function() {
            this.pollTask && this.pollTask.stop(), this.pendingStart = !1
        },
        startPolling: function(e) {
            if (this.pollTask && !this.pollTask.removed) return SYNO.SDS.Drive.Utils.DocumentVisibility.isVisible() ? void(this.pollTask.running || this.getPollingTask().start(e)) : void(this.pendingStart = !0)
        },
        shareNode: function(e) {
            var t = e.content.link_id;
            this.findAppWindow().getAction().getNode({
                permanent_link: t
            }, function(i, n) {
                i && this.findAppWindow().getAction().shareNodeByParam({
                    permanent_link: t,
                    share_user: e.sender.name,
                    capabilities: n.capabilities,
                    name: n.name,
                    listeners: {
                        scope: this,
                        load: function(e) {
                            e && this.findAppWindow().getAction().onGotoPath(e.file_id, function() {
                                return !0
                            })
                        }
                    }
                })
            }, this)
        },
        onRowClick: function(e, t, i) {
            var n = this.grid.store.getAt(t),
                s = n.data;
            if (this.isFileAction(s.type)) {
                if (s.content.success || !s.content.names || Ext.isArray(s.content.errors) && 1 >= s.content.names.length) return;
                return new SYNO.SDS.Drive.Task.ViewErrorDialog({
                    owner: this.findAppWindow(),
                    appWindow: this.findAppWindow(),
                    errors: s.content.errors
                }).show(), void this.hide()
            }
            if ("drive#request_office_template" === s.type) {
                if (!SYNO.SDS.Drive.Utils.hasOffice() || !SYNO.SDS.Office.GetAction().shareTemplate) {
                    var o = SYNO.SDS.Drive._T("app", "install_office_alert");
                    return SYNO.SDS.Drive.Define.Info.office_migration && (o = SYNO.SDS.Drive._T("app", "migration_office")), void SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), o)
                }
                return SYNO.SDS.Office.GetAction().shareTemplate(s), void this.hide()
            }
            if ("drive#request" === s.type) return this.shareNode(s), void this.hide();
            if ("file" === s.content.file_type && SYNO.SDS.Drive.Utils.isOfficeFile(s.content.name)) return SYNO.SDS.Drive.Utils.openOfficeLink(s.content.link_id, s.content.hash, !0), void this.hide();
            var r = this.findAppWindow();
            r.getAction().onGotoPath({
                permanent_link: s.content.link_id
            }, function(e, t) {
                if (e) return !0;
                if (1002 !== t.code) return void r.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t));
                var i = SYNO.SDS.Drive._T("request", "ask_access"),
                    n = r.getMsgBox().confirm("", i, function(e) {
                        "yes" === e && r.getAction().requestAccess({
                            permanent_link: s.content.link_id
                        }, function(e, t) {
                            var n = SYNO.SDS.Drive._T("request", "sent");
                            i = e ? n.replace("<br>", "") : SYNO.SDS.Drive.Utils.getErrorStr(t), SYNO.SDS.Drive.Utils.showToastMsg(r, i, 3500)
                        })
                    });
                n.fbButtons.yes.setText(SYNO.SDS.Drive._T("request", "access")), n.fbButtons.no.setText(_T("common", "cancel"))
            }), this.hide()
        },
        getMsgDate: function(e, t) {
            var i, n, s = !1,
                o = e.time;
            return i = this.getCurrentTime() - o, n = i < 0, s = i > SYNO.SDS.Drive.Notification.Menu.OneWeekSeconds, s || t || n ? SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * o)) : Ext.util.Format.relativeTime(1e3 * o)
        },
        getCurrentTime: function() {
            return Ext.isNumber(this.nowSec) ? this.nowSec : this.nowSec = (new Date).getTime() / 1e3
        },
        onUpdateUser: function() {
            if (this.currentData) {
                for (var e, t, i = [], n = 0; n < this.currentData.length; ++n) t = this.currentData[n], (e = t.sender.uid) && !this.userObj[e] && i.push(e);
                0 !== i.length && this.findAppWindow().getWebAPI().getUsers({
                    params: {
                        uid: Ext.unique(i)
                    },
                    scope: this,
                    callback: function(e, t) {
                        if (e) {
                            for (var i = 0, n = t.users.length; i < n; i++) {
                                var s = t.users[i];
                                this.userObj[s.uid] = Ext.copyTo({}, s, ["name", "nick", "color"]);
                                var o = this.getAccountURL(s.uid);
                                SYNO.SDS.Drive.GetWindow().getImageLoader().load(o)
                            }
                            this.onUpdateUserIcon()
                        }
                    }
                })
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Notification.GridView", {
        extend: "SYNO.ux.FleXcroll.grid.GridView",
        constructor: function(e) {
            this.callParent([e])
        },
        onLayout: function() {
            var e = this,
                t = e.scroller.dom;
            e.autoFlexcroll && (e.fitColumns(!1), e.updateScrollbar(t))
        }
    }), Ext.define("SYNO.SDS.Drive.Task.ViewErrorDialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            this.appWindow = e.appWindow;
            var t = {
                title: SYNO.SDS.Drive._T("task", "view_error"),
                width: 800,
                height: 520,
                resizable: !1,
                cls: "syno-d-bgtask-view-error",
                layout: "fit",
                items: [this.getGridPanel(e)],
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.Drive._T("common", "close"),
                    btnStyle: "grey",
                    handler: this.onCloseClick,
                    scope: this
                }]
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getGridPanel: function(e) {
            if (this.grid) return this.grid;
            var t = {
                cls: "syno-d-bgtask-view-error-grid",
                enableHdMenu: !1,
                view: this.createGridView(),
                store: this.createGridStore(e.errors),
                cm: this.createGridCM(),
                listeners: {
                    viewready: function(e) {
                        this.view.updateScroller()
                    }
                }
            };
            return this.grid = new SYNO.ux.GridPanel(t), this.grid
        },
        createGridView: function() {
            var e = {
                rowHeight: 29,
                forceFit: !0,
                disableTextSelect: !0,
                deferEmptyText: !1
            };
            return new SYNO.ux.FleXcroll.grid.BufferView(e)
        },
        createGridStore: function(e) {
            var t = e.map(function(e) {
                return {
                    name: e.context.name,
                    path: e.context.path,
                    file_type: e.context.file_type,
                    reason: SYNO.SDS.Drive.Utils.getErrorStr(e.code)
                }
            });
            return new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["name", "path", "file_type", "reason"],
                data: t
            })
        },
        createGridCM: function() {
            var e = SYNO.SDS.Drive._T;
            return new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0,
                    sortable: !1,
                    scope: this
                },
                columns: [{
                    dataIndex: "name",
                    width: 240,
                    header: e("common", "file_name"),
                    renderer: function(e, t, i, n, s, o) {
                        var r = "dir" === i.data.file_type ? "dir" : SYNO.SDS.Drive.Utils.getExt(e);
                        return String.format('<span class="{0}"></span>', SYNO.SDS.Drive.FileType.getMappingTypeCss(r, 16)) + this.defaultRender(e)
                    }
                }, {
                    dataIndex: "path",
                    width: 280,
                    header: e("common", "path"),
                    renderer: this.defaultRender.createDelegate(this)
                }, {
                    dataIndex: "reason",
                    width: 223,
                    header: e("task", "reason"),
                    renderer: this.defaultRender.createDelegate(this)
                }]
            })
        },
        defaultRender: function(e, t, i, n, s, o) {
            var r = Ext.util.Format.htmlEncode(e) || "-",
                a = Ext.util.Format.htmlEncode(r);
            return String.format('<span ext:qtip="{0}">{1}</span>', a, r)
        },
        onCloseClick: function() {
            this.close()
        }
    }), Ext.define("SYNO.SDS.Drive.Task.MonitorDialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("task", "task_monitor"),
                width: 920,
                height: 559,
                resizable: !1,
                cls: "syno-d-bgtask-monitor",
                layout: "fit",
                items: [this.getGridPanel(e)],
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.Drive._T("common", "close"),
                    btnStyle: "grey",
                    handler: this.onCloseClick,
                    scope: this
                }]
            };
            Ext.apply(t, e || {}), this.appWindow = e.appWindow, e.store.suspendEvents(), this.callParent([t])
        },
        getGridPanel: function(e) {
            if (this.grid) return this.grid;
            var t = SYNO.SDS.Drive._T,
                i = {
                    cls: "syno-d-bgtask-monitor-grid",
                    enableHdMenu: !1,
                    view: this.createGridView(),
                    store: e.store,
                    cm: this.createGridCM(),
                    sm: this.createSelModel(),
                    tbar: [{
                        xtype: "syno_button",
                        itemId: "clear",
                        text: t("common", "clear_complete"),
                        btnStyle: "grey",
                        handler: this.onClearClick,
                        scope: this
                    }, {
                        xtype: "syno_button",
                        itemId: "remove",
                        text: t("common", "remove"),
                        btnStyle: "grey",
                        handler: this.onRemoveClick,
                        scope: this
                    }, {
                        xtype: "syno_button",
                        itemId: "restart",
                        text: t("common", "restart"),
                        btnStyle: "grey",
                        disabled: !0,
                        handler: this.onRestartClick,
                        scope: this
                    }],
                    listeners: {
                        scope: this,
                        viewready: function() {
                            e.store.resumeEvents(), this.getGridPanel().getView().updateScroller()
                        }
                    }
                };
            return this.grid = new SYNO.ux.GridPanel(i), this.grid
        },
        createGridView: function() {
            var e = {
                rowHeight: 29,
                forceFit: !0,
                disableTextSelect: !0,
                deferEmptyText: !1
            };
            return new SYNO.ux.FleXcroll.grid.BufferView(e)
        },
        createSelModel: function() {
            return new Ext.grid.RowSelectionModel({
                listeners: {
                    scope: this,
                    buffer: 80,
                    selectionchange: this.onSelectionChange
                }
            })
        },
        createGridCM: function() {
            var e = SYNO.SDS.Drive._T;
            return new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0,
                    sortable: !1,
                    scope: this
                },
                columns: [{
                    dataIndex: "title",
                    width: 120,
                    header: e("task", "task_title"),
                    renderer: this.titleRender.createDelegate(this),
                    listeners: {
                        scope: this,
                        click: this.onTitleClick
                    }
                }, {
                    dataIndex: "name",
                    width: 250,
                    header: e("file", "file"),
                    renderer: this.defaultRender.createDelegate(this)
                }, {
                    dataIndex: "time",
                    width: 100,
                    header: e("task", "left_time"),
                    renderer: function(e, t, i, n, s, o) {
                        var r = i.get("progress");
                        if (0 >= r || "processing" !== i.get("status")) return "-";
                        var a;
                        if (i.get("leftTime") >= 0) a = SYNO.SDS.Drive.Date.fancyDuration(i.get("leftTime").toFixed(0));
                        else {
                            var l = i.get("starttime"),
                                d = (new Date).getTime(),
                                h = (100 - r) / r * (d - l);
                            a = SYNO.SDS.Drive.Date.fancyDuration((h / 1e3).toFixed(0))
                        }
                        return String.format('<span css="syno-d-bgtask-lefttime" ext:qtip="{0}"> {1} <span>', a, a)
                    }
                }, {
                    dataIndex: "speed",
                    width: 100,
                    header: e("task", "speed"),
                    renderer: function(e, t, i, n, s, o) {
                        var r = '<span css="syno-d-bgtask-speed"  ext:qtip="{0}"> {1}/' + SYNO.SDS.Drive._T("task", "time_s") + " <span>",
                            a = i.get("progress"),
                            l = i.get("total");
                        if (0 >= a || 0 >= l || "processing" !== i.get("status")) return "-";
                        var d = 0;
                        if (i.get("speed") >= 0) d = i.get("speed");
                        else {
                            var h = i.get("starttime");
                            d = l * (a / 100) / (((new Date).getTime() - h) / 1e3), d = Math.round(100 * d) / 100
                        }
                        return "delete" === i.get("action") || "convert_office" === i.get("action") ? d += " " + SYNO.SDS.Drive._T("task", "file_number") : d = Ext.util.Format.fileSize(d), String.format(r, d, d)
                    }
                }, {
                    dataIndex: "progress",
                    width: 172,
                    header: e("task", "progress"),
                    renderer: function(e, t, i, n, s, o) {
                        var r = this.getProgressTpl();
                        return e = parseFloat(e), e = Math.round(100 * e) / 100, 0 < e ? r.fill(e, "", 100 === e) : ""
                    }
                }, {
                    dataIndex: "status",
                    width: 121,
                    header: e("common", "status"),
                    renderer: function(e, t, i, n, s, o) {
                        var r, a;
                        switch (e) {
                            case "task_error":
                                r = "error-occurred underline";
                                break;
                            case "partial_error":
                                r = "error underline";
                                break;
                            default:
                                r = e
                        }
                        return a = Ext.util.Format.htmlEncode(i.get("statusText")), String.format('<span class="syno-d-bgtask-status {0}" ext:qtip="{1}"> {2} </span>', r, Ext.util.Format.htmlEncode(a), a)
                    },
                    listeners: {
                        scope: this,
                        click: this.onShowError
                    }
                }]
            })
        },
        defaultRender: function(e, t, i, n, s, o) {
            var r = Ext.util.Format.htmlEncode(e),
                a = Ext.util.Format.htmlEncode(r);
            return String.format('<span ext:qtip="{0}">{1}</span>', a, r)
        },
        titleRender: function(e, t, i, n, s, o) {
            var r = i.get("titleTooltip");
            return String.format('<span ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(r), e)
        },
        getProgressTpl: function() {
            return this.progressTpl ? this.progressTpl : (this.progressTpl = new SYNO.SDS.Utils.ProgressBar({
                barWidth: 100,
                barHeight: 8,
                showValueText: !0
            }), this.progressTpl)
        },
        onShowError: function(e, t, i, n, s) {
            if (Ext.fly(n.getTarget()).hasClass("underline")) {
                var o = this.grid.getStore().getAt(i).get("taskid"),
                    r = this.appWindow.getTaskMgr().getTask(o);
                new SYNO.SDS.Drive.Task.ViewErrorDialog({
                    owner: this,
                    appWindow: this.appWindow,
                    errors: r.errors
                }).show()
            }
        },
        onSelectionChange: function() {
            var e = this.grid.getSelectionModel().getSelections(),
                t = 0 < e.length;
            Ext.each(e, function(e) {
                if ("upload_" !== e.get("taskid").substr(0, 7) || !e.data.status || -1 === e.get("status").indexOf("error")) return t = !1, !1
            }, this), this.grid.getTopToolbar().get("restart").setDisabled(!t), this.grid.getTopToolbar().get("remove").setDisabled(0 === e.length)
        },
        onClearClick: function() {
            for (var e = this.grid.getStore().data.items, t = 0; t < e.length; t++) "success" === e[t].data.status && (this.appWindow.getTaskMgr().removeTask(e[t].get("taskid")), e = this.grid.getStore().data.items, t--)
        },
        onRemoveClick: function() {
            var e = this.grid.getSelectionModel().getSelections();
            Ext.each(e, function(e) {
                this.appWindow.getTaskMgr().removeTask(e.get("taskid"))
            }, this)
        },
        onRestartClick: function() {
            var e = this.grid.getSelectionModel().getSelections();
            Ext.each(e, function(e) {
                this.appWindow.getTaskMgr().restartTask(e.get("taskid"))
            }, this)
        },
        onCloseClick: function() {
            this.close()
        },
        onTitleClick: function(e, t, i, n, s) {
            if (Ext.fly(n.getTarget()).hasClass("syno-d-bgtask-action")) {
                var o = this.grid.getStore().getAt(i).get("taskid");
                this.appWindow.getTaskMgr().getTask(o).onClickAction(), this.hide()
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Task.TrayPanel", {
        extend: "SYNO.ux.Menu",
        constructor: function(e) {
            var t = {
                cls: "syno-d-bgtask-menu",
                width: 400,
                items: [this.createGridPanel(), this.createViewDetailBtn()],
                listeners: {
                    scope: this,
                    show: this.onShowMenu
                }
            };
            Ext.apply(t, e || {}), this.appWindow = e.appWindow, this.callParent([t]), this.onRegEvent()
        },
        onRegEvent: function() {
            var e = this.appWindow.getTaskMgr();
            this.mon(e, {
                scope: this,
                ontaskadd: this.onTaskAdd,
                ontaskremove: this.onTaskRemove
            })
        },
        createViewDetailBtn: function() {
            var e = {
                text: SYNO.SDS.Drive._T("task", "view_detail"),
                cls: "syno-d-bgtask-view-detail",
                handler: this.onViewDetail,
                scope: this
            };
            return this.viewDetailBtn = new SYNO.SDS.Drive.SimpleButton(e), this.viewDetailBtn
        },
        createGridPanel: function() {
            var e = ['<div class="syno-d-empty-panel-container">', '<div class="syno-d-empty-panel-img"></div>', '<div class="syno-d-empty-panel-text">', SYNO.SDS.Drive._T("notification", "empty"), "</div>", "</div>"].join(""),
                t = {
                    title: this.getTitle(),
                    header: !0,
                    cls: "syno-d-bgtask-grid",
                    width: 376,
                    boxMaxHeight: 435,
                    store: this.getStore(),
                    hideHeaders: !0,
                    disableSelection: !0,
                    useNewStyle: !1,
                    colModel: new Ext.grid.ColumnModel({
                        defaults: {
                            menuDisabled: !0,
                            fixed: !0,
                            align: "left"
                        },
                        columns: [{
                            width: 376,
                            dataIndex: "taskid",
                            renderer: this.onTaskInfoRender.createDelegate(this),
                            listeners: {
                                scope: this,
                                click: this.onClickTask
                            }
                        }]
                    }),
                    view: new SYNO.ux.FleXcroll.grid.BufferView({
                        rowHeight: 57,
                        forceFit: !0,
                        disableTextSelect: !0,
                        deferEmptyText: !1,
                        emptyText: e,
                        scrollOffset: 0,
                        rowSelectorDepth: 11,
                        listeners: {
                            scope: this,
                            rowsinserted: this.onUpdateGridView
                        }
                    }),
                    listeners: {
                        scope: this,
                        viewready: this.onUpdateGridView,
                        rowclick: this.onRowClick,
                        afterrender: {
                            single: !0,
                            fn: this.onGridRender
                        }
                    }
                };
            return this.grid = new SYNO.ux.GridPanel(t), this.grid
        },
        getStore: function() {
            return this.dataStore ? this.dataStore : (this.dataStore = new Ext.data.JsonStore({
                autoDestroy: !1,
                fields: ["action", "title", "titleTooltip", "name", "progress", "status", "starttime", "speed", "leftTime", "total", "statusText", "taskid"],
                listeners: {
                    scope: this,
                    remove: function(e, t, i, n) {
                        0 === e.getCount() && this.findAppWindow().getEventMgr().fireEvent("hide_bgtask_tray")
                    }
                }
            }), this.dataStore)
        },
        getProgressTpl: function() {
            return this.progressTpl ? this.progressTpl : (this.progressTpl = new SYNO.SDS.Utils.ProgressBar({
                barWidth: 150,
                barHeight: 8,
                showValueText: !0
            }), this.progressTpl)
        },
        getTaskInfoTpl: function() {
            return this.taskInfoTpl ? this.taskInfoTpl : (this.taskInfoTpl = new Ext.XTemplate('<div class="syno-d-bgtask-info-wrapper {[this.getCursorClass(values.status, values.actionTitle)]}">', '<div class="syno-d-bgtask-info-wrapper-top">', '<span class="syno-d-bgtask-title">{[values.title]}: </span>', '<span class="syno-d-bgtask-name" ext:qtip="{[SYNO.SDS.Drive.Utils.doubleHtmlEncode(values.name)]}">', "{[Ext.util.Format.htmlEncode(values.name)]}", "</span>", "</div>", '<div class="syno-d-bgtask-info-wrapper-bottom">', "{progress}", "{[this.getSplitDiv(values)]}", '<div class="syno-d-bgtask-status {[this.getStatusClass(values.status)]}"', 'ext:qtip="{[SYNO.SDS.Drive.Utils.doubleHtmlEncode(values.statusText)]}">', "{[Ext.util.Format.htmlEncode(values.statusText)]}", "</div>", "</div>", "</div>", '<div class="{[this.getActionClass(values.status)]} {[this.getCursorClass(values.status, values.actionTitle)]}"></div>', {
                getSplitDiv: function(e) {
                    var t = e.statusText;
                    return Ext.isEmpty(t) || Ext.isEmpty(e.progress) ? "" : '<div class="syno-d-bgtask-split"></div>'
                },
                getStatusClass: function(e) {
                    var t;
                    switch (e) {
                        case "task_error":
                            t = "error-occurred underline";
                            break;
                        case "partial_error":
                            t = "error underline";
                            break;
                        default:
                            t = e
                    }
                    return t
                },
                getActionClass: function(e) {
                    switch (e) {
                        case "success":
                            return "syno-d-bgtask-success";
                        default:
                            return "syno-d-bgtask-remove"
                    }
                },
                getCursorClass: function(e, t) {
                    var i = ["upload"];
                    if ("success" === e && -1 === i.indexOf(t)) return "syno-d-bgtask-not-pointor"
                }
            }), this.taskInfoTpl)
        },
        getTitle: function() {
            return String.format('<span class="syno-d-bgtask-grid-title">{0}</span><span class="syno-d-bgtask-clean" ext:qtip="{1}"></span>', SYNO.SDS.Drive._T("task", "bgtask_title"), SYNO.SDS.Drive._T("common", "clear_complete"))
        },
        onGridRender: function() {
            var e = this.grid.header.down(".x-panel-header-text > .syno-d-bgtask-clean");
            this.mon(e, "click", this.onCleanTask, this)
        },
        onUpdateGridView: function() {
            if (this.isVisible()) {
                var e = this.grid;
                if (e.getView().hasRows()) {
                    var t = this.grid.getView().mainBody.getHeight();
                    this.grid.getHeight() + 36 !== t && this.grid.setHeight(t + 36), this.viewDetailBtn.show()
                } else e.setHeight(302), this.viewDetailBtn.hide();
                e.ownerCt.doLayout()
            }
        },
        onClickTask: function(e, t, i, n, s) {
            var o = this.grid.getStore().getAt(i).get("taskid"),
                r = this.appWindow.getTaskMgr().getTask(o);
            if (Ext.fly(n.getTarget()).hasClass("underline")) new SYNO.SDS.Drive.Task.ViewErrorDialog({
                owner: this.appWindow,
                appWindow: this.appWindow,
                errors: r.errors
            }).show(), this.hide();
            else if ("success" === r.status && "upload" === r.title) {
                var a = r.uploadPath || r.path + "/" + r.name;
                this.findAppWindow().getAction().onGotoPath(a.substring(3, a.length), void 0, void 0, !1), this.hide()
            }
        },
        onShowMenu: function() {
            this.grid.getView().refresh(), this.onUpdateGridView()
        },
        onViewDetail: function() {
            new SYNO.SDS.Drive.Task.MonitorDialog({
                owner: this.appWindow,
                appWindow: this.appWindow,
                store: this.getStore()
            }).show(), this.hide()
        },
        onTaskInfoRender: function(e, t, i, n, s, o) {
            var r = this.getProgressTpl(),
                a = this.getTaskInfoTpl(),
                l = parseFloat(i.get("progress"));
            l = Math.round(100 * l) / 100;
            var d = i.get("status"),
                h = i.get("statusText");
            return a.apply({
                title: i.get("title"),
                name: i.get("name"),
                titleTooltip: i.get("titleTooltip"),
                actionTitle: i.get("actionTitle"),
                status: d,
                statusText: 0 < l && "processing" === d ? "" : h,
                progress: "success" !== d && 0 < l ? r.fill(l, "", 100 === l) : ""
            })
        },
        onTaskAdd: function(e) {
            "upload" === e.type && this.findAppWindow().getEventMgr().fireEvent("show_bgtask_tray"), this.getStore().loadData([{
                action: e.action,
                title: e.getTrayTitle(),
                titleTooltip: e.getTrayTitleTooltip(),
                name: e.getTrayNames(),
                status: e.status,
                statusText: e.statusText,
                progress: e.hasProgress ? 0 : -1,
                starttime: e.starttime,
                speed: e.speed,
                leftTime: e.leftTime,
                total: e.total,
                taskid: e.taskid
            }], !0);
            var t = this.getStore().getAt(this.getStore().getCount() - 1);
            this.mon(e, {
                scope: this,
                onsuccess: this.onTaskSuccess.createDelegate(this, [t], !0),
                onerror: this.onTaskError.createDelegate(this, [t], !0),
                onprogress: this.onTaskProgress.createDelegate(this, [t], !0)
            })
        },
        onRowClick: function(e, t, i) {
            var n = Ext.fly(i.getTarget());
            if (n.is("div.syno-d-bgtask-remove")) {
                var s = e.getStore().getAt(t);
                this.onTaskRemove(s.get("taskid"), !0, !1)
            } else if (n.hasClass("syno-d-bgtask-action")) {
                var o = this.grid.getStore().getAt(t).get("taskid"),
                    r = this.appWindow.getTaskMgr().getTask(o);
                r.onClickAction(), this.hide()
            }
        },
        onTaskRemove: function(e, t, i) {
            if (i) {
                var n = this.dataStore.findExact("taskid", e),
                    s = Ext.get(this.grid.view.getRow(n));
                s && s.slideOut("r", {
                    duration: .5,
                    remove: !1,
                    callback: this.removeTask.createDelegate(this, [e, t])
                })
            } else this.removeTask(e, t)
        },
        onTaskProgress: function(e, t, i) {
            i.beginEdit(), i.set("status", e.status), i.set("statusText", e.statusText), i.set("progress", t), i.set("actionTitle", e.title), i.set("speed", e.speed), i.set("leftTime", e.leftTime), i.set("total", e.total), i.commit()
        },
        onTaskSuccess: function(e, t, i) {
            i.beginEdit(), i.set("status", "success"), i.set("title", e.getTrayTitle()), i.set("titleTooltip", e.getTrayTitleTooltip()), i.set("statusText", e.statusText), i.set("progress", 100), i.set("actionTitle", e.title), i.commit()
        },
        onTaskError: function(e, t, i) {
            i.beginEdit(), i.set("status", e.status), i.set("title", e.getTrayTitle()), i.set("titleTooltip", e.getTrayTitleTooltip()), i.set("statusText", e.statusText), i.set("progress", -1), i.set("actionTitle", e.title), i.commit()
        },
        onCleanTask: function() {
            for (var e = this.grid.getStore().data.items, t = 0; t < e.length; t++) "success" === e[t].data.status && (this.removeTask(e[t].get("taskid"), !0), e = this.grid.getStore().data.items, t--)
        },
        removeTask: function(e, t) {
            var i = this.dataStore.findExact("taskid", e); - 1 !== i && (this.dataStore.removeAt(i), t && this.appWindow.getTaskMgr().removeTask(e), this.onUpdateGridView())
        },
        onDestroy: function() {
            this.dataStore.destroy(), this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.Drive.QuotaInfo.Grid", {
        extend: "SYNO.ux.GridPanel",
        constructor: function() {
            this.callParent([this.fillConfig()])
        },
        fillConfig: function() {
            return {
                cls: "syno-d-quota-grid-panel",
                hideHeaders: !0,
                disableSelection: !0,
                store: new SYNO.API.JsonStore({
                    autoDestroy: !1,
                    root: "share_list",
                    proxy: new SYNO.API.Proxy(SYNO.SDS.Drive.WebAPIDesc.get_quota),
                    fields: [{
                        name: "name",
                        convert: function(e, t) {
                            return "homes" === e ? SYNO.SDS.Drive._T("category", "node") : e
                        }
                    }, {
                        name: "quota"
                    }, {
                        name: "used"
                    }, {
                        name: "share_quota"
                    }, {
                        name: "share_used"
                    }, {
                        name: "is_home"
                    }, {
                        name: "support_per_share_quota"
                    }],
                    listeners: {
                        scope: this,
                        beforeload: this.onStoreBeforeLoad,
                        load: this.onStoreLoad,
                        exception: this.onStoreException
                    }
                }),
                view: new SYNO.ux.FleXcroll.grid.BufferView({
                    rowHeight: 54,
                    disableTextSelect: !0,
                    deferEmptyText: !1
                }),
                height: 375,
                colModel: new Ext.grid.ColumnModel({
                    defaults: {
                        menuDisabled: !0,
                        editable: !1,
                        fixed: !0,
                        align: "left"
                    },
                    columns: [{
                        width: 46,
                        renderer: {
                            fn: this.renderIcon,
                            scope: this
                        }
                    }, {
                        width: 226,
                        dataIndex: "name"
                    }, {
                        width: 216,
                        renderer: {
                            fn: this.renderQuotaInfo,
                            scope: this
                        }
                    }]
                })
            }
        },
        onStoreBeforeLoad: function() {
            this.findWindow().setStatusBusy()
        },
        onStoreLoad: function() {
            this.findWindow().clearStatusBusy(), this.store.filter("support_per_share_quota", !0)
        },
        onStoreException: function(e, t, i, n, s, o) {
            this.findWindow().clearStatusBusy(), this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(s), function() {
                this.findWindow().close()
            }, this)
        },
        renderIcon: function(e, t, i) {
            var n = i.get("is_home");
            t.css += !0 === n ? "syno-quota-home-folder " : "syno-quota-team-folder "
        },
        renderQuotaInfo: function(e, t, i) {
            var n = i.get("quota"),
                s = i.get("used"),
                o = i.get("share_quota"),
                r = i.get("share_used");
            return this.showProgressBar(n, s, o, r)
        },
        loadData: function() {
            this.store.load()
        },
        showProgressBar: function(e, t, i, n) {
            var s = this.getProgressTpl(),
                o = this.getTaskInfoTpl(),
                r = '<span class="syno-d-quota-used-bold">' + Ext.util.Format.fileSize(1024 * t * 1024) + "</span>",
                a = '<span class="syno-d-quota-used-bold">' + Ext.util.Format.fileSize(1024 * e * 1024) + "</span>",
                l = -1,
                d = -1,
                h = 0;
            0 < e && (l = 100 * t / e), 0 < i && (d = 100 * n / i);
            var c = t / 1024,
                u = e / 1024,
                p = n / 1024,
                S = i / 1024,
                f = 99 < l && 2 > u - c,
                m = 99 < d && 2 > S - p;
            if (!0 === f) return String.format('<div class="syno-d-quota-used-limit"> {0} </div>', SYNO.SDS.Drive._T("quota", "reach_personal_quota_limit"));
            if (!0 === m) return String.format('<div class="syno-d-quota-used-limit"> {0} </div>', SYNO.SDS.Drive._T("quota", "reach_share_quota_limit"));
            if (!(0 < e)) {
                var g = String.format(SYNO.SDS.Drive._T("quota", "used"), r);
                return String.format('<div class="syno-d-quota-used"> {0} </div>', g)
            }
            return h = Math.round(l), o.apply({
                showText: String.format(SYNO.SDS.Drive._T("quota", "used_of_quota"), r, a),
                progress: s.fill(h, "", 100 === h)
            })
        },
        getProgressTpl: function() {
            return this.progressBar ? this.progressBar : (this.progressBar = new SYNO.SDS.Utils.ProgressBar({
                barWidth: 200,
                barHeight: 4,
                showValueText: !1
            }), this.progressBar)
        },
        getTaskInfoTpl: function() {
            return this.taskInfoTpl ? this.taskInfoTpl : (this.taskInfoTpl = new Ext.XTemplate('<div class="syno-d-bgtask-info-wrapper">', '<div class="syno-d-bgtask-info-wrapper-top">', '<span class="syno-d-quota-used"> {showText} </span>', "</div>", '<div class="syno-d-bgtask-info-wrapper-bottom">', "{progress}", "</div>", "</div>"), this.taskInfoTpl)
        },
        onWindowShow: function() {
            this.loadData()
        }
    }), Ext.define("SYNO.SDS.Drive.QuotaInfo.Window", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            var t, i = {
                owner: e.owner,
                title: SYNO.SDS.Drive._T("quota", "storage_usage"),
                cls: "syno-d-quota-window",
                height: 545,
                width: 580,
                resizable: !1,
                items: [],
                buttons: [{
                    text: _T("common", "close"),
                    scope: this,
                    handler: this.close
                }],
                listeners: {}
            };
            return 0 === e.data.length ? t = {
                layout: {
                    type: "vbox",
                    align: "center",
                    pack: "center"
                },
                cls: "syno-d-quota-empty-panel",
                items: [{
                    cls: "syno-d-quota-empty-icon"
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-quota-empty-desc",
                    value: SYNO.SDS.Drive._T("quota", "quota_not_support"),
                    width: 360
                }]
            } : (this.gridPanel = new SYNO.SDS.Drive.QuotaInfo.Grid, t = {
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [{
                    xtype: "syno_displayfield",
                    html: SYNO.SDS.Drive._T("quota", "description") + '<div class="quota-spacer"></div><div id="quota-quick-tip"></div>',
                    listeners: {
                        scope: this,
                        afterrender: function(e) {
                            var t = SYNO.SDS.Drive.Utils.isDSM7OrAbove() ? SYNO.SDS.Drive._T("quota", "description_c2_quicktip") : SYNO.SDS.Drive._T("quota", "description_quicktip");
                            new SYNO.SDS.Drive.WhiteQuickTip({
                                tipWidth: 320,
                                tipItems: new Ext.BoxComponent({
                                    html: t
                                }),
                                renderTo: "quota-quick-tip"
                            })
                        }
                    }
                }, this.gridPanel],
                listeners: {
                    scope: this.gridPanel,
                    show: this.gridPanel.onWindowShow
                }
            }), Ext.apply(i, t)
        }
    }), Ext.define("SYNO.SDS.Drive.Client.Panel", {
        extend: "SYNO.ux.GridPanel",
        constructor: function(e) {
            this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
            var t = this.fillConfig(e);
            this.callParent([t]), this.getSelectionModel().on("rowselect", function(e) {
                0 === e.getCount() || this._S("demo_mode") || this.getTopToolbar().getComponent("btnUnlink").enable()
            }, this), this.getSelectionModel().on("rowdeselect", function(e) {
                0 === e.getCount() && this.getTopToolbar().getComponent("btnUnlink").disable()
            }, this), this.getStore().on("beforeload", function() {
                this.getTopToolbar().getComponent("btnUnlink").disable()
            }, this)
        },
        fillConfig: function(e) {
            var t;
            this.pageSize = 50, t = !this._S("is_admin");
            var i = [{
                    id: "client_id",
                    header: SYNO.SDS.Drive._T("clientinfo", "title_id"),
                    dataIndex: "client_id",
                    align: "left",
                    width: 150,
                    sortable: !0
                }, {
                    id: "client_name",
                    header: SYNO.SDS.Drive._T("common", "usrname"),
                    dataIndex: "client_name",
                    align: "left",
                    hidden: t,
                    width: 120,
                    sortable: !0
                }, {
                    id: "client_type",
                    header: SYNO.SDS.Drive._T("clientinfo", "client_type"),
                    dataIndex: "client_type",
                    align: "left",
                    sortable: !0,
                    width: 130,
                    renderer: function(e) {
                        return {
                            drive: SYNO.SDS.Drive._T("clientinfo", "client_drive"),
                            drive_mobile: SYNO.SDS.Drive._T("clientinfo", "client_drive_mobile"),
                            drive_backup: SYNO.SDS.Drive._T("clientinfo", "client_drive"),
                            backup: SYNO.SDS.Drive._T("clientinfo", "client_backup"),
                            ds_cloud: SYNO.SDS.Drive._T("clientinfo", "client_ds_cloud"),
                            cloudstation: SYNO.SDS.Drive._T("clientinfo", "client_cloudstation"),
                            sharesync: SYNO.SDS.Drive._T("clientinfo", "client_sharesync"),
                            serversync: SYNO.SDS.Drive._T("clientinfo", "client_serversync"),
                            unknown: "--"
                        } [e]
                    }
                }, {
                    id: "login_time",
                    header: SYNO.SDS.Drive._T("clientinfo", "title_linktime"),
                    dataIndex: "login_time",
                    align: "left",
                    renderer: function(e, t, i) {
                        return "off_line" === i.get("client_status") ? "" : SYNO.SDS.CSTN.RenderTime(e, t)
                    },
                    width: 130,
                    sortable: !0
                }, {
                    id: "client_status",
                    header: SYNO.SDS.Drive._T("clientinfo", "syncing_status"),
                    dataIndex: "client_status",
                    align: "left",
                    renderer: function(e) {
                        return {
                            off_line: SYNO.SDS.Drive._T("clientinfo", "disconnected"),
                            on_line: '<span class="green-status">' + SYNO.SDS.Drive._T("clientinfo", "connected") + "</span>",
                            syncing: '<span class="blue-status">' + SYNO.SDS.Drive._T("clientinfo", "syncing") + "</span>",
                            wipe: SYNO.SDS.Drive._T("clientinfo", "wiped")
                        } [e]
                    },
                    width: 130,
                    sortable: !0
                }, {
                    id: "client_ip",
                    header: SYNO.SDS.Drive._T("clientinfo", "last_ip"),
                    align: "left",
                    dataIndex: "client_ip",
                    width: 130,
                    sortable: !0
                }, {
                    id: "client_location",
                    header: SYNO.SDS.Drive._T("clientinfo", "client_location"),
                    align: "left",
                    dataIndex: "client_location",
                    width: 130,
                    sortable: !0
                }, {
                    id: "client_session_id",
                    dataIndex: "client_session_id",
                    hidden: !0,
                    sortable: !0
                }, {
                    id: "client_is_relay",
                    dataIndex: "client_is_relay",
                    hidden: !0,
                    sortable: !0
                }],
                n = new Ext.grid.ColumnModel({
                    columns: i
                }),
                s = this.createStore(),
                o = new Ext.Toolbar({
                    defaults: {
                        btnStyle: "grey"
                    },
                    items: [{
                        xtype: "syno_button",
                        disabled: this._S("demo_mode"),
                        tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                        itemId: "btnUnlink",
                        text: SYNO.SDS.Drive._T("clientinfo", "action_unlink"),
                        handler: this.onDisconnect,
                        scope: this
                    }, {
                        xtype: "syno_button",
                        disabled: this._S("demo_mode"),
                        tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                        itemId: "btnRefres",
                        text: SYNO.SDS.Drive._T("btn", "refresh"),
                        handler: this.onRefresh,
                        scope: this
                    }]
                }),
                r = new SYNO.ux.PagingToolbar({
                    store: s,
                    pageSize: this.pageSize,
                    displayInfo: !0,
                    owner: this
                }),
                a = {
                    itemId: "client",
                    tbar: o,
                    view: new SYNO.ux.FleXcroll.grid.GridView,
                    stripeRows: !0,
                    enableColLock: !1,
                    enableHdMenu: !1,
                    enableColumnMove: !1,
                    colModel: n,
                    ds: s,
                    sm: new Ext.grid.RowSelectionModel({
                        singleSelect: !1
                    }),
                    autoExpandColumn: "login_time",
                    loadMask: !0,
                    bbar: r
                };
            return SYNO.LayoutConfig.fill(a), Ext.apply(a, e), a
        },
        createStore: function() {
            var e = ["client_id", "client_name", "login_time", "client_status", "client_session_id", "client_ip", "client_is_relay", "client_type", "client_version", "client_can_wipe", "client_location", "device_uuid"],
                t = new SYNO.API.Store({
                    pruneModifiedRecords: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    proxy: new SYNO.API.Proxy({
                        api: SYNO.SDS.CSTN.WebAPI.Connection.api,
                        version: 1,
                        method: "list",
                        appWindow: this.owner
                    }),
                    reader: new Ext.data.JsonReader({
                        root: "items",
                        totalProperty: "total",
                        idProperty: "id"
                    }, e),
                    sortInfo: {
                        field: "login_time",
                        direction: "DESC"
                    },
                    paramNames: {
                        start: "offset",
                        limit: "limit",
                        sort: "sort_by",
                        dir: "sort_direction"
                    },
                    baseParams: {
                        offset: 0,
                        limit: this.pageSize,
                        sort_by: "login_time",
                        sort_direction: "DESC",
                        view_role: _S("user")
                    },
                    listeners: {
                        scope: this,
                        exception: function(e, t, i, n, s) {
                            s && s.code && this.owner.getMsgBox().alert(SYNO.SDS.Drive._T("app", "app_name"), SYNO.SDS.CSTN.getErrorString(s))
                        }
                    },
                    remoteSort: !0
                });
            return this.addManagedComponent(t), t
        },
        applyDisconnect: function(e) {
            this.owner.setStatusBusy();
            var t = this.getSelectionModel().getSelections(),
                i = [];
            Ext.each(t, function(e) {
                i.push(e.get("client_session_id"))
            }), SYNO.SDS.CSTN.WebAPI.Connection.delete.call(this.owner, i, e, this.ajaxCheckSrvStatusCB, this)
        },
        ajaxCheckSrvStatusCB: function(e, t, i, n) {
            SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
                success: SYNO.SDS.CSTN.cbLoad,
                failure: SYNO.SDS.CSTN.webapiErrHdlMain
            })
        },
        checkSrvStatus: function() {
            this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
        },
        onPageActivate: function() {
            this.checkSrvStatus()
        },
        onActivate: function() {
            this.onPageActivate()
        },
        onDisconnect: function() {
            var e = new SYNO.SDS.Drive.DialogWithCheckBox({
                owner: this.owner,
                chkMsg: SYNO.SDS.Drive._T("warning", "msg_wipedata")
            });
            if (void 0 === this.getSelectionModel().getSelected()) return void e.alert(SYNO.SDS.Drive._T("app", "app_name"), SYNO.SDS.Drive._T("warning", "msg_confirmunlink"));
            var t = this.getSelectionModel().getSelected().data.client_can_wipe;
            e.confirm("", SYNO.SDS.Drive._T("warning", "msg_confirmunlink"), t, function(t) {
                "yes" === t && this.applyDisconnect(e.checked)
            }, this)
        },
        onRefresh: function() {
            this.checkSrvStatus()
        }
    }), Ext.define("SYNO.SDS.Drive.DialogWithCheckBox", {
        extend: "SYNO.SDS.MessageBox",
        checked: !1,
        checkboxEl: null,
        chkMsg: "",
        constructor: function(e) {
            this.chkMsg = e.chkMsg, this.callParent([Ext.apply(e, {
                closable: !1,
                header: !1,
                draggable: !1,
                buttonAlign: "right",
                elements: "body",
                padding: e.draggable ? "0 20px" : "20px 20px 0 20px"
            })])
        },
        doClose: function() {
            this.checked = this.checkboxEl.checked, SYNO.SDS.Drive.DialogWithCheckBox.superclass.doClose.apply(this, arguments)
        },
        onRender: function() {
            this.callParent(arguments);
            var e = Ext.DomHelper.append(this.body.dom.children[0].childNodes[1].childNodes[2], {
                html: "<label></label>"
            });
            this.checkboxEl = new SYNO.ux.Checkbox({
                tag: "span",
                cls: "syno-mb-input",
                boxLabel: this.chkMsg,
                renderTo: e
            })
        },
        showMsg: function(e) {
            this.checkboxEl.show(), e.showChk || this.checkboxEl.hide(), SYNO.SDS.Drive.DialogWithCheckBox.superclass.showMsg.apply(this, arguments)
        },
        getButtons: function(e) {
            this.buttonNames = ["custom", "ok", "yes", "no", "cancel"], SYNO.SDS.isCompatibleMode() && (this.buttonNames = ["custom", "no", "cancel", "ok", "yes"]);
            var t = [];
            return this.fbButtons = {}, Ext.each(this.buttonNames, function(e) {
                t.push(this.fbButtons[e] = new SYNO.ux.Button({
                    btnStyle: "no" === e || "cancel" === e ? "grey" : "default",
                    hideModE: "offset",
                    text: this.buttonText[e],
                    handler: this.handleButton.createDelegate(this, [e])
                }))
            }, this), t
        },
        confirm: function(e, t, i, n, s, o) {
            return this.showMsg({
                title: e,
                msg: t,
                showChk: i,
                buttons: o || Ext.MessageBox.YESNO,
                fn: n,
                scope: s,
                icon: Ext.MessageBox.QUESTION,
                minWidth: this.minWidth
            }), this
        },
        getWrapper: function(e) {
            function t(e, t) {
                return function() {
                    return t.apply(e, arguments)
                }
            }
            return this.msgBoxWrapper || (this.msgBoxWrapper = {
                show: t(this, this.showMsg),
                hide: t(this, this.doClose),
                wait: t(this, this.wait),
                confirm: t(this, this.confirm),
                setIcon: t(this, this.setIconClass),
                updateText: t(this, this.updateText)
            }), this.extra = {}, Ext.apply(this.extra, e || {}), this.extra && this.extra.sinkable && Ext.apply(this, {
                sinkable: !!this.extra.sinkable
            }), this.msgBoxWrapper
        }
    }), Ext.define("SYNO.SDS.Drive.Client.Dialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = this.fillConfig(e);
            this.callParent([t])
        },
        fillConfig: function(e) {
            var t = {
                title: SYNO.SDS.Drive._T("func", "mgr_clientinfo"),
                width: 840,
                height: 600,
                layout: "fit",
                items: this.getPanel(e),
                buttons: [{
                    xtype: "syno_button",
                    text: _T("common", "close"),
                    scope: this,
                    handler: this.close
                }]
            };
            return Ext.apply(t, e)
        },
        getPanel: function(e) {
            return this.panel || (this.panel = new SYNO.SDS.Drive.Client.Panel(e))
        }
    }), Ext.define("SYNO.SDS.Drive.Toolbar", {
        extend: "Ext.Container",
        constructor: function(e) {
            this.owner = e.owner, this.callParent([Ext.apply({
                layout: "border",
                width: 60,
                cls: "syno-d-main-toolbar",
                items: [this.getTopPanel(), this.getBottomPanel()],
                listeners: {
                    scope: this,
                    beforeshow: this.onBeforeShow
                }
            }, e)]), this.onRegEvent()
        },
        onRegEvent: function() {
            var e = this.findAppWindow().getEventMgr();
            this.mon(e, {
                scope: this,
                notification_update: this.onUpdateNotification,
                hide_bgtask_tray: this.onHideBgTask,
                envready: this.onUpdateUserIcon
            }), this.mon(e, "envready", this.onUpdateClientDownloadMenu, this), this.mon(e, "bgtask_update", this.onUpdateBgTask, this, {
                buffer: 100
            }), this.mon(e, "show_bgtask_tray", this.onShowBgTask, this, {
                buffer: 300
            })
        },
        onBeforeShow: Ext.emptyFn,
        getTopPanel: function() {
            var e = "SYNO.SDS.Drive.Application" === _S("standaloneAppName");
            SYNO.SDS.Drive.Utils.isLogined() && SYNO.SDS.JSLoad("SYNO.SDS.AppLauncher.Panel", function() {
                this.appLauncherPanel = new SYNO.SDS.AppLauncher.Panel({
                    width: 380,
                    height: 216,
                    padding: "15px",
                    defaultOffsets: [54, 16],
                    animate: !1
                }), e && SYNO.SDS.Drive.Utils.isLogined() && this.appLauncherPanel.mon(this.appLauncherPanel.launcherView.getStore(), "load", function() {
                    this.hasOtherApp() || (this.items.get("top").get("home").hide(), this.items.get("top").get("home-sep").removeClass("syno-d-toolbar-sep-first"), this.items.get("top").get("home-sep").addClass("syno-d-toolbar-sep-first-hide"))
                }, this, {
                    single: !0
                }), this.appLauncherPanel.hide()
            }, this);
            var t = [{
                xtype: "synodrive_simple_button",
                itemId: "home",
                ctCls: "syno-d-home-icon-ct",
                cls: e ? "syno-d-launcher-icon" : "syno-d-home-icon",
                tooltip: e ? void 0 : SYNO.SDS.Drive._T("drive", "home"),
                handler: function() {
                    if (!SYNO.SDS.Drive.Utils.isLogined() || !e) return void this.onOpenMgr();
                    this.appLauncherPanel && this.hasOtherApp() && (this.appLauncherPanel.isVisible() ? this.appLauncherPanel.hide() : this.appLauncherPanel.show())
                },
                scope: this
            }, {
                itemId: "home-sep",
                xtype: "container",
                ctCls: "syno-d-toolbar-sep-ct",
                cls: "syno-d-toolbar-sep-first"
            }];
            return this.onAddTopItems(t), {
                itemId: "top",
                xtype: "container",
                region: "center",
                width: 40,
                layout: new SYNO.SDS.Drive.Toolbar.TableLayout,
                margins: {
                    left: 10,
                    right: 10,
                    top: 0,
                    bottom: 0
                },
                defaults: {
                    xtype: "synodrive_round_button",
                    hideParent: !0
                },
                cls: "syno-d-main-top-toolbar",
                items: t
            }
        },
        hasOtherApp: function() {
            var e = this.appLauncherPanel.launcherView.getStore(),
                t = e.getTotalCount(),
                i = !1;
            return 1 < t ? i = !0 : 1 === t && e.each(function(e) {
                if ("SYNO.SDS.Office.Application" !== e.get("appname") && "SYNO.SDS.Drive.Application" !== e.get("appname")) return i = !0, !1
            }), i
        },
        onAddTopItems: function(e) {
            SYNO.SDS.Drive.Utils.isAppAuthorized() && "SYNO.SDS.Drive.PublicApplication" !== _S("standaloneAppName") && e.push([this.btn_notification = new SYNO.SDS.Drive.SimpleButton({
                cls: "syno-d-notification-btn",
                itemId: "notification",
                scope: this,
                menuAlign: "tl-tr",
                menu: this.getNotificationMenu()
            }), this.btn_notification_count = new SYNO.SDS.Drive.SimpleButton({
                hidden: !0,
                cls: "syno-d-notification-count",
                itemId: "notification-count",
                scope: this,
                menuAlign: "tl-tr",
                menu: this.getNotificationMenu()
            })]), e.push(this.btn_bgtask_tray = new SYNO.SDS.Drive.SimpleButton({
                hidden: !0,
                cls: "syno-d-bgtask-tray-btn",
                itemId: "bgtask-tray",
                scope: this,
                menuAlign: "tl-tr",
                menu: this.getBackgroundTray()
            }))
        },
        onOpenMgr: function() {
            var e;
            if (this.appLauncherPanel) {
                this.appLauncherPanel.launcherView.getStore().each(function(t) {
                    if ("SYNO.SDS.Drive.Application" === t.get("appname")) return e = t.get("launch_url"), !1
                })
            }
            e || window.location.port && !SYNO.SDS.Drive.WindowHelper.getBaseAppPath() || (e = SYNO.SDS.Drive.WindowHelper.getBaseAppURL()), e ? window.open(e, "_blank") : SYNO.SDS.Drive.Utils.onOpenMgr()
        },
        updateAccountIcon: function(e, t) {
            var i = {
                retina: SYNO.SDS.UIFeatures.test("isRetina"),
                size: "S"
            };
            e && (i._dc = Ext.id(void 0, "photo_"));
            var n = this.getBaseURL({
                api: "SYNO.SynologyDrive.SCIM.Photo",
                version: 1,
                method: "get",
                params: i
            }, !0, this._S("user") + ".png");
            SYNO.SDS.Drive.Utils.updateAccountIcon(this.icon_btn, n), t && (t.nickName || t.userName) && (this.displayName = t.userName, SYNO.SDS.Drive.Define.Info.use_nickname && t.nickName && (this.displayName = t.nickName), this.icon_btn.setText(SYNO.SDS.Drive.Utils.getAccount1stName(this.displayName)))
        },
        onUpdateUserIcon: function() {
            SYNO.SDS.Drive.Utils.isLogined() && (this.findAppWindow().getWebAPI().getUsers({
                params: {
                    user: [_S("user")]
                },
                scope: this,
                callback: function(e, t) {
                    if (e && t && t.users) {
                        var i = t.users[0];
                        this.displayName = i.name, SYNO.SDS.Drive.Define.Info.use_nickname && i.nick && (this.displayName = i.nick), this.icon_btn.setText(SYNO.SDS.Drive.Utils.getAccount1stName(this.displayName))
                    }
                }
            }), this.findAppWindow().getWebAPI().getQuotaInfo({
                scope: this,
                callback: function(e, t) {
                    if (e && t) {
                        var i = this;
                        this.quotaInfoList = [], Ext.each(t.share_list, function(e) {
                            !0 === e.support_per_share_quota && (i.quotaInfoList.push(e), i.isShowMyDrive = i.isShowMyDrive || e.is_home)
                        })
                    }
                }
            }))
        },
        onUpdateClientDownloadMenu: function() {
            _S("is_admin") || SYNO.SDS.Drive.Define.Info.enable_non_admin_user_sync || Ext.getCmp(this.clientDownloadMenuId).setVisible(!1)
        },
        getBottomPanel: function() {
            var e = [];
            return e.push({
                xtype: "container",
                height: 0,
                ctCls: "syno-d-toolbar-sep-ct syno-d-account-sep-ct",
                cls: "syno-d-toolbar-sep"
            }), this.onAddBottomItems(e), {
                itemId: "bottom",
                xtype: "container",
                region: "south",
                height: 100,
                width: 40,
                cls: "syno-d-main-bottom-toolbar",
                layout: new SYNO.SDS.Drive.Toolbar.TableLayout,
                margins: {
                    left: 10,
                    right: 10,
                    top: 0,
                    bottom: 0
                },
                defaults: {
                    hideParent: !0
                },
                items: e,
                listeners: {
                    scope: this,
                    single: !0,
                    afterlayout: this.onBottomAfterLayout
                }
            }
        },
        onAddBottomItems: function(e) {
            e.push(this.onCreateAccountBtn())
        },
        onCreateAccountBtn: function() {
            var e = SYNO.SDS.Drive._T,
                t = SYNO.SDS.Drive.Utils.isLogined(),
                i = SYNO.SDS.Drive.Utils.isAppAuthorized(),
                n = [],
                s = this;
            t && (i && (this.quotaFieldSet = new SYNO.ux.FieldSet({
                xtype: "syno_fieldset",
                cls: "syno-d-quota-fieldset",
                headerCfg: {
                    style: "padding-top: 8px",
                    cls: "x-fieldset-header",
                    html: "name"
                },
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-d-drive-text",
                    itemId: "my-drive",
                    value: e("category", "node"),
                    listeners: {
                        afterrender: function(e) {
                            this.mon(e.getEl(), "click", function() {
                                this.icon_btn.menu.get("storage_usage_win").fireEvent("click"), this.icon_btn.menu.hide()
                            }, this)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-d-quota-used-text",
                    itemId: "quota-used-info",
                    html: "used",
                    listeners: {
                        afterrender: function(e) {
                            this.mon(e.getEl(), "click", function() {
                                this.icon_btn.menu.get("storage_usage_win").fireEvent("click"), this.icon_btn.menu.hide()
                            }, this)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    itemId: "quota-progress-bar",
                    html: this.onQuotaInfoRender(),
                    listeners: {
                        afterrender: function(e) {
                            this.mon(e.getEl(), "click", function() {
                                this.icon_btn.menu.get("storage_usage_win").fireEvent("click"), this.icon_btn.menu.hide()
                            }, this)
                        },
                        scope: this
                    }
                }],
                scope: this.findAppWindow()
            }), n.push(this.quotaFieldSet, "-", {
                text: e("common", "setting"),
                scope: this.findAppWindow(),
                handler: function() {
                    new SYNO.SDS.Drive.Setting.Window({
                        owner: this,
                        module: s
                    }).show()
                }
            }, {
                text: e("quota", "storage_usage"),
                itemId: "storage_usage_win",
                scope: this.findAppWindow(),
                handler: this.onClickStorage
            }, {
                text: SYNO.SDS.Drive._T("func", "mgr_log"),
                scope: this.findAppWindow(),
                handler: this.onClickLog
            }, {
                text: SYNO.SDS.Drive._T("common", "client"),
                menu: new SYNO.ux.Menu({
                    items: [{
                        text: SYNO.SDS.Drive._T("func", "mgr_clientinfo"),
                        scope: this.findAppWindow(),
                        handler: function() {
                            new SYNO.SDS.Drive.Client.Dialog({
                                owner: this,
                                module: s
                            }).show()
                        }
                    }, {
                        id: this.clientDownloadMenuId = Ext.id(),
                        text: e("common", "download_client"),
                        scope: this.findAppWindow(),
                        handler: function() {
                            new SYNO.SDS.Drive.DownloadClient.Window({
                                owner: this,
                                module: s
                            }).show()
                        }
                    }]
                })
            }, "-")), n.push({
                text: _T("common", "alt_help"),
                scope: this.findAppWindow(),
                handler: this.onClickHelp
            }, {
                text: _T("personal_settings", "about"),
                handler: function() {
                    SYNO.SDS.Drive.GetWindow().showAboutWindow()
                }
            }, "-", {
                text: _T("common", "logout"),
                handler: function() {
                    if (SYNO.SDS.Utils.Logout.setConfig({
                            reserveQueryString: !0
                        }), SYNO.SDS.System) SYNO.SDS.System.Logout();
                    else try {
                        SYNO.SDS.Utils.Logout.action()
                    } catch (e) {}
                }
            }));
            var o = new SYNO.SDS.Drive.RoundButton({
                itemId: "account",
                cls: "syno-d-account-icon-m",
                tooltip: _S("user"),
                menuAlign: "bl-br",
                text: SYNO.SDS.Drive.Utils.getAccount1stName(_S("user")),
                menu: t ? new SYNO.ux.Menu({
                    cls: "syno-d-account-menu",
                    ignoreParentClicks: !0,
                    width: 260,
                    defaultOffsets: [8, 0],
                    items: n
                }) : void 0,
                scope: this,
                handler: t ? this.onClickIcon : this.onLogin
            });
            return this.icon_btn = o, this.updateAccountIcon(), o
        },
        onBottomAfterLayout: Ext.emptyFn,
        getTagStore: function() {
            return this.tagStore ? this.tagStore : (this.tagStore = new SYNO.API.Store({
                autoLoad: SYNO.SDS.Drive.Utils.isAppAuthorized(),
                remoteSort: !1,
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.SynologyDrive.Labels",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        beforeload: function(e, t) {
                            var i = e.activeRequest.read;
                            i && Ext.Ajax.abort(i)
                        }
                    }
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    id: "label_id"
                }, [{
                    name: "label_id"
                }, {
                    name: "name"
                }, {
                    name: "color",
                    convert: function(e, t) {
                        return e.substr(1)
                    }
                }, {
                    name: "position"
                }, {
                    name: "category",
                    defaultValue: "label"
                }])
            }), this.findAppWindow().addManagedComponent(this.tagStore), this.tagStore)
        },
        getNotificationMenu: function() {
            return this.notification_menu || (this.notification_menu = new SYNO.SDS.Drive.Notification.Menu({
                defaultOffsets: [8, 0],
                owner: this
            }))
        },
        getBackgroundTray: function() {
            return this.background_tray || (this.background_tray = new SYNO.SDS.Drive.Task.TrayPanel({
                owner: this,
                defaultOffsets: [8, 0],
                appWindow: this.findAppWindow()
            }))
        },
        onClickIcon: function() {
            this.findAppWindow().getWebAPI().getQuotaInfo({
                scope: this,
                callback: function(e, t) {
                    if (e && t) {
                        var i = this;
                        this.quotaInfoList = [], Ext.each(t.share_list, function(e) {
                            !0 === e.support_per_share_quota && (i.quotaInfoList.push(e), i.isShowMyDrive = i.isShowMyDrive || e.is_home)
                        }), this.updateQuotaInfo()
                    }
                }
            }), this.updateQuotaInfo()
        },
        onClickStorage: function() {
            new SYNO.SDS.Drive.QuotaInfo.Window({
                owner: this.findAppWindow(),
                data: this.getLeftPanel().quotaInfoList
            }).show()
        },
        onClickLog: function() {
            new SYNO.SDS.Drive.Log.Dialog({
                owner: this
            }).show()
        },
        onClickHelp: function() {
            var e = "SYNO.SDS.Drive.Application",
                t = this.getHelpParam();
            Ext.isString(t) && t.length > 0 && (e += ":" + t), SYNO.SDS.Drive.Utils.openURL(SYNO.SDS.Drive.Utils.getHelpURL(e), null, !0)
        },
        onUpdateNotification: function(e) {
            this.btn_notification.setVisible(0 === e), this.btn_notification_count.setVisible(0 !== e), 0 !== e && this.btn_notification_count.setText(e > 99 ? "<span class='syno-d-notification-count-over'>99+</span>" : e)
        },
        onUpdateBgTask: function(e, t, i) {
            if (this.btn_bgtask_tray.el.removeClass("syno-d-bgtask-tray-btn"), this.btn_bgtask_tray.el.removeClass("syno-d-bgtask-tray-gif-btn"), this.blAnimate = t, t ? this.btn_bgtask_tray.el.addClass("syno-d-bgtask-tray-gif-btn") : this.btn_bgtask_tray.el.addClass("syno-d-bgtask-tray-btn"), void 0 !== e && this.btn_bgtask_tray.setVisible(e), !1 === e && this.btn_bgtask_tray.menu.hide(), !0 === i) {
                this.btn_bgtask_tray.setVisible(!0);
                var n = this.btn_bgtask_tray.getEl().getXY();
                n[0] += 32, this.btn_bgtask_tray.menu.showAt(n)
            }
        },
        onShowBgTask: function() {
            this.onUpdateBgTask(!0, this.blAnimate, !0)
        },
        onHideBgTask: function() {
            this.onUpdateBgTask(!1, !1, !1)
        },
        onLogin: function() {
            window.location = SYNO.SDS.Drive.Utils.getAppURL()
        },
        onQuotaInfoRender: function() {
            var e = this.getProgressTpl(),
                t = this.getTaskInfoTpl(),
                i = 25;
            if (!this.isShowMyDrive) return "";
            var n = this.quotaInfoList[0].quota,
                s = this.quotaInfoList[0].used;
            return 0 !== n && (i = Math.round(100 * s / n)), t.apply({
                progress: e.fill(i, "", 100 === i)
            })
        },
        getQuotaInfoText: function(e) {
            var t = "<b>" + Ext.util.Format.fileSize(1024 * e.used * 1024) + "</b>",
                i = "<b>" + Ext.util.Format.fileSize(1024 * e.quota * 1024) + "</b>",
                n = String.format(SYNO.SDS.Drive._T("quota", "used_of_quota"), t, i);
            return 0 === e.quota && (n = String.format(SYNO.SDS.Drive._T("quota", "used"), t)), n
        },
        getProgressTpl: function() {
            return this.progressBar ? this.progressBar : (this.progressBar = new SYNO.SDS.Utils.ProgressBar({
                barWidth: 220,
                barHeight: 4,
                showValueText: !1
            }), this.progressBar)
        },
        getTaskInfoTpl: function() {
            return this.taskInfoTpl ? this.taskInfoTpl : (this.taskInfoTpl = new Ext.XTemplate('<div class="syno-d-bgtask-info-wrapper">', '<div class="syno-d-bgtask-info-wrapper-bottom">', "{progress}", "</div>", "</div>"), this.taskInfoTpl)
        },
        updateQuotaInfo: function() {
            if (this.quotaFieldSet.setTitle(this.displayName), this.isShowMyDrive) {
                var e = this.quotaInfoList[0],
                    t = this.getQuotaInfoText(e),
                    i = this.onQuotaInfoRender(),
                    n = e.quota;
                this.quotaFieldSet.get("quota-used-info").update(t), 0 === n ? this.quotaFieldSet.get("quota-progress-bar").doHide() : this.quotaFieldSet.get("quota-progress-bar").update(i)
            } else this.quotaFieldSet.get("my-drive").doHide(), this.quotaFieldSet.get("quota-used-info").doHide(), this.quotaFieldSet.get("quota-progress-bar").doHide();
            this.icon_btn.menu.doLayout()
        }
    }), Ext.define("SYNO.SDS.Drive.Toolbar.TableLayout", {
        extend: "Ext.layout.TableLayout",
        columns: 1,
        getNextCell: function(e) {
            var t = Ext.layout.TableLayout.prototype.getNextCell.call(this, e);
            return t.align = "center", t
        }
    }), SYNO.SDS.Drive.SelMenu = Ext.extend(SYNO.ux.Menu, {
        constructor: function(e) {
            this.owner = e.owner, SYNO.SDS.Drive.SelMenu.superclass.constructor.call(this, Ext.apply({
                cls: "syno-ux-menu syno-d-select-menu"
            }, e))
        },
        render: function(e, t) {
            e || (e = this.findAppWindow().getEl()), SYNO.SDS.Drive.SelMenu.superclass.render.call(this, e, t)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.TreeNodeUI", {
        extend: "Ext.tree.TreeNodeUI",
        getDDHandles: function() {
            return this.anchor.id = Ext.id(), [this.iconNode, this.textNode, this.elNode, this.anchor]
        },
        renderElements: function(e, t, i, n) {
            this.callParent(arguments), this.afterRenderElement(t)
        },
        setText: function(e) {
            this.node.setText(Ext.util.Format.htmlEncode(e)), this.node.attributes.name = e, this.node.setTooltip(e)
        },
        afterRenderElement: function(e) {
            this.elNode.classList.add("syno-d-tree-node"), this.ecNode.setAttribute("draggable", !1), !1 !== e.removeIconNode && this.elNode.removeChild(this.iconNode), !1 !== e.removeEcNode && this.elNode.removeChild(this.ecNode), !0 === e.removeIndentNode && this.elNode.removeChild(this.indentNode)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.TreeRootNodeUI", {
        extend: "SYNO.SDS.Drive.Comp.TreeNodeUI",
        renderElements: function(e, t, i, n) {
            switch (this.callParent(arguments), e.id) {
                case "tag_label":
                    ;
                    Ext.DomHelper.append(e.ui.elNode, '<div class="syno-d-add-category"></div>'), this.elNode.classList.add("syno-d-tree-root-node"), this.elNode.classList.add("syno-d-tree-tag-label", "syno-d-tree-tag-node");
                    break;
                case "category_label":
                    this.elNode.classList.add("syno-d-tree-root-node")
            }
        },
        onDblClick: function(e) {
            e.preventDefault()
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.TreeSubNodeUI", {
        extend: "SYNO.SDS.Drive.Comp.TreeNodeUI",
        renderElements: function(e, t, i, n) {
            this.callParent(arguments), this.elNode.classList.add("syno-d-tree-sub-node")
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.LabelTreeNodeUI", {
        extend: "SYNO.SDS.Drive.Comp.TreeNodeUI",
        getDDHandles: function() {
            var e = this.callParent(arguments);
            return e.push(this.colorNode), e
        },
        renderElements: function(e, t, i, n) {
            this.callParent(arguments), this.elNode.classList.add("syno-d-tree-tag-node");
            var s = String.format('<div id="{0}" class="syno-d-color" style="background-color:#{1}; color:#FFF;"></div>', Ext.id(), t.color);
            Ext.DomHelper.append(this.elNode, s), this.colorNode = this.elNode.childNodes[2]
        },
        setColor: function(e) {
            Ext.fly(this.colorNode).setStyle("background-color", "#" + e);
            var t = this.node.attributes.color;
            this.node.attributes.color = e, this.node.fireEvent("colorchange", this.node, e, t)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.TreeLoader", {
        extend: "SYNO.API.TreeLoader",
        constructor: function(e) {
            var t = {
                listeners: {
                    scope: this,
                    beforeload: this.onBeforeLoad,
                    load: this.onLoad,
                    loadexception: this.onLoadException
                }
            };
            this.category = e.category, SYNO.SDS.Drive.Utils.apply(t, e || {}), this.callParent([t])
        },
        createNode: function(e, t) {
            if (!1 !== this.parseNodeAttr(e, t)) return this.callParent(arguments)
        },
        getNodeId: function(e, t) {
            return String.format("{0}:{1}", e, t)
        },
        parseNodeAttr: function(e, t) {
            if (e.removeIconNode = t.attributes.removeIconNode, e.removeEcNode = t.attributes.removeEcNode, e.qtip = e.name, e.listRO = t.attributes.listRO, e.listNA = t.attributes.listNA, !1 === e.listRO && e.capabilities && !e.capabilities.can_write || !1 === e.listNA && e.capabilities && !e.capabilities.can_write && !e.capabilities.can_preview) return !1
        },
        onBeforeLoad: function(e, t) {
            e.nodeParameter = ""
        },
        onLoad: function(e, t, i) {},
        onLoadException: function(e, t, i) {
            var n = i.responseText;
            try {
                if (n = Ext.decode(n), n.success) return;
                i = n.error
            } catch (e) {}
            SYNO.SDS.Drive.GetWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(i))
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DriveTreeLoader", {
        extend: "SYNO.SDS.Drive.Comp.TreeLoader",
        constructor: function(e) {
            var t = {
                dataroot: ["data", "items"],
                uiProviders: {
                    render: SYNO.SDS.Drive.Comp.TreeSubNodeUI
                },
                baseParams: {
                    path: "/mydrive",
                    sort_by: "name",
                    sort_direction: "asc",
                    filter: {
                        type: ["dir"]
                    }
                }
            };
            Ext.apply(t, SYNO.SDS.Drive.WebAPIDesc.list_files), Ext.apply(t, e || {}), this.callParent([t])
        },
        parseNodeAttr: function(e, t) {
            return !1 !== this.callParent(arguments) && ("dir" === e.type && (e.text = e.name, e.uiProvider = "render", e.id = this.getNodeId(this.category, e.file_id), void(e.removeEcNode = !1)))
        },
        onBeforeLoad: function(e, t) {
            this.callParent(arguments), "node" === t.id ? e.baseParams.path = "/mydrive" : e.baseParams.path = SYNO.SDS.Drive.Utils.getPathId(t.attributes.file_id)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.FolderTreeLoader", {
        extend: "SYNO.SDS.Drive.Comp.TreeLoader",
        constructor: function(e) {
            var t = {
                dataroot: ["data", "items"],
                uiProviders: {
                    render: SYNO.SDS.Drive.Comp.TreeSubNodeUI
                },
                baseParams: {
                    sort_by: "name",
                    sort_direction: "asc"
                }
            };
            Ext.apply(t, SYNO.SDS.Drive.WebAPIDesc.list_team_folders), Ext.apply(t, e || {}), this.callParent([t]), this.subNodeLoader = new SYNO.SDS.Drive.Comp.DriveTreeLoader({
                category: this.category
            })
        },
        parseNodeAttr: function(e, t) {
            if (!1 === this.callParent(arguments)) return !1;
            e.text = e.name, e.uiProvider = "render", e.id = this.getNodeId(this.category, e.file_id), e.removeEcNode = !1, e.loader = this.subNodeLoader
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.SharedTreeLoader", {
        extend: "SYNO.SDS.Drive.Comp.TreeLoader",
        constructor: function(e) {
            var t = {
                dataroot: ["data", "items"],
                uiProviders: {
                    render: SYNO.SDS.Drive.Comp.TreeSubNodeUI
                },
                baseParams: {
                    sort_by: "name",
                    sort_direction: "asc",
                    filter: {
                        type: ["dir"]
                    }
                }
            };
            Ext.apply(t, e || {}), Ext.apply(t, SYNO.SDS.Drive.WebAPIDesc[e.method]), this.callParent([t]), this.subNodeLoader = new SYNO.SDS.Drive.Comp.DriveTreeLoader({
                category: this.category
            })
        },
        parseNodeAttr: function(e, t) {
            if (!1 === this.callParent(arguments)) return !1;
            e.text = e.name, e.uiProvider = "render", e.id = this.getNodeId(this.category, e.file_id), e.removeEcNode = !1, e.loader = this.subNodeLoader
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.LabelTreeLoader", {
        extend: "SYNO.SDS.Drive.Comp.TreeLoader",
        constructor: function(e) {
            var t = {
                dataroot: ["data", "items"],
                uiProviders: {
                    render: SYNO.SDS.Drive.Comp.LabelTreeNodeUI
                }
            };
            Ext.apply(t, SYNO.SDS.Drive.WebAPIDesc.list_labels), Ext.apply(t, e || {}), this.callParent([t])
        },
        parseNodeAttr: function(e, t) {
            this.callParent(arguments), e.draggable = !0, e.leaf = !0, e.uiProvider = "render", e.id = this.getNodeId(this.category, e.label_id), e.text = e.name, e.category = this.category, e.color = e.color.substr(1)
        }
    }), Ext.define("SYNO.SDS.Drive.TreeWindow", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            var t = {
                    width: 480,
                    height: 446,
                    cls: "syno-d-tree-dlg",
                    layout: "fit",
                    items: [this.getPanel(e)],
                    buttonAlign: "left",
                    useStatusBar: !1,
                    buttons: [{
                        xtype: "syno_button",
                        btnStyle: "grey",
                        cls: "syno-d-icon-btn syno-d-create-folder-btn",
                        iconCls: "syno-d-create-folder-icon",
                        hidden: e.hideCreate,
                        scope: this,
                        handler: this.onCreateFolder
                    }, "->"]
                },
                i = [{
                    xtype: "syno_button",
                    btnStyle: "grey",
                    text: _T("common", "cancel"),
                    scope: this,
                    handler: this.onCancel
                }, this.ok_btn = new SYNO.ux.Button({
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "default",
                    disabled: !0,
                    scope: this,
                    handler: this.onApply
                })];
            SYNO.SDS.CSTN.IsDSM7OrAbove() || i.reverse(), t.buttons.push.apply(t.buttons, i);
            var n = Ext.apply(t, e);
            this.callParent([n]), this.mon(this, "afterlayout", this.onAfterLayout, this, {
                single: !0
            })
        },
        onApply: function() {
            var e;
            this.namefield && this.namefield.isDirty() && (e = this.namefield.getValue()), this.fireEvent("choose", this, this.getTree().getSelectionModel().getSelectedNode(), e)
        },
        onCancel: function() {
            this.close()
        },
        onAfterLayout: function() {
            this.center()
        },
        getPanel: function(e) {
            return {
                autoFlexcroll: !1,
                border: !1,
                layout: {
                    type: "vbox",
                    align: "stretch",
                    defaultMargins: {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0
                    }
                },
                items: [{
                    xtype: "syno_formpanel",
                    autoFlexcroll: !1,
                    labelAlign: "top",
                    border: !1,
                    hidden: e.hideForm,
                    items: [this.namefield = new SYNO.ux.TextField({
                        xtype: "syno_textfield",
                        fieldLabel: SYNO.SDS.Drive._T("action", "enter_name"),
                        name: "name",
                        width: 424,
                        value: e.formText
                    })]
                }, this.getTree(e)]
            }
        },
        getTree: function(e) {
            return this.tree || (this.tree = new SYNO.SDS.Drive.TreePanel(e))
        },
        onCreateFolder: function() {
            var e = this.getTree().getSelectionModel(),
                t = e.getSelectedNode();
            if (t) {
                this.findAppWindow().getAction().createNode({
                    file_id: t.attributes.file_id,
                    ntype: "dir"
                }, function(i, n) {
                    if (!i) return void this.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(n));
                    var s = t.id.split(":")[0];
                    t.reload(function() {
                        (t = this.getTree().getNodeByFileId(n.file_id, s)) && (e.select(t), t.ensureVisible())
                    }, this)
                }, this)
            }
        },
        onGoToPath: function(e) {
            this.getTree().onGoToPath(e)
        }
    }), Ext.define("SYNO.SDS.Drive.TreePanel", {
        extend: "SYNO.ux.TreePanel",
        constructor: function(e) {
            this.action = e.action;
            var t = [{
                id: "node",
                text: SYNO.SDS.Drive._T("category", "node"),
                draggable: !1,
                expanded: !0,
                allowDrop: !1,
                removeIconNode: !1,
                listNA: !1,
                loader: this.getDriveLoader()
            }, {
                id: "team_folder",
                text: SYNO.SDS.Drive._T("category", "team_folder"),
                draggable: !1,
                expanded: !0,
                allowDrop: !1,
                hidden: !0,
                removeIconNode: !1,
                listNA: !1,
                loader: this.getFolderLoader()
            }, {
                id: "shared_with_me",
                text: SYNO.SDS.Drive._T("category", "shared_with_me"),
                draggable: !1,
                expanded: !0,
                allowDrop: !1,
                hidden: !0,
                removeIconNode: !1,
                listNA: !1,
                loader: this.getSharedLoader()
            }];
            SYNO.SDS.Drive.Define.Info.is_home || t.shift();
            var i = {
                clearOnLoad: !0,
                flex: 1,
                bodyStyle: "padding: 8px 11px 8px 8px;",
                margins: {
                    top: 0,
                    left: 8,
                    right: 8,
                    bottom: 8
                },
                useGradient: !1,
                border: !0,
                rootVisible: !1,
                useArrows: !0,
                root: new Ext.tree.AsyncTreeNode({
                    id: "root",
                    allowDrag: !1,
                    allowDrop: !1,
                    children: t
                }),
                selModel: new Ext.tree.DefaultSelectionModel({
                    listeners: {
                        scope: this,
                        beforeselect: this.onBeforeSelect,
                        selectionchange: this.onSelectionChange
                    }
                }),
                listeners: {
                    scope: this,
                    beforeclick: this.onBeforeTreeNodeClick
                }
            };
            this.callParent([i])
        },
        onBeforeTreeNodeClick: function(e, t, i) {
            return !this.action || !("team_folder" === e.id || "shared_with_me" === e.id)
        },
        onBeforeSelect: function(e, t, i) {
            if (!this.action) return !0;
            if ("team_folder" === t.id || "shared_with_me" === t.id) {
                var n, s = this.getSelectionModel();
                if (window.event) {
                    var o = new Ext.EventObjectImpl(window.event);
                    switch (o.getKey()) {
                        case o.DOWN:
                            n = s.selectNext;
                            break;
                        case o.UP:
                            n = s.selectPrevious
                    }
                } else {
                    var r = s.getSelectedNode();
                    r && (r === t.previousSibling ? n = s.selectNext : r.parentNode !== t && r !== t.nextSibling || (n = s.selectPrevious))
                }
                return n && n.defer(80, s, [t]), !1
            }
            return this.onBeforeTreeNodeClick(t)
        },
        onSelectionChange: function() {
            this.ownerCt.ownerCt.ok_btn && this.ownerCt.ownerCt.ok_btn.enable()
        },
        getDriveLoader: function() {
            return this.driveLoader ? this.driveLoader : (this.driveLoader = new SYNO.SDS.Drive.Comp.DriveTreeLoader({
                category: "node"
            }), this.driveLoader)
        },
        getFolderLoader: function() {
            return this.folderLoader ? this.folderLoader : (this.folderLoader = new SYNO.SDS.Drive.Comp.FolderTreeLoader({
                category: "team_folder",
                listeners: {
                    load: function(e, t, i) {
                        Ext.isEmpty(t.childNodes) || t.ui.show()
                    }
                }
            }), this.folderLoader)
        },
        getSharedLoader: function() {
            return this.sharedLoader ? this.sharedLoader : (this.sharedLoader = new SYNO.SDS.Drive.Comp.SharedTreeLoader({
                category: "shared_with_me",
                method: "list_shared_with_me",
                listeners: {
                    load: function(e, t, i) {
                        Ext.isEmpty(t.childNodes) || t.ui.show()
                    }
                }
            }), this.sharedLoader)
        },
        getNodeIdFromFileId: function(e, t) {
            return String.format("{0}:{1}", e, t)
        },
        getNodeByFileId: function(e, t) {
            return this.root.findChild("id", this.getNodeIdFromFileId(t, e), !0)
        },
        onGotoDefaultPath: function() {
            var e = this.root.getPath();
            this.getNodeById("node") && (e += "/node", this.selectPath(e))
        },
        onGoToPath: function(e) {
            if (!this.isDestroyed) {
                if (!e || 0 === e.length) return void this.onGotoDefaultPath();
                var t = e[0].id,
                    i = 0,
                    n = this.root.getPath() + "/" + t;
                if (("shared_with_me" === t || "team_folder" === t) && 1 === e.length) return void this.onGotoDefaultPath();
                for (i = 1; i < e.length; ++i) n += "/" + this.getNodeIdFromFileId(t, e[i].id);
                this.selectPath(n, "id", function(e) {
                    e || this.onGotoDefaultPath()
                }.bind(this))
            }
        }
    }), Ext.define("SYNO.SDS.Drive.CopyToWindow", {
        extend: "SYNO.SDS.Drive.TreeWindow",
        constructor: function(e) {
            if (!e.hideForm) {
                var t = SYNO.SDS.Drive.Utils.parseDisplayName(e.formText);
                t !== e.formText && (this.ext = SYNO.SDS.Drive.Utils.getExt(e.formText), e.formText = t)
            }
            this.callParent([e])
        },
        onApply: function() {
            var e;
            this.namefield && this.namefield.isDirty() && (e = this.namefield.getValue().trim(), this.ext && (e += "." + this.ext)), this.fireEvent("choose", this, this.getTree().getSelectionModel().getSelectedNode(), e)
        }
    }), Ext.define("SYNO.SDS.Drive.CreateWindow", {
        extend: "SYNO.SDS.Drive.NodeEditWindow",
        mode: "add",
        constructor: function(e) {
            this.callParent([Ext.apply({
                title: e.title || _T("common", "create"),
                allowBlank: !1
            }, e)])
        },
        getFormPanel: function() {
            return this.formPanel = this.formPanel || new SYNO.ux.FormPanel({
                cls: "syno-d-add-edit-form",
                autoHeight: !0,
                border: !1,
                fieldWidth: 400,
                labelAlign: "top",
                items: [{
                    xtype: "syno_textfield",
                    fieldLabel: SYNO.SDS.Drive._T("common", "name"),
                    itemId: this.nameItemId,
                    name: this.nameItemId,
                    value: this.initName,
                    validator: this.nameValidator.createDelegate(this)
                }]
            }), this.formPanel
        }
    }), Ext.define("SYNO.SDS.Drive.FrameworkImpl", {
        singleton: !0,
        evalName: function(e) {
            return e.split(".").reduce(function(e, t) {
                return e[t]
            }, window)
        },
        applyMixin: function() {
            function e(e, t) {
                function i(e) {
                    return -1 !== ["override", "self", "superclass", "supr"].indexOf(e)
                }
                var s = n(e),
                    o = s.$isClass ? s.prototype : Object.getPrototypeOf(s);
                Ext.iterate(o, function(e, n) {
                    i(e) || (t[e] ? t[e].prototype = n : t[e] = n)
                }, this)
            }
            var t, i = SYNO.SDS.Drive.FrameworkImpl,
                n = i.evalName;
            t = this.$isClass ? this.prototype : this, t.mixins && t.mixins.forEach(function(i) {
                e.call(this, i, t)
            }, this)
        }
    }), Ext.define("SYNO.SDS.Drive.Framework", {
        singleton: !0,
        postDefine: function() {
            SYNO.SDS.Drive.FrameworkImpl.applyMixin.apply(this, arguments)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.PagingToolBar", {
        getPagingToolBar: function(e) {
            if (this.paging) return this.paging;
            var t = e ? e.pageSize : 1e3;
            return this.paging = new SYNO.ux.PagingToolbar({
                store: e,
                pageSize: t,
                displayInfo: !0,
                showRefreshBtn: !0,
                updateInfo: function() {
                    var e = this.store,
                        t = e.getCount(),
                        i = e.getTotalCount();
                    if (e.snapshot && (i -= e.snapshot.getCount() - e.data.getCount()), this.setButtonsVisible(i > t), this.displayItem) {
                        var n = 0 === t ? this.emptyMsg : String.format(this.displayMsg, this.cursor + 1, this.cursor + t, i);
                        this.displayItem.setText(n)
                    }
                }
            }), this.paging
        },
        updatePaginToolBar: function(e) {
            e.infinite ? (this.paging.hide(), this.paging.bindStore(null)) : (this.paging.show(), this.paging.bindStore(e))
        }
    }), Ext.define("SYNO.SDS.Drive.MemberDialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        mixins: ["SYNO.SDS.Drive.Comp.PagingToolBar"],
        constructor: function(e) {
            this.rec = e.rec;
            var t = {
                title: SYNO.SDS.Drive._T("common", "members"),
                width: 500,
                height: 462,
                resizable: !1,
                items: [this.getGridPanel()],
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.Drive._T("common", "close"),
                    btnStyle: "grey",
                    handler: this.onCloseClick,
                    scope: this
                }]
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getGridPanel: function() {
            if (this.grid) return this.grid;
            var e = {
                autoHeight: !1,
                height: 342,
                cls: "syno-d-share-formpanel",
                enableHdMenu: !1,
                view: this.createGridView(),
                store: this.getGridStore(),
                cm: this.createGridCM(),
                bbar: this.getPagingToolBar(this.getGridStore()),
                listeners: {
                    viewready: function(e) {
                        this.view.updateScroller()
                    }
                }
            };
            return this.grid = new SYNO.ux.GridPanel(e), this.grid
        },
        createGridView: function() {
            var e = {
                rowHeight: 29,
                forceFit: !0,
                disableTextSelect: !0,
                deferEmptyText: !1
            };
            return new SYNO.ux.FleXcroll.grid.BufferView(e)
        },
        getGridStore: function() {
            return this.gridStore ? this.gridStore : (this.pageSize = 100, this.gridStore = new SYNO.API.Store({
                autoDestroy: !0,
                autoLoad: !0,
                pageSize: this.pageSize,
                proxy: new SYNO.API.Proxy(SYNO.SDS.Drive.WebAPIDesc.list_team_folders_members),
                baseParams: {
                    team_id: this.rec.get("team_id"),
                    offset: 0,
                    limit: this.pageSize
                },
                reader: new Ext.data.JsonReader({
                    root: "items",
                    fields: [{
                        name: "display_name"
                    }, {
                        name: "name"
                    }, {
                        name: "uid"
                    }, {
                        name: "role"
                    }]
                }),
                listeners: {
                    scope: this,
                    beforeload: this.onBeforeLoad,
                    load: this.onLoad,
                    loadexception: this.onLoadException
                }
            }), this.gridStore)
        },
        createGridCM: function() {
            return new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0,
                    sortable: !1,
                    scope: this
                },
                columns: [{
                    dataIndex: "display_name",
                    width: 240,
                    header: _T("common", "user"),
                    renderer: function(e, t, i, n, s, o) {
                        return '<span class="syno-d-share-user"></span>' + this.defaultRender(e)
                    }
                }, {
                    dataIndex: "role",
                    width: 100,
                    header: _T("share", "permission"),
                    renderer: this.permRender.createDelegate(this)
                }]
            })
        },
        defaultRender: function(e, t, i, n, s, o) {
            var r = Ext.util.Format.htmlEncode(e),
                a = Ext.util.Format.htmlEncode(r);
            return String.format('<span ext:qtip="{0}">{1}</span>', a, r)
        },
        permRender: function(e, t, i, n, s, o) {
            var r;
            switch (e) {
                case "viewer":
                    r = "ro";
                    break;
                case "editor":
                    r = "rw";
                    break;
                default:
                    r = e
            }
            return e = SYNO.SDS.Drive._T("perm", r), this.defaultRender(e)
        },
        onBeforeLoad: function() {
            this.setStatusBusy()
        },
        onLoad: function() {
            this.clearStatusBusy()
        },
        onLoadException: function(e, t, i) {
            this.clearStatusBusy(), SYNO.SDS.Drive.Utils.showErrorMsg(this, i, function() {
                this.close()
            }, this)
        },
        onCloseClick: function() {
            this.close()
        }
    }, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Conflict.Dialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            Ext.apply(this, e || {});
            var t = {
                owner: e.owner,
                title: this.getTitle(),
                cls: "syno-d-conflict-dialog",
                width: 540,
                autoHeight: !0,
                resizable: !1,
                layout: "fit",
                items: [this.getPanel()],
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.Drive._T("common", "cancel"),
                    btnStyle: "grey",
                    handler: this.onCancelClick,
                    scope: this
                }],
                listeners: this.listeners || {}
            };
            this.currIndex = 0, this.conflictAction = {}, this.callParent([t]), this.mon(this, "afterlayout", this.onAfterLayout, this, {
                single: !0
            })
        },
        onAfterLayout: function() {
            this.replaceContainer && this.mon(this.replaceContainer, "containerclick", this.onContainerClick, this), this.skipContainer && this.mon(this.skipContainer, "containerclick", this.onContainerClick, this), this.keepContainer && this.mon(this.keepContainer, "containerclick", this.onContainerClick, this), this.updateCheckbox()
        },
        getTitle: function() {
            var e = SYNO.SDS.Drive._T;
            return String.format(e("action", "mvcp_replace"), e("action", this.action))
        },
        getPanel: function() {
            if (this.panel) return this.panel;
            var e = [{
                xtype: "syno_displayfield",
                cls: "syno-d-conflict-desc",
                value: SYNO.SDS.Drive._T("action", "mvcp_conflict_desc")
            }];
            "restore" !== this.action && e.push(this.getReplaceContainer()), e.push(this.getSkipContainer()), e.push(this.getKeepContainer()), e.push(this.getCheckbox());
            var t = {
                cls: "syno-d-conflict-panel",
                autoFlexcroll: !0,
                defaults: {
                    style: {
                        marginBottom: "8px"
                    }
                },
                items: e
            };
            return this.panel = new SYNO.ux.Panel(t), this.panel
        },
        getReplaceContainer: function() {
            if (this.replaceContainer) return this.replaceContainer;
            var e = SYNO.SDS.Drive._T;
            return this.replaceContainer = new SYNO.SDS.Drive.Conflict.FileInfoContainer({
                action: "replace",
                actionKey: "overwrite",
                title: this.getTitle(),
                desc: e("action", String.format("replace_{0}_desc", this.action)),
                fileInfo: this.conflicts[0].src
            }), this.replaceContainer
        },
        getSkipContainer: function() {
            if (this.skipContainer) return this.skipContainer;
            var e = SYNO.SDS.Drive._T;
            return this.skipContainer = new SYNO.SDS.Drive.Conflict.FileInfoContainer({
                action: "skip",
                title: e("action", "skip"),
                desc: e("action", "skip_desc"),
                fileInfo: this.conflicts[0].dest
            }), this.skipContainer
        },
        getKeepContainer: function() {
            if (this.keepContainer) return this.keepContainer;
            var e = SYNO.SDS.Drive._T;
            return this.keepContainer = new SYNO.SDS.Drive.Conflict.KeepContainer({
                action: "keep",
                actionKey: "autorename",
                title: String.format(e("action", "keep_both_file"), e("action", this.action)),
                desc: e("action", String.format("rename_{0}_desc", this.action)),
                fileInfo: this.conflicts[0].src
            }), this.keepContainer
        },
        getCheckbox: function() {
            return this.checkbox ? this.checkbox : (this.checkbox = new SYNO.ux.Checkbox({
                cls: "syno-d-conflict-checkbox",
                boxLabel: SYNO.SDS.Drive._T("action", "mvcp_apply_all_label"),
                itemId: "apply_all",
                hidden: 1 === this.conflicts.length
            }), this.checkbox)
        },
        updatePanel: function() {
            if (++this.currIndex === this.conflicts.length) return this.doConflictAction();
            this.replaceContainer && this.replaceContainer.updateContent(this.conflicts[this.currIndex].src), this.skipContainer && this.skipContainer.updateContent(this.conflicts[this.currIndex].dest), this.keepContainer && this.keepContainer.updateContent(this.conflicts[this.currIndex].src), this.updateCheckbox(), this.doLayout()
        },
        onContainerClick: function(e) {
            var t = SYNO.SDS.Drive.Utils.getPathId(this.conflicts[this.currIndex].src.file_id);
            if (this.conflictAction[t] = e, this.checkbox.getValue()) {
                for (var i = this.currIndex + 1; i < this.conflicts.length; ++i) t = SYNO.SDS.Drive.Utils.getPathId(this.conflicts[i].src.file_id), this.conflictAction[t] = e;
                return this.doConflictAction()
            }
            this.updatePanel()
        },
        updateCheckbox: function() {
            var e = SYNO.SDS.Drive._T,
                t = this.conflicts.length - this.currIndex - 1;
            0 === t ? this.checkbox.boxlabelEl.update(e("action", "mvcp_apply_all_label")) : this.checkbox.boxlabelEl.update(String.format(e("action", "mvcp_apply_label"), t))
        },
        doConflictAction: function() {
            !1 !== this.fireEvent("doaction", this.conflictAction) && this.close()
        },
        onCancelClick: function() {
            this.close()
        }
    }), Ext.define("SYNO.SDS.Drive.Conflict.Container", {
        extend: "Ext.Container",
        constructor: function(e) {
            var t = [{
                xtype: "syno_displayfield",
                cls: "syno-d-conflict-c-title",
                value: e.title
            }];
            t = t.concat(this.getItems(e));
            var i = {
                cls: "syno-d-conflict-container",
                items: t,
                listeners: {
                    scope: this,
                    afterlayout: {
                        single: !0,
                        fn: this.onAfterLayout
                    }
                }
            };
            this.action = e.action, this.actionKey = e.actionKey || this.action, this.callParent([i])
        },
        onAfterLayout: function() {
            this.mon(this.el, {
                scope: this,
                click: this.onElClick
            })
        },
        onElClick: function() {
            this.fireEvent("containerclick", this.actionKey)
        },
        updateContent: function(e) {
            this.getComponent("info-template").update(e)
        },
        getItems: function(e) {}
    }), Ext.define("SYNO.SDS.Drive.Conflict.FileInfoContainer", {
        extend: "SYNO.SDS.Drive.Conflict.Container",
        getItems: function(e) {
            return [{
                xtype: "syno_displayfield",
                cls: "syno-d-conflict-c-desc",
                value: e.desc
            }, {
                itemId: "info-template",
                border: !1,
                data: e.fileInfo,
                tpl: this.getTemplate()
            }]
        },
        getTemplate: function() {
            return this.infoTpl ? this.infoTpl : (this.infoTpl = new Ext.XTemplate('<div class="syno-d-conflict-c-icon {[this.getExtClass(values)]}"></div>', '<div class="syno-d-conflict-c-fileinfo">', '<div class="filename" ext:qtip="{[SYNO.SDS.Drive.Utils.doubleHtmlEncode(values.name)]}">{[this.getName(values.name)]}</div>', '<div class="path" ext:qtip="{[SYNO.SDS.Drive.Utils.doubleHtmlEncode(values.path)]}">{[this.getPath(values.path)]}</div>', '<div class="size">{[this.getSize(values.size)]}</div>', '<div class="mtime">{[this.getMtime(values.mtime)]}</div>', "</div>", {
                getExtClass: function(e) {
                    var t = "dir" === e.file_type ? "dir" : SYNO.SDS.Drive.Utils.getExt(e.name);
                    return SYNO.SDS.Drive.FileType.getMappingTypeCss(t, 64)
                },
                getName: function(e) {
                    return Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e))
                },
                getPath: function(e) {
                    return String.format("{0}: {1}", SYNO.SDS.Drive._T("common", "path"), Ext.util.Format.htmlEncode(e))
                },
                getSize: function(e) {
                    return String.format("{0}: {1}", SYNO.SDS.Drive._T("file", "size"), Ext.util.Format.fileSize(e))
                },
                getMtime: function(e) {
                    var t = SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * e));
                    return String.format("{0}: {1}", SYNO.SDS.Drive._T("file", "mtime"), t)
                }
            }), this.infoTpl)
        }
    }), Ext.define("SYNO.SDS.Drive.Conflict.KeepContainer", {
        extend: "SYNO.SDS.Drive.Conflict.Container",
        getItems: function(e) {
            return this.desc = e.desc, [{
                itemId: "info-template",
                border: !1,
                data: e.fileInfo,
                tpl: this.getTemplate()
            }]
        },
        getTemplate: function() {
            if (this.infoTpl) return this.infoTpl;
            var e = this.desc;
            return this.infoTpl = new Ext.XTemplate('<div class="syno-d-conflict-c-desc">{[this.getDesc()]}', '<span class="syno-d-conflict-k-name">', '<span class="syno-d-conflict-k-name-head" ext:qtip="{[this.getKeepFileNameQtip(values.renamed)]}">', "{[this.getHeadFileName(values.renamed)]}", "</span>", '<span class="syno-d-conflict-k-name-tail" ext:qtip="{[this.getKeepFileNameQtip(values.renamed)]}">', "{[this.getTailFileName(values.renamed)]}", "</span>", "</span>", "</div>", {
                getDesc: function() {
                    return String.format(e, " ")
                },
                getKeepFileNameQtip: function(e) {
                    return Ext.util.Format.htmlEncode(this.getKeepFileName(e))
                },
                getKeepFileName: function(e) {
                    var t = this.getHeadFileName(e),
                        i = this.getTailFileName(e),
                        n = t + i;
                    return n = n.substr(1, n.length - 2)
                },
                getHeadFileName: function(e) {
                    var t = e.lastIndexOf("("),
                        i = -1 === t ? e : e.substr(0, t - 1);
                    return String.format('"{0}', Ext.util.Format.htmlEncode(i))
                },
                getTailFileName: function(e) {
                    var t = e.lastIndexOf("("),
                        i = Ext.util.Format.htmlEncode(e.substr(t));
                    return String.format('&nbsp;{0}"', i)
                }
            }), this.infoTpl
        }
    }), Ext.ns("SYNO.SDS.Drive"), Ext.define("SYNO.SDS.Drive.PasswordDialog", {
        extend: "SYNO.SDS.Drive.ModalWindow",
        constructor: function(e) {
            this.pendingValidateCallback = {}, this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            var t = new SYNO.SDS.Drive.PasswordDialog.Store({
                    autoDestroy: !0,
                    data: e.files,
                    idProperty: "file_id",
                    fields: [{
                        name: "file_id"
                    }, {
                        name: "name"
                    }, {
                        name: "display_path"
                    }, {
                        name: "file_type"
                    }, {
                        name: "ntype",
                        mapping: "name",
                        convert: function(e, t) {
                            return SYNO.SDS.Drive.Utils.getNtype(e, t.file_type)
                        }
                    }]
                }),
                i = {
                    title: _T("common", "enter_password_to_continue"),
                    width: 638,
                    height: 161 + 45 * Math.min(8, Math.max(3, t.getCount())),
                    buttons: [{
                        xtype: "syno_button",
                        text: SYNO.SDS.Drive._T("common", "close"),
                        scope: this,
                        handler: this.close
                    }, {
                        xtype: "syno_button",
                        btnStyle: "default",
                        text: _T("common", "ok"),
                        scope: this,
                        handler: this.onApply
                    }],
                    layout: "fit",
                    defaults: {
                        border: !1
                    },
                    items: [{
                        xtype: "syno_editorgrid",
                        itemId: "grid",
                        cls: "syno-d-mgr-export-password-grid",
                        store: t,
                        enableHdMenu: !1,
                        clicksToEdit: 1,
                        colModel: new Ext.grid.ColumnModel({
                            defaults: {
                                menuDisabled: !0,
                                resizable: !1
                            },
                            columns: [{
                                width: 300,
                                header: _T("common", "file_name"),
                                dataIndex: "name",
                                renderer: this.renderFileNameColumn
                            }, {
                                width: 198,
                                header: _T("common", "password"),
                                renderer: this.renderPasswordColumn
                            }, {
                                header: _T("common", "action"),
                                renderer: this.renderActionColumn,
                                align: "center",
                                listeners: {
                                    scope: this,
                                    click: this.skip
                                }
                            }]
                        }),
                        sm: new Ext.grid.RowSelectionModel({
                            singleSelect: !0,
                            handleMouseDown: Ext.emptyFn
                        }),
                        listeners: {
                            scope: this,
                            viewready: this.onViewReady
                        },
                        viewConfig: {
                            forceFit: !0,
                            listeners: {
                                scope: this,
                                refresh: function(e) {
                                    var t = e.el.dom;
                                    Array.prototype.forEach.call(t.querySelectorAll("input[data-syno-file-id]"), this.addPasswordListener, this)
                                },
                                rowremoved: function() {
                                    this.setHeight(161 + 45 * Math.min(8, Math.max(3, t.getCount())))
                                }
                            }
                        }
                    }]
                };
            return SYNO.SDS.CSTN.IsDSM7OrAbove() || i.buttons.reverse(), Ext.apply(i, e)
        },
        renderFileNameColumn: function(e, t, i, n, s, o) {
            var r = "";
            switch (i.data.ntype) {
                case "odoc":
                    r = "syno-d-doc-menu-icon";
                    break;
                case "osheet":
                    r = "syno-d-sheet-menu-icon";
                    break;
                case "oslides":
                    r = "syno-d-slide-menu-icon"
            }
            return t.attr += 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(i.data.display_path))) + '"', "<span class=" + r + ">" + Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e)) + "</span>"
        },
        renderPasswordColumn: function(e, t, i, n, s, o) {
            return '<input type="password" placeholder="' + _T("common", "password") + '" size="20" data-syno-file-id="' + i.id + '" data-syno-state="idle">'
        },
        renderActionColumn: function(e, t, i, n, s, o) {
            return '<a data-syno-file-id="' + i.id + '">' + _T("common", "skip") + "</a>"
        },
        onViewReady: function(e) {
            e.view.refresh(), e.view.scroller.dom.fleXcroll.formUpdate()
        },
        addPasswordListener: function(e) {
            var t = this,
                i = !1;
            e.addEventListener("focus", function() {
                e.classList.add("syno-d-mgr-export-password-grid-input-focus")
            }), e.addEventListener("blur", function() {
                e.classList.remove("syno-d-mgr-export-password-grid-input-focus")
            }), e.addEventListener("keypress", function(e) {
                i = !0
            }), e.addEventListener("keyup", function(n) {
                (i || 8 === n.keyCode || 46 === n.keyCode) && (i = !1, t.validatePassword(e, function(e, t) {
                    var i = t.parentElement;
                    e ? (t.itip = "", i.classList.add("syno-d-mgr-export-password-valid"), i.classList.remove("syno-d-mgr-export-password-invalid")) : (t.itip = _T("common", "err_pass"), i.classList.remove("syno-d-mgr-export-password-valid"), i.classList.add("syno-d-mgr-export-password-invalid"))
                }))
            })
        },
        validatePassword: function(e, t) {
            var i = e.getAttribute("data-syno-file-id");
            switch (e.getAttribute("data-syno-state")) {
                case "idle":
                case "pending":
                    e.setAttribute("data-syno-state", "validating");
                    break;
                case "validating":
                    return e.setAttribute("data-syno-state", "pending"), void(this.pendingValidateCallback[i] = t);
                default:
                    return
            }
            SYNO.SDS.Office.GetAction().checkNodePassword({
                file_id: i,
                password: e.value
            }, function(n, s) {
                var o = this;
                switch (e.getAttribute("data-syno-state")) {
                    case "validating":
                        e.setAttribute("data-syno-state", "idle");
                        break;
                    case "pending":
                        return void setTimeout(function() {
                            t = o.pendingValidateCallback[i], delete o.pendingValidateCallback[i], o.validatePassword(e, t)
                        }, 0)
                }
                t && t(n, e)
            }, this)
        },
        addNotDownloadFiles: function(e) {
            this.other_files || (this.other_files = []), this.other_files.push(e)
        },
        onApply: function() {
            var e = {},
                t = !1;
            Ext.each(this.getComponent("grid").view.el.dom.querySelectorAll("input[data-syno-file-id]"), function(i) {
                i.parentElement.classList.contains("syno-d-mgr-export-password-valid") || (t = !0);
                var n = i.value;
                n && !i.parentElement.classList.contains("syno-d-mgr-export-password-invalid") ? e[SYNO.SDS.Drive.Utils.getPathId(i.getAttribute("data-syno-file-id"))] = n : this.addNotDownloadFiles(i.getAttribute("data-syno-file-id"))
            }, this), this.requestDownload(e, this.other_files, t)
        },
        skip: function(e, t, i, n) {
            var s = n.getTarget();
            if (!s) return !1;
            var o = Ext.get(s);
            if (!o) return !1;
            if (!o.is("a")) return !1;
            var r, a, l = t.view.getRow(i),
                d = l.offsetHeight,
                h = [];
            l.addEventListener("transitionend", function(e) {
                "opacity" === e.propertyName && (t.store.removeAt(i), t.view.refresh(), h.forEach(function(e, i) {
                    var n = t.view.getRow(i).querySelector('input[type="password"]');
                    n.value = e[0], e.length > 1 && n.parentElement.classList.add(e[1])
                }))
            }), l.style.left = "360px", l.style.opacity = 0, r = l.querySelector('input[type="password"]'), this.addNotDownloadFiles(r.getAttribute("data-syno-file-id"));
            for (var c = 0, u = t.store.getCount(); c < u; ++c) c !== i && (l = t.view.getRow(c), r = l.querySelector('input[type="password"]'), a = [r.value], r.parentElement.classList.contains("syno-d-mgr-export-password-valid") ? a.push("syno-d-mgr-export-password-valid") : r.parentElement.classList.contains("syno-d-mgr-export-password-invalid") && a.push("syno-d-mgr-export-password-invalid"), h.push(a), c > i && (l.style.top = -d + "px"))
        },
        requestDownload: function(e, t, i) {
            this.fireEvent("apply", this, e, t || [], i)
        }
    }), Ext.define("SYNO.SDS.Drive.PasswordDialog.Store", {
        extend: "Ext.data.JsonStore",
        sortInfo: {
            field: "display_path",
            direction: "ASC"
        },
        createSortFunction: function(e, t) {
            t = t || "ASC";
            var i = "DESC" === t.toUpperCase() ? -1 : 1,
                n = this.fields.get(e).sortType;
            return function(t, s) {
                var o, r, a;
                return "display_path" !== e ? (o = n(t.data[e]), r = n(s.data[e]), a = o > r ? 1 : o < r ? -1 : 0, i * a) : (o = String(t.data[e]), r = String(s.data[e]), a = o.localeCompare(r), i * a)
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.PanelEventHandler", {
        publicEventMap: {
            viewstorechange: "onViewStoreChange",
            storeloaddone: "onLoadStore",
            storebeforeload: "onBeforeNodeLoad",
            storeloadfail: "onExceptionStore",
            enableviewmask: "onEnableMask",
            disableviewmask: "onDisableMask",
            pathchange: "onPathChange"
        },
        onRegEvent: function() {
            var e = this.appWin,
                t = e.getEventMgr();
            this.blRegEvent || (Ext.iterate(this.publicEventMap, function(e) {
                var i = this.publicEventMap[e];
                this.mon(t, e, this[i], this)
            }, this), e.hasClipboard && this.mon(SYNO.SDS.Drive.Mgr.FileClipboard, {
                scope: this,
                set: this.updateCutIcon,
                beforeset: this.removeCutIcons,
                beforeclean: this.removeCutIcons
            }), this.mon(e.el, "mousedown", this.onHandleMouseDown, this), this.mon(e.el, "click", this.onHandleMouseClick, this, {
                buffer: 300
            }), this.blRegEvent = !0, this.mon(this, "beforedestroy", this.unRegEvent, this))
        },
        unRegEvent: function() {
            var e = this.appWin,
                t = e.getEventMgr(),
                i = this.appWin.getViewModeMgr().getViewMode();
            this.blRegEvent && "empty" !== i && (Ext.iterate(this.publicEventMap, function(e) {
                var i = this.publicEventMap[e];
                this.mun(t, e, this[i], this)
            }, this), e.hasClipboard && (this.mun(SYNO.SDS.Drive.Mgr.FileClipboard, "set", this.updateCutIcon, this), this.mun(SYNO.SDS.Drive.Mgr.FileClipboard, "beforeset", this.removeCutIcons, this), this.mun(SYNO.SDS.Drive.Mgr.FileClipboard, "beforeclean", this.removeCutIcons, this)), this.mun(e.el, "mousedown", this.onHandleMouseDown, this), this.mun(e.el, "click", this.onHandleMouseClick, this), this.blRegEvent = !1)
        },
        onEnableMask: function() {
            this.loadMask.enable(), this.getView().trackResetOnLoad = !0
        },
        onDisableMask: function() {
            this.loadMask.disable(), this.getView().trackResetOnLoad = !1
        },
        onLoadStore: function(e, t) {
            var i = this.findAppWindow(),
                n = i.getEventMgr();
            this.loadMask.hide(), this.unmaskView(), this.onFocusRow.defer(80, this), this.updateCutIcon();
            var s = i.getNavigation();
            if (t && 0 === t.length) {
                if ("search" === s.getCategory()) {
                    var o = SYNO.SDS.Drive._T("empty", "search");
                    this.findAppWindow().getDrivePanel().setEmptyText(o)
                }
                e.removeAll()
            }
            if (n.fireEvent("viewpanelload", t, this.itemId), (s.isRootPath() && "node" === s.getLastPath().id || !s.isRootPath()) && s.getLastPath() && !s.getLastPath().skip_load && (!s.getLastPath().perm || !s.getLastPath().display_path)) {
                var r = s.getLastPath().id,
                    a = "node" === r ? "/mydrive" : SYNO.SDS.Drive.Utils.getPathId(r);
                if ("/mydrive" === a) return void this.findAppWindow().getAction().getMyDrive(this.onGetNodeDone, this);
                i.getWebAPI().getNode({
                    params: {
                        path: a
                    },
                    scope: this,
                    callback: this.onGetNodeDone
                })
            }
        },
        onGetNodeDone: function(e, t, i) {
            if (e) {
                var n = this.findAppWindow(),
                    s = n.getNavigation();
                if (i && "/mydrive" === i.path) {
                    if ("node" !== s.getLastPath().id) return
                } else if (t.file_id !== s.getLastPath().id) return;
                s.applyLastPath({
                    perm: t.capabilities,
                    display_path: t.display_path
                }), n.getDrivePanel().onCheckToolbar()
            }
        },
        onBeforeNodeLoad: function(e, t) {
            this.findAppWindow().getEventMgr().fireEvent("beforeviewpanelload", this.itemId);
            var i = this.findAppWindow().getNavigation(),
                n = i.getCategory();
            if (this.isViewMasked() && this.unmaskView(), this.loadMask.show(), "recent" !== n && "search" !== n && "label" !== n) {
                if (!e.sorting) {
                    var s = this.getSortInfo(i.getCategoryText());
                    s && (t.params.sort_by = s.field, t.params.sort_direction = s.direction)
                }
                t.params.sort_by || (t.params.sort_by = "name", t.params.sort_direction = "ASC"), this.updateSortState(e, t.params)
            }
            var o;
            o = "search" === n ? "" : SYNO.SDS.Drive._T("empty", "grid"), this.findAppWindow().getDrivePanel().setEmptyText(o)
        },
        onExceptionStore: function(e) {
            this.loadMask.hide(), this.findAppWindow().getEventMgr().fireEvent("viewpanelfail", e), this.isViewMasked() && this.unmaskView(), this.maskView(SYNO.SDS.Drive.Utils.getErrorStr(e))
        },
        getActiveStore: function() {
            return this.activeStore
        },
        switchStore: function(e, t) {
            var i = !1;
            return this.activeStore !== t && (i = !0), this.activeStore = t, i
        },
        onShowContextMenu: function(e) {
            e.preventDefault();
            var t = this.findAppWindow().getMenu();
            t.setType("menu_context"), t.setOrigin(e.target), t.showAt(e.getXY())
        },
        onDoubleClick: function(e, t, i, n) {
            this.findAppWindow().getAction().openNode()
        },
        getSortInfo: function(e) {
            if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
                var t = this.findAppWindow();
                if (Ext.getClassByName("SYNO.SDS.Drive.MainWindow") && t instanceof SYNO.SDS.Drive.MainWindow) return t.appInstance.getUserSettings("gridsortstates") || {}
            }
        },
        isViewMasked: function() {
            return this.el.isMasked()
        },
        maskView: function(e, t) {
            this.el.mask(e, t)
        },
        unmaskView: function() {
            this.el.unmask()
        },
        setEmptyText: function(e) {
            this.getView().emptyText = e
        },
        updateCutIcon: function(e, t) {
            "recycle" !== this.findAppWindow().getNavigation().getCategory() && this.findAppWindow().hasClipboard && (t = t || SYNO.SDS.Drive.Mgr.FileClipboard.get()) && "cut" === t.action && Ext.each(t.recs, function(e) {
                this.addRemoveCutClass(e, !0)
            }, this)
        },
        removeCutIcons: function() {
            if ("recycle" !== this.findAppWindow().getNavigation().getCategory() && this.findAppWindow().hasClipboard) {
                var e = SYNO.SDS.Drive.Mgr.FileClipboard.get();
                Ext.each(e.recs, function(e) {
                    this.addRemoveCutClass(e, !1)
                }, this)
            }
        },
        getMouseElement: function(e) {
            if (!this.findAppWindow().maskCnt && !this.isViewMasked() && this.getActiveStore().getTotalCount()) {
                var t = e.getTarget();
                if (t) return Ext.fly(t)
            }
        },
        onHandleMouseDown: function(e) {
            if (this.blClickScrollBar = !1, e.within(this.el)) {
                var t = this.getMouseElement(e);
                t && (this.blClickScrollBar = !!t.is(":any(div.vscrollerbar|div.hscrollerbar)"))
            }
        },
        onHandleMouseClick: function(e) {
            if (!this.blClickScrollBar) {
                var t = this.getMouseElement(e);
                if (t && !t.findParent(":any(span.action-text|td.x-grid3-hd|div.x-grid3-row|td.x-grid3-cell|.syno-ux-textfilter|.x-form-trigger|button|input|img|a|div.x-combo-list-item|div.x-menu|td.x-date-active|div.vscrollerbar|div.hscrollerbar|em.syno-d-round-button|div.thumbnail-entry|div.file-wrap|div.snippet-entry)", 15)) {
                    this.getSelectionModel().clearSelections()
                }
            }
        },
        onPathChange: function(e, t, i, n) {
            n || this.onFocusRow()
        },
        onFocusRow: function() {
            var e;
            if (e = this.findAppWindow().getNavigation().getSelection()) {
                var t = this.getActiveStore();
                if (t.loading) return;
                var i = t.indexOfId(e); - 1 !== i && this.focusItem(i)
            }
        },
        getView: function() {},
        addRemoveCutClass: function() {},
        onViewStoreChange: function() {},
        onViewModeChage: function() {},
        updateSortState: function() {}
    }), Ext.define("SYNO.SDS.Drive.Comp.ScrollEventHandler", {
        INFINITE_LOAD_THRESHOLD: 200,
        onAfterBindStore: function(e) {
            this.mun(this, "flexcroll", this.onScroll, this, {
                buffer: 100
            }), this.removeLoading(!1), e && e.infinite && (this.mon(this, "flexcroll", this.onScroll, this, {
                buffer: 100
            }), this.addLoading(), this.onCheckLoadMore(), this.mon(e, "load", this.addLoading, this), this.mon(this, "deactivate", this.removeLoading, this, {
                single: !0
            }))
        },
        onScroll: function() {
            this.onCheckLoadMore()
        },
        onCheckLoadMore: function() {
            if (this.isVisible()) {
                var e = this.getStore();
                if (e && e.infinite) {
                    var t, i;
                    if (this instanceof SYNO.SDS.Drive.Comp.GridPanel) {
                        if (!this.view || !this.view.scroller || !this.view.scroller.dom) return;
                        i = this.view.scroller.dom, t = i.fleXdata
                    } else if (this instanceof SYNO.SDS.Drive.Comp.DataView) {
                        if (!this.el || !this.el.dom) return;
                        i = this.el.dom
                    }
                    if (i && (t = i.fleXdata, i.fleXcroll, t)) {
                        var n = SYNO.SDS.Drive.GetWindow().getViewModeMgr().getViewMode();
                        if ("tile" === n && t.getContentWidth() - (this.getWidth() + t.scrollPosition[0][0]) <= this.INFINITE_LOAD_THRESHOLD || "tile" !== n && t.getContentHeight() - (this.getHeight() + t.scrollPosition[1][0]) <= this.INFINITE_LOAD_THRESHOLD) {
                            if (!e.isloadMore()) return void(e.loadingMore || this.removeLoading(!1));
                            var s = this;
                            e.loadMore(function() {
                                this.view && (this.view.trackResetOnLoad = !1)
                            }, function() {
                                this.updateFleXcroll(), this.view && (this.view.syncFocusEl(0), this.view.trackResetOnLoad = !0)
                            }, s)
                        }
                    }
                }
            }
        },
        addLoading: function() {
            var e = this.getStore();
            e && e.infinite && e.isloadMore() && this.rendered && this.el && this.el.dom && (this.el.hasClass("syno-d-search-loading") || (this.addClass("syno-d-search-loading"), this.updateFleXcroll()))
        },
        removeLoading: function(e) {
            if (this.rendered && this.el && this.el.dom && (this.el.hasClass("syno-d-search-loading") && (this.removeClass("syno-d-search-loading"), this.updateFleXcroll()), !1 !== e)) {
                var t = this.getStore();
                if (!t || !t.infinite) return;
                this.mun(t, "load", this.addLoading, this)
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.KeyEventHandler", {
        delayKeyTime: 100,
        initKeyEvent: function(e) {
            var t = this;
            t.search_key = "", t.mon(t, "afterlayout", function() {
                this.mon(this.el, "keyup", this.onDetectKeyUp, this), this.mon(this.el, "keydown", this.onDetectKeyDown, this), this.mon(this.el, "keypress", this.onDetectKeyPress, this)
            }, t, {
                single: !0
            }), t.mon(t, "beforedestroy", t.unRegKeyEvent, t)
        },
        runKeySearchTask: function() {
            var e = this;
            e.runTask("searchKeyTask", e.searchKey, Ext.isNumber(e.delayKeyTime) ? e.delayKeyTime : 100)
        },
        clearKeyword: function() {
            this.search_key = ""
        },
        searchKey: function() {
            var e = this,
                t = e.search_key;
            this.clearKeyword(), this.searchKeyAndFocus(t, !1)
        },
        searchKeyAndFocus: function(e, t) {
            var i = this.getStore(),
                n = this.getSelectionModel(),
                s = n.getSelected(),
                o = 0,
                r = -1;
            return o = t ? i.indexOf(s) : i.indexOf(s) + 1, o > i.getCount() - 1 && (o = 0), !((r = i.find("name", e, o, !1, !1)) < 0 && (0 !== o && (r = i.find("name", e, 0, !1, !1)), r < 0)) && (this.focusItem(r), !0)
        },
        hasKeyModifiers: function(e) {
            for (var t, i = ["shift", "ctrl", "alt"], n = 0, s = i.length; n < s; ++n)
                if (t = i[n], e[t + "Key"]) return !0;
            return !1
        },
        onDetectKeyUp: function(e) {
            this.blPressEnter && (this.blPressEnter = !1)
        },
        onDetectKeyDown: function(e) {
            if (e.getKey() === Ext.EventObject.ENTER && !this.blPressEnter) return this.blPressEnter = !0, this.clearKeyword(), void this.findAppWindow().getAction().openNode()
        },
        onDetectKeyPress: function(e) {
            var t = this;
            if (!t.isVisible() || t.hasKeyModifiers(e)) return void t.clearKeyword();
            t.search_key = Ext.isString(t.search_key) ? t.search_key : "", t.search_key += String.fromCharCode(e.getCharCode()), t.runKeySearchTask()
        },
        unRegKeyEvent: function() {
            var e = this,
                t = ["searchKeyTask", "clearKeyTask"];
            Ext.each(t, function(e, t, i) {
                this.removeDelayedTask(e)
            }, e)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DropTarget", {
        extend: "Ext.dd.DropTarget",
        constructor: function(e, t) {
            this.callParent(arguments)
        },
        isDropCategory: function(e) {
            switch (e) {
                case "label":
                    return !0;
                default:
                    return !1
            }
        },
        notifyOut: function(e, t, i) {
            this.updateDDText(e, t, i)
        },
        notifyOver: function(e, t, i) {
            this.updateDDText(e, t, i);
            var n = this.getDDIndex(t);
            return this.notifyOverAndDrop(n, e, t, i) ? this.dropAllowed : this.dropNotAllowed
        },
        updateDDText: function(e, t, i) {
            e.getProxy().getGhost().update(this.getDragDropText(i.selections))
        },
        getDragDropText: function(e) {
            var t = e.length;
            if (0 !== t) {
                return "<span class='syno-d-drag-text'>" + SYNO.SDS.Drive.Utils.parseDisplayName(Ext.util.Format.htmlEncode(e[0].data.name)) + "</span>" + (1 < t ? "<span class='syno-d-drag-num'>" + (t > 99 ? "99+" : t) + "</span>" : "")
            }
        },
        getDDTarget: function() {
            return this.ddTarget
        },
        getDDIndex: function(e) {
            return !1
        },
        notifyOverAndDrop: function(e, t, i) {
            return !1
        },
        notifyDrop: function(e, t, i) {
            return !1
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DataView", {
        extend: "SYNO.SDS.Utils.DataView.LazyDataView",
        mixins: ["SYNO.SDS.Drive.Comp.ScrollEventHandler"],
        constructor: function(e) {
            var t = {
                autoScroll: !0,
                trackResetOnLoad: !1,
                disableTextSelect: !0,
                multiSelect: !0,
                enableDragDrop: !1,
                trackOver: !0,
                emptyText: ""
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getTemplateTarget: function() {
            var e = this;
            if (e.el.dom) return e.scrollBar = e.scrollBar || e.el.createChild({
                tag: "div",
                class: "syno-d-dataview-ct",
                style: "display:inline-block;width:100%;"
            }), e.scrollBar
        },
        afterRender: function(e) {
            this.callParent(arguments), this.mun(this.getTemplateTarget(), "click", this.onClick, this), this.on("flexcrollInitDone", function() {
                this.mon(this.el.child(".mcontentwrapper"), "click", this.onClick, this)
            }, this, {
                single: !0
            }), this.getEl().on("click", function(e) {
                this.getEl().focus()
            }, this), this.keys && (this.keymap = new Ext.KeyMap(this.getEl(), this.keys)), this.enableDragDrop && !this.dragZone && (this.dragZone = new SYNO.SDS.Drive.Comp.DataViewDragZone(e, this.dragConfig)), this.enableDragDrop && !this.dropTarget && (this.dropTarget = new SYNO.SDS.Drive.Comp.DataViewDropTarget(e, this.dropConfig))
        },
        onBeforeLoad: function() {
            this.selectedRecIds = this.getSelectedRecords().map(function(e) {
                return e.id
            }), this.callParent(arguments)
        },
        onStoreLoad: function(e, t, i) {
            if (!i || !i.add) {
                if (!Ext.isEmpty(this.selectedRecIds) && this.store) {
                    for (var n = 0, s = this.selectedRecIds.length; n < s; n++) {
                        var o = this.store.indexOfId(this.selectedRecIds[n]); - 1 !== o && this.select(this.all.elements[o], !0, !0)
                    }
                    this.selectedRecIds = null
                }
                this.updateScrollbar(this.trackResetOnLoad), this.trackResetOnLoad = !0, this.fireEvent("afterUpdateScrollbar", this)
            }
        },
        onMouseOver: function(e) {
            this.callParent(arguments);
            var t, i = !1,
                n = !1;
            Ext.dd.DragDropMgr.dragCurrent && Ext.dd.DragDropMgr.dragCurrent.getProxy && (t = Ext.dd.DragDropMgr.dragCurrent.getProxy()), t && t.getGhost() && t.getGhost().isVisible() && (n = !0, Ext.dd.DragDropMgr.dragCurrent.dragData.dataview instanceof SYNO.SDS.Drive.ViewPanel.DataViewPanel && (i = !0));
            var s = e.getTarget(this.itemSelector, this.getTemplateTarget());
            if (s && n) {
                var o = this.indexOf(s);
                if (!this.isSelected(o)) {
                    var r = this.store.getAt(o);
                    !r || i && "dir" !== r.data.ntype || Ext.fly(s).addClass("dragover")
                }
            }
        },
        bindStore: function(e) {
            this.callParent(arguments), this.onAfterBindStore(e)
        },
        onAfterBindStore: Ext.empytFn,
        onMouseOut: function(e) {
            this.callParent(arguments);
            var t = e.getTarget(this.itemSelector, this.getTemplateTarget());
            t && Ext.fly(t).removeClass("dragover")
        },
        clearAllSelections: function() {
            this.clearSelections()
        },
        createTemplate: Ext.emptyFn,
        onLoadItem: function(e) {},
        onUnLoadItem: function(e) {}
    }, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Comp.DataViewDragZone", {
        extend: "Ext.dd.DragZone",
        ddGroup: "DataViewDD",
        proxy: new Ext.dd.StatusProxy({
            animRepair: !1
        }),
        constructor: function(e, t) {
            this.callParent(arguments), this.ddTarget = t.owner, this.scroll = !1, this.ddel = document.createElement("div"), this.ddel.className = "x-grid-dd-wrap"
        },
        onBeforeDrag: function(e, t) {
            var i = SYNO.SDS.Drive.GetWindow().getNavigation(),
                n = i.getCategory();
            return !("recycle" === n || "team_folder" === n && i.isRootPath())
        },
        getDragData: function(e) {
            var t = this.ddTarget.dataview,
                i = e.getTarget(t.itemSelector, t.getTemplateTarget()),
                n = -1;
            if (i && (n = this.ddTarget.dataview.indexOf(i), -1 === n || t.isSelected(n) || e.hasModifier() || t.select(n, !1), -1 !== n && t.isSelected(n) && !e.hasModifier())) return {
                dataview: this.ddTarget,
                ddel: this.ddel,
                index: n,
                selections: this.ddTarget.getSelections()
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DataViewDropTarget", {
        extend: "SYNO.SDS.Drive.Comp.DropTarget",
        constructor: function(e, t) {
            this.callParent(arguments), this.ddTarget = t.owner
        },
        notifyOverAndDrop: function(e, t, i, n) {
            if (-1 === e) return !1;
            var s = this.ddTarget.dataview.getStore().getAt(e);
            if (!s) return !1;
            var o = this.ddTarget.findAppWindow().getNavigation(),
                r = o.getCategory();
            if ("recycle" === r || "shared_with_me" === r && o.isRootPath() || "team_folder" === r && o.isRootPath()) return !1;
            if (n.dataview instanceof SYNO.SDS.Drive.Comp.DataViewPanel) {
                if ("dir" !== s.data.ntype) return !1
            } else if (Ext.isEmpty(n.selections) || !this.isDropCategory(n.selections[0].data.category)) return !1;
            return !0
        },
        notifyDrop: function(e, t, i) {
            var n = this.ddTarget.dataview,
                s = t.getTarget(n.itemSelector, n.getTemplateTarget());
            s && Ext.fly(s).removeClass("dragover");
            var o = this.getDDIndex(t);
            if (!this.notifyOverAndDrop(o, e, t, i) || i.selections[0] === n.getStore().getAt(o)) return !1;
            var r = n.getStore().getAt(o);
            if (!r) return !1;
            var a = this.ddTarget.findAppWindow();
            return i.dataview instanceof SYNO.SDS.Drive.ViewPanel.DataViewPanel ? a.getAction().moveNode({
                to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(r.id),
                to_parent_folder_name: r.get("name")
            }) : a.getAction().changeTagByRec([i.selections[0].data], [], [r]), !0
        },
        getDDIndex: function(e) {
            var t = this.ddTarget.dataview,
                i = e.getTarget(t.itemSelector, t.getTemplateTarget());
            return i ? t.indexOf(i) : -1
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.TileView", {
        extend: "SYNO.SDS.Drive.Comp.DataView",
        constructor: function(e) {
            var t = {
                store: e.store,
                itemSelector: "div.file-wrap",
                tpl: this.createTemplate()
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        createTemplate: function() {
            return new Ext.XTemplate('<tpl for=".">', '<div class="file-wrap" role="option" aria-haspopup="true">', '<div class="syno-d-start-ntype {[this.getClass(values)]}"', " ext:qtip=\"{[this.getFileNameQtip(values.name || '-')]}\"/>", "{[this.getFileName(values.name || '-')]}", "</div>", "</div>", "</tpl>", {
                compiled: !0,
                disableFormats: !0,
                getFileName: function(e) {
                    return Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e))
                },
                getFileNameQtip: function(e) {
                    return SYNO.SDS.Drive.Utils.doubleHtmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e))
                },
                getClass: this.getClass.createDelegate(this)
            })
        },
        getTemplateTarget: function() {
            if (this.el.dom) return this.scrollBar = this.scrollBar || this.el.createChild({
                tag: "div",
                class: "syno-d-dataview-ct",
                style: "display: inline-flex; flex-wrap: wrap; flex-direction: column; height: calc(100% - 12px); margin-top: 8px;"
            }), this.scrollBar
        },
        updateScrollbar: function() {
            this.scrollBar && (this.scrollBar.removeClass("ellipsis"), this.scrollBar.setWidth("auto"), this.scrollBar.setWidth(this.scrollBar.dom.scrollWidth), this.scrollBar.addClass("ellipsis")), this.callParent(arguments)
        },
        onUpdateScrollbar: function(e) {
            var t = this;
            if (t.isVisible()) {
                var i = t.el.dom;
                i && i.fleXcroll ? (e && i.fleXcroll.setScrollPos(0, 0), i.fleXcroll.updateScrollBars(), e || i.fleXcroll.setScrollPos(0, 0, !0)) : i && (fleXenv.fleXcrollMain(i, this.disableTextSelect), i.onfleXcroll = function() {
                    t.isVisible() && t.onUpdateView && t.onUpdateView(), this.fireEvent("flexcroll", this, this.getFleXcrollInfo(t.el.dom))
                }.createDelegate(this), i.fleXcroll && this.fireEvent("flexcrollInitDone")), i = null
            }
        },
        getThumbnailRowNum: function(e) {
            var t = e.getTemplateTarget(),
                i = e.selected.elements[0].getHeight();
            return Math.floor(t.getHeight() / i)
        },
        onKeyUp: function(e) {
            if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
            var t = this;
            e.shiftKey ? t.selectPreItemIn() : t.selectPreItem()
        },
        onKeyDown: function(e) {
            if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
            var t = this;
            e.shiftKey ? t.selectNextItemIn() : t.selectNextItem()
        },
        onKeyRight: function(e) {
            if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
            var t = this,
                i = t.getThumbnailRowNum(t);
            e.shiftKey ? t.selectNextRowItemIn(i) : t.selectNextRowItem(i)
        },
        onKeyLeft: function(e) {
            if (!0 !== this.isNeedToShift()) return void this.selectItem(0);
            var t = this,
                i = t.getThumbnailRowNum(t);
            e.shiftKey ? t.selectPreRowItemIn(i) : t.selectPreRowItem(i)
        },
        getClass: function(e) {
            return String.format("{0}-background-s{1}", SYNO.SDS.Drive.FileType.getMappingType(e.ntype), 16)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.SelectionModel", {
        getSelections: function() {
            return []
        },
        selectRecords: function() {},
        selectRow: function() {},
        clearSelections: function() {}
    }), Ext.define("SYNO.SDS.Drive.Comp.DragDropHandler", {
        MAX_UPLOAD_SIZE: 4294963200,
        initDragDrop: function() {
            this.enterCount = 0, this.mask = this.createMask(), this.mon(this.getMaskTargetEl(), "dragover", this.onDragOverHandler, this), this.mon(this.getMaskTargetEl(), "drop", this.onDropHandler, this), this.mon(Ext.getDoc(), "dragover", this.onDragOverHandler, this), this.mon(Ext.getDoc(), "dragenter", this.onDragEnter, this), this.mon(Ext.getDoc(), "dragleave", this.onDragLeave, this)
        },
        isDragFile: function(e) {
            try {
                if (Ext.isWebKit) {
                    return e.dataTransfer.types && -1 !== e.dataTransfer.types.indexOf("Files")
                }
                if (Ext.isGecko) return e.dataTransfer.types.contains && e.dataTransfer.types.contains("application/x-moz-file") || 0 <= e.dataTransfer.types.indexOf("application/x-moz-file");
                if (Ext.isIE10 || Ext.isModernIE) {
                    var t = !1;
                    return t = Array.isArray(e.dataTransfer.types) ? e.dataTransfer.types && -1 !== e.dataTransfer.types.indexOf("Files") : e.dataTransfer.types && e.dataTransfer.types.contains("Files"), e.dataTransfer.files && t
                }
            } catch (e) {}
            return !1
        },
        isAllowDrop: function(e) {
            if (!this.isDragFile(e.browserEvent)) return !1;
            if (!e.within(this.getMaskTargetEl()) || !e.browserEvent.dataTransfer) return !1;
            var t = this.findAppWindow();
            if (t.allowDrop) return !0;
            var i = t.getNavigation(),
                n = i.getLastPath();
            return !!("node" === i.getCategory() || "recycle" !== i.getCategory() && n && n.perm && n.perm.can_write)
        },
        onDragOverHandler: function(e) {
            e.stopPropagation(), e.preventDefault(), this.isAllowDrop(e) ? (e.browserEvent.dataTransfer.dropEffect = "copy", this.onMask()) : (e.browserEvent.dataTransfer.dropEffect = "none", this.unMask())
        },
        onDropHandler: function(e) {
            if (e.stopPropagation(), e.preventDefault(), !this.isAllowDrop(e)) return e.browserEvent.dataTransfer.dropEffect = "none", void this.unMask();
            var t = e.browserEvent.dataTransfer.files,
                i = e.browserEvent.dataTransfer.items;
            this.enterCount = 0, this.onFileChange(t, i), this.unMask()
        },
        onDragEnter: function(e) {
            this.enterCount++
        },
        onDragLeave: function(e) {
            0 === --this.enterCount && this.unMask()
        },
        createMask: function() {
            var e = '<div class="drag-drop-hint-wrap"><div class="drag-drop-top-hint"></div><div class="drag-drop-bottom-hint">' + SYNO.SDS.Drive._T("upload", "drop_here") + "</div></div>",
                t = this.getMaskTargetEl().createChild({
                    cls: "drag-drop-mask",
                    tag: "div",
                    html: e
                });
            return this.maskCls && t.addClass(this.maskCls), t.setVisibilityMode(Ext.Element.DISPLAY), t.hide(), t
        },
        getMaskTargetEl: function() {
            return this.el
        },
        onMask: function() {
            this.mask.show()
        },
        unMask: function() {
            this.mask.hide()
        },
        onFileChange: function(e, t) {
            var i = this.findAppWindow(),
                n = i.getNavigation();
            this.checkFileCanUpload(e, t).then(function() {
                var s = SYNO.SDS.Drive.Utils.getPathId(n.getLastPathId());
                SYNO.SDS.Drive.TaskFactory.addUploadTasks(i, s, e, t)
            })
        },
        checkFileCanUpload: function(e, t) {
            var i = this.findAppWindow();
            if (0 === e.length) return SYNO.SDS.Drive.Utils.showAlertMsg(i, SYNO.SDS.Drive._T("error", "upload_folder")), Promise.reject();
            for (var n = [], s = 0; s < e.length; ++s) n.push(this.checkCanUpload(e[s], t ? t[s] : void 0));
            return Promise.all(n).then(function() {
                return Promise.resolve()
            }).catch(function(e) {
                return SYNO.SDS.Drive.Utils.showAlertMsg(i, SYNO.SDS.Drive._T("error", e)), Promise.reject()
            })
        },
        checkCanUpload: function(e, t) {
            return Ext.isModernIE && e.size > this.MAX_UPLOAD_SIZE ? Promise.reject("upload_4G_limit") : t || !Ext.isSafari && 4096 !== e.size ? Promise.resolve() : new Promise(function(t, i) {
                var n = new FileReader;
                n.onerror = function(e) {
                    i("upload_folder")
                }, n.onload = function() {
                    t()
                };
                var s = Math.min(e.size, 1024);
                n.readAsArrayBuffer(e.slice(0, s))
            })
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.EmptyPanel", {
        extend: "SYNO.ux.Panel",
        mixins: ["SYNO.SDS.Drive.Comp.SelectionModel", "SYNO.SDS.Drive.Comp.DragDropHandler"],
        constructor: function(e) {
            this.owner = e.owner, this.appWin = this.findAppWindow(), this.callParent([this.fillConfig(e || {})]), this.mon(this, "afterlayout", this.initDragDrop, this, {
                single: !0
            }), this.mon(this, "afterlayout", function(e) {
                this.mon(e.getEl(), "contextmenu", this.onShowContextMenu, this)
            }, this, {
                single: !0
            })
        },
        fillConfig: function(e) {
            var t = {
                bodyCfg: {
                    tabindex: "0"
                },
                cls: "syno-d-empty-panel",
                html: '<div class="syno-d-empty-panel-arrow"></div><div class="syno-d-empty-panel-container"><div class="syno-d-empty-panel-img"></div><div class="syno-d-empty-panel-text"></div></div>'
            };
            return Ext.apply(e, t)
        },
        onUpdateText: function(e, t) {
            this.getText().update(t), "empty" !== e ? (this.getArrow().hide(), this.getImg().addClass("syno-d-empty-panel-err-img")) : this.getImg().removeClass("syno-d-empty-panel-err-img")
        },
        getText: function() {
            return this.emptytext || (this.emptytext = this.el.child("div.syno-d-empty-panel-text"))
        },
        getArrow: function() {
            return this.arrow || (this.arrow = this.el.child("div.syno-d-empty-panel-arrow"))
        },
        getImg: function() {
            return this.img || (this.img = this.el.child("div.syno-d-empty-panel-img"))
        },
        onUpdate: function() {
            var e, t = this.findAppWindow().getNavigation(),
                i = t.getCategory();
            switch (i) {
                case "node":
                case "recent":
                case "starred":
                case "recycle":
                case "shared_with_me":
                case "sharing_to_others":
                case "backup":
                    e = i;
                    break;
                case "team_folder":
                    e = _S("is_admin") ? "team_folder_empty_admin" : "team_folder_empty";
                    break;
                default:
                    e = "tag"
            }
            this.onUpdateText("empty", SYNO.SDS.Drive._T("empty", e)), this.getArrow()["node" === i ? "show" : "hide"]()
        },
        onShowContextMenu: function(e) {
            e.preventDefault();
            var t = this.findAppWindow().getMenu();
            t.setType("menu_context"),
                t.setOrigin(e.target), t.showAt(e.getXY())
        }
    }, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Comp.Navigation", {
        extend: "Ext.Component",
        category: "",
        defaultCategory: ["node", "team_folder", "share_folder", "backup", "shared_with_me", "sharing_to_others", "recent", "starred", "recycle", "search", "label"],
        paths: {
            node: [{
                id: "node",
                text: SYNO.SDS.Drive._T("category", "node")
            }],
            team_folder: [{
                id: "team_folder",
                text: SYNO.SDS.Drive._T("category", "team_folder")
            }],
            share_folder: [{
                id: "share_folder",
                text: SYNO.SDS.Drive._T("category", "share_folder")
            }],
            shared_with_me: [{
                id: "shared_with_me",
                text: SYNO.SDS.Drive._T("category", "shared_with_me")
            }],
            sharing_to_others: [{
                id: "sharing_to_others",
                text: SYNO.SDS.Drive._T("category", "sharing_to_others")
            }],
            backup: [{
                id: "backup",
                text: SYNO.SDS.Drive._T("category", "backup")
            }],
            recent: [{
                id: "recent",
                text: SYNO.SDS.Drive._T("category", "recent")
            }],
            starred: [{
                id: "starred",
                text: SYNO.SDS.Drive._T("category", "starred")
            }],
            recycle: [{
                id: "recycle",
                text: SYNO.SDS.Drive._T("category", "recycle")
            }],
            search: [{
                id: "search",
                text: SYNO.SDS.Drive._T("category", "search")
            }],
            label: [{
                id: "label",
                text: SYNO.SDS.Drive._T("category", "label")
            }]
        },
        constructor: function(e) {
            this.appWindow = e.appWindow, this.callParent(arguments);
            var t = this.findAppWindow().getEventMgr();
            this.mon(t, {
                scope: this,
                setnodetitledone: this.onSetNodeTitleDone,
                deletenodedone: this.onDeleteNodeDone,
                mvcpstart: this.onMVCPStart,
                restorestart: this.onRestoreStart,
                deleteshortcutdone: this.onRemoveStar,
                setnodetagdone: this.onSetTag,
                deletenodepermdone: this.onDeleteNodePerm
            })
        },
        onSetNodeTitleDone: function(e, t, i) {
            e && t && "dir" === t.type && t.file_id === this.getLastPath().id && (this.getLastPath().text = t.name, this.findAppWindow().getEventMgr().fireEvent("currentpathrename", t.name))
        },
        onDeleteNodeDone: function(e, t, i) {
            if (e) {
                var n = this.getLastPath().id;
                i.files.some(function(e) {
                    return n === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e)
                }) && this.popPath()
            }
        },
        onMVCPStart: function(e, t, i) {
            if ("move" === e) {
                var n = this.getLastPath().id;
                t.files.some(function(e) {
                    return n === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e)
                }) && this.findAppWindow().getAction().onGotoPath({
                    path: t.to_parent_folder
                })
            }
        },
        onRestoreStart: function(e, t) {
            var i = this.getLastPath().id;
            e.files.some(function(e) {
                return i === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e.path)
            }) && this.popPath()
        },
        onRemoveStar: function(e, t, i) {
            if (e) {
                var n = this.getLastPath().id;
                i.files.some(function(e) {
                    return n === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e)
                }) && "starred" === this.category && this.popPath()
            }
        },
        onSetTag: function(e, t, i) {
            if (e) {
                var n = this.getLastPath().id;
                if (i.files.some(function(e) {
                        return n === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e)
                    })) {
                    var s = this.category;
                    i.labels.some(function(e) {
                        return "delete" === e.action && e.label_id === s
                    }) && this.popPath()
                }
            }
        },
        onDeleteNodePerm: function(e, t, i) {
            if (e && "shared_with_me" === this.category) {
                var n = this.getLastPath().id;
                i.compound.some(function(e) {
                    return n === SYNO.SDS.Drive.Utils.getFileIdFromPathId(e.path)
                }) && this.popPath()
            }
        },
        initPath: function(e, t) {
            if (-1 !== this.defaultCategory.indexOf(e) && (t = SYNO.SDS.Drive._T("category", e)), SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile) {
                var i = window.getDriveFile() || {};
                this.paths[e] = [{
                    id: "node",
                    text: i.name
                }]
            } else this.paths[e] = [{
                id: e,
                text: t
            }]
        },
        setDefaultCategory: function() {
            this.setCategoryAndPath(SYNO.SDS.Drive.Define.Info.is_home ? "node" : "team_folder")
        },
        setCategory: function(e, t, i, n) {
            if (n || this.category !== e || Ext.isEmpty(this.category) || "search" === this.category) {
                var s = this.findAppWindow(),
                    o = this.category;
                s.getEventMgr().fireEvent("beforecategorychange", e, o), this.initPath(e, t), this.category = e, s.getEventMgr().fireEvent("categorychange", e, SYNO.Util.copy(i), o)
            }
        },
        getCategory: function() {
            return this.category
        },
        getCategoryText: function() {
            return this.isDefaultCategoryExist(this.getCategory()) ? this.getCategory() : "label"
        },
        isDefaultCategoryExist: function(e) {
            return -1 !== this.defaultCategory.indexOf(e)
        },
        isCategoryExist: function(e) {
            return this.paths.hasOwnProperty(e)
        },
        removeCategory: function(e) {
            this.isCategoryExist(e) && (this.paths[e] = null, delete this.paths[e])
        },
        eachCategory: function(e) {
            for (var t in this.paths) this.paths.hasOwnProperty(t) && e(t)
        },
        getPath: function(e) {
            return e = e || this.getCategory(), this.paths[e] || []
        },
        getLastPath: function() {
            var e = this.getPath();
            return e[e.length - 1] || {}
        },
        getLastPathId: function() {
            return this.isRootPath() && "node" === this.category ? SYNO.SDS.Drive.Define.Info.drive_id : this.getLastPath().id
        },
        popPath: function() {
            this.getPath().pop(), this.setPath(this.getPath(), !0)
        },
        applyLastPath: function(e) {
            Ext.apply(this.getLastPath(), e)
        },
        appendPath: function(e) {
            this.getPath().push(e), this.setPath(this.getPath(), !0)
        },
        isPathChanged: function(e) {
            var t = this.getPath();
            if (Ext.isNumber(e) && (!t || t.length !== e + 1)) return !0;
            if (!t || !e || t.length !== e.length) return !0;
            for (var i = 0; i < e.length; i++)
                if (t[i].id !== e[i].id) return !0;
            return !1
        },
        setPath: function(e, t, i) {
            var n = this.getCategory();
            t = t || this.isPathChanged(e), Ext.isNumber(e) ? this.paths[n] = this.paths[this.getCategory()].slice(0, e + 1) : this.paths[n] = e, this.findAppWindow().getEventMgr().fireEvent("pathchange", e, this.paths[n], n, t, i)
        },
        updatePath: function(e, t, i) {
            this.paths[e][t].text = i, this.findAppWindow().getEventMgr().fireEvent("pathchange", null, this.paths[e], e, !1)
        },
        setCategoryAndPath: function(e, t, i, n, s, o) {
            var r = this.findAppWindow().getEventMgr();
            if (Ext.isEmpty(t) || !t[0]) {
                var a = this.getPath(e);
                a || (this.initPath(e, s), a = this.getPath(e)), t = [a[0]]
            } else t[0].id !== e && t.splice(0, 0, this.getPath(e)[0]);
            r.suspendEvents(!0);
            var l = this.isPathChanged(t) || o;
            this.setSelection(n), this.setCategory(e, s, i, o), this.setPath(t, l, i), r.resumeEvents()
        },
        setSelection: function(e) {
            this.selection_id = e
        },
        getSelection: function() {
            return this.selection_id
        },
        isRootPath: function() {
            var e = this.getPath();
            return e && e.length <= 1
        },
        findAppWindow: function() {
            return this.appWindow
        },
        goBack: function() {
            if (!window.history) return void this.setDefaultCategory();
            window.history.back()
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.GridPanel", {
        extend: "SYNO.ux.GridPanel",
        mixins: ["SYNO.SDS.Drive.Comp.SelectionModel", "SYNO.SDS.Drive.Comp.PagingToolBar", "SYNO.SDS.Drive.Comp.PanelEventHandler", "SYNO.SDS.Drive.Comp.ScrollEventHandler", "SYNO.SDS.Drive.Comp.DragDropHandler", "SYNO.SDS.Drive.Comp.KeyEventHandler"],
        cm_lists: {
            full: ["name", "mtime", "owner_name", "size", "labels"],
            nameonly: ["name"],
            nosize: ["name", "mtime", "owner_name"],
            nolabel: ["name", "mtime", "owner_name", "size", "display_path"],
            recent: ["name", "atime", "owner_name", "size", "labels"],
            search: ["name", "mtime", "owner_name", "size", "labels", "display_path"],
            backup: ["name", "mtime", "labels"],
            shared: ["name", "mtime", "owner_name", "size", "permissions"]
        },
        cm_mapping: {
            recycle: "nolabel",
            recent: "recent",
            backup: "nameonly",
            team_folder: "nameonly",
            share_folder: "nosize",
            search: "search",
            sharing_to_others: "shared"
        },
        constructor: function(e) {
            this.module = e.module, this.owner = e.owner, this.mode = e.mode || "grid", this.appWin = this.findAppWindow();
            var t = {
                cls: "detail" === this.mode ? "syno-d-mgr-grid syno-d-mgr-detail" : "syno-d-mgr-grid",
                colModel: this.getGridCM(),
                stateful: !0,
                stateEvents: ["columnresize"],
                selModel: this.getSelModel(),
                minColumnWidth: 50,
                store: this.getActiveStore(),
                enableColumnMove: !1,
                enableColumnResize: !0,
                loadMask: !0,
                monitorWindowResize: !0,
                columnLines: !1,
                stripeRows: !1,
                hideMode: "offsets",
                autoExpandColumn: "name",
                autoExpandMin: 180,
                view: this.getGridView(),
                bbar: this.getPagingToolBar(this.getActiveStore())
            };
            Ext.apply(t, e || {}), this.callParent([t]), this.initKeyEvent()
        },
        updateSortState: function(e, t) {
            var i;
            switch (t.sort_by) {
                case "modified_time":
                    i = "mtime";
                    break;
                case "owner":
                case "user":
                    i = "owner_name";
                    break;
                default:
                    i = t.sort_by
            }
            var n = {
                field: i,
                direction: t.sort_direction || "DESC"
            };
            e.sortInfo = n, this.getView().updateSortIcon(this.getGridCM().findColumnIndex(n.field), e.sortInfo.direction.toUpperCase())
        },
        switchCM: function(e) {
            var t, i = this.getGridCM(),
                n = i.columns,
                s = !1;
            if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) t = SYNO.SDS.Drive.Utils.isAppAuthorized() ? ["name", "mtime", "owner_name"] : ["name", "mtime"];
            else {
                var o = this.getColumnMapping();
                if (!this.findAppWindow().getNavigation().isRootPath()) switch (e) {
                    case "team_folder":
                        o = "full";
                        break;
                    case "share_folder":
                        o = "nolabel";
                        break;
                    case "backup":
                        o = "backup"
                }
                t = this.cm_lists[o]
            }
            return this.headerBtn && this.headerBtn.setVisible(1 < t.length), Ext.each(n, function(i) {
                var n = !1,
                    o = !0; - 1 === t.indexOf(i.dataIndex) && (n = !0, o = !1), "search" === e && "labels" === i.dataIndex && (n = !0), "name" === i.dataIndex && (o = !1), n !== i.hidden && (s = !0, i.hidden = n), i.hideable = o, "labels" !== i.dataIndex && "display_path" !== i.dataIndex && ("recent" === e ? !1 !== i.sortable && (i.sortable = !1, s = !0) : !0 !== i.sortable && (i.sortable = !0, s = !0))
            }, this), s && this.updateColumn(), s
        },
        getColumnMapping: function() {
            var e = this.findAppWindow().getNavigation().getCategory();
            return this.cm_mapping[e] || "full"
        },
        updateColumn: function() {
            if (this.rendered && !1 !== this.applyColumnState && this.isVisible()) {
                var e = this.getGridCM(),
                    t = e.columns,
                    i = this.getColumnState(),
                    n = 0;
                Ext.each(t, function(e, t) {
                    e.hidden || (i && t < i.length ? e.width = i[t].width : "display_path" === e.dataIndex ? e.width = 250 : "name" === e.dataIndex || "labels" === e.dataIndex ? e.width = 200 : "permissions" === e.dataIndex ? e.width = 230 : e.width = 100, n += e.width)
                });
                var s = this.getView(),
                    o = s.cm.getTotalWidth(!1);
                n > o && Ext.each(t, function(e, t) {
                    e.hidden || ("display_path" === e.dataIndex ? e.width = 250 : "name" === e.dataIndex || "labels" === e.dataIndex ? e.width = 200 : e.width = 100)
                }), e.setConfig(t, !0), e.totalWidth = null, this.updateColumnWidth(!1), i && !1 !== this.applyColumnState && this.saveState()
            }
        },
        updateForceFit: function() {
            var e = this.getView(),
                t = this.getGridEl(),
                i = t.getWidth();
            e.forceFit = 700 < i
        },
        updateColumnWidth: function(e) {
            var t = this.getView();
            this.updateForceFit(), t.forceFit ? t.fitColumns(e) : t.autoExpand(e)
        },
        getSelectedElements: function() {
            return this.getSelections().reduce(function(e, t) {
                var i = this.store.indexOfId(t.id);
                return e.push(this.view.getRow(i)), e
            }.bind(this), [])
        },
        getSelections: function() {
            return this.getSelectionModel().getSelections()
        },
        selectRecords: function(e, t) {
            this.getSelectionModel().selectRecords(e, t)
        },
        getActiveAjaxId: function() {
            return this.getActiveStore().proxy.activeRequest.read
        },
        onViewStoreChange: function(e, t, i) {
            var n = !1,
                s = !1;
            n = this.switchCM(e), s = this.switchStore(e, i), (n || s) && (this.reconfigure(this.getActiveStore(), this.getGridCM()), this.updatePaginToolBar(this.getActiveStore()))
        },
        onShowPanel: function() {
            var e = this.findAppWindow().getNavigation();
            this.switchCM(e.getCategory()), this.reconfigure(this.getActiveStore(), this.getGridCM()), this.updatePaginToolBar(this.getActiveStore())
        },
        onActivate: function() {
            this.onRegEvent(), this.updateColumn(), this.updateCutIcon(), this.getActiveStore().getCount() && this.removeClass("syno-d-mgr-empty-grid"), this.updateScrollbar(this.getView().scroller.dom), this.body.focus(100)
        },
        onDeActivate: function() {
            this.unRegEvent()
        },
        getOwnerColumn: function(e) {
            return new Ext.grid.Column(Ext.apply({
                width: 100,
                header: SYNO.SDS.Drive._T("file", "owner"),
                dataIndex: "owner_name",
                renderer: function(e, t, i, n, s, o) {
                    if (SYNO.SDS.Drive.Define.Info.use_nickname && i.data.owner) {
                        var r = i.data.owner.name,
                            a = i.data.owner.nickname;
                        return a && (r += " (" + a + ")"), String.format('<span ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(r)), Ext.util.Format.htmlEncode(e))
                    }
                    return Ext.util.Format.htmlEncode(e)
                }
            }, e || {}))
        },
        getSizeColumn: function(e) {
            return new Ext.grid.Column(Ext.apply({
                width: 100,
                header: SYNO.SDS.Drive._T("file", "size"),
                dataIndex: "size",
                renderer: function(e, t, i, n, s, o) {
                    t.css = "syno-d-size-colume";
                    return "dir" === i.get("ntype") ? "" : Ext.util.Format.fileSize(e)
                }
            }, e || {}))
        },
        getTimeColumn: function(e) {
            return new Ext.grid.Column(Ext.apply({
                width: 100,
                renderer: function(e, t, i, n, s, o) {
                    return SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * e))
                }
            }, e || {}))
        },
        getLabelsColumn: function(e) {
            return new Ext.grid.Column(Ext.apply({
                width: 200,
                header: SYNO.SDS.Drive._T("category", "tag"),
                sortable: !1,
                dataIndex: "labels",
                renderer: function(e, t, i, n, s, o) {
                    var r, a = SYNO.SDS.Drive.GetWindow().getNavigation(),
                        l = a.getCategoryText();
                    "label" === l && (r = a.getCategory()), t.css = "syno-d-tag-colume";
                    var d = "";
                    return Ext.isArray(e) && Ext.each(e, function(e) {
                        if (!(r === e.label_id || e.type && "personal_label" !== e.type)) {
                            var t = Ext.util.Format.htmlEncode(e.name);
                            d += String.format('<span class="syno-d-tag" style="background-color:#{0};color:#{1};{2}" ext:qtip="{3}">{4}</span>', e.color, SYNO.SDS.Drive.Define.TagTextColor[e.color], Ext.isChrome || 1 !== t.length ? "" : "min-width:13px", Ext.util.Format.htmlEncode(t), t)
                        }
                    }), "" === d ? "-" : d
                }
            }, e || {}))
        },
        getPermissionsColumn: function(e) {
            return new Ext.grid.Column(Ext.apply({
                width: 230,
                header: SYNO.SDS.Drive._T("share", "permission"),
                sortable: !1,
                dataIndex: "permissions",
                renderer: function(e, t, i) {
                    t.css = "syno-d-tag-colume";
                    var n = "",
                        s = i.data.shared_with;
                    Ext.each(s, function(e) {
                        if ("user" === e.type || "group" === e.type) return n += String.format('<span class="syno-d-tag syno-d-tag-shared" ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(SYNO.SDS.Drive._T("share", "Invitee")), SYNO.SDS.Drive._T("share", "Invitee")), !1
                    }), Ext.each(s, function(e) {
                        if ("internal" === e.type) return n += String.format('<span class="syno-d-tag syno-d-tag-shared" ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(SYNO.SDS.Drive._T("share", "app_share")), SYNO.SDS.Drive._T("share", "app_share")), !1
                    });
                    var o = !1;
                    return Ext.each(s, function(e) {
                        if ("public" === e.type) return n += String.format('<span class="syno-d-tag syno-d-tag-shared" ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(SYNO.SDS.Drive._T("share", "public_share")), SYNO.SDS.Drive._T("share", "public_share")), o = !0, !1
                    }), i.data.adv_shared && !o && (n += String.format('<span class="syno-d-tag syno-d-tag-shared" ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(SYNO.SDS.Drive._T("share", "advanced_share_type")), SYNO.SDS.Drive._T("share", "advanced_share_type"))), "" === n ? "-" : n
                }
            }, e || {}))
        },
        reconfigure: function(e, t) {
            e.reconfiguring = !0, this.updateColumn(), this.callParent(arguments), this.onAfterBindStore(e), e.reconfiguring = !1
        },
        focusItem: function(e) {
            this.getSelectionModel().selectRow(e);
            var t = this.getView();
            this.findAppWindow().modalWin.length ? t.syncFocusEl(t.ensureVisible(e, 0, !1)) : t.focusRow(e)
        },
        onUpdateScrollbar: function(e) {
            this.getView().updateScroller(e)
        },
        onAfterBindStore: Ext.empytFn,
        updatePaginToolBar: Ext.empytFn,
        getActiveStore: function() {},
        getGridView: function() {},
        getGridCM: function() {},
        getNameColumn: function() {},
        getSelModel: function() {
            return new Ext.grid.RowSelectionModel({})
        },
        getColumnState: Ext.emptyFn,
        saveState: function(e) {}
    }, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Comp.NameColumn", {
        extend: "Ext.grid.Column",
        id: "name",
        constructor: function(e) {
            this.appWindow = e.appWindow, this.iconSize = e.iconSize || 16, this.showStar = e.showStar, this.callParent(arguments)
        },
        renderer: function(e, t, i, n, s, o) {
            var r = "",
                a = this.appWindow.getNavigation().getCategory(),
                l = Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e)),
                d = "",
                h = !1,
                c = 0;
            return SYNO.SDS.Drive.WindowHelper.isPublicShare() || (d = this.getSharingNames(a, i.data.shared_with, i.data.adv_shared)), d && (h = !0), !1 === this.showStar || SYNO.SDS.Drive.WindowHelper.isPublicShare() || (r += this.getStarIcon(a, i)), r += this.getFileTypeIcon(i), h && c++, i.data.encrypted && c++, r += this.getTitle(l, c), h && (r += this.getSharingIndicator(d)), i.data.encrypted && (r += this.getEncryptIndicator()), r
        },
        getSharingNames: function(e, t, i) {
            var n = [];
            return Ext.each(t, function(e) {
                switch (e.type) {
                    case "internal":
                        n.push(SYNO.SDS.Drive._T("share", "app_share"));
                        break;
                    case "public":
                        n.push(SYNO.SDS.Drive._T("share", "public_share"));
                        break;
                    default:
                        n.push(e.display_name)
                }
            }), i && n.push(SYNO.SDS.Drive._T("share", "protection_share")), n.join(", ")
        },
        getTitle: function(e, t) {
            return String.format('<span ext:qtip="{0}" class="syno-d-start-title" style="max-width:calc(100% - {1}px);">{2}</span>', Ext.util.Format.htmlEncode(e), 72 + 24 * t, e)
        },
        getFileTypeIcon: function(e) {
            return String.format('<span class="{0}"></span>', SYNO.SDS.Drive.FileType.getMappingTypeCss(e.data.ntype, this.iconSize))
        },
        getStarIcon: function(e, t) {
            var i = this.appWindow.getNavigation();
            return "search" === e && !t.get("recycle") || "recycle" !== e && "search" !== e && ("team_folder" !== e || !i.isRootPath()) ? String.format('<span class="{0}"></span>', t.get("starred") ? "syno-d-start-icon syno-d-start-icon-check" : "syno-d-start-icon") : ""
        },
        getSharingIndicator: function(e) {
            return String.format('<span ext:qtip="{0}" class="syno-d-shard-icon"></span>', SYNO.SDS.Drive.Utils.doubleHtmlEncode(e))
        },
        getEncryptIndicator: function() {
            return String.format('<span class="syno-d-encrypt-icon"></span>')
        },
        processEvent: function(e, t, i, n, s) {
            var o = Ext.fly(t.getTarget());
            if ("click" === e && o.is("span.syno-d-start-icon")) {
                var r = i.store.getAt(n),
                    a = r.get("starred");
                r.data.starred = !a, r.commit(), this.fireEvent("change", this, i, r, a, n, s, t)
            }
            this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DetailNameColumn", {
        extend: "SYNO.SDS.Drive.Comp.NameColumn",
        constructor: function(e) {
            var t = {
                iconSize: 24
            };
            Ext.apply(t, e || {}), this.callParent([t])
        },
        getTitle: function(e, t) {
            return String.format('<span ext:qtip="{0}" class="syno-d-start-title" style="max-width:calc(100% - {1}px);">{2}</span>', Ext.util.Format.htmlEncode(e), 72 + 24 * (t + 1), e)
        },
        getFileTypeIcon: function(e) {
            if (!SYNO.SDS.Drive.FileType.hasThumbnail(e.data.ntype)) return this.callParent(arguments);
            var t = this.appWindow.getViewModeMgr().getViewMode();
            if ("empty" !== t && "detail" !== t) return "";
            var i = SYNO.SDS.Drive.FileType.getMappingTypeCss(e.data.ntype, 24),
                n = String.format("detail_{0}", SYNO.Util.Base64.encode(e.data.file_id.toString())),
                s = this.getThumbImg(e.data),
                o = String.format('<div class="syno-d-img-container {0}"><img id="{1}" class="syno-d-start-ntype syno-d-hidden syno-d-def-icon" data-type="{2}" data-thumb="{3}" src="" draggable="false"></div>', i, n, Ext.util.Format.htmlEncode(e.data.ntype), s);
            return this.appWindow.getImageQueue().addImage({
                id: n,
                url: s,
                listeners: {
                    load: this.onImageLoad.createDelegate(this)
                }
            }), o
        },
        getThumbImg: function(e) {
            if (!SYNO.SDS.Drive.FileType.hasThumbnail(e.ntype)) return "";
            if (e.thumbnail) return e.thumbnail;
            var t = Ext.apply({
                params: {
                    path: SYNO.SDS.Drive.Utils.getPathId(e.file_id),
                    size: "small",
                    version_id: e.version_id
                }
            }, SYNO.SDS.Drive.WebAPIDesc.get_thumbnail);
            return SYNO.API.GetBaseURL(t)
        },
        onImageLoad: function(e) {
            e.naturalWidth >= 32 && e.naturalHeight >= 32 && e.classList.remove("syno-d-def-icon"), e.classList.remove("syno-d-hidden"), e.parentNode.className = "syno-d-img-container"
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.GridView", {
        extend: "SYNO.ux.FleXcroll.grid.BufferView",
        afterRenderUI: function() {
            this.callParent(arguments), this.autoFlexcroll && this.grid.mon(this, "flexcroll", function() {
                this.fireEvent.apply(this, ["flexcroll"].concat(Array.prototype.slice.call(arguments, 0)))
            }, this.grid)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.PathBar", {
        extend: "Ext.BoxComponent",
        cls: "syno-d-pathtoolbar",
        activeButton: null,
        scrollRepeatInterval: 400,
        scrollDuration: .35,
        buttonWidthSet: !1,
        allowDomMove: !1,
        autoScroll: !1,
        items: [],
        onUpdateBtns: function(e) {
            for (var t = Math.max(this.items.length, e.length), i = e.length - 1, n = 0; n < t; n++)
                if (n < this.items.length && n < e.length) this.updateButton({
                    itemId: n,
                    text: e[n].text,
                    tooltip: e[n].tooltip
                }, n === i);
                else {
                    if (!(n < e.length)) {
                        this.removeButtons(n, t);
                        break
                    }
                    this.addButton({
                        itemId: n,
                        text: e[n].text,
                        tooltip: e[n].tooltip
                    }, 0 === n, n === i)
                } this.setActiveButton(this.items[this.items.length - 1]), !1 === this.fireEvent("beforeshowarrow") ? this.activeButton.removeClass(this.activeButton.arrowCls) : this.activeButton.addClass(this.activeButton.arrowCls)
        },
        onRender: function() {
            this.callParent(arguments), this.mon(this, "resize", this.delegateUpdates, this), this.items = [];
            var e = Ext.get(this.el);
            this.stripWrap = e.createChild({
                cls: "syno-d-pathbuttons-strip-wrap",
                cn: {
                    tag: "ul",
                    cls: "syno-d-pathbuttons-strip"
                }
            }), this.stripSpacer = e.createChild({
                cls: "syno-d-pathbuttons-strip-spacer"
            }), this.strip = new Ext.Element(this.stripWrap.dom.firstChild), this.edge = this.strip.createChild({
                tag: "li",
                cls: "syno-d-pathbuttons-edge"
            }), this.strip.createChild({
                cls: "x-clear"
            })
        },
        addButton: function(e, t, i) {
            var n = this.strip.createChild({
                    tag: "li"
                }, this.edge),
                s = new SYNO.SDS.Drive.Comp.PathButton(this, n, e, t, i);
            return this.items.push(s), this.buttonWidthSet || (this.lastButtonWidth = s.container.getWidth()), this.addManagedComponent(s), s
        },
        updateButton: function(e, t) {
            this.items[e.itemId].updateButton(e, t)
        },
        removeButtons: function(e, t) {
            for (var i, n, s = e; s < t; s++) n = this.items[s], i = document.getElementById(n.container.id), this.removeManagedComponent(n), n.purgeListeners(), n.destroy(), i.parentNode.removeChild(i);
            var o = [];
            for (s = 0; s < e; s++) o.push(this.items[s]);
            this.items = o, this.delegateUpdates()
        },
        setActiveButton: function(e) {
            this.activeButton = e, this.delegateUpdates()
        },
        delegateUpdates: function() {
            this.rendered && this.onAutoScroll()
        },
        onAutoScroll: function() {
            var e = this.items.length,
                t = this.el.dom.clientWidth,
                i = this.stripWrap,
                n = i.dom.offsetWidth,
                s = this.getScrollPos(),
                o = this.edge.getOffsetsTo(this.stripWrap)[0] + s;
            e < 1 || n < 40 || (i.setWidth(t), o <= t || 1 === this.items.length ? (i.dom.scrollLeft = 0, this.el.removeClass("syno-d-pathbuttons-selection-btn-displayed"), this.getMenuBtn().hide()) : (this.el.addClass("syno-d-pathbuttons-selection-btn-displayed"), t -= i.getMargins("lr"), i.setWidth(t > 40 ? t : 40), this.getMenuBtn().show(), this.updateScrollandSelMenu()))
        },
        getMenu: function() {
            return this.selMenu ? this.selMenu : this.selMenu = new SYNO.ux.Menu({
                items: [],
                listeners: {
                    scope: this,
                    click: function(e, t) {
                        this.fireEvent("pathbarclick", this, t.itemId, !1, null)
                    }
                }
            })
        },
        getMenuBtn: function() {
            if (this.menuBtn) return this.menuBtn;
            var e = this.el.dom.offsetHeight;
            return this.menuBtn = new Ext.Button({
                template: new Ext.Template('<em class="{2}" unselectable="on"><button type="{0}"></button><span class="syno-d-pathbutton-right"></span></em>').compile(),
                cls: "syno-d-pathbuttons-selection-btn",
                renderTo: this.el,
                height: e,
                text: "...",
                menu: this.getMenu()
            })
        },
        destory: function() {
            this.menuBtn && (this.menuBtn.purgeListeners(), this.menuBtn.destroy(), this.menuBtn = null), this.callParent(arguments)
        },
        getScrollPos: function() {
            return parseInt(this.stripWrap.dom.scrollLeft, 10) || 0
        },
        updateScrollandSelMenu: function() {
            for (var e = this.items.length, t = e - 1, i = 0, n = this.stripWrap.getWidth(), s = t; s >= 0 && !((i += this.items[s].el.getWidth()) + 87 > n); s--);
            s === t && (s -= 1), this.selMenu.removeAll();
            for (var o = s; o >= 0; o--) this.selMenu.addItem({
                itemId: String.format("{0}", o),
                htmlEncode: !1,
                text: this.items[o].text
            });
            var r = this.items[s + 1],
                a = this.stripWrap.dom.scrollLeft,
                l = r.el.getOffsetsTo(this.stripWrap)[0] + a;
            this.stripWrap.scrollTo("left", l)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.PathButton", {
        extend: "Ext.Button",
        firstBtnCls: "syno-d-pathbutton-first-btn",
        lastBtnCls: "syno-d-pathbutton-last-btn",
        arrowCls: "syno-d-pathbutton-arrow",
        constructor: function(e, t, i, n, s) {
            this.panel = e;
            var o = n ? this.firstBtnCls : "",
                r = s ? this.lastBtnCls : "",
                a = Ext.apply({
                    renderTo: t,
                    clickEvent: "mousedown",
                    tabIndex: -1,
                    listeners: {
                        click: {
                            fn: this._onClickButton,
                            scope: this
                        }
                    },
                    template: new Ext.Template('<table cellspacing="0" class="x-btn ' + o + " " + r + ' {3}"><tbody><tr>', '<td class="syno-d-pathbutton-left"></td>', '<td class="syno-d-pathbutton-center"><em class="{5}" unselectable="on">', '<button class="x-btn-text {2}" type="{1}" style="height:18px;">{0}</button>', "</em></td>", '<td class="syno-d-pathbutton-right"></td>', "</tr></tbody></table>")
                }, i);
            a.text && (a.text = Ext.util.Format.htmlEncode(a.text)), a.tooltip && (a.tooltip = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(a.tooltip))), this.callParent([a])
        },
        updateButton: function(e, t) {
            e.text && this.setText(Ext.util.Format.htmlEncode(e.text)), e.tooltip && this.setTooltip(Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.tooltip))), t ? this.addClass(this.lastBtnCls) : this.removeClass(this.lastBtnCls)
        },
        _onClickButton: function() {
            this.panel.fireEvent("pathbarclick", this.panel, this.itemId, this.el.hasClass(this.lastBtnCls), this)
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.Path", {
        extend: "SYNO.SDS.Drive.Comp.PathBar",
        constructor: function(e) {
            this.appWin = e.appWin, this.callParent(arguments), this.onRegEvent()
        },
        onRegEvent: function() {
            var e = this.findAppWindow().getEventMgr();
            this.mon(e, {
                scope: this,
                search: this.onSearch,
                categorychange: this.onChange,
                pathchange: this.onChange,
                currentpathrename: this.onChange
            })
        },
        onChange: function() {
            this.onUpdateBtns(this.findAppWindow().getNavigation().getPath())
        },
        findAppWindow: function() {
            return this.appWin
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.ThumbnailView", {
        extend: "SYNO.SDS.Drive.Comp.DataView",
        defaultIconSize: 48,
        constructor: function(e) {
            var t = {
                store: e.store,
                itemSelector: "div.thumbnail-entry",
                tpl: this.createTemplate()
            };
            Ext.apply(t, e || {}), this.callParent([t]), this.onRegEvent()
        },
        onRegEvent: function() {
            this.mon(this, {
                scope: this,
                resize: this.onViewResize
            })
        },
        createTemplate: function() {
            var e = this.defaultIconSize;
            return new Ext.XTemplate('<tpl for=".">', '<div class="thumbnail-entry">', '<div class="thumbnail-wrapper {[this.getLoadingClass(values)]}">', '<div class="image-container syno-d-ori-icon">', '<img id="{[this.getId(values)]}" data-failed="0" draggable="false" data-type="{[Ext.util.Format.htmlEncode(this.getDataType(values))]}" data-thumb="{[this.getThumbImg(values)]}" src="{[this.getThumbDefaultSrc(values)]}">', "</div>", "</div>", "<div ext:qtip=\"{[SYNO.SDS.Drive.Utils.doubleHtmlEncode(this.getFileName(values.name || '-'))]}\" class=\"title\">{[Ext.util.Format.htmlEncode(this.getFileName(values.name || '-'))]}</div>", "</div>", "</tpl>", {
                getId: function(e) {
                    return String.format("thumbnail_{0}", e.file_id ? SYNO.Util.Base64.encode(e.file_id.toString()) : "")
                },
                getDataType: function(e) {
                    return e.ntype
                },
                getLoadingClass: function(e) {
                    return this.hasThumbnail(e) ? "thumbnail-loading" : ""
                }.bind(this),
                getThumbImg: this.getThumbImg.bind(this),
                getThumbDefaultSrc: function(t) {
                    return this.hasThumbnail(t) ? SYNO.SDS.Drive.FileType.getDefaultIcon() : SYNO.SDS.Drive.FileType.getFileTypeIcon(t.ntype, e)
                }.bind(this),
                getFileName: function(e) {
                    return SYNO.SDS.Drive.Utils.parseDisplayName(e)
                },
                scope: this
            })
        },
        hasThumbnail: function(e) {
            return !e.removed && SYNO.SDS.Drive.FileType.hasThumbnail(e.ntype)
        },
        onViewResize: function() {
            this.updateWidthStyle()
        },
        updateWidthStyle: function() {
            var e = this.getViewSize(),
                t = this.getWidth() - 24,
                i = Math.floor((t + 16) / (e + 16)),
                n = (t + 16) / i - 16 - 2,
                s = String.format(".thumbnail-wrapper { width: {0}px; height: {1}px; } .thumbnail-entry .title {width: {2}px}", n, n, n),
                o = document.head || document.getElementsByTagName("head")[0];
            this.style && o.removeChild(this.style), this.style = document.createElement("style"), this.style.type = "text/css", this.style.styleSheet ? this.style.styleSheet.cssText = s : this.style.appendChild(document.createTextNode(s)), o.appendChild(this.style)
        },
        getThumbImg: function(e) {
            if (!this.hasThumbnail(e)) return "";
            if (e.thumbnail) return e.thumbnail;
            var t = Ext.apply({
                params: {
                    path: SYNO.SDS.Drive.Utils.getPathId(e.file_id),
                    size: "medium",
                    version_id: e.version_id
                }
            }, SYNO.SDS.Drive.WebAPIDesc.get_thumbnail);
            return SYNO.API.GetBaseURL(t)
        },
        onLoadItem: function(e) {
            var t = e.query("img")[0],
                i = t.getAttribute("data-type");
            if (SYNO.SDS.Drive.FileType.hasThumbnail(i)) {
                var n = t.getAttribute("data-thumb"),
                    s = SYNO.SDS.Drive.FileType.getFileTypeIcon(i, this.defaultIconSize),
                    o = n || s,
                    r = !1;
                if (n) {
                    var a = this.store.getAt(this.indexOf(e));
                    if (a && a.data) {
                        var l = a.data,
                            d = Ext.urlDecode(t.src) || {};
                        (!d.path || SYNO.SDS.Drive.Utils.getPathId(l.file_id) !== Ext.decode(d.path) || d.version_id && l.version_id !== Ext.decode(d.version_id)) && (r = !0, o = this.getThumbImg(l))
                    }
                }(r || -1 !== t.src.indexOf(SYNO.SDS.Drive.FileType.getDefaultIcon())) && this.findAppWindow().getImageQueue().addImage({
                    id: t.id,
                    url: o,
                    listeners: {
                        load: this.onImageLoad.createDelegate(this),
                        error: this.onImageError.createDelegate(this)
                    }
                })
            }
        },
        onUnLoadItem: function(e) {
            var t = e.query("img")[0],
                i = t.getAttribute("data-type");
            SYNO.SDS.Drive.FileType.hasThumbnail(i) && this.findAppWindow().getImageQueue().removeImage(t.id)
        },
        onImageLoad: function(e) {
            e.parentNode.parentNode.classList.remove("thumbnail-loading"), e.parentNode.classList.remove("syno-d-ori-icon");
            var t = this.getViewSize();
            e.naturalWidth >= t && e.naturalHeight >= t || e.parentNode.classList.add("syno-d-not-fit-icon")
        },
        onImageError: function(e) {
            e.parentNode.parentNode.classList.remove("thumbnail-loading"), e.parentNode.classList.add("syno-d-ori-icon"), e.parentNode.classList.remove("syno-d-not-fit-icon"), e.src = SYNO.SDS.Drive.FileType.getFileTypeIcon(e.getAttribute("data-type"), this.defaultIconSize)
        },
        onUpdate: function(e, t) {
            var i = this.store.indexOf(t);
            if (i > -1) {
                var n = this.isSelected(i),
                    s = this.all.elements[i],
                    o = this.bufferRender([t], i)[0],
                    r = Ext.DomQuery.selectNode("img", o);
                if (s && r && r.complete) {
                    var a = !1,
                        l = Ext.fly(s).child("img", !0),
                        d = t.data,
                        h = Ext.urlDecode(l.src) || {};
                    if (h.path && SYNO.SDS.Drive.Utils.getPathId(d.file_id) === Ext.decode(h.path) && d.version_id === Ext.decode(h.version_id) || (a = !0), !a) return s.replaceChild(o.lastChild, s.lastChild), void Ext.removeNode(o)
                }
                this.all.replaceElement(i, o, !0), n && (this.selected.replaceElement(s, o), this.all.item(i).addClass(this.selectedClass)), this.updateIndexes(i, i)
            }
        },
        setViewSize: function(e, t) {
            this.view_size = e, t && this.updateWidthStyle()
        },
        getViewSize: function() {
            return this.view_size || 140
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.SnippetView", {
        extend: "SYNO.SDS.Drive.Comp.DataView",
        constructor: function(e) {
            var t = {
                store: e.store,
                itemSelector: "div.snippet-entry",
                tpl: this.createTemplate()
            };
            Ext.apply(t, e || {}), Ext.apply(t.listeners, {
                click: this.onViewItemClick
            }), this.callParent([t])
        },
        createTemplate: function() {
            return new Ext.XTemplate('<tpl for=".">', '<div class="snippet-entry {[this.getEntryClass(values)]}">', '<span class="{[this.getStarClass(values)]}"></span>', '<span class="{[this.getFileTypeClass(values)]}"></span>', '<div class="info-wrapper">', '<div class="main-info">', '<div ext:qtip="{[this.getFileNameQtip(values)]}" class="title">{[this.getFileName(values.name || \'-\')]}</div>', '<div ext:qtip="{[Ext.util.Format.htmlEncode(this.getHighlight(values))]}" class="snippet">{[this.getHighlight(values)]}</div>', "</div>", '<div class="sub-info"> {[this.getMtime(values.mtime)]} </div>', "</div>", "</div>", "</tpl>", {
                getEntryClass: function(e) {
                    return 0 === this.owner.store.indexOfId(e.file_id) ? "first-item" : ""
                },
                getStarClass: function(e) {
                    return e.starred ? "syno-d-start-icon syno-d-start-icon-check" : "syno-d-start-icon"
                },
                getFileTypeClass: function(e) {
                    return SYNO.SDS.Drive.FileType.getMappingTypeCss(e.ntype, 16)
                },
                getHighlight: function(e) {
                    return this.escapeHighlight(e.content_snippet || "-")
                },
                escapeHighlight: function(e) {
                    return Ext.util.Format.htmlEncode(e || "").replace(/(3dd2fc93591338387e3f9e8f06fe0e34)|(92e78cb96015fb30b3d910376e32825d)/g, function(e, t, i) {
                        return t ? '<span class="highlight">' : "</span>"
                    })
                },
                getFileName: function(e) {
                    return Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e))
                },
                getFileNameQtip: function(e) {
                    return SYNO.SDS.Drive.Utils.doubleHtmlEncode(SYNO.SDS.Drive.Utils.parseDisplayPath(e.display_path))
                },
                getMtime: function(e) {
                    return SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * e))
                },
                owner: this
            })
        },
        onViewItemClick: function(e, t, i, n) {
            var s = Ext.fly(n.getTarget());
            if (s && s.is("span.syno-d-start-icon")) {
                var o = this.getStore().getAt(t),
                    r = o.get("starred");
                r ? this.findAppWindow().getAction().deleteShortcut({
                    file_id: [o.id]
                }) : this.findAppWindow().getAction().setShortcut({
                    file_id: [o.id]
                }), o.data.starred = !r, o.commit()
            }
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.DataViewPanel", {
        extend: "SYNO.ux.Panel",
        mixins: ["SYNO.SDS.Drive.Comp.SelectionModel", "SYNO.SDS.Drive.Comp.PagingToolBar", "SYNO.SDS.Drive.Comp.PanelEventHandler", "SYNO.SDS.Drive.Comp.DragDropHandler", "SYNO.SDS.Drive.Comp.KeyEventHandler"],
        constructor: function(e) {
            this.module = e.module, this.owner = e.owner, this.appWin = this.findAppWindow(), this.dataview = this.createDataView(e.Dataview);
            var t = {
                loadMask: !0,
                items: this.dataview,
                layout: "fit",
                bbar: this.getPagingToolBar(),
                listeners: {
                    scope: this,
                    activate: this.onActivate,
                    deactivate: this.onDeActivate,
                    afterlayout: {
                        single: !0,
                        fn: function() {
                            e.allowDragFile && this.initDragDrop()
                        }
                    }
                }
            };
            Ext.apply(t, e || {}), this.callParent([t]), this.initKeyEvent()
        },
        initEvents: function() {
            this.loadMask && (this.loadMask = new Ext.LoadMask(this.bwrap, Ext.apply({
                store: this.store
            }, this.loadMask))), this.callParent(arguments)
        },
        onActivate: function() {
            this.onRegEvent(), this.activeStore = this.findAppWindow().getStoreMgr().getActiveStore(), this.dataview.bindStore(this.activeStore), this.updatePaginToolBar(this.activeStore), this.updateCutIcon(), this.refreshEmptyText(), this.getView().el.focus(100)
        },
        onDeActivate: function() {
            this.loadMask && !Ext.isBoolean(this.loadMask) && this.loadMask.hide(), this.unRegEvent(), this.dataview.bindStore(null)
        },
        getView: function() {
            return this.dataview
        },
        getSelectedElements: function() {
            return this.dataview.selected.elements
        },
        getSelections: function() {
            return this.dataview.getSelectedRecords()
        },
        selectRecords: function(e, t) {
            this.getSelectionModel().selectRecords(e, t)
        },
        onDataSelectionChange: function() {
            this.findAppWindow().getEventMgr().fireEvent("nodeselectchange")
        },
        getStore: function() {
            return this.dataview.getStore()
        },
        onViewStoreChange: function(e, t, i) {
            this.switchStore(e, i) && (this.dataview.bindStore(this.activeStore), this.updatePaginToolBar(this.activeStore))
        },
        createDataView: function(e) {
            return new e({
                store: null,
                enableDragDrop: !1,
                deferEmptyText: !1,
                listeners: {
                    scope: this,
                    dblclick: this.onDoubleClick,
                    selectionchange: this.onDataSelectionChange
                }
            })
        },
        setEmptyText: function(e) {
            var t = this.dataview.getWidth(),
                i = this.dataview.getHeight() - 3;
            this.emptyText = e, this.dataview.emptyText = String.format('<div class="syno-d-dataview-empty" style="width: {0}px; height: {1}px"> {2} </div>', t, i, e)
        },
        refreshEmptyText: function() {
            0 === this.activeStore.getTotalCount() && (this.setEmptyText(this.emptyText || ""), this.dataview.refresh())
        },
        getSelectionModel: function() {
            return this.selectionModel || (this.selectionModel = new SYNO.SDS.Drive.Comp.DataViewSelectionModel(this.dataview))
        },
        focusItem: function(e) {
            this.getSelectionModel().selectRow(e), this.dataview.focusNode(e)
        },
        onUpdateScrollbar: function(e) {
            this.dataview.onUpdateScrollbar(e)
        },
        updatePaginToolBar: Ext.empytFn
    }, SYNO.SDS.Drive.Framework.postDefine), SYNO.SDS.Drive.Comp.DataViewSelectionModel = function(e) {
        var t = e,
            i = function() {
                return t.getSelectionCount() > 0
            },
            n = function() {
                return t.getSelectedRecords()
            };
        return {
            dataView: t,
            getSelected: function() {
                return n()[0]
            },
            getCount: function() {
                return t.getSelectionCount()
            },
            hasSelection: i,
            getSelections: n,
            selectAll: function(e) {
                t.selectRange(0, e - 1)
            },
            clearAllSelections: function(e) {
                t.clearAllSelections(e)
            },
            clearSelections: function(e) {
                t.clearSelections(e)
            },
            selectRow: function(e, i) {
                t.select(e, i)
            },
            selectRecords: function(e, i) {
                var n = 0;
                if (!Ext.isEmpty(e))
                    for (i || this.clearAllSelections(), n = 0; n < e.length; n++) this.selectRow(t.store.indexOf(e[n]), !0)
            }
        }
    }, Ext.define("SYNO.SDS.Drive.Comp.HotkeyHandler", {
        createHotkeyMap: function() {
            if (!this.keyMap) {
                this.fillKeyConfig();
                var e = this.findAppWindow().getAction(),
                    t = this;
                this.keyMap = new Ext.KeyMap(this.el, [{
                    key: Ext.EventObject.C,
                    alt: !1,
                    ctrl: !0,
                    shift: !1,
                    scope: e,
                    fn: function() {
                        t.hasPermission("copy") && !0 === t.config.copy && (e.onCopyAction(), t.config.paste = !0)
                    }
                }, {
                    key: Ext.EventObject.X,
                    alt: !1,
                    ctrl: !0,
                    shift: !1,
                    scope: e,
                    fn: function() {
                        t.hasPermission("cut") && !0 === t.config.cut && (e.onCutAction(), t.config.paste = !0)
                    }
                }, {
                    key: Ext.EventObject.V,
                    alt: !1,
                    ctrl: !0,
                    shift: !1,
                    scope: e,
                    fn: function() {
                        t.hasPermission("paste") && !0 === t.config.paste && e.onPasteAction(Ext.EventObject.V)
                    }
                }, {
                    key: Ext.EventObject.A,
                    alt: !1,
                    ctrl: !0,
                    shift: !1,
                    scope: t,
                    fn: function() {
                        !0 === t.config.select_all && t.selectAll()
                    }
                }, {
                    alt: !1,
                    ctrl: !1,
                    shift: !1,
                    key: Ext.EventObject.ESC,
                    scope: t,
                    fn: function() {
                        !0 === t.config.unselect && t.unSelect()
                    }
                }, {
                    alt: !1,
                    ctrl: !1,
                    shift: !1,
                    key: Ext.EventObject.DELETE,
                    scope: e,
                    fn: function() {
                        t.hasPermission("remove") && !0 === t.config.remove && e.deleteNode()
                    }
                }, {
                    alt: !1,
                    ctrl: !1,
                    shift: !1,
                    key: Ext.EventObject.F2,
                    scope: e,
                    fn: function() {
                        t.hasPermission("rename") && !0 === t.config.rename && e.renameNode()
                    }
                }, {
                    alt: !1,
                    ctrl: !1,
                    shift: !1,
                    key: Ext.EventObject.S,
                    scope: e,
                    fn: function() {
                        (t.hasPermission("add_star") || t.hasPermission("remove_star")) && (!0 !== t.config.add_star && !0 !== t.config.remove_star || e.updateMultiShortcut())
                    }
                }]), this.findAppWindow().addManagedComponent(this.keyMap)
            }
        },
        fillKeyConfig: function() {
            this.config = {
                copy: !0,
                cut: !0,
                paste: !0,
                select_all: !0,
                unselect: !0,
                remove: !0,
                rename: !0,
                add_star: !0,
                remove_star: !0
            }
        },
        getConfig: function() {
            return this.config
        },
        hasPermission: function(e) {
            var t = this.findAppWindow().getAction().ActionPrivChecker.check(e, this.findAppWindow().getAction().getTargets(), "hotkey");
            return t.display && t.enable
        }
    }), Ext.define("SYNO.SDS.Drive.Comp.SortButton", {
        extend: "SYNO.SDS.Drive.SimpleButton",
        itemId: "sort",
        constructor: function(e) {
            var t = SYNO.SDS.Drive._T,
                i = {
                    tabIndex: -1,
                    itemId: "sort",
                    tooltip: t("common", "sort"),
                    cls: "syno-d-sort-btn",
                    menu: new SYNO.SDS.Drive.SelMenu({
                        owner: e.appWindow,
                        defaults: {
                            checked: !1
                        },
                        items: [{
                            itemId: "score",
                            text: t("file", "relativity"),
                            hidden: !0
                        }, {
                            itemId: "name",
                            text: t("file", "title")
                        }, {
                            itemId: "mtime",
                            text: t("file", "mtime"),
                            checked: !0
                        }, {
                            itemId: "type",
                            text: t("file", "type")
                        }, {
                            itemId: "owner_name",
                            text: t("file", "owner")
                        }, {
                            itemId: "size",
                            text: t("file", "size")
                        }],
                        listeners: {
                            scope: this,
                            itemclick: this.onItemClick,
                            beforeshow: this.onBeforeShow
                        }
                    })
                };
            Ext.apply(i, e || {}), this.callParent([i])
        },
        getMenuClass: function() {
            return ""
        },
        onItemClick: function(e, t) {
            this.getSortType() !== e.itemId && this.findAppWindow().getStoreMgr().getActiveStore().sort(e.itemId, "mtime" === e.itemId ? "DESC" : "ASC")
        },
        getSortType: function() {
            return (this.findAppWindow().getStoreMgr().getActiveStore().getSortState() || {}).field || "mtime"
        },
        onBeforeShow: function(e) {
            var t = this.findAppWindow().getNavigation().getCategory();
            "list" !== this.findAppWindow().getViewModeMgr().getViewMode() && this.parentPanel.getGrid().switchCM(t), this.parentPanel.getGrid().getGridCM().columns.forEach(function(t) {
                var i = e.get(t.dataIndex);
                void 0 !== i && (!0 !== t.sortable || !1 !== t.hidden && !0 !== t.hideable ? i.setVisible(!1) : i.setVisible(!0))
            }, this), e.get("score").setVisible("search" === t), e.items.each(function(e) {
                e.setChecked && e.setChecked(e.itemId === this.getSortType())
            }, this)
        }
    });
Ext.define("SYNO.SDS.Drive.Comp.ViewModeButton", {
    extend: "SYNO.SDS.Drive.SimpleButton",
    defaultMode: "list",
    constructor: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = {
                tabIndex: -1,
                itemId: "view_mode",
                cls: "syno-d-viewmode-btn viewmode-list",
                disabled: !1,
                tooltip: t("view", "list_mode"),
                menu: {
                    items: [{
                        itemId: "list",
                        text: t("view", "list_mode"),
                        tooltip: t("view", "list_mode"),
                        iconCls: "syno-d-viewmode-menu menu-list"
                    }, {
                        itemId: "detail",
                        text: t("view", "detail_mode"),
                        tooltip: t("view", "detail_mode"),
                        iconCls: "syno-d-viewmode-menu menu-detail"
                    }, {
                        itemId: "thumbnail",
                        text: t("view", "thumb_mode"),
                        tooltip: t("view", "thumb_mode"),
                        iconCls: "syno-d-viewmode-menu menu-thumbnail"
                    }, {
                        itemId: "tile",
                        text: t("view", "tile_mode"),
                        tooltip: t("view", "tile_mode"),
                        iconCls: "syno-d-viewmode-menu menu-tile"
                    }, {
                        itemId: "snippet",
                        text: t("view", "snippet_mode"),
                        tooltip: t("view", "snippet_mode"),
                        iconCls: "syno-d-viewmode-menu menu-snippet",
                        hidden: !0
                    }],
                    listeners: {
                        scope: this,
                        itemclick: this.onItemClick,
                        show: this.onMenuShow
                    }
                },
                listeners: {
                    scope: this,
                    single: !0,
                    beforeshow: this.onBeforeShow
                }
            };
        Ext.apply(i, e || {}), this.appWin = e.appWindow, this.callParent([i]), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.appWin.getEventMgr();
        this.mon(e, {
            scope: this,
            viewmodechange: this.onViewModeChage
        })
    },
    onMenuShow: function() {
        SYNO.SDS.Drive.Utils.isDriveAppWindow(this.findAppWindow()) && "search" === SYNO.SDS.Drive.GetWindow().getNavigation().getCategory() ? this.menu.get("snippet").show() : this.menu.get("snippet").hide(), this.menu.doLayout()
    },
    onBeforeShow: function() {
        this.onViewModeChage(this.appWin.getViewModeMgr().getViewMode())
    },
    onItemClick: function(e) {
        this.appWin.getViewModeMgr().setViewMode(e.itemId), this.setTooltip(e.tooltip)
    },
    onViewModeChage: function(e) {
        if ("empty" !== e) {
            var t = String.format("viewmode-{0}", this.currentMode),
                i = String.format("viewmode-{0}", e);
            this.el.removeClass(t), this.el.addClass(i), "snippet" !== this.currentMode && "label" !== this.currentMode && (this.previousMode = this.currentMode), this.currentMode = e;
            var n = this.menu.get(e);
            n && this.setTooltip(n.tooltip)
        }
    },
    setViewMode: function(e) {
        var t = this.menu.get(e);
        t && this.onItemClick(t)
    },
    setPrevViewMode: function() {
        this.setViewMode(this.getPreviousMode())
    },
    getPreviousMode: function() {
        return this.previousMode || this.defaultMode
    },
    getCurrentMode: function() {
        return this.currentMode || this.defaultMode
    }
}), Ext.define("SYNO.SDS.Drive.Comp.SimpleSplitButton", {
    extend: "SYNO.SDS.Drive.SimpleButton",
    constructor: function(e) {
        var t = {
            tabIndex: -1,
            cls: "syno-d-simple-split-btn",
            margins: "0 0 0 6",
            menu: this.getMenu(e)
        };
        Ext.apply(t, e || {}), this.appWindow = e.appWindow, this.callParent([t])
    },
    onClickItem: function(e, t, i) {
        this.setText(e.text);
        var n = this.menu.items.items;
        Ext.each(n, function(e) {
            e.setChecked(!1)
        }, this), e.setChecked(!0), this.menu.hide()
    },
    getCheckedId: function() {
        var e, t = this.menu.items.items;
        return Ext.each(t, function(t) {
            if (t.checked) return e = t.itemId, !1
        }, this), e
    },
    getItemText: function(e) {
        var t = this.menu.get(e);
        return t ? t.text : ""
    },
    setCheckedId: function(e) {
        var t = this.menu.get(e);
        t && this.onClickItem(t)
    },
    getMenu: Ext.emptyFn
}), Ext.define("SYNO.SDS.Drive.Comp.SharedItemButton", {
    extend: "SYNO.SDS.Drive.Comp.SimpleSplitButton",
    constructor: function(e) {
        var t = {
            itemId: "shared_items",
            text: SYNO.SDS.Drive._T("category", "shared_with_me"),
            hidden: !0
        };
        Ext.apply(t, e || {}), this.callParent([t])
    },
    getMenu: function(e) {
        return this.menu ? this.menu : (this.menu = new SYNO.SDS.Drive.SelMenu({
            owner: e.appWindow,
            defaults: {
                checked: !1
            },
            items: [{
                itemId: "shared_with_me",
                text: SYNO.SDS.Drive._T("category", "shared_with_me"),
                checked: !0
            }, {
                itemId: "sharing_to_others",
                text: SYNO.SDS.Drive._T("category", "sharing_to_others")
            }],
            listeners: {
                scope: this,
                itemclick: this.onClickItem
            }
        }), this.menu)
    },
    onClickItem: function(e, t) {
        return this.callParent(arguments), this.appWindow.getNavigation().setCategory(e.itemId, void 0, void 0, !0), !1
    }
}), Ext.define("SYNO.SDS.Drive.Comp.RecycleButton", {
    extend: "SYNO.SDS.Drive.Comp.SimpleSplitButton",
    lastTime: 0,
    cacheTime: 3e3,
    constructor: function(e) {
        var t = {
            itemId: "recycle"
        };
        Ext.apply(t, e || {}), this.callParent([t]), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.appWindow.getEventMgr();
        this.mon(e, "envready", this.onBeforeShow, this)
    },
    getMenu: function(e) {
        return this.menu ? this.menu : (this.menu = new SYNO.SDS.Drive.SelMenu({
            owner: e.appWindow,
            defaults: {
                checked: !1
            },
            items: [],
            listeners: {
                scope: this,
                itemclick: this.onClickItem,
                beforeshow: this.onBeforeShow
            }
        }), this.menu)
    },
    onClickItem: function(e, t) {
        return this.callParent(arguments), this.appWindow.getNavigation().setCategoryAndPath("recycle", void 0, void 0, void 0, void 0, !0), !1
    },
    onBeforeShow: function() {
        var e = (new Date).getTime();
        e - this.lastTime < this.cacheTime || (this.lastTime = e, SYNO.SDS.Drive.WebAPICore.sendPromise("list_team_folders", {}).then(this.onAddTeamFolders.bind(this)).catch(Ext.emptyFn))
    },
    onAddTeamFolders: function(e) {
        this.init = !0;
        var t = this.getCheckedId();
        this.menu.removeAll(), SYNO.SDS.Drive.Define.Info.is_home && this.menu.add({
            itemId: "node",
            text: SYNO.SDS.Drive._T("category", "node")
        }), Ext.each(e.items, function(e) {
            this.menu.add({
                itemId: e.file_id,
                text: e.name
            }), this.initName && (this.initName === e.name && (t = e.file_id), this.initName = null)
        }, this);
        var i;
        (i = Ext.isEmpty(t) ? this.menu.items.items[0] : this.menu.get(t)) && (this.setText(i.text), i.setChecked(!0))
    },
    setCheckedName: function(e) {
        if (this.init) {
            var t = this.getCheckedId(),
                i = this.menu.items.items;
            Ext.each(i, function(i) {
                if (e === i.text) return t !== i.itemId && this.setCheckedId(i.itemId), !1
            }, this)
        } else this.initName = e
    }
}), Ext.define("SYNO.SDS.Drive.Comp.MainPanel", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.appWin = this.findAppWindow();
        var t = {
            cls: "syno-d-mgr-right",
            border: !1,
            itemId: "main",
            region: "center",
            layout: "card",
            activeItem: this.appWin.getViewModeMgr().getViewMode(),
            boxMaxWidth: SYNO.SDS.Drive.WindowHelper.isPublicShare() ? 1e3 : void 0,
            defaults: {
                border: !1
            },
            tbar: this.getToolbar(),
            items: this.getPanelItems()
        };
        Ext.apply(t, e || {}), this.callParent([t])
    },
    onRegEvent: function() {
        var e = this.appWin.getEventMgr();
        this.mon(e, {
            scope: this,
            beforeviewpanelload: this.onBeforePanelLoad,
            viewpanelload: this.onPanelLoadDone,
            viewpanelfail: this.onPanelLoadFail,
            viewmodechange: this.onViewModeChage
        })
    },
    getPanelItems: function() {
        return [this.getGrid(), this.getDetailPanel(), this.getThumbnailPanel(), this.getTilePanel(), this.getEmptyPanel()]
    },
    getEmptyPanel: function() {
        return this.emptypanel ? this.emptypanel : this.emptypanel = new SYNO.SDS.Drive.Comp.EmptyPanel({
            itemId: "empty",
            hideMode: "offsets",
            owner: this
        })
    },
    getPathBar: function() {
        return this.pathbar ? this.pathbar : (this.pathbar = new SYNO.SDS.Drive.Comp.Path({
            appWin: this.findAppWindow(),
            listeners: {
                beforeshowarrow: this.onBeforeShowArrow,
                pathbarclick: this.onPathbarClick,
                scope: this
            }
        }), this.pathbar)
    },
    onBeforeShowArrow: function() {
        return !1
    },
    onPathbarClick: function(e, t, i, n) {
        var s = this.findAppWindow().getNavigation(),
            o = s.getPath();
        s.setCategoryAndPath(s.getCategory(), o.slice(0, parseInt(t) + 1), void 0, void 0, void 0, !0)
    },
    getSharedItemBtn: function() {
        return this.sharedItemBtn ? this.sharedItemBtn : (this.sharedItemBtn = new SYNO.SDS.Drive.Comp.SharedItemButton({
            appWindow: this.appWin
        }), this.sharedItemBtn)
    },
    getRecycleBtn: function() {
        return this.recycleBtn ? this.recycleBtn : (this.recycleBtn = new SYNO.SDS.Drive.Comp.RecycleButton({
            appWindow: this.appWin
        }), this.recycleBtn)
    },
    getViewModeBtn: function() {
        return this.viewModeBtn ? this.viewModeBtn : (this.viewModeBtn = new SYNO.SDS.Drive.Comp.ViewModeButton({
            appWindow: this.appWin
        }), this.viewModeBtn)
    },
    getSortBtn: function() {
        return this.sortBtn ? this.sortBtn : (this.sortBtn = new SYNO.SDS.Drive.Comp.SortButton({
            appWindow: this.appWin,
            parentPanel: this
        }), this.sortBtn)
    },
    onBeforePanelLoad: function(e) {
        this.removeClass("syno-d-mgr-empty-grid"), this.setActivePanel(e)
    },
    onPanelLoadDone: function(e, t) {
        var i = this.findAppWindow(),
            n = i.getNavigation(),
            s = n.getCategory();
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare() && Ext.getClassByName("SYNO.SDS.Drive.MainWindow") && i instanceof SYNO.SDS.Drive.MainWindow && "search" !== s && 1 >= n.getPath().length && 0 === e.length ? (this.setActivePanel("empty"), this.getEmptyPanel().onUpdate()) : ("search" === s && 0 === e.length ? this.addClass("syno-d-mgr-empty-grid") : this.removeClass("syno-d-mgr-empty-grid"), this.setActivePanel(t)), !this.blLoadInit && n.isRootPath() && SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var o = !1;
            Ext.each(e, function(e) {
                if ("dir" === e.data.ntype) return o = !0, !1
            }), o && this.getTopToolbar().setHeight(83), this.blLoadInit = !0
        }
        this.onCheckToolbar()
    },
    onPanelLoadFail: function(e) {
        this.setActivePanel("empty"), this.getEmptyPanel().onUpdateText("error", SYNO.SDS.Drive.Utils.getErrorStr(e))
    },
    onViewModeChage: function(e) {
        var t = this.getActivePanel().getSelections(),
            i = this.layout;
        i.activeItem !== i.container.getComponent(e) && i.setActiveItem(e);
        var n = this.getActivePanel();
        n.selectRecords(t), n.onUpdateScrollbar && n.onUpdateScrollbar(!0)
    },
    setActivePanel: function(e) {
        var t = this.findAppWindow().getViewModeMgr();
        e !== t.getViewMode() && t.setViewMode(e)
    },
    setEmptyText: function(e) {
        Ext.each(this.items.items, function(t) {
            Ext.isFunction(t.setEmptyText) && t.setEmptyText(e)
        })
    },
    getActivePanel: function() {
        return this.layout.activeItem
    },
    getGrid: function() {},
    getDetailPanel: function() {},
    getThumbnailPanel: function() {},
    getTilePanel: function() {},
    getToolbar: function() {}
}), Ext.define("SYNO.SDS.Drive.OfficeIntro.Window", {
    extend: "SYNO.SDS.Drive.ModalWindow",
    constructor: function(e) {
        var t = {
            width: 680,
            height: 509,
            cls: "syno-d-prompt-window syno-d-office-intro-window",
            layout: "fit",
            header: !1,
            elements: "body",
            useStatusBar: !1,
            resizable: !1,
            closable: !1,
            draggable: !1,
            padding: void 0,
            items: this.getContent()
        };
        Ext.apply(t, e || {}), this.callParent([t])
    },
    getContent: function() {
        var e = SYNO.SDS.Drive._T;
        return {
            xtype: "container",
            layout: "vbox",
            layoutConfig: {
                align: "center"
            },
            items: [{
                xtype: "spacer",
                height: 20
            }, {
                xtype: "container",
                cls: "syno-d-office-intro-image"
            }, {
                xtype: "spacer",
                height: 20
            }, {
                xtype: "syno_displayfield",
                cls: "syno-d-prompt-window-title",
                value: e("cstn", "welcome_title_office")
            }, {
                xtype: "spacer",
                height: 12
            }, {
                xtype: "syno_displayfield",
                cls: "syno-d-prompt-window-desc",
                html: String.format(e("common", "prompt_intro_office_desc"), e("cstn", "package_center"))
            }, {
                xtype: "spacer",
                flex: 1
            }, {
                xtype: "syno_button",
                width: 200,
                cls: "syno-d-prompt-window-btn",
                text: e("common", "got_it"),
                scope: this,
                handler: this.onWinClose
            }, {
                xtype: "spacer",
                height: 36
            }]
        }
    },
    afterShow: function() {
        this.callParent(arguments);
        var e = this.owner.el.query(".sds-window-mask")[0];
        Ext.fly(e).addClass("syno-d-prompt-window-mask")
    },
    onWinClose: function() {
        var e = this.owner.el.query(".sds-window-mask")[0];
        Ext.fly(e).removeClass("syno-d-prompt-window-mask"), this.owner.appInstance.setUserSettings("hide_office_intro_prompt", !0), this.close()
    }
}), Ext.define("SYNO.SDS.Drive.PermPanel", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = e.mode || "request",
            i = SYNO.SDS.Drive._T,
            n = {
                cls: "syno-d-perm-panel-background",
                xtype: "container",
                layout: {
                    type: "vbox",
                    align: "center",
                    pack: "center"
                },
                items: [{
                    xtype: "container",
                    height: 288,
                    width: 640,
                    cls: "syno-d-perm-panel-container",
                    defaults: {
                        width: 640
                    },
                    items: [this.title = new Ext.BoxComponent({
                        height: 42,
                        cls: "syno-d-perm-panel-title",
                        html: this.getTitle(t)
                    }), {
                        xtype: "container",
                        layout: "border",
                        height: 220,
                        cls: "syno-d-perm-panel-container-panel",
                        defaults: {
                            border: !1
                        },
                        items: [{
                            region: "west",
                            margins: {
                                top: 0,
                                bottom: 0,
                                left: 32,
                                right: 0
                            },
                            width: 128,
                            items: [this.iconBox = new Ext.BoxComponent({
                                xtype: "box",
                                ctCls: "syno-d-perm-panel-icon-ct",
                                cls: "syno-d-perm-panel-icon syno-d-perm-panel-icon-noperm"
                            })]
                        }, {
                            region: "center",
                            xtype: "container",
                            ctCls: "syno-d-perm-panel-center-ct",
                            cls: "syno-d-perm-panel-center",
                            layout: {
                                type: "table",
                                columns: 1
                            },
                            defaults: {
                                columnWidth: 1
                            },
                            margins: {
                                top: 32,
                                bottom: 32,
                                left: 32,
                                right: 32
                            },
                            items: [this.permDesc = new Ext.BoxComponent({
                                cls: "syno-d-perm-panel-desc",
                                html: this.getDesc(t)
                            }), {
                                xtype: "container",
                                cls: "syno-d-perm-panel-desc-ct",
                                defaults: {
                                    width: "auto"
                                },
                                items: [this.accessBtn = new SYNO.ux.Button({
                                    cls: "syno-d-perm-panel-btn",
                                    xtype: "syno_button",
                                    btnStyle: "green",
                                    text: i("request", "access"),
                                    scope: this,
                                    handler: this.onRequestAccess
                                }), this.switchBtn = new SYNO.ux.Button({
                                    cls: "syno-d-perm-panel-btn",
                                    xtype: "syno_button",
                                    btnStyle: "grey",
                                    text: i("request", "switch_account"),
                                    scope: this,
                                    handler: this.onLogout
                                }), this.loginBtn = new SYNO.ux.Button({
                                    cls: "syno-d-perm-panel-btn",
                                    xtype: "syno_button",
                                    btnStyle: "green",
                                    text: _T("common", "login"),
                                    scope: this,
                                    handler: this.onLogin
                                })]
                            }]
                        }]
                    }]
                }],
                listeners: {
                    scope: this,
                    activate: this.onActivate
                }
            };
        Ext.apply(n, e), this.callParent([n])
    },
    onActivate: function() {
        var e = this.findAppWindow();
        e.onHidePromptToast && e.onHidePromptToast()
    },
    getTitle: function(e, t) {
        var i = SYNO.SDS.Drive._T;
        switch (e) {
            case "SENT":
                return i("request", "title");
            case "SERVICE_UNAVAILABLE":
            case "NON_EXIST":
            case "VIEW_OWNER_DISABLED":
                return t || i("request", "not_exist_title");
            case "EXPIRED":
                return t || i("share", "expired_title");
            case "NO_PERM":
                return i("request", "no_perm_title");
            default:
                return i("request", "title")
        }
    },
    getDesc: function(e, t) {
        var i = SYNO.SDS.Drive._T;
        switch (e) {
            case "SENT":
                return i("request", "sent");
            case "SERVICE_UNAVAILABLE":
                return t || i("error", "service_unavailable");
            case "NON_EXIST":
                return t || i("error", "item_not_exist");
            case "VIEW_OWNER_DISABLED":
                return t || i("error", "view_user_disabled");
            case "EXPIRED":
                return t || i("share", "expired_link_desc");
            default:
                return SYNO.SDS.Drive.Utils.isLogined() ? i("request", "desc") + "<br><br>" + String.format(i("request", "user"), '<span class="syno-d-perm-panel-account">' + _S("user") + "</span>") : i("request", "no_perm")
        }
    },
    getMode: function() {
        return this.mode || "request"
    },
    getIconClasses: function() {
        var e;
        switch (this.mode) {
            case "SENT":
                e = "syno-d-perm-panel-icon-mail";
                break;
            case "SERVICE_UNAVAILABLE":
            case "NON_EXIST":
            case "VIEW_OWNER_DISABLED":
                e = "syno-d-perm-panel-icon-no-exist";
                break;
            case "EXPIRED":
                e = "syno-d-perm-panel-icon-expired-link";
                break;
            default:
                e = "syno-d-perm-panel-icon-noperm"
        }
        return "syno-d-perm-panel-icon " + e
    },
    onUpdateByErrCode: function(e, t) {
        switch (e) {
            case 1002:
                this.onUpdate("NO_PERM", void 0, void 0, t);
                break;
            case 1003:
            case 1036:
                this.onUpdate("NON_EXIST");
                break;
            case 1038:
                this.onUpdate("EXPIRED");
                break;
            case 1039:
                this.onUpdate("VIEW_OWNER_DISABLED");
                break;
            default:
                this.onUpdate("SERVICE_UNAVAILABLE")
        }
    },
    onUpdate: function(e, t, i, n) {
        switch (this.mode = e, this.iconBox.rendered ? this.iconBox.getEl().dom.className = this.getIconClasses() : this.iconBox.cls = this.getIconClasses(), this.title.el ? this.title.update(this.getTitle(e, t)) : this.mon(this.title, "afterrender", function() {
                this.title.update(this.getTitle(e, t))
            }, this, {
                single: !0
            }), this.permDesc.el ? this.permDesc.update(this.getDesc(e, i)) : this.mon(this.permDesc, "afterrender", function() {
                this.permDesc.update(this.getDesc(e, i))
            }, this, {
                single: !0
            }), e) {
            case "SERVICE_UNAVAILABLE":
                this.accessBtn.hide(), this.switchBtn.hide(), SYNO.SDS.Drive.Utils.isLogined() ? this.loginBtn.hide() : this.loginBtn.show();
                break;
            case "NON_EXIST":
            case "SENT":
            case "VIEW_OWNER_DISABLED":
            case "EXPIRED":
                this.accessBtn.hide(), this.switchBtn.hide(), this.loginBtn.hide();
                break;
            default:
                if (SYNO.SDS.Drive.Utils.isLogined()) {
                    var s = !1;
                    s = n ? "disallow" !== n.sharing_level : !window.getDriveAllowToShare || !1 !== window.getDriveAllowToShare(), SYNO.SDS.Drive.Utils.isAppAuthorized() && s ? this.accessBtn.show() : this.accessBtn.hide(), this.switchBtn.show(), this.loginBtn.hide()
                } else this.accessBtn.hide(), this.switchBtn.hide(), this.loginBtn.show()
        }
    },
    onRequestAccess: function() {
        var e = this.findAppWindow();
        e.setStatusBusy();
        var t;
        if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) t = {
            permanent_link: window.getDriveLink()
        };
        else {
            var i = SYNO.SDS.Drive.Utils.getHashParam() || {};
            if (!i.file_id) return;
            t = {
                file_id: i.file_id
            }
        }
        e.getAction().requestAccess(t, function(t, i) {
            if (e.clearStatusBusy(), !t) return void e.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(i));
            this.onUpdate("SENT")
        }, this)
    },
    onLogin: function() {
        SYNO.SDS.Utils.Logout.redirect(!1)
    },
    onLogout: function() {
        SYNO.SDS.Utils.Logout.action()
    }
}), Ext.define("SYNO.SDS.Drive.FileButton", {
    extend: "SYNO.ux.FileButton",
    mulitSelect: !0,
    acceptType: "",
    constructor: function(e) {
        this.callParent(arguments)
    },
    getFileName: function(e) {
        if (Ext.isWindows) return e.substr(e.lastIndexOf("\\") + 1);
        var t = /fakepath\\(.+)$/.exec(e);
        return null !== t && (e = t[1]), e
    },
    onRender: function() {
        this.callParent(arguments), this.el.set({
            multiple: this.mulitSelect,
            accept: this.acceptType
        }, !0)
    },
    onFileChange: function(e, t, i) {
        var n = [],
            s = e.target.files;
        Ext.each(s, function(e) {
            n.push(this.getFileName(e.name))
        }, this), this.fileTextField.setValue(n.join(",")), this.fireEvent("change", e.target.files)
    },
    setAttributes: function(e) {
        this.el.set({
            accept: e.accept
        }, !0), !1 === e.multiple && this.el.dom.removeAttribute("multiple")
    }
}), Ext.reg("synodrive_filebutton", SYNO.SDS.Drive.FileButton), Ext.define("SYNO.SDS.Drive.Upload.FromPCPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    mixins: ["SYNO.SDS.Drive.Comp.DragDropHandler"],
    constructor: function(e) {
        this.owner = e.owner, this.appWin = this.findAppWindow(), this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: "syno-d-upload-from-pc-panel",
            layout: "fit",
            padding: 0,
            fieldWidth: 250,
            fileUpload: !0,
            items: [this.getGridPanel()],
            tbar: this.getToolbar(),
            listeners: {
                scope: this,
                afterlayout: {
                    single: !0,
                    fn: this.initDragDrop
                }
            }
        };
        return Ext.apply(t, e)
    },
    getGridPanel: function() {
        if (this.grid) return this.grid;
        var e = SYNO.SDS.Drive._T;
        return this.grid = new SYNO.ux.GridPanel({
            itemId: "upload_file_grid",
            hideHeaders: !0,
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                rowHeight: 48,
                borderHeight: 1,
                cacheSize: 30,
                scrollDelay: !1,
                forceFit: !0,
                disableTextSelect: !0
            }),
            flex: 1,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    scope: this,
                    beforerowselect: function() {
                        return !!this.owner.singleSelect
                    }
                }
            }),
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0
                },
                columns: [{
                    dataIndex: "filename",
                    header: e("file", "title"),
                    renderer: function(e, t, i, n, s, o) {
                        var r, a, l, d = i.get("fileObj"),
                            h = i.get("fileEntry");
                        return SYNO.SDS.Drive.FileType.isImageMime(d.type) ? (r = URL.createObjectURL(d), l = 32, Ext.defer(function() {
                            URL.revokeObjectURL(r)
                        }, 1e3)) : (l = 24, r = h && h.isDirectory ? SYNO.SDS.Drive.FileType.getFileTypeIcon("dir", l) : SYNO.SDS.Drive.FileType.getFileTypeIcon(SYNO.SDS.Drive.Utils.getExt(e), l)), a = String.format('<div class="syno-d-upload-preview" style="background-image: url({0}); background-size:{1}px"></div>', r, l), a += String.format('<span class="syno-d-upload-text">{0}</span>', Ext.util.Format.htmlEncode(SYNO.SDS.Drive.Utils.parseDisplayName(e))), a += '<span class="syno-d-upload-remove"></span>'
                    }
                }]
            }),
            store: this.getFileStore(),
            listeners: {
                scope: this,
                rowclick: this.onRowClick
            }
        }), this.grid
    },
    getFileStore: function() {
        return this.fileStore ? this.fileStore : (this.fileStore = new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["filename", "filesize"]
        }), this.fileStore)
    },
    getToolbar: function() {
        if (this.toolbar) return this.toolbar;
        var e = SYNO.SDS.Drive._T;
        return this.toolbar = new SYNO.ux.Toolbar({
            items: [{
                xtype: "synodrive_filebutton",
                itemId: "upload",
                buttonConfig: {
                    btnStyle: "default"
                },
                buttonOnly: !0,
                buttonText: e("upload", "upload_from_pc"),
                listeners: {
                    scope: this,
                    change: this.addFiles
                }
            }]
        }), this.toolbar
    },
    onRowClick: function(e, t, i, n) {
        Ext.fly(i.getTarget()).is("span.syno-d-upload-remove") && (this.fileStore.removeAt(t), this.setStatusText())
    },
    getFileName: function(e) {
        if (Ext.isWindows) return e.substr(e.lastIndexOf("\\") + 1);
        var t = /fakepath\\(.+)$/.exec(e);
        return null !== t && (e = t[1]), e
    },
    addFiles: function(e, t) {
        if (!1 === this.findAppWindow().fireEvent("beforefileselect", e, t)) return !1;
        for (var i = 0; i < e.length; ++i) {
            var n = SYNO.SDS.Drive.Utils.getDragItem(e, t, i);
            this.fileStore.add(new Ext.data.Record({
                name: Ext.id(void 0, "file_upload_"),
                filename: this.getFileName(e[i].name),
                filesize: Ext.util.Format.fileSize(e[i].size),
                fileObj: e[i],
                fileEntry: n ? n.webkitGetAsEntry() : void 0,
                source: "from_pc"
            }))
        }
        if (this.setStatusText(), this.owner.singleSelect) {
            var s = this.getGridPanel().getSelectionModel();
            s.hasSelection() || s.selectRow(0), t || this.findAppWindow().onApply()
        }
    },
    setFileBtnAttributes: function(e) {
        this.toolbar.get("upload").setAttributes(e)
    },
    setStatusText: function() {
        var e = this.fileStore.getCount();
        this.findAppWindow().setApplyBtnDisabled(0 === e), this.findAppWindow().setStatus(String.format(SYNO.SDS.Drive._T("upload", "items"), e))
    },
    onFileChange: function(e, t) {
        this.checkFileCanUpload(e, t).then(function() {
            this.addFiles(e, t)
        }.bind(this))
    },
    getMaskTargetEl: function() {
        return this.grid.getEl()
    },
    getResults: function() {
        var e = [];
        if (this.owner.singleSelect) {
            var t = this.getGridPanel().getSelectionModel();
            if (t.hasSelection()) {
                var i = t.getSelected();
                e.push(i.data)
            }
            return e
        }
        return this.fileStore.each(function(t) {
            e.push(t.data)
        }), e
    },
    cleanAll: function() {
        this.fileStore.removeAll()
    },
    isDirty: function() {
        return 0 < this.getResults().length
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Upload.URLPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = {
                cls: "syno-d-upload-url-panel",
                labelAlign: "top",
                items: [{
                    xtype: "syno_textfield",
                    name: "url_field",
                    itemId: "url_field",
                    fieldLabel: t("upload", "paste_url"),
                    cls: "syno-d-upload-url-field",
                    allowBlank: !1,
                    enableKeyEvents: !0,
                    validator: function(e) {
                        var t = this.isValidURL(e);
                        return this.findAppWindow().setApplyBtnDisabled(!t), t
                    }.bind(this),
                    listeners: {
                        scope: this,
                        buffer: 100,
                        keyup: function(e) {
                            var t = this.isValidURL(e.getValue());
                            this.findAppWindow().setApplyBtnDisabled(!t)
                        }
                    }
                }]
            };
        Ext.apply(i, e || {}), this.callParent([i])
    },
    isValidURL: function(e) {
        return !!/^(?:https?|ftps?|sftp):\/\/[^\s\$.?#].[^\s]*$/i.exec(e)
    },
    getResults: function() {
        return [{
            source: "from_url",
            url: this.form.findField("url_field").getValue()
        }]
    },
    isValid: function() {
        return this.form.isValid()
    },
    getError: function() {
        return ""
    },
    isDirty: function() {
        return this.form.isDirty()
    }
}), Ext.define("SYNO.SDS.Drive.Upload.YouTubeURLPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = {
                cls: "syno-d-upload-url-panel",
                labelAlign: "top",
                items: [{
                    xtype: "syno_compositefield",
                    fieldLabel: t("upload", "paste_youtube_url"),
                    style: {
                        "padding-top": "8px"
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-d-upload-youtube-icon"
                    }, {
                        xtype: "syno_textfield",
                        name: "youtube_url_field",
                        itemId: "youtube_url_field",
                        cls: "syno-d-upload-url-field",
                        style: {
                            "margin-left": "3px"
                        },
                        allowBlank: !1,
                        enableKeyEvents: !0,
                        validator: function(e) {
                            var t = this.isValidURL(e);
                            return this.findAppWindow().setApplyBtnDisabled(!t), t
                        }.bind(this),
                        listeners: {
                            scope: this,
                            buffer: 100,
                            keyup: function(e) {
                                var t = this.isValidURL(e.getValue());
                                this.findAppWindow().setApplyBtnDisabled(!t)
                            }
                        }
                    }]
                }]
            };
        Ext.apply(i, e || {}), this.callParent([i])
    },
    isValidURL: function(e) {
        return !!/^https?:\/\/(?:[^\/]*\.)?(youtu\.be\/|youtube\.com\/watch\?(?:.*&)?v=)[\w\-]+/.exec(e)
    },
    getResults: function() {
        return [{
            source: "from_youtube_url",
            url: this.form.findField("youtube_url_field").getValue()
        }]
    },
    isValid: function() {
        return this.form.isValid()
    },
    getError: function() {
        return ""
    },
    isDirty: function() {
        return this.form.isDirty()
    }
}), Ext.define("SYNO.SDS.Drive.Upload.GridPanel", {
    extend: "SYNO.SDS.Drive.Comp.GridPanel",
    applyColumnState: !1,
    constructor: function(e) {
        var t = {
            enableDragDrop: !1,
            enableHdMenu: !1,
            minColumnWidth: 50,
            listeners: {
                scope: this,
                rowclick: function(e, t, i) {
                    i && t >= 0 && !i.hasModifier() && e.getSelectionModel().selectRow(t)
                },
                show: this.onShowPanel,
                activate: this.onActivate,
                deactivate: this.onDeActivate,
                rowdblclick: this.onDoubleClick
            }
        };
        Ext.apply(t, e || {}), this.callParent([t])
    },
    getGridView: function(e) {
        return new SYNO.ux.FleXcroll.grid.BufferView({
            rowHeight: "detail" === this.mode ? 48 : 36,
            borderHeight: 2,
            cacheSize: 30,
            scrollDelay: !1,
            forceFit: !0,
            disableTextSelect: !0,
            updateSortIcon: function(e, t) {
                var i = this.sortClasses,
                    n = i["DESC" === t.toUpperCase() ? 1 : 0],
                    s = this.mainHd.select("td").removeClass(i),
                    o = s.item(e);
                o && o.addClass(n)
            }
        })
    },
    getActiveStore: function() {
        return this.activeStore = this.findAppWindow().getStoreMgr().getActiveStore(), this.activeStore
    },
    getNameColumn: function() {
        return new("detail" === this.mode ? SYNO.SDS.Drive.Comp.DetailNameColumn : SYNO.SDS.Drive.Comp.NameColumn)({
            appWindow: this.findAppWindow(),
            width: 200,
            showStar: !1,
            dataIndex: "name",
            header: SYNO.SDS.Drive._T("file", "title")
        })
    },
    getGridCM: function() {
        return this.gridcm ? this.gridcm : (this.gridcm = new Ext.grid.ColumnModel({
            defaults: {
                menuDisabled: !0,
                sortable: !0,
                hidden: !1
            },
            columns: [this.getNameColumn(), this.getOwnerColumn(), this.getSizeColumn(), this.getTimeColumn({
                dataIndex: "mtime",
                header: SYNO.SDS.Drive._T("file", "mtime")
            })]
        }), this.gridcm)
    },
    getSelModel: function() {
        return new Ext.grid.RowSelectionModel({
            listeners: {
                scope: this,
                selectionchange: this.onSelectionChange
            }
        })
    },
    onSelectionChange: function() {
        this.findAppWindow().getEventMgr().fireEvent("nodeselectchange")
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Upload.DnDPanel", {
    extend: "SYNO.ux.FormPanel",
    mixins: ["SYNO.SDS.Drive.Comp.DragDropHandler"],
    constructor: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = {
                type: "vbox",
                pack: "center",
                align: "center"
            },
            n = {
                cls: "syno-d-upload-dnd-panel",
                layout: i,
                items: [{
                    xtype: "container",
                    cls: "syno-d-upload-container",
                    layout: i,
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-d-upload-drag-here",
                        value: t("upload", "drag_here")
                    }, {
                        xtype: "syno_displayfield",
                        cls: "syno-d-upload-or",
                        value: t("upload", "or_you_can")
                    }, {
                        xtype: "synodrive_filebutton",
                        itemId: "upload",
                        buttonConfig: {
                            btnStyle: "default"
                        },
                        buttonText: t("upload", "upload_from_pc"),
                        buttonOnly: !0,
                        listeners: {
                            scope: this,
                            change: this.onFileChange
                        }
                    }]
                }],
                listeners: {
                    scope: this,
                    afterlayout: {
                        single: !0,
                        fn: this.initDragDrop
                    }
                }
            };
        Ext.apply(n, e || {}), this.callParent([n])
    },
    onMask: function() {
        this.el.addClass("syno-d-upload-dragover")
    },
    unMask: function() {
        this.el.removeClass("syno-d-upload-dragover")
    },
    onFileChange: function(e, t) {
        this.checkFileCanUpload(e, t).then(function() {
            this.findAppWindow().getEventMgr().fireEvent("uploadfilechange", e, t)
        }.bind(this))
    },
    setFileBtnAttributes: function(e) {
        this.form.findField("upload").setAttributes(e)
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Upload.LabelPanel", {
    extend: "SYNO.ux.GridPanel",
    mixins: ["SYNO.SDS.Drive.Comp.SelectionModel", "SYNO.SDS.Drive.Comp.PanelEventHandler", "SYNO.SDS.Drive.Comp.KeyEventHandler"],
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.appWin = this.findAppWindow();
        var t = {
            enableHdMenu: !1,
            hideHeaders: !0,
            loadMask: !0,
            colModel: this.getGridCM(),
            selModel: this.getSelModel(),
            store: this.getActiveStore(),
            view: this.getGridView(),
            listeners: {
                scope: this,
                activate: function() {
                    this.onRegEvent(), this.getView().focusEl.focus(100)
                },
                deactivate: function() {
                    this.unRegEvent()
                },
                rowdblclick: this.onRowDbClick
            }
        };
        Ext.apply(t, e || {}), this.callParent([t]), this.initKeyEvent()
    },
    getGridView: function() {
        return new SYNO.ux.FleXcroll.grid.BufferView({
            rowHeight: 36,
            borderHeight: 1,
            forceFit: !0,
            disableTextSelect: !0
        })
    },
    getGridCM: function() {
        return new Ext.grid.ColumnModel({
            defaults: {
                menuDisabled: !0
            },
            columns: [{
                dataIndex: "name",
                renderer: function(e, t, i, n, s, o) {
                    var r = String.format('<div id="{0}" class="syno-d-color" style="background-color:#{1}; color:#FFF;"></div>', Ext.id(), i.get("color"));
                    return r += String.format("<span>{0}<span>", Ext.util.Format.htmlEncode(e))
                }
            }]
        })
    },
    getSelModel: function() {
        return new Ext.grid.RowSelectionModel({
            singleSelect: !0
        })
    },
    getActiveStore: function() {
        return this.activeStore = this.findAppWindow().getStoreMgr().getActiveStore(), this.activeStore
    },
    isViewMasked: function() {
        return this.getGridEl().isMasked()
    },
    maskView: function(e, t) {
        this.getGridEl().mask(e, t)
    },
    unmaskView: function() {
        this.getGridEl().unmask()
    },
    onViewStoreChange: function(e, t, i) {
        this.reconfigure(this.getActiveStore(), this.getGridCM())
    },
    onRowDbClick: function(e, t, i, n) {
        var s = this.getActiveStore().getAt(t);
        this.findAppWindow().getNavigation().appendPath({
            id: s.id,
            text: s.data.name,
            skip_load: !0
        })
    },
    focusItem: function(e) {
        this.getView().focusRow(e)
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.Upload.DriveMainPanel", {
    extend: "SYNO.SDS.Drive.Comp.MainPanel",
    enableSelectDir: !1,
    constructor: function(e) {
        this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        this.callParent(arguments);
        var e = this.appWin.getEventMgr();
        this.mon(e, {
            scope: this,
            beforecategorychange: this.onBeforeSetCategory,
            nodeselectchange: this.onSelectionChange
        })
    },
    getPanelItems: function() {
        var e = this.callParent(arguments);
        return e.push(this.getLabelPanel()), e
    },
    getGrid: function() {
        return this.grid ? this.grid : this.grid = new SYNO.SDS.Drive.Upload.GridPanel({
            itemId: "list",
            hideMode: "offsets",
            mode: "grid",
            owner: this
        })
    },
    getDetailPanel: function() {
        return this.detailpanel ? this.detailpanel : this.detailpanel = new SYNO.SDS.Drive.Upload.GridPanel({
            itemId: "detail",
            hideMode: "offsets",
            mode: "detail",
            owner: this
        })
    },
    getThumbnailPanel: function() {
        return this.thumbnailpanel ? this.thumbnailpanel : this.thumbnailpanel = new SYNO.SDS.Drive.Comp.DataViewPanel({
            itemId: "thumbnail",
            cls: "syno-d-thumbnail-view",
            Dataview: SYNO.SDS.Drive.Comp.ThumbnailView,
            hideMode: "offsets",
            owner: this
        })
    },
    getTilePanel: function() {
        return this.tilepanel ? this.tilepanel : this.tilepanel = new SYNO.SDS.Drive.Comp.DataViewPanel({
            itemId: "tile",
            cls: "syno-d-tile-view",
            Dataview: SYNO.SDS.Drive.Comp.TileView,
            hideMode: "offsets",
            owner: this
        })
    },
    getLabelPanel: function() {
        return this.labelpanel ? this.labelpanel : this.labelpanel = new SYNO.SDS.Drive.Upload.LabelPanel({
            itemId: "label",
            cls: "syno-d-upload-label-panel",
            hideMode: "offsets",
            owner: this
        })
    },
    getToolbar: function() {
        return this.navitbar ? this.navitbar : this.navitbar = new Ext.Toolbar({
            height: 36,
            items: [this.getPathBar(), "->", this.getSharedItemBtn(), this.getViewModeBtn(), this.getSortBtn()],
            listeners: {
                single: !0,
                afterlayout: function(e) {
                    this.mon(e, "resize", this.onUpdatePathbar, this)
                },
                scope: this
            }
        })
    },
    onCheckToolbar: function() {
        var e = this.findAppWindow(),
            t = e.getNavigation(),
            i = t.getCategory();
        this.navitbar.get("shared_items").setVisible("shared_items" === e.getActiveCategory());
        var n = this.navitbar.get("sort"),
            s = this.navitbar.get("view_mode");
        "label" === i ? (n.setDisabled(t.isRootPath()), s.setDisabled(t.isRootPath())) : (n.setDisabled(!1), s.setDisabled(!1), this.navitbar.get("sort").setVisible(!("recent" === i || "backup" === i || "team_folder" === i && t.isRootPath()))), this.onUpdatePathbar()
    },
    onUpdatePathbar: function() {
        if (this.rendered) {
            var e = 0,
                t = this.navitbar;
            t.items.each(function(t) {
                !0 !== t.hidden && t.rendered && (e += t.getOuterSize().width)
            }), e -= this.getPathBar().getWidth();
            var i = t.getWidth() - t.getResizeEl().getPadding("lr"),
                n = i - e + 1 - 50;
            n > 0 && this.getPathBar().setWidth(n)
        }
    },
    setEnableSelectDir: function(e) {
        this.enableSelectDir = e || !1
    },
    onSelectionChange: function() {
        var e = this.getActivePanel().getSelections();
        0 === e.length || !this.enableSelectDir && this.hasDir(e) || this.beforeselectfn && !this.beforeselectfn(e) ? (this.findAppWindow().clearStatus(), this.findAppWindow().setApplyBtnDisabled(!0)) : (this.findAppWindow().setStatus(String.format(SYNO.SDS.Drive._T("upload", "items_selected"), e.length)), this.findAppWindow().setApplyBtnDisabled(!1))
    },
    hasDir: function(e) {
        var t = !1;
        return Ext.each(e, function(e) {
            if ("dir" === e.data.ntype) return t = !0, !1
        }), t
    },
    onBeforeSetCategory: function(e, t) {
        var i = this.findAppWindow().getNavigation();
        "label" !== e || e === t && !i.isRootPath() ? "label" === t && this.viewModeBtn.setPrevViewMode() : this.setActivePanel(e)
    },
    setBeforeSelection: function(e) {
        this.beforeselectfn = e
    },
    getResults: function() {
        var e = [],
            t = this.findAppWindow().getNavigation(),
            i = this.getActivePanel();
        return Ext.isFunction(i.getSelections) ? (Ext.each(i.getSelections(), function(i) {
            var n = i.data;
            n.source = "share_folder" === t.getCategory() ? "from_nas" : "from_drive", e.push(n)
        }), e) : []
    },
    isValid: function() {
        return !0
    },
    getError: function() {
        return ""
    },
    isDirty: function() {
        return 0 < this.getResults().length
    },
    setSingleSelect: function(e) {
        this.items.each(function(t) {
            this.getLabelPanel() !== t && "empty" !== t.itemId && (t.dataview ? (t.dataview.multiSelect = !e, t.dataview.singleSelect = e) : t.getSelectionModel && (t.getSelectionModel().singleSelect = e))
        }, this)
    },
    setViewSize: function(e) {
        var t = this.getActivePanel();
        this.items.each(function(i) {
            this.getLabelPanel() !== i && this.getEmptyPanel() !== i && i.dataview && i.dataview.setViewSize && i.dataview.setViewSize(e, i === t)
        }, this)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.UploadPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = {
            cls: "syno-d-upload-main-panel",
            layout: "card",
            activeItem: 0,
            items: [this.getDnDPanel(), this.getFromPCPanel()]
        };
        Ext.apply(t, e || {}), this.callParent([t]), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.findAppWindow().getEventMgr();
        this.mon(e, {
            scope: this,
            uploadfilechange: this.onFileChange
        })
    },
    getDnDPanel: function() {
        return this.dndPanel ? this.dndPanel : (this.dndPanel = new SYNO.SDS.Drive.Upload.DnDPanel({
            itemId: "dnd_panel",
            owner: this
        }), this.dndPanel)
    },
    getFromPCPanel: function() {
        return this.fromPCPanel ? this.fromPCPanel : (this.fromPCPanel = new SYNO.SDS.Drive.Upload.FromPCPanel({
            itemId: "from_pc_panel",
            owner: this
        }), this.fromPCPanel)
    },
    onFileChange: function(e, t) {
        0 < e.length && (this.fromPCPanel.addFiles(e, t), this.layout.setActiveItem("from_pc_panel"))
    },
    setFileBtnAttributes: function(e) {
        this.fromPCPanel.setFileBtnAttributes(e), this.dndPanel.setFileBtnAttributes(e)
    },
    getResults: function() {
        return this.fromPCPanel.getResults()
    },
    cleanAll: function() {
        this.fromPCPanel.cleanAll(), this.layout.setActiveItem("dnd_panel")
    },
    isValid: function() {
        return !(this.singleSelect && !this.getFromPCPanel().getGridPanel().getSelectionModel().hasSelection())
    },
    getError: function() {
        return this.singleSelect ? SYNO.SDS.Drive._T("upload", "select_one") : ""
    },
    isDirty: function() {
        return this.fromPCPanel.isDirty()
    },
    setSingleSelect: function(e) {
        this.singleSelect = e
    }
}), Ext.define("SYNO.SDS.Drive.Upload.Store.Label", {
    extend: "SYNO.SDS.Drive.ViewStore.Base",
    getAPIInfo: function() {
        return SYNO.SDS.Drive.WebAPIDesc.list_labels
    },
    getReader: function() {
        return new Ext.data.JsonReader({
            root: "items",
            id: "label_id"
        }, [{
            name: "label_id"
        }, {
            name: "name"
        }, {
            name: "color",
            convert: function(e, t) {
                return e.substr(1)
            }
        }, {
            name: "position"
        }, {
            name: "category",
            defaultValue: "label"
        }, {
            name: "type",
            defaultValue: "personal_label"
        }])
    },
    onBeforeNodeLoad: function(e, t) {
        return this.appWindow.getEventMgr().fireEvent("storebeforeload", e, t)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.Store.ShareFolder", {
    extend: "SYNO.SDS.Drive.ViewStore.Base",
    getAPIInfo: function() {
        return {
            api: "SYNO.Core.File",
            method: "list",
            version: 2
        }
    },
    getReader: function() {
        return new Ext.data.JsonReader({
            root: "files",
            id: "path"
        }, [{
            name: "file_id",
            mapping: "path"
        }, {
            name: "name"
        }, {
            name: "size",
            mapping: "additional.size"
        }, {
            name: "mtime",
            mapping: "additional.time.mtime"
        }, {
            name: "atime",
            mapping: "additional.time.atime"
        }, {
            name: "real_path",
            mapping: "additional.real_path"
        }, {
            name: "owner_name",
            mapping: "additional.owner.user"
        }, {
            name: "is_recycle_bin",
            mapping: "additional.is_recycle_bin"
        }, {
            name: "is_snapshot"
        }, {
            name: "ntype",
            convert: function(e, t) {
                return t.isdir ? "dir" : SYNO.SDS.Drive.Utils.getExt(t.name)
            }
        }, {
            name: "type",
            convert: function(e, t) {
                return t.isdir ? "dir" : "file"
            }
        }, {
            name: "thumbnail",
            convert: function(e, t) {
                var i = Ext.apply({
                    params: {
                        path: t.path,
                        size: "medium"
                    }
                }, SYNO.SDS.Drive.WebAPIDesc.get_dsm_thumbnail);
                return SYNO.API.GetBaseURL(i)
            }
        }])
    },
    parseSortInfo: function(e) {
        if (e && e.params && e.params.sort_direction && (e.params.sort_direction = e.params.sort_direction.toLowerCase()), e && e.params && e.params.sort_by) switch (e.params.sort_by) {
            case "owner_name":
                e.params.sort_by = "user"
        }
    },
    getBaseParams: function() {
        return {
            needrw: !0,
            status_filter: "valid",
            superuser: !0,
            additional: ["real_path", "size", "owner", "time", "type", "mount_point_type", "is_recycle_bin"]
        }
    },
    getLoadParam: function(e) {
        var t = this.appWindow.getNavigation(),
            i = {};
        return t.isRootPath() ? i = {
            folder_path: "/"
        } : (i = {
            folder_path: t.getLastPathId()
        }, this.pattern && (i.pattern = this.pattern)), i
    },
    onLoadStore: function(e, t) {
        e.each(function(t) {
            (t.data.is_recycle_bin || t.data.is_snapshot) && (e.remove(t), e.totalLength--)
        }), this.local_filter && e.filter(this.local_filter), this.callParent(arguments)
    },
    onExceptionStore: function(e, t, i, n, s, o) {
        var r = SYNO.API.getErrorString(s);
        s && 117 === s.code && (r = SYNO.API.getErrorString(5613)), SYNO.SDS.Drive.Upload.Store.ShareFolder.superclass.onExceptionStore.call(this, e, t, i, n, r, o)
    },
    setPattern: function(e) {
        this.pattern = e
    },
    setLocalFilter: function(e) {
        this.local_filter = e
    }
}), Ext.define("SYNO.SDS.Drive.Upload.Store.Tag", {
    extend: "SYNO.SDS.Drive.ViewStore.Node",
    getAPIInfo: function() {
        return SYNO.SDS.Drive.WebAPIDesc.list_label_files
    },
    getBaseParams: function() {
        var e = {
            offset: 0,
            limit: this.pageSize
        };
        return this.getFilter() && (e = Ext.apply({
            filter: this.getFilter()
        })), e
    },
    getLoadParam: function(e) {
        var t = this.appWindow.getNavigation(),
            i = t.getPath(),
            n = {};
        return SYNO.SDS.Drive.Utils.apply(n, {
            label_id: i[1].id
        }), n
    }
}), Ext.define("SYNO.SDS.Drive.ActionHandler.Download", {
    constructor: function(e) {
        this.appWindow = e.appWindow, this.officeDownloader = e.officeDownloader, SYNO.SDS.Drive.Utils.isDrivePage() && (this.offloadDownloader = this.appWindow.getDownloadMgr() || new SYNO.SDS.Drive.HybridShare.OffloadDownloader(e))
    },
    findAppWindow: function() {
        return this.appWindow || SYNO.SDS.Drive.GetWindow()
    },
    setTarget: function(e) {
        this.target = e
    },
    resetTarget: function() {
        this.target = null
    },
    getTargets: function() {
        return this.target ? this.target : this.findAppWindow().getPanel().getSelections()
    },
    getTargetFileIds: function() {
        return this.getTargets().map(function(e) {
            return e.get("file_id")
        })
    },
    downloadFileVersion: function(e, t, i, n) {
        e = Ext.apply(e, {
            json_error: !0
        }), SYNO.SDS.Drive.Utils.showToastMsg(this.findAppWindow(), SYNO.SDS.Drive._T("common", "preparing_download"), 3e3), SYNO.SDS.Drive.WebAPICore.download("download_revisions", e, t, i, n)
    },
    downloadNodes: function(e) {
        var t = !1;
        if (Ext.each(e, function(e) {
                if (SYNO.SDS.Drive.Utils.isOfficeFile(e.data.name)) return t = !0, !1
            }), t && !SYNO.SDS.Drive.Utils.hasOffice()) {
            var i = SYNO.SDS.Drive._T("app", "install_office_alert");
            return SYNO.SDS.Drive.Define.Info.office_migration && (i = SYNO.SDS.Drive._T("app", "migration_office")), void SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), i)
        }
        if (1 === e.length) return this.downloadNode(e[0]);
        var n = this.findAppWindow().getNavigation(),
            s = n.getLastPath().text,
            o = [],
            r = [];
        return Ext.each(e, function(e) {
            var t = e.data.file_id;
            o.push(t), r.push({
                file_id: t,
                name: e.data.name
            })
        }), this.downloadAsZip(s, r, {
            file_id: o
        }, "recycle" === n.getCategory())
    },
    downloadAsZip: function(e, t, i, n) {
        i = Ext.apply({
            dry_run: !0,
            archive_name: e
        }, SYNO.SDS.Drive.Utils.prepareRequestParams(i)), i.force_download = !0, i.json_error = !0;
        var s, o, r = e + ".zip";
        n ? (o = i.files, i.files = [], Ext.each(o, function(e) {
            i.files.push({
                path: e,
                version_id: 0
            })
        }), s = "download_revisions") : s = "download_files";
        var a = [];
        SYNO.SDS.Drive.WebAPICore.send(s, i, function(e, n) {
            if (!e) return void SYNO.SDS.Drive.Utils.showErrorMsg(this.findAppWindow(), n);
            if (delete i.dry_run, n.result && 0 < n.result.length) {
                if (!SYNO.SDS.Drive.Utils.hasOffice()) return void(SYNO.SDS.Drive.Define.Info.office_migration ? SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), SYNO.SDS.Drive._T("app", "migration_office")) : SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), SYNO.SDS.Drive._T("app", "install_office_alert")));
                this._showPasswordDialog(n.result, function(e, n, o, l) {
                    if (Ext.each(t, function(e) {
                            -1 === o.indexOf(e.file_id) && a.push(e.name)
                        }), Ext.isEmpty(a)) return void e.setStatusError({
                        text: _T("common", "err_pass"),
                        clear: !0
                    });
                    if (i.decrypt = n, l) {
                        var d = function(t) {
                            "yes" === t && (e.close(), this._postDownloadNodes(s, i, a, r))
                        };
                        e.getMsgBox().confirm("", SYNO.SDS.Drive._T("confirm", "no_password"), d, this)
                    } else e.close(), this._postDownloadNodes(s, i, a, r)
                }, this)
            } else a = t.map(function(e) {
                return e.name
            }), this._postDownloadNodes(s, i, a, r)
        }, this)
    },
    downloadNode: function(e) {
        var t = SYNO.SDS.Drive.Utils.getNtype(e.data.name, e.data.type);
        switch (SYNO.SDS.Drive.Utils.getFileTypeMapping(t)) {
            case "dir":
                var i = this.findAppWindow().getNavigation(),
                    n = e.data.name;
                return void this.downloadAsZip(n, [{
                    file_id: e.data.file_id,
                    name: n
                }], {
                    file_id: this.getTargetFileIds() || [e.data.file_id]
                }, "recycle" === i.getCategory());
            case "office":
                return SYNO.SDS.Drive.Utils.hasOffice() ? this.officeDownloader.downloadOffice(e) : void(SYNO.SDS.Drive.Define.Info.office_migration ? SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), SYNO.SDS.Drive._T("app", "migration_office")) : SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), SYNO.SDS.Drive._T("app", "install_office_alert")));
            case "regular":
                return SYNO.SDS.Drive.Utils.isDrivePage() && this._allowOffload([e]) ? this.offloadDownloader.download(e) : this._downloadFile(SYNO.SDS.Drive.Utils.getPathId(e.data.file_id), e.data.name, e.data.removed)
        }
    },
    _downloadFile: function(e, t, i) {
        var n = {};
        i ? (n.files = [{
            path: e,
            version_id: 0
        }], this.downloadFileVersion(n, t)) : (n.files = [e], n.force_download = !0, n.json_error = !0, SYNO.SDS.Drive.Utils.showToastMsg(this.findAppWindow(), SYNO.SDS.Drive._T("common", "preparing_download"), 3e3), SYNO.SDS.Drive.WebAPICore.download("download_files", n, t))
    },
    _postDownloadNodes: function(e, t, i, n) {
        i = Ext.isArray(i) ? i : [i], this.findAppWindow().getTaskMgr().addTask(SYNO.SDS.Drive.TaskFactory.createDownloadBgTask({
            title: "download",
            params: t,
            name: i
        }, e, n))
    },
    _showPasswordDialog: function(e, t, i) {
        new SYNO.SDS.Drive.PasswordDialog({
            files: e,
            listeners: {
                scope: this,
                apply: function() {
                    t && Ext.isFunction(t) && t.apply(i, arguments)
                }
            }
        }).show()
    },
    _allowOffload: function(e) {
        return !!SYNO.SDS.Drive.Utils.isDSM7OrAbove() && (!!this.offloadDownloader.isOffloadSupport(e) && "disallow" !== this.findAppWindow().appInstance.getUserSettings("offload_setting"))
    }
}), Ext.define("SYNO.SDS.Drive.Action", {
    constructor: function(e) {
        this.appWindow = e.appWindow, this.target = e.target, this.downloadHandler = new SYNO.SDS.Drive.ActionHandler.Download(Ext.applyIf(e, {
            officeDownloader: this
        }))
    },
    clone: function() {
        return new SYNO.SDS.Drive.Action(this)
    },
    setTarget: function(e) {
        this.target = e, this.downloadHandler.setTarget(e)
    },
    resetTarget: function() {
        this.target = null, this.downloadHandler.resetTarget()
    },
    getTargets: function() {
        return this.target ? this.target : this.findAppWindow().getPanel().getSelections()
    },
    getTarget: function() {
        return this.getTargets().length > 0 ? this.getTargets()[0] : null
    },
    getTargetFileIds: function() {
        return this.getTargets().map(function(e) {
            return e.get("file_id")
        })
    },
    findAppWindow: function() {
        return this.appWindow || SYNO.SDS.Drive.GetWindow()
    },
    initInfoData: function(e) {
        Ext.apply(SYNO.SDS.Drive.Define.Info, e), SYNO.SDS.Drive.Define.Info.ready = !0
    },
    initSettingData: function(e) {
        Ext.apply(SYNO.SDS.Drive.Define.Info, e);
        var t = SYNO.SDS.Drive.Define.Info.sharing_permission;
        SYNO.SDS.Drive.Define.Info.disabled_all_sharing = !(t.internal_link_sharing || t.invite_sharing || t.public_sharing), SYNO.SDS.Drive.Define.Info.use_nickname = "nickname" === (SYNO.SDS.Drive.Define.Info.displayname_result || SYNO.SDS.Drive.Define.Info.default_displayname), SYNO.SDS.Drive.Define.Info.settingready = !0
    },
    initEnv: function() {
        var e = this.findAppWindow(),
            t = this;
        e.getWebAPI().initial({
            callback: function(i, n) {
                var s = function() {
                    var s, o;
                    if (i && !n.has_fail ? (s = SYNO.API.Util.GetValByAPI(n, SYNO.SDS.Drive.WebAPIDesc.info.api, SYNO.SDS.Drive.WebAPIDesc.info.method), t.initInfoData(s), s = SYNO.API.Util.GetValByAPI(n, SYNO.SDS.Drive.WebAPIDesc.get_setting.api, SYNO.SDS.Drive.WebAPIDesc.get_setting.method), t.initSettingData(s), e.getEventMgr().fireEvent("envready", this), e.getEventMgr().fireEvent("settingready", this)) : o = SYNO.SDS.Drive.Utils.getErrorStr(SYNO.API.Util.GetFirstError(n)), o) return void e.getEl().mask(o, "syno-ux-mask-info")
                };
                e.rendered ? s.call(e) : e.mon(e, "afterlayout", s, this, {
                    single: !0,
                    buffer: 80
                })
            },
            scope: e
        }), e.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: [SYNO.SDS.Drive.WebAPIDesc.office_status]
            },
            callback: function(t, i) {
                if (t && !i.has_fail) {
                    var n = SYNO.SDS.Drive.WebAPIDesc.office_status;
                    if (SYNO.API.Util.GetValByAPI(i, n.api, n.method).migration) {
                        SYNO.SDS.Drive.Define.Info.office_migration = !0;
                        var s = e.addWebAPITask(Ext.apply({
                            interval: 5e3,
                            scope: this,
                            callback: function(e, t) {
                                e && !t.has_fail && !t.migration && t.start && (s.stop(), function() {
                                    SYNO.API.Request({
                                        api: "SYNO.Core.Desktop.Initdata",
                                        method: "get",
                                        version: 1,
                                        params: {
                                            action: "jsconfig"
                                        },
                                        callback: function(e, t, i, n) {
                                            e && (SYNO.SDS.Config.JSConfig = t.JSConfig, SYNO.SDS.Strings = t.Strings, SYNO.SDS.ServiceStatus = t.ServiceStatus, SYNO.SDS.AppPrivilege = t.AppPrivilege, SYNO.SDS.UrlTag = t.UrlTag, SYNO.SDS.JSLoad.init(), SYNO.SDS.appendMissingCSSFiles(t.CSSFiles), SYNO.SDS.JSLoad("SYNO.SDS.Office.Drive", function() {
                                                SYNO.SDS.Drive.Define.Info.office_migration = !1
                                            }))
                                        }
                                    })
                                }.defer(1e3))
                            }
                        }, SYNO.SDS.Drive.WebAPIDesc.office_status));
                        s.start(!1)
                    }
                }
            },
            scope: e
        })
    },
    waitSettingReady: function() {
        if (this.waitSettingReadyPromise) return this.waitSettingReadyPromise;
        var e;
        return e = SYNO.SDS.Drive.Define.Info.settingready ? Promise.resolve() : new Promise(function(e) {
            this.findAppWindow().getEventMgr().on("settingready", e, null, {
                single: !0
            })
        }.bind(this)), this.waitSettingReadyPromise = e
    },
    prepareParam: function(e) {
        return SYNO.SDS.Drive.Utils.prepareRequestParams(e)
    },
    onCreateCallBack: function(e, t, i, n) {
        var s = this.findAppWindow();
        return !1 !== n && s.setStatusBusy(),
            function(o, r, a, l, d) {
                !1 !== n && s.clearStatusBusy(), Ext.isFunction(t) && t.call(i || window, o, r || {}, a, l, d), (o || !1 === n) && s.getEventMgr().fireEvent(e, o, r, a || {}, l, e, d)
            }
    },
    createNode: function(e, t, i) {
        var n = this.findAppWindow(),
            s = new SYNO.SDS.Drive.CreateWindow({
                owner: i instanceof SYNO.SDS.Drive.ModalWindow ? i : n,
                listeners: {
                    scope: this,
                    apply: function(o, r, a) {
                        n.getWebAPI().createNode({
                            params: {
                                type: "folder",
                                conflict_action: "autorename",
                                path: String.format("{0}/{1}", SYNO.SDS.Drive.Utils.getPathId(e.file_id), a[o.nameItemId])
                            },
                            scope: this,
                            callback: this.onCreateCallBack("createnodedone", Ext.createSequence(t || Ext.emptyFn, function() {
                                s.onApplyCb.apply(s, arguments)
                            }.createDelegate(n), i || window), i || window)
                        })
                    }
                }
            });
        s.show()
    },
    renameNode: function(e, t, i) {
        new SYNO.SDS.Drive.RenameNodeWindow({
            initName: e.name,
            blDir: e.blDir,
            owner: this.findAppWindow(),
            listeners: {
                scope: this,
                apply: function(n, s, o) {
                    var r = {
                        name: o[n.nameItemId]
                    };
                    e.file_id && (r = Ext.apply(r, {
                        file_id: e.file_id
                    })), this.findAppWindow().getAction().setNodeTitle(r, Ext.createSequence(t || Ext.emptyFn, function() {
                        n.onApplyCb.apply(n, arguments)
                    }.createDelegate(this.findAppWindow()), i || window), i || window)
                }
            }
        }).show()
    },
    getChannelMap: function(e, t, i) {
        this.findAppWindow().getWebAPI().getChannelMap({
            params: e,
            scope: i,
            callback: this.onCreateCallBack("getchannelmapdone", t, i, !1)
        })
    },
    getGroupMap: function(e, t, i) {
        this.findAppWindow().getWebAPI().getGroupMap({
            params: e,
            scope: i,
            callback: this.onCreateCallBack("getgroupmapdone", t, i, !1)
        })
    },
    getMyDrive: function(e, t) {
        var i = SYNO.SDS.Drive.Define.Info,
            n = {
                path: "/mydrive"
            };
        if (i.mydrive_node) return void e.call(t || window, !0, i.mydrive_node, n);
        this.findAppWindow().getWebAPI().getNode({
            params: n,
            callback: Ext.createSequence(function(e, t) {
                e && (i.mydrive_node = t, i.drive_id = t.file_id)
            }, e || Ext.emptyFn, t || window)
        })
    },
    getNode: function(e, t, i) {
        this.findAppWindow().getWebAPI().getNode({
            params: this.prepareParam(e),
            scope: i,
            callback: this.onCreateCallBack("getnodedone", t || Ext.emptyFn, i || window, !1)
        })
    },
    copyNode: function(e, t, i) {
        i && i.close(), this.mvcpNode("copy", e, t)
    },
    copyNodeTo: function(e, t, i, n, s, o) {
        var r = new SYNO.SDS.Drive.CopyToWindow({
            title: SYNO.SDS.Drive._T("action", "copy_to"),
            hideCreate: !1,
            hideForm: n,
            formText: n ? void 0 : o,
            action: "copy",
            owner: s || this.findAppWindow(),
            listeners: {
                scope: this,
                choose: function(t, i, n) {
                    this.copyNode(Ext.apply({
                        to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(i.attributes.file_id),
                        to_parent_folder_name: i.attributes.text
                    }, e || {}), void 0, r)
                },
                show: function(e) {
                    this.onTreeDlgGotoPath(e)
                }
            }
        });
        r.show()
    },
    moveNode: function(e, t, i) {
        i && i.close(), this.mvcpNode("move", e, t)
    },
    moveNodeTo: function(e, t, i) {
        new SYNO.SDS.Drive.TreeWindow({
            title: SYNO.SDS.Drive._T("action", "move_to"),
            hideCreate: !1,
            hideForm: !0,
            action: "move",
            owner: this.findAppWindow(),
            listeners: {
                scope: this,
                choose: function(t, i) {
                    this.moveNode(Ext.apply({
                        to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(i.attributes.file_id),
                        to_parent_folder_name: i.attributes.text
                    }, e || {}), void 0, t)
                },
                show: function(e) {
                    this.onTreeDlgGotoPath(e)
                }
            }
        }).show()
    },
    onTreeDlgGotoPath: function(e, t) {
        if (!t) return void e.onGoToPath([]);
        e.setStatusBusy(), this.findAppWindow().getWebAPI().getNode({
            params: this.prepareParam(t),
            scope: this,
            callback: function(t, i) {
                if (e.clearStatusBusy(), t && !i.removed) {
                    var n, s, o = i.display_path,
                        r = o.split("/"),
                        a = [],
                        l = "file" === i.type;
                    if ("/" === o.charAt(0) && r.splice(0, 1), Ext.each(r, function(e, t) {
                            if (!l || r.length - 1 !== t)
                                if (0 !== t) a.push(s + r.slice(1, t + 1).join("/"));
                                else switch (e) {
                                    case "mydrive":
                                        s = "/mydrive/", n = "node";
                                        break;
                                    case "team-folders":
                                        s = "/team-folders/", n = "team_folder";
                                        break;
                                    default:
                                        return !1
                                }
                        }), e.onGoToPath([{
                            id: n
                        }]), 0 !== a.length) {
                        var d, h = e.getTree().getSelectionModel().getSelectedNode();
                        h && (d = h.id), this.findAppWindow().getWebAPI().getNodes({
                            params: {
                                path: a
                            },
                            scope: this,
                            callback: function(t, i) {
                                if (t && !i.has_fail && !e.getTree().isDestroyed) {
                                    var s = e.getTree().getSelectionModel().getSelectedNode();
                                    if (!s || d === s.id) {
                                        var o = [{
                                            id: n
                                        }];
                                        Ext.each(i.result, function(e) {
                                            var t = e.data;
                                            if ("dir" !== t.type) return !1;
                                            var i = t.name;
                                            i || (i = SYNO.SDS.Drive.Utils.getBaseName(t.display_path)), o.push({
                                                id: t.file_id,
                                                text: i,
                                                perm: t.capabilities,
                                                display_path: t.display_path
                                            })
                                        }), e.onGoToPath(o)
                                    }
                                }
                            }
                        })
                    }
                }
            }
        })
    },
    mvcpNode: function(e, t, i, n) {
        var s = String.format("{0}_files", e),
            o = Ext.applyIf(t || {}, {
                dry_run: !0
            });
        if (o.conflict_action || !1 === o.dry_run) return delete o.dry_run, void this.doMvcpNode(e, o, i, n);
        SYNO.SDS.Drive.WebAPICore.sendPromise(s, o).then(function(t) {
            delete o.dry_run, t.result && 0 < t.result.length ? this.showConflictDialog(e, t.result, function(t) {
                this.doMvcpNode(e, o, i, n, t)
            }, this) : this.doMvcpNode(e, o, i, n)
        }.bind(this)).catch(function(e) {
            SYNO.SDS.Drive.Utils.showErrorMsg(this.findAppWindow(), e)
        }.bind(this))
    },
    doMvcpNode: function(e, t, i, n, s) {
        t.conflict_action || (t.conflict_action = s || "autorename"), this.postMvcpNode(e, t, i, n)
    },
    postMvcpNode: Ext.emptyFn,
    cleanNode: function(e, t, i) {
        var n = this.findAppWindow(),
            s = SYNO.SDS.Drive._T("recycle", "clean_all_confirm");
        n.getMsgBox().confirmDelete("", s, function(t) {
            "yes" === t && n.getTaskMgr().addTask(SYNO.SDS.Drive.TaskFactory.createEmptyRecycleTask(e.path, e.name))
        }, this)
    },
    postDeleteNode: function(e, t, i) {
        this.findAppWindow().getWebAPI().deleteNode({
            params: e,
            scope: this,
            callback: this.onCreateCallBack("deletenodedone", t, i)
        })
    },
    deleteNode: function(e, t, i) {
        var n, s = this.findAppWindow(),
            o = SYNO.SDS.Drive._T;
        e = this.prepareParam(e);
        var r = 1 === e.files.length;
        n = !e.permanent && e.revisions > 0 ? r ? o("file", "recycle_confirm_one") : o("file", "recycle_confirm") : r ? o("file", "delete_confim_one") : o("file", "delete_confim"), r || (n = String.format(n, e.files.length)), s.getMsgBox().confirmDelete("", n, function(n) {
            "yes" === n && this.postDeleteNode(e, t, i)
        }, this)
    },
    restoreNode: function(e, t, i) {
        this.findAppWindow().getWebAPI().restoreNode({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("restorenodedone", t, i)
        })
    },
    restoreFileVersion: function(e, t) {
        var i = e || {};
        SYNO.SDS.Drive.WebAPICore.sendPromise("restore_revisions", i).then(function(e) {
            delete i.dry_run, e.result && 0 < e.result.length ? this.showConflictDialog("restore", e.result, function(e) {
                this.doRestoreFileVersion(i, t, e)
            }, this) : this.doRestoreFileVersion(i, t)
        }.bind(this)).catch(function(e) {
            SYNO.SDS.Drive.Utils.showErrorMsg(this.findAppWindow(), e)
        }.bind(this))
    },
    doRestoreFileVersion: function(e, t, i, n, s) {
        e.conflict_action || (e.conflict_action = i || "autorename"), this.postRestoreNode(e, t)
    },
    postRestoreNode: Ext.emptyFn,
    setNode: function(e, t, i) {
        this.findAppWindow().getWebAPI().setNode({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("setnodedone", t, i)
        })
    },
    setNodeTitle: function(e, t, i) {
        this.findAppWindow().getWebAPI().setNode({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("setnodetitledone", t, i)
        })
    },
    setNodeTag: function(e, t, i, n) {
        this.findAppWindow().getWebAPI().setNodeTag({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("setnodetagdone", t, i, !1)
        })
    },
    shareNode: function(e) {
        e = this.prepareParam(e), new SYNO.SDS.Drive.Share.Window(Ext.apply({
            owner: this.findAppWindow()
        }, e)).show()
    },
    setNodePerm: function(e, t, i) {
        this.findAppWindow().getWebAPI().setNodePerm({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("setnodepermdone", t, i)
        })
    },
    deleteNodePerm: function(e, t, i) {
        if (e = this.prepareParam(e), e.files) {
            var n = [],
                s = [];
            Ext.each(e.files, function(t) {
                n.push("share_file"), s.push({
                    path: t,
                    permissions: [{
                        action: "delete",
                        member: {
                            type: "user",
                            name: e.username
                        }
                    }]
                })
            }), SYNO.SDS.Drive.WebAPICore.send(n, s, this.onCreateCallBack("deletenodepermdone", t, i))
        } else this.findAppWindow().getWebAPI().deleteNodePerm({
            params: e,
            scope: this,
            callback: this.onCreateCallBack("deletenodepermdone", t, i)
        })
    },
    infoNode: function(e) {
        new SYNO.SDS.Drive.Info.Window(Ext.apply({
            owner: this.findAppWindow()
        }, this.prepareParam(e))).show()
    },
    createTag: function(e, t, i) {
        this.findAppWindow().getWebAPI().createTag({
            params: e,
            scope: this,
            callback: this.onCreateCallBack("createtagdone", t, i)
        })
    },
    setTag: function(e, t, i, n, s) {
        this.findAppWindow().getWebAPI().setTag({
            params: e,
            scope: this,
            callback: !1 === s ? t : this.onCreateCallBack("settagdone", t, i, !1)
        })
    },
    deleteTag: function(e, t, i) {
        this.findAppWindow().getWebAPI().deleteTag({
            params: e,
            scope: this,
            callback: this.onCreateCallBack("deletetagdone", t, i)
        })
    },
    setShortcut: function(e, t, i) {
        this.findAppWindow().getWebAPI().setShortcut({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("setshortcutdone", t, i, !1)
        })
    },
    deleteShortcut: function(e, t, i) {
        this.findAppWindow().getWebAPI().deleteShortcut({
            params: this.prepareParam(e),
            scope: this,
            callback: this.onCreateCallBack("deleteshortcutdone", t, i, !1)
        })
    },
    openFile: function(e) {
        var t = {},
            i = SYNO.SDS.Drive.Utils.getPathId(e.get("file_id")),
            n = e.get("name");
        t = "recycle" === this.findAppWindow().getNavigation().getCategory() ? Ext.apply({
            params: {
                files: [{
                    path: i,
                    version_id: 0
                }],
                force_download: !1
            }
        }, SYNO.SDS.Drive.WebAPIDesc.download_revisions) : Ext.apply({
            params: {
                files: [i],
                force_download: !1
            }
        }, SYNO.SDS.Drive.WebAPIDesc.download_files);
        var s = SYNO.API.GetBaseURL(t, !0, n);
        window.open(Ext.urlAppend(s, "_dc=" + (new Date).getTime()))
    },
    listRecent: function(e, t, i) {
        this.findAppWindow().getWebAPI().listRecent({
            params: e,
            callback: t,
            scope: i
        })
    },
    setChatChannel: function(e, t, i) {
        this.findAppWindow().getWebAPI().setChatChannel({
            params: e,
            callback: t,
            scope: i
        })
    },
    requestAccess: function(e, t, i) {
        this.findAppWindow().getWebAPI().requestAccess({
            params: this.prepareParam(e),
            callback: t,
            scope: i
        })
    },
    convertOffice: function(e, t) {
        var i = this.prepareParam(e) || {};
        i.conflict_action || (i.conflict_action = "autorename"), this.postConvertOffice(e, t)
    },
    postConvertOffice: function(e, t) {
        t = Ext.isArray(t) ? t : [t];
        var i = SYNO.SDS.Drive.TaskFactory.createConvertBgTask({
            params: e,
            name: t
        });
        this.findAppWindow().getTaskMgr().addTask(i)
    },
    showConflictDialog: function(e, t, i, n) {
        var s = [];
        Ext.each(t, function(e) {
            s.push({
                src: {
                    file_id: e.src_info.file_id,
                    name: e.src_info.name,
                    path: SYNO.SDS.Drive.Utils.parseDisplayPath(e.src_info.display_path),
                    size: e.src_info.size,
                    mtime: e.src_info.modified_time,
                    file_type: e.src_info.file_type,
                    renamed: SYNO.SDS.Drive.Utils.parseDisplayName(e.renamed)
                },
                dest: {
                    file_id: e.dst_info.file_id,
                    name: e.dst_info.name,
                    path: SYNO.SDS.Drive.Utils.parseDisplayPath(e.dst_info.display_path),
                    size: e.dst_info.size,
                    mtime: e.dst_info.modified_time,
                    file_type: e.dst_info.file_type
                }
            })
        }), new SYNO.SDS.Drive.Conflict.Dialog({
            action: e,
            conflicts: s,
            listeners: {
                scope: this,
                doaction: function(e) {
                    i && Ext.isFunction(i) && i.call(n, e)
                }
            }
        }).show()
    },
    syncDevice: function(e, t, i) {
        var n = [];
        Ext.isEmpty(e.enable) || n.push(Ext.apply({
            params: this.prepareParam({
                file_id: e.enable,
                enable_sync: !0
            })
        }, SYNO.SDS.Drive.WebAPIDesc.sync_to_device)), Ext.isEmpty(e.disable) || n.push(Ext.apply({
            params: this.prepareParam({
                file_id: e.disable,
                enable_sync: !1
            })
        }, SYNO.SDS.Drive.WebAPIDesc.sync_to_device)), this.findAppWindow().getWebAPI().syncDevice({
            params: n,
            callback: this.onCreateCallBack("syncdevicedone", t, i)
        })
    },
    updateRecently: function(e, t, i) {
        this.findAppWindow().getWebAPI().setNode({
            params: {
                path: SYNO.SDS.Drive.Utils.getPathId(e)
            },
            callback: t,
            scope: i
        })
    },
    syncPluginString: function(e) {
        this.findAppWindow().getWebAPI().syncPluginString({
            params: {
                app: e
            },
            callback: function(e, t) {
                if (e)
                    for (var i in t) t.hasOwnProperty(i) && (SYNO.SDS.Strings[i] = t[i])
            }
        })
    },
    getUserSetting: function(e, t) {
        this.findAppWindow().getWebAPI().getUserSetting({
            callback: e,
            scope: t
        })
    },
    downloadOffice: Ext.emptyFn,
    downloadFileVersion: function(e, t, i, n) {
        return this.downloadHandler.downloadFileVersion(e, t, i, n)
    },
    downloadAsZip: function(e, t, i, n) {
        return this.downloadHandler.downloadAsZip(e, t, i, n)
    },
    downloadNode: function(e) {
        return this.downloadNodes([e])
    },
    downloadNodes: function(e) {
        return this.downloadHandler.downloadNodes(e)
    },
    downloadSelectedNodes: function() {
        this.downloadNodes(this.getTargets())
    }
}), Ext.define("SYNO.SDS.Drive.Upload.ActionMgr", {
    extend: "SYNO.SDS.Drive.Action",
    openNode: function() {
        var e = this.findAppWindow(),
            t = e.GetOneSeleted();
        if (t) {
            if ("dir" === t.data.ntype) {
                var i = t.data;
                return void e.getNavigation().appendPath({
                    id: t.id,
                    text: i.name,
                    perm: i.capabilities,
                    display_path: i.display_path
                })
            }
            e.getAllowDblClick() && e.onApply()
        }
    }
}), Ext.define("SYNO.SDS.Drive.StoreMgr", {
    extend: "Ext.Component",
    publicEventMap: {
        createnodedone: "onCreateNodeDone",
        convertofficedone: "onConvertOfficeDone",
        setnodepermdone: "onSetNodePermDone",
        deletenodepermdone: "onDeleteNodepermDone",
        deletetagdone: "onUpdateNodeStoreReload",
        settagdone: "onUpdateNodeStoreReload",
        copynodedone: "onCopyNodeDone",
        encryptnodedone: "onEncryptNodeDone",
        setnodedone: "onSetNodeDone",
        movenodedone: "onMoveNodeDone",
        setnodetitledone: "onSetNodeTitleDone",
        deletenodedone: "onDeleteNodeDone",
        restorenodedone: "onRestoreNodeDone",
        categorychange: "onCategoryChange",
        pathchange: "onPathChange",
        updatenode: "onUpdateNodeStoreReloadByObject",
        uploadcomplete: "onUploadComplete",
        syncdevicedone: "onSyncDeviceDone",
        cleannodedone: "onCleanNodeDone"
    },
    privateEventMap: {
        setnodetagdone: "onSetNodeTagDone",
        setshortcutdone: "onSetShortcutDone",
        deleteshortcutdone: "onDeleteShortcutDone"
    },
    constructor: function(e) {
        this.appWindow = e.appWindow, this.callParent(arguments), this.createStores(), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.appWindow.getEventMgr();
        this.blRegEvent || (Ext.iterate(this.publicEventMap, function(t) {
            var i = this.publicEventMap[t];
            this.mon(e, t, this[i], this)
        }, this), SYNO.SDS.Drive.WindowHelper.isPublicShare() || Ext.iterate(this.privateEventMap, function(t) {
            var i = this.privateEventMap[t];
            this.mon(e, t, this[i], this)
        }, this))
    },
    createStores: function() {
        this.stores = {
            node: new SYNO.SDS.Drive.ViewStore.Node({
                appWindow: this.appWindow
            }),
            shared_with_me: new SYNO.SDS.Drive.ViewStore.SharedWithMe({
                appWindow: this.appWindow
            }),
            sharing_to_others: new SYNO.SDS.Drive.ViewStore.SharingToOther({
                appWindow: this.appWindow
            }),
            backup: new SYNO.SDS.Drive.ViewStore.Backup({
                appWindow: this.appWindow
            }),
            team_folder: new SYNO.SDS.Drive.ViewStore.TeamFolder({
                appWindow: this.appWindow
            }),
            recycle: new SYNO.SDS.Drive.ViewStore.Recycle({
                appWindow: this.appWindow
            }),
            recent: new SYNO.SDS.Drive.ViewStore.Recent({
                appWindow: this.appWindow
            }),
            starred: new SYNO.SDS.Drive.ViewStore.Starred({
                appWindow: this.appWindow
            }),
            search: new SYNO.SDS.Drive.ViewStore.Search({
                appWindow: this.appWindow
            }),
            tag: new SYNO.SDS.Drive.ViewStore.Tag({
                appWindow: this.appWindow
            })
        }, this.activeStore = this.stores.node
    },
    getStore: function(e) {
        return this.stores[e]
    },
    getActiveStore: function() {
        return this.activeStore
    },
    onCategoryChange: function(e, t, i) {
        "search" !== e && e === i || (this.stores.hasOwnProperty(e) ? this.activeStore = this.stores[e] : this.activeStore = this.stores.tag, "search" === e && this.activeStore.cleanParams(), this.onStoreReload(!0, SYNO.SDS.Drive.Utils.apply(t || {}, {
            params: {
                offset: 0,
                limit: 1e3
            }
        })), this.appWindow.getEventMgr().fireEvent("viewstorechange", e, t, this.activeStore))
    },
    onPathChange: function(e, t, i, n) {
        if (n) {
            var s, o = this.appWindow.getNavigation();
            s = o.isRootPath() ? this.stores.hasOwnProperty(i) ? this.stores[i] : this.stores.tag : "recycle" !== i ? this.stores.node : this.activeStore, s !== this.activeStore && (this.activeStore = s, this.appWindow.getEventMgr().fireEvent("viewstorechange", i, null, this.activeStore)), "search" !== i && this.onStoreReload(!0, {
                params: {
                    offset: 0,
                    limit: 1e3
                }
            }, !0)
        }
    },
    getObjectByFileId: function(e) {
        var t, i = this.getActiveStore();
        if (Ext.isArray(e)) {
            for (var n = 0; n < e.length; n++)
                if (t = i.getById(e[n])) return t;
            return !1
        }
        return (t = i.getById(e)) || !1
    },
    getObject: function(e) {
        var t, i = this.getActiveStore();
        Ext.isArray(e) || (e = [e]);
        for (var n = 0; n < e.length; n++) {
            var s = e[n].split(":");
            if ((s.length < 2 || "link" !== s[0]) && (t = this.getObjectByFileId(s[1]))) return t;
            var o = i.findExact("permanent_link", s[1]);
            if (-1 !== o && (t = i.getAt(o))) return t
        }
        return !1
    },
    getObjectByDisplayPath: function(e) {
        var t, i = this.getActiveStore();
        Ext.isArray(e) || (e = [e]);
        for (var n = 0; n < e.length; n++) {
            var s = i.findExact("display_path", e[n]);
            if (-1 !== s && (t = i.getAt(s))) return t
        }
        return !1
    },
    findNextFocusIdx: function() {
        var e = this.appWindow.getPanel();
        if (!e.getSelectionModel) return -1;
        var t = e.getSelectionModel().getSelections();
        if (Ext.isEmpty(t)) return -1;
        var i = e.getStore().getTotalCount() - t.length - 1;
        return Ext.each(t, function(t) {
            i = Math.min(i, e.getStore().indexOf(t))
        }), i
    },
    onCreateNodeDone: function(e, t, i, n) {
        var s = this.appWindow.getNavigation();
        if ("recycle" !== s.getCategory()) {
            var o, r = s.getLastPathId();
            t && (t.parent_id ? o = t.parent_id : t.result && t.result.params && t.result.params.to_parent_folder && (o = SYNO.SDS.Drive.Utils.getFileIdFromPathId(t.result.params.to_parent_folder))), r === o && this.onStoreReload(!1, void 0, !1, n)
        }
    },
    onConvertOfficeDone: function(e, t, i) {
        if (e && t) {
            var n = this.appWindow,
                s = n.getNavigation();
            if ("recycle" !== s.getCategory()) {
                var o = s.getLastPathId();
                Ext.each(t.result.params.files, function(e) {
                    if (o === e.parent_id) return this.onStoreReload(), !1
                }, this)
            }
        }
    },
    onSetNodePermDone: function(e, t, i) {
        e && this.onUpdateNodeStoreReloadByObject(i.file_id)
    },
    onDeleteNodepermDone: function(e, t, i) {
        e && this.onUpdateNodeStoreReloadByObject(i.file_id)
    },
    onCopyNodeDone: function(e, t, i) {
        if (e && "recycle" !== this.appWindow.getNavigation().getCategory()) {
            var n = this.appWindow.getNavigation().getLastPathId();
            SYNO.SDS.Drive.Utils.getFileIdFromPathId(i.to_parent_folder) === n && this.onStoreReload()
        }
    },
    onEncryptNodeDone: function(e, t, i) {
        if (e && t) {
            var n = this.appWindow.getNavigation();
            "recycle" !== n.getCategory() && (t.parent_id === n.getLastPathId() || this.getObjectByDisplayPath(t.display_path)) && this.onStoreReload()
        }
    },
    onSetNodeDone: function(e, t, i) {
        e && "recycle" !== this.appWindow.getNavigation().getCategory() && this.getObjectByFileId(t.file_id) && this.onStoreReload()
    },
    onMoveNodeDone: function(e, t, i) {
        if (i && "recycle" !== this.appWindow.getNavigation().getCategory()) {
            var n = this.appWindow.getNavigation().getLastPathId();
            if (SYNO.SDS.Drive.Utils.getFileIdFromPathId(i.to_parent_folder) === n) return void this.onStoreReload();
            var s;
            Ext.each(i.files, function(e) {
                if (s = this.getObject(e)) return this.onStoreReload(), !1
            }, this)
        }
    },
    onSetNodeTitleDone: function(e, t, i) {
        if (e && "recycle" !== this.appWindow.getNavigation().getCategory()) {
            var n = this.getObjectByFileId(t.file_id);
            n && n.data.name !== i.name && (n.data.name = t.name, n.data.display_path = t.display_path, n.data.path = t.path, n.commit())
        }
    },
    onDeleteNodeDone: function(e, t, i) {
        if (e) switch (this.appWindow.getNavigation().getCategory()) {
            case "recycle":
                this.onStoreReload(void 0, void 0, void 0, void 0, !0);
                break;
            default:
                Ext.each(i.files, function(e) {
                    if (this.getObject(e)) return this.onStoreReload(void 0, void 0, void 0, void 0, !0), !1
                }, this)
        }
    },
    onCleanNodeDone: function(e, t, i) {
        if (e) {
            var n = this.appWindow.getNavigation();
            "recycle" === n.getCategory() && (n.isRootPath() ? this.onStoreReload() : n.setCategoryAndPath("recycle"))
        }
    },
    onRestoreNodeDone: function(e, t, i) {
        if (e) {
            switch (this.appWindow.getNavigation().getCategory()) {
                case "recycle":
                    Ext.each(i.files, function(e) {
                        if (this.getObject(e.path)) return this.onStoreReload(), !1
                    }, this);
                    break;
                default:
                    this.onStoreReload()
            }
        }
    },
    onUpdateNodeStoreReloadByObject: function(e) {
        e && !this.getObjectByFileId(e) || this.onUpdateNodeStoreReload()
    },
    onUpdateNodeStoreReload: function() {
        switch (this.appWindow.getNavigation().getCategory()) {
            case "recycle":
                break;
            default:
                this.onStoreReload()
        }
    },
    onSetNodeTagDone: function(e, t, i) {
        if (!e) return void this.onStoreReload();
        var n = !1;
        Ext.each(i.files, function(e) {
            var t = this.getObject(e);
            if (t) return !t.data.labels && i.labels || t.data.labels && !i.labels || t.data.labels.length !== i.labels.length ? (n = !0, !1) : void 0
        }, this), n && this.onStoreReload()
    },
    onSetShortcutDone: function(e, t, i) {
        if (!e) return void this.onStoreReload();
        Ext.each(i.files, function(e) {
            var t = this.getObject(e);
            t && !0 !== t.data.starred && (t.data.starred = !0, t.commit())
        }, this)
    },
    onDeleteShortcutDone: function(e, t, i) {
        e || this.onStoreReload(), Ext.each(i.files, function(e) {
            var t = this.getObject(e);
            t && !1 !== t.data.starred && (t.data.starred = !1, t.commit())
        }, this)
    },
    onUploadComplete: function(e) {
        if (e && Ext.isArray(e)) {
            var t = this.appWindow.getNavigation();
            Ext.each(e, function(e) {
                if (SYNO.SDS.Drive.Utils.getFileIdFromPathId(e.path) === t.getLastPathId()) return this.onStoreReload(), !1
            }, this)
        }
    },
    onStoreReload: function(e, t, i, n, s) {
        this.load_options = {
            blMask: e || !1,
            focusNext: s || !1,
            options: t || {}
        };
        var o = this.appWindow.getEventMgr();
        this.delayStoreReloadTask || (this.delayStoreReloadTask = new Ext.util.DelayedTask(function() {
            !0 !== this.load_options.blMask ? o.fireEvent("disableviewmask") : (this.getActiveStore().removeAll(), o.fireEvent("enableviewmask")), this.appWindow.getPanel().getView && (this.appWindow.getPanel().getView().preserveScroll = this.load_options.focusNext), this.load_options.focusIdx = this.findNextFocusIdx(), this.getActiveStore().reload(Ext.apply({
                scope: this,
                callback: function() {
                    if (void 0 !== this.load_options.focusIdx) {
                        var e = this.appWindow.getPanel(); - 1 !== this.load_options.focusIdx && Ext.isEmpty(e.getSelections()) && (e.getSelectionModel && e.getSelectionModel().selectRow(this.load_options.focusIdx), e.focusItem && e.focusItem(this.load_options.focusIdx), e.getView && (e.getView().preserveScroll = !1)), o.fireEvent("enableviewmask")
                    }
                }
            }, this.load_options.options))
        }, this), this.mon(this, "beforedestroy", function() {
            this.delayStoreReloadTask.cancel(), this.delayStoreReloadTask = null
        }, this)), this.delayStoreReloadTask.cancel(), this.delayStoreReloadTask.delay(i ? 0 : n || 80)
    },
    onSyncDeviceDone: function(e, t, i) {
        e && "shared_with_me" === this.appWindow.getNavigation().getCategory() && this.onStoreReload()
    },
    destroy: function() {
        Ext.iterate(this.stores, function(e) {
            this.stores[e].destroy()
        }, this), this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.StoreMgr", {
    extend: "SYNO.SDS.Drive.StoreMgr",
    createStores: function() {
        this.callParent(arguments), this.stores.share_folder = new SYNO.SDS.Drive.Upload.Store.ShareFolder({
            appWindow: this.appWindow
        }), this.stores.tag && this.stores.tag.destroy(), this.stores.tag = new SYNO.SDS.Drive.Upload.Store.Tag({
            appWindow: this.appWindow
        }), this.stores.label && this.stores.tag.destroy(), this.stores.label = new SYNO.SDS.Drive.Upload.Store.Label({
            appWindow: this.appWindow
        })
    },
    onPathChange: function(e, t, i, n) {
        var s = this.appWindow.getNavigation(),
            o = this.appWindow.getViewModeMgr(),
            r = !1;
        if (n) {
            var a;
            switch (i) {
                case "starred":
                case "team_folder":
                case "shared_with_me":
                case "sharing_to_others":
                case "backup":
                    a = this.activeStore, s.isRootPath() ? this.activeStore = this.stores[i] : this.activeStore = this.stores.node, a !== this.activeStore && (r = !0);
                    break;
                case "label":
                    if (a = this.activeStore, s.isRootPath()) this.activeStore = this.stores.label, o.setViewMode(i);
                    else {
                        t.length <= 2 ? this.activeStore = this.stores.tag : this.activeStore = this.stores.node;
                        this.appWindow.getDrivePanel().getViewModeBtn().setPrevViewMode()
                    }
                    a !== this.activeStore && (r = !0);
                    break;
                case "share_folder":
                    r = !0
            }
            r && this.appWindow.getEventMgr().fireEvent("viewstorechange", i, null, this.activeStore), "search" !== i && this.onStoreReload(!0, {
                params: {
                    offset: 0,
                    limit: 1e3
                }
            }, !0)
        }
    }
}), Ext.ns("SYNO.SDS.Drive"), SYNO.SDS.Drive.Layout = function() {
    SYNO.SDS.Drive.isRunLayout || (SYNO.SDS.Drive.isRunLayout = !0, SYNO.ux.FormPanel.prototype.labelWidth = 150, SYNO.ux.FormPanel.prototype.labelPad = 10, SYNO.ux.FormPanel.prototype.fieldWidth = 344, SYNO.SDS.Utils.FormPanel.prototype.labelWidth = 150, SYNO.SDS.Utils.FormPanel.prototype.labelPad = 10, SYNO.SDS.Utils.FormPanel.prototype.fieldWidth = 344, Ext.grid.GridView.prototype.emptyText = _TT("SYNO.SDS.Drive.Application", "empty", "grid"), Ext.grid.GridView.prototype.applyEmptyText = function() {
        this.emptyText && (this.hasRows() ? this.grid.el.removeClass("syno-d-mgr-empty-grid") : (this.grid.el.addClass("syno-d-mgr-empty-grid"), this.mainBody.update('<div class="x-grid-empty">' + this.emptyText + "</div>")))
    }, SYNO.ux.GridPanel.prototype.useNewStyle = !0, SYNO.ux.GridPanel.prototype.ori_initEvents = SYNO.ux.GridPanel.prototype.initEvents, SYNO.ux.GridPanel.prototype.initEvents = function(e, t) {
        SYNO.ux.GridPanel.prototype.ori_initEvents.apply(this, arguments);
        var i = this.findWindow() || this.findAppWindow();
        i && this.mon(i, "show", function() {
            var e = this.bwrap;
            e && e.isMasked() && this.loadMask.show()
        }, this, {
            single: !0
        })
    }, SYNO.ux.PagingToolbar.prototype.buttonAlign = "left", SYNO.ux.PagingToolbar.prototype.calcButtonNumber = function() {
        var e = this.getWidth() - this.el.child(".x-toolbar-right").getWidth(),
            t = e - 136,
            i = this.btn3.getWidth();
        return Math.floor(t / i)
    }, SYNO.ux.DateTimeField.prototype.width = 190, SYNO.ux.ComboBox.prototype.listAlign = ["tl-bl?", [0, 2]], SYNO.ux.SuperBoxSelect.prototype.listAlign = ["tl-bl?", [0, 2]], delete Ext.menu.Menu.prototype.defaultOffsets, Ext.menu.DateTimeMenu.prototype.defaultOffsets = [0, 2], Ext.menu.Menu.prototype.scrollerHeight = 16, Ext.menu.Menu.prototype.createScrollers = function() {
        function e() {
            var e = this.ul.dom;
            this.scroller.top[e.scrollTop <= 0 ? "addClass" : "removeClass"]("x-menu-scroller-disabled"), this.scroller.bottom[e.scrollTop + this.activeMax >= e.scrollHeight ? "addClass" : "removeClass"]("x-menu-scroller-disabled")
        }
        var t = Ext.menu.Menu.prototype.createScrollers;
        return function() {
            this.scroller || (t.call(this, arguments), Ext.fly(this.ul.dom).on("scroll", e, this)), e.call(this)
        }
    }(), SYNO.ux.DateTimeMenu.prototype.defaultOffsets = [0, 2], SYNO.ux.DateMenu.prototype.defaultOffsets = [0, 2], SYNO.ux.Menu.prototype.useARIA = !1, SYNO.SDS.BaseWindow.prototype.getMsgBox = function(e) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            var t = e && e.owner || this;
            t = t.isDestroyed ? null : t, this.isV5Style() ? this.msgBox = new SYNO.SDS.MessageBoxV5({
                owner: t,
                preventDelay: !!e && (e.preventDelay || !1),
                draggable: !!e && (e.draggable || !1)
            }) : this.msgBox = new SYNO.SDS.MessageBox({
                owner: t
            })
        }
        return this.msgBox.getWrapper(Ext.apply(e || {}, {
            btnStyle: "default"
        }))
    }, SYNO.SDS.MessageBoxV5.prototype.old_getButtons = SYNO.SDS.MessageBoxV5.prototype.getButtons, SYNO.SDS.MessageBoxV5.prototype.getButtons = function(e) {
        var t = SYNO.SDS.MessageBoxV5.prototype.old_getButtons.apply(this, arguments);
        return Ext.each(t, function(e) {
            e.transitionFocus = Ext.emptyFn
        }), t
    }, SYNO.ux.FileButton.prototype.buttonConfig = {
        btnStyle: "grey"
    }, Ext.Button.prototype.ori_initComponent = Ext.Button.prototype.initComponent, Ext.Button.prototype.initComponent = function() {
        Ext.Button.prototype.ori_initComponent.apply(this, arguments), this.menu && !this.menu.defaultOffsets && (this.menu.defaultOffsets = [0, 2])
    }, SYNO.ux.Button.prototype.updateButtonStyle && (SYNO.ux.Button.prototype.updateButtonStyle = function(e) {
        this.addClass("syno-ux-button"), "blue" === this.btnStyle ? this.addClass("syno-ux-button-blue") : "grey" === this.btnStyle ? this.addClass("syno-ux-button-grey") : "red" === this.btnStyle ? this.addClass("syno-ux-button-red") : "green" === this.btnStyle ? this.addClass("syno-ux-button-green") : "orange" === this.btnStyle ? this.addClass("syno-ux-button-orange") : "none" === this.btnStyle || this.addClass("syno-ux-button-default")
    }), SYNO.ux.SplitButton.prototype.updateButtonStyle && (SYNO.ux.SplitButton.prototype.updateButtonStyle = function(e) {
        this.addClass("syno-ux-button"), this.addClass("syno-ux-button-split"), "blue" === this.btnStyle ? this.addClass("syno-ux-button-blue") : "grey" === this.btnStyle ? this.addClass("syno-ux-button-grey") : "red" === this.btnStyle ? this.addClass("syno-ux-button-red") : "green" === this.btnStyle ? this.addClass("syno-ux-button-green") : "orange" === this.btnStyle ? this.addClass("syno-ux-button-orange") : "none" === this.btnStyle || this.addClass("syno-ux-button-default")
    }), SYNO.ux.SearchField.prototype.ori_initComponent = SYNO.ux.SearchField.prototype.initComponent, SYNO.ux.SearchField.prototype.initComponent = function() {
        SYNO.ux.SearchField.prototype.ori_initComponent.apply(this, arguments), this.menu && !this.menu.defaultOffsets && (this.menu.defaultOffsets = [0, 2])
    }, Ext.DatePicker.prototype.createMonthPicker = function() {
        if (!this.monthPicker.dom.firstChild) {
            for (var e = ['<table border="0" cellspacing="0">'], t = 0; t < 6; t++) e.push('<tr><td class="x-date-mp-month"><a href="#">', Date.getShortMonthName(t), "</a></td>", '<td class="x-date-mp-month x-date-mp-sep"><a href="#">', Date.getShortMonthName(t + 6), "</a></td>", 0 === t ? '<td class="x-date-mp-ybtn" align="center"><a class="x-date-mp-prev"></a></td><td class="x-date-mp-ybtn" align="center"><a class="x-date-mp-next"></a></td></tr>' : '<td class="x-date-mp-year"><a href="#"></a></td><td class="x-date-mp-year"><a href="#"></a></td></tr>');
            e.push('<tr class="x-date-mp-sep"></tr>', '<tr class="x-date-mp-btns"><td colspan="4"><button type="button" class="x-date-mp-ok">', this.okText, '</button><button type="button" class="x-date-mp-cancel">', this.cancelText, "</button></td></tr>", "</table>"), this.monthPicker.update(e.join("")), this.mon(this.monthPicker, "click", this.onMonthClick, this), this.mon(this.monthPicker, "dblclick", this.onMonthDblClick, this), this.mpMonths = this.monthPicker.select("td.x-date-mp-month"), this.mpYears = this.monthPicker.select("td.x-date-mp-year"), this.mpMonths.each(function(e, t, i) {
                i += 1, e.dom.xmonth = i % 2 == 0 ? 5 + Math.round(.5 * i) : Math.round(.5 * (i - 1))
            })
        }
    }, SYNO.ux.TimePickerField.prototype.comboWidth = 70, SYNO.ux.TimePickerField.prototype.comboDefaultMargins = "0 0 0 5", SYNO.ux.TimePickerField.prototype.comboMargins = {
        top: 0,
        bottom: 0,
        left: 5,
        right: 0
    }, Ext.DateTimePicker.prototype.ori_showMonthPicker = Ext.DateTimePicker.prototype.showMonthPicker, Ext.DateTimePicker.prototype.showMonthPicker = function() {
        var e = this.el.child(".table");
        e && e.hide();
        var t = this.el.child(".x-date-picker");
        t && t.setStyle("max-height", "254px"), this.ownerCt.doLayout(), Ext.DateTimePicker.prototype.ori_showMonthPicker.apply(this, arguments)
    }, Ext.DateTimePicker.prototype.ori_hideMonthPicker = Ext.DateTimePicker.prototype.hideMonthPicker, Ext.DateTimePicker.prototype.hideMonthPicker = function() {
        Ext.DateTimePicker.prototype.ori_hideMonthPicker.apply(this, arguments);
        var e = this.el.child(".table");
        e && e.show();
        var t = this.el.child(".x-date-picker");
        t && t.setStyle("max-height", "none"), this.ownerCt.doLayout()
    }, SYNO.SDS.ModalWindow.prototype.fillWindowPadding = function(e) {
        return Ext.applyIf(e, {
            padding: "12px 19px 0 19px"
        })
    }, SYNO.SDS.ModalWindow.prototype.centerTitle = Ext.emptyFn, Ext.menu.Menu.prototype.shadow = !1, Ext.Panel.prototype.shadow = !1, SYNO.ux.SuperBoxSelect.prototype.shadow = !1, SYNO.SDS.Wizard.ModalWindow.prototype.ori_configButtons = SYNO.SDS.Wizard.ModalWindow.prototype.configButtons, SYNO.SDS.Wizard.ModalWindow.prototype.configButtons = function(e) {
        var t = SYNO.SDS.Wizard.ModalWindow.prototype.ori_configButtons.apply(this, arguments),
            i = t.length - 2;
        return "blue" !== t[i].btnStyle && (i = t.length - 1), t[i].btnStyle = "default", t
    }, SYNO.SDS.Wizard.ModalWindow.prototype.ori_setDescription = SYNO.SDS.Wizard.ModalWindow.prototype.setDescription, SYNO.SDS.Wizard.ModalWindow.prototype.setDescription = function(e) {
        SYNO.SDS.Wizard.ModalWindow.prototype.ori_setDescription.apply(this, arguments);
        var t, i = this.getComponent("banner");
        i && (t = i.getComponent("description"), t.setVisible(!!e))
    }, SYNO.ux.SuperBoxSelectItem.prototype.preDestroy = function(e) {
        if ((!0 === this.owner.allowDeleteData || !this.owner.readOnly) && !1 !== this.fireEvent("remove", this)) {
            var t = function() {
                this.owner.navigateItemsWithTab && this.moveFocus("right"), this.hidden.remove(), this.hidden = null, this.destroy()
            };
            return e ? t.call(this) : this.el.hide({
                duration: .2,
                callback: t,
                scope: this
            }), this
        }
    }, SYNO.SDS.Utils.ori_AddTip = SYNO.SDS.Utils.AddTip, SYNO.SDS.Utils.AddTip = function(e, t) {
        var i = SYNO.SDS.Utils.ori_AddTip(e, t),
            n = i.children[0],
            s = SYNO.SDS.Drive.GetWindow().appInstance.jsConfig;
        n.src = s.jsBaseURL + "/../SynologyDrive-Drive/images/_Component/" + (SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x") + "/_Common/icon_information_light.png", Ext.fly(n).setStyle("margin-bottom", "3px")
    }, Ext.slider.SingleSlider.prototype.ori_moveThumb = Ext.slider.SingleSlider.prototype.moveThumb, Ext.slider.SingleSlider.prototype.moveThumb = function(e, t, i) {
        -5 > t && (t = -5), Ext.slider.SingleSlider.prototype.ori_moveThumb.call(this, e, t, i)
    })
}, "SYNO.SDS.Drive.Application" !== _S("standaloneAppName") && "SYNO.SDS.Drive.PublicApplication" !== _S("standaloneAppName") || SYNO.SDS.Drive.Layout(), Ext.ns("SYNO.SDS.Drive"), Ext.define("SYNO.SDS.Drive.WebAPI", {
    constructor: function(e) {
        this.appWindow = e.appWindow, this.callParent([e])
    },
    copyTo: function(e, t, i) {
        return SYNO.SDS.Drive.Utils.copyTo(e, t, i)
    },
    initial: function(e) {
        this.appWindow.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: [SYNO.SDS.Drive.WebAPIDesc.info, SYNO.SDS.Drive.WebAPIDesc.get_setting]
            },
            callback: e.callback,
            scope: e.scope || window
        })
    },
    listRecent: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "offset,limit,filter"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.list_recent))
    },
    createNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path,type,conflict_action"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.create_files))
    },
    getChannelMap: function(e) {
        if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Chat.Application")) return void e.callback.call(e.scope || window, !1);
        this.appWindow.sendWebAPI({
            api: "SYNO.Chat.Channel",
            version: 1,
            method: "list",
            params: {
                type: "channel",
                attributes: ["channel_id", "name"]
            },
            callback: e.callback,
            scope: e.scope || window
        })
    },
    getGroupMap: function(e) {
        this.appWindow.sendWebAPI({
            api: "SYNO.SynologyDrive.Share.Priv",
            version: 1,
            method: "list",
            params: {
                type: "group",
                query: "",
                offset: 0,
                limit: 65536
            },
            callback: e.callback,
            scope: e.scope || window
        })
    },
    getUsers: function(e) {
        this.appWindow.sendWebAPI({
            api: "SYNO.SynologyDrive.SCIM.User",
            version: 1,
            method: "get",
            params: this.copyTo({}, e.params || {}, "user,uid"),
            callback: e.callback,
            scope: e.scope || window
        })
    },
    getNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.get_file))
    },
    getTrashAncestor: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.list_trash_ancestor))
    },
    getNodes: function(e) {
        var t = [];
        Ext.each(e.params.path, function(e) {
            t.push(Ext.apply({
                params: {
                    path: e
                }
            }, SYNO.SDS.Drive.WebAPIDesc.get_file))
        }), this.appWindow.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                params: t
            },
            callback: e.callback,
            scope: e.scope || window
        })
    },
    getNodeAncestors: function(e) {
        var t = {
            path: e.params.path
        };
        this.appWindow.sendWebAPI(Ext.apply({
            params: t,
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.list_node_ancestor))
    },
    setNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path,name,created_time,modified_time,labels,starred,properties,app_properties"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.update_file))
    },
    setNodeTag: function(e) {
        var t = e.params || {};
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, t, "files,labels"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.set_labels))
    },
    deleteNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "files,permanent"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.delete_files))
    },
    cleanNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.empty_recycle_bin))
    },
    restoreNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "files,conflict_action,to_parent_folder"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.restore_revisions))
    },
    copyNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "files,to_parent_folder,conflict_action,dry_run"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.copy_files))
    },
    moveNode: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "files,to_parent_folder,conflict_action,dry_run,change_name"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.move_files))
    },
    listTag: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "filter,field,offset,limit,sort_by,sort_direction"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.list_labels))
    },
    createTag: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "file_id,name,color"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.create_labels))
    },
    setTag: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "label_id,name,color,position"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.update_labels))
    },
    deleteTag: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "label_id"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.delete_labels))
    },
    setShortcut: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({
                starred: !0
            }, e.params, "files"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.star_file))
    },
    deleteShortcut: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({
                starred: !1
            }, e.params, "files"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.star_file))
    },
    getShardLink: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.get_file_link))
    },
    getShardLinkPromise: function(e) {
        return new Promise(function(t, i) {
            this.getShardLink({
                params: e,
                callback: function(e, n) {
                    e ? t(n) : i(n)
                }
            })
        }.bind(this))
    },
    getShardLinkAndInfo: function(e) {
        var t = [Ext.apply({
            params: this.copyTo({}, e.params, "path")
        }, SYNO.SDS.Drive.WebAPIDesc.get_file_link), Ext.apply({
            params: this.copyTo({}, e.params, "path")
        }, SYNO.SDS.Drive.WebAPIDesc.get_file)];
        this.appWindow.sendWebAPI({
            compound: {
                params: t,
                stopwhenerror: !1
            },
            callback: e.callback,
            scope: e.scope
        })
    },
    setNodePerm: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path,permissions"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.share_file))
    },
    deleteNodePerm: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: {
                path: e.params.path,
                permissions: [{
                    action: "delete",
                    member: {
                        type: "user",
                        name: e.params.username
                    }
                }]
            },
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.share_file))
    },
    requestAccess: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params || {}, "path"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.request_access))
    },
    setChatChannel: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "path, channel_ids"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.bind_chat_channels))
    },
    convertOffice: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "files"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.convert_office))
    },
    syncDevice: function(e) {
        this.appWindow.sendWebAPI({
            compound: {
                params: e.params,
                stopwhenerror: !1
            },
            callback: e.callback,
            scope: e.scope
        })
    },
    syncPluginString: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: this.copyTo({}, e.params, "app"),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.plugin_string))
    },
    checkAdvSharingPassword: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: e.params,
            encryption: ["password"],
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.auth_adv_sharing))
    },
    getAdvSharingLink: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: e.params,
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.get_adv_sharing))
    },
    getAdvSharingLinkPromise: function(e) {
        return new Promise(function(t, i) {
            this.getAdvSharingLink({
                params: e,
                callback: function(e, n) {
                    e ? t(n) : i(n)
                }
            })
        }.bind(this))
    },
    updateAdvSharingLink: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: e.params,
            encryption: ["protect_password"],
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.update_adv_sharing))
    },
    updateAdvSharingLinkPromise: function(e) {
        return new Promise(function(t, i) {
            this.updateAdvSharingLink({
                params: e,
                callback: function(e, n) {
                    e ? t(n) : i(n)
                },
                scope: this
            })
        }.bind(this))
    },
    removeAdvSharingLink: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: e.params,
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.remove_adv_sharing))
    },
    removeAdvSharingLinkPromise: function(e) {
        return new Promise(function(t, i) {
            this.removeAdvSharingLink({
                params: e,
                callback: function(e, n) {
                    e ? t(n) : i(n)
                },
                scope: this
            })
        }.bind(this))
    },
    createAdvSharingLink: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: e.params,
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.create_adv_sharing))
    },
    createAdvSharingLinkPromise: function(e) {
        return new Promise(function(t, i) {
            this.createAdvSharingLink({
                params: e,
                callback: function(e, n) {
                    e ? t(n) : i(n)
                },
                scope: this
            })
        }.bind(this))
    },
    getQuotaInfo: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.get_quota))
    },
    getUserSetting: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.get_user_setting))
    },
    notifyDownloadEvent: function(e) {
        this.appWindow.sendWebAPI(Ext.apply({
            params: Ext.apply({
                notify_download_event: !0
            }, e.params),
            callback: e.callback,
            scope: e.scope || window
        }, SYNO.SDS.Drive.WebAPIDesc.download_files))
    }
}), Ext.define("SYNO.SDS.Drive.AppInstance", {
    extend: "SYNO.SDS.AppInstance",
    skipRecord: !SYNO.SDS.Drive.Utils.isAppAuthorized(),
    constructor: function() {
        SYNO.SDS.Drive.AppInstance.superclass.constructor.apply(this, arguments);
        var e = ["syno-d-theme"];
        SYNO.SDS.Drive.WindowHelper.isPublicShare() && e.push(["syno-d-public"]), Ext.getBody().addClass(e)
    },
    setUserSettings: function() {
        SYNO.SDS.Drive.Utils.isAppAuthorized() && SYNO.SDS.Drive.AppInstance.superclass.setUserSettings.apply(this, arguments)
    },
    beforeOpen: function() {
        if (this.isOldIE = Ext.isIE6 || Ext.isIE7 || Ext.isIE8 || Ext.isIEQuirks || Ext.isIE9, this.isOldIE) {
            return new SYNO.SDS.MessageBoxV5({
                modal: !0,
                draggable: !1,
                renderTo: document.body
            }).getWrapper().alert("", SYNO.SDS.Drive._T("error", "not_support_ie8"), function() {
                try {
                    window.close()
                } catch (e) {}
                window.location.assign("/")
            }), !1
        }
        return !this.onCheckRedirect()
    },
    onCheckRedirect: function() {
        var e = Ext.urlDecode(window.location.search.substr(1));
        if (e.launchParam) {
            var t = Ext.urlDecode(e.launchParam);
            if (t.link) {
                var i, n = t.link,
                    s = t.sharing_link;
                return i = s ? SYNO.SDS.Drive.Sharing.GetURL(n, s) : SYNO.SDS.Drive.Utils.getDriveLink(n), window.location.hash && (i += window.location.hash), window.location.href = i, !0
            }
        }
        return !1
    }
}), Ext.define("SYNO.SDS.Drive.PrototypeWindow", {
    extend: "SYNO.SDS.AppWindow",
    aboutTitleColor: "#1EB9C7",
    constructor: function(e) {
        SYNO.SDS.Drive.Utils.isAppAuthorized() && !SYNO.SDS.Drive.Define.Info.ready && this.getAction().initEnv(), this.callParent([this.fillConfig(e)]), SYNO.SDS.Drive.Utils.isAppAuthorized() && !SYNO.SDS.System && (SYNO.SDS.System = new SYNO.SDS._System)
    },
    isAlwaysOnBottom: function() {
        return !0
    },
    onOpen: function(e) {
        return SYNO.SDS.Drive.Env.init(e), SYNO.SDS.Drive.PrototypeWindow.superclass.onOpen.apply(this, arguments)
    },
    onRequest: function(e) {
        return SYNO.SDS.Drive.Env.init(e), SYNO.SDS.Drive.PrototypeWindow.superclass.onRequest.apply(this, arguments)
    },
    getWebAPI: function() {
        return this.webapimgr || (this.webapimgr = new SYNO.SDS.Drive.WebAPI({
            appWindow: this
        }))
    },
    getAction: function() {
        return this.actionmgr || (this.actionmgr = new SYNO.SDS.Drive.Action({}))
    },
    getStatusMgr: function() {
        return this.statusmgr
    },
    getEventMgr: function() {
        return this.eventmgr
    },
    getStoreMgr: function() {
        return this.storemgr
    },
    getViewModeMgr: function() {
        return this.viewmodemgr
    },
    getImageQueue: function() {
        return this.imagequeue
    },
    getTaskMgr: function() {
        return this.taskmgr
    },
    getDownloadMgr: function() {
        return this.downloadmgr
    },
    fillConfig: function(e) {
        var t = this.getWinPanel(),
            i = [];
        i.push([this.getWinPanel(), this.getPermPanel()]);
        var n = {
            renderTo: Ext.getBody(),
            height: Ext.lib.Dom.getViewHeight(!0),
            layout: "card",
            deferredRender: !0,
            activeItem: t,
            items: i
        };
        return n.useDefualtKey = !1, Ext.apply(n, e), n
    },
    getWinPanel: function(e) {
        return this.winpanel || (this.winpanel = new Ext.Container({
            anchor: "100%, 100%",
            layout: "border",
            hideMode: "offsets",
            items: [this.getLeftPanel(), this.getMainPanel()]
        }))
    },
    getLeftPanel: function() {
        return this.toolbar || (this.toolbar = new SYNO.SDS.Drive.Toolbar({
            region: "west",
            owner: this
        }))
    },
    fillWindowPadding: function() {},
    getPermPanel: function() {
        return this.permPanel || (this.permPanel = new SYNO.SDS.Drive.PermPanel({})), this.permPanel
    },
    getImageLoader: function() {
        return SYNO.SDS.Drive.Utils.getImageLoader()
    },
    onBeforeDestroy: function() {
        this.getImageLoader().stop(), SYNO.SDS.Drive.PrototypeWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    showAboutWindow: function() {
        if (SYNO.SDS.CSTN.IsDSM7OrAbove()) {
            var e = {
                isBeta: SYNO.SDS.Drive.Define.Info.beta
            };
            return void this.callParent([e])
        }
        this.aboutWindow || (this.aboutWindow = new SYNO.SDS.AboutWindow({
            owner: this,
            aboutHeader: "&nbsp;",
            pkgColor: this.aboutTitleColor || "#1EB9C7",
            width: 450,
            height: 184
        }), this.mon(this.aboutWindow, "afterlayout", function(e) {
            var t = this.findAppWindow().appInstance.jsConfig;
            e.items.items[0].getEl().dom.innerHTML = String.format('<img alt="" src="{0}" width="96" height="96">', t.jsBaseURL + "/images/_Favicon/SynologyDrive_256.png")
        }, this)), this.aboutWindow.show()
    }
}), Ext.define("SYNO.SDS.Drive.BasicInstance", {
    extend: "SYNO.SDS.Drive.AppInstance",
    appWindowName: "SYNO.SDS.Drive.BasicApp"
}), Ext.define("SYNO.SDS.Drive.BasicApp", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(e) {
        Ext.getBody().addClass(["syno-drive-theme"]), this.addEvents({
            beforedestroy: !0
        }), this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t, i = [],
            n = window.getDriveErrCode();
        1037 === n ? t = this.getPasswordPanel() : (t = this.getPermPanel(), t.onUpdateByErrCode(n)), i.push([t]);
        var s = {
            layout: "card",
            deferredRender: !0,
            activeItem: t,
            items: i
        };
        return s.useDefualtKey = !1, Ext.apply(s, e), s
    },
    getWebAPI: function() {
        return this.webapimgr || (this.webapimgr = new SYNO.SDS.Drive.WebAPI({
            appWindow: this
        }))
    },
    getAction: function() {
        return this.actionmgr || (this.actionmgr = new SYNO.SDS.Drive.Action({}))
    },
    getPermPanel: function() {
        return this.permPanel || (this.permPanel = new SYNO.SDS.Drive.PermPanel({})), this.permPanel
    },
    getPasswordPanel: function() {
        return this.passwdPanel || (this.passwdPanel = new SYNO.SDS.Drive.Share.AdvancedPasswordPanel({
            owner: this
        })), this.passwdPanel
    }
}), Ext.define("SYNO.SDS.Drive.ViewModeMgr", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.appWindow = e.appWindow, this.viewMode = e.viewMode || this.getViewMode(), this.callParent(arguments)
    },
    isCheckUserSetting: function() {
        return !!(!SYNO.SDS.Drive.WindowHelper.isPublicShare() && Ext.getClassByName("SYNO.SDS.Drive.MainWindow") && this.appWindow instanceof SYNO.SDS.Drive.MainWindow)
    },
    setViewMode: function(e) {
        this.viewMode = e, this.appWindow.getEventMgr().fireEvent("viewmodechange", e), this.isCheckUserSetting() && "snippet" !== e && "empty" !== e && SYNO.SDS.UserSettings.setProperty("SYNO.SDS.Drive.Application", "viewmode", e)
    },
    getUserViewMode: function() {
        if (this.isCheckUserSetting()) return SYNO.SDS.UserSettings.getProperty("SYNO.SDS.Drive.Application", "viewmode")
    },
    getViewMode: function() {
        return this.viewMode || this.getUserViewMode() || "list"
    }
}), Ext.define("SYNO.SDS.Drive.ImageLoaderQueue", {
    extend: "Ext.Component",
    maxImageRequest: 24,
    constructor: function(e) {
        this.queue = [], this.appWindow = e.appWindow, this.callParent(arguments), this.imageloader = SYNO.SDS.Drive.Utils.getImageLoader()
    },
    getTask: function() {
        return this.actionTask = this.actionTask || this.addTask({
            id: "drive_task_load_image",
            interval: 17,
            run: this.loadImage,
            scope: this
        }), this.actionTask
    },
    findIndexOf: function(e) {
        var t = 0;
        for (t = 0; t < this.queue.length; t++)
            if (this.queue[t].id === e) return t;
        return -1
    },
    addImage: function(e) {
        var t = this.getTask(); - 1 === this.findIndexOf(e) && (this.queue.push(e), !1 === t.running && t.restart(!0))
    },
    removeImage: function(e) {
        if (0 !== this.queue.length) {
            var t = this.findIndexOf(e); - 1 !== t && (this.queue.splice(t, 1), 0 === this.queue.length && this.getTask().stop())
        }
    },
    removeAll: function() {
        this.queue = [], this.getTask().stop()
    },
    loadImage: function() {
        var e, t = 0,
            i = Math.min(this.maxImageRequest, this.queue.length);
        for (t = 0; t < i; t++) try {
            e = this.queue[t];
            var n = Ext.fly(e.id);
            n && n.dom && (n.dom.src = e.url, this.imageloader.loadImg(n.dom, e.listeners))
        } catch (e) {
            SYNO.Debug.error(e)
        }
        this.queue.splice(0, i), 0 === this.queue.length && this.getTask().stop()
    },
    stop: function() {
        this.getTask().stop()
    },
    destroy: function() {
        this.queue = null, this.actionTask && (this.actionTask = null), this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.Application", {
    extend: "SYNO.SDS.Drive.AppInstance",
    appWindowName: "SYNO.SDS.Drive.Upload.MainWindow",
    constructor: function(e) {
        this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.MainWindow", {
    extend: "SYNO.SDS.Drive.PrototypeWindow",
    driveToolbarList: ["node", "shared_items", "starred", "recent", "team_folder", "label"],
    mainToolbarList: ["from_upload", "from_drive", "from_nas", "from_url", "from_youtube_url"],
    allowDrop: !0,
    constructor: function(e) {
        Ext.isWebKit ? window.name || (window.name = "SYNOSDSDriveUploadApplication") : window.name && (window.name = ""), this.driveFirstItemId = this.driveToolbarList[0], this.eventmgr = new SYNO.SDS.Drive.EventMgr({
            appWindow: this
        }), this.storemgr = new SYNO.SDS.Drive.Upload.StoreMgr({
            appWindow: this
        }), this.addManagedComponent(this.storemgr), this.viewmodemgr = new SYNO.SDS.Drive.ViewModeMgr({
            appWindow: this
        }), this.addManagedComponent(this.viewmodemgr), this.imagequeue = new SYNO.SDS.Drive.ImageLoaderQueue({
            appWindow: this
        }), this.addManagedComponent(this.imagequeue), this.callParent(arguments), this.mon(this.eventmgr, "envready", function() {
            if (!SYNO.SDS.Drive.Define.Info.is_home) {
                this.driveToolbarList.shift();
                this.wintoolbar.get("node").setVisible(!1)
            }
            this.driveFirstItemId = this.driveToolbarList[0]
        }, this)
    },
    fillConfig: function(e) {
        var t = {
            layout: "card",
            height: this.getHeight(),
            width: this.getWidth(),
            maximizable: !1,
            autoDestroy: !0,
            cls: "syno-drive-win syno-d-upload-window",
            deferredRender: !0,
            activeItem: 0,
            items: [this.getUploadPanel(), this.getDrivePanel(), this.getURLPanel(), this.getYouTubeURLPanel()],
            tbar: this.getWinToolbar(),
            buttons: [{
                itemId: "cancel",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                itemId: "ok",
                text: _T("common", "ok"),
                btnStyle: "default",
                disabled: !0,
                scope: this,
                handler: this.onApply
            }],
            listeners: {
                scope: this,
                afterlayout: {
                    single: !0,
                    fn: this.onAfterLayout
                }
            }
        };
        return SYNO.SDS.CSTN.IsDSM7OrAbove() || t.buttons.reverse(), Ext.apply(t, e || {}), t
    },
    getHeight: function() {
        var e = .8 * Ext.getBody().getViewSize().height;
        return e > 680 ? e = 680 : e < 440 && (e = 440), e
    },
    getWidth: function() {
        var e = Math.floor(.75 * Ext.getBody().getViewSize().width);
        return e > 1120 ? e = 1120 : e < 680 && (e = 680), e
    },
    onAfterLayout: function() {
        this.maskEl && this.maskEl.addClass("syno-d-upload-window-mask")
    },
    onOpen: function(e) {
        this.callParent(arguments);
        var t = this.openParams = e || {};
        if (e)
            for (var i in e)
                if (e.hasOwnProperty(i)) switch (e[i]) {
                    case "true":
                        e[i] = !0;
                        break;
                    case "false":
                        e[i] = !1
                }
        if (!1 === t.from_upload && this.wintoolbar.remove("from_upload"), SYNO.SDS.Drive.Utils.isAppAuthorized() && !1 !== t.from_drive || this.wintoolbar.remove("from_drive"), SYNO.SDS.Drive.Utils.isLogined() && !1 !== t.from_nas || this.wintoolbar.remove("from_nas"), !1 === t.from_url && this.wintoolbar.remove("from_url"), !0 !== t.from_youtube_url && this.wintoolbar.remove("from_youtube_url"), t.activeItem) {
            var n = this.wintoolbar.get(t.activeItem);
            this.onChangeUploadCategory(n)
        }
        var s = t.fromPCParams;
        if (t.filter) {
            if (t.filter.extensions) {
                var o = t.filter.extensions,
                    r = ""; - 1 !== o.indexOf("bmp") && (r = "image/x-windows-bmp"), -1 !== o.indexOf("tif") && (r = "image/tiff"), r = o.reduce(function(e, t) {
                    return e && (e += ","), e + "image/" + t
                }, r), s = Ext.applyIf(s || {}, {
                    multiple: !0,
                    accept: r
                }), t.fromNasParams = Ext.applyIf(t.fromNasParams || {}, {
                    pattern: o.join(",")
                })
            }
            t.fromDriveParams = Ext.applyIf(t.fromDriveParams || {}, {
                filter: t.filter
            })
        }
        if (t.fromNasParams) {
            var a = this.getStoreMgr().getStore("share_folder");
            a.setPattern(t.fromNasParams.pattern), t.fromNasParams.local_filter && a.setLocalFilter(t.fromNasParams.local_filter)
        }
        if (t.fromDriveParams) {
            var l = t.fromDriveParams.filter;
            Ext.iterate(this.getStoreMgr().stores, function(e, t) {
                "share_folder" !== e && "label" !== e && t.setFilter(l)
            })
        }
        if (this.drivePanel.setEnableSelectDir(t.enableSelectDir), t.beforeSelection) {
            var d = t.beforeSelection;
            Ext.isString(d) && (d = new Function(d)), this.drivePanel.setBeforeSelection(d)
        }
        if (Ext.isBoolean(t.singleSelect)) {
            var h = t.singleSelect;
            this.drivePanel.setSingleSelect(h), this.uploadPanel.setSingleSelect(h), s = Ext.apply(s || {}, {
                multiple: !h
            })
        }
        s && this.uploadPanel.setFileBtnAttributes(s), t.viewMode && this.getViewModeMgr().setViewMode(t.viewMode), "small" === t.viewSize && (this.addClass("syno-d-small-upload-window"), this.getDrivePanel().setViewSize(100)), (t.width || t.height) && (this.setSize(t.width, t.height), this.center()), t.hidden && this.setVisible(!1)
    },
    onApply: function() {
        if (!this.layout.activeItem.isValid()) return void this.getMsgBox().alert("", this.layout.activeItem.getError() || _T("common", "forminvalid"));
        Ext.isFunction(this.openParams.onApply) && !1 === this.openParams.onApply(this, this.getResult()) || this[this.closeAction]()
    },
    onCancel: function() {
        this.layout.activeItem.isDirty() ? this.getMsgBox().confirm("", SYNO.SDS.Drive._T("upload", "cancel_confirm"), function(e) {
            "yes" === e && this[this.closeAction]()
        }, this) : this[this.closeAction]()
    },
    getResult: function() {
        return this.layout.activeItem.getResults()
    },
    getUploadPanel: function() {
        return this.uploadPanel ? this.uploadPanel : (this.uploadPanel = new SYNO.SDS.Drive.Upload.UploadPanel({
            itemId: "from_upload",
            owner: this
        }), this.uploadPanel)
    },
    getURLPanel: function() {
        return this.urlPanel ? this.urlPanel : (this.urlPanel = new SYNO.SDS.Drive.Upload.URLPanel({
            itemId: "from_url",
            owner: this
        }), this.urlPanel)
    },
    getYouTubeURLPanel: function() {
        return this.youtubeUrlPanel ? this.youtubeUrlPanel : (this.youtubeUrlPanel = new SYNO.SDS.Drive.Upload.YouTubeURLPanel({
            itemId: "from_youtube_url",
            owner: this
        }), this.youtubeUrlPanel)
    },
    getDrivePanel: function() {
        return this.drivePanel || (this.drivePanel = new SYNO.SDS.Drive.Upload.DriveMainPanel({
            itemId: "from_drive",
            owner: this
        })), this.drivePanel
    },
    getDriveToolbarItemCfg: function(e) {
        var t = {
            itemId: e,
            text: SYNO.SDS.Drive._T("category", e),
            handler: this.onChangeDriveCategory,
            scope: this
        };
        return e === this.driveFirstItemId && (t.cls = "syno-d-upload-toolbar-first"), t
    },
    getMainToolbarItemCfg: function(e) {
        var t = {
            itemId: e,
            text: SYNO.SDS.Drive._T("upload", e),
            handler: this.onChangeUploadCategory,
            scope: this
        };
        return "from_upload" === e && (t.cls = "syno-d-upload-toolbar-first"), t
    },
    getWinToolbar: function() {
        if (this.wintoolbar) return this.wintoolbar;
        var e = [],
            t = SYNO.SDS.Drive._T;
        return Ext.each(this.mainToolbarList, function(t) {
            e.push(this.getMainToolbarItemCfg(t))
        }, this), e.push({
            itemId: "back",
            cls: "syno-d-upload-back-btn",
            hidden: !0,
            handler: this.onChangeUploadCategory,
            scope: this
        }), Ext.each(this.driveToolbarList, function(t) {
            e.push(Ext.apply(this.getDriveToolbarItemCfg(t), {
                hidden: !0
            }))
        }, this), e.push({
            itemId: "more",
            cls: "syno-d-upload-more-btn",
            text: t("category", "more"),
            hidden: !0,
            menu: new SYNO.ux.Menu({
                ignoreParentClicks: !0,
                items: []
            })
        }), e.push("->"), e.push({
            cls: "syno-d-upload-close-btn",
            handler: this.onCancel,
            scope: this
        }), this.wintoolbar = new SYNO.ux.Toolbar({
            height: 40,
            cls: "syno-d-upload-toolbar",
            defaults: {
                xtype: "syno_button"
            },
            items: e
        }), this.wintoolbar.get("from_upload").addClass("syno-d-button-selected"), this.wintoolbar
    },
    onChangeUploadCategory: function(e, t, i) {
        var n = e.itemId,
            s = this.layout.activeItem,
            o = this.getNavigation();
        if (!i && "from_upload" === s.itemId && s.isDirty()) return void this.getMsgBox().confirm("", SYNO.SDS.Drive._T("upload", "switch_confirm"), function(t) {
            "yes" === t && (s.cleanAll(), this.onChangeUploadCategory(e, null, !0))
        }, this);
        switch (this.clearButtonSelected(), e.itemId) {
            case "from_drive":
                this.setActiveCategory(this.driveFirstItemId);
                var r = this.driveFirstItemId;
                "shared_items" === r && (r = this.getDrivePanel().getSharedItemBtn().getCheckedId()), o.setCategory(r), this.showHideMainToolbar(!1), this.showHideDriveToolbar(!0), this.wintoolbar.get(this.driveFirstItemId).addClass("syno-d-button-selected");
                break;
            case "back":
                this.showHideDriveToolbar(!1), this.showHideMainToolbar(!0);
                for (var a = 0; a < this.mainToolbarList.length; ++a) {
                    var l = this.mainToolbarList[a];
                    if ("from_drive" !== l) {
                        var d = this.wintoolbar.get(l);
                        if (d) {
                            n = l, d.addClass("syno-d-button-selected");
                            break
                        }
                    }
                }
                break;
            case "from_nas":
                n = "from_drive", this.setActiveCategory("share_folder"), o.setCategory("share_folder"), e.addClass("syno-d-button-selected");
                break;
            default:
                e.addClass("syno-d-button-selected")
        }
        this.clearStatus(), this.setApplyBtnDisabled(!0), this.layout.setActiveItem(n)
    },
    onChangeDriveCategory: function(e) {
        this.clearButtonSelected(), e.addClass("syno-d-button-selected"), this.setApplyBtnDisabled(!0);
        var t = e.itemId;
        "shared_items" === t && (t = this.getDrivePanel().getSharedItemBtn().getCheckedId()), this.setActiveCategory(e.itemId), this.navigation.setCategory(t)
    },
    setActiveCategory: function(e) {
        this.active_category = e
    },
    getActiveCategory: function(e) {
        return this.active_category
    },
    onMoreItemClick: function(e) {
        var t = this.wintoolbar.get("more");
        this.clearButtonSelected(), t.addClass("syno-d-button-selected"), t.setText(e.text), this.setActiveCategory(e.itemId), this.navigation.setCategory(e.itemId)
    },
    clearButtonSelected: function() {
        var e = this.wintoolbar.items.items;
        Ext.each(e, function(e) {
            e.removeClass("syno-d-button-selected")
        })
    },
    showHideDriveToolbar: function(e) {
        var t = 0,
            i = this.wintoolbar.getWidth() - 60;
        Ext.each(this.driveToolbarList, function(i) {
            var n = this.wintoolbar.get(i);
            n.setVisible(e), t += n.getWidth()
        }, this);
        var n = this.wintoolbar.get("back");
        if (!1 === this.openParams.from_upload && !1 === this.openParams.from_nas && !1 === this.openParams.from_url && !0 !== this.openParams.from_youtube_url ? n.setVisible(!1) : (n.setVisible(e), t += n.getWidth()), t <= i) return void this.wintoolbar.get("more").hide();
        var s = this.wintoolbar.get("more");
        s.setVisible(!0), t += s.getWidth();
        var o = this.driveToolbarList.length - 1;
        for (s.menu.removeAll(); t > i && o > 0;) {
            var r = this.driveToolbarList[o--],
                a = this.wintoolbar.get(r),
                l = this.getDriveToolbarItemCfg(r);
            Ext.apply(l, {
                handler: this.onMoreItemClick
            }), s.menu.addItem(l), t -= a.getWidth(), a.hide()
        }
        s.show()
    },
    setApplyBtnDisabled: function(e) {
        Ext.each(this.buttons, function(t) {
            "ok" === t.itemId && t.setDisabled(e)
        })
    },
    showHideMainToolbar: function(e) {
        Ext.each(this.mainToolbarList, function(t) {
            var i = this.wintoolbar.get(t);
            i && i.setVisible(e)
        }, this)
    },
    getPanel: function() {
        return this.getDrivePanel().getActivePanel()
    },
    getAction: function() {
        return this.actionmgr ? this.actionmgr : (this.actionmgr = new SYNO.SDS.Drive.Upload.ActionMgr({
            appWindow: this
        }), this.actionmgr)
    },
    getNavigation: function() {
        return this.navigation ? this.navigation : (this.navigation = new SYNO.SDS.Drive.Comp.Navigation({
            appWindow: this
        }), this.addManagedComponent(this.navigation), this.navigation)
    },
    GetOneSeleted: function() {
        return this.getPanel().getSelections()[0]
    },
    GetSeletions: function() {
        return this.getPanel().getSelections()
    },
    GetSeletionIds: function() {
        var e = this.getPanel().getSelections(),
            t = [];
        return Ext.each(e, function(e) {
            t.push(e.id)
        }), t
    },
    getAllowDblClick: function() {
        return this.openParams && this.openParams.allowDblClick
    },
    destroy: function() {
        this.callParent(arguments), this.navigation = null, this.actionmgr = null, this.eventmgr = null
    }
}), Ext.define("SYNO.SDS.Drive.Upload.IFrameApplication", {
    extend: "SYNO.SDS.Drive.Upload.Application",
    appWindowName: "SYNO.SDS.Drive.Upload.IFrameMainWindow",
    constructor: function(e) {
        this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.Drive.Upload.IFrameMainWindow", {
    extend: "SYNO.SDS.Drive.Upload.MainWindow",
    constructor: function(e) {
        this.origin = window.location.protocol + "//" + window.location.host, this.callParent(arguments), Ext.getBody().addClass(["syno-d-theme", "syno-drive-theme"])
    },
    getHeight: function() {
        return Ext.getBody().getViewSize().height
    },
    getWidth: function() {
        return Ext.getBody().getViewSize().width
    },
    onAfterLayout: function() {
        window.parent.postMessage({
            action: "afterlayout"
        }, this.origin)
    },
    onApply: function() {
        if (!this.layout.activeItem.isValid()) return void this.getMsgBox().alert("", this.layout.activeItem.getError() || _T("common", "forminvalid"));
        var e = this.getResult();
        window.parent.postMessage({
            action: "apply",
            result: e
        }, this.origin)
    },
    close: function() {
        window.parent.postMessage({
            action: "close"
        }, this.origin)
    }
}), Ext.define("SYNO.SDS.Drive.MenuUtils", {
    statics: {
        onShowHideMenu: function(e) {
            var t, i, n = !1,
                s = null,
                o = 0;
            for (e instanceof Ext.util.MixedCollection && (e = e.items), Ext.each(e, function(e) {
                    e instanceof Ext.menu.Separator && e.show()
                }), t = 0, i = e.length; t >= 0 && t < i; t++) {
                var r = e.get ? e.get(t) : e[t];
                r instanceof Ext.menu.Separator && !r.hidden ? (n || 0 === t || 0 === o ? r.hide() : s = r, n = !0) : r.hidden || (o++, n = !1, s = null)
            }
            s && s.hide()
        }
    }
}), Ext.define("SYNO.SDS.Drive.TaskMgr", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.appWindow = e.appWindow, this.queue = {
            upload: new SYNO.SDS.Drive.UploadTaskQueue({
                idx: 0,
                appWindow: this.appWindow,
                maxConcurrency: 1
            }),
            background: new SYNO.SDS.Drive.TaskQueue({
                idx: 1,
                appWindow: this.appWindow
            })
        }, this.statusBitset = 0, this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        Ext.iterate(this.queue, function(e, t) {
            this.mon(t, {
                scope: this,
                oncomplete: this.onAllComplete
            })
        }, this), this.mon(this.appWindow.getEventMgr(), "envready", this.initBgTask, this)
    },
    initBgTask: function() {
        SYNO.SDS.Drive.WindowHelper.isPublicShare() && !SYNO.SDS.Drive.Utils.isLogined() || SYNO.SDS.Drive.WebAPICore.sendPromise("list_tasks").then(this._addExistTasks.bind(this)).catch(Ext.emptyFn)
    },
    _addExistTasks: function(e) {
        Ext.each(e.items, function(e) {
            if ("finished" === e.status || !e.result || "download" === e.result.action) return void(e.result && "download" === e.result.action && SYNO.SDS.Drive.WebAPICore.send("delete_task", {
                task_id: e.result.task_id
            }));
            this.addTask(SYNO.SDS.Drive.TaskFactory.createBgTask({
                title: e.result.action,
                name: e.result.names,
                params: e.result.params,
                total: e.result.total_size,
                progress: e.progress,
                async_task_id: e.task_id,
                showProgress: !1,
                showStartToast: !1,
                pollingOnly: !0
            }))
        }, this)
    },
    getTask: function(e) {
        var t = this._getTaskType(e);
        return this.queue[t] ? this.queue[t].get(e) : null
    },
    addTask: function(e) {
        e && e.type && this.queue[e.type] && -1 === this.queue[e.type].find(e.taskid) && (e.taskmgr = this, this.queue[e.type].push(e), this.fireEvent("ontaskadd", e), this.statusBitset |= 1 << this.queue[e.type].idx, this.appWindow.getEventMgr().fireEvent("bgtask_update", !0, !0))
    },
    addTasks: function(e) {
        Ext.each(e, function(e) {
            this.addTask(e)
        }, this)
    },
    removeTask: function(e) {
        var t = this._getTaskType(e);
        this.queue[t].remove(e), this.fireEvent("ontaskremove", e)
    },
    removeTasks: function(e) {
        Ext.each(e, function(e) {
            this.removeTask(e)
        }, this)
    },
    restartTask: function(e) {
        var t = this.getTask(e),
            i = t.clone();
        this.removeTask(e), this.addTask(i)
    },
    restartTasks: function(e) {
        Ext.each(e, function(e) {
            this.restartTask(e)
        }, this)
    },
    onAllComplete: function(e) {
        this.statusBitset ^= 1 << e.idx, 0 === this.statusBitset && this.appWindow.getEventMgr().fireEvent("bgtask_update", void 0, !1)
    },
    _getTaskType: function(e) {
        var t = e.indexOf("_");
        return -1 === t ? e : e.substr(0, t)
    }
}), Ext.define("SYNO.SDS.Drive.TaskQueue", {
    extend: "Ext.util.Observable",
    autoStart: !0,
    maxConcurrency: -1,
    currentProcessing: 0,
    queue: [],
    constructor: function(e) {
        Ext.apply(this, e || {}), this.callParent(arguments)
    },
    push: function(e) {
        if (-1 !== this.find(e.taskid)) return void SYNO.Debug.error("Task is already exist");
        this.queue.push(e), this.process(e)
    },
    get: function(e) {
        var t = this.find(e);
        return this.queue[t]
    },
    remove: function(e) {
        var t = this.find(e);
        if (-1 !== t) {
            var i = this.queue[t];
            this.queue.splice(t, 1), i.stop(), i.destroy()
        }
    },
    clear: function() {
        this.queue = []
    },
    find: function(e) {
        var t = 0;
        for (t = 0; t < this.queue.length; ++t)
            if (this.queue[t].taskid === e) return t;
        return -1
    },
    pause: function() {
        this.autoStart = !1
    },
    resume: function() {
        this.autoStart = !0
    },
    process: function(e) {
        !this.autoStart || 0 === this.queue.length || -1 !== this.maxConcurrency && this.currentProcessing >= this.maxConcurrency || e && (this.currentProcessing++, e.start().then(this._processNext.createDelegate(this, [e]), this._processNext.createDelegate(this, [e])))
    },
    _processNext: function(e) {
        var t = null;
        return this.currentProcessing--, Ext.each(this.queue, function(e) {
            if ("wait" === e.status) return t = e, !1
        }), t ? this.process(t) : this.fireEvent("oncomplete", this), t
    }
}), Ext.define("SYNO.SDS.Drive.UploadTaskQueue", {
    extend: "SYNO.SDS.Drive.TaskQueue",
    toastSuccTasks: [],
    toastErrTasks: [],
    notificationTasks: [],
    _processNext: function(e) {
        var t = !0;
        "stopped" !== e.status && ("success" !== e.status ? (this.toastErrTasks.push(e), this.notificationTasks.push(e)) : this.toastSuccTasks.push(e)), null === this.callParent(arguments) && (t = !1), this._showToast(t), this._sendNotification(t)
    },
    _showToast: function(e) {
        if (this.delayToastTask && (window.clearTimeout(this.delayToastTask), this.delayToastTask = null), e) return void(this.delayToastTask = this._showToast.defer(1500, this));
        Ext.isEmpty(this.toastSuccTasks) && Ext.isEmpty(this.toastErrTasks) || (this.appWindow.getEventMgr().fireEvent("uploadcomplete", this.toastSuccTasks), SYNO.SDS.Drive.Utils.showToastMsg(this.appWindow, this.getToastMessage(), 3e3), this.toastSuccTasks = [], this.toastErrTasks = [])
    },
    _sendNotification: function(e) {
        if (this.delayNotifyTask && (window.clearTimeout(this.delayNotifyTask), this.delayNotifyTask = null), e) return void(this.delayNotifyTask = this._sendNotification.defer(1e4, this));
        if (!Ext.isEmpty(this.notificationTasks)) {
            var t = this.getNotificationData(this.notificationTasks);
            SYNO.SDS.Drive.WebAPICore.send("create_notification", {
                content: t,
                type: "drive#upload_task"
            }), this.notificationTasks = []
        }
    },
    getToastMessage: function() {
        var e, t, i = "",
            n = "";
        return Ext.isEmpty(this.toastSuccTasks) || (t = 1 < this.toastSuccTasks.length, e = String.format("upload{0}_{1}", t ? "_multi" : "", "success"), t || Ext.each(this.toastSuccTasks[0].name, function(e) {
            "" !== n && (n += ", "), n += SYNO.SDS.Drive.Utils.parseDisplayName(e)
        }), n = Ext.util.Format.htmlEncode(n), i = String.format(SYNO.SDS.Drive._T("task", e), t ? this.toastSuccTasks.length : String.format('"{0}"', n))), Ext.isEmpty(this.toastErrTasks) || (Ext.isEmpty(i) || (i += "<br>"), t = 1 < this.toastErrTasks.length, e = String.format("upload{0}_{1}", t ? "_multi" : "", "error"), t || Ext.each(this.toastErrTasks[0].name, function(e) {
            "" !== n && (n += ", "), n += SYNO.SDS.Drive.Utils.parseDisplayName(e)
        }), n = Ext.util.Format.htmlEncode(n), i += String.format(SYNO.SDS.Drive._T("task", e), t ? this.toastErrTasks.length : String.format('"{0}"', n))), i
    },
    getNotificationData: function(e) {
        if (!Ext.isEmpty(e)) {
            var t = e.map(function(e) {
                return {
                    context: {
                        name: e.name,
                        file_type: e.blUploadDir ? "dir" : "file"
                    },
                    code: e.errors[0].code
                }
            });
            return {
                action: "upload",
                names: t.map(function(e) {
                    return e.context.name
                }),
                errors: t,
                success: !1
            }
        }
    }
});
