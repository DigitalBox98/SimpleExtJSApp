/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.Drive.FilePanel", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.initLaunch(), this.capabilities = {
            preview: SYNO.SDS.Drive.GetWindow().getAction().ActionPrivChecker.check("preview", this.getRecord()).display,
            download: SYNO.SDS.Drive.GetWindow().getAction().ActionPrivChecker.check("download", this.getRecord()).display
        };
        var t = [{
            xtype: "box",
            cls: this.getFileTypeIconCls(),
            width: 128,
            height: 128
        }, {
            xtype: "box",
            width: 1,
            height: 16
        }, this.title = new Ext.BoxComponent({
            xtype: "box",
            cls: "syno-d-file-title-box",
            html: this.getTitle(window.getDriveFile().starred)
        }), {
            xtype: "box",
            width: 1,
            height: 24,
            hidden: !this.capabilities.preview
        }, this.getViewBtn(), {
            xtype: "box",
            width: 1,
            height: 8,
            hidden: !this.capabilities.download
        }, this.getDownloadBtn()];
        this.isAllowAction() && t.push({
            xtype: "box",
            width: 1,
            height: 8
        }, this.getStarBtn(), {
            xtype: "box",
            width: 1,
            height: 8
        }, this.getLabelBtn());
        var i = {
            cls: "syno-d-file-background",
            xtype: "container",
            layout: {
                type: "vbox",
                align: "center",
                pack: "center",
                padding: "-32 32 0 32"
            },
            items: [{
                xtype: "container",
                height: 478,
                width: 360,
                cls: "syno-d-file-container",
                defaults: {
                    border: !1
                },
                border: !1,
                layout: {
                    type: "vbox",
                    align: "center",
                    pack: "center"
                },
                items: t,
                listeners: {
                    scope: this,
                    single: !0,
                    afterlayout: function(e) {
                        if (!this.isAllowAction()) return void this.updateEllipsis();
                        var t = 0;
                        e.items.each(function(e, i, n) {
                            "syno_button" === e.xtype && t < e.getWidth() && (t = e.getWidth())
                        }), 202 < t && (e.items.each(function(e, i, n) {
                            "syno_button" === e.xtype && e.el.setStyle("min-width", t - 2 + "px")
                        }), e.doLayout()), this.updateEllipsis()
                    }
                }
            }]
        };
        Ext.apply(i, e), this.callParent([i]), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = SYNO.SDS.Drive.GetWindow();
        if (!e.getPlugin().ready) {
            var t = e.getEventMgr();
            this.mon(t, {
                scope: this,
                openpluginready: this.onOpenPluginReady
            })
        }
        this.on("render", function() {
            SYNO.SDS.Drive.GetWindow().getAction().openUniversalViewer(this.getRecord())
        }, this)
    },
    onOpenPluginReady: function() {
        this.getViewBtn().setText(this.getViewBtnText())
    },
    initLaunch: Ext.emptyFn,
    getRecord: function() {
        var e = window.getDriveFile();
        return new Ext.data.JsonReader({
            id: "file_id",
            fields: SYNO.SDS.Drive.ViewStore.Node.prototype.getReaderFields()
        }).extractData([e], !0)[0]
    },
    updateEllipsis: function() {
        var e = Ext.fly(this.titleId);
        e.setWidth(e.getWidth())
    },
    getTitle: function(e) {
        var t = SYNO.SDS.Drive.Utils.parseDisplayName(window.getDriveFile().name),
            i = Ext.util.Format.htmlEncode(t);
        return String.format('<table cellspacing="0" cellpadding="0" border="0"><tr>{0}<td ext:qtip="{1}" id="{2}" class="syno-d-file-title">{3}</td></tr></table>', this.getStarIcon(e), Ext.util.Format.htmlEncode(i), this.titleId = Ext.id(), i)
    },
    getStarIcon: function(e) {
        return this.isAllowAction() && !1 !== e ? String.format('<td class="{0}"></td>', e ? "syno-d-start-icon syno-d-start-icon-check" : "syno-d-start-icon") : ""
    },
    getFileTypeIconCls: function() {
        var e = window.getDriveFile();
        return SYNO.SDS.Drive.FileType.getMappingTypeCss(SYNO.SDS.Drive.Utils.getNtype(e.name, e.type), 128)
    },
    isAllowAction: function() {
        return SYNO.SDS.Drive.Utils.isAppAuthorized() && !window.getDriveFile().removed && !SYNO.SDS.Drive.WindowHelper.isAdvShare()
    },
    getViewBtnText: function() {
        return SYNO.SDS.Drive.Utils.isLogined() ? SYNO.SDS.Drive.GetWindow().getPlugin().ready ? SYNO.SDS.Drive.GetWindow().getAction().checkOpenNewWin(this.getRecord()) ? SYNO.SDS.Drive._T("action", "view") : SYNO.SDS.Drive._T("action", "preview") : SYNO.SDS.Drive._T("action", "view") : SYNO.SDS.Drive._T("action", "preview")
    },
    getViewBtn: function() {
        return this.viewBtn ? this.viewBtn : (this.viewBtn = new SYNO.ux.Button({
            cls: "syno-d-file-btn",
            xtype: "syno_button",
            btnStyle: "default",
            text: this.getViewBtnText(),
            autoWidth: !0,
            height: 36,
            scope: this,
            hidden: !this.capabilities.preview,
            handler: function() {
                this.findAppWindow().getAction().previewNode(this.getRecord())
            }
        }), this.viewBtn)
    },
    getDownloadBtn: function() {
        return this.downloadBtn ? this.downloadBtn : (this.downloadBtn = new SYNO.ux.Button({
            cls: "syno-d-file-btn",
            xtype: "syno_button",
            btnStyle: "default",
            text: SYNO.SDS.Drive._T("action", "download"),
            autoWidth: !0,
            height: 36,
            scope: this,
            hidden: !this.capabilities.download,
            handler: function() {
                var e = window.getDriveFile();
                this.findAppWindow().getAction().downloadNode({
                    data: e
                })
            }
        }), this.downloadBtn)
    },
    getStarBtn: function() {
        return this.starBtn ? this.starBtn : (this.starred = window.getDriveFile().starred, this.starBtn = new SYNO.ux.Button({
            cls: "syno-d-file-btn",
            xtype: "syno_button",
            btnStyle: "default",
            text: this.starred ? SYNO.SDS.Drive._T("star", "remove") : SYNO.SDS.Drive._T("star", "add"),
            autoWidth: !0,
            height: 36,
            scope: this,
            handler: function() {
                var e = window.getDriveFile().file_id,
                    t = this.findAppWindow().getAction();
                this.starred ? t.deleteShortcut({
                    file_id: [e]
                }) : t.setShortcut({
                    file_id: [e]
                }), this.starred = !this.starred, this.updateStar(this.starred)
            }
        }), this.starBtn)
    },
    getLabelBtn: function() {
        return this.labelBtn ? this.labelBtn : (this.labelBtn = new SYNO.ux.Button({
            cls: "syno-d-file-btn syno-d-file-label-btn",
            xtype: "syno_button",
            btnStyle: "default",
            text: SYNO.SDS.Drive._T("category", "label"),
            autoWidth: !0,
            height: 36,
            menu: new SYNO.SDS.Drive.SearchTagMenu({
                GetSeletions: function() {
                    return [{
                        labels: Ext.isEmpty(this.labels) ? SYNO.SDS.Drive.Env.labels : this.labels
                    }]
                }.createDelegate(this),
                store: this.getTagStore(),
                listeners: {
                    scope: this,
                    apply: this.onChangeTag,
                    beforeshow: function() {
                        this.reloadLabelData()
                    }
                }
            })
        }), this.labelBtn)
    },
    updateStar: function(e) {
        this.getStarBtn().setText(e ? SYNO.SDS.Drive._T("star", "remove") : SYNO.SDS.Drive._T("star", "add")), this.title.update(this.getTitle(e)), this.doLayout()
    },
    getTagStore: function() {
        return this.tagStore ? this.tagStore : (this.tagStore = new SYNO.API.Store({
            autoLoad: SYNO.SDS.Drive.Utils.isAppAuthorized(),
            remoteSort: !1,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.SynologyDrive.Labels",
                version: 1,
                method: "list",
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                id: "label_id"
            }, [{
                name: "label_id"
            }, {
                name: "name"
            }, {
                name: "color",
                convert: function(e, t) {
                    return e.substr(1)
                }
            }, {
                name: "position"
            }, {
                name: "category",
                defaultValue: "label"
            }])
        }), SYNO.SDS.Drive.GetWindow().addManagedComponent(this.tagStore), this.tagStore)
    },
    onChangeTag: function(e, t, i) {
        var n = [],
            o = this.findAppWindow();
        Ext.each(e, function(e, t, i) {
            n.push({
                action: "add",
                label_id: e.label_id
            })
        }), Ext.each(t, function(e, t, i) {
            n.push({
                action: "delete",
                label_id: e.label_id
            })
        }), this.labels = i, o.getAction().setNodeTag({
            file_id: [window.getDriveFile().file_id],
            labels: n
        }, function(e, t) {
            e ? this.reloadLabelData() : (this.labels = null, this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t)))
        }, this)
    },
    reloadLabelData: function() {
        this.getTagStore().reload(), this.findAppWindow().getAction().getNode({
            file_id: window.getDriveFile().file_id
        }, function(e, t) {
            this.labels = null, e && SYNO.SDS.Drive.Env.set(t)
        }, this)
    }
}), Ext.define("SYNO.SDS.Drive.ViewPanel.TreeDragZone", {
    extend: "Ext.tree.TreeDragZone",
    proxy: new Ext.dd.StatusProxy({
        animRepair: !1
    }),
    constructor: function(e, t) {
        this.callParent(arguments), this.tree = e, this.removeInvalidHandleType("a"), this.labelRecord = Ext.data.Record.create([{
            name: "label_id"
        }, {
            name: "color"
        }, {
            name: "category"
        }, {
            name: "title"
        }]), this.nodeRecord = Ext.data.Record.create([{
            name: "file_id"
        }, {
            name: "ntype"
        }, {
            name: "parent_id"
        }, {
            name: "name"
        }])
    },
    beforeDragOut: function(e, t, i) {
        return !0
    },
    getDragData: function(e) {
        var t = this.callParent(arguments);
        if (t && t.node) {
            var i = t.node.attributes.category;
            if ("label" === i) {
                var n = t.node.parentNode.indexOf(t.node);
                return Ext.apply(t, {
                    selections: [new this[i + "Record"](t.node.attributes)],
                    index: n,
                    tree: this.tree,
                    category: i
                }), t
            }
        }
    }
}), Ext.define("SYNO.SDS.Drive.ViewPanel.TreeDropZone", {
    extend: "Ext.tree.TreeDropZone",
    constructor: function(e, t) {
        this.callParent(arguments), this.tree = e
    },
    isNodeAllowDrop: function(e, t) {
        var i = e.node;
        if (!i || !i.parentNode) return !1;
        var n = !0,
            o = this.getNodeCategoryFromNodeId(i.id);
        if ("label" === t.category && "label" !== o) return !1;
        switch (o) {
            case "shared_with_me":
            case "sharing_to_others":
            case "recent":
            case "starred":
            case "recycle":
            case "tag_label":
                n = !1;
                break;
            default:
                "team_folder" === i.id && (n = !1)
        }
        if (n) {
            var r = SYNO.SDS.Drive.GetWindow().getNavigation(),
                a = r.getCategory();
            ("recycle" === a || "label" !== o && "shared_with_me" === a && r.isRootPath()) && (n = !1)
        }
        return !!n || (e.ddel.classList.remove("x-tree-node-over"), !1)
    },
    onNodeEnter: function(e, t, i, n) {
        this.isNodeAllowDrop(e, n) && e.node.ui.elNode.classList.add("syno-d-tree-node-dragover")
    },
    onNodeOut: function(e, t, i, n) {
        this.isNodeAllowDrop(e, n) && e.node.ui.elNode.classList.remove("syno-d-tree-node-dragover")
    },
    onNodeOver: function(e, t, i, n) {
        return this.updateDDText(t, i, n), this.isNodeAllowDrop(e, n)
    },
    getNodeCategoryFromNodeId: function(e) {
        var t = e.indexOf(":");
        return -1 === t ? e : e.substr(0, t)
    },
    onNodeDrop: function(e, t, i, n) {
        if (this.isNodeAllowDrop(e, n)) {
            var o = e.node,
                r = o.parentNode.indexOf(o),
                a = n.selections;
            if (n.tree) return void("label" === n.category && this.reorderTag(r, n, a, e.node));
            var s = n.grid || n.dataview;
            if (s instanceof SYNO.SDS.Drive.ViewPanel.GridPanel || s instanceof SYNO.SDS.Drive.ViewPanel.DataViewPanel) {
                if ("recycle" === s.findAppWindow().getNavigation().getCategory()) return;
                switch (this.getNodeCategoryFromNodeId(o.id)) {
                    case "team_folder":
                    case "node":
                        this.moveNode(o, s, a);
                        break;
                    case "label":
                        this.addTag(r, s, a)
                }
            } else;
        }
    },
    updateDDText: function(e, t, i) {
        e.getProxy().getGhost().update(this.getDragDropText(i.selections))
    },
    getDragDropText: function(e) {
        var t = e.length;
        if (0 !== t) {
            return "<span class='syno-d-drag-text'>" + SYNO.SDS.Drive.Utils.parseDisplayName(Ext.util.Format.htmlEncode(e[0].data.name)) + "</span>" + (1 < t ? "<span class='syno-d-drag-num'>" + (t > 99 ? "99+" : t) + "</span>" : "")
        }
    },
    reorderTag: function(e, t, i, n) {
        this.tree.labelRootNode.insertBefore(t.node, t.index < e ? n.nextSibling : n), t.tree.findAppWindow().getAction().setTag({
            label_id: i[0].get("label_id"),
            position: e
        }, function(e, t) {
            e || SYNO.SDS.Drive.GetWindow().getEventMgr().fireEvent("settagdone")
        }, void 0, void 0, !1)
    },
    moveNode: function(e, t, i) {
        var n;
        n = "node" === e.id ? SYNO.SDS.Drive.Define.Info.drive_id : SYNO.SDS.Drive.Utils.getFileIdFromPathId(e.id), t.findAppWindow().getAction().moveNode({
            to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(n),
            to_parent_folder_name: e.text
        })
    },
    addTag: function(e, t, i) {
        var n = this.tree.getStore().getAt(e);
        return !!n && (t.findAppWindow().getAction().changeTagByRec([n.data], [], i), !0)
    }
}), Ext.define("SYNO.SDS.Drive.ViewPanel.GridPanel", {
    extend: "SYNO.SDS.Drive.Comp.GridPanel",
    constructor: function(e) {
        var t = {
            enableDragDrop: !SYNO.SDS.Drive.WindowHelper.isPublicShare(),
            ddGroup: "DriveMgrDD",
            minColumnWidth: 25,
            listeners: {
                scope: this,
                afterlayout: {
                    scope: this,
                    buffer: 200,
                    fn: this.onAfterLayout
                },
                afterrender: {
                    scope: this,
                    single: !0,
                    fn: function(t) {
                        SYNO.SDS.Drive.WindowHelper.isPublicShare() || (t.getView().dragZone && t.getView().dragZone.destroy(), t.getView().dragZone = new Ext.grid.GridDragZone(t, {
                            ddGroup: t.ddGroup || "GridDD",
                            onBeforeDrag: function(e, t) {
                                var i = SYNO.SDS.Drive.GetWindow().getNavigation(),
                                    n = i.getCategory();
                                return !("recycle" === n || "team_folder" === n && i.isRootPath())
                            }
                        })), this.dropTarget || (this.dropTarget = new SYNO.SDS.Drive.ViewPanel.GridDropTarget(t, {
                            panel: t,
                            ddGroup: "DriveMgrDD"
                        })), e.allowDragFile && this.initDragDrop()
                    }
                },
                show: this.onShowPanel,
                activate: this.onActivate,
                deactivate: this.onDeActivate,
                beforedestroy: function() {
                    this.dropTarget && this.dropTarget.removeFromGroup(this.ddGroup)
                },
                rowclick: function(e, t, i) {
                    i && t >= 0 && !i.hasModifier() && e.getSelectionModel().selectRow(t)
                },
                rowdblclick: this.onDoubleClick,
                rowcontextmenu: this.gridRowToolBarMenu,
                containercontextmenu: function(e, t) {
                    e.getSelectionModel().clearSelections(), this.onShowContextMenu(t)
                },
                sortchange: this.saveSortInfo,
                resize: {
                    scope: this,
                    buffer: 100,
                    fn: function() {
                        this.updateColumn(), this.updateFleXcroll()
                    }
                }
            }
        };
        Ext.apply(t, e || {}), this.callParent([t])
    },
    getGridView: function() {
        var e = this.findAppWindow();
        return new SYNO.SDS.Drive.Comp.GridView({
            rowHeight: "detail" === this.mode ? 48 : 36,
            borderHeight: 2,
            cacheSize: 30,
            scrollDelay: !1,
            forceFit: !0,
            disableTextSelect: !0,
            onUpdate: function(t, i, n) {
                if (this.grid.isVisible()) {
                    var o = this.getVisibleRows(),
                        r = t.indexOf(i);
                    if (r >= o.first - this.cacheSize && r <= o.last + this.cacheSize) {
                        var a = 0 === e.modalWin.length && this.grid.getSelectionModel().isSelected(i);
                        this.refreshRow(i), a && this.focusEl.focus()
                    }
                }
            },
            onLoad: function() {
                var e = this;
                e.preserveScroll || e.updateScroller(e.trackResetOnLoad)
            },
            onRowOver: function(e, t) {
                var i, n = this.findRow(t);
                if (!1 !== (i = !!n && n.rowIndex) && (n = this.getRow(i))) {
                    var o;
                    if (Ext.dd.DragDropMgr.dragCurrent && Ext.dd.DragDropMgr.dragCurrent.getProxy && (o = Ext.dd.DragDropMgr.dragCurrent.getProxy()), o && o.getGhost() && o.getGhost().isVisible()) {
                        if (Ext.dd.DragDropMgr.dragCurrent.dragData.grid instanceof SYNO.SDS.Drive.ViewPanel.GridPanel) {
                            if ("dir" !== this.grid.store.getAt(i).data.ntype) return
                        }
                        this.fly(n).addClass([this.rowOverCls, "syno-d-grid-row-drag"]), this.grid.mon(this.fly(n), "drop", function() {
                            this.fly(n).removeClass("syno-d-grid-row-drag")
                        }, this, {
                            single: !0
                        })
                    } else this.fly(n).addClass(this.rowOverCls)
                }
            },
            onRowOut: function(e, t) {
                var i, n = this.findRow(t);
                !1 === (i = !!n && n.rowIndex) || e.within(this.getRow(i), !0) || (n = this.getRow(i)) && (this.fly(n).removeClass([this.rowOverCls, "syno-d-grid-row-drag"]), this.fly(n).removeAllListeners())
            },
            updateSortIcon: function(e, t) {
                if ("recent" !== SYNO.SDS.Drive.GetWindow().getNavigation().getCategory()) {
                    var i = this.sortClasses,
                        n = i["DESC" === t.toUpperCase() ? 1 : 0],
                        o = this.mainHd.select("td").removeClass(i),
                        r = o.item(e);
                    r && r.addClass(n)
                }
            },
            fitColumns: function(e, t, i) {
                this.forceFit && SYNO.SDS.Drive.Comp.GridView.prototype.fitColumns.call(this, e, t, i)
            },
            listeners: {
                scope: this,
                buffer: 100,
                rowupdated: function() {
                    this.updateColumnWidth(!0)
                }
            }
        })
    },
    getSelModel: function() {
        return new Ext.grid.RowSelectionModel({
            listeners: {
                scope: this,
                selectionchange: this.onSelectionChange
            }
        })
    },
    getActiveStore: function() {
        return this.activeStore = this.findAppWindow().getStoreMgr().getActiveStore(), this.activeStore
    },
    onAfterLayout: function(e) {
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var t = this.findAppWindow().appInstance.getUserSettings("gridstates");
            if (t) {
                var i = this.getColumnMapping();
                t.hasOwnProperty(i) && this.getColumnState() && e.applyState(t[i])
            }
            this.updateColumn()
        }
    },
    getColumnState: function() {
        if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) return !1;
        var e, t = 0,
            i = this.findAppWindow().appInstance.getUserSettings("gridstates");
        if (i) {
            var n = this.getColumnMapping();
            if (i.hasOwnProperty(n)) {
                e = i[n].columns;
                for (var o = 0; o < e.length; o++) e[o].hidden || (t += e[o].width)
            }
            var r = this.getGridCM().getTotalWidth();
            if (r - 10 <= t && r + 10 >= t) return e
        }
        return !1
    },
    saveState: function(e) {
        if (this.callParent(arguments), !SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var t = this.findAppWindow().appInstance.getUserSettings("gridstates") || {},
                i = this.getColumnMapping(),
                n = this.getState(),
                o = Ext.apply({}, n);
            delete o.sort, delete o.group, t[i] = o, this.findAppWindow().appInstance.setUserSettings("gridstates", t)
        }
    },
    saveSortInfo: function() {
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var e = this.findAppWindow(),
                t = e.getNavigation(),
                i = t.getCategory();
            if ("recent" !== i && "search" !== i) {
                var n = this.getStore();
                if (!n.reconfiguring) {
                    var o = e.appInstance.getUserSettings("gridsortstates") || {},
                        r = n.getSortState();
                    r && (o = r, e.appInstance.setUserSettings("gridsortstates", o))
                }
            }
        }
    },
    gridRowToolBarMenu: function(e, t, i) {
        var n = e.getSelectionModel();
        n.isSelected(t) || n.selectRow(t), this.onShowContextMenu(i)
    },
    getNameColumn: function() {
        return new("detail" === this.mode ? SYNO.SDS.Drive.Comp.DetailNameColumn : SYNO.SDS.Drive.Comp.NameColumn)({
            appWindow: this.findAppWindow(),
            width: 200,
            hidden: !1,
            dataIndex: "name",
            header: SYNO.SDS.Drive._T("file", "title"),
            listeners: {
                buffer: 100,
                scope: this,
                change: function(e, t, i, n, o, r, a) {
                    var s = this.findAppWindow();
                    n ? s.getAction().deleteShortcut({
                        file_id: s.GetSeletionIds()
                    }) : s.getAction().setShortcut({
                        file_id: s.GetSeletionIds()
                    })
                }
            }
        })
    },
    getGridCM: function() {
        return this.gridcm ? this.gridcm : (this.gridcm = new Ext.grid.ColumnModel({
            defaults: {
                menuDisabled: !0,
                sortable: !0,
                hidden: !1
            },
            columns: [this.getNameColumn(), this.getOwnerColumn(), this.getTimeColumn({
                dataIndex: "mtime",
                header: SYNO.SDS.Drive._T("file", "mtime")
            }), this.getTimeColumn({
                dataIndex: "atime",
                header: SYNO.SDS.Drive._T("common", "atime"),
                hidden: !0
            }), this.getSizeColumn(), this.getLabelsColumn(), {
                dataIndex: "display_path",
                header: SYNO.SDS.Drive._T("file", "location"),
                sortable: !1,
                hidden: !0,
                width: 250,
                renderer: function(e, t, i) {
                    e = "recycle" === SYNO.SDS.Drive.GetWindow().getNavigation().getCategory() ? SYNO.SDS.Drive.Utils.parseDisplayPath(i.data.original_path) : SYNO.SDS.Drive.Utils.parseDisplayPath(e);
                    var n = Ext.util.Format.htmlEncode(e);
                    return t.css = "syno-d-location-colume", t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(n) + '"', n
                }
            }, this.getPermissionsColumn()],
            listeners: {
                scope: this,
                hiddenchange: this.updateColumn
            }
        }), this.gridcm)
    },
    onSelectionChange: function() {
        this.findAppWindow().getEventMgr().fireEvent("nodeselectchange")
    },
    addRemoveCutClass: function(e, t) {
        var i = this.getActiveStore().indexOfId(e.id);
        t ? this.getView().addRowClass(i, "syno-d-file-cut") : this.getView().removeRowClass(i, "syno-d-file-cut")
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.ViewPanel.GridDropTarget", {
    extend: "SYNO.SDS.Drive.Comp.DropTarget",
    constructor: function(e, t) {
        this.ddTarget = e, this.store = e.store, this.callParent([e.getView().scroller.dom, t])
    },
    notifyOverAndDrop: function(e, t, i, n) {
        if (!1 === e) return !1;
        var o = this.ddTarget.getStore().getAt(e);
        if (!o) return !1;
        var r = this.ddTarget.findAppWindow().getNavigation(),
            a = r.getCategory();
        if ("recycle" === a || "team_folder" === a && r.isRootPath()) return !1;
        if (n.grid instanceof SYNO.SDS.Drive.ViewPanel.GridPanel) {
            if ("shared_with_me" === a && r.isRootPath()) return !1;
            if ("dir" !== o.data.type) return !1
        } else if (Ext.isEmpty(n.selections) || !this.isDropCategory(n.selections[0].data.category)) return !1;
        return !0
    },
    notifyDrop: function(e, t, i) {
        var n = this.getDDIndex(t),
            o = this.ddTarget;
        if (!this.notifyOverAndDrop(n, e, t, i) || i.selections[0] === this.ddTarget.getStore().getAt(n)) return !1;
        var r = o.getStore().getAt(n);
        if (!r) return !1;
        var a = o.findAppWindow();
        return i.grid instanceof SYNO.SDS.Drive.ViewPanel.GridPanel ? a.getAction().moveNode({
            to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(r.get("file_id")),
            to_parent_folder_name: r.get("name")
        }) : a.getAction().changeTagByRec([i.selections[0].data], [], [r]), !0
    },
    getDDIndex: function(e) {
        return this.ddTarget.view.findRowIndex(e.getTarget())
    }
}), Ext.define("SYNO.SDS.Drive.ViewPanel.DataViewPanel", {
    extend: "SYNO.SDS.Drive.Comp.DataViewPanel",
    constructor: function() {
        this.callParent(arguments), this.mon(this, "afterlayout", function() {
            this.mon(this.getEl(), {
                contextmenu: function(e) {
                    e.within(this.dataview.getTemplateTarget()) || this.onShowDataViewContainerMenu(this.dataview, e)
                },
                scope: this
            })
        }, this, {
            single: !0,
            buffer: 80
        })
    },
    createDataView: function(e) {
        return new e({
            store: null,
            enableDragDrop: !0,
            dragConfig: {
                owner: this,
                ddGroup: "DriveMgrDD"
            },
            dropConfig: {
                owner: this,
                ddGroup: "DriveMgrDD"
            },
            listeners: {
                scope: this,
                contextmenu: this.onShowDataViewMenu,
                containercontextmenu: this.onShowDataViewContainerMenu,
                dblclick: this.onDoubleClick,
                selectionchange: this.onDataSelectionChange
            }
        })
    },
    onShowDataViewMenu: function(e, t, i, n) {
        n.preventDefault(), this.dataview.isSelected(i) || this.dataview.select(i, !1), this.onShowContextMenu(n)
    },
    onShowDataViewContainerMenu: function(e, t) {
        t.getTarget(e.itemSelector, e.getTemplateTarget()) || e.clearSelections(), this.onShowContextMenu(t)
    },
    addRemoveCutClass: function(e, t) {
        var i = this.getActiveStore().indexOf(e),
            n = this.getView().getNode(i);
        if (n) {
            var o = Ext.fly(n);
            t ? o.addClass("syno-d-file-cut") : o.removeClass("syno-d-file-cut")
        }
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.ViewPanel.MainPanel", {
    extend: "SYNO.SDS.Drive.Comp.MainPanel",
    mixins: ["SYNO.SDS.Drive.Comp.HotkeyHandler"],
    constructor: function(e) {
        var t = {
            listeners: {
                afterrender: this.onAfterRender,
                scope: this
            }
        };
        this.callParent([Ext.apply(t, e)]), this.onRegEvent()
    },
    onRegEvent: function() {
        this.callParent(arguments);
        var e = this.appWin.getEventMgr();
        SYNO.SDS.Drive.WindowHelper.isPublicShare() || this.mon(e, {
            scope: this,
            beforecategorychange: this.onBeforeCategoryChange,
            viewpanelfail: this.onCheckToolbar
        })
    },
    onAfterRender: function() {
        this.createHotkeyMap()
    },
    getPanelItems: function() {
        var e = this.callParent(arguments);
        return e.push(this.getSnippetPanel()), e
    },
    getGrid: function() {
        return this.grid ? this.grid : this.grid = new SYNO.SDS.Drive.ViewPanel.GridPanel({
            itemId: "list",
            hideMode: "offsets",
            mode: "grid",
            allowDragFile: !SYNO.SDS.Drive.WindowHelper.isPublicShare(),
            owner: this
        })
    },
    getDetailPanel: function() {
        return this.detailpanel ? this.detailpanel : this.detailpanel = new SYNO.SDS.Drive.ViewPanel.GridPanel({
            itemId: "detail",
            hideMode: "offsets",
            mode: "detail",
            allowDragFile: !SYNO.SDS.Drive.WindowHelper.isPublicShare(),
            owner: this
        })
    },
    getActiveKeyMap: function() {
        return this.keyMap
    },
    getThumbnailPanel: function() {
        return this.thumbnailpanel ? this.thumbnailpanel : this.thumbnailpanel = new SYNO.SDS.Drive.ViewPanel.DataViewPanel({
            itemId: "thumbnail",
            cls: "syno-d-thumbnail-view",
            Dataview: SYNO.SDS.Drive.Comp.ThumbnailView,
            hideMode: "offsets",
            allowDragFile: !SYNO.SDS.Drive.WindowHelper.isPublicShare(),
            owner: this
        })
    },
    getTilePanel: function() {
        return this.tilepanel ? this.tilepanel : this.tilepanel = new SYNO.SDS.Drive.ViewPanel.DataViewPanel({
            itemId: "tile",
            cls: "syno-d-tile-view",
            Dataview: SYNO.SDS.Drive.Comp.TileView,
            hideMode: "offsets",
            allowDragFile: !SYNO.SDS.Drive.WindowHelper.isPublicShare(),
            owner: this
        })
    },
    getSnippetPanel: function() {
        return this.snippetpanel ? this.snippetpanel : this.snippetpanel = new SYNO.SDS.Drive.ViewPanel.DataViewPanel({
            itemId: "snippet",
            cls: "syno-d-snippet-view",
            Dataview: SYNO.SDS.Drive.Comp.SnippetView,
            hideMode: "offsets",
            allowDragFile: !1,
            owner: this
        })
    },
    getToolbar: function() {
        if (this.toolbar) return this.toolbar;
        var e;
        return e = SYNO.SDS.Drive.WindowHelper.isPublicShare() ? [this.getTitleActionTBar(), this.getNaviTBar()] : [this.getNaviTBar(), this.getActionTBar()], this.toolbar = new Ext.Container({
            cls: "syno-d-mgr-toolbar-container",
            layout: {
                type: "vbox",
                pack: "start",
                align: "stretch"
            },
            height: SYNO.SDS.Drive.WindowHelper.isPublicShare() ? 44 : 76,
            defaults: {
                flex: 1
            },
            items: e
        }), this.toolbar
    },
    getNaviTBar: function() {
        if (this.navitbar) return this.navitbar;
        var e = [this.getPathBar()];
        return SYNO.SDS.Drive.WindowHelper.isPublicShare() || e.push([{
            xtype: "box",
            width: 24
        }, this.getSearchField()]), this.navitbar = new Ext.Toolbar({
            height: SYNO.SDS.Drive.WindowHelper.isPublicShare() ? 40 : 36,
            items: e,
            listeners: {
                single: !0,
                afterlayout: function(e) {
                    this.mon(e, "resize", function() {
                        if (this.rendered) {
                            var e = 0,
                                t = this.navitbar;
                            t.items.each(function(t) {
                                !0 !== t.hidden && t.rendered && (e += t.getOuterSize().width)
                            }), e -= this.getPathBar().getWidth();
                            var i = t.getWidth() - t.getResizeEl().getPadding("lr"),
                                n = i - e + 1;
                            n > 0 && this.getPathBar().setWidth(n)
                        }
                    }, this)
                },
                scope: this
            }
        })
    },
    selectAll: function() {
        var e = this.getActivePanel().activeStore.data.length;
        this.getActivePanel().getSelectionModel().selectAll(e)
    },
    unSelect: function() {
        this.getActivePanel().getSelectionModel().clearSelections()
    },
    createNode: function(e) {
        this.findAppWindow().getAction().createNode({
            ntype: e.itemId
        })
    },
    onUploadApply: function(e, t) {
        if (0 !== t.length) {
            var i = this.findAppWindow(),
                n = i.getNavigation(),
                o = SYNO.SDS.Drive.Utils.getPathId(n.getLastPathId());
            switch (t[0].source) {
                case "from_pc":
                    var r = [],
                        a = [];
                    Ext.each(t, function(e) {
                        r.push(e.fileObj), a.push(e.fileEntry || void 0)
                    }), SYNO.SDS.Drive.TaskFactory.addUploadTasks(i, o, r, 0 === a.length ? void 0 : a);
                    break;
                case "from_nas":
                    var s = [],
                        l = [];
                    Ext.each(t, function(e) {
                        s.push(e.real_path), l.push(e.name)
                    }, this), i.getTaskMgr().addTask(SYNO.SDS.Drive.TaskFactory.createUploadFromNasTask(o, s, l))
            }
        }
    },
    getActionTBar: function() {
        if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) return this.getTitleActionTBar();
        if (this.actiontbar) return this.actiontbar;
        var e = SYNO.SDS.Drive._T,
            t = this.findAppWindow(),
            i = t.getAction(),
            n = [{
                itemId: "dir",
                text: e("file", "dir"),
                iconCls: "syno-d-dir-menu-icon",
                scope: this,
                handler: this.createNode
            }];
        SYNO.SDS.Drive.Utils.hasOffice() && (n.push({
            xtype: "menuseparator"
        }), SYNO.SDS.Office.Drive.genCreateMenu.call(this, n), n.push({
            xtype: "menuseparator"
        })), n.push({
            itemId: "upload",
            text: e("upload", "add_files"),
            iconCls: "syno-d-addfile-menu-icon",
            scope: this,
            handler: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.Drive.Upload.Application", {
                    enableSelectDir: !0,
                    from_drive: !1,
                    from_url: !1,
                    activeItem: "from_upload",
                    onApply: this.onUploadApply.createDelegate(this)
                })
            }
        });
        var o = [{
                itemId: "create",
                cls: "syno-d-create-btn",
                tooltip: e("common", "create"),
                menu: new SYNO.ux.Menu({
                    ignoreParentClicks: !0,
                    items: n
                })
            }, {
                itemId: "members",
                cls: "syno-d-members-btn",
                tooltip: e("common", "members"),
                scope: i,
                handler: i.showMember
            }, {
                itemId: "sync_to_device",
                cls: "syno-d-sync-btn",
                tooltip: e("sync", "title"),
                scope: i,
                handler: i.showSyncDevice
            }, {
                itemId: "share",
                cls: "syno-d-share-btn",
                tooltip: e("action", "share"),
                scope: i,
                handler: i.shareNode
            }, {
                itemId: "get_link",
                cls: "syno-d-link-btn",
                tooltip: e("action", "get_file_link"),
                scope: i,
                handler: i.getLinkFromToolBar
            }, {
                itemId: "tag",
                cls: "syno-d-tag-btn",
                tooltip: e("category", "tag"),
                menu: new SYNO.SDS.Drive.SearchTagMenu({
                    GetSeletions: function() {
                        return this.findAppWindow().GetSeletions()
                    }.createDelegate(this),
                    store: this.findAppWindow().getCategoryPanel().getStore(),
                    listeners: {
                        scope: i,
                        apply: i.changeTag
                    }
                }),
                showMenu: function() {
                    return this.findAppWindow().getMenu().setType("menu_toolbar"), SYNO.ux.Button.prototype.showMenu.apply(this, arguments), this
                }
            }, {
                itemId: "restore",
                cls: "syno-d-restore-btn",
                tooltip: e("action", "restore"),
                scope: i,
                handler: i.restoreNode
            }, {
                itemId: "copy_to_new",
                cls: "syno-d-copy-to-btn",
                tooltip: e("action", "copy_to_new"),
                scope: i,
                handler: i.copyNodeToNew
            }, {
                itemId: "remove",
                cls: "syno-d-remove-btn",
                tooltip: e("action", "remove"),
                scope: i,
                handler: i.deleteNode
            }, {
                itemId: "action",
                cls: "syno-d-action-btn",
                tooltip: e("common", "action"),
                getMenuClass: function() {
                    return ""
                },
                menu: this.findAppWindow().getMenu(),
                showMenu: function() {
                    return this.menu.setType("menu_toolbar"), this.menu.setOrigin(this.el.dom), SYNO.ux.Button.prototype.showMenu.apply(this, arguments), this
                }
            }, "->", this.getInfoTooltipBtn(), this.getRecycleBtn(), this.getViewModeBtn(), this.getSortBtn()],
            r = new SYNO.ux.Toolbar({
                height: 40,
                cls: "syno-d-mgr-toolbar",
                defaults: {
                    xtype: "synodrive_round_button"
                },
                items: o
            });
        return _S("is_admin") || r.remove("recycle"), this.actiontbar = r
    },
    getInfoTooltipBtn: function() {
        if (this.infoTooltip) return this.infoTooltip;
        var e = SYNO.SDS.Drive._T,
            t = String.format("<h2>{0}</h2><p>{1}</p>", e("info_tip", "backup_category_title"), String.format(e("info_tip", "backup_category_content"), "&gt;", "<b>", "</b>", '<a target="_blank" rel="noreferrer" href="https://www.synology.com/knowledgebase/DSM/help/SynologyDriveClient/synologydriveclient#historicalversion">', "</a>"));
        return this.infoTooltip = new SYNO.SDS.Drive.WhiteQuickTip({
            style: {
                margin: "0 12px 0 0"
            },
            lightIcon: !0,
            itemId: "backup_info_tooltip",
            tipWidth: 450,
            tipItems: new Ext.BoxComponent({
                html: t
            }),
            attrs: {
                "ext:qalign": "t-b?"
            },
            listeners: {
                scope: this,
                show: function() {
                    this.findAppWindow().appInstance.getUserSettings("main_panel_backup_tooltip_shown") || (this.findAppWindow().appInstance.setUserSettings("main_panel_backup_tooltip_shown", !0), new SYNO.SDS.Drive.ArrowMenu({
                        width: 490,
                        cls: "syno-d-infotip-menu",
                        items: new Ext.BoxComponent({
                            html: t
                        }),
                        getArrowLayout: function(e) {
                            return {
                                position: "t-b",
                                offset: [-3, 0]
                            }
                        }
                    }).open(this.infoTooltip.el))
                },
                buffer: 100
            }
        }), this.infoTooltip
    },
    getSearchField: function() {
        return this.searchField || (this.searchField = new SYNO.SDS.Drive.Mgr.SearchField({
            owner: this,
            onTriggerEmpty: function() {
                var e = this.findAppWindow().getNavigation();
                "search" === e.getCategory() && e.goBack()
            }
        })), this.searchField
    },
    onBeforeCategoryChange: function(e, t) {
        var i = this.findAppWindow().getViewModeMgr().getViewMode();
        "search" === e ? "list" === i || "detail" === i ? this.viewModeBtn.setViewMode("snippet") : this.viewModeBtn.setViewMode(i) : "search" === t && ("snippet" !== i && "empty" !== i || this.viewModeBtn.setViewMode("list"))
    },
    onCheckToolbar: function() {
        SYNO.SDS.Drive.WindowHelper.isPublicShare() || this.findAppWindow().getStatusMgr().fireUpdateToolbarBtnEvent()
    },
    getTitleActionTBar: function() {
        if (this.titleActionBar) return this.titleActionBar;
        var e = SYNO.SDS.Drive._T,
            t = this.findAppWindow().getAction(),
            i = [],
            n = window.getDriveFile() || {};
        i.push({
            itemId: "public_title",
            xtype: "syno_displayfield",
            cls: "syno-d-public-title",
            value: n.name
        });
        var o = n.removed;
        return !SYNO.SDS.Drive.Utils.isAppAuthorized() || o || SYNO.SDS.Drive.WindowHelper.isAdvShare() || i.push([{
            itemId: "star",
            cls: "syno-d-shortcut-btn" + (n.starred ? " syno-d-shortcut-add" : ""),
            tooltip: SYNO.SDS.Drive._T("common", "add_shortcut"),
            handler: function(e) {
                var i = e.getEl();
                i.hasClass("syno-d-shortcut-add") ? (i.removeClass("syno-d-shortcut-add"), t.deleteShortcut({
                    file_id: [n.file_id]
                })) : (i.addClass("syno-d-shortcut-add"), t.setShortcut({
                    file_id: [n.file_id]
                }))
            },
            scope: this
        }, {
            itemId: "tag",
            cls: "syno-d-tag-btn",
            tooltip: e("category", "tag"),
            menu: new SYNO.SDS.Drive.SearchTagMenu({
                GetSeletions: function() {
                    return [{
                        labels: Ext.isEmpty(this.labels) ? SYNO.SDS.Drive.Env.labels : this.labels
                    }]
                }.createDelegate(this),
                store: this.getTagStore(),
                listeners: {
                    scope: this,
                    apply: this.onChangeTag,
                    beforeshow: function() {
                        this.reloadLabelData()
                    }
                }
            })
        }]), o || i.push({
            itemId: "download",
            cls: "syno-d-download-btn",
            tooltip: e("action", "download"),
            scope: t,
            handler: function() {
                var e = window.getDriveFile();
                this.findAppWindow().getAction().downloadAsZip(e.name, [{
                    file_id: e.file_id,
                    name: e.name
                }], {
                    file_id: [e.file_id]
                }, e.removed)
            }
        }), i.push("->", this.getViewModeBtn()), this.titleActionBar = new Ext.Toolbar({
            cls: "syno-d-title-action-tb",
            height: 43,
            defaults: {
                xtype: "synodrive_simple_button"
            },
            items: i
        })
    },
    getTagStore: function() {
        return this.tagStore ? this.tagStore : (this.tagStore = new SYNO.API.Store({
            autoLoad: SYNO.SDS.Drive.Utils.isAppAuthorized(),
            remoteSort: !1,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.SynologyDrive.Labels",
                version: 1,
                method: "list",
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                id: "label_id"
            }, [{
                name: "label_id"
            }, {
                name: "name"
            }, {
                name: "color",
                convert: function(e, t) {
                    return e.substr(1)
                }
            }, {
                name: "position"
            }, {
                name: "category",
                defaultValue: "label"
            }])
        }), this.findAppWindow().addManagedComponent(this.tagStore), this.tagStore)
    },
    onChangeTag: function(e, t, i) {
        var n = [],
            o = this.findAppWindow();
        Ext.each(e, function(e, t, i) {
            n.push({
                action: "add",
                label_id: e.label_id
            })
        }), Ext.each(t, function(e, t, i) {
            n.push({
                action: "delete",
                label_id: e.label_id
            })
        }), this.labels = i, o.getAction().setNodeTag({
            file_id: [window.getDriveFile().file_id],
            labels: n
        }, function(e, t) {
            e ? this.reloadLabelData() : (this.labels = null, this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t)))
        }, this)
    },
    reloadLabelData: function() {
        this.getTagStore().reload(), this.findAppWindow().getAction().getNode({
            file_id: window.getDriveFile().file_id
        }, function(e, t) {
            this.labels = null, e && SYNO.SDS.Drive.Env.set(t)
        }, this)
    },
    canDisplayPathMenu: function() {
        var e = this.findAppWindow(),
            t = e.getNavigation().getLastPath();
        return !SYNO.SDS.Drive.WindowHelper.isPublicShare() && !!t.display_path && !t.display_path.match(/^\/team-folders\/[^\/]+$/)
    },
    onBeforeShowArrow: function() {
        return this.canDisplayPathMenu()
    },
    onPathbarClick: function(e, t, i, n) {
        if (t > 0 && i && this.canDisplayPathMenu()) {
            var o = this.findAppWindow(),
                r = o.getMenu();
            return void SYNO.SDS.Drive.WebAPICore.sendPromise("get_file", {
                path: SYNO.SDS.Drive.Utils.getPathId(o.getNavigation().getLastPath().id),
                extra: ["sync_to_device"]
            }).then(function(e) {
                var t = o.getAction().clone();
                e.ntype = SYNO.SDS.Drive.Utils.getNtype(e.name, e.type), t.setTarget([new Ext.data.Record(e, e.file_id)]), r.setType("menu_pathbar"), r.setOrigin(n.el.dom), r.setAction(t), r.show(n.el, n.menuAlign), r.on("hide", r.resetAction, r, {
                    single: !0
                })
            }).catch(function(e) {
                SYNO.Debug.error(e, e.stack), r.resetAction(), r.hide()
            })
        }
        var a = this.findAppWindow().getNavigation(),
            s = a.getPath();
        a.setCategoryAndPath(a.getCategory(), s.slice(0, parseInt(t) + 1), void 0, void 0, void 0, !0)
    }
}, SYNO.SDS.Drive.Framework.postDefine), Ext.define("SYNO.SDS.Drive.ViewPanel.CategoryTreePanel", {
    extend: "SYNO.ux.TreePanel",
    constructor: function(e) {
        var t = {
            cls: "syno-d-viewpanel-category",
            useArrows: !0,
            animate: !0,
            border: !1,
            enableDD: !0,
            rootVisible: !1,
            autoFlexcroll: !0,
            clearOnLoad: !0,
            findNext: !1,
            updateScrollBarEventNames: ["append", "insert", "remove", "expandnode", "collapsenode", "resize"],
            root: this.getTreeRootNode(),
            bodyStyle: "",
            margins: {
                top: 0,
                right: 12,
                bottom: 0,
                left: 12
            },
            selModel: new Ext.tree.DefaultSelectionModel({
                listeners: {
                    scope: this,
                    beforeselect: this.onBeforeSelect,
                    selectionchange: this.onSelectionChange
                }
            }),
            tbar: [{
                xtype: "box",
                width: 208,
                cls: "syno-d-mgr-logo"
            }],
            listeners: {
                scope: this,
                click: this.onTreeNodeClick,
                beforeclick: this.onBeforeTreeNodeClick,
                contextmenu: this.onShowContextMenu,
                resize: {
                    buffer: 100,
                    fn: this.onTreeResize
                }
            }
        };
        Ext.apply(t, e || {}), this.appWindow = e.appWindow, this.lastClickTime = 0, this.callParent([t]), this.onRegEvent()
    },
    onUpdateScrollbar: function(e) {
        var t = this;
        if (t.isVisible()) {
            var i = t.el.dom;
            i && i.fleXcroll ? (e && i.fleXcroll.setScrollPos(0, 0), i.fleXcroll.updateScrollBars(), e || i.fleXcroll.setScrollPos(0, 0, !0)) : i && (fleXenv.fleXcrollMain(i, this.disableTextSelect), i.onfleXcroll = function() {
                t.isVisible() && t.onUpdateView && t.onUpdateView(), this.fireEvent("flexcroll", this, this.getFleXcrollInfo(t.el.dom))
            }.createDelegate(this), i.fleXcroll && this.fireEvent("flexcrollInitDone")), i = null
        }
    },
    initEvents: function() {
        this.dragZone = new SYNO.SDS.Drive.ViewPanel.TreeDragZone(this, {
            ddGroup: "DriveMgrDD",
            scroll: this.ddScroll
        }), this.dropZone = new SYNO.SDS.Drive.ViewPanel.TreeDropZone(this, {
            ddGroup: "DriveMgrDD",
            scroll: this.ddScroll
        }), this.callParent(arguments)
    },
    onRegEvent: function() {
        var e = this.findAppWindow(),
            t = e.getEventMgr();
        this.mon(t, {
            scope: this,
            envready: this.onEnvReady,
            storeloaddone: this.onReloadTreeNode,
            createnodedone: this.onCreateNodeDone,
            deletenodedone: this.onDeleteNodeDone,
            copynodedone: this.onCopyNodeDone,
            movenodedone: this.onMoveNodeDone,
            setnodetitledone: this.onSetNodeTitleDone,
            createtagdone: this.onCreateTagDone,
            settagdone: this.onSetTagDone,
            deletetagdone: this.onDeleteTagDone,
            categorychange: this.onCategoryChange,
            pathchange: this.onPathChange
        }), e.mon(e, "resize", function() {
            this.updateScroller()
        }, this, {
            buffer: 100
        })
    },
    onEnvReady: function() {
        _S("is_admin") || SYNO.SDS.Drive.Define.Info.is_home || this.categoryNode.removeChild(this.recycleNode), this.labelRootNode.expand(!1, !1)
    },
    onTreeResize: function() {
        var e = this.getWidth(),
            t = document.head || document.getElementsByTagName("head")[0],
            i = String.format(".syno-drive-theme .syno-d-viewpanel-category.syno-ux-treepanel .x-tree-node .syno-d-tree-node.syno-d-tree-tag-node .x-tree-node-anchor span { max-width: {0}px} .syno-drive-theme .syno-d-viewpanel-category.syno-ux-treepanel .x-tree-node .syno-d-tree-node.syno-d-tree-tag-node {width: {1}px !important;}", e - 80, e - 10);
        this.style && t.removeChild(this.style), this.style = document.createElement("style"), this.style.type = "text/css", this.style.styleSheet ? this.style.styleSheet.cssText = i : this.style.appendChild(document.createTextNode(i)), t.appendChild(this.style)
    },
    getTreeRootNode: function() {
        return this.treeRoot ? this.treeRoot : (this.treeRoot = new Ext.tree.TreeNode({
            id: "root",
            text: "none",
            allowDrag: !1,
            allowDrop: !1
        }), this.getCategoryRootNode().appendChild([this.getDriveNode(), this.getFolderNode(), this.getBackupNode(), this.getSharingWithMeNode(), this.getSharingToOthersNode(), this.getRecentNode(), this.getStarredNode(), this.getRecycleNode()]), this.treeRoot.appendChild(this.getCategoryRootNode()), this.treeRoot.appendChild(this.getLabelRootNode()), this.treeRoot)
    },
    getCategoryRootNode: function() {
        return this.categoryNode ? this.categoryNode : (this.categoryNode = new Ext.tree.TreeNode({
            id: "category_label",
            text: SYNO.SDS.Drive._T("category", "category_label"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            expandable: !1,
            uiProvider: SYNO.SDS.Drive.Comp.TreeRootNodeUI
        }), this.categoryNode)
    },
    getLabelRootNode: function() {
        return this.labelRootNode ? this.labelRootNode : (this.labelRootNode = new Ext.tree.AsyncTreeNode({
            id: "tag_label",
            text: SYNO.SDS.Drive._T("category", "tag_label"),
            draggable: !1,
            expanded: !1,
            allowDrop: !1,
            expandable: !1,
            loader: this.getLabelLoader(),
            uiProvider: SYNO.SDS.Drive.Comp.TreeRootNodeUI
        }), this.labelStoreAdapter = new SYNO.SDS.Drive.ViewPanel.LabelStoreAdapter({
            node: this.labelRootNode,
            owner: this
        }), this.labelRootNode)
    },
    getSharingWithMeNode: function() {
        return this.sharingWithMeNode ? this.sharingWithMeNode : (this.sharingWithMeNode = new Ext.tree.TreeNode({
            id: "shared_with_me",
            text: SYNO.SDS.Drive._T("category", "shared_with_me"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.sharingWithMeNode)
    },
    getSharingToOthersNode: function() {
        return this.sharingToOtherNode ? this.sharingToOtherNode : (this.sharingToOtherNode = new Ext.tree.TreeNode({
            id: "sharing_to_others",
            text: SYNO.SDS.Drive._T("category", "sharing_to_others"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.sharingToOtherNode)
    },
    getRecentNode: function() {
        return this.recentNode ? this.recentNode : (this.recentNode = new Ext.tree.TreeNode({
            id: "recent",
            text: SYNO.SDS.Drive._T("category", "recent"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.recentNode)
    },
    getStarredNode: function() {
        return this.starredNode ? this.starredNode : (this.starredNode = new Ext.tree.TreeNode({
            id: "starred",
            text: SYNO.SDS.Drive._T("category", "starred"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.starredNode)
    },
    getRecycleNode: function() {
        return this.recycleNode ? this.recycleNode : (this.recycleNode = new Ext.tree.TreeNode({
            id: "recycle",
            text: SYNO.SDS.Drive._T("category", "recycle"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.recycleNode)
    },
    getFolderNode: function() {
        return this.folderNode ? this.folderNode : (this.folderNode = new Ext.tree.AsyncTreeNode({
            id: "team_folder",
            text: SYNO.SDS.Drive._T("category", "team_folder"),
            draggable: !1,
            expanded: !1,
            allowDrop: !0,
            removeIndentNode: !0,
            removeEcNode: !1,
            loader: this.getFolderLoader(),
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.folderNode)
    },
    getBackupNode: function() {
        return this.backupNode || (this.backupNode = new Ext.tree.TreeNode({
            id: "backup",
            text: SYNO.SDS.Drive._T("category", "backup"),
            draggable: !1,
            expanded: !0,
            allowDrop: !1,
            leaf: !0,
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        })), this.backupNode
    },
    getDriveNode: function() {
        return this.driveNode ? this.driveNode : (this.driveNode = new Ext.tree.AsyncTreeNode({
            id: "node",
            text: SYNO.SDS.Drive._T("category", "node"),
            draggable: !1,
            expanded: !1,
            allowDrop: !0,
            removeIndentNode: !0,
            removeEcNode: !1,
            loader: this.getDriveLoader(),
            uiProvider: SYNO.SDS.Drive.Comp.TreeNodeUI
        }), this.driveNode)
    },
    getDriveLoader: function() {
        return this.driveLoader ? this.driveLoader : (this.driveLoader = new SYNO.SDS.Drive.Comp.DriveTreeLoader({
            category: "node"
        }), this.driveLoader)
    },
    getFolderLoader: function() {
        return this.folderLoader ? this.folderLoader : (this.folderLoader = new SYNO.SDS.Drive.Comp.FolderTreeLoader({
            category: "team_folder"
        }), this.folderLoader)
    },
    getLabelLoader: function() {
        return this.labelLoader ? this.labelLoader : (this.labelLoader = new SYNO.SDS.Drive.Comp.LabelTreeLoader({
            category: "label"
        }), this.labelLoader)
    },
    onTreeNodeClick: function(e, t, i) {
        switch (e.id) {
            case "tag_label":
                return this.openCreateTagDialog(t), !1;
            default:
                if (Ext.fly(t.getTarget()).is("div.syno-d-color")) return this.showColorMenu(e, t), !1
        }
        this.onSelectionChange(this, e, i, !0)
    },
    onSelectionChange: function(e, t, i, n) {
        var o = this.getNodePaths(t, []);
        if (!Ext.isEmpty(o)) {
            var r, a = this.findAppWindow().getNavigation(),
                s = a.getCategory();
            if ("node" !== s && "team_folder" !== s) {
                var l = this.getFileCategoryFromNodeId(t.id);
                "label" === l && (l = this.getLabelCategoryFromNodeId(t.id) || l), r = l === s, !n && r && (o = a.getPath())
            } else r = this.getFileIdFromNodeId(t.id) === a.getLastPath().id;
            var d = (new Date).getTime();
            d - this.lastClickTime < 300 && r || (this.lastClickTime = d, a.setCategoryAndPath(o[0].id, o, void 0, r ? a.getSelection() : void 0, void 0, !!n && r))
        }
    },
    onBeforeTreeNodeClick: function(e, t, i) {
        return "category_label" !== e.id
    },
    onBeforeSelect: function(e, t, i) {
        if (this.dragZone.dragging) return !1;
        if ("tag_label" === t.id) {
            if (window.event) {
                var n = new Ext.EventObjectImpl(window.event);
                switch (n.getKey()) {
                    case n.DOWN:
                        this.getSelectionModel().selectNext(t);
                        break;
                    case n.UP:
                        this.getSelectionModel().selectPrevious(t)
                }
            }
            return !1
        }
        return this.onBeforeTreeNodeClick(t)
    },
    onShowContextMenu: function(e, t) {
        t.preventDefault();
        var i;
        "label" === e.attributes.category && (i = this.getTagMenu(), i.setRec(this.labelStoreAdapter.getByNode(e)), i.showAt(t.getXY()))
    },
    getTagMenu: function() {
        return this.tagmenu ? this.tagmenu : (this.tagmenu = new SYNO.SDS.Drive.TagMenu({
            owner: this
        }), this.findAppWindow().addManagedComponent(this.tagmenu), this.tagmenu)
    },
    getColorMenu: function() {
        return this.colormenu ? this.colormenu : (this.colormenu = new SYNO.SDS.Drive.ColorMenu({
            owner: this,
            listeners: {
                scope: this,
                colorchange: function(e, t, i) {
                    var n = this.labelRootNode.findChild("id", e);
                    n && n.ui.setColor(i.get("color")), this.findAppWindow().getAction().setTag({
                        label_id: i.get("label_id"),
                        color: "#" + t
                    }, void 0, void 0, !1)
                }
            }
        }), this.findAppWindow().addManagedComponent(this.colormenu), this.colormenu)
    },
    onReloadTreeNode: function(e, t) {
        var i = this.findAppWindow().getNavigation(),
            n = i.getCategory();
        if ("node" === n || "team_folder" === n) {
            var o = this.getSelectionModel().getSelectedNode();
            if (o && o.isExpandable() && o.isLoaded() && !o.isLoading()) {
                var r = this.getFileIdFromNodeId(o.id),
                    a = i.getLastPathId();
                if (!("node" === o.id && a !== SYNO.SDS.Drive.Define.Info.drive_id || "node" !== o.id && r !== a)) {
                    var s = 0,
                        l = !1;
                    e.each(function(e) {
                        if ("dir" === e.data.ntype) {
                            s++;
                            var t;
                            return (t = o.findChild("id", this.getNodeIdFromFileId(n, e.data.file_id))) && Ext.util.Format.htmlDecode(t.text) === e.data.name ? void 0 : (l = !0, !1)
                        }
                    }, this), s !== o.childNodes.length && (l = !0), l && this.delayReloadTreeNode(o, 100)
                }
            }
        }
    },
    onCreateNodeDone: function(e, t, i, n) {
        e && t && "dir" === t.type && (this.saveNodeStatus(), this.refreshTreeNode("node", t.parent_id, this.resumeNodeStatus.createDelegate(this)), this.refreshTreeNode("team_folder", t.parent_id, this.resumeNodeStatus.createDelegate(this)))
    },
    onDeleteNodeDone: function(e, t, i) {
        if (e && i) {
            var n;
            Ext.each(i.files, function(e) {
                if (n = SYNO.SDS.Drive.Utils.getFileIdFromPathId(e), this.refreshParentTreeNode("node", n) || this.refreshParentTreeNode("team_folder", n)) return !1
            }, this)
        }
    },
    onCopyNodeDone: function(e, t, i, n) {
        var o = SYNO.SDS.Drive.Utils.getFileIdFromPathId(i.to_parent_folder);
        this.saveNodeStatus(), Ext.each(n, function(e) {
            if ("dir" === e.data.type) return this.refreshTreeNode("node", o, this.resumeNodeStatus.createDelegate(this)), this.refreshTreeNode("team_folder", o, this.resumeNodeStatus.createDelegate(this)), !1
        }, this)
    },
    onMoveNodeDone: function(e, t, i, n) {
        var o = this,
            r = SYNO.SDS.Drive.Utils.getFileIdFromPathId(i.to_parent_folder);
        this.saveNodeStatus(), Ext.each(n, function(e) {
            if ("dir" === e.data.type) return this.refreshParentTreeNode("node", e.data.file_id, function() {
                o.refreshTreeNode("node", r, o.resumeNodeStatus.createDelegate(o))
            }), this.refreshParentTreeNode("team_folder", e.data.file_id, function() {
                o.refreshTreeNode("team_folder", r, o.resumeNodeStatus.createDelegate(o))
            }), !1
        }, this)
    },
    saveNodeStatus: function() {
        var e = this.getSelectionModel().getSelectedNode();
        e && (this.selectedNodePath = e.getPath())
    },
    resumeNodeStatus: function() {
        this.selectedNodePath && this.selectPath(this.selectedNodePath)
    },
    onSetNodeTitleDone: function(e, t, i) {
        e && t && "dir" === t.type && (this.updateTreeNode("node", t.file_id, t.name), this.updateTreeNode("team_folder", t.file_id, t.name))
    },
    reload_nodes: [],
    delayReloadTreeNode: function(e, t, i) {
        this.reloadTask && (window.clearTimeout(this.reloadTask), this.reloadTask = null);
        var n = !1;
        Ext.each(this.reload_nodes, function(t) {
            if (t.id === e.id) return n = !0, !1
        }), !n && e.reload && this.reload_nodes.push(e), this.reloadTask = Ext.defer(function() {
            Ext.each(this.reload_nodes, function(e, t, n) {
                e.reload(n.length - 1 === t ? i : void 0)
            }), this.reload_nodes = [], this.reloadTask = null
        }, t || 100, this)
    },
    refreshParentTreeNode: function(e, t, i) {
        var n = this.getNodeByFileId(e, t);
        return n && "dir" === n.attributes.type && n.parentNode ? (this.delayReloadTreeNode(n.parentNode, 100, i), !0) : (i && i.defer(100, this), !1)
    },
    updateTreeNode: function(e, t, i, n) {
        var o = this.getNodeByFileId(e, t);
        if (!o) return !1;
        i && o.ui.setText(i), n && o.ui.setColor(n)
    },
    refreshTreeNode: function(e, t, i) {
        var n = this.getNodeByFileId(e, t);
        return n && n.isLoaded() && n.isExpanded() ? (this.delayReloadTreeNode(n, 100, i), !0) : (i && i.defer(100, this), !1)
    },
    onSetTagDone: function(e, t) {
        if (e) {
            var i = this.findAppWindow().getNavigation(),
                n = this.findAppWindow().getDrivePanel().getPathBar();
            "label" === i.getCategoryText() && n.items && n.items[0] && n.items[0].text !== t.name && i.updatePath(t.label_id, 0, t.name), this.updateTreeNode("label", t.label_id, t.name, t.color.substr(1))
        }
    },
    onCreateTagDone: function(e, t, i) {
        if (e) {
            var n = this.labelLoader.createNode(t, this.labelRootNode);
            n && this.labelRootNode.appendChild(n), this.labelRootNode.expand(!1, !1)
        }
    },
    onDeleteTagDone: function(e, t, i) {
        if (e) {
            var n = this.getNodeIdFromFileId("label", i.label_id),
                o = this.labelRootNode.findChild("id", n);
            o && this.labelRootNode.removeChild(o);
            var r = this.findAppWindow().getNavigation();
            r.getCategory() === o.attributes.label_id && r.setDefaultCategory()
        }
    },
    onReloadLabel: function() {
        this.labelRootNode.reload()
    },
    onCategoryChange: function(e, t, i) {
        if (e !== i) {
            var n, o = this.getSelectionModel().getSelectedNode();
            switch (e) {
                case "search":
                    return void this.getSelectionModel().clearSelections();
                case "node":
                case "team_folder":
                    return;
                case "backup":
                case "shared_with_me":
                case "sharing_to_others":
                case "recent":
                case "starred":
                case "recycle":
                    n = this.root.findChild("id", e, !0);
                    break;
                default:
                    n = this.getNodeByFileId("label", e)
            }
            n && n !== o && this.getSelectionModel().select(n)
        }
    },
    onPathChange: function(e, t, i, n) {
        if (0 !== t.length && n && ("node" === i || "team_folder" === i)) {
            var o = this.findAppWindow().getNavigation(),
                r = this.getNodeIdFromFileId(o.getCategory(), o.getLastPathId()),
                a = this.root.findChild("id", r, !0);
            if (a) this.getSelectionModel().select(a);
            else {
                var s = 0,
                    l = "/root/category_label/" + t[0].id;
                for (s = 1; s < t.length; ++s) l += "/" + this.getNodeIdFromFileId(i, t[s].id);
                this.selectPath(l, "id", function(e, t) {
                    if (!e) {
                        var i = this.getSelectionModel().getSelectedNode();
                        if (0 !== l.indexOf(i.getPath())) {
                            if (!(i = this.findExistParentNode(l))) return;
                            this.getSelectionModel().select(i)
                        }
                        this.delayReloadTreeNode(i, 100, function() {
                            this.selectPath(l)
                        }.bind(this))
                    }
                }.bind(this))
            }
        }
    },
    findExistParentNode: function(e) {
        for (var t, i, n = null; !Ext.isEmpty(e) && !n;) i = e.lastIndexOf("/"), t = e.substr(i + 1), n = this.root.findChild("id", t, !0), e = e.substr(0, i);
        return n
    },
    showColorMenu: function(e, t) {
        var i = this.labelStoreAdapter.getByNode(e);
        if (!i) return !1;
        this.getColorMenu().show(t.getTarget(), "tl-tr", void 0, i), t.stopEvent()
    },
    openCreateTagDialog: function(e) {
        var t = Ext.fly(e.getTarget());
        if (t && t.is("div.syno-d-add-category")) {
            new SYNO.SDS.Drive.AddTag({
                owner: this.findAppWindow()
            }).open()
        }
    },
    getNodePaths: function(e, t) {
        if (!e || "category_label" === e.id || "tag_label" === e.id) return t;
        Ext.isArray(t) || (t = []), t = this.getNodePaths(e.parentNode, t);
        var i = e.attributes;
        return t.push({
            id: this.getFileIdFromNodeId(e.id),
            text: i.name || e.text,
            perm: i.capabilities,
            display_path: i.display_path
        }), t
    },
    getFileIdFromNodeId: function(e) {
        var t = e.indexOf(":");
        return -1 === t ? e : e.substr(t + 1)
    },
    getLabelCategoryFromNodeId: function(e) {
        var t = e.split(":", 2);
        return "label" === t[0] && t.length >= 2 ? t[1] : ""
    },
    getFileCategoryFromNodeId: function(e) {
        return e.split(":", 2)[0]
    },
    getNodeIdFromFileId: function(e, t) {
        return String.format("{0}:{1}", e, t)
    },
    getNodeByFileId: function(e, t) {
        var i;
        return i = t === SYNO.SDS.Drive.Define.Info.drive_id ? "node" : this.getNodeIdFromFileId(e, t), this.root.findChild("id", i, !0)
    },
    getStore: function() {
        return this.labelStoreAdapter.getStore()
    }
}), Ext.define("SYNO.SDS.Drive.ViewPanel.LabelStoreAdapter", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.node = e.node, this.store = new Ext.data.JsonStore({
            fields: ["category", "label_id", "name", "color"],
            data: []
        }), this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        this.mon(this.node, {
            scope: this,
            load: this.onInitStore,
            append: this.onInitStore,
            insert: this.onInitStore,
            remove: this.onInitStore
        })
    },
    getStore: function() {
        return this.store
    },
    getByNode: function(e) {
        return this.getByIndex(this.node.indexOf(e))
    },
    getByIndex: function(e) {
        return this.store.getAt(e)
    },
    onInitStore: function() {
        this.store.removeAll(), Ext.each(this.node.childNodes, function(e) {
            this.mun(e, "textchange", this.onNodeTextChange, this), this.mon(e, "textchange", this.onNodeTextChange, this), this.mun(e, "colorchange", this.onNodeColorChange, this), this.mon(e, "colorchange", this.onNodeColorChange, this), this.store.loadData(e.attributes, !0)
        }, this)
    },
    onNodeTextChange: function(e, t, i, n) {
        var o = this.getByNode(e);
        o.beginEdit(), o.set("name", Ext.util.Format.htmlDecode(t)), o.commit()
    },
    onNodeColorChange: function(e, t, i, n) {
        var o = this.getByNode(e);
        o.beginEdit(), o.set("color", t), o.commit()
    }
}), Ext.define("SYNO.SDS.Drive.TagMenu", {
    extend: "SYNO.ux.Menu",
    constructor: function(e) {
        e.owner && (this.owner = e.owner, delete e.owner);
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            items: [{
                itemId: "text",
                canActivate: !1,
                style: "font-weight: bold"
            }, "-", {
                itemId: "edit",
                text: _T("common", "alt_edit"),
                scope: this,
                handler: this.onTagEdit
            }, {
                itemId: "delete",
                text: _T("common", "delete"),
                scope: this,
                handler: this.onTagDelete
            }],
            listeners: {
                scope: this,
                beforeshow: function(e) {
                    var t = this.rec;
                    e.items.get("text").setText(t.data.name)
                }
            }
        };
        return Ext.apply(t, e), t
    },
    setRec: function(e) {
        this.rec = e
    },
    getRec: function() {
        return this.rec
    },
    onTagEdit: function() {
        new SYNO.SDS.Drive.EditTag({
            targetRec: this.rec,
            owner: this.findAppWindow()
        }).open()
    },
    onTagDelete: function() {
        this.findAppWindow().getAction().deleteTag({
            label_id: this.rec.get("label_id")
        }, function(e, t) {
            e || this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
        }, this)
    }
}), Ext.define("SYNO.SDS.Drive.Sync.Panel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            padding: 0,
            layout: {
                type: "vbox",
                pack: "start",
                align: "stretch"
            },
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-d-sync-desc",
                value: SYNO.SDS.Drive._T("sync", "desc")
            }, this.getGrid()]
        };
        return Ext.apply(t, e)
    },
    getStore: function() {
        return this.store || (this.store = new SYNO.API.Store({
            pruneModifiedRecords: !0,
            autoLoad: !0,
            autoDestroy: !0,
            proxy: new SYNO.API.Proxy(SYNO.SDS.Drive.WebAPIDesc.list_shared_with_me),
            baseParams: {},
            sortInfo: {
                field: "name",
                direction: "asc"
            },
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: null,
                id: "file_id"
            }, [{
                name: "file_id"
            }, {
                name: "name"
            }, {
                name: "sync_to_device"
            }]),
            listeners: {
                scope: this,
                beforeload: this.onBeforeLoad,
                load: this.onLoadStore,
                exception: this.onExceptionStore
            }
        }))
    },
    onBeforeLoad: function(e, t) {
        if (0 === e.getTotalCount()) return this.findWindow().setStatusBusy(), !0
    },
    onLoadStore: function(e, t) {
        this.findWindow().clearStatusBusy()
    },
    onExceptionStore: function(e, t, i, n, o, r) {
        this.findWindow().clearStatusBusy(), this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(o), function() {
            this.findWindow().close()
        }, this)
    },
    getGrid: function() {
        var e = new SYNO.ux.EnableColumn({
            header: SYNO.SDS.Drive._T("chat", "binding"),
            dataIndex: "sync_to_device",
            width: 150,
            align: "center",
            menuDisabled: !0,
            enableFastSelectAll: !0,
            sortable: !1
        });
        return this.grid || (this.grid = new SYNO.ux.GridPanel({
            enableHdMenu: !1,
            flex: 1,
            margins: {
                top: 8,
                bottom: 0,
                left: 0,
                right: 0
            },
            viewConfig: {
                forceFit: !0,
                markDirty: !1,
                deferEmptyText: !1
            },
            autoExpandColumn: "name",
            sm: new Ext.grid.RowSelectionModel({
                listeners: {
                    beforerowselect: function() {
                        return !1
                    }
                }
            }),
            plugins: [e],
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0,
                    align: "left",
                    sortable: !0
                },
                columns: [{
                    id: "name",
                    header: SYNO.SDS.Drive._T("file", "title"),
                    dataIndex: "name",
                    width: 293,
                    renderer: function(e, t) {
                        var i = Ext.util.Format.htmlEncode(e);
                        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
                    }
                }, e]
            }),
            store: this.getStore(),
            listeners: {
                viewready: function(e) {
                    e.getView().updateScroller()
                }
            }
        }))
    },
    getParams: function() {
        var e = [],
            t = [],
            i = this.getStore().getModifiedRecords();
        return Ext.each(i, function(i) {
            i.data.sync_to_device ? e.push(i.id) : t.push(i.id)
        }), {
            enable: e,
            disable: t
        }
    },
    isDirty: function() {
        return this.getStore().getModifiedRecords().length > 0
    }
}), Ext.ns("SYNO.SDS.Drive.Chat"), Ext.define("SYNO.SDS.Drive.Sync.Window", {
    extend: "SYNO.SDS.Drive.AddEditWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            title: SYNO.SDS.Drive._T("sync", "title"),
            width: 500,
            height: 530,
            layout: "fit",
            items: this.getFormPanel(e)
        };
        return Ext.apply(t, e)
    },
    getFormPanel: function(e) {
        return this.formpanel || (this.formpanel = new SYNO.SDS.Drive.Sync.Panel(e))
    },
    isValid: function() {
        return !0
    },
    isDirty: function() {
        return this.getFormPanel().isDirty()
    },
    getParams: function() {
        return this.getFormPanel().getParams()
    },
    onAction: function(e) {
        this.findAppWindow().getAction().syncDevice(e, this.onApplyCb, this)
    },
    onApplyCb: function(e, t, i, n) {
        if (this.clearStatusBusy(), e && !t.has_fail) return this.onApplyDone(t, i, n), void this.close();
        this.setStatusError({
            text: SYNO.SDS.Drive.Utils.getErrorStr(t)
        }), this.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
    },
    onApplyDone: function(e, t, i) {
        this.close()
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Common", {
    singleton: !0,
    externalPriority: {
        Office: 0,
        DocumentViewer: 1,
        VideoStation: 2,
        VideoPlayer: 3,
        Others: 4
    },
    constructor: function() {},
    getConfig: function() {
        return this.config || (this.config = this.createConfig())
    },
    createConfig: function() {
        return {
            actions: this.createActionsMap(),
            config: this.createItemConfigTemplate()
        }
    },
    createActionsMap: function() {
        return {
            share: !SYNO.SDS.Drive.WindowHelper.isPublicShare() && !SYNO.SDS.Drive.Define.Info.disabled_all_sharing
        }
    },
    createItemConfigTemplate: function() {
        return {
            timeToLive: 6e5,
            requestUrl: function(e) {
                var t = this.getActiveRecord(e);
                return t ? SYNO.API.GetBaseURL(SYNO.SDS.Drive.WebAPICore.getApiConfig("download_files", {
                    files: [SYNO.SDS.Drive.Utils.getPathId(e)],
                    force_download: !0,
                    is_preview: !0
                }), !0, t.get("name")) : null
            }.bind(this),
            requestDownload: function(e) {
                var t = this.getActiveRecord(e);
                return t ? (SYNO.SDS.Drive.GetWindow().getAction().downloadNode(t), !0) : null
            }.bind(this),
            requestOpenTab: function(e) {
                var t = this.getActiveRecord(e);
                return t ? (SYNO.SDS.Drive.GetWindow().getAction().openFile(t), !0) : null
            }.bind(this),
            requestShare: function(e) {
                var t = this.getActiveRecord(e);
                return t ? new Promise(function(i) {
                    SYNO.SDS.Drive.GetWindow().getAction().shareNodeByParam({
                        owner: SYNO.SDS.Drive.GetWindow(),
                        file_id: e,
                        capabilities: t.get("capabilities"),
                        name: t.get("name"),
                        restoreWindowFocus: Ext.emptyFn,
                        listeners: {
                            close: function() {
                                i(!0)
                            }
                        }
                    })
                }) : Promise.resolve(!1)
            }.bind(this),
            requestBasicInfo: function(e) {
                var t = this.getActiveRecord(e);
                return t ? [{
                    title: "general",
                    items: [{
                        name: "file_type",
                        value: this.getFileType(t)
                    }, {
                        name: "modified_date",
                        value: this.getModifiedDate(t)
                    }, {
                        name: "size",
                        value: this.getSize(t)
                    }]
                }] : null
            }.bind(this)
        }
    },
    getActiveStore: function() {
        return SYNO.SDS.Drive.GetWindow().getStoreMgr().getActiveStore()
    },
    getActiveRecords: function() {
        return SYNO.SDS.Drive.WindowHelper.isPublicFileShare() ? [SYNO.SDS.Drive.GetWindow().getFilePanel().getRecord()] : this.getActiveStore().data.items
    },
    getActiveRecord: function(e) {
        if (SYNO.SDS.Drive.WindowHelper.isPublicFileShare()) {
            var t = SYNO.SDS.Drive.GetWindow().getFilePanel().getRecord();
            return t.get("file_id") === e ? t : null
        }
        return this.getActiveStore().getById(e)
    },
    getExternalOpener: function(e) {
        var t = [],
            i = this.externalPriority;
        return SYNO.SDS.Drive.GetWindow().getEventMgr().fireEvent("uvgetexternal", t, e), t.sort(function(e, t) {
            var n = i.Others;
            return (Object.prototype.hasOwnProperty.call(i, e) ? i[e] : n) - (Object.prototype.hasOwnProperty.call(i, t) ? i[t] : n)
        })
    },
    getFileType: function(e) {
        return SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(e.get("name")))
    },
    getModifiedDate: function(e) {
        return SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(1e3 * e.get("mtime")))
    },
    getSize: function(e) {
        return Ext.util.Format.fileSize(e.get("size"))
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Office", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Common.self",
    singleton: !0,
    createActionsMap: function() {
        return Ext.apply(this.callParent(arguments), {
            openExternal: this.hasOffice()
        })
    },
    hasOffice: function() {
        return !!SYNO.SDS.Drive.Utils.hasOffice()
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Synoffice", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Office.self",
    singleton: !0,
    createItemConfigTemplate: function() {
        return Ext.apply(this.callParent(arguments), {
            requestPreview: !!SYNO.SDS.Drive.Utils.hasOffice() && function(e) {
                var t = this.getActiveRecord(e);
                return t ? SYNO.API.GetBaseURL({
                    api: "SYNO.Office.Snapshot",
                    method: "get",
                    version: 3,
                    params: {
                        link_id: t.json.permanent_link
                    }
                }, !0) : null
            }.bind(this),
            requestDownload: !!this.hasOffice() && function(e) {
                var t = this.getActiveRecord(e);
                return !!t && (SYNO.SDS.Office.GetAction().downloadOffice(t), !0)
            }.bind(this),
            requestOpenTab: !!this.hasOffice() && function(e) {
                var t = this.getActiveRecord(e);
                return !!t && (SYNO.SDS.Drive.Utils.openOffice(t.get("permanent_link")), !0)
            }.bind(this),
            requestExternal: !!this.hasOffice() && {
                getOpener: function(e) {
                    return this.getExternalOpener(this.getActiveRecord(e))
                }.bind(this),
                requester: function(e, t) {
                    var i = this.getActiveRecord(e);
                    if (!i) return !1;
                    var n = !1;
                    switch (t) {
                        case "Office":
                            n = SYNO.SDS.Drive.Utils.openOffice(i.get("permanent_link"))
                    }
                    return n
                }.bind(this)
            },
            getImageURL: function(e, t) {
                var i = "oo/file/" + encodeURIComponent(e) + "/" + encodeURIComponent(t) + "/image",
                    n = {
                        raw: !1
                    };
                return Ext.urlAppend(i, Ext.urlEncode(n), !0)
            }
        })
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Msoffice", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Office.self",
    singleton: !0,
    createActionsMap: function() {
        return Ext.apply(this.callParent(arguments), {
            openExternal: this.hasOffice() || this.hasDocumentViewer()
        })
    },
    createItemConfigTemplate: function() {
        return Ext.apply(this.callParent(arguments), {
            requestExternal: !(!this.hasOffice() && !this.hasDocumentViewer()) && {
                getOpener: function(e) {
                    return this.getExternalOpener(this.getActiveRecord(e))
                }.bind(this),
                requester: function(e, t) {
                    var i = this.getActiveRecord(e);
                    if (!i) return !1;
                    var n = !1;
                    switch (t) {
                        case "Office":
                            n = SYNO.SDS.Office.Drive.openFile.call(this, i, SYNO.SDS.Drive.GetWindow());
                            break;
                        case "DocumentViewer":
                            n = SYNO.SDS.Drive.ThirdParty.openWithDocumentViewer(i)
                    }
                    return n
                }.bind(this)
            }
        })
    },
    hasOffice: function() {
        return this.callParent(arguments) && SYNO.SDS.Drive.Utils.isAppAuthorized() && !!SYNO.SDS.Office.Drive.openFile
    },
    hasDocumentViewer: function() {
        return SYNO.SDS.Drive.ThirdParty.hasDocumentViewer()
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Xlsx", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Msoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Oslide", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Synoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Pptx", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Msoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Docx", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Msoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Odoc", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Synoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Osheet", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Synoffice.self",
    singleton: !0
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Video", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Common.self",
    singleton: !0,
    createActionsMap: function() {
        return Ext.apply(this.callParent(arguments), {
            openExternal: this.canPlayVideo()
        })
    },
    createItemConfigTemplate: function() {
        return Ext.apply(this.callParent(arguments), {
            requestExternal: !!this.canPlayVideo() && {
                getOpener: function(e) {
                    return this.getExternalOpener(this.getActiveRecord(e))
                }.bind(this),
                requester: function(e, t) {
                    var i = this.getActiveRecord(e);
                    if (!i) return !1;
                    switch (t) {
                        case "VideoStation":
                            SYNO.SDS.Drive.ThirdParty.openWithVideoStation(i);
                            break;
                        case "VideoPlayer":
                            SYNO.SDS.Drive.ThirdParty.openWithVideoPlayer(i)
                    }
                    return !0
                }.bind(this)
            }
        })
    },
    canPlayVideo: function() {
        return this.hasVideoPlayer() || this.hasVideoStation()
    },
    hasVideoPlayer: function() {
        return SYNO.SDS.Drive.ThirdParty.hasVideoPlayer()
    },
    hasVideoStation: function() {
        return SYNO.SDS.Drive.ThirdParty.hasVideoStation()
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Type.Img", {
    extend: "SYNO.SDS.Drive.UniversalViewer.Type.Common.self",
    singleton: !0,
    constructor: function() {
        this.callParent(arguments), this.precedence = {
            exif: ["Image Description", "Manufacturer", "Model", "Exposure Time", "FNumber", "ISO Speed Ratings", "Focal Length", "Lens Model", "Flash", "GPS Longitude", "GPS Latitude", "GPS Altitude"],
            iptc: ["Object Name", "Caption", "Keywords"],
            xmp: ["Title", "Description", "Subject", "Pixel X Dimension", "Pixel Y Dimension", "X Resolution", "Y Resolution"]
        }
    },
    createItemConfigTemplate: function() {
        return Ext.apply(this.callParent(arguments), {
            requestPreview: function(e) {
                var t = this.getActiveRecord(e);
                if (!t) return null;
                var i = SYNO.SDS.Drive.Utils.getExt(t.get("name"));
                return SYNO.API.GetBaseURL(SYNO.SDS.Drive.WebAPICore.getApiConfig("get_thumbnail", {
                    path: SYNO.SDS.Drive.Utils.getPathId(e),
                    animate: !0,
                    size: "large",
                    version_id: t.get("version_id"),
                    online_convert: -1 === ["bmp", "gif", "jpeg", "jpg", "png", "ico"].indexOf(i)
                }))
            }.bind(this),
            requestDetailInfo: function(e) {
                var t = this.getActiveRecord(e);
                return t ? new Promise(function(e, i) {
                    SYNO.SDS.Drive.WebAPICore.send("get_metadata", {
                        path: String.format("id:{0}", t.get("file_id"))
                    }, function(i, n) {
                        if (!i) return e(null);
                        var o = this.generateInfoMap(n.exif),
                            r = this.generateInfoMap(n.iptc),
                            a = this.generateInfoMap(n.xmp);
                        e([{
                            title: "general",
                            items: this.parseGeneral(t, o)
                        }, {
                            title: "image_exif",
                            items: this.parseExif(t, o)
                        }, {
                            title: "image_iptc",
                            items: this.parseIptc(t, r)
                        }, {
                            title: "image_xmp",
                            items: this.parseXmp(t, a)
                        }])
                    }, this)
                }.bind(this)) : null
            }.bind(this)
        })
    },
    generateInfoMap: function(e) {
        return e.reduce(function(e, t) {
            var i = t.name,
                n = t.value;
            return e[i] ? e[i] = String.format("{0}, {1}", e[i], n) : e[i] = String(n), e
        }, Object.create(null))
    },
    getInfo: function(e, t, i) {
        return t[i] && t[i].trim()
    },
    getPhotoDate: function(e, t) {
        var i = t["Date and Time"];
        if (!i || !/^\d{4}:\d{2}:\d{2} \d{2}:\d{2}:\d{2}$/.test(i)) return null;
        var n = i.split(" "),
            o = n[0].split(":"),
            r = n[1].split(":");
        return SYNO.SDS.Drive.Utils.getFormatDateTime(new Date(parseInt(o[0], 10), parseInt(o[1], 10) - 1, parseInt(o[2], 10), parseInt(r[0], 10), parseInt(r[1], 10), parseInt(r[2], 10)))
    },
    getResolution: function(e, t) {
        var i = t["Pixel X Dimension"] || t["Image Width"],
            n = t["Pixel Y Dimension"] || t["Image Length"];
        return i && n ? String.format("{0} x {1}", i, n) : ""
    },
    parseGeneral: function(e, t) {
        return [
            ["file_type", this.getFileType(e, t)],
            ["modified_date", this.getModifiedDate(e, t)],
            ["image_date", this.getPhotoDate(e, t)],
            ["image_resolution", this.getResolution(e, t)],
            ["size", this.getSize(e, t)],
            ["image_model", this.getInfo(e, t, "Model")],
            ["image_aperture", this.getInfo(e, t, "FNumber")],
            ["image_exposure", this.getInfo(e, t, "Exposure Time")],
            ["image_iso", this.getInfo(e, t, "ISO Speed Ratings")],
            ["image_focal_length", this.getInfo(e, t, "Focal Length")]
        ].map(function(e) {
            return {
                name: e[0],
                value: e[1]
            }
        }.bind(this)).filter(function(e) {
            return e.value
        })
    },
    parseMetaData: function(e, t, i) {
        t = Ext.apply(Object.create(null), t);
        var n = i.reduce(function(i, n) {
            var o = this.getInfo(e, t, n);
            return o && (i.push({
                name: n,
                value: o,
                translated: !0
            }), t[n] = null), i
        }.bind(this), []);
        for (var o in t)
            if (Object.prototype.hasOwnProperty.call(t, o)) {
                var r = this.getInfo(e, t, o);
                r && n.push({
                    name: o,
                    value: r,
                    translated: !0
                })
            } return n
    },
    parseExif: function(e, t) {
        return this.parseMetaData(e, t, this.precedence.exif)
    },
    parseIptc: function(e, t) {
        return this.parseMetaData(e, t, this.precedence.iptc)
    },
    parseXmp: function(e, t) {
        return this.parseMetaData(e, t, this.precedence.xmp)
    }
}), Ext.define("SYNO.SDS.Drive.UniversalViewer.Window", {
    extend: "SYNO.SDS.Drive.ModalWindow",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)]), this.loaded = !1, this.universalViewerPromise = null, this.mon(this.findAppWindow().getEventMgr(), {
            scope: this,
            viewpanelload: this.onStoreReload
        })
    },
    fillConfig: function(e) {
        return Ext.apply({
            cls: "syno-d-uv-window",
            items: [this.createContainer()],
            layout: "absolute",
            padding: 0,
            maximized: !0,
            useDefualtKey: !1
        }, e)
    },
    createContainer: function() {
        return new Ext.BoxComponent({
            itemId: "container",
            cls: "syno-d-uv-container"
        })
    },
    getContainer: function() {
        return this.getComponent("container")
    },
    focus: function() {
        this.load().then(function(e) {
            e && e.focus()
        })
    },
    _exec: function(e) {
        this.universalViewerPromise && this.universalViewerPromise.then(function(t) {
            t && e(t)
        })
    },
    onStoreReload: function() {
        this._exec(function(e) {
            e.isHidden() ? e.clear() : e.once("hide", e.clear.bind(e))
        })
    },
    preload: function() {
        this.loaded || (this.loaded = !0, SYNO.SDS.Drive.WindowHelper.isPublicShare() ? this.load() : SYNO.SDS.Drive.GetWindow().getAction().waitSettingReady().then(function() {
            this.load()
        }.bind(this)))
    },
    load: function() {
        if (this.universalViewerPromise) return this.universalViewerPromise;
        this.loaded = !0;
        var e;
        try {
            e = this.findAppWindow().appInstance.jsConfig.version
        } catch (e) {}
        return this.universalViewerPromise = new Promise(function(t, i) {
            var n = document.createElement("script");
            n.onload = t, n.onerror = i, n.async = !0, n.type = "text/javascript", n.src = "webman/3rdparty/SynologyDrive-Drive/universal-viewer/dist/uv.loader.js" + (e ? "?v=" + encodeURIComponent(e) : ""), document.head.appendChild(n)
        }).then(function() {
            return window.UV.createUniversalViewer({
                cacheVersion: e,
                lang: _S("lang"),
                rootEl: this.getContainer().getEl().dom,
                defaultType: SYNO.SDS.Drive.UniversalViewer.Type.Common.getConfig(),
                types: ["img", "xlsx", "docx", "pptx", "osheet", "odoc", "oslide", "video"].reduce(function(e, t) {
                    var i = SYNO.SDS.Drive.UniversalViewer.Type[t[0].toUpperCase() + t.slice(1)];
                    return i && (e[t] = i.getConfig()), e
                }.bind(this), Object.create(null))
            })
        }.bind(this)).then(function(e) {
            return e.on("beforeshow", function() {
                this.show()
            }.bind(this)), e.on("hide", function() {
                this.hide()
            }.bind(this)), e.on("itemdownload", function(e) {
                e.archiveItem && this.findAppWindow().getWebAPI().notifyDownloadEvent({
                    params: {
                        files: ["id:" + e.id]
                    }
                })
            }.bind(this)), window.uv = e
        }.bind(this)).catch(function(e) {
            return null
        })
    },
    open: function(e) {
        this.load().then(function(t) {
            if (t) {
                var i = this.getActiveRecords().filter(function(e) {
                        return "file" === e.get("type")
                    }),
                    n = i.indexOf(e);
                n < 0 && (n = 0), t.show({
                    items: i.map(this.createItemConfig, this),
                    index: n
                })
            }
        }.bind(this))
    },
    close: function() {
        this._exec(function(e) {
            e.hide()
        })
    },
    clear: function() {
        this._exec(function(e) {
            e.clear()
        })
    },
    createItemConfig: function(e) {
        var t = e.get("file_id"),
            i = e.get("name"),
            n = e.get("size"),
            o = e.get("capabilities"),
            r = {
                id: t,
                name: i,
                size: n
            };
        return "psd" === SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(i)) && Ext.apply(r, {
            requestPreview: null,
            requestDetailInfo: null
        }), Ext.iterate({
            requestUrl: o.can_preview,
            requestPreview: o.can_preview,
            requestPrint: o.can_read,
            requestDownload: o.can_read,
            requestOpenTab: o.can_read,
            copyable: o.can_read,
            requestShare: o.can_share
        }, function(e, t) {
            t || (r[e] = !1)
        }), e.get("encrypted") && ["requestUrl", "requestPreview", "requestPrint", "requestDownload", "requestDetailInfo"].forEach(function(e) {
            r[e] = !1
        }), r
    },
    getActiveStore: function() {
        return this.findAppWindow().getStoreMgr().getActiveStore()
    },
    getActiveRecords: function() {
        return SYNO.SDS.Drive.WindowHelper.isPublicFileShare() ? [SYNO.SDS.Drive.GetWindow().getFilePanel().getRecord()] : this.getActiveStore().data.items
    },
    getActiveRecord: function(e) {
        if (SYNO.SDS.Drive.WindowHelper.isPublicFileShare()) {
            var t = SYNO.SDS.Drive.GetWindow().getFilePanel().getRecord();
            return t.get("file_id") === e ? t : null
        }
        return this.getActiveStore().getById(e)
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.History", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.appWindow = e.appWindow, this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.appWindow.getEventMgr();
        this.mon(e, {
            scope: this,
            pathchange: this.onPathChange
        })
    },
    onPathChange: function(e, t, i, n, o) {
        this.onPushHistory(i, t, o)
    },
    onPause: function() {
        this.pause = !0
    },
    onResume: function() {
        this.pause = !1
    },
    compare: function(e, t) {
        return !(!e || !e.category || e.category !== t.category) && (Ext.isDefined(e.file_ids) === Ext.isDefined(t.file_ids) && (!e.file_ids || e.file_ids.join(",") === t.file_ids.join(",")))
    },
    onPushHistory: function(e, t, i) {
        if (window.history && window.history.pushState && !this.pause) try {
            if ("search" === e && window.history.state && e === window.history.state.category) {
                if (i) {
                    var n = window.history.state;
                    n.options = Ext.apply(n.options, i), window.history.replaceState(n, document.title)
                }
                return
            }
            var o = {
                    category: e,
                    options: {}
                },
                r = {},
                a = "";
            switch (e) {
                case "recycle":
                    o.options.recycle_mode = this.appWindow.getDrivePanel().getRecycleBtn().getCheckedId()
            }
            Ext.apply(o.options, i || {}), t.length > 1 ? (Ext.apply(o, {
                paths: t,
                file_ids: t.map(function(e) {
                    return e.id
                })
            }), Ext.apply(r, {
                file_id: t[t.length - 1].id
            }), a = "#" + Ext.urlEncode(r)) : a = window.location.pathname + window.location.search;
            var s = window.history.state;
            if (this.compare(s, o)) return;
            window.history.pushState(o, document.title, a)
        } catch (e) {
            SYNO.Debug(e)
        }
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.Menu", {
    extend: "SYNO.ux.Menu",
    menuType: "menu_context",
    menuTypes: "menu_context menu_pathbar menu_toolbar".split(" "),
    constructor: function(e) {
        this.appWin = e.appWin, this.callParent([this.fillConfig(e)]), this.findAppWindow().addManagedComponent(this), this.mon(this, "beforeshow", this.onBeforeShow, this)
    },
    findAppWindow: function() {
        return this.appWin
    },
    fillConfig: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = [{
                itemId: "extern_last"
            }, {
                itemId: "preview",
                text: t("action", "preview"),
                handler: this.deletgateHandler("previewNode")
            }, {
                itemId: "open",
                text: t("action", "open"),
                handler: this.deletgateHandler("openNode")
            }, {
                itemId: "open_new_window",
                text: t("action", "open_in_new_tab"),
                hidden: !0,
                handler: this.deletgateHandler("openNewWin")
            }, {
                itemId: "gc_view",
                text: t("action", "view"),
                menuExternable: !0,
                hidden: !0,
                menu: new SYNO.ux.Menu({})
            }, {
                itemId: "goto",
                text: t("action", "goto_folder"),
                handler: this.deletgateHandler("gotoNode")
            }, "-", {
                itemId: "share",
                text: t("action", "share"),
                handler: this.deletgateHandler("shareNode")
            }, {
                itemId: "get_link",
                text: t("action", "get_file_link"),
                handler: this.deletgateHandler("getLinkFromMenu")
            }, "-", {
                itemId: "copy_to",
                text: t("action", "copy_to"),
                handler: this.deletgateHandler("copyNodeTo")
            }, {
                itemId: "move_to",
                text: t("action", "move_to"),
                handler: this.deletgateHandler("moveNodeTo")
            }, {
                itemId: "rename",
                text: t("action", "rename"),
                handler: this.deletgateHandler("renameNode")
            }, "-", {
                itemId: "add_star",
                text: t("star", "add"),
                handler: this.deletgateHandler("setShortcut")
            }, {
                itemId: "remove_star",
                text: t("star", "remove"),
                handler: this.deletgateHandler("deleteShortcut")
            }, {
                itemId: "tag",
                text: t("category", "tag"),
                menu: this.searchTagMenu = new SYNO.SDS.Drive.SearchTagMenu({
                    owner: this.appWin,
                    disableSearch: !0,
                    GetSeletions: function() {
                        return this.getAction().getTargets()
                    }.bind(this),
                    store: this.findAppWindow().getCategoryPanel() ? this.findAppWindow().getCategoryPanel().getStore() : null,
                    listeners: {
                        scope: this,
                        show: function() {
                            this.searchTagMenu.action = this.getAction()
                        },
                        apply: function() {
                            this.searchTagMenu.action.changeTag.apply(this.searchTagMenu.action, arguments)
                        }
                    }
                })
            }, "-", {
                itemId: "info",
                text: t("action", "info"),
                handler: this.deletgateHandler("infoNode")
            }, {
                itemId: "manage_versions",
                text: t("action", "manage_versions"),
                handler: this.deletgateHandler("manageVersions")
            }, {
                itemId: "leave",
                text: t("action", "share_leave"),
                handler: this.deletgateHandler("leaveNode")
            }, {
                itemId: "chat_binding",
                text: t("chat", "binding_btn"),
                handler: this.deletgateHandler("bindingChat")
            }, {
                itemId: "copy_to_new",
                text: t("action", "copy_to_new"),
                handler: this.deletgateHandler("copyNodeToNew")
            }];
        return SYNO.SDS.Drive.Utils.hasOffice() ? SYNO.SDS.Office.Drive.genActionMenu.call(this, i, this.findAppWindow()) : i.push({
            itemId: "download",
            text: t("action", "download"),
            handler: this.deletgateHandler("downloadSelectedNodes")
        }), i.push.apply(i, ["-", {
            itemId: "add_sync_device",
            text: t("sync", "add"),
            handler: this.deletgateHandler("addSyncDevice")
        }, {
            itemId: "remove_syno_device",
            text: t("sync", "remove"),
            handler: this.deletgateHandler("removeSyncDevice")
        }, "-", {
            itemId: "remove",
            text: t("action", "remove"),
            handler: this.deletgateHandler("deleteNode")
        }, {
            itemId: "restore",
            text: t("action", "restore"),
            handler: this.deletgateHandler("restoreNode")
        }, "-", {
            itemId: "clean_recycle",
            text: t("recycle", "clean_all"),
            handler: this.deletgateHandler("cleanNode")
        }]), Ext.apply({
            ignoreParentClicks: !0,
            items: i
        }, e)
    },
    deletgateHandler: function(e) {
        return function() {
            var t = this.getAction();
            t[e].apply(t, arguments)
        }.bind(this)
    },
    onBeforeShow: function() {
        return this.findAppWindow().getStatusMgr().onUpdateMenuBtn()
    },
    setType: function(e) {
        SYNO.Assert(-1 !== this.menuTypes.indexOf(e), "menu type needs to be one of " + this.menuTypes.join(",")), this.menuType = e
    },
    getType: function() {
        return this.menuType
    },
    setAction: function(e) {
        this.action = e
    },
    resetAction: function() {
        this.action = null
    },
    getAction: function() {
        return this.action || this.findAppWindow().getAction()
    },
    setOrigin: function(e) {
        this.origin = e
    },
    getOrigin: function() {
        return this.origin
    },
    constrainScroll: function(e) {
        var t, i = this.ul.setHeight("auto").getHeight(),
            n = this.el.getHeight(),
            o = n + 5,
            r = e;
        if (this.floating) {
            var a = Ext.fly(this.el.dom.parentNode),
                s = a.getViewSize().height;
            t = this.maxHeight ? this.maxHeight : s - e, o > s ? (t = s, r = 0) : t > o ? r = e : e > o ? (r = e - n, t = n) : (r = s - o, t = o)
        } else t = this.getHeight();
        return this.maxHeight && (t = Math.min(this.maxHeight, t)), n > t && t > 0 ? (this.activeMax = t - 2 * this.scrollerHeight - this.el.getFrameWidth("tb") - Ext.num(this.el.shadowOffset, 0), this.ul.setHeight(this.activeMax), this.createScrollers(), this.el.select(".x-menu-scroller").setDisplayed("")) : (this.ul.setHeight(i), this.el.select(".x-menu-scroller").setDisplayed("none")), this.ul.dom.scrollTop = 0, r
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.ActionPriv", {
    singleton: !0,
    create: {
        category_exclude: ["recent", "recycle", "search"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/starred", "/label", "/backup"],
        enable: !0,
        enable_when_empty: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkCreate"
    },
    tag: {
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        type_exclude: ["menu_toolbar"],
        allow_public_fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkPrivilegedPublic"
    },
    copy: {
        privilege: ["can_read"],
        path_exclude: ["/team_folder"],
        category_exclude: ["recycle"],
        type_exclude: ["menu_pathbar"]
    },
    copy_to: {
        privilege: ["can_read"],
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"]
    },
    copy_to_new: {
        privilege: ["can_read"],
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/starred", "/recent", "/label", "/backup"],
        type_exclude: ["menu_toolbar", "menu_pathbar"],
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkParentWrite"
    },
    move: {
        privilege: ["can_read", "can_delete"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/backup"],
        category_exclude: ["recycle"],
        type_exclude: ["menu_pathbar"]
    },
    move_to: {
        privilege: ["can_read", "can_delete"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/backup"],
        category_exclude: ["recycle"]
    },
    preview: {
        privilege: ["can_preview"],
        path_exclude: ["/team_folder"],
        type_exclude: ["menu_pathbar"],
        multiple: !1,
        allow_public_fn: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkPreview"
    },
    open: {
        privilege: ["can_preview"],
        path_exclude: ["/team_folder"],
        type_exclude: ["menu_pathbar"],
        multiple: !1,
        allow_public_fn: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkOpen"
    },
    open_new_window: {
        privilege: ["can_read"],
        path_exclude: ["/team_folder"],
        ntype: ["regular", "office"],
        multiple: !1,
        allow_public_fn: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkOpenNewWin"
    },
    goto: {
        category: ["search"],
        multiple: !1,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkGoto"
    },
    star: {
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        one_match: !0,
        allow_public_fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkPrivilegedPublic"
    },
    add_star: {
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        one_match: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkAddStar",
        allow_public_fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkPrivilegedPublic"
    },
    remove_star: {
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        one_match: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkRemoveStar"
    },
    info: {
        privilege: ["can_read"],
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        multiple: !1
    },
    download: {
        path_exclude: ["/team_folder"],
        privilege: ["can_read"],
        allow_public_fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkSelectionPublic"
    },
    share: {
        privilege: ["can_share"],
        path_exclude: ["/team_folder"],
        category_exclude: ["recycle"],
        type_exclude: ["menu_toolbar"],
        multiple: !1,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkShare"
    },
    get_link: {
        privilege: ["can_preview"],
        path_exclude: ["/team_folder"],
        category_exclude: ["recycle"],
        type_exclude: ["menu_toolbar"],
        multiple: !1
    },
    rename: {
        privilege: ["can_rename"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/backup"],
        category_exclude: ["recycle"],
        multiple: !1,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkRename"
    },
    remove: {
        privilege: ["can_delete"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others"],
        type_exclude: ["menu_toolbar"],
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkRemoved"
    },
    cut: {
        privilege: ["can_read", "can_delete"],
        path_exclude: ["/team_folder", "/shared_with_me", "/sharing_to_others", "/backup"],
        category_exclude: ["recycle"],
        type_exclude: ["menu_pathbar"]
    },
    paste: {
        privilege: ["can_write"],
        category_exclude: ["recycle", "recent"],
        path_exclude: ["/team_folder", "/starred", "/shared_with_me", "/sharing_to_others", "/backup"],
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkPaste",
        beforefn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.beforeCheckPaste",
        multiple: !1,
        enable_when_empty: !0,
        enable: !0
    },
    manage_versions: {
        privilege: ["can_write"],
        ntype_exclude: ["dir"],
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        multiple: !1
    },
    chat_binding: {
        privilege: ["can_read"],
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        ntype: ["dir"],
        multiple: !1,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkChatBinding"
    },
    leave: {
        category_exclude: ["recycle"],
        path_exclude: ["/team_folder"],
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkLeave"
    },
    view_mode: {
        enable: !0,
        allow_public_fn: !0
    },
    sort: {
        category_exclude: ["recent"],
        path_exclude: ["/team_folder", "/backup"],
        enable: !0
    },
    recycle: {
        category: ["recycle"],
        enable_when_empty: !0,
        enable: !0
    },
    restore: {
        privilege: ["can_read"],
        category: ["recycle"],
        type_exclude: ["menu_toolbar"],
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkRemoved"
    },
    clean_recycle: {
        category: ["recycle"],
        enable: !0,
        enable_when_empty: !1,
        type_exclude: ["menu_pathbar"]
    },
    members: {
        path: ["/team_folder"]
    },
    sync_to_device: {
        privilege: ["can_read"],
        path: ["/shared_with_me"],
        enable: !0
    },
    add_sync_device: {
        privilege: ["can_read"],
        category: ["shared_with_me"],
        type_exclude: ["menu_toolbar"],
        path: ["/shared_with_me"],
        one_match: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkAddSync"
    },
    remove_syno_device: {
        privilege: ["can_read"],
        category: ["shared_with_me"],
        path: ["/shared_with_me"],
        one_match: !0,
        fn: "SYNO.SDS.Drive.Mgr.ActionPrivUtils.checkRemoveSync"
    },
    action: {
        enable: !0,
        path_exclude: ["/team_folder"]
    },
    backup_info_tooltip: {
        path: ["/backup"]
    },
    public_title: {
        enable: !0,
        allow_public_fn: !0
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.ActionPrivUtils", {
    singleton: !0,
    checkPrivilegedPublic: function(e, t, i) {
        return "toolbar" === t && SYNO.SDS.Drive.Utils.isAppAuthorized()
    },
    checkSelectionPublic: function(e, t, i) {
        return "toolbar" === t || e.length > 0
    },
    checkAddStar: function(e, t) {
        return !e.get("starred")
    },
    checkRemoveStar: function(e, t) {
        return e.get("starred")
    },
    checkAddSync: function(e, t) {
        return !e.get("sync_to_device")
    },
    checkRemoveSync: function(e, t) {
        return e.get("sync_to_device")
    },
    checkChatBinding: function(e, t) {
        return !SYNO.SDS.Drive.Define.Info.disabled_all_sharing && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Chat.Application")
    },
    checkLeave: function(e, t) {
        return SYNO.SDS.Drive.Utils.hasUserShared(e.get("shared_with"), _S("user"))
    },
    beforeCheckPaste: function() {
        return !SYNO.SDS.Drive.Mgr.FileClipboard.isEmpty()
    },
    checkPaste: function(e, t) {
        var i, n = SYNO.SDS.Drive.Mgr.FileClipboard,
            o = t.getNavigation();
        if (!e || "dir" !== e.get("type")) {
            if ("node" === o.getCategory() && o.isRootPath()) return !0;
            i = o.getLastPath().perm, o.getLastPathId()
        } else i = e.get("capabilities"), e.get("file_id");
        if (!i || !i.can_read || !i.can_write) return !1;
        var r = n.get();
        return "cut" === r.action && r.recs, !0
    },
    checkPreview: function(e, t) {
        return SYNO.SDS.Drive.GetWindow().getAction().checkPreview(e)
    },
    checkOpen: function(e, t) {
        return SYNO.SDS.Drive.GetWindow().getAction().checkOpen(e)
    },
    checkOpenNewWin: function(e, t) {
        return SYNO.SDS.Drive.GetWindow().getAction().checkOpenNewWin(e)
    },
    checkCreate: function(e, t) {
        var i = t.getNavigation();
        if (i.isRootPath()) return !0;
        var n = i.getLastPath().perm;
        return !Ext.isDefined(n) || n.can_write
    },
    checkParentWrite: function(e, t) {
        var i = t.getNavigation(),
            n = i.getLastPath().perm;
        return !Ext.isDefined(n) || n.can_write
    },
    checkRemoved: function(e, t) {
        return "recycle" === t.getNavigation().getCategory() ? e.get("removed") : !SYNO.SDS.Drive.Utils.is1stSharedWithMe(e.get("display_path"))
    },
    checkRename: function(e, t) {
        return !SYNO.SDS.Drive.Utils.is1stSharedWithMe(e.get("display_path"))
    },
    checkGoto: function(e, t) {
        return SYNO.SDS.Drive.Utils.isVisibleInDrive(e.get("display_path"))
    },
    checkShare: function(e, t) {
        var i = {
            shared_with: e.data.shared_with,
            adv_shared: e.data.adv_shared,
            display_path: e.data.display_path
        };
        return SYNO.SDS.Drive.Utils.checkSharePrivilge(i, !0)
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.Plugin", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.appWindow = e.appWindow, this.scanExternMenu(), this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        var e = this.appWindow.getEventMgr();
        this.mon(e, {
            scope: this,
            countdrivemenu: this.onCountDriveMenu,
            beforeshowdrivemenu: this.onUpdateMenu,
            beforeopennode: this.onBeforeOpenNode,
            uvgetexternal: this.onUVGetExternal
        })
    },
    getMenu: function() {
        return SYNO.SDS.Drive.GetWindow().getMenu()
    },
    scanExternMenu: function() {
        var e, t, i, n = [];
        this.externPlugins = [];
        var o = [];
        for (e in SYNO.SDS.Config.FnMap)
            if (SYNO.SDS.Config.FnMap.hasOwnProperty(e) && SYNO.SDS.StatusNotifier.isAppEnabled(e)) {
                t = SYNO.SDS.Config.FnMap[e];
                var r = function(r, a, s, l) {
                    Ext.isEmpty(r) || (r.inherit && (r = Ext.applyIf(r, t.config[r.inherit][a])), i = {
                        is_drive: !!l,
                        baseURL: t.config.jsBaseURL,
                        className: e,
                        data: r
                    }, ("app" === t.config.type || Ext.isString(r.launchFn)) && (l || this.isAllowAppNameByFB(e, r)) && (this.externPlugins.push(i), n.push(e), Ext.isString(r.checkFn) && o.push(new Promise(function(e) {
                        SYNO.SDS.JSLoad(r.checkFn, e)
                    })), Ext.isArray(r.items) && Ext.each(r.items, function(e) {
                        Ext.isString(e.checkFn) && o.push(new Promise(function(t) {
                            SYNO.SDS.JSLoad(e.checkFn, t)
                        }))
                    }), Ext.isString(r.launchFn) && o.push(new Promise(function(e) {
                        SYNO.SDS.JSLoad(r.launchFn, e)
                    }))))
                };
                Ext.isArray(t.config.drive_extern) ? Ext.each(t.config.drive_extern, function(e, t, i) {
                    r.call(this, e, t, i, !0)
                }, this) : (Ext.isArray(t.config.fb_extern) && Ext.each(t.config.fb_extern, r, this), Ext.isArray(t.config.fb_extern_v2) && Ext.each(t.config.fb_extern_v2, r, this)), t.config.url && (t.config.url = this.updateAppUrl(t.config.url))
            } if (Ext.isEmpty(o) || Promise.all(o).then(function() {
                this.ready = !0, SYNO.SDS.Drive.GetWindow().getEventMgr().fireEvent("openpluginready")
            }.bind(this)), !Ext.isEmpty(n)) {
            var a = [];
            Ext.each(n, function(e) {
                var t = SYNO.SDS.Config.FnMap[e] || {},
                    i = t.config;
                a.push({
                    app: e,
                    path: i.jsBaseURL + "/" + i.texts
                })
            }), SYNO.SDS.Drive.GetWindow().getAction().syncPluginString(a)
        }
    },
    updateAppUrl: function(e) {
        var t;
        return SYNO.SDS.Drive.WindowHelper.isAdvShare() ? (t = "/d/s/" + window.getDriveLink() + "/" + window.getDriveSharingLink(), e.replace(t, "/")) : window.getDriveLink && !Ext.isEmpty(window.getDriveLink()) ? (t = "/d/f/" + window.getDriveLink(), e.replace(t, "/")) : e
    },
    parseToFileRec: function(e) {
        e = Ext.isArray(e) ? e : [e];
        var t = [],
            i = Ext.data.Record.create([{
                name: "file_id",
                mapping: "path"
            }, {
                name: "path"
            }, {
                name: "filename",
                convert: function(e, t) {}
            }, {
                name: "filesize"
            }, {
                name: "type",
                convert: function(e, t) {}
            }, {
                name: "isdir"
            }]);
        return Ext.each(e, function(e) {
            t.push(new i({
                path: e.get("display_path"),
                filename: e.get("name"),
                filesize: e.get("size"),
                type: "dir" === e.get("ntype") ? "" : e.get("ntype").toUpperCase(),
                isdir: "dir" === e.get("ntype")
            }))
        }, this), t
    },
    onCountDriveMenu: function(e, t, i, n) {
        SYNO.SDS.Drive.Utils.isLogined() && i && 0 !== i.length && (n.count += this.onInsertExternMenu(i, this.parseToFileRec(i), !0))
    },
    onUpdateMenu: function(e, t, i) {
        this.onUpdateExternMenu(i)
    },
    onUpdateExternMenu: function(e) {
        this.onRemoveExternMenu(this.getMenu()), SYNO.SDS.Drive.Utils.isLogined() && e && 0 !== e.length && this.onInsertExternMenu(e, this.parseToFileRec(e))
    },
    onRemoveExternMenu: function(e) {
        for (var t;
            "extern_last" !== (t = e.get(0)).getItemId();) e.remove(t, !0);
        e.items.each(function(e) {
            if (e.menuExternable) {
                if (!e.menu.items) return void e.hide();
                e.menu.items.each(function(t) {
                    t.isExtern && e.menu.remove(t, !0)
                }), 0 === e.menu.items.length && e.hide()
            }
        })
    },
    onInsertExternMenu: function(e, t, i) {
        var n = 0;
        return Ext.each(this.externPlugins, function(o) {
            this.onCheckPlugin(o, e, t, !1) && (i || this.onInsertExternMenuItem(o, e, t), ++n)
        }, this), n
    },
    onInsertExternMenuItem: function(e, t, i) {
        var n, o = e.data.inMenu,
            r = e.data.menuPriority || 0;
        if (o) {
            n = this.onClickExternMenu.createDelegate(this, [e, t, i]);
            var a = {
                ignoreParentClicks: !0,
                text: this.localizeMsg(e.data.text, e.className),
                isExtern: !0,
                menuPriority: r,
                result: {
                    display: !0,
                    enable: !0
                }
            };
            if (Ext.isArray(e.data.items)) {
                var s, l = !1,
                    d = [];
                if (Ext.each(e.data.items, function(o) {
                        if (s = void 0, Ext.isString(o.checkFn)) {
                            if (!this.onCheckFiles(o.checkFn, e, t, i, o.data)) return;
                            l = !0
                        }
                        d.push({
                            text: this.localizeMsg(o.text, e.className),
                            handler: s || n
                        })
                    }, this), !l) return !1;
                Ext.apply(a, {
                    menu: new SYNO.ux.Menu({
                        items: d
                    })
                })
            } else Ext.apply(a, {
                handler: n
            });
            var c = this.getMenu(),
                h = c.getComponent(o);
            return this.onInsertExternMenuConfig(h.menu, a), h.show(), !0
        }
    },
    onInsertExternMenuConfig: function(e, t) {
        var i = 0,
            n = t.menuPriority;
        e.items && e.items.each(function(e, t) {
            var o = e.menuPriority || 0;
            if (n <= o) return !1;
            i = t + 1
        }), e.insert(i, t)
    },
    onCheckPlugin: function(e, t, i, n) {
        var o = !0;
        if (1 < t.length && !0 !== e.data.multiple) return !1;
        if (Ext.each(t, function(t) {
                if (!0 !== e.data.removed && t.get("removed")) return o = !1;
                var i = t.get("ntype").toLowerCase(),
                    n = "dir" === t.get("ntype") ? e.data.dir : e.data.file;
                return !1 === n || Ext.isArray(n) && 0 > n.indexOf(i) ? o = !1 : void 0
            }, this), !o) return o;
        try {
            if (Ext.isString(e.data.checkFn)) o = this.onCheckFiles(e.data.checkFn, e, t, i, n);
            else if (!e.data.text) return !1
        } catch (e) {
            return SYNO.Debug(e), !1
        }
        return o
    },
    onBeforeOpenNode: function(e, t) {
        return !this.onExternDbClick(e, t)
    },
    onExternDbClick: function(e, t) {
        var i = !1,
            n = [e],
            o = this.parseToFileRec(n);
        return Ext.each(this.externPlugins, function(r) {
            try {
                if ("dir" !== e.get("ntype") && !0 !== r.data.dbclick || "dir" === e.get("ntype") && !0 !== r.data.dirdbclick) return;
                if (!this.onCheckPlugin(r, n, o, !0)) return;
                return t || this.onClickExternMenu.createDelegate(this, [r, [e], this.parseToFileRec([e])])(), i = !0, !1
            } catch (e) {
                SYNO.Debug("Fail to click " + e)
            }
        }, this), i
    },
    onUVGetExternal: function(e, t) {
        Ext.each(this.externPlugins, function(i) {
            if (this.onCheckPlugin(i, [t], this.parseToFileRec([t]), !1)) switch (i.className) {
                case "SYNO.SDS.Office.AppInstance":
                    e.push("Office");
                    break;
                case "SYNO.SDS.DocumentViewer.Application":
                    e.push("DocumentViewer");
                    break;
                case "SYNO.SDS.VideoPlayer2.Application":
                    SYNO.SDS.Drive.ThirdParty.hasVideoStation() ? e.push("VideoStation") : e.push("VideoPlayer")
            }
        }, this)
    },
    localizeMsg: function(e, t) {
        var i;
        return e ? (i = e.split(":"), Ext.isArray(t) || (t = [t]), i.length < 2 ? e : (3 === i.length && t.push(i.shift()), t.push("SYNO.SDS.Drive.Application"), i[1] = SYNO.SDS.Utils.GetLocalizedString(i[0] + ":" + i[1], t), i.shift(), String.format.apply(String, i))) : ""
    },
    onCheckFiles: function(e, t, i, n, o) {
        return !(!(e = Ext.getClassByName(e)) || !e.call(this, t, n, o))
    },
    isAllowAppNameByFB: function(e, t) {
        switch (e) {
            case "SYNO.SDS.VideoPlayer2.Application":
            case "SYNO.SDS.DocumentViewer.Application":
                return t.dbclick = !0, !0;
            case "SYNO.SDS.Office.AppInstance":
                return "SYNO.SDS.Office.FBExt.checkImport" === t.checkFn && (t.dbclick = !0, !0);
            default:
                return !1
        }
    },
    onClickExternMenu: function(e, t, i) {
        var n = e.className,
            o = SYNO.SDS.Drive.ThirdParty;
        if (e.is_drive)
            if (Ext.isString(e.data.launchFn)) {
                if ("SYNO.SDS.VideoPlayer2.Application" === n && o.hasVideoStation() && !SYNO.SDS.Config.FnMap["SYNO.VideoController2.SupportDrive"]) return void o.openWithVideoStation(t[0]);
                var r = Ext.getClassByName(e.data.launchFn);
                r && r.call(this, {
                    recs: t,
                    param: e.data.param || {},
                    urlFn: "SYNO.SDS.Drive.ThirdParty._getFileUrl"
                })
            } else SYNO.SDS.AppLaunch(e.className, {
                recs: t,
                param: e.data.param || {}
            });
        else switch (n) {
            case "SYNO.SDS.VideoPlayer2.Application":
                o.hasVideoStation() ? o.openWithVideoStation(t[0]) : o.openWithVideoPlayer(t[0]);
                break;
            case "SYNO.SDS.DocumentViewer.Application":
                o.openWithDocumentViewer(t[0]);
                break;
            case "SYNO.SDS.Office.AppInstance":
                SYNO.SDS.Office.Drive.openFile(t[0]);
                break;
            default:
                return
        }
        this.appWindow.getAction().updateRecently(t[0].get("file_id"))
    }
}), Ext.ns("SYNO.webfm.SmartDDMVCPMgr"), SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath = Ext.emptyFn, Ext.define("SYNO.SDS.Drive.Mgr.FileClipboard", {
    singleton: !0,
    extend: "Ext.util.Observable",
    constructor: function() {
        this.callParent(arguments), this.data = null, this.addEvents("set", "get", "beforeclean", "clean")
    },
    set: function(e, t) {
        return this.fireEvent("beforeset", this, this.data), this.data = {
            action: e,
            recs: t,
            parent_id: t[0].get("parent_id")
        }, this.fireEvent("set", this, this.data), this.data
    },
    get: function() {
        return this.fireEvent("get", this, this.data), this.data || {}
    },
    clean: function() {
        this.fireEvent("beforeclean", this), this.data = null, this.fireEvent("clean", this)
    },
    isEmpty: function() {
        return !(this.data && this.data.recs)
    }
}), Ext.define("SYNO.SDS.Drive.ThirdParty", {
    singleton: !0,
    hasVideoStation: function() {
        return Ext.isDefined(SYNO.SDS.Config.FnMap["SYNO.VideoController2.SupportFileVideo"]) && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.VideoStation.AppInstance")
    },
    hasVideoPlayer: function() {
        return SYNO.SDS.Drive.Utils.isLogined() && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.VideoPlayer2.Application")
    },
    openWithVideoStation: function(e) {
        if (SYNO.SDS.Config.FnMap["SYNO.VideoController2.SupportDrive"]) return void SYNO.SDS.WindowLaunch("SYNO.VideoController2.Application", {
            player_id: "streaming",
            browse_type: "filevideo",
            video_type: "filevideo",
            is_drive: !0,
            drive_path: "id:" + e.get("file_id")
        }, !0);
        var t = window.open("about:blank");
        SYNO.SDS.Drive.WebAPICore.sendPromise("create_vs_link", {
            path: this._getPathParam(e)
        }).then(function(e) {
            SYNO.SDS.WindowLaunchToWindow("SYNO.VideoController2.Application", {
                ieMode: 9,
                player_id: "streaming",
                path: e.path,
                symlink: e.filename,
                browse_type: "filevideo",
                video_type: "filevideo"
            }, t)
        }).catch(function(e) {
            t.close(), SYNO.SDS.Drive.Utils.showErrorMsg(SYNO.SDS.Drive.GetWindow(), e)
        })
    },
    openWithVideoPlayer: function(e) {
        SYNO.SDS.WindowLaunch("SYNO.SDS.VideoPlayer2.Application", {
            url: this._getFileUrl(e),
            filename: e.get("name")
        }, !0)
    },
    hasDocumentViewer: function() {
        return SYNO.SDS.Drive.Utils.isLogined() && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.DocumentViewer.Application")
    },
    openWithDocumentViewer: function(e) {
        var t = window.open("about:blank");
        SYNO.SDS.Drive.WebAPICore.sendPromise("doc_convert", {
            path: this._getPathParam(e)
        }).then(function(i) {
            SYNO.SDS.JSLoad("SYNO.SDS.DocumentViewer.LaunchHelper", function() {
                SYNO.SDS.DocumentViewer.LaunchHelper.windowLaunchToWindow({
                    name: e.get("name"),
                    task_id: i.task_id
                }, t)
            })
        }).catch(function(e) {
            t.close(), SYNO.SDS.Drive.Utils.showErrorMsg(SYNO.SDS.Drive.GetWindow(), e)
        })
    },
    _getPathParam: function(e) {
        return SYNO.SDS.Drive.Utils.getPathId(e.id)
    },
    _getFileUrl: function(e) {
        return SYNO.API.GetBaseURL(Ext.apply({
            params: {
                files: [SYNO.SDS.Drive.ThirdParty._getPathParam(e)],
                force_download: !0,
                is_preview: !0
            }
        }, SYNO.SDS.Drive.WebAPIDesc.download_files))
    }
}), Ext.define("SYNO.SDS.Drive.VersionMgr.Menu", {
    extend: "SYNO.ux.Menu",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)]), this.owner = e.owner, this.win = e.win, this.appWin = e.appWin
    },
    fillConfig: function(e) {
        var t = SYNO.SDS.Drive._T;
        return {
            items: [{
                itemId: "preview",
                text: t("action", "preview"),
                scope: this,
                handler: this.actionPreview
            }, {
                itemId: "download_regular",
                text: t("action", "download"),
                scope: this,
                handler: this.actionDownloadRegular
            }, {
                itemId: "restore",
                text: t("action", "restore"),
                scope: this,
                handler: this.actionRestore
            }, {
                itemId: "copy_to_new",
                text: t("action", "copy_to_new"),
                scope: this,
                handler: this.actionCopyToNew
            }, {
                itemId: "download_office",
                text: t("action", "download"),
                scope: this,
                handler: this.actionDownloadOffice
            }],
            listeners: {
                scope: this,
                beforeshow: this.onBeforeShow
            }
        }
    },
    getSelectedValue: function(e) {
        switch (e) {
            case "version_id":
                return this.owner.getSelectionModel().getSelections()[0].get(e);
            default:
                return this.owner.data[e]
        }
    },
    findWindow: function() {
        return this.win
    },
    findAppWindow: function() {
        return this.appWin
    },
    onBeforeShow: function() {
        this.items.each(function(e) {
            e.show()
        }), this.owner.isOfficeFile() ? this.items.get("download_regular").hide() : (this.items.get("preview").hide(), this.items.get("download_office").hide())
    },
    actionPreview: function() {
        var e = this.getSelectedValue("permanent_link"),
            t = String.format("ver={0}", this.getSelectedValue("version_id"));
        SYNO.SDS.Drive.Utils.openOfficeLink(e, t)
    },
    actionDownloadRegular: function() {
        var e = {
                files: [{
                    path: SYNO.SDS.Drive.Utils.getPathIdByLink(this.getSelectedValue("permanent_link")),
                    version_id: this.getSelectedValue("version_id")
                }]
            },
            t = this.getSelectedValue("name");
        "dir" === this.getSelectedValue("type") && (e.archive_name = t, t += ".zip"), SYNO.SDS.Drive.Utils.showToastMsg(this.findAppWindow(), SYNO.SDS.Drive._T("common", "preparing_download"), 3e3), this.findAppWindow().getAction().downloadFileVersion(e, t, function(e) {
            this.findWindow().setStatusError({
                text: SYNO.SDS.Drive.Utils.getErrorStr(e),
                clear: !0
            })
        }, this)
    },
    actionDownloadOffice: function() {
        SYNO.SDS.Office.GetAction().downloadOffice(this.owner.data, this.getSelectedValue("version_id"), this.findWindow())
    },
    actionRestore: function() {
        var e = this.getSelectedValue("parent_id");
        this.restoreToFolder(SYNO.SDS.Drive.Utils.getPathId(e), "version")
    },
    actionCopyToNew: function() {
        var e = new SYNO.SDS.Drive.TreeWindow({
            action: "copy",
            owner: this.findWindow(),
            title: SYNO.SDS.Drive._T("action", "copy_to_new"),
            hideForm: !0,
            hideCreate: !1,
            listeners: {
                scope: this,
                choose: function(t, i) {
                    e.close();
                    var n = SYNO.SDS.Drive.Utils.getPathId(i.attributes.file_id);
                    this.restoreToFolder(n, "autorename")
                },
                show: function(e) {
                    this.findAppWindow().getAction().onTreeDlgGotoPath(e, {
                        file_id: this.getSelectedValue("parent_id")
                    })
                }
            }
        });
        e.show()
    },
    restoreToFolder: function(e, t) {
        var i = {
            to_parent_folder: e
        };
        this.owner.isOfficeFile() ? ("version" === t && delete i.to_parent_folder, Ext.apply(i, {
            path: SYNO.SDS.Drive.Utils.getPathIdByLink(this.getSelectedValue("permanent_link")),
            ver: this.getSelectedValue("version_id"),
            encrypted: this.getSelectedValue("encrypted")
        }), this.findWindow().setStatusBusy(), SYNO.SDS.Office.GetAction().restoreVersion(i, this.findWindow(), function(e, t, i) {
            this.findWindow().clearStatusBusy(), e ? this.findWindow().close() : this.findWindow().getMsgBox().alert("", t ? SYNO.SDS.Office.Utils.getErrorStr(t) : SYNO.SDS.Office._T("error", "restore_version_op_fail"))
        }, this)) : (Ext.apply(i, {
            conflict_action: t,
            files: [{
                path: SYNO.SDS.Drive.Utils.getPathIdByLink(this.getSelectedValue("permanent_link")),
                version_id: this.getSelectedValue("version_id")
            }]
        }), this.findAppWindow().getAction().doRestoreFileVersion(i, this.getSelectedValue("name")), this.findWindow().close())
    }
}), Ext.define("SYNO.SDS.Drive.VersionMgr.Grid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.data = e.data, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this.isOfficeFile(),
            i = t ? SYNO.SDS.Drive.WebAPIDesc.list_office_revisions : SYNO.SDS.Drive.WebAPIDesc.list_revisions;
        return {
            cls: "syno-d-versionmgr-grid",
            hideHeaders: !0,
            columns: [{
                id: "type",
                width: 34,
                renderer: {
                    scope: this,
                    fn: this.renderType
                }
            }, {
                id: "version",
                width: 449,
                renderer: {
                    scope: this,
                    fn: this.renderVersion
                }
            }, {
                id: "action-btn",
                width: 47,
                renderer: {
                    scope: this,
                    fn: this.renderActionBtn
                },
                listeners: {
                    scope: this,
                    click: this.onActionBtnClick
                }
            }],
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                rowHeight: 59,
                borderHeight: 1,
                cacheSize: 30,
                scrollDelay: !1,
                forceFit: !0,
                disableTextSelect: !0
            }),
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            store: new SYNO.API.JsonStore({
                autoDestroy: !0,
                root: t ? "versions" : "items",
                idProperty: t ? "version" : "version_id",
                fields: [{
                    name: "version_name",
                    convert: function(e, t) {
                        return t.ver_name
                    }
                }, {
                    name: "version_id",
                    convert: function(e, t) {
                        return t.version_id ? e : t.version
                    }
                }, {
                    name: "modified_time",
                    convert: function(e, t) {
                        return t.created_time ? t.created_time : t.mtime
                    }
                }, {
                    name: "editors",
                    convert: function(e, t) {
                        return t.editors ? e : []
                    }
                }, {
                    name: "editor_display_name"
                }],
                proxy: new SYNO.API.Proxy(i),
                listeners: {
                    scope: this,
                    beforeload: this.onStoreBeforeLoad,
                    load: this.onStoreLoad,
                    exception: this.onStoreException
                }
            })
        }
    },
    isOfficeFile: function() {
        return this.is_office || (this.is_office = SYNO.SDS.Drive.Utils.isOfficeFile(this.data.name))
    },
    onStoreBeforeLoad: function() {
        this.findWindow().setStatusBusy()
    },
    onStoreLoad: function() {
        this.findWindow().clearStatusBusy()
    },
    onStoreException: function(e, t, i, n, o, r) {
        this.findWindow().clearStatusBusy(), this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(o), function() {
            this.findWindow().close()
        }, this)
    },
    loadOfficeData: function(e) {
        var t = {
            path: e,
            additional: {
                uid: !0,
                name: !0,
                nickname: SYNO.SDS.Drive.Define.Info.use_nickname
            }
        };
        this.store.load({
            params: t
        })
    },
    loadData: function() {
        var e;
        e = this.data.permanent_link ? SYNO.SDS.Drive.Utils.getPathIdByLink(this.data.permanent_link) : SYNO.SDS.Drive.Utils.getPathId(this.data.file_id), this.isOfficeFile() ? this.loadOfficeData(e) : this.store.load({
            params: {
                path: e
            }
        })
    },
    renderType: function() {
        return String.format('<span class="{0}"></span>', SYNO.SDS.Drive.FileType.getMappingTypeCss(SYNO.SDS.Drive.Utils.getExt(this.data.name), 24))
    },
    renderVersion: function(e, t, i) {
        var n, o = SYNO.SDS.Drive.Utils.convertEpochTime(1e3 * i.get("modified_time")),
            r = i.data.version_name,
            a = this.isOfficeFile() ? i.data.editors : i.data.editor_display_name || i.data.editors,
            s = function(e) {
                return "#" === e.charAt(0) ? SYNO.SDS.Drive._T("common", "deleted_user") : e
            };
        if (this.isOfficeFile()) {
            var l = "";
            n = "", a.forEach(function(e) {
                l && (l += ", "), n && (n += ", "), n += e.name, 0 === e.uid ? l += SYNO.SDS.Drive._T("common", "system") : e.name ? SYNO.SDS.Drive.Define.Info.use_nickname && e.nickname ? (l += e.nickname, n += " (" + e.nickname + ")") : l += e.name : l += SYNO.SDS.Drive._T("common", "deleted_user")
            }), a = l
        } else a = Array.isArray(a) ? a.filter(function(e) {
            return Ext.isString(e) && "" !== e.trim().length
        }).map(s).join(", ") : s(a);
        a = Ext.util.Format.htmlEncode(a || " ");
        var d;
        d = r ? Ext.util.Format.htmlEncode(r + " (" + o + ")") : Ext.util.Format.htmlEncode(o || " ");
        var c;
        return SYNO.SDS.Drive.Define.Info.use_nickname ? (this.isOfficeFile() || (n = i.data.editors) !== i.data.editor_display_name && (n += " (" + i.data.editor_display_name + ")"), c = '<div class="syno-d-versionmgr-title"><span class="syno-d-versionmgr-mtime">{0}</span></div><div class="syno-d-versionmgr-editors" ext:qtip="{1}">{2}</div>', String.format(c, d, Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(n)), Ext.util.Format.htmlEncode(a || " "))) : (c = '<div class="syno-d-versionmgr-title"><span class="syno-d-versionmgr-mtime">{0}</span></div><div class="syno-d-versionmgr-editors">{1}</div>', String.format(c, d, Ext.util.Format.htmlEncode(a || " ")))
    },
    renderActionBtn: function() {
        return '<span class="syno-d-versionmgr-action-btn"></span>'
    },
    setActiveBtn: function(e) {
        this.activeBtn = e
    },
    getActiveBtn: function() {
        return Ext.fly(this.activeBtn)
    },
    getMenu: function() {
        return this.menu || (this.menu = new SYNO.SDS.Drive.VersionMgr.Menu({
            owner: this,
            win: this.findWindow(),
            appWin: this.findAppWindow()
        }), this.mon(this.menu, {
            scope: this,
            show: this.onMenuShow,
            hide: this.onMenuHide
        }), this.addManagedComponent(this.menu)), this.menu
    },
    onMenuShow: function() {
        this.getActiveBtn().addClass("syno-d-versionmgr-btn-menu-active")
    },
    onMenuHide: function() {
        this.getActiveBtn().removeClass("syno-d-versionmgr-btn-menu-active")
    },
    onActionBtnClick: function(e, t, i, n) {
        if (n.target && Ext.fly(n.target).hasClass("syno-d-versionmgr-action-btn")) {
            this.setActiveBtn(n.target);
            var o = this.getMenu(),
                r = Ext.fly(n.target).getAnchorXY("br");
            o.showAt([r[0] - o.render().getWidth(), r[1]])
        }
    },
    onRestoreNodeDone: function(e, t, i, n) {
        e && (i.to_parent_folder || this.loadData())
    },
    onWindowShow: function() {
        this.mon(this.findAppWindow().getEventMgr(), {
            scope: this,
            restorenodedone: this.onRestoreNodeDone
        }), this.loadData()
    }
}), Ext.define("SYNO.SDS.Drive.VersionMgr.Window", {
    extend: "SYNO.SDS.Drive.ModalWindow",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        return this.grid = new SYNO.SDS.Drive.VersionMgr.Grid({
            data: e.data
        }), {
            owner: e.owner,
            title: SYNO.SDS.Drive._T("action", "manage_versions"),
            width: 580,
            height: 491,
            layout: "fit",
            resizable: !1,
            items: [this.grid],
            buttons: [{
                text: SYNO.SDS.Drive._T("common", "close"),
                scope: this,
                handler: this.close
            }],
            listeners: {
                scope: this.grid,
                show: this.grid.onWindowShow
            }
        }
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.ActionPrivChecker", {
    singleton: !0,
    capabilities: {
        can_comment: 1,
        can_read: 2,
        can_write: 4,
        can_share: 8,
        can_delete: 16,
        can_preview: 32,
        can_rename: 64
    },
    check: function(e, t, i) {
        var n = {
            display: !0,
            enable: !0,
            hide: function() {
                this.enable = !1, this.display = !1
            },
            disable: function() {
                this.enable = !1
            }
        };
        t && !Ext.isArray(t) && (t = [t]);
        var o = SYNO.SDS.Drive.Mgr.ActionPriv[e];
        return o ? (this.config = o, this.selections = t, this.type = i, this._checkPublicShare(n) && this._checkCategoryAndPath(n) && this._checkSelections(n) && this._checkBeforeRecord(n) && this._checkRecord(n) && this._checkViewMode(n), n) : (n.hide(), n)
    },
    _checkPublicShare: function(e) {
        if (SYNO.SDS.Drive.WindowHelper.isPublicShare())
            if (Ext.isString(this.config.allow_public_fn)) {
                var t = Ext.getClassByName(this.config.allow_public_fn);
                if (!t(this.selections, this.type, SYNO.SDS.Drive.GetWindow())) return e.hide(), !1
            } else if (!this.config.allow_public_fn) return e.hide(), !1;
        return !0
    },
    _checkCategoryAndPath: function(e) {
        var t = SYNO.SDS.Drive.GetWindow().getNavigation(),
            i = t.getCategoryText();
        if (this.config.category_exclude && -1 !== this.config.category_exclude.indexOf(i)) return e.hide(), !1;
        if (this.config.category && -1 === this.config.category.indexOf(i)) return e.hide(), !1;
        var n, o = t.getPath(),
            r = "/" + i,
            a = "menu_pathbar" === this.type ? o.length - 1 : o.length;
        for (n = 1; n < a; ++n) r += "/" + o[n].id;
        return this.config.path_exclude && -1 !== this.config.path_exclude.indexOf(r) ? (e.hide(), !1) : !this.config.path || -1 !== this.config.path.indexOf(r) || (e.hide(), !1)
    },
    _checkSelections: function(e) {
        var t = !1;
        if (!this.config.enable && 0 === this.selections.length) return this._hideIfMenu(e), !1;
        if (!1 === this.config.multiple && 1 < this.selections.length) return this._hideIfMenu(e), !1;
        if (this.config.type_exclude && -1 !== this.config.type_exclude.indexOf(this.type)) return e.hide(), !1;
        if (this.config.multiple_fn) {
            if (Ext.isFunction(this.config.multiple_fn)) t = this.config.multiple_fn(this.selections, SYNO.SDS.Drive.GetWindow());
            else if (Ext.isString(this.config.multiple_fn)) {
                var i = Ext.getClassByName(this.config.multiple_fn);
                t = i(this.selections, SYNO.SDS.Drive.GetWindow())
            }
            return t || e.hide(), t
        }
        return !0
    },
    _hideIfMenu: function(e) {
        "toolbar" === this.type ? e.disable() : e.hide()
    },
    _checkBeforeRecord: function(e) {
        var t = !0;
        if (this.config.beforefn)
            if (Ext.isFunction(this.config.beforefn)) t = this.config.beforefn(this.selections);
            else if (Ext.isString(this.config.beforefn)) {
            var i = Ext.getClassByName(this.config.beforefn);
            t = i(this.selections)
        }
        return t || e.hide(), t
    },
    _checkRecord: function(e) {
        var t = !0;
        return 1 < this.selections.length && !0 === this.config.multiple || (Ext.each(this.selections, function(e) {
            var i = SYNO.SDS.Drive.Utils.getFileTypeMapping(e.get("ntype"));
            if (this.config.ntype && -1 === this.config.ntype.indexOf(i)) return t = !1;
            if (this.config.ntype_exclude && -1 !== this.config.ntype_exclude.indexOf(i)) return t = !1;
            if (this.config.privilege) {
                var n = this.config.privilege.reduce(function(e, t) {
                    return e | this.capabilities[t]
                }.bind(this), 0);
                if (n !== (n & this._getPrivilege(e))) return t = !1
            }
            return this.config.display_path_regex && !this.config.display_path_regex.some(function(t) {
                return t.test(e.get("display_path"))
            }) ? t = !1 : !(this.config.fn && (t = this._checkFn(e)) && this.config.one_match) && void 0
        }, this), Ext.isEmpty(this.selections) && (this.config.enable || this.config.enable_when_empty) && (t = this._checkFn(null)), t || this._hideIfMenu(e), t)
    },
    _checkFn: function(e) {
        var t = !0;
        if (this.config.fn) {
            if (Ext.isFunction(this.config.fn)) return t = this.config.fn(e, SYNO.SDS.Drive.GetWindow());
            if (Ext.isString(this.config.fn)) {
                return t = Ext.getClassByName(this.config.fn)(e, SYNO.SDS.Drive.GetWindow())
            }
        }
        return t
    },
    _getPrivilege: function(e) {
        var t = 0,
            i = e.get("capabilities");
        return Ext.iterate(i, function(e, i) {
            i && (t |= this.capabilities[e])
        }, this), t
    },
    _checkViewMode: function(e) {
        return !("empty" === SYNO.SDS.Drive.GetWindow().getViewModeMgr().getViewMode() && !this.config.enable_when_empty) || (e.disable(), !1)
    }
}), Ext.ns("SYNO.SDS.Drive.Mgr"), Ext.define("SYNO.SDS.Drive.Mgr.Action", {
    extend: "SYNO.SDS.Drive.Action",
    ActionPriv: SYNO.SDS.Drive.Mgr.ActionPriv,
    ActionPrivChecker: SYNO.SDS.Drive.Mgr.ActionPrivChecker,
    clone: function() {
        return new SYNO.SDS.Drive.Mgr.Action(this)
    },
    createNode: function(e, t, i) {
        SYNO.SDS.Drive.Mgr.Action.superclass.createNode.call(this, Ext.apply({
            file_id: this.findAppWindow().getNavigation().getLastPathId()
        }, e || {}), t, i || this)
    },
    mergeTag: function(e, t, i) {
        var n = {},
            o = [];
        Ext.isArray(e) && (Ext.each(t, function(e, t, i) {
            o.push(Ext.copyTo({}, e, "color,label_id,name,type"))
        }), Ext.each(i, function(e, t, i) {
            n[e.label_id] = !0
        }), Ext.iterate(e, function(e) {
            var t, n = [],
                r = {},
                a = [];
            for (Ext.isArray(e.data.labels) && (a = e.data.labels.slice()), t = 0; t < a.length; t++) r[a[t].label_id] = a[t];
            for (t = 0; t < o.length; t++) {
                var s = o[t];
                s.label_id in r || (r[s.label_id] = s)
            }
            for (t = 0; t < i.length; t++) delete r[i[t].label_id];
            Ext.iterate(r, function(e, t) {
                "#" === t.color.charAt(0) && (t.color = t.color.substr(1)), n.push(t)
            }), e.data.labels = n, e.commit()
        }))
    },
    changeTag: function(e, t, i) {
        var n = this.getTargets();
        this.changeTagByRec(e, t, n)
    },
    changeTagByRec: function(e, t, i) {
        var n = [],
            o = [];
        Ext.each(i, function(e) {
            o.push(SYNO.SDS.Drive.Utils.getPathId(e.get("file_id")))
        }), o.length && (Ext.each(e, function(e, t, i) {
            n.push({
                action: "add",
                label_id: e.label_id
            })
        }), Ext.each(t, function(e, t, i) {
            n.push({
                action: "delete",
                label_id: e.label_id
            })
        }), this.mergeTag(i, e, t), this.setNodeTag({
            files: o,
            labels: n
        }))
    },
    setNodeTag: function(e) {
        SYNO.SDS.Drive.Mgr.Action.superclass.setNodeTag.call(this, e, function(e, t, i, n) {
            if (!e) return void this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
        }, this)
    },
    _previewNode: function(e) {
        var t = SYNO.SDS.Drive.GetWindow(),
            i = e.data;
        return i.capabilities.can_preview ? !!("dir" === i.ntype || Ext.getClassByName("SYNO.SDS.Drive.MainWindow") && t instanceof SYNO.SDS.Drive.MainWindow) : (t.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(1002)), !1)
    },
    previewNode: function(e) {
        (e = e instanceof Ext.data.Record ? e : this.getTarget()) && this._previewNode(e) && "dir" !== e.data.ntype && this.openUniversalViewer(e)
    },
    openNode: function(e) {
        if ((e = e instanceof Ext.data.Record ? e : this.getTarget()) && this._previewNode(e)) {
            var t = SYNO.SDS.Drive.GetWindow(),
                i = e.data;
            if ("dir" === i.ntype) {
                switch (t.getNavigation().getCategory()) {
                    case "search":
                        this.onGotoPath(e.id);
                        break;
                    default:
                        t.getNavigation().appendPath({
                            id: e.id,
                            text: i.name,
                            perm: i.capabilities,
                            display_path: i.display_path
                        })
                }
            } else if (SYNO.SDS.Drive.Utils.isOfficeFile(e.get("name"))) SYNO.SDS.Drive.Utils.openOffice(e.get("permanent_link"));
            else if ("video" === SYNO.SDS.Drive.FileType.getMappingType(SYNO.SDS.Drive.Utils.getExt(e.get("name")))) SYNO.SDS.Drive.ThirdParty.hasVideoStation() ? SYNO.SDS.Drive.ThirdParty.openWithVideoStation(e) : SYNO.SDS.Drive.ThirdParty.hasVideoPlayer() ? SYNO.SDS.Drive.ThirdParty.openWithVideoPlayer(e) : this.openUniversalViewer(e);
            else if ("recycle" === this.findAppWindow().getNavigation().getCategory()) {
                if (SYNO.SDS.Drive.Utils.isAppAuthorized() && SYNO.SDS.Drive.Utils.hasOffice() && SYNO.SDS.Office.Drive.openFile && SYNO.SDS.Office.Drive.openFile.call(this, e, t));
                else if (!1 !== t.getEventMgr().fireEvent("beforeopennode", e)) {
                    if (!i.capabilities.can_read && "dir" !== e.data.ntype) return void t.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(1002));
                    this.openFile(e)
                }
            } else this.openUniversalViewer(e)
        }
    },
    checkPreview: function(e) {
        return !e.get("removed") && "dir" !== e.get("ntype")
    },
    checkOpen: function(e) {
        return e.get("removed") || "dir" === e.get("ntype")
    },
    checkOpenNewWin: function(e) {
        return "dir" !== e.data.ntype && !e.data.removed && (!(!e.data.capabilities.can_read && "dir" !== e.data.ntype) && (!SYNO.SDS.Drive.Utils.isOfficeFile(e.get("name")) || SYNO.SDS.Drive.Utils.hasOffice()))
    },
    openNewWin: function() {
        var e = this.getTarget();
        return e.data.capabilities.can_read ? SYNO.SDS.Drive.Utils.isOfficeFile(e.get("name")) ? void SYNO.SDS.Drive.Utils.openOffice(e.get("permanent_link")) : void this.openFile(e) : void this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(1002))
    },
    renameNode: function() {
        var e = this.findAppWindow(),
            t = this.getTarget();
        if (1 === this.getTargets().length && !t.data.removed) {
            var i = "dir" === t.data.type;
            new SYNO.SDS.Drive.RenameNodeWindow({
                initName: t.data.name,
                blDir: i,
                owner: e,
                listeners: {
                    scope: this,
                    apply: function(e, i, n) {
                        SYNO.SDS.Drive.Mgr.Action.superclass.setNodeTitle.call(this, {
                            path: SYNO.SDS.Drive.Utils.getPathId(t.id),
                            name: n[e.nameItemId]
                        }, function() {
                            e.onApplyCb.apply(e, arguments)
                        })
                    }
                }
            }).show()
        }
    },
    postDeleteNode: function(e, t, i) {
        var n = e.name;
        delete e.name, this.findAppWindow().getTaskMgr().addTask(SYNO.SDS.Drive.TaskFactory.createBgTask({
            title: "delete",
            params: e,
            name: n,
            showProgress: !1,
            showStartToast: !0
        }))
    },
    deleteNode: function() {
        var e = this.findAppWindow(),
            t = this.getTargets(),
            i = [],
            n = [],
            o = 0;
        0 !== t.length && (Ext.each(t, function(e) {
            i.push(e.get("file_id")), n.push(e.get("name")), o = Math.max(o, e.get("revisions"))
        }), this.callParent([{
            revisions: o,
            file_id: i,
            name: n,
            permanent: "recycle" === e.getNavigation().getCategory()
        }, void 0, this]))
    },
    restoreNode: function() {
        var e = this.getTargets(),
            t = [],
            i = [];
        Ext.each(e, function(e) {
            t.push({
                path: SYNO.SDS.Drive.Utils.getPathId(e.get("file_id"))
            }), i.push(e.get("name"))
        }), this.restoreFileVersion({
            files: t,
            dry_run: !0
        }, i)
    },
    updateShortcutEarly: function(e) {
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var t = this.getTargets();
            Ext.iterate(t, function(t) {
                t.data.starred = !!e, t.commit()
            })
        }
    },
    updateMultiShortcut: function(e) {
        var t = !1,
            i = this.findAppWindow(),
            n = this.getTargets();
        0 !== n.length && "recycle" !== i.getNavigation().category && (Ext.iterate(n, function(e) {
            if (!e.data.starred) return t = !0, !1
        }), !0 === t ? this.setShortcut(e) : this.deleteShortcut(e))
    },
    setShortcut: function(e) {
        this.updateShortcutEarly(!0), e && e.file_id || (e = Ext.apply({
            file_id: this.getTargetFileIds()
        }, e || {})), SYNO.SDS.Drive.Mgr.Action.superclass.setShortcut.call(this, e, function(e, t, i, n) {
            if (!e) return void this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
        }, this)
    },
    deleteShortcut: function(e) {
        this.updateShortcutEarly(!1), e && e.file_id || (e = Ext.apply({
            file_id: this.getTargetFileIds()
        }, e || {})), SYNO.SDS.Drive.Mgr.Action.superclass.deleteShortcut.call(this, e, function(e, t, i, n) {
            if (!e) return void this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
        }, this)
    },
    infoNode: function() {
        SYNO.SDS.Drive.Mgr.Action.superclass.infoNode.call(this, {
            rec: this.getTarget()
        })
    },
    mvcpNode: function(e, t, i) {
        var n = [],
            o = [];
        if (t.files) {
            var r = SYNO.SDS.Drive.Mgr.FileClipboard.get();
            n = i, o = r.recs
        } else {
            t.files = [];
            var a = !1,
                s = SYNO.SDS.Drive.Utils.getFileIdFromPathId(t.to_parent_folder);
            if (o = this.getTargets(), Ext.each(o, function(i) {
                    if (t.files.push(SYNO.SDS.Drive.Utils.getPathId(i.get("file_id"))), n.push(i.get("name")), i.get("parent_id") === s && (a = !0, "move" === e)) return !1
                }), a) {
                if ("move" === e) return void SYNO.SDS.Drive.Utils.showAlertMsg(this.findAppWindow(), SYNO.SDS.Drive._T("error", "parent_path_conflict"));
                t.conflict_action = "autorename"
            }
        }
        SYNO.SDS.Drive.Mgr.Action.superclass.mvcpNode.call(this, e, t, n, o)
    },
    postMvcpNode: function(e, t, i, n) {
        var o = SYNO.SDS.Drive.TaskFactory.createBgTask({
                title: e,
                params: t,
                name: i
            }, n),
            r = this.findAppWindow(),
            a = r.getStoreMgr().getActiveStore(),
            s = SYNO.SDS.Drive.Utils.getFileIdFromPathId(t.to_parent_folder);
        r.getPanel().getView && r.getPanel().getView().syncFocusEl && r.getPanel().getView().syncFocusEl(a.indexOf(s)), r.getTaskMgr().addTask(o), r.getEventMgr().fireEvent("mvcpstart", e, t, i)
    },
    copyNodeToNew: function() {
        var e = this.findAppWindow().getNavigation();
        this.copyNode({
            to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(e.getLastPathId()),
            to_parent_folder_name: e.getLastPath().text,
            conflict_action: "autorename"
        })
    },
    copyNodeTo: function() {
        var e = this.getTargets();
        if (0 !== e.length) {
            var t = e[0].get("name");
            this.callParent([{}, void 0, void 0, !0, void 0, t])
        }
    },
    moveNodeTo: function() {
        this.callParent([{}, void 0, void 0])
    },
    onTreeDlgGotoPath: function(e, t) {
        if (!t) {
            var i = this.findAppWindow().getNavigation(),
                n = i.getCategory(),
                o = i.getPath();
            if ("shared_with_me" === n && o && o.length > 1 || "node" === n || "team_folder" === n) return void e.onGoToPath(i.getPath());
            var r = this.getTargets();
            if (0 === r.length) return void e.onGoToPath([]);
            var a = r[0].data.display_path.match(/^(.+)(\/.+$)/);
            if (!a) return void e.onGoToPath([]);
            var s = a[1];
            r.forEach(function(t) {
                var i = t.data.display_path.match(/^(.+)(\/.+$)/);
                if (!i || s !== i[1]) return void e.onGoToPath([])
            });
            var l = s.split("/");
            if ("/" === s.charAt(0) && l.splice(0, 1), "mydrive" === l[0]) n = "node";
            else if ("team-folders" === l[0]) n = "team_folder";
            else {
                if ("shared-with-me" !== l[0]) return void e.onGoToPath([]);
                n = "shared_with_me"
            }
            return void this.findAppWindow().getWebAPI().getNodeAncestors({
                params: this.prepareParam({
                    file_id: r[0].data.file_id
                }),
                scope: this,
                callback: function(t, o) {
                    if (!t || o.error) return void e.onGoToPath([]);
                    var r = [];
                    Ext.each(o.items, function(e) {
                        var t = e.name || SYNO.SDS.Drive.Utils.getBaseName(e.display_path);
                        r.push({
                            id: e.file_id,
                            text: t,
                            perm: e.capabilities,
                            display_path: e.display_path
                        })
                    }), "node" === n ? r.shift() : "shared_with_me" === n && r.splice(0, o.items.length - (l.length - 1)), r.splice(0, 0, i.getPath(n)[0]), e.onGoToPath(r)
                }
            })
        }
        SYNO.SDS.Drive.Mgr.Action.superclass.onTreeDlgGotoPath.apply(this, arguments)
    },
    shareNode: function(e) {
        var t = this.getTarget();
        SYNO.SDS.Drive.Mgr.Action.superclass.shareNode.call(this, {
            file_id: t.id,
            capabilities: t.data.capabilities,
            type: t.data.ntype,
            name: t.data.name,
            display_path: t.data.display_path,
            adv_shared: t.data.adv_shared
        })
    },
    shareNodeByParam: function(e) {
        SYNO.SDS.Drive.Mgr.Action.superclass.shareNode.call(this, e)
    },
    leaveNode: function() {
        SYNO.SDS.Drive.Mgr.Action.superclass.deleteNodePerm.call(this, {
            file_id: this.getTargetFileIds(),
            username: this.findAppWindow()._S("user")
        }, function(e, t, i, n) {
            if (!e) return void this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(t))
        }, this)
    },
    getLinkFromMenu: function(e) {
        var t = this.createShareMenu(),
            i = e.parentMenu.menuType;
        if ("menu_pathbar" === i) t.open(i, e.parentMenu.getOrigin());
        else {
            var n = this.findAppWindow().getPanel().getSelectedElements()[0];
            t.open(this.findAppWindow().getPanel().itemId, n)
        }
    },
    getLinkFromToolBar: function(e) {
        this.createShareMenu().open("toolbar", e.el.dom)
    },
    createShareMenu: function() {
        var e = this.getTarget(),
            t = new SYNO.SDS.Drive.Share.GetLink.Menu({
                owner: this.findAppWindow(),
                file_info: this.prepareParam({
                    file_id: e.id,
                    capabilities: e.data.capabilities,
                    shared_with: e.data.shared_with,
                    adv_shared: e.data.adv_shared,
                    display_path: e.data.display_path,
                    file_type: e.data.ntype
                })
            });
        return t.setAction(this), t
    },
    onCopyAction: function() {
        this.onCuCopyAction("copy")
    },
    onCutAction: function() {
        this.onCuCopyAction("cut")
    },
    onCuCopyAction: function(e) {
        var t = this.findAppWindow();
        t.hasSeletion() && "recycle" !== t.getNavigation().category && SYNO.SDS.Drive.Mgr.FileClipboard.set(e, this.getTargets())
    },
    onPasteAction: function(e) {
        var t, i, n = this.findAppWindow();
        if ("recycle" !== n.getNavigation().category) {
            if (e.ownerCt && "toolbar" !== e.ownerCt.getType()) {
                var o = this.getTargets();
                o && 1 === o.length && "dir" === o[0].data.ntype && (t = o[0].id, i = o[0].name)
            }
            if (t || (t = n.getNavigation().getLastPathId(), i = n.getNavigation().getLastPath().text), t && !SYNO.SDS.Drive.Mgr.FileClipboard.isEmpty()) {
                var r = SYNO.SDS.Drive.Mgr.FileClipboard.get(),
                    a = [],
                    s = [];
                Ext.each(r.recs, function(e) {
                    a.push(SYNO.SDS.Drive.Utils.getPathId(e.get("file_id"))), s.push(e.get("name"))
                });
                var l = {
                    files: a,
                    to_parent_folder: SYNO.SDS.Drive.Utils.getPathId(t),
                    to_parent_folder_name: i
                };
                r.parent_id !== t ? "cut" === r.action ? this.moveNode(l, s) : this.copyNode(l, s) : "copy" === r.action && (l.conflict_action = "autorename", this.copyNode(l, s)), SYNO.SDS.Drive.Mgr.FileClipboard.clean()
            }
        }
    },
    onGotoPath: function(e, t, i, n) {
        e = Ext.isString(e) ? this.prepareParam({
            file_id: e
        }) : this.prepareParam(e);
        var o = this.findAppWindow();
        o.getWebAPI().getNode({
            params: e,
            scope: this,
            callback: function(r, a) {
                if (!r) return void(t ? t.call(i || this, r, a, void 0, e) : o.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(a)));
                this.goto(a, t, i, e, n)
            }
        })
    },
    gotoNode: function() {
        var e = this.getTarget();
        this.goto(e.data)
    },
    goto: function(e, t, i, n, o) {
        var r, a = [],
            s = e.display_path,
            l = s.split("/"),
            d = this.findAppWindow(),
            c = function(e, n, r, a, s) {
                var l;
                "file" !== n.type && !1 !== o || (l = n.file_id);
                var d = this.findAppWindow().getNavigation();
                t && !t.call(i || this, e, n, r, a, s, l) || d.setCategoryAndPath(r, s, null, l)
            };
        if (e.removed) {
            var h;
            "dir" === e.type && (r = e.name, r || (r = SYNO.SDS.Drive.Utils.getBaseName(e.display_path)), h = {
                id: e.file_id,
                text: r,
                perm: e.capabilities,
                display_path: e.display_path
            });
            var u = "mydrive" === l[2];
            if (!_S("is_admin") && !u) return;
            return !u && l.length <= 6 || u && l.length <= 4 ? void c.call(this, !0, e, "recycle", n, [h]) : void d.getWebAPI().getTrashAncestor({
                params: this.prepareParam({
                    file_id: e.file_id
                }),
                scope: this,
                callback: function(o, s) {
                    if (!o) return void(t ? t.call(i || this, o, s, "recycle", n) : d.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(s)));
                    Ext.each(s.items, function(e) {
                        if ("dir" !== e.type) return !1;
                        r = e.name, r || (r = SYNO.SDS.Drive.Utils.getBaseName(e.display_path)), a.push({
                            id: e.file_id,
                            text: r,
                            perm: e.capabilities,
                            display_path: e.display_path
                        })
                    }), h && a.push(h), c.call(this, o, e, "recycle", n, a)
                }
            })
        }
        var S;
        if ("/" === s.charAt(0) && l.splice(0, 1), "mydrive" === l[0] ? S = "node" : "team-folders" === l[0] ? S = "team_folder" : "shared-with-me" === l[0] && (S = "shared_with_me"), !S) {
            var g = SYNO.SDS.Drive.Utils.getHashParam();
            return void(g.file_id && g.file_id === e.file_id ? SYNO.SDS.Drive.Utils.openURL(SYNO.SDS.Drive.Utils.getDriveLink(e.permanent_link), void 0, !1) : d.getMsgBox({
                preventDelay: !0
            }).confirm("", SYNO.SDS.Drive._T("request", "open_shared_folder"), function(t) {
                "yes" === t && SYNO.SDS.Drive.Utils.openURL(SYNO.SDS.Drive.Utils.getDriveLink(e.permanent_link), void 0, !0)
            }))
        }
        d.getWebAPI().getNodeAncestors({
            params: this.prepareParam({
                file_id: e.file_id
            }),
            scope: this,
            callback: function(s, h) {
                if (!s || h.error) return void(t ? t.call(i || this, s, h, S, n) : (d.getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(h.error)), c.call(this, !1, e, S, n, [])));
                Ext.each(h.items, function(e) {
                    return "dir" === e.type && (!(r = e.name || SYNO.SDS.Drive.Utils.getBaseName(e.display_path)) || void a.push({
                        id: e.file_id,
                        text: r,
                        perm: e.capabilities,
                        display_path: e.display_path
                    }))
                }), !1 !== o && "file" !== e.type && a.push({
                    id: e.file_id,
                    text: e.name,
                    perm: e.capabilities,
                    display_path: e.display_path
                }), "node" === S ? a.shift() : "shared_with_me" === S && a.splice(0, h.items.length - (l.length - 1)), c.call(this, s, e, S, n, a)
            }
        })
    },
    bindingChat: function() {
        var e = this.getTarget();
        new SYNO.SDS.Drive.Chat.Binding.Window({
            file_id: e.id,
            owner: this.findAppWindow()
        }).show()
    },
    manageVersions: function() {
        var e = this.getTarget();
        this.showVersion(e.data)
    },
    showVersion: function(e, t) {
        if (SYNO.SDS.Drive.Utils.isOfficeFile(e.name) && !SYNO.SDS.Drive.Utils.hasOffice()) {
            var i = SYNO.SDS.Drive._T("app", "install_office_alert");
            return SYNO.SDS.Drive.Define.Info.office_migration && (i = SYNO.SDS.Drive._T("app", "migration_office")), void SYNO.SDS.Drive.Utils.showAlertMsg(t || this.findAppWindow(), i)
        }
        new SYNO.SDS.Drive.VersionMgr.Window({
            data: e,
            owner: t || this.findAppWindow()
        }).show()
    },
    getUniversalViewerWindow: function() {
        return this.universalViewerWindow || (this.universalViewerWindow = new SYNO.SDS.Drive.UniversalViewer.Window)
    },
    preloadUniversalViewer: function() {
        this.getUniversalViewerWindow().preload()
    },
    openUniversalViewer: function(e) {
        this.getUniversalViewerWindow().open(e)
    },
    closeUniversalViewer: function() {
        this.getUniversalViewerWindow().close()
    },
    clearUniversalViewer: function() {
        this.getUniversalViewerWindow().clear()
    },
    showMember: function() {
        new SYNO.SDS.Drive.MemberDialog({
            rec: this.getTarget(),
            owner: this.findAppWindow()
        }).show()
    },
    showSyncDevice: function() {
        new SYNO.SDS.Drive.Sync.Window({
            owner: this.findAppWindow()
        }).show()
    },
    postRestoreNode: function(e, t) {
        t = Ext.isArray(t) ? t : [t];
        var i = SYNO.SDS.Drive.TaskFactory.createRestoreBgTask({
                params: e,
                name: t
            }),
            n = this.findAppWindow();
        n.getTaskMgr().addTask(i), n.getEventMgr().fireEvent("restorestart", e, t)
    },
    addSyncDevice: function() {
        var e = this.getTargets(),
            t = [];
        Ext.each(e, function(e) {
            e.get("sync_to_device") || t.push(e.get("file_id"))
        }), this.findAppWindow().getAction().syncDevice({
            enable: t
        })
    },
    removeSyncDevice: function() {
        var e = this.getTargets(),
            t = [];
        Ext.each(e, function(e) {
            e.get("sync_to_device") && t.push(e.get("file_id"))
        }), this.findAppWindow().getAction().syncDevice({
            disable: t
        })
    },
    cleanNode: function() {
        var e = this.findAppWindow();
        if ("recycle" === e.getNavigation().getCategory()) {
            var t = e.getDrivePanel().getRecycleBtn(),
                i = t.getCheckedId(),
                n = t.getItemText(i);
            _S("is_admin") || (i = "node", n = SYNO.SDS.Drive._T("category", "node"));
            var o = "node" === i ? SYNO.SDS.Drive.Define.Info.drive_id : i,
                r = SYNO.SDS.Drive.Utils.getPathId(o);
            this.callParent([{
                path: r,
                name: n
            }])
        }
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.SearchPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.owner = e.owner;
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        var i = this.findAppWindow().getEventMgr();
        this.mon(i, "envready", this.onEnvReady, this), this.mon(i, "beforecategorychange", this.onBeforeCategoryChange, this), this.mon(i, "pathchange", this.onPathChange, this)
    },
    onBeforeCategoryChange: function(e) {
        "search" !== e && (this.categoryBeforeSearch = e)
    },
    onPathChange: function(e, t, i, n) {
        n && "search" !== i && (this.isRootBeforeSearch = t && t.length <= 1, this.lastPath = t[t.length - 1], this.isRootBeforeSearch && "node" === i ? this.lastPathId = SYNO.SDS.Drive.Define.Info.drive_id : this.lastPathId = this.lastPath.id, this.setCurrentText())
    },
    setCurrentText: function() {
        var e = this.getComponent("location_combo"),
            t = e.store.getById("current_location"),
            i = String.format("{0} ({1})", SYNO.SDS.Drive._T("search", "curlocation"), this.lastPath.text);
        "current_location" === e.value && e.setRawValue(i), t.set("display", i)
    },
    onMouseDown: function(e) {
        var t = this.datefromField,
            i = this.datetoField;
        this.handleHideDateField(e, t), this.handleHideDateField(e, i), this.handleHideBtn(e, this.tagField)
    },
    onEnvReady: function() {
        SYNO.SDS.Drive.Define.Info.is_home || this.location_store.removeAt(this.location_store.indexOfId("mydrive"))
    },
    focusKeywordInput: function() {
        this.items.get(0).focus()
    },
    handleHideDateField: function(e, t) {
        var i = t.menu;
        t && t.menu && (e.within(t.trigger) || e.within(this.getEl()) && !e.within(t.getEl()) && !e.within(i.getEl()) && i.isVisible() && t.menuEvents("hide"))
    },
    handleHideBtn: function(e, t) {
        var i = t.menu;
        t && t.menu && e.within(this.getEl()) && !e.within(i.getEl()) && i.isVisible() && t.hideMenu()
    },
    getSearchParams: function() {
        if (this.rendered) {
            var e = this.getForm(),
                t = e.getValues();
            if (e.isValid()) return t.tag = this.tagField.getRawValue(), t.searchdatefromformat = e.findField("searchdatefrom").format, t.searchdatetoformat = e.findField("searchdateto").format, t.curlocation = !1, "current_location" === t.location && (t = this.curLocationMap(t)), t
        }
    },
    onSearch: function() {
        var e = this.findAppWindow(),
            t = e.getNavigation(),
            i = this.getForm(),
            n = this.tagField;
        if (i.isValid()) {
            if (!i.isDirty() && !n.isDirty()) {
                var o = e.getMsgBox(),
                    r = function() {
                        if (o.getDialog().isVisible()) return !1
                    };
                return SYNO.SDS.Desktop.el.mask().dom.style.opacity = 0, o.alert("", SYNO.SDS.Drive._T("search", "least_one"), function() {
                    SYNO.SDS.Desktop.el.unmask(), this.mun(this.ownerCt, r)
                }, this), o.getDialog().setZIndex(20001), void this.mon(this.ownerCt, "beforehide", r)
            }
            this.owner.hideMenu(), t.setCategoryAndPath("search", null, {
                params: this.getSearchParams()
            })
        }
    },
    curLocationMap: function(e) {
        if (this.isRootBeforeSearch) switch (this.categoryBeforeSearch) {
            case "node":
                e.location = "mydrive";
                break;
            case "team_folder":
                e.location = "team_folders";
                break;
            case "sharing_to_others":
                e.location = "shared_with_others";
                break;
            case "starred":
                e.location = "starred";
                break;
            case "shared_with_me":
                e.location = "shared_with_me";
                break;
            default:
                e.location = null, e.tag = [{
                    category: "label",
                    label_id: this.categoryBeforeSearch
                }]
        } else e.location = "custom", e.parent_id = this.categoryBeforeSearch + ":" + this.lastPathId;
        return e.curlocation = !0, e
    },
    isSupport: function(e) {
        return "recycle" !== this.categoryBeforeSearch && "backup" !== this.categoryBeforeSearch && "recent" !== this.categoryBeforeSearch || "current_location" !== this.getForm().getFieldValues().location || SYNO.SDS.Drive._T("search", "current_location_not_supported")
    },
    setValue: function(e) {
        e && (!0 === e.curlocation && (e.location = "current_location"), this.reset(), this.tagField.setValue(e.tag), this.getForm().setValues(e), this.findAppWindow().getDrivePanel().getSearchField().setValue(e.query))
    },
    reset: function() {
        this.getForm().reset(), this.tagField.reset(), this.getForm().findField("searchdatefrom").setMaxValue(null), this.getForm().findField("searchdateto").setMinValue(null), this.showHideGroupCmp("custom_owner", "owner", !1), this.showHideGroupCmp("custom_size", "size", !1), this.showHideGroupCmp("custom_file_type", "ntype", !1), this.showHideGroupCmp("datefield_group", "datetype", !1)
    },
    handleClickCancel: function() {
        this.reset()
    },
    fillConfig: function(e) {
        var t = SYNO.SDS.Drive._T,
            i = new Ext.data.SimpleStore({
                autoDestroy: !0,
                fields: ["value", "display"],
                data: [
                    ["any", t("search", "any")],
                    ["modified_time", t("file", "mtime")],
                    ["created_time", t("file", "ctime")]
                ]
            });
        this.tagField = new SYNO.SDS.Drive.TagButton({
            fieldLabel: t("category", "tag"),
            width: 368,
            menuCfg: {
                width: 368,
                hideCreate: !0,
                allowOtherMenus: !0,
                store: this.findAppWindow().getCategoryPanel().getStore()
            }
        }), this.tagField.cls += " syno-d-adv-search-component", this.datefromField = new SYNO.SDS.Drive.DateField({
            name: "searchdatefrom",
            editable: !1,
            format: SYNO.SDS.Drive.Utils.getDateFormat(),
            emptyText: t("search", "date_from"),
            value: "",
            itemId: "searchdatefrom",
            listeners: {
                select: {
                    fn: function(e, t) {
                        this.form.findField("searchdateto").setMinValue(t)
                    },
                    scope: this
                }
            }
        }), this.datetoField = new SYNO.SDS.Drive.DateField({
            name: "searchdateto",
            editable: !1,
            format: SYNO.SDS.Drive.Utils.getDateFormat(),
            emptyText: t("search", "date_to"),
            value: "",
            itemId: "searchdateto",
            listeners: {
                select: {
                    fn: function(e, t) {
                        this.form.findField("searchdatefrom").setMaxValue(t)
                    },
                    scope: this
                }
            }
        });
        var n = {
            width: 566,
            height: 522,
            autoHeight: !0,
            cls: "syno-d-adv-search-panel",
            defaults: {
                anchor: "100%"
            },
            items: [{
                xtype: "syno_textfield",
                fieldLabel: t("search", "keyword"),
                cls: "syno-d-adv-search-component",
                name: "query",
                value: ""
            }, {
                xtype: "syno_combobox",
                fieldLabel: t("file", "location"),
                cls: "syno-d-adv-search-component",
                name: "location",
                validator: this.isSupport.createDelegate(this),
                itemId: "location_combo",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: this.location_store = new Ext.data.SimpleStore({
                    idIndex: 0,
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: [
                        ["any", t("search", "all")],
                        ["current_location", t("search", "curlocation")],
                        ["mydrive", t("category", "node")],
                        ["team_folders", t("category", "team_folder")],
                        ["shared_with_me", t("category", "shared_with_me")],
                        ["shared_with_others", t("category", "sharing_to_others")],
                        ["starred", t("category", "starred")],
                        ["customize_location", t("search", "customize_location")]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                listClass: "x-menu syno-ux-combobox-list",
                value: "any",
                listeners: {
                    scope: this,
                    beforeselect: function(e, t, i) {
                        if ("customize_location" === t.data.value) return this.treedlg = new SYNO.SDS.Drive.TreeWindow({
                            title: SYNO.SDS.Drive._T("search", "search_folder"),
                            hideCreate: !0,
                            hideForm: !0,
                            owner: this.findAppWindow(),
                            listeners: {
                                scope: this,
                                choose: function(t, i) {
                                    if (!i) return void t.getMsgBox().alert("", SYNO.SDS.Drive._T("error", "select_one"));
                                    var n, o = i.attributes.id;
                                    switch (i.attributes.id) {
                                        case "node":
                                            o = "mydrive";
                                            break;
                                        case "team_folder":
                                            o = "team_folders";
                                            break;
                                        case "shared_with_me":
                                            o = "shared_with_me";
                                            break;
                                        default:
                                            n = i.attributes.text
                                    }
                                    this.getForm().findField("parent_id").setValue(n ? i.attributes.id : ""), e.setValue(n || o), t.close()
                                },
                                show: function(e) {
                                    e.onGoToPath([]);
                                    var t = this.ownerCt,
                                        i = parseInt(this.treedlg.getEl().getStyle("z-index"), 10);
                                    t.el.setZIndex(i - 3);
                                    var n = t.el.mask();
                                    n.setOpacity(0), n.setStyle("z-index", i - 1)
                                },
                                beforehide: function() {
                                    this.ownerCt.el.unmask()
                                }
                            }
                        }), this.treedlg.show(), e.collapse(), !1
                    },
                    select: function(e) {
                        this.getForm().findField("parent_id").setValue("")
                    }
                }
            }, {
                xtype: "hidden",
                name: "parent_id"
            }, {
                xtype: "syno_combobox",
                fieldLabel: t("file", "type"),
                cls: "syno-d-adv-search-component",
                name: "ntype",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: new Ext.data.SimpleStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: [
                        ["any", t("search", "any")],
                        ["folder", t("file", "dir")],
                        ["file", t("search", "file")],
                        ["odoc", t("file", "odoc")],
                        ["osheet", t("file", "osheet")],
                        ["oslides", t("file", "oslide")],
                        ["document", t("file", "doc")],
                        ["image", t("file", "type_photo")],
                        ["audio", t("file", "type_music")],
                        ["video", t("file", "type_video")],
                        ["extension", t("file", "extension")]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                listClass: "x-menu syno-ux-combobox-list",
                value: "any",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.showHideGroupCmp("custom_file_type", "ntype", "extension" === t.data.value)
                    }
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: "",
                name: "custom_file_type",
                emptyText: t("file", "extension"),
                disabled: !0,
                allowBlank: !1,
                hidden: !0
            }, {
                xtype: "syno_combobox",
                fieldLabel: t("file", "owner"),
                cls: "syno-d-adv-search-component",
                name: "owner",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: new Ext.data.SimpleStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: [
                        ["any", t("search", "owner_any")],
                        ["me", t("search", "owner_me")],
                        ["not_me", t("search", "owner_not_me")],
                        ["custom", t("search", "custom_owner")]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                listClass: "x-menu syno-ux-combobox-list",
                value: "any",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.showHideGroupCmp("custom_owner", "owner", "custom" === t.data.value)
                    }
                }
            }, {
                xtype: "syno_combobox",
                fieldLabel: "",
                name: "custom_owner",
                lazyInit: !1,
                emptyText: _T("common", "owner"),
                listEmptyText: SYNO.SDS.Drive._T("common", "no_data"),
                editable: !0,
                hideTrigger: !0,
                store: this.getUserStore(),
                minChars: 1,
                valueField: "name",
                displayField: "name",
                queryParam: "query",
                mode: "remote",
                enableKeyEvents: !1,
                hidden: !0,
                disabled: !0,
                allowBlank: !1,
                tpl: new Ext.XTemplate('<tpl for=".">{[this.insertBefore(values, xindex, parent)]}<div class="x-combo-list-item {[values.cls || ""]}" role="option" aria-label="{[Ext.util.Format.htmlEncode(Ext.util.Format.stripTags(values.displayname))]}" id="{[Ext.id()]}" ext:qtip="{[Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(values.displayname))]}">{[Ext.util.Format.htmlEncode(values.displayname)]}</div></tpl></tpl>', {
                    insertBefore: function(e, t, i) {
                        return t > 1 && i[t - 2].type !== e.type ? '<div class="syno-d-menu-sep">&nbsp;</div>' : ""
                    }
                })
            }, this.tagField, {
                xtype: "syno_combobox",
                fieldLabel: t("file", "size") + " (MB)",
                cls: "syno-d-adv-search-component",
                name: "size",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: new Ext.data.SimpleStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: [
                        ["any", t("search", "any")],
                        ["equal", t("search", "size_equal")],
                        ["greater", t("search", "size_greater")],
                        ["less", t("search", "size_less")]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                listClass: "x-menu syno-ux-combobox-list",
                value: "any",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.showHideGroupCmp("custom_size", "size", "any" !== t.data.value)
                    }
                }
            }, {
                xtype: "syno_numberfield",
                fieldLabel: "",
                name: "custom_size",
                emptyText: t("file", "size") + " (MB)",
                allowNegative: !1,
                vtype: "nonenegativeinteger",
                hidden: !0,
                disabled: !0,
                maxValue: Math.floor(SYNO.SDS.Drive.Define.MAX_INT_VALUE / 1024 / 1024)
            }, {
                xtype: "syno_combobox",
                fieldLabel: t("time", "time_date"),
                name: "datetype",
                itemCls: "syno-d-adv-search-date-type",
                triggerAction: "all",
                editable: !1,
                mode: "local",
                store: i,
                displayField: "display",
                valueField: "value",
                lazyRender: !0,
                listClass: "x-menu syno-ux-combobox-list",
                value: "any",
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        this.showHideGroupCmp("datefield_group", "datetype", "any" !== t.data.value)
                    }
                }
            }, {
                xtype: "syno_compositefield",
                name: "datefield_group",
                fieldLabel: "",
                cls: "syno-d-adv-search-component",
                defaultMargins: "0 8 0 0",
                defaults: {
                    flex: 1
                },
                hidden: !0,
                items: [this.datefromField, this.datetoField]
            }, {
                xtype: "toolbar",
                cls: "syno-d-adv-search-toolbar",
                items: [{
                    xtype: "syno_button",
                    text: t("common", "reset"),
                    btnStyle: "grey",
                    listeners: {
                        click: this.handleClickCancel,
                        scope: this
                    }
                }, {
                    xtype: "tbfill"
                }, {
                    xtype: "syno_button",
                    btnStyle: "default",
                    text: t("common", "search"),
                    listeners: {
                        click: this.onSearch,
                        scope: this
                    }
                }]
            }],
            keys: [{
                key: [Ext.EventObject.ENTER],
                scope: this,
                fn: function() {
                    this.isVisible() && this.onSearch()
                }
            }]
        };
        return Ext.apply(n, e), n
    },
    showHideGroupCmp: function(e, t, i) {
        var n = this.form.findField(e),
            o = this.form.findField(t);
        n && o && (i ? (n.addClass("syno-d-adv-search-component"), o.removeClass("syno-d-adv-search-component"), n.setDisabled(!1), n.show()) : (n.removeClass("syno-d-adv-search-component"), o.addClass("syno-d-adv-search-component"), n.setDisabled(!0), n.hide()))
    },
    getCategoryBeforeSearch: function() {
        return this.categoryBeforeSearch
    },
    getUserStore: function() {
        return this.userStore || (this.userStore = new SYNO.API.Store({
            appWindow: this,
            autoLoad: !1,
            autoDestroy: !0,
            pruneModifiedRecords: !0,
            baseParams: {
                query: "",
                limit: 500,
                additional: ["nickname"]
            },
            proxy: new SYNO.API.Proxy(Ext.apply({
                listeners: {
                    scope: this,
                    beforeload: function(e, t) {
                        var i = e.activeRequest.read;
                        if (i && Ext.Ajax.abort(i), 0 !== this.userStore.getTotalCount() && this.blQueryEmpty) {
                            var n = this.form.findField("owner");
                            return this.userStore.filter(n.displayField, t.query, !0, !1, !1), n.onLoad(), !1
                        }
                        this.query = t.query
                    },
                    load: function() {
                        this.query || this.blQueryEmpty || (this.blQueryEmpty = !0)
                    }
                }
            }, SYNO.SDS.Drive.WebAPIDesc.list_app_priv)),
            reader: new Ext.data.JsonReader({
                root: "list",
                idProperty: "",
                fields: [{
                    name: "id",
                    convert: function(e, t) {
                        return t.name + "@" + t.type
                    }
                }, "name", "nickname", "type", "role", {
                    name: "cls",
                    convert: function(e, t) {
                        return "group" === t.type ? "syno-d-combo-share-group" : "syno-d-combo-share-user"
                    }
                }, {
                    name: "displayname",
                    convert: function(e, t) {
                        return t.nickname ? t.name + " (" + t.nickname + ")" : t.name
                    }
                }]
            }),
            listeners: {
                scope: this,
                load: function(e) {
                    e.filterBy(function(e) {
                        return "user" === e.data.type
                    })
                }
            }
        }))
    }
}), Ext.define("SYNO.SDS.Drive.Mgr.SearchField", {
    extend: "SYNO.ux.SearchField",
    constructor: function(e) {
        var t = this.fillConfig(e || {});
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            ctCls: "syno-ux-textfilter syno-d-round-searchfield",
            width: 280,
            height: 32,
            margins: {
                right: 10
            },
            enableKeyEvents: !0,
            listeners: {
                blur: this.enableHotkey,
                focus: this.disableHotkey,
                keyup: function(e, t) {
                    t.ENTER === t.keyCode && (this.searchTimer && window.clearTimeout(this.searchTimer), this.searchTimer = this.onSearchFieldKeyDown.defer(400, this))
                }
            },
            onTriggerClick: function() {
                this.disabled || (SYNO.ux.SearchField.superclass.onTriggerClick.apply(this, arguments), this.onTriggerEmpty(), this.getSearchPanel().reset())
            }
        };
        return Ext.apply(t, e), t
    },
    enableHotkey: function() {
        this.findAppWindow().getDrivePanel().getActiveKeyMap().enable()
    },
    disableHotkey: function() {
        this.findAppWindow().getDrivePanel().getActiveKeyMap().disable()
    },
    onSearchFieldKeyDown: function() {
        this.searchTimer && (window.clearTimeout(this.searchTimer), this.searchTimer = null), this.getValue() && this.fullTextSearch({
            query: this.getValue()
        })
    },
    fullTextSearch: function(e) {
        var t = this.findAppWindow(),
            i = t.getNavigation(),
            n = this.getSearchPanel();
        if (!0 !== n.isSupport()) return void SYNO.SDS.Drive.Utils.showToastMsg(t, SYNO.SDS.Drive._T("category", String.format("not_supported_search_{0}", n.getCategoryBeforeSearch())), 3e3);
        var o = n.getSearchParams() || {};
        i.setCategoryAndPath("search", null, {
            params: Ext.apply(o, e)
        }), t.getStoreMgr().getActiveStore().removeAll()
    },
    getSearchPanel: function() {
        return this.searchPanel || (this.searchPanel = new SYNO.SDS.Drive.Mgr.SearchPanel({
            owner: this
        }))
    },
    getMenu: function() {
        var e = this;
        return this.menu || (this.menu = new SYNO.ux.Menu({
            cls: "syno-d-adv-search-menu",
            owner: this,
            enableScrolling: !1,
            defaultOffsets: [0, 2],
            items: [this.getSearchPanel()],
            listeners: {
                scope: this.getSearchPanel(),
                beforeshow: function(t) {
                    this.getForm().findField("query").setValue(e.getValue())
                },
                beforehide: function() {
                    return (!this.treedlg || !this.treedlg.isVisible()) && (!this.form.findField("custom_owner").list.isVisible() && void e.setValue(this.getForm().findField("query").getValue()))
                }
            }
        }), this.findAppWindow().addManagedComponent(this.menu)), this.menu
    },
    showMenu: function() {
        return this.rendered && this.getMenu() && (this.getMenu().isVisible() && this.getMenu().hide(), this.getMenu().ownerCt = this, this.getMenu().show(this.wrap, "tr-br?")), this.getSearchPanel().getForm().clearInvalid(), this
    },
    hideMenu: function() {
        this.menu.hide()
    },
    onTriggerEmpty: function() {}
}), Ext.define("SYNO.SDS.Drive.MenuToolbarMgr", {
    extend: "Ext.Component",
    constructor: function(e) {
        this.appWindow = e.appWindow, this.callParent(arguments), this.onRegEvent()
    },
    onRegEvent: function() {
        this.addEvents("nodeselectchange", "synctoolbarbtn"), this.mon(this, "synctoolbarbtn", this.onUpdateToolbarBtnWrap, this, {
            buffer: 80
        });
        var e = this.appWindow.getEventMgr();
        this.mon(e, {
            pathchange: this.fireUpdateToolbarBtnEvent.bind(this),
            nodeselectchange: this.fireUpdateToolbarBtnEvent.bind(this)
        }), SYNO.SDS.Drive.WindowHelper.isPublicShare() || (this.mon(e, {
            categorychange: this.fireUpdateToolbarBtnEvent.bind(this)
        }), this.mon(SYNO.SDS.Drive.Mgr.FileClipboard, "clean", this.fireUpdateToolbarBtnEvent.bind(this)))
    },
    fireUpdateToolbarBtnEvent: function() {
        this.fireEvent("synctoolbarbtn")
    },
    onUpdateToolbarBtnWrap: function() {
        window.requestAnimationFrame(this.onUpdateToolbarBtn.bind(this))
    },
    onUpdateToolbarBtn: function() {
        var e = this.appWindow.getDrivePanel().getActionTBar(),
            t = this.appWindow.getAction().getTargets();
        if (SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var i = new Ext.data.JsonReader({
                id: "file_id",
                fields: SYNO.SDS.Drive.ViewStore.Node.prototype.getReaderFields()
            });
            t = [i.extractData([window.getDriveFile()], !0)[0]]
        }
        if (Ext.each(e.items.items, function(e) {
                var i = this.appWindow.getAction().ActionPrivChecker.check(e.itemId, t, "toolbar");
                i.display ? (i.enable ? e.enable() : e.disable(), e.show()) : e.hide()
            }, this), !SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var n = this.onUpdateMenuBtn("menu_toolbar", !0);
            this.appWindow.getDrivePanel().getActionTBar().get("action").setDisabled(!n), SYNO.SDS.Drive.Define.Info.disabled_all_sharing && this.appWindow.getDrivePanel().getActionTBar().get("share").setVisible(!1)
        }
        this._onUpdateHotKeyMap()
    },
    onUpdateMenuBtn: function(e, t) {
        var i = this.appWindow.getMenu(),
            n = e || i.getType(),
            o = i.getAction().getTargets();
        Ext.each(i.items.items, function(e) {
            e.result = i.getAction().ActionPrivChecker.check(e.itemId, o, n), t || (e.result.display ? (e.result.enable ? e.enable() : e.disable(), e.show()) : e.hide())
        }, this);
        var r = this._showMenuItems(o, i.items.items, t);
        return !t && i.isVisible() && (r ? i.doLayout() : i.hide()), r
    },
    _showMenuItems: function(e, t, i) {
        var n = this.appWindow.getNavigation().getCategory(),
            o = {
                count: 0
            };
        return i ? this.appWindow.getEventMgr().fireEvent("countdrivemenu", t, n, e, o) : (this.appWindow.getEventMgr().fireEvent("beforeshowdrivemenu", t, n, e), SYNO.SDS.Drive.MenuUtils.onShowHideMenu(t)), o.count > 0 || t.some(function(e) {
            return !(e instanceof Ext.menu.Separator) && e.result && e.result.display && e.result.enable
        })
    },
    _onUpdateHotKeyMap: function() {
        var e = this.appWindow.getMenu(),
            t = this.appWindow.getDrivePanel().getConfig();
        Ext.each(e.items.items, function(e) {
            Ext.isDefined(t[e.itemId]) && (t[e.itemId] = !e.disabled)
        }, this)
    }
}), Ext.define("SYNO.SDS.Drive.Chat.Binding.Panel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.file_id = e.file_id, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            padding: 0,
            layout: {
                type: "vbox",
                pack: "start",
                align: "stretch"
            },
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-d-chat-binding-desc",
                value: SYNO.SDS.Drive._T("chat", "binding_desc")
            }, {
                xtype: "container",
                layout: {
                    type: "vbox",
                    pack: "start",
                    align: "stretch"
                },
                items: [this.getSearchField()]
            }, this.getGrid(), this.getSuperBox()]
        };
        return Ext.apply(t, e)
    },
    getSearchField: function() {
        return this.filter || (this.filter = new SYNO.ux.TextFilter({
            store: this.getStore(),
            queryDelay: 10,
            localFilter: !0,
            triggerConfig: {
                tag: "button",
                type: "button",
                cls: "x-form-trigger syno-ux-textfilter-trigger",
                "aria-label": _JSLIBSTR("common", "clear_input")
            },
            localFilterField: [{
                scope: this,
                fn: function(e) {
                    var t = this.getSearchField().getValue().toLowerCase();
                    return e.get("name").toLowerCase().indexOf(t) > -1
                }
            }]
        }))
    },
    getStore: function() {
        return this.store || (this.store = new SYNO.API.Store({
            pruneModifiedRecords: !0,
            autoLoad: !0,
            autoDestroy: !0,
            proxy: new SYNO.API.Proxy(SYNO.SDS.Drive.WebAPIDesc.list_chat_channels),
            baseParams: {
                path: SYNO.SDS.Drive.Utils.getPathId(this.file_id)
            },
            sortInfo: {
                field: "name",
                direction: "asc"
            },
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: null,
                id: "channel_id"
            }, [{
                name: "channel_id"
            }, {
                name: "name",
                convert: function(e, t) {
                    return SYNO.SDS.Drive.Utils.getChannelName(t.channel_id, e)
                }
            }, {
                name: "enable"
            }]),
            createSortFunction: function(e, t) {
                if ("name" !== e) return SYNO.API.Store.superclass.createSortFunction.apply(this, arguments);
                t = t || "asc";
                var i = "DESC" === t.toUpperCase() ? -1 : 1;
                return function(t, n) {
                    var o = String(t.data[e]),
                        r = String(n.data[e]);
                    return i * o.localeCompare(r)
                }
            },
            listeners: {
                scope: this,
                beforeload: this.onBeforeLoad,
                load: this.onLoadStore,
                exception: this.onExceptionStore
            }
        }))
    },
    onBeforeLoad: function(e, t) {
        if (0 === e.getTotalCount()) return this.findWindow().setStatusBusy(), !0;
        e.filter("name", this.getSearchField().getValue(), !0, !1, !1)
    },
    onLoadStore: function(e, t) {
        this.findWindow().clearStatusBusy(), this.getStore().each(function(e) {
            if (e.get("enable")) {
                var t = this.getSuperBox();
                t.addItem({
                    channel_id: e.id,
                    name: e.data.name
                }), 1 === t.getCount() && (t.show(), this.doLayout())
            }
        }, this)
    },
    onExceptionStore: function(e, t, i, n, o, r) {
        this.findWindow().clearStatusBusy(), this.findWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(o), function() {
            this.findWindow().close()
        }, this)
    },
    getGrid: function() {
        var e = new SYNO.ux.EnableColumn({
            header: SYNO.SDS.Drive._T("chat", "binding"),
            dataIndex: "enable",
            width: 150,
            align: "center",
            menuDisabled: !0,
            enableFastSelectAll: !0,
            sortable: !1,
            listeners: {
                scope: this,
                click: function(e, t, i, n, o) {
                    var r = t.store.getAt(i),
                        a = this.getSuperBox();
                    r.get("enable") ? (a.addItem({
                        channel_id: r.id,
                        name: r.data.name
                    }), 1 === a.getCount() && (a.show(), this.doLayout())) : (a.preventMultipleRemoveEvents = !0, a.items.each(function(e) {
                        if (r.id === e.value) return e.preDestroy(!0), !1
                    }), 0 === a.getCount() && (a.hide(), this.doLayout()), a.preventMultipleRemoveEvents = !1)
                },
                selectall: function(e, t) {
                    var i = this.getSuperBox(),
                        n = 0 === i.getCount(),
                        o = function(e) {
                            e.get("enable") ? (n && (i.show(), this.doLayout(), n = !1), i.addItem({
                                channel_id: e.id,
                                name: e.data.name
                            })) : i.items.each(function(t) {
                                if (e.id === t.value) return t.preDestroy(!0), !1
                            })
                        }.bind(this);
                    i.preventMultipleRemoveEvents = !0, t ? Ext.each(this.getStore().getModifiedRecords(), o) : this.getStore().each(o), 0 === i.getCount() && (i.hide(), this.doLayout()), i.preventMultipleRemoveEvents = !1
                }
            }
        });
        return this.grid || (this.grid = new SYNO.ux.GridPanel({
            enableHdMenu: !1,
            flex: 1,
            margins: {
                top: 8,
                bottom: 0,
                left: 0,
                right: 0
            },
            viewConfig: {
                forceFit: !0,
                markDirty: !1,
                deferEmptyText: !1,
                emptyText: SYNO.SDS.Drive._T("chat", "no_channel")
            },
            autoExpandColumn: "name",
            sm: new Ext.grid.RowSelectionModel({
                listeners: {
                    beforerowselect: function() {
                        return !1
                    }
                }
            }),
            plugins: [e],
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !0,
                    align: "left",
                    sortable: !0
                },
                columns: [{
                    id: "name",
                    header: SYNO.SDS.Drive._T("chat", "channel_name"),
                    dataIndex: "name",
                    width: 293,
                    renderer: function(e, t) {
                        var i = Ext.util.Format.htmlEncode(e);
                        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
                    }
                }, e]
            }),
            store: this.getStore(),
            listeners: {
                viewready: function(e) {
                    e.getView().updateScroller()
                }
            }
        }))
    },
    getSuperBox: function() {
        return this.superbox || (this.superbox = new SYNO.ux.SuperBoxSelect({
            removeValuesFromStore: !1,
            hidden: !0,
            hideLabel: !0,
            hideTrigger: !0,
            typeAhead: !1,
            allowAddNewData: !1,
            allowDeleteData: !0,
            addNewDataOnBlur: !1,
            allowQueryAll: !1,
            displayField: "name",
            valueField: "channel_id",
            store: this.getStore(),
            mode: "local",
            listeners: {
                scope: this,
                removeitem: function(e, t, i) {
                    i.set("enable", !1), 0 === e.getCount() && (e.hide(), this.doLayout())
                },
                render: {
                    single: !0,
                    fn: function(e) {
                        e.setReadOnly(!0), e.outerWrapEl.addClass("syno-d-chat-binding-superbox")
                    }
                }
            }
        }))
    },
    getParams: function() {
        var e = [],
            t = this.getStore().getModifiedRecords();
        return Ext.each(t, function(t) {
            e.push({
                channel_id: t.id,
                action: t.data.enable ? "add" : "delete"
            })
        }), {
            path: SYNO.SDS.Drive.Utils.getPathId(this.file_id),
            channel_ids: e
        }
    },
    isDirty: function() {
        return this.getStore().getModifiedRecords().length > 0
    }
}), Ext.define("SYNO.SDS.Drive.Chat.Binding.Window", {
    extend: "SYNO.SDS.Drive.AddEditWindow",
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        this.owner = e.owner, this.file_id = e.file_id;
        var t = {
            title: SYNO.SDS.Drive._T("chat", "binding_title"),
            width: 440,
            height: 527,
            layout: "fit",
            items: this.getFormPanel(e)
        };
        return Ext.apply(t, e)
    },
    onEnter: function(e, t) {
        var i = t.getTarget();
        i && Ext.fly(i).is("input") || this.callParent(arguments)
    },
    getFormPanel: function(e) {
        return this.formpanel || (this.formpanel = new SYNO.SDS.Drive.Chat.Binding.Panel(e))
    },
    isValid: function() {
        return !0
    },
    isDirty: function() {
        return this.getFormPanel().isDirty()
    },
    getParams: function() {
        return this.getFormPanel().getParams()
    },
    onAction: function(e) {
        this.findAppWindow().getAction().setChatChannel(e, this.onApplyCb, this)
    },
    onApplyDone: function(e, t, i) {
        this.close()
    }
}), 

/**
 * @class SYNO.SDS.Drive.Application
 * @extends SYNO.SDS.Drive.AppInstance
 * SynologyDrive application class
 *
 */
Ext.define("SYNO.SDS.Drive.Application", {
    extend: "SYNO.SDS.Drive.AppInstance",
    appWindowName: "SYNO.SDS.Drive.MainWindow",
    constructor: function() {
        Ext.getBody().addClass(["syno-drive-theme"]), SYNO.SDS.Drive.Application.superclass.constructor.apply(this, arguments)
    },
    beforeOpen: function(e) {
        if (!SYNO.SDS.Drive.Application.superclass.beforeOpen.apply(this, arguments)) return !1;
        if (e.file_id) {
            var t = e.file_id,
                i = Ext.urlDecode(window.location.search.substring(1));
            delete e.file_id, SYNO.SDS.Drive.Utils.isEmpty(e) ? delete i.launchParam : i.launchParam = Ext.urlEncode(e);
            var n = window.location,
                o = "";
            n.hash && (o = n.hash), o = (o ? o + "&" : "#") + Ext.urlEncode({
                file_id: t
            });
            var r = Ext.urlAppend(String.format("{0}", "/" === n.pathname ? "/" : n.pathname), Ext.urlEncode(i), !1) + o;
            if (!window.history || !window.history.replaceState) return window.location.href = r, !1;
            window.history.replaceState("", document.title, r)
        }
        return !0
    }
}), Ext.define("SYNO.SDS.Drive.PublicApplication", {
    extend: "SYNO.SDS.Drive.Application"
}), Ext.define("SYNO.SDS.Drive.MainWindow", {
    extend: "SYNO.SDS.Drive.PrototypeWindow",
    hasClipboard: !0,
    constructor: function(e) {
        if (Ext.isWebKit ? window.name || (window.name = "SYNOSDSDriveApplication") : window.name && (window.name = ""), SYNO.SDS.Drive.Window = this, SYNO.SDS.Drive.Utils.isAppAuthorized() && SYNO.SDS.Drive.Utils.jsLoad(), this.eventmgr = new SYNO.SDS.Drive.EventMgr({
                appWindow: this
            }), this.storemgr = new SYNO.SDS.Drive.StoreMgr({
                appWindow: this
            }), this.viewmodemgr = new SYNO.SDS.Drive.ViewModeMgr({
                appWindow: this
            }), this.history = new SYNO.SDS.Drive.Mgr.History({
                appWindow: this
            }), this.imagequeue = new SYNO.SDS.Drive.ImageLoaderQueue({
                appWindow: this
            }), this.taskmgr = new SYNO.SDS.Drive.TaskMgr({
                appWindow: this
            }), this.statusmgr = new SYNO.SDS.Drive.MenuToolbarMgr({
                appWindow: this
            }), this.downloadmgr = new SYNO.SDS.Drive.HybridShare.OffloadDownloader({
                appWindow: this
            }), this.plugin_menu = new SYNO.SDS.Drive.Mgr.Plugin({
                appWindow: this
            }), this.addEvents({
                beforedestroy: !0
            }), this.callParent([Ext.apply({
                cls: "syno-drive-win" + (SYNO.SDS.Drive.WindowHelper.isPublicShare() ? " syno-d-mgr-public" : "")
            }, e)]), this.onRegEvent(), !SYNO.SDS.Drive.WindowHelper.isPublicShare()) try {
            SYNO.SDS.BackgroundTaskMgr.pollingTask.stop()
        } catch (e) {}
    },
    getPlugin: function() {
        return this.plugin_menu
    },
    onRegEvent: function() {
        Ext.EventManager.on(window, "popstate", this.onHistoryChange, this), SYNO.SDS.Drive.WindowHelper.isPublicShare() || (Ext.EventManager.on(window, "hashchange", function(e) {
            if (history.state) return void this.setActiveItem(this.getWinPanel());
            this.onHashChange()
        }, this), this.mon(this.eventmgr, "envready", this.onEnvReady, this), this.mon(this.eventmgr, {
            scope: this,
            setnodetagdone: this.onSetNodeTagDone,
            setshortcutdone: this.onSetShortcutDone,
            deleteshortcutdone: this.onDeleteShortcutDone
        }), Ext.EventManager.on(this.el, "keypress", this.onDetectKeyPress, this), this.on("show", function() {
            this.getAction().preloadUniversalViewer()
        }, this))
    },
    onSetNodeTagDone: function(e) {
        this.showActionToastMsg(e ? "apply_label_succ" : "apply_label_fail")
    },
    onSetShortcutDone: function(e) {
        this.showActionToastMsg(e ? "add_star_succ" : "add_star_fail")
    },
    onDeleteShortcutDone: function(e) {
        this.showActionToastMsg(e ? "del_star_succ" : "del_star_fail")
    },
    onDetectKeyPress: function(e) {
        if (47 === e.getKey()) {
            e.preventDefault();
            var t = this.findAppWindow().getDrivePanel().getSearchField();
            t.showMenu(), t.getSearchPanel().focusKeywordInput()
        }
    },
    showActionToastMsg: function(e) {
        var t = this.getViewModeMgr().getViewMode();
        "menu_pathbar" !== SYNO.SDS.Drive.GetWindow().getMenu().getType() && "thumbnail" !== t && "tile" !== t && "snippet" !== t || SYNO.SDS.Drive.Utils.showToastMsg(this, SYNO.SDS.Drive._T("task", e), 3e3)
    },
    isObjectExist: function(e) {
        var t = this.findAppWindow().getStoreMgr().getActiveStore();
        if (Ext.isArray(e)) {
            for (var i = 0; i < e.length; i++)
                if (t.getById(e[i])) return !0;
            return !1
        }
        return !!t.getById(e)
    },
    onBeforeDestroy: function() {
        this.history.destroy(), SYNO.SDS.Drive.MainWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onOpen: function(e) {
        if (this.openParams = e, this.callParent(arguments), SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile) "file" !== window.getDriveFile().type && (this.onSetHistoryCategoryAndPath("node"), window.history && window.history.replaceState && window.history.replaceState({
            category: "node"
        }, document.title));
        else {
            var t = SYNO.SDS.Drive.Utils.getHashParam() || {};
            this.onHashChange(t, !0)
        }
    },
    onSetHistoryCategoryAndPath: function(e, t, i) {
        var n = this.findAppWindow().getNavigation();
        this.history.onPause(), n.setCategoryAndPath(e, t, Ext.apply(i || {}, {})), this.history.onResume()
    },
    onInitCategory: function(e) {
        if (!this.initCategory) {
            if (!e) {
                var t = SYNO.SDS.Drive.Utils.getHashParam() || {};
                e = this.openParams.category || t.category
            }
            if (!SYNO.SDS.Drive.Define.Info.ready) return void this.mon(this.eventmgr, "envready", this.onInitCategory.bind(this, e), this);
            this.initCategory = !0, e = SYNO.SDS.Drive.Define.Info.is_home ? Ext.isEmpty(e) ? "node" : e : "node" === e || Ext.isEmpty(e) ? "team_folder" : e, this.onSetHistoryCategoryAndPath(e), window.history && window.history.replaceState && window.history.replaceState({
                category: e
            }, document.title)
        }
    },
    onEnvReady: function() {
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            var e = this.getCategoryPanel();
            SYNO.SDS.Drive.Define.Info.is_home || e.categoryNode.removeChild(e.driveNode), SYNO.SDS.Drive.Define.Info.has_backup || e.categoryNode.removeChild(e.backupNode)
        }
        SYNO.SDS.Drive.Define.Info.is_home && this.findAppWindow().getAction().getMyDrive(function(e) {
            e || (SYNO.SDS.Drive.Define.Info.is_home = !1)
        }), this.onShowPromotionWindows(), this.isBeta = SYNO.SDS.Drive.Define.Info.beta
    },
    onHistoryChange: function(e) {
        if (e && history.state && !SYNO.SDS.Utils.Logout.logoutTriggered) {
            this.history.onPause(), this.findAppWindow().getAction().closeUniversalViewer();
            var t = SYNO.Util.copy(history.state),
                i = t.category,
                n = t.paths,
                o = t.options;
            switch (i) {
                case "search":
                    o && o.params && (this.getDrivePanel().getSearchField().getSearchPanel().setValue(o.params), this.onSetHistoryCategoryAndPath(i, n, o));
                    break;
                case "recycle":
                    o && o.recycle_mode && this.getDrivePanel().getRecycleBtn().setCheckedId(o.recycle_mode), this.onSetHistoryCategoryAndPath(i, n, o);
                    break;
                case "shared_with_me":
                case "sharing_to_others":
                case "backup":
                case "node":
                case "team_folder":
                case "recent":
                case "starred":
                    this.onSetHistoryCategoryAndPath(i, n, o);
                    break;
                default:
                    if (-1 === this.getCategoryPanel().getStore().indexOfId("label:" + i)) return;
                    this.onSetHistoryCategoryAndPath(i, n, o)
            }
            this.history.onResume()
        }
    },
    onHashChange: function(e, t) {
        if (!SYNO.SDS.Drive.WindowHelper.isPublicShare()) {
            e = e || SYNO.SDS.Drive.Utils.getHashParam() || {};
            var i = e.category;
            if (e.file_id && "sharing" === e.action) {
                this.onInitCategory();
                var n = function() {
                    new SYNO.SDS.Drive.Share.Window({
                        path: SYNO.SDS.Drive.Utils.getPathId(e.file_id),
                        owner: this.findAppWindow(),
                        share_user: e.user,
                        listeners: {
                            scope: this,
                            load: function(t) {
                                t && this.findAppWindow().getAction().onGotoPath(e.file_id, function() {
                                    return !0
                                })
                            }
                        }
                    }).show(), this.onCleanHash()
                }.bind(this);
                SYNO.SDS.Drive.Define.Info.settingready ? n() : this.mon(this.getEventMgr(), "settingready", function() {
                    n()
                }, this, {
                    single: !0
                })
            } else if (e.file_id) this.mainPanel && this.mainPanel.getActivePanel().getEl().mask(_T("common", "loading"), "x-mask-loading"), this.getAction().onGotoPath(e.file_id, function(t, i, n, o, r, a) {
                return this.mainPanel && this.mainPanel.getActivePanel().getEl().unmask(), !t || Ext.isBoolean(i.has_fail) && i.has_fail ? void this.onGotoPathError(i, e) : (this.setActiveItem(this.getWinPanel()), this.findAppWindow().getNavigation().setCategoryAndPath(n, r, null, a), !1)
            }, this);
            else if (i) {
                if (this.onInitCategory(), this.onCleanHash(), "search" === i) return;
                this.findAppWindow().getNavigation().setCategoryAndPath(i)
            } else t && window.location.hash ? (this.onInitCategory(), this.onCleanHash()) : this.onInitCategory()
        }
    },
    setActiveItem: function(e) {
        var t = this.layout;
        t.activeItem !== e && t.setActiveItem(e)
    },
    onCleanHash: function() {
        window.history && window.history.pushState ? window.history.pushState("", document.title, window.location.pathname + window.location.search) : window.location.hash = ""
    },
    onShowPromotionWindows: function() {
        this.onShowOfficeIntro() || this.onShowPromptToast()
    },
    onShowOfficeIntro: function() {
        if (!_S("is_admin")) return !1;
        if (SYNO.SDS.Drive.Utils.hasOffice()) return !1;
        if (this.appInstance.getUserSettings("hide_office_intro_prompt")) return !1;
        var e = new SYNO.SDS.Drive.OfficeIntro.Window({
            owner: this,
            module: this
        });
        return this.mon(e, "close", this.onShowPromptToast, this), e.show(), !0
    },
    onShowPromptToast: function() {
        SYNO.SDS.Drive.WindowHelper.isPublicShare() || (_S("is_admin") || SYNO.SDS.Drive.Define.Info.enable_non_admin_user_sync) && (this.appInstance.getUserSettings("hide_prompt_toast") || this.toastMessage && this.toastMessage.isVisible() || (this.toastMessage || (this.toastMessage = new SYNO.SDS.Drive.DownloadClient.PromptToast({
            renderTo: Ext.getBody(),
            alignTargetEl: Ext.getBody(),
            floating: {
                zindex: parseInt(this.getEl().getStyle("z-index"))
            },
            appWindow: this
        }), this.addManagedComponent(this.toastMessage)), this.toastMessage.showPanel()))
    },
    onHidePromptToast: function() {
        this.toastMessage && this.toastMessage.hidePanel(!1)
    },
    onGotoPathError: function(e, t) {
        var i = 1e3;
        switch (e = SYNO.API.Util.GetFirstError(e), e && (i = e.code), i) {
            case 1002:
                this.layout.setActiveItem(this.getPermPanel()), this.getPermPanel().onUpdate("NO_PERM");
                break;
            case 1003:
                this.layout.setActiveItem(this.getPermPanel()), this.getPermPanel().onUpdate("NON_EXIST");
                break;
            default:
                this.onInitCategory(), this.findAppWindow().getMsgBox().alert("", SYNO.SDS.Drive.Utils.getErrorStr(i)), this.onCleanHash()
        }
    },
    getMainPanel: function() {
        var e = [];
        SYNO.SDS.Drive.WindowHelper.isPublicShare() || e.push(new Ext.Container({
            xytpe: "conatiner",
            cls: "syno-d-viewpanel-category-ct",
            region: "west",
            owner: this,
            width: 240,
            minWidth: 240,
            maxWidth: 320,
            split: !0,
            border: !1,
            layout: "fit",
            items: [this.getCategoryPanel()],
            listeners: {
                scope: this,
                afterlayout: {
                    single: !0,
                    buffer: 80,
                    fn: function() {
                        this.mon(this.getEl(), "mouseenter", function() {
                            this.getCategoryPanel().getTreeEl().removeClass("syno-d-hide-scrollbar")
                        }, this), this.mon(this.getEl(), "mouseleave", function() {
                            this.getCategoryPanel().getTreeEl().addClass("syno-d-hide-scrollbar")
                        }, this)
                    }
                }
            }
        })), SYNO.SDS.Drive.WindowHelper.isPublicShare() && window.getDriveFile && "file" === window.getDriveFile().type ? e.push(this.getFilePanel()) : e.push(this.getDrivePanel());
        var t = [{
            xtype: "container",
            cls: "syno-d-main-panel",
            layout: "border",
            region: "center",
            border: !1,
            margins: {
                top: SYNO.SDS.Drive.WindowHelper.isPublicShare() ? 14 : 12,
                right: 16,
                bottom: SYNO.SDS.Drive.WindowHelper.isPublicShare() ? 36 : 12,
                left: 0
            },
            items: e
        }];
        return SYNO.SDS.Drive.WindowHelper.isPublicShare() && t.push({
            hidden: !0,
            xtype: "box",
            region: "south",
            cls: "syno-d-public-logo",
            html: SYNO.SDS.Drive._T("drive", "displayname")
        }), {
            xtype: "container",
            layout: "border",
            region: "center",
            items: t
        }
    },
    getDrivePanel: function() {
        return this.mainPanel || (this.mainPanel = new SYNO.SDS.Drive.ViewPanel.MainPanel({
            boxMinWidth: 12,
            boxMinHeight: 1,
            region: "center",
            owner: this
        })), this.mainPanel
    },
    getFilePanel: function() {
        return this.filePanel || (this.filePanel = new SYNO.SDS.Drive.FilePanel({
            region: "center",
            owner: this
        })), this.filePanel
    },
    getCategoryPanel: function() {
        return SYNO.SDS.Drive.WindowHelper.isPublicShare() || this.list || (this.list = new SYNO.SDS.Drive.ViewPanel.CategoryTreePanel({
            owner: this
        })), this.list
    },
    getPanel: function() {
        return this.getDrivePanel().getActivePanel()
    },
    getAction: function() {
        return this.actionmgr ? this.actionmgr : this.actionmgr = new SYNO.SDS.Drive.Mgr.Action({
            appWindow: this
        })
    },
    getNavigation: function() {
        return this.navigation ? this.navigation : (this.navigation = new SYNO.SDS.Drive.Comp.Navigation({
            appWindow: this
        }), this.addManagedComponent(this.navigation), this.navigation)
    },
    GetOneSeleted: function() {
        return this.getPanel().getSelections()[0]
    },
    GetSeletions: function() {
        return this.getPanel().getSelections()
    },
    GetSeletionIds: function() {
        var e = this.getPanel().getSelections(),
            t = [];
        return Ext.each(e, function(e) {
            t.push(e.get("file_id"))
        }), t
    },
    getMenu: function() {
        return this.action_menu ? this.action_menu : this.action_menu = new SYNO.SDS.Drive.Mgr.Menu({
            appWin: this.findAppWindow()
        })
    },
    hasSeletion: function() {
        return this.GetSeletions().length > 0
    }
});
