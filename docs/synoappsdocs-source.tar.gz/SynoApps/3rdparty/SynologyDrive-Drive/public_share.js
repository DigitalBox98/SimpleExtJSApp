/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.DrivePublicShare"), window._S = function(S) {
    return SYNO.SDS.Session[S]
}, _TT = function(S, i, e) {
    try {
        return SYNO.SDS.Strings[S][i][e]
    } catch (S) {
        return ""
    }
}, window._D || (window._D = function() {
    return ""
}), SYNO.SDS.appendMissingCSSFiles = function(S) {
    Ext.each(S, function(S) {
        var i = !1;
        if (Ext.each(document.getElementsByTagName("link"), function(e) {
                if (0 < e.href.indexOf(S)) return i = !0, !1
            }), !i) {
            var e = document.createElement("link");
            e.setAttribute("rel", "stylesheet"), e.setAttribute("type", "text/css"), e.setAttribute("href", S), document.getElementsByTagName("head")[0].appendChild(e)
        }
    })
}, SYNO.SDS.initData = function(S) {
    var i, e = Ext.urlDecode(window.location.search.substr(1)),
        n = _S("lang");
    if (Ext.isNumber(S) && S > 0) return void SYNO.SDS.initData.defer(S, this);
    i = e.jsDebug ? {
        action: "debug"
    } : null, SYNO.API.Request({
        api: "SYNO.Core.Desktop.Initdata",
        method: "get",
        params: i,
        version: 1,
        callback: function(S, i, e, t) {
            function s() {
                Ext.isDefined(window._loadSynoLang) && window._loadSynoLang(), i.Session.SynoToken = _S("SynoToken"), SYNO.SDS.Session = Ext.apply(SYNO.SDS.Session, i.Session), SYNO.SDS.Config.JSConfig = i.JSConfig, SYNO.SDS.Strings = i.Strings, SYNO.SDS.initUserSettings = i.UserSettings, SYNO.SDS.initGroupSettings = i.GroupSettings, SYNO.SDS.UrlTag = i.UrlTag, SYNO.SDS.AppPrivilege = i.AppPrivilege, SYNO.SDS.ServiceStatus = i.ServiceStatus, SYNO.SDS.UIFeatures.IconSizeManager.enableHDDisplay(i.SynohdpackStatus), SYNO.SDS.init(), SYNO.SDS.DrivePublicShare.initWin(), n && _S("lang") !== n && Ext.form.VTypes.reloadVtypeStr(), SYNO.SDS.appendMissingCSSFiles(i.CSSFiles)
            }
            if (!S) return SYNO.Debug("SYNO.SDS.initData fail", arguments), void SYNO.SDS.initData(3e3);
            switch (i.Session.lang) {
                case "cht":
                case "chs":
                case "jpn":
                case "krn":
                    Ext.getBody().addClass("syno-cjk")
            }
            n && i.Session.lang !== n ? SYNO.SDS.Utils.loadUIStrings(i.Session.lang, i.Session.fullversion, s) : s()
        }
    })
}, SYNO.SDS.init = function() {
    var S = Ext.urlDecode(location.search.substr(1)),
        i = S.jsDebug,
        e = S.report;
    if (Ext.isDefined(e)) return void(window.location = Ext.urlAppend("/dar/" + e));
    Ext.isDefined(i) && (SYNO.SDS.JSDebug = i), SYNO.SDS.initFramework(), window.getDriveTexts && (SYNO.SDS.Strings["SYNO.SDS.Drive.PublicApplication"] = SYNO.SDS.Strings["SYNO.SDS.Drive.MainWindow"] = SYNO.SDS.Strings["SYNO.SDS.Drive.Application"] = window.getDriveTexts()), window.getOfficeTexts && (SYNO.SDS.Strings["SYNO.SDS.Office.AppInstance"] = window.getOfficeTexts()), SYNO.SDS.Desktop = new SYNO.SDS._StandaloneDesktop, SYNO.SDS.HandleTimeoutTask = new SYNO.SDS.interval.Task
}, SYNO.SDS.initFramework = function() {
    if (SYNO.SDS.LaunchTime = (new Date).getTime(), SYNO.SDS.JSLoad.init(), SYNO.SDS.UserSettings = new SYNO.SDS._UserSettings, Ext.isDefined(SYNO.SDS.JSDebug) && (SYNO.Debug("JS Loading Caching Disabled. (append _dc to js link)"), "all" === SYNO.SDS.JSDebug)) {
        var S = SYNO.SDS.Config.FnMap;
        SYNO.Debug("JS Dynamic Loading Disabled.");
        for (var i in S) S.hasOwnProperty(i) && SYNO.SDS.JSLoad(i)
    }
}, SYNO.SDS.DrivePublicShare.initWin = function() {
    SYNO.SDS.Session.standalone = !0, Ext.isFunction(window.getDriveFile) && (window.getDriveFile() ? SYNO.SDS.Session.standaloneAppName = "SYNO.SDS.Drive.PublicApplication" : SYNO.SDS.Session.standaloneAppName = "SYNO.SDS.Drive.BasicInstance"), SYNO.SDS.InitUtils.initQuickTips().initDragDrop().disableIESelect().disableSelectAllKeyboard().disableRightClick().defaultCSSSelectors(), _S("isLogined") && SYNO.SDS.InitUtils.handleServerError(), SYNO.SDS.UIFeatures.IconSizeManager.addHDClsAndCSS(!0), SYNO.SDS.AppLaunch(SYNO.SDS.Session.standaloneAppName)
}, Ext.define("SYNO.SDS.DrivePublicShare.SSOUtils", {
    singleton: !0,
    isCheck: function() {
        return !_S("isLogined") && window.getDriveErrCode && 1002 === window.getDriveErrCode()
    },
    init: function() {
        SYNO.SDS.SSOUtils.init(this.isCheck() ? this.onSSOCallback : Ext.emptyFn, this)
    },
    onSSOCallback: function(S) {
        "login" === S.status && S.access_token && 40 === S.access_token.length && SYNO.SDS.JSLoad("SYNO.SDS.Drive.Override", function() {
            SYNO.SDS.Utils.Logout.redirect(!1)
        })
    }
}), Ext.onReady(function() {
    var S = function() {
            return SYNO.SDS.Packages = new SYNO.SDS._Packages, SYNO.SDS.Packages.getData()
        },
        i = function(i) {
            SYNO.SDS.StatusNotifier = new SYNO.SDS._StatusNotifier({}), SYNO.SDS.WindowMgr = new SYNO.SDS._WindowMgr, SYNO.SDS.FocusMgr = new SYNO.SDS._FocusMgr, SYNO.SDS.AppMgr = new SYNO.SDS._AppMgr, SYNO.SDS.GestureMgr = new SYNO.SDS._GestureMgr;
            var e = Ext.urlDecode(location.search.substr(1)),
                n = e.jsDebug;
            if (Ext.isDefined(n) && (SYNO.SDS.JSDebug = n), _S("isLogined")) {
                if (SYNO.SDS.isCompatibleMode && SYNO.SDS.isCompatibleMode() && SYNO.SDS._Packages) return void S().then(SYNO.SDS.initData, SYNO.SDS.initData);
                SYNO.SDS.initData()
            } else SYNO.SDS.JSLoad.init(), SYNO.SDS.AppPrivilege = {}, SYNO.SDS.ServiceStatus = {}, SYNO.SDS.isCompatibleMode && SYNO.SDS.isCompatibleMode() && SYNO.SDS._Packages && (SYNO.SDS.Packages = new SYNO.SDS._Packages, Ext.isDefined(i.pkgStatus) && (SYNO.SDS.Packages._packages = i.pkgStatus)), SYNO.SDS.Desktop = new SYNO.SDS._StandaloneDesktop, SYNO.SDS.Strings = SYNO.SDS.Strings || {}, SYNO.SDS.Strings["SYNO.SDS.Drive.PublicApplication"] = SYNO.SDS.Strings["SYNO.SDS.Drive.MainWindow"] = SYNO.SDS.Strings["SYNO.SDS.Drive.Application"] = window.getDriveTexts(), SYNO.SDS.Strings["SYNO.SDS.Office.AppInstance"] = window.getOfficeTexts(), SYNO.SDS.DrivePublicShare.initWin(), SYNO.SDS.Session.user = String.format(_TT("SYNO.SDS.Drive.Application", "common", "guest"), ""), SYNO.SDS.Session.anonymous = !0, SYNO.SDS.UserSettings = new SYNO.SDS._UserSettings
        };
    Ext.QuickTips.init(), Ext.isIE9m && !Ext.isIE9 || Ext.QuickTips.getQuickTip().getEl().disableShadow(), Ext.ns("SYNO.SDS.Session");
    var e, n = Ext.urlDecode(window.location.search.substr(1));
    e = n.jsDebug ? {
        action: "debug"
    } : null, SYNO.SDS.InitUtils.initAPIManagerPromise().then(function() {
        SYNO.API.Request({
            api: "SYNO.SynologyDrive.Shard",
            version: 1,
            method: "init",
            params: e,
            scope: this,
            callback: function(S, e) {
                if (!S) return void SYNO.Debug("Can't init data");
                Ext.apply(SYNO.SDS.Session, e.Session), _S("isLogined") || (SYNO.SDS.Config.JSConfig = e.JSConfig), SYNO.SDS.DrivePublicShare.SSOUtils.init(), i(e)
            }
        })
    })
});