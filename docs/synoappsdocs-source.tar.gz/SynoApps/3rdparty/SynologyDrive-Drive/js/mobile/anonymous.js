! function() {
    _mr.getButtonsConfig = function() {
        var t = this.getState().btns;
        if (Array.isArray(t) && !(t.length < 2)) return [{
            text: t[0],
            href: this.getAppLink()
        }, {
            text: t[1],
            handler: this.logout.bind(this, this.isOffice())
        }]
    }, _mr.render()
}();