_mr.getIconSrc = function() {
    return this.getAssetPath() + "/_Common/icon_not_exist.png"
}, _mr.render();