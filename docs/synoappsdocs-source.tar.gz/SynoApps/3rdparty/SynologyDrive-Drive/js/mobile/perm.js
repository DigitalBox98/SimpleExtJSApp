! function() {
    _mr.getButtonsConfig = function() {
        var t = this.getState().btns;
        if (Array.isArray(t) && !(t.length < 2)) {
            var e = [];
            return !1 !== this.getState().show_request_access && e.push({
                text: t[0],
                handler: function(t) {
                    t.preventDefault(), this._onRequestAccess()
                }.bind(this)
            }), e.push({
                text: t[1],
                handler: this.logout.bind(this)
            }), e
        }
    }, _mr._onRequestAccess = function() {
        this.requestWebAPI({
            api: "SYNO.SynologyDrive.Files",
            method: "request_access",
            version: 1,
            params: {
                path: "link:" + this.getState().permanent_link
            }
        }, function(t) {
            t && this._switchToSentPage()
        }.bind(this))
    }, _mr._switchToSentPage = function() {
        var t = this.getState().i18n;
        this.getTitleElement().textContent = t.title, document.title = t.title, this.getIconImg().src = this.getAssetPath() + "/_Common/icon_request_send.png", this.getDescElement().textContent = t.sent.replace("<br><br>", ""), this.getActionContainer().style.visibility = "hidden"
    }, _mr.getIconSrc = function() {
        return this.getAssetPath() + "/_Common/icon_no_permission.png"
    }, _mr.render = function() {
        var t = document.createElement("b");
        t.textContent = this.getState().account;
        var e = document.createElement("span");
        e.appendChild(t);
        var n = this.getDescElement();
        n.innerHTML = n.innerHTML.replace("{0}", e.innerHTML), _mr.constructor.prototype.render.call(this)
    }, _mr.render()
}();