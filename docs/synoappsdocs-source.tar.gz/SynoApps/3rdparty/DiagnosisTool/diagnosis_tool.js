/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.DiagnosisTool");

/**
 * @class SYNO.SDS.DiagnosisTool.Application
 * @extends SYNO.SDS.AppInstance
 * DiagnosisTool application class
 *
 */
SYNO.SDS.DiagnosisTool.Application = Ext.extend(SYNO.SDS.AppInstance, {
    appWindowName: "SYNO.SDS.DiagnosisTool.MainWindow"
});
SYNO.SDS.DiagnosisTool.MainWindow = Ext.extend(SYNO.SDS.AppWindow, {
    constructor: function(a) {
        this.appInstance = a.appInstance;
        var b = this.fillConfig(a);
        SYNO.SDS.DiagnosisTool.MainWindow.superclass.constructor.call(this, b)
    },
    fillConfig: function(a) {
        this.panel = new SYNO.SDS.DiagnosisTool.MainForm({
            owner: this
        });
        var b = {
            layout: "fit",
            showHelp: false,
            maximizable: false,
            width: 550,
            height: 330,
            resizable: false,
            border: false,
            items: [this.panel]
        };
        Ext.apply(b, a);
        return b
    }
});
SYNO.SDS.DiagnosisTool.MainForm = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(a) {
        this.owner = a.owner;
        this.store = a.store;
        this.jsConfig = a.owner.jsConfig;
        this.cgiUrl = a.owner.jsConfig.jsBaseURL + "/packet_capture.cgi";
        var b = this.fillConfig(a);
        SYNO.SDS.DiagnosisTool.MainForm.superclass.constructor.call(this, b)
    },
    fillConfig: function(a) {
        var b = {
            trackResetOnLoad: true,
            border: false,
            synodefaults: {
                width: 200
            },
            labelWidth: 200,
            items: [{
                xtype: "compositefield",
                fieldLabel: "Output directory",
                items: [{
                    xtype: "syno_textfield",
                    disabled: true,
                    width: 200,
                    id: this.outputDirId = Ext.id(),
                    name: "output_dir",
                    value: "web"
                }, {
                    xtype: "syno_button",
                    text: "Choose",
                    scope: this,
                    handler: this.chooseOutputDir
                }]
            }, {
                xtype: "syno_combobox",
                indent: 1,
                name: "interface",
                fieldLabel: "Interface",
                value: "",
                store: [],
                listeners: {
                    scope: this,
                    afterrender: function() {
                        this.requestInterfaces()
                    }
                }
            }, {
                xtype: "syno_combobox",
                indent: 1,
                name: "filter",
                fieldLabel: "Filter",
                value: "all",
                store: [
                    ["all", "Capture all packets"],
                    ["dsm", "DSM Web UI"],
                    ["upnp", "UPnP"]
                ],
                listeners: {
                    scope: this,
                    select: this.filterSelectHandler
                }
            }, {
                xtype: "syno_textfield",
                indent: 1,
                disabled: true,
                name: "expression",
                fieldLabel: "Expression",
                value: ""
            }, {
                xtype: "syno_displayfield",
                height: 20
            }, {
                xtype: "buttongroup",
                defaultType: "syno_button",
                frame: false,
                columns: 3,
                items: [{
                    id: this.startButtonId = Ext.id(),
                    htmlEncode: false,
                    text: '<span class="green-status">Start capture</span>',
                    scope: this,
                    handler: this.startHandler
                }, {
                    id: this.stopButtonId = Ext.id(),
                    htmlEncode: false,
                    disabled: true,
                    text: '<span class="red-status">Stop</span>',
                    scope: this,
                    handler: this.stopHandler
                }, {
                    text: "Open output directory",
                    scope: this,
                    handler: this.openDirHandler
                }]
            }],
            listeners: {
                scope: this,
                afterrender: function() {
                    this.task = this.getPollingTask();
                    this.task.start()
                },
                beforedestroy: function() {
                    this.task.remove()
                }
            }
        };
        SYNO.LayoutConfig.fill(b);
        Ext.apply(b, a);
        return b
    },
    startHandler: function() {
        var a = this.addAjaxTask({
            method: "POST",
            single: true,
            autoJsonDecode: true,
            url: this.jsConfig.jsBaseURL + "/packet_capture.cgi",
            params: {
                output_dir: this.getOutputDir(),
                expression: this.getExpression(),
                "interface": this.getInterface(),
                action: "start"
            },
            success: function(b, c) {
                if (b.success === false) {
                    this.showError(b)
                }
                this.statusUpdater(b);
                this.pollingTask.start()
            },
            scope: this
        });
        a.start(true);
        this.pollingTask.stop();
        Ext.getCmp(this.startButtonId).disable()
    },
    stopHandler: function() {
        var a = this.addAjaxTask({
            method: "POST",
            single: true,
            autoJsonDecode: true,
            url: this.jsConfig.jsBaseURL + "/packet_capture.cgi",
            params: {
                action: "stop"
            },
            success: function(b, c) {
                this.statusUpdater(b);
                this.pollingTask.start()
            },
            scope: this
        });
        a.start(true);
        this.pollingTask.stop();
        Ext.getCmp(this.stopButtonId).disable()
    },
    getPollingTask: function() {
        if (undefined === this.pollingTask) {
            this.pollingTask = this.addAjaxTask({
                method: "POST",
                interval: 2000,
                autoJsonDecode: true,
                url: this.jsConfig.jsBaseURL + "/packet_capture.cgi",
                params: {
                    action: "status"
                },
                success: function(a, b) {
                    this.statusUpdater(a)
                },
                scope: this
            });
            this.pollingTask.start(true)
        }
        return this.pollingTask
    },
    statusUpdater: function(a) {
        if (a && Ext.isDefined(a.alive)) {
            if (a.alive === true) {
                Ext.getCmp(this.startButtonId).disable();
                Ext.getCmp(this.stopButtonId).enable()
            } else {
                Ext.getCmp(this.startButtonId).enable();
                Ext.getCmp(this.stopButtonId).disable()
            }
        }
    },
    chooseOutputDir: function() {
        var a = new SYNO.SDS.Utils.FileChooser.Chooser({
            owner: this.owner,
            superuser: true,
            folderToolbar: true,
            usage: {
                type: "chooseDir"
            },
            title: _T("common", "choose")
        }, true);
        a.mon(a, "choose", this.onChooserSelect, this);
        a.open()
    },
    onChooserSelect: function(c, b) {
        var a = b.path;
        if (a.length > 0 && a.substr(0, 1) === "/") {
            a = a.substr(1)
        }
        this.setOutputDir(a);
        c.close()
    },
    setOutputDir: function(a) {
        return Ext.getCmp(this.outputDirId).setValue(a)
    },
    getOutputDir: function() {
        return Ext.getCmp(this.outputDirId).getValue()
    },
    openDirHandler: function() {
        var a = this.getOutputDir();
        if (Ext.isEmpty(a)) {
            return
        }
        SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
            opendir: "/" + a
        })
    },
    getExpression: function() {
        return this.getForm().findField("expression").getValue()
    },
    setExpression: function(a) {
        return this.getForm().findField("expression").setValue(a)
    },
    getInterface: function() {
        return this.getForm().findField("interface").getValue()
    },
    loadInterfaces: function(b) {
        var a = this.getForm().findField("interface");
        if (!Ext.isArray(b) || b.length <= 0) {
            return
        }
        a.getStore().loadData(b);
        a.setValue(b[0])
    },
    filterSelectHandler: function(d, a, b) {
        var c = d.getValue();
        if (c === "all") {
            this.setExpression("")
        } else {
            if (c === "dsm") {
                this.setExpression("port 5000")
            } else {
                if (c === "upnp") {
                    this.setExpression("udp and port 1900")
                }
            }
        }
    },
    requestInterfaces: function() {
        var a = this.addAjaxTask({
            method: "POST",
            single: true,
            autoJsonDecode: true,
            url: this.jsConfig.jsBaseURL + "/packet_capture.cgi",
            params: {
                action: "list_interface"
            },
            success: function(b, c) {
                var d = [];
                if (!Ext.isArray(b.interfaces)) {
                    return
                }
                Ext.each(b.interfaces, function(f, e) {
                    if (f.status === "connected") {
                        d.push(f.id)
                    }
                }, this);
                if (d.length > 0) {
                    this.loadInterfaces(d)
                }
            },
            scope: this
        });
        a.start(true)
    },
    showError: function(a) {
        var b, c;
        if (a.success !== false) {
            return
        }
        if (!Ext.isObject(a.errno)) {
            return
        }
        b = a.errno;
        if (b.section && b.key) {
            c = _T(b.section, b.key)
        } else {
            if (b.msg) {
                c = b.msg
            }
        }
        if (c) {
            this.owner.getMsgBox().alert(this.owner.title, c)
        }
    }
});
