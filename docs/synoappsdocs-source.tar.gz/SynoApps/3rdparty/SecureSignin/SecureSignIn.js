Ext.namespace('SYNO.SDS.SecureSignIn');

// @define: SYNO.SDS.SecureSignIn.Instance
/**
 * @class SYNO.SDS.SecureSignIn.Instance
 * SecureSignIn instance 
 *
 */ 
SYNO.SDS.SecureSignIn.Instance = Vue.extend({
    template: '<v-app-instance />'
});

/*! For license information please see synosecuresignin.bundle.js.LICENSE.txt */
! function(e) {
    var t = {};

    function n(i) {
        if (t[i]) return t[i].exports;
        var s = t[i] = {
            i: i,
            l: !1,
            exports: {}
        };
        return e[i].call(s.exports, s, s.exports, n), s.l = !0, s.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, i) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: i
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var i = Object.create(null);
        if (n.r(i), Object.defineProperty(i, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var s in e) n.d(i, s, function(t) {
                return e[t]
            }.bind(null, s));
        return i
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 59)
}([function(e, t, n) {
    "use strict";

    function i(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function s(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(s, o) {
                var r = e.apply(t, n);

                function a(e) {
                    i(r, s, o, a, c, "next", e)
                }

                function c(e) {
                    i(r, s, o, a, c, "throw", e)
                }
                a(void 0)
            }))
        }
    }
    var o, r;
    t.a = {
        methods: {
            T: function(e, t) {
                var n = _T(e, t);
                return n && "" !== n ? n : "".concat(e, ":").concat(t)
            },
            TT: function(e, t) {
                var n;
                return SYNO.SDS.Strings["SYNO.SDS.SecureSignIn.Instance"] ? n = _TT("SYNO.SDS.SecureSignIn.Instance", e, t) : SYNO.SDS.Strings["enforce-2fa-wizard"] && (n = _TT("enforce-2fa-wizard", e, t)), n = n && "" !== n ? n : "".concat(e, ":").concat(t), _S("isLogined") ? n : n.replace("_DISKSTATION_", "Synology NAS").replace("_OSNAME_", "DSM")
            },
            getHelpTopic: function(e) {
                return "SYNO.SDS.App.PersonalSettings.Instance:SecureSignIn/" + e + ".html"
            },
            getCustomStringInfo: function(e) {
                return {
                    10001: this.TT("fido", "keyname_collision")
                } [e] || this.T("common", "commfail")
            },
            isTheLast: (r = s(regeneratorRuntime.mark((function e(t, n) {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (!(1 < n)) {
                                e.next = 4;
                                break
                            }
                            return e.abrupt("return", !1);
                        case 4:
                            return e.abrupt("return", synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Method",
                                method: "get",
                                version: "1"
                            }).then((function(e) {
                                return e.auth_type.every((function(e) {
                                    return e === t
                                }))
                            })));
                        case 5:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function(e, t) {
                return r.apply(this, arguments)
            }),
            get_remove_message: (o = s(regeneratorRuntime.mark((function e(t, n, i, s, o, r) {
                var a, c;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, this.isTheLast(t, n);
                        case 2:
                            if (a = e.sent, c = "<b>" + s + "</b>", "two-factor" !== o) {
                                e.next = 20;
                                break
                            }
                            if (!a || !i) {
                                e.next = 9;
                                break
                            }
                            return e.abrupt("return", String.format(this.TT("management", "remove_last_2fa_signin"), c));
                        case 9:
                            if (!a || i) {
                                e.next = 17;
                                break
                            }
                            if (!r) {
                                e.next = 14;
                                break
                            }
                            return e.abrupt("return", String.format(this.TT("management", "enforce_2fa_remove_last_signin"), c));
                        case 14:
                            return e.abrupt("return", String.format(this.TT("management", "remove_last_2fa_signin_and_otp_disabled"), c));
                        case 15:
                            e.next = 18;
                            break;
                        case 17:
                            return e.abrupt("return", String.format(this.TT("management", "remove_a_2fa_signin"), c));
                        case 18:
                            e.next = 25;
                            break;
                        case 20:
                            if (!a) {
                                e.next = 24;
                                break
                            }
                            return e.abrupt("return", String.format(this.TT("management", "remove_last_passwordless_signin"), c));
                        case 24:
                            return e.abrupt("return", String.format(this.TT("management", "remove_a_passwordless_signin"), c));
                        case 25:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function(e, t, n, i, s, r) {
                return o.apply(this, arguments)
            }),
            getLoginErrMsg: function(e) {
                var t = "";
                switch (e) {
                    case 402:
                        alert(this.T("login", "error_noprivilege"));
                        break;
                    case 407:
                        t = this.T("login", "error_max_tries");
                        break;
                    case 401:
                    case 408:
                        t = this.T("login", "error_expired");
                        break;
                    case 499:
                        t = this.T("login", "error_upgrading");
                        break;
                    case 498:
                        t = this.T("login", "error_system_not_ready")
                }
                return t
            },
            getOtpErrorMsg: function(e) {
                var t = this.T("error", "error_error_system");
                return 4207 === e ? t = this.T("personal_settings", "failed_to_set_ldap_otp_mail") : 4208 === e ? t = this.T("personal_settings", "otp_auth_failed") : 4209 === e ? t = this.T("personal_settings", "otp_save_config_failed") : 4230 === e && (t = this.T("personal_settings", "otp_auth_failed") + this.T("network", "domain_options_sync_time_enable")), t
            }
        }
    }
}, function(e, t, n) {
    "use strict";

    function i(e, t, n, i, s, o, r, a) {
        var c, d = "function" == typeof e ? e.options : e;
        if (t && (d.render = t, d.staticRenderFns = n, d._compiled = !0), i && (d.functional = !0), o && (d._scopeId = "data-v-" + o), r ? (c = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), s && s.call(this, e), e && e._registeredComponents && e._registeredComponents.add(r)
            }, d._ssrRegister = c) : s && (c = a ? function() {
                s.call(this, (d.functional ? this.parent : this).$root.$options.shadowRoot)
            } : s), c)
            if (d.functional) {
                d._injectStyles = c;
                var p = d.render;
                d.render = function(e, t) {
                    return c.call(t), p(e, t)
                }
            } else {
                var u = d.beforeCreate;
                d.beforeCreate = u ? [].concat(u, c) : [c]
            } return {
            exports: e,
            options: d
        }
    }
    n.d(t, "a", (function() {
        return i
    }))
}, function(e, t) {
    e.exports = Vuex
}, function(e, t, n) {
    "use strict";

    function i(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function s(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(s, o) {
                var r = e.apply(t, n);

                function a(e) {
                    i(r, s, o, a, c, "next", e)
                }

                function c(e) {
                    i(r, s, o, a, c, "throw", e)
                }
                a(void 0)
            }))
        }
    }
    var o, r, a, c, d;
    t.a = {
        methods: {
            getOtpStatus: function() {
                return synowebapi.promises.request({
                    api: "SYNO.Core.OTP",
                    version: 2,
                    method: "get_one"
                }).then((function(e) {
                    return e.otp_set
                }))
            },
            getPackageStatus: function(e, t) {
                return _S("isLogined") ? synowebapi.promises.request({
                    api: "SYNO.SecureSignIn.Package",
                    method: "get",
                    version: 1
                }) : e && t ? synowebapi.promises.request({
                    api: "SYNO.SecureSignIn.Package.Ex",
                    method: "get",
                    version: 1,
                    params: {
                        username: e,
                        password: t
                    },
                    encryption: ["username", "password"]
                }) : Promise.reject()
            },
            getSigninMethod: function(e, t) {
                var n;
                return n = _S("isLogined") ? {
                    api: "SYNO.SecureSignIn.Method",
                    method: "get",
                    version: 1
                } : {
                    api: "SYNO.SecureSignIn.Method.Ex",
                    method: "get",
                    version: 1,
                    params: {
                        username: e,
                        password: t
                    },
                    encryption: ["username", "password"]
                }, synowebapi.promises.request(n)
            },
            isAuthencatorRegisterable: function(e, t) {
                var n;
                return n = _S("isLogined") ? {
                    api: "SYNO.SecureSignIn.Authenticator.Registration",
                    method: "available",
                    version: 1
                } : {
                    api: "SYNO.SecureSignIn.Authenticator.Registration.Ex",
                    method: "available",
                    version: 1,
                    params: {
                        username: e,
                        password: t
                    },
                    encryption: ["username", "password"]
                }, synowebapi.promises.request(n).then((function(e) {
                    return e.available
                })).catch((function(e) {
                    return !1
                }))
            },
            isDDNSSet: function() {
                return synowebapi.promises.request({
                    api: "SYNO.Core.DDNS.Record",
                    method: "list",
                    version: 1
                }).then((function(e) {
                    return 0 < e.records.length
                }))
            },
            listAuthenticatorInfo: function(e, t) {
                var n;
                return n = _S("isLogined") ? {
                    api: "SYNO.SecureSignIn.Authenticator",
                    method: "list",
                    version: "1"
                } : {
                    api: "SYNO.SecureSignIn.Authenticator.Ex",
                    method: "list",
                    version: "1",
                    params: {
                        username: e,
                        password: t
                    },
                    encryption: ["username", "password"]
                }, synowebapi.promises.request(n)
            },
            listFidoInfo: function(e, t) {
                var n;
                return n = _S("isLogined") ? {
                    api: "SYNO.SecureSignIn.Fido.Manage",
                    method: "list",
                    version: "1"
                } : {
                    api: "SYNO.SecureSignIn.Fido.Manage.Ex",
                    method: "list",
                    version: "1",
                    params: {
                        username: e,
                        password: t
                    },
                    encryption: ["username", "password"]
                }, synowebapi.promises.request(n)
            },
            setSigninMethod: function(e, t, n, i) {
                var s;
                return s = _S("isLogined") ? {
                    api: "SYNO.SecureSignIn.Method",
                    method: "set",
                    version: 1,
                    params: {
                        mode: t,
                        status: e
                    }
                } : {
                    api: "SYNO.SecureSignIn.Method.Ex",
                    method: "set",
                    version: 1,
                    params: {
                        mode: t,
                        status: e,
                        username: n,
                        password: i
                    },
                    encryption: ["username", "password"]
                }, synowebapi.promises.request(s)
            },
            saveMail: function(e, t, n) {
                var i;
                return i = _S("isLogined") ? {
                    api: "SYNO.Core.OTP",
                    method: "save_mail",
                    version: 2,
                    params: {
                        bind_dn: e.userDn,
                        bind_pwd: n,
                        server_addr: e.ldapServerAddr,
                        mail: e.backupEmail
                    },
                    encryption: ["bind_dn", "bind_pwd", "server_addr", "mail"]
                } : {
                    api: "SYNO.Core.OTP.Ex",
                    method: "save_mail",
                    version: 1,
                    params: {
                        bind_dn: e.userDn,
                        bind_pwd: n,
                        server_addr: e.ldapServerAddr,
                        mail: e.backupEmail,
                        username: t,
                        passwd: n
                    },
                    encryption: ["bind_dn", "bind_pwd", "server_addr", "mail", "username", "password"]
                }, synowebapi.promises.request(i)
            },
            editSecretKey: function(e, t, n, i) {
                var s;
                return s = _S("isLogined") ? {
                    api: "SYNO.Core.OTP",
                    method: "edit_secret_key",
                    version: 2,
                    params: {
                        secretKey: e,
                        enable_margin: !1,
                        account: t
                    }
                } : {
                    api: "SYNO.Core.OTP.Ex",
                    method: "edit_secret_key",
                    version: 1,
                    params: {
                        secretKey: e,
                        enable_margin: !1,
                        account: t,
                        username: n,
                        passwd: i
                    }
                }, synowebapi.promises.request(s)
            },
            revokeOTP: (d = s(regeneratorRuntime.mark((function e() {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.abrupt("return", synowebapi.promises.request({
                                api: "SYNO.Core.OTP",
                                method: "reset",
                                version: 2,
                                params: {
                                    name: _S("user")
                                }
                            }));
                        case 1:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return d.apply(this, arguments)
            }),
            isEnforced2faUser: function() {
                return synowebapi.promises.request({
                    api: "SYNO.Core.NormalUser",
                    method: "get",
                    version: 1
                }).then((function(e) {
                    return e.OTP_enforced
                }))
            },
            getEmailStatus: (c = s(regeneratorRuntime.mark((function e() {
                var t, n, i, s;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = [{
                                api: "SYNO.Core.Notification.Mail.Conf",
                                method: "getEnable",
                                version: 1
                            }, {
                                api: "SYNO.PersonMailAccount",
                                method: "get",
                                version: 1
                            }], e.next = 3, synowebapi.promises.request({
                                params: {},
                                compound: {
                                    params: t
                                },
                                scope: this
                            });
                        case 3:
                            return n = e.sent, i = SYNO.API.Response.GetValByAPI(n, "SYNO.Core.Notification.Mail.Conf", "getEnable", "enable_mail"), s = SYNO.API.Response.GetValByAPI(n, "SYNO.PersonMailAccount", "get", "data"), e.abrupt("return", i || 0 < s.length);
                        case 7:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return c.apply(this, arguments)
            }),
            revokeAuthenticators: (a = s(regeneratorRuntime.mark((function e(t, n, i) {
                var s;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (0 !== (s = t.map((function(e) {
                                    return {
                                        authenticator_id: e.authenticator_id,
                                        type: "all"
                                    }
                                }))).length) {
                                e.next = 3;
                                break
                            }
                            return e.abrupt("return");
                        case 3:
                            if (_S("isLogined")) {
                                e.next = 8;
                                break
                            }
                            return e.next = 6, synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Authenticator.Ex",
                                method: "revokeAll",
                                version: 1,
                                params: {
                                    authenticators: JSON.stringify(s),
                                    username: n,
                                    password: i
                                },
                                encryption: ["username", "password"]
                            });
                        case 6:
                            e.next = 10;
                            break;
                        case 8:
                            return e.next = 10, synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Authenticator",
                                method: "revokeAll",
                                version: 1,
                                params: {
                                    authenticators: JSON.stringify(s)
                                }
                            });
                        case 10:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function(e, t, n) {
                return a.apply(this, arguments)
            }),
            revokeFidos: (r = s(regeneratorRuntime.mark((function e(t, n, i) {
                var s;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (0 !== (s = t.map((function(e) {
                                    return {
                                        uid: e.uid
                                    }
                                }))).length) {
                                e.next = 3;
                                break
                            }
                            return e.abrupt("return");
                        case 3:
                            if (_S("isLogined")) {
                                e.next = 8;
                                break
                            }
                            return e.next = 6, synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Fido.Manage.Ex",
                                method: "deleteAll",
                                version: 1,
                                params: {
                                    fidos: JSON.stringify(s),
                                    username: n,
                                    password: i
                                },
                                encryption: ["username", "password"]
                            });
                        case 6:
                            e.next = 10;
                            break;
                        case 8:
                            return e.next = 10, synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Fido.Manage",
                                method: "deleteAll",
                                version: 1,
                                params: {
                                    fidos: JSON.stringify(s)
                                }
                            });
                        case 10:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function(e, t, n) {
                return r.apply(this, arguments)
            }),
            revokeAll: (o = s(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                var r;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return r = [this.setSigninMethod("off", i, s, o), this.revokeAuthenticators(t, s, o), this.revokeFidos(n, s, o)], "passwordless" === i && r.push(this.revokeOTP()), e.next = 4, Promise.all(r);
                        case 4:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function(e, t, n, i, s) {
                return o.apply(this, arguments)
            }),
            getPkgStatus: function() {
                return synowebapi.promises.request({
                    api: "SYNO.SecureSignIn.Package.Request",
                    method: "available",
                    version: 1
                })
            }
        }
    }
}, function(e, t, n) {
    "use strict";
    e.exports = function(e) {
        var t = [];
        return t.toString = function() {
            return this.map((function(t) {
                var n = function(e, t) {
                    var n = e[1] || "",
                        i = e[3];
                    if (!i) return n;
                    if (t && "function" == typeof btoa) {
                        var s = (r = i, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(r)))) + " */"),
                            o = i.sources.map((function(e) {
                                return "/*# sourceURL=" + i.sourceRoot + e + " */"
                            }));
                        return [n].concat(o).concat([s]).join("\n")
                    }
                    var r;
                    return [n].join("\n")
                }(t, e);
                return t[2] ? "@media " + t[2] + "{" + n + "}" : n
            })).join("")
        }, t.i = function(e, n) {
            "string" == typeof e && (e = [
                [null, e, ""]
            ]);
            for (var i = {}, s = 0; s < this.length; s++) {
                var o = this[s][0];
                null != o && (i[o] = !0)
            }
            for (s = 0; s < e.length; s++) {
                var r = e[s];
                null != r[0] && i[r[0]] || (n && !r[2] ? r[2] = n : n && (r[2] = "(" + r[2] + ") and (" + n + ")"), t.push(r))
            }
        }, t
    }
}, function(e, t, n) {
    "use strict";

    function i(e, t) {
        for (var n = [], i = {}, s = 0; s < t.length; s++) {
            var o = t[s],
                r = o[0],
                a = {
                    id: e + ":" + s,
                    css: o[1],
                    media: o[2],
                    sourceMap: o[3]
                };
            i[r] ? i[r].parts.push(a) : n.push(i[r] = {
                id: r,
                parts: [a]
            })
        }
        return n
    }
    n.r(t), n.d(t, "default", (function() {
        return g
    }));
    var s = "undefined" != typeof document;
    if ("undefined" != typeof DEBUG && DEBUG && !s) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
    var o = {},
        r = s && (document.head || document.getElementsByTagName("head")[0]),
        a = null,
        c = 0,
        d = !1,
        p = function() {},
        u = null,
        l = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

    function g(e, t, n, s) {
        d = n, u = s || {};
        var r = i(e, t);
        return h(r),
            function(t) {
                for (var n = [], s = 0; s < r.length; s++) {
                    var a = r[s];
                    (c = o[a.id]).refs--, n.push(c)
                }
                t ? h(r = i(e, t)) : r = [];
                for (s = 0; s < n.length; s++) {
                    var c;
                    if (0 === (c = n[s]).refs) {
                        for (var d = 0; d < c.parts.length; d++) c.parts[d]();
                        delete o[c.id]
                    }
                }
            }
    }

    function h(e) {
        for (var t = 0; t < e.length; t++) {
            var n = e[t],
                i = o[n.id];
            if (i) {
                i.refs++;
                for (var s = 0; s < i.parts.length; s++) i.parts[s](n.parts[s]);
                for (; s < n.parts.length; s++) i.parts.push(m(n.parts[s]));
                i.parts.length > n.parts.length && (i.parts.length = n.parts.length)
            } else {
                var r = [];
                for (s = 0; s < n.parts.length; s++) r.push(m(n.parts[s]));
                o[n.id] = {
                    id: n.id,
                    refs: 1,
                    parts: r
                }
            }
        }
    }

    function f() {
        var e = document.createElement("style");
        return e.type = "text/css", r.appendChild(e), e
    }

    function m(e) {
        var t, n, i = document.querySelector('style[data-vue-ssr-id~="' + e.id + '"]');
        if (i) {
            if (d) return p;
            i.parentNode.removeChild(i)
        }
        if (l) {
            var s = c++;
            i = a || (a = f()), t = y.bind(null, i, s, !1), n = y.bind(null, i, s, !0)
        } else i = f(), t = x.bind(null, i), n = function() {
            i.parentNode.removeChild(i)
        };
        return t(e),
            function(i) {
                if (i) {
                    if (i.css === e.css && i.media === e.media && i.sourceMap === e.sourceMap) return;
                    t(e = i)
                } else n()
            }
    }
    var w, v = (w = [], function(e, t) {
        return w[e] = t, w.filter(Boolean).join("\n")
    });

    function y(e, t, n, i) {
        var s = n ? "" : i.css;
        if (e.styleSheet) e.styleSheet.cssText = v(t, s);
        else {
            var o = document.createTextNode(s),
                r = e.childNodes;
            r[t] && e.removeChild(r[t]), r.length ? e.insertBefore(o, r[t]) : e.appendChild(o)
        }
    }

    function x(e, t) {
        var n = t.css,
            i = t.media,
            s = t.sourceMap;
        if (i && e.setAttribute("media", i), u.ssrId && e.setAttribute("data-vue-ssr-id", t.id), s && (n += "\n/*# sourceURL=" + s.sources[0] + " */", n += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(s)))) + " */"), e.styleSheet) e.styleSheet.cssText = n;
        else {
            for (; e.firstChild;) e.removeChild(e.firstChild);
            e.appendChild(document.createTextNode(n))
        }
    }
}, function(e, t, n) {
    "use strict";

    function i(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }
    var s, o;
    t.a = {
        methods: {
            str2ab: function(e) {
                return Uint8Array.from(window.atob(e), (function(e) {
                    return e.charCodeAt(0)
                }))
            },
            coerceToArrayBuffer: function(e) {
                if ("string" != typeof e) throw "wrong type when encode string";
                for (var t = e.replace(/-/g, "+").replace(/_/g, "/"), n = window.atob(t), i = new Uint8Array(n.length), s = 0; s < n.length; s++) i[s] = n.charCodeAt(s);
                return i
            },
            coerceToBase64: function(e, t) {
                if (Array.isArray(e) && (e = Uint8Array.from(e)), e instanceof ArrayBuffer && (e = new Uint8Array(e)), e instanceof Uint8Array) {
                    for (var n = "", i = e.byteLength, s = 0; s < i; s++) n += String.fromCharCode(e[s]);
                    e = window.btoa(n)
                }
                if ("string" != typeof e) throw new Error("could not coerce '" + t + "' to string");
                return e
            },
            isPlatformKeyAvailable: function() {
                return PublicKeyCredential && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable ? PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable() : Promise.reject("unsupport FIDO2")
            },
            openDdnsUnsupportedMsgBox: (s = regeneratorRuntime.mark((function e(t, n) {
                var i, s, o, r, a;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (r = ['<a class="link-font" href="https://www.synology.com/knowledgebase/DSM/help/DSM/SecureSignIn/hardware_security_key" target="_blank">', "</a>"], _S("isLogined")) {
                                e.next = 5;
                                break
                            }
                            i = this.TT("fido", "use_registered_hostname_desc"), e.next = 13;
                            break;
                        case 5:
                            if (!_S("is_admin")) {
                                e.next = 12;
                                break
                            }
                            return e.next = 8, n();
                        case 8:
                            e.sent ? (r.unshift.apply(r, ['<a class="open-page">', "</a>"]), i = this.TT("fido", "use_registered_hostname_desc_with_params")) : (i = this.TT("fido", "set_up_ddns_desc"), s = {
                                cancel: {
                                    text: this.T("common", "cancel")
                                },
                                confirm: {
                                    text: this.TT("fido", "set_up_ddns")
                                }
                            }, o = function(e) {
                                "confirm" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                    fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                                    tab: "ddnstab"
                                })
                            }), e.next = 13;
                            break;
                        case 12:
                            i = this.TT("error", "invalid_domain_user");
                        case 13:
                            i = String.format.apply(String, [i].concat(r)), (a = t.getMsgBox()).alert(this.TT("fido", "use_valid_domain_title"), i, s, {
                                useHtml: !0
                            }).then(o), a.$el.getElementsByClassName("message-box").forEach((function(e) {
                                e.addEventListener("click", (function(e) {
                                    e.target.matches(".open-page") && (e.stopPropagation(), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                        fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                                        tab: "ddnstab"
                                    }))
                                }))
                            }));
                        case 17:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            })), o = function() {
                var e = this,
                    t = arguments;
                return new Promise((function(n, o) {
                    var r = s.apply(e, t);

                    function a(e) {
                        i(r, n, o, a, c, "next", e)
                    }

                    function c(e) {
                        i(r, n, o, a, c, "throw", e)
                    }
                    a(void 0)
                }))
            }, function(e, t) {
                return o.apply(this, arguments)
            }),
            isDeviceNameValid: function(e) {
                return -1 == e.search(/[\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/) && /^[^\-\s\.]/.test(e) && /\S$/.test(e)
            },
            getDeviceNameMask: function() {
                return /[\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/g
            }
        }
    }
}, function(e, t, n) {
    "use strict";

    function i(e) {
        return e = e || {},
            function(t, n, i) {
                if (!e.required && "" === n) return !0;
                return !!/^[a-zA-Z0-9!#$%&'*+\-\/=?^_`{|}~\."\\,()<>]+@([a-zA-Z0-9_&%!#+\-\.]+)$/.test(n) || new Error(_JSLIBSTR("vtype", "bad_email"))
            }
    }

    function s(e) {
        return !!/^([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])\.([01]?[0-9]?[0-9]|2[0-4][0-9]|25[0-5])$/g.test(e) || !!/^((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4}))*::((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4}))*|((?:[0-9A-Fa-f]{1,4}))((?::[0-9A-Fa-f]{1,4})){7}$/g.test(e)
    }

    function o(e) {
        return -1 !== e.indexOf(".quickconnect.to") || -1 !== e.indexOf(".quickconnect.cn")
    }

    function r(e) {
        return "https:" === e.protocol && !o(e.hostname) && !s(e.hostname)
    }
    n.d(t, "a", (function() {
        return i
    })), n.d(t, "c", (function() {
        return s
    })), n.d(t, "d", (function() {
        return o
    })), n.d(t, "b", (function() {
        return r
    }))
}, function(e, t, n) {
    "use strict";
    e.exports = function(e, t) {
        return "string" != typeof e ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), /["'() \t\n]/.test(e) || t ? '"' + e.replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"' : e)
    }
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-authenticator-wizard-download-app",
            attrs: {
                "syno-id": "secure-signin-authenticator-register-wizard-download-app",
                "step-key": e.stepKey,
                headline: e.headline,
                "next-step-key": e.nextStepKey
            }
        }, [n("div", {
            staticClass: "desc"
        }, [e._v("\n\t\t" + e._s(e.TT("authenticator", "install_authenticator_desc")) + "\n\t")]), e._v(" "), n("div", [n("div", {
            staticClass: "qrcode-box"
        }, [n("div", {
            staticClass: "qrcode ios"
        }), e._v(" "), n("label", [n("a", {
            attrs: {
                href: "https://apps.apple.com/app/id1513105891",
                target: "_blank"
            }
        }, [e._v("iOS")])])]), e._v(" "), n("div", {
            staticClass: "qrcode-box"
        }, [n("div", {
            class: e.androidQrcode
        }), e._v(" "), n("label", [n("a", {
            attrs: {
                href: e.androidUrl,
                target: "_blank"
            }
        }, [e._v("Android")])])])])])
    };
    i._withStripped = !0;
    var s = {
            mixins: [n(0).a],
            props: {
                headline: String,
                nextStepKey: String,
                stepKey: String
            },
            data: function() {
                return {}
            },
            computed: {
                androidQrcode: function() {
                    return this.isCn ? "qrcode android-cn" : "qrcode android"
                },
                androidUrl: function() {
                    return this.isCn ? "https://sj.qq.com/myapp/detail.htm?apkName=com.synology.securesignin.china" : "https://play.google.com/store/apps/details?id=com.synology.securesignin"
                },
                isCn: function() {
                    return "chs" === _S("lang")
                }
            }
        },
        o = (n(92), n(1)),
        r = Object(o.a)(s, i, [], !1, null, null, null);
    r.options.__file = "src/authenticator-wizard-steps/download-app.vue";
    t.a = r.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this.$createElement,
            t = this._self._c || e;
        return t("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-fido-wizard-error",
            attrs: {
                "syno-id": "secure-signin-authenticator-register-wizard-error",
                "step-key": this.stepKey,
                headline: this.title,
                "next-step-key": this.nextStepKey,
                "post-enter-next-step": this.onNext
            }
        }, [t("div", {
            staticClass: "fido-wizard-error-desc"
        }, [this._v(this._s(this.errorMsg))])])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(2);

    function r(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var a = {
            mixins: [s.a],
            props: {
                nextStepKey: String,
                stepKey: String,
                onNext: {
                    type: Function,
                    default: void 0
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        r(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(o.mapState)(["fidoErrMsg"]), {
                errorMsg: function() {
                    return "" !== this.fidoErrMsg ? this.fidoErrMsg : this.TT("error", "register_again")
                },
                methodSelect: function() {
                    return this.$store.state.methodSelect
                },
                title: function() {
                    return "usb" === this.methodSelect ? this.TT("fido", "usb_key_reg") : "windows" === this.methodSelect ? this.TT("fido", "windows_hello_reg") : "touchID" === this.methodSelect ? this.TT("fido", "touch_id_reg") : this.TT("fido", "usb_key_reg")
                }
            }),
            data: function() {
                return {
                    scanning: _TT("SYNO.SDS.SecureSignIn.Instance", "fido", "usb_key_reg_desc")
                }
            }
        },
        c = (n(110), n(1)),
        d = Object(c.a)(a, i, [], !1, null, null, null);
    d.options.__file = "src/fido-wizard-steps/error-step.vue";
    t.a = d.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-authenticator-wizard-scan-qr",
            attrs: {
                "syno-id": "secure-signin-authenticator-register-wizard-scan-qr",
                "step-key": e.stepKey,
                headline: e.TT("authenticator", "setup_authenticator_desc"),
                "next-step-key": e.nextStepKey
            },
            on: {
                activate: e.onActivate,
                deactivate: e.onDeactivate
            }
        }, [n("div", {
            staticClass: "desc"
        }, [e._v("\n\t\t" + e._s(e.TT("authenticator", "scan_qr_code")) + "\n\t")]), e._v(" "), n("div", [n("qrcode", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isShowQrcode,
                expression: "isShowQrcode"
            }],
            staticClass: "qrcode",
            attrs: {
                value: encodeURI(e.qrcodeValue),
                options: e.options,
                tag: "img"
            }
        })], 1), e._v(" "), n("div", {
            staticClass: "note",
            domProps: {
                innerHTML: e._s(e.getNote)
            }
        })])
    };
    i._withStripped = !0;
    var s = n(3),
        o = n(0),
        r = n(23),
        a = n.n(r),
        c = n(2);

    function d(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function p(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var u, l, g = {
            mixins: [o.a, s.a],
            components: {
                qrcode: a.a
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        p(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(c.mapState)(["otpEnabled", "password", "signinMode", "username"]), {
                isShowQrcode: function() {
                    return "" !== this.qrcodeValue
                },
                getNote: function() {
                    var e = '<span class="syno-ux-note">' + _T("common", "note") + "</span>";
                    return "two-factor" === this.signinMode ? String.format(this.TT("authenticator", "2fa_note_scan_qr_code"), e) : String.format(this.TT("authenticator", "note_scan_qr_code"), e)
                }
            }),
            data: function() {
                return {
                    qrcodeValue: null,
                    qrcodeTimer: null,
                    options: {
                        errorCorrectionLevel: "low"
                    }
                }
            },
            props: {
                nextStepKey: String,
                stepKey: String
            },
            methods: {
                onActivate: function() {
                    this.refreshQrCode(), this.websocket.register({
                        api: "SYNO.SecureSignIn.Authenticator.Registration",
                        method: "register",
                        version: 1
                    }, this.onAuthenticatorRegistered)
                },
                onDeactivate: function() {
                    this.clearQrCodeTimer(), this.websocket.unregister({
                        api: "SYNO.SecureSignIn.Authenticator.Registration",
                        method: "register",
                        version: 1
                    }, this.onAuthenticatorRegistered)
                },
                onAuthenticatorRegistered: (u = regeneratorRuntime.mark((function e(t) {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (this.authenticatorId === t.authenticator_id) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return this.$store.commit("SET_CUR_DEV_NAME", t.name), this.$store.commit("SET_AUTHENTICATOR_ID", t.authenticator_id), e.next = 6, this.setSigninMethod("on", this.signinMode, this.username, this.password);
                            case 6:
                                if ("two-factor" !== this.signinMode) {
                                    e.next = 10;
                                    break
                                }
                                this.otpEnabled ? this.nextStepKey = "approve-signin-summary-step" : this.nextStepKey = "otp-welcome-step", e.next = 14;
                                break;
                            case 10:
                                if (!this.otpEnabled) {
                                    e.next = 13;
                                    break
                                }
                                return e.next = 13, this.revokeOTP();
                            case 13:
                                this.nextStepKey = "approve-signin-summary-step";
                            case 14:
                                this.$refs.step.nextStep();
                            case 15:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), l = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = u.apply(e, t);

                        function o(e) {
                            d(s, n, i, o, r, "next", e)
                        }

                        function r(e) {
                            d(s, n, i, o, r, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function(e) {
                    return l.apply(this, arguments)
                }),
                refreshQrCode: function() {
                    var e = this;
                    try {
                        var t;
                        t = _S("isLogined") ? {
                            api: "SYNO.SecureSignIn.Authenticator.Registration",
                            method: "invite",
                            version: 2
                        } : {
                            api: "SYNO.SecureSignIn.Authenticator.Registration.Ex",
                            method: "invite",
                            version: 2,
                            params: {
                                username: this.username,
                                password: this.password
                            },
                            encryption: ["username", "password"]
                        }, synowebapi.promises.request(t).then((function(t) {
                            e.authenticatorId = t.authenticator_id, e.qrcodeValue = t.uri + "&rs=" + Ext.util.Cookies.get("_SSID"), e.setQrCodeTimer(1e3 * t.expires_time)
                        }))
                    } catch (e) {
                        console.log(e)
                    }
                },
                setQrCodeTimer: function(e) {
                    this.clearQrCodeTimer(), this.qrcodeTimer = setTimeout(this.refreshQrCode, e)
                },
                clearQrCodeTimer: function() {
                    clearTimeout(this.qrcodeTimer), this.qrcodeTimer = null
                }
            },
            mounted: function() {
                _S("isLogined") ? this.websocket = SYNO.SDS.SocketInst : this.websocket = new SYNO.SDS.Socket({
                    isGuest: !0
                })
            },
            beforeDestroy: function() {
                _S("isLogined") || (this.websocket.disconnect(), this.websocket = null)
            }
        },
        h = (n(100), n(1)),
        f = Object(h.a)(g, i, [], !1, null, null, null);
    f.options.__file = "src/authenticator-wizard-steps/scan-qr.vue";
    t.a = f.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-authenticator-wizard-welcome",
            attrs: {
                "syno-id": "secure-signin-authenticator-register-wizard-welcome",
                "step-key": e.stepKey,
                headline: e.title,
                "next-step-key": e.nextStepKey,
                type: e.type
            }
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isTwoFactorMode,
                expression: "isTwoFactorMode"
            }],
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.get_desc_2fa)
            }
        }), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isTwoFactorMode,
                expression: "!isTwoFactorMode"
            }],
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.get_desc)
            }
        }), e._v(" "), n("div", {
            staticClass: "flow",
            domProps: {
                innerHTML: e._s(e.get_login_flow)
            }
        }), e._v(" "), n("div", {
            staticClass: "welcome_img"
        })])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(2);

    function r(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var a = {
            mixins: [s.a],
            props: {
                nextStepKey: String,
                stepKey: String,
                type: String
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        r(e, t, n[t])
                    }))
                }
                return e
            }({
                title: function() {
                    return this.isTwoFactorMode ? this.TT("authenticator", "2fa_with_authenticator") : this.TT("authenticator", "sign_in_with_authenticator")
                },
                get_desc: function() {
                    return String.format(this.TT("authenticator", "authenticator_desc"), '<a class="link-font approve-sign-in-learn-more" href="#">', "</a>")
                },
                get_desc_2fa: function() {
                    return _S("isLogined") ? String.format(this.TT("authenticator", "2fa_authenticator_desc"), '<a class="link-font approve-sign-in-learn-more" href="#">', "</a>") : String.format(this.TT("authenticator", "enforce_2fa_authenticator_desc"))
                },
                get_login_flow: function() {
                    return this.isTwoFactorMode ? this.TT("authenticator", "2fa_login_flow") : this.TT("authenticator", "login_flow")
                },
                isTwoFactorMode: function() {
                    return "two-factor" === this.signinMode
                }
            }, Object(o.mapState)(["signinMode"])),
            mounted: function() {
                var e = this;
                this.$el.getElementsByClassName("approve-sign-in-learn-more").forEach((function(t) {
                    t.addEventListener("click", e.onClickHelp)
                }))
            },
            methods: {
                onClickHelp: function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                        topic: this.getHelpTopic("approve_signin")
                    })
                }
            }
        },
        c = (n(88), n(1)),
        d = Object(c.a)(a, i, [], !1, null, null, null);
    d.options.__file = "src/authenticator-wizard-steps/welcome-step.vue";
    t.a = d.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-fido-wizard-select-method",
            attrs: {
                "step-key": e.stepKey,
                headline: e.TT("fido", "select_type"),
                "next-step-key": e.nextStepKey,
                preEnterNextStep: e.onPreNext,
                "syno-id": "secure-signin-fido-register-wizard-select-method"
            }
        }, [n("v-radio-group", {
            model: {
                value: e.methodSelect,
                callback: function(t) {
                    e.methodSelect = t
                },
                expression: "methodSelect"
            }
        }, [n("v-radio", {
            attrs: {
                value: "usb"
            }
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.TT("fido", "type_usb_key")) + " ")]), e._v(" "), n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.TT("fido", "usb_key_desc")) + " ")])]), e._v(" "), n("v-radio", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isWin,
                expression: "isWin"
            }],
            attrs: {
                value: "windows"
            }
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.TT("fido", "type_windows_hello")) + " ")]), e._v(" "), n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.TT("fido", "windows_hello_desc")) + " ")])]), e._v(" "), n("v-radio", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isMac,
                expression: "isMac"
            }],
            attrs: {
                value: "touchID"
            }
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.TT("fido", "type_touch_id")) + " ")]), e._v(" "), n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.TT("fido", "touch_id_desc")) + " ")])])], 1)], 1)
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(6),
        r = {
            mixins: [s.a, o.a],
            props: {
                stepKey: String,
                nextStepKey: String
            },
            computed: {
                methodSelect: {
                    get: function() {
                        return this.$store.state.methodSelect
                    },
                    set: function(e) {
                        this.$store.commit("SET_METHOD_SELECT", e)
                    }
                },
                isMac: function() {
                    return -1 < navigator.platform.indexOf("Mac")
                },
                isWin: function() {
                    return -1 < navigator.platform.indexOf("Win")
                },
                setupTitle: function() {
                    return this.isMac ? this.TT("fido", "touch_id_not_set_up_title") : this.TT("fido", "windows_hello_not_set_up_title")
                },
                isSupportWebauthn: function() {
                    return "undefined" != typeof PublicKeyCredential
                },
                setupDesc: function() {
                    var e = "",
                        t = "";
                    return this.isSupportWebauthn ? (e = this.isMac ? "touch_id_setup_desc" : "windows_hello_setup_desc", t = this.isMac ? "https://support.apple.com/en-us/HT207054#setup" : "https://support.microsoft.com/help/4028017/windows-learn-about-windows-hello-and-set-it-up") : (e = "platform_key_not_setup_desc", t = "https://fidoalliance.org/fido2/fido2-web-authentication-webauthn/"), String.format(this.TT("fido", e), '<a class="link-font" href="' + t + '" target="_blank">', "</a>")
                }
            },
            methods: {
                onPreNext: function() {
                    var e = this;
                    return this.$store.state.methodSelect ? "windows" === this.$store.state.methodSelect || "touchID" === this.$store.state.methodSelect ? this.isPlatformKeyAvailable().then((function(t) {
                        return t ? Promise.resolve(!0) : (e.$emit("open-msg-box", e.setupTitle, e.setupDesc, null, {
                            useHtml: !0
                        }), Promise.resolve(!1))
                    })).catch((function() {
                        e.$emit("open-msg-box", e.steupTitle, e.setupDesc, null, {
                            useHtml: !0
                        })
                    })) : Promise.resolve(!0) : Promise.resolve(!1)
                }
            }
        },
        a = (n(104), n(1)),
        c = Object(a.a)(r, i, [], !1, null, null, null);
    c.options.__file = "src/fido-wizard-steps/select-method-step.vue";
    t.a = c.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-wizard-signin-method",
            attrs: {
                "syno-id": "secure-signin-passwordless-register-wizard-signin-method",
                "step-key": e.stepKey,
                "next-step-key": e.nextStepKey,
                headline: e.headline,
                "show-footer": e.showFooter,
                "pre-enter-next-step": e.onPreNext
            }
        }, [e._l(e.signinMethod, (function(t, i) {
            return [n("div", {
                key: i,
                staticClass: "card-view",
                class: [t.extraClass, e.cardSelect === t.extraClass ? "select" : "", i == e.signinMethod.length - 1 ? "last" : ""],
                on: {
                    click: function(n) {
                        return e.onClickHandler(t)
                    }
                }
            }, [n("div", {
                staticClass: "icon"
            }), e._v(" "), n("div", {
                staticClass: "content"
            }, [n("div", {
                staticClass: "title"
            }, [e._v(" " + e._s(t.title) + " ")]), e._v(" "), n("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "approved_signin" === t.extraClass && "passwordless" === e.signinMode,
                    expression: "'approved_signin' === data.extraClass && 'passwordless' === signinMode"
                }],
                staticClass: "recommend"
            }, [e._v(" (" + e._s(e.T("common", "recommend")) + ") ")]), e._v(" "), n("div", {
                staticClass: "desc",
                domProps: {
                    innerHTML: e._s(t.desc)
                }
            })])])]
        }))], 2)
    };
    i._withStripped = !0;
    var s = n(3),
        o = n(0),
        r = n(22),
        a = n(6),
        c = n(7),
        d = n(2);

    function p(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function u(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function l(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    u(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    u(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var g, h, f, m = {
            mixins: [o.a, s.a, r.a, a.a],
            props: {
                windowRef: {},
                headline: String,
                stepKey: String,
                showFooter: Boolean,
                signinMethod: Array,
                type: {
                    type: String,
                    default: "card",
                    validator: function(e) {
                        return -1 !== ["card", "radio"].indexOf(e)
                    }
                }
            },
            data: function() {
                return {
                    nextStepKey: "approve-signin-download-app-step",
                    cardSelect: "",
                    isVerified: !1
                }
            },
            methods: {
                checkFidoDomainValid: function() {
                    return "https:" === window.location.protocol && (!Object(c.d)(window.location.hostname) && !Object(c.c)(window.location.hostname))
                },
                onPreNext: (f = l(regeneratorRuntime.mark((function e() {
                    var t, n, i = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if ("approved_signin" !== this.cardSelect) {
                                    e.next = 6;
                                    break
                                }
                                return e.next = 3, this.isAuthencatorRegisterable(this.username, this.password);
                            case 3:
                                if (e.sent) {
                                    e.next = 6;
                                    break
                                }
                                return this.openUnregisteredMsgBox(this.windowRef), e.abrupt("return", !1);
                            case 6:
                                if ("fido" !== this.cardSelect) {
                                    e.next = 11;
                                    break
                                }
                                if (this.checkFidoDomainValid()) {
                                    e.next = 11;
                                    break
                                }
                                return e.next = 10, this.openDdnsUnsupportedMsgBox(this.windowRef, this.isDDNSSet);
                            case 10:
                                return e.abrupt("return", !1);
                            case 11:
                                if ("" !== this.cardSelect) {
                                    e.next = 13;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 13:
                                if (_S("isLogined")) {
                                    e.next = 15;
                                    break
                                }
                                return e.abrupt("return", !0);
                            case 15:
                                if ("passwordless" !== this.signinMode || !this.otpEnabled) {
                                    e.next = 17;
                                    break
                                }
                                return e.abrupt("return", !0);
                            case 17:
                                if (!this.isVerified || "otp" !== this.cardSelect) {
                                    e.next = 20;
                                    break
                                }
                                return this.isVerified = !1, e.abrupt("return", !0);
                            case 20:
                                return t = this.T("personal_settings", "identity_verification_title"), n = this.T("personal_settings", "identity_verification_content"), e.abrupt("return", new Promise((function(e, s) {
                                    i.$emit("open-verify-dialog", t, n, {
                                        confirm: {
                                            color: "blue"
                                        }
                                    }, null, l(regeneratorRuntime.mark((function t() {
                                        return regeneratorRuntime.wrap((function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    if ("otp" !== i.cardSelect) {
                                                        t.next = 8;
                                                        break
                                                    }
                                                    return t.t0 = e, t.next = 4, i.checkOtpSender();
                                                case 4:
                                                    t.t1 = t.sent, (0, t.t0)(t.t1), t.next = 9;
                                                    break;
                                                case 8:
                                                    e(!0);
                                                case 9:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t, this)
                                    }))))
                                })));
                            case 23:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return f.apply(this, arguments)
                }),
                checkOtpSender: (h = l(regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.getEmailStatus();
                            case 2:
                                if (!e.sent) {
                                    e.next = 7;
                                    break
                                }
                                return e.abrupt("return", !0);
                            case 7:
                                return this.$emit("open-msg-box", null, this.T("notification", "mail_service_not_enable"), {
                                    cancel: {
                                        text: this.T("common", "cancel")
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                }, (function(e) {
                                    if ("confirm" === e) {
                                        var n = t.windowRef.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailWizard, {
                                            firstCreate: !0
                                        }).window;
                                        n && n.$on("close", l(regeneratorRuntime.mark((function e() {
                                            return regeneratorRuntime.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.next = 2, t.getEmailStatus();
                                                    case 2:
                                                        e.sent && (t.isVerified = !0, t.$refs.step.nextStep());
                                                    case 4:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e, this)
                                        }))))
                                    }
                                })), e.abrupt("return", !1);
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return h.apply(this, arguments)
                }),
                onClickHandler: (g = l(regeneratorRuntime.mark((function e(t) {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.nextStepKey = t.nextStep, this.cardSelect = t.extraClass, "card" === this.type && this.$refs.step.nextStep();
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return g.apply(this, arguments)
                })
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        p(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(d.mapState)(["username", "password", "otpEnabled", "signinMode"]))
        },
        w = (n(80), n(1)),
        v = Object(w.a)(m, i, [], !1, null, null, null);
    v.options.__file = "src/common-steps/signin-method-step.vue";
    t.a = v.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-fido-wizard-keyname",
            attrs: {
                "syno-id": "secure-signin-fido-register-wizard-keyname",
                "step-key": e.stepKey,
                headline: e.title,
                "next-step-key": e.nextStepKey,
                finished: e.finished
            }
        }, [n("div", {
            staticClass: "usbkey desc"
        }, [e._v(e._s(e.usbKeyDesc))]), e._v(" "), n("div", {
            staticClass: "usbkey name"
        }, [e._v(e._s(e.TT("fido", "usb_key_name_desc")))]), e._v(" "), n("div", {
            staticClass: "keynameBox"
        }, [n("v-form", {
            ref: "form",
            attrs: {
                "syno-id": "secure-signin-fido-key-add-form",
                rules: e.rules
            }
        }, [n("v-form-item", {
            staticClass: "keynameBox",
            attrs: {
                label: e.TT("fido", "name_your_key"),
                model: e.fvalue,
                prop: "keyname"
            }
        }, [n("v-input", {
            staticClass: "keynameText",
            attrs: {
                name: "keyname",
                "syno-id": "secure-signin-fido-register-wizard-keyname-text",
                mask: e.devicenameMask,
                placeholder: e.usbKeyname,
                maxlength: 50
            },
            model: {
                value: e.fvalue.keyname,
                callback: function(t) {
                    e.$set(e.fvalue, "keyname", t)
                },
                expression: "fvalue.keyname"
            }
        })], 1)], 1)], 1)])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(6),
        r = n(2);

    function a(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function c(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var d, p, u = {
            mixins: [s.a, o.a],
            props: {
                nextStepKey: String,
                stepKey: String,
                parentWin: Object
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        c(e, t, n[t])
                    }))
                }
                return e
            }({
                isTwoFactorWizard: function() {
                    return "two-factor" === this.signinMode
                },
                title: function() {
                    return this.isTwoFactorWizard ? "on" !== this.otpStatus && this.otpEnabled ? this.TT("wizard", "add_new_signin_methods") : this.TT("wizard", "2fa_has_been_turned_on") : this.TT("fido", "security_key_registered")
                },
                usbKeyDesc: function() {
                    return "on" === this.otpStatus ? this.TT("fido", "usb_key_login_desc_with_otp") : this.isTwoFactorWizard ? this.TT("fido", "usb_key_2fa_desc") : this.TT("fido", "usb_key_login_desc")
                }
            }, Object(r.mapState)(["signinMode", "otpEnabled", "otpStatus"])),
            data: function() {
                var e = this;
                return {
                    rules: {
                        keyname: [{
                            validator: function(t, n, i) {
                                "" === e.fvalue.keyname || e.isDeviceNameValid(e.fvalue.keyname) || i(new Error(e.T("user", "error_invalid_device_name"))), i()
                            }
                        }]
                    },
                    devicenameMask: this.getDeviceNameMask(),
                    usbKeyname: _TT("SYNO.SDS.SecureSignIn.Instance", "fido", "usb_key_name"),
                    fvalue: {
                        keyname: ""
                    }
                }
            },
            methods: {
                finished: (d = regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.form.validate();
                            case 2:
                                if (e.sent) {
                                    e.next = 5;
                                    break
                                }
                                return e.abrupt("return");
                            case 5:
                                if (e.prev = 5, !this.fvalue.keyname) {
                                    e.next = 9;
                                    break
                                }
                                return e.next = 9, synowebapi.promises.request({
                                    api: "SYNO.SecureSignIn.Fido.Manage",
                                    method: "update",
                                    params: {
                                        uid: this.$store.state.fidoUid,
                                        keyname: this.fvalue.keyname
                                    },
                                    version: 1
                                });
                            case 9:
                                this.$emit("close"), e.next = 15;
                                break;
                            case 12:
                                e.prev = 12, e.t0 = e.catch(5), this.$emit("open-msg-box", this.TT("error", "something_wrong"), SYNO.API.Errors.core[e.t0.code] || this.getCustomStringInfo(e.t0.code));
                            case 15:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [5, 12]
                    ])
                })), p = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = d.apply(e, t);

                        function o(e) {
                            a(s, n, i, o, r, "next", e)
                        }

                        function r(e) {
                            a(s, n, i, o, r, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return p.apply(this, arguments)
                })
            }
        },
        l = (n(108), n(1)),
        g = Object(l.a)(u, i, [], !1, null, null, null);
    g.options.__file = "src/fido-wizard-steps/keyname-step.vue";
    t.a = g.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            staticClass: "syno-securesignin-authenticator-wizard-summary",
            attrs: {
                "syno-id": "secure-signin-authenticator-register-wizard-summary",
                "step-key": e.stepKey,
                headline: e.title,
                finished: e.finished,
                "next-step-key": e.nextStepKey
            }
        }, [n("div", {
            staticClass: "desc"
        }, [e._v("\n\t\t" + e._s(e.get_login_desc) + "\n\t")]), e._v(" "), n("div", {
            staticClass: "item-container"
        }, [n("div", {
            staticClass: "block login-method"
        }, [n("div", {
            staticClass: "title"
        }, [n("div", [e._v(e._s(e.get_login_method_title))])]), e._v(" "), n("div", {
            staticClass: "content"
        }, [n("div", [e._v(e._s(e.get_login_method_content))])])]), e._v(" "), n("div", {
            staticClass: "block device"
        }, [n("div", {
            staticClass: "title"
        }, [n("div", [e._v(e._s(e.TT("authenticator", "recv_sign_in_requests")))])]), e._v(" "), n("div", {
            staticClass: "content"
        }, [n("div", [e._v(e._s(e.curDevName))])])])])])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(2);

    function r(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function a(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }
    var c, d, p = {
            mixins: [s.a],
            props: {
                stepKey: String,
                nextStepKey: String
            },
            methods: {
                finished: (c = regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.$emit("close");
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), d = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = c.apply(e, t);

                        function o(e) {
                            a(s, n, i, o, r, "next", e)
                        }

                        function r(e) {
                            a(s, n, i, o, r, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return d.apply(this, arguments)
                })
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        r(e, t, n[t])
                    }))
                }
                return e
            }({
                isTwoFactorWizard: function() {
                    return "two-factor" === this.signinMode
                },
                title: function() {
                    return this.isTwoFactorWizard ? "on" !== this.otpStatus && this.otpEnabled ? this.TT("wizard", "add_new_signin_methods") : this.TT("wizard", "2fa_has_been_turned_on") : this.TT("common", "setup_success")
                },
                get_login_desc: function() {
                    return this.isTwoFactorWizard ? this.TT("authenticator", "2fa_setup_finish_desc") : this.TT("authenticator", "login_desc")
                },
                get_login_method_title: function() {
                    return this.TT("authenticator", "sign_in_method")
                },
                get_login_method_content: function() {
                    return "on" === this.otpStatus ? [this.TT("authenticator", "approve_sign_in"), this.T("personal_settings", "otp_verification_code")].join(", ") : this.TT("authenticator", "approve_sign_in")
                }
            }, Object(o.mapState)(["curDevName", "signinMode", "otpEnabled", "otpStatus"]))
        },
        u = (n(102), n(1)),
        l = Object(u.a)(p, i, [], !1, null, null, null);
    l.options.__file = "src/authenticator-wizard-steps/summary-step.vue";
    t.a = l.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            staticClass: "syno-securesignin-fido-wizard-summary",
            attrs: {
                "step-key": e.stepKey,
                headline: e.title,
                finished: e.finished,
                "syno-id": "secure-signin-fido-register-wizard-summary",
                "next-step-key": e.nextStepKey
            }
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isWin,
                expression: "isWin"
            }],
            staticClass: "desc"
        }, [e._v(e._s(e.isWinDesc))]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isMac,
                expression: "isMac"
            }],
            staticClass: "desc"
        }, [e._v(e._s(e.isMacDesc))])])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(2);

    function r(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function a(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var c, d, p = {
            mixins: [s.a],
            props: {
                nextStepKey: String,
                stepKey: String
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        a(e, t, n[t])
                    }))
                }
                return e
            }({
                isTwoFactorWizard: function() {
                    return "two-factor" === this.signinMode
                },
                title: function() {
                    return this.isTwoFactorWizard ? "on" !== this.otpStatus && this.otpEnabled ? this.TT("wizard", "add_new_signin_methods") : this.TT("wizard", "2fa_has_been_turned_on") : this.TT("fido", "security_key_registered")
                },
                isMac: function() {
                    return navigator.platform.indexOf("Mac") > -1
                },
                isWin: function() {
                    return navigator.platform.indexOf("Win") > -1
                },
                isWinDesc: function() {
                    return "on" === this.otpStatus ? this.TT("fido", "windows_hello_login_desc_with_otp") : this.isTwoFactorWizard ? this.TT("fido", "windows_hello_2fa_desc") : this.TT("fido", "windows_hello_login_desc")
                },
                isMacDesc: function() {
                    return "on" === this.otpStatus ? this.TT("fido", "touch_id_login_desc_with_otp") : this.isTwoFactorWizard ? this.TT("fido", "touch_id_2fa_desc") : this.TT("fido", "touch_id_login_desc")
                }
            }, Object(o.mapState)(["signinMode", "otpEnabled", "otpStatus"])),
            methods: {
                finished: (c = regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.$emit("close");
                            case 1:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), d = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = c.apply(e, t);

                        function o(e) {
                            r(s, n, i, o, a, "next", e)
                        }

                        function a(e) {
                            r(s, n, i, o, a, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return d.apply(this, arguments)
                })
            }
        },
        u = (n(112), n(1)),
        l = Object(u.a)(p, i, [], !1, null, null, null);
    l.options.__file = "src/fido-wizard-steps/summary-step.vue";
    t.a = l.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this.$createElement,
            t = this._self._c || e;
        return t("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-fido-wizard-register",
            attrs: {
                "step-key": this.stepKey,
                headline: this.title,
                "next-step-key": this.nextStepKey,
                "syno-id": "secure-signin-fido-register-wizard-register"
            },
            on: {
                activate: this.registerFido
            }
        }, [t("div", {
            staticClass: "register-loading-box"
        }, [t("div", {
            staticClass: "register-loader"
        })]), this._v(" "), t("div", {
            staticClass: "scanning-key-box",
            domProps: {
                innerHTML: this._s(this.scanning)
            }
        })])
    };
    i._withStripped = !0;
    var s = n(3),
        o = n(0),
        r = n(6),
        a = n(2);

    function c(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function d(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    c(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    c(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function p(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var u = {
            mixins: [s.a, o.a, r.a],
            props: {
                stepKey: String,
                onRegistered: Function
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        p(e, t, n[t])
                    }))
                }
                return e
            }({
                title: function() {
                    return "usb" === this.methodSelect ? this.TT("fido", "usb_key_reg") : "windows" === this.methodSelect ? this.TT("fido", "windows_hello_reg") : "touchID" === this.methodSelect ? this.TT("fido", "touch_id_reg") : "unsupported method"
                },
                scanning: function() {
                    return "usb" === this.methodSelect ? this.TT("fido", "usb_key_reg_desc") : "windows" === this.methodSelect || "touchID" === this.methodSelect ? this.TT("fido", "follow_steps") : "unsupported method"
                }
            }, Object(a.mapState)(["methodSelect", "otpEnabled", "password", "signinMode", "username"])),
            data: function() {
                return {
                    userVerification: "preferred",
                    nextStepKey: ""
                }
            },
            methods: {
                registerFido: function() {
                    var e, t = this;
                    e = _S("isLogined") ? {
                        api: "SYNO.SecureSignIn.Fido.Register",
                        method: "get_attest",
                        version: 1
                    } : {
                        api: "SYNO.SecureSignIn.Fido.Register.Ex",
                        method: "get_attest",
                        version: 1,
                        params: {
                            username: this.$store.state.username,
                            password: this.$store.state.password
                        },
                        encryption: ["username", "password"]
                    }, synowebapi.promises.request(e).then((function(e) {
                        return e.challenge = t.str2ab(e.challenge), e.user.id = t.str2ab(e.user.id), e.pubKeyCredParams = e.pubKeyCreds, e.authenticatorSelection = {
                            authenticatorAttachment: "usb" === t.methodSelect ? "cross-platform" : "platform",
                            userVerification: t.userVerification
                        }, e.excludeCredentials.forEach(function(e) {
                            e.id = this.coerceToArrayBuffer(e.id)
                        }.bind(t)), navigator.credentials.create({
                            publicKey: e
                        })
                    })).then((function(n) {
                        var i = {
                            id: n.id,
                            attestationObj: t.coerceToBase64(n.response.attestationObject),
                            clientData: t.coerceToBase64(n.response.clientDataJSON),
                            userVerification: t.userVerification,
                            keytype: t.methodSelect
                        };
                        return e = _S("isLogined") ? {
                            api: "SYNO.SecureSignIn.Fido.Register",
                            method: "register",
                            version: 1,
                            params: i
                        } : {
                            api: "SYNO.SecureSignIn.Fido.Register.Ex",
                            method: "register",
                            version: 1,
                            params: Object.assign({
                                username: t.$store.state.username,
                                password: t.$store.state.password
                            }, i),
                            encryption: ["username", "password"]
                        }, synowebapi.promises.request(e)
                    })).then((function(e) {
                        return t.$store.commit("SET_FIDO_UID", e.uid), t.setSigninMethod("on", t.signinMode, t.username, t.password)
                    })).then(d(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if ("two-factor" !== t.signinMode) {
                                        e.next = 4;
                                        break
                                    }
                                    t.otpEnabled ? t.nextStepKey = "usb" === t.methodSelect ? "fido-keyname-step" : "fido-summary-step" : t.nextStepKey = "otp-welcome-step", e.next = 8;
                                    break;
                                case 4:
                                    if (!t.otpEnabled) {
                                        e.next = 7;
                                        break
                                    }
                                    return e.next = 7, t.revokeOTP();
                                case 7:
                                    t.nextStepKey = "usb" === t.methodSelect ? "fido-keyname-step" : "fido-summary-step";
                                case 8:
                                    t.$refs.step.nextStep();
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })))).catch((function(e) {
                        11 === e.code && t.$store.commit("SET_FIDO_ERR", t.TT("fido", "register_duplicate_key")), t.nextStepKey = "fido-error-step", t.$refs.step.nextStep()
                    }))
                }
            }
        },
        l = (n(106), n(1)),
        g = Object(l.a)(u, i, [], !1, null, null, null);
    g.options.__file = "src/fido-wizard-steps/register-step.vue";
    t.a = g.exports
}, function(e, t, n) {
    "use strict";
    var i = n(2);
    var s = new(n.n(i).a.Store)({
        state: {
            signinMode: "",
            username: "",
            password: "",
            isSkipOtp: !1,
            inheritStatus: "",
            backupEmail: "",
            ldapServerAddr: "",
            otpImg: "",
            otpName: "",
            otpSecret: "",
            otpEnabled: !1,
            userDn: "",
            otpStatus: "",
            authenticatorId: "",
            fidoUid: NaN,
            curDevName: "",
            methodSelect: "",
            fidoErrMsg: ""
        },
        mutations: {
            RESET: function(e) {
                var t = {
                    signinMode: "",
                    username: "",
                    password: "",
                    isSkipOtp: !1,
                    inheritStatus: "",
                    backupEmail: "",
                    ldapServerAddr: "",
                    otpImg: "",
                    otpName: "",
                    otpSecret: "",
                    otpEnabled: !1,
                    userDn: "",
                    otpStatus: "",
                    authenticatorId: "",
                    fidoUid: NaN,
                    curDevName: "",
                    methodSelect: "",
                    fidoErrMsg: ""
                };
                Object.keys(t).forEach((function(n) {
                    e[n] = t[n]
                }))
            },
            SET_SIGNIN_MODE: function(e, t) {
                e.signinMode = t
            },
            SET_USERNAME: function(e, t) {
                e.username = t
            },
            SET_PASSWORD: function(e, t) {
                e.password = t
            },
            SET_BACKUP_EMAIL: function(e, t) {
                e.backupEmail = t
            },
            SET_LDAP_SERVER_ADDR: function(e, t) {
                e.ldapServerAddr = t
            },
            SET_OTP_IMG: function(e, t) {
                e.otpImg = t
            },
            SET_OTP_NAME: function(e, t) {
                e.otpName = t
            },
            SET_OTP_SECRET: function(e, t) {
                e.otpSecret = t
            },
            SET_OTP_ENABLED: function(e, t) {
                e.otpEnabled = t
            },
            SET_USER_DN: function(e, t) {
                e.userDn = t
            },
            SET_AUTHENTICATOR_ID: function(e, t) {
                e.authenticatorId = t
            },
            SET_FIDO_UID: function(e, t) {
                e.fidoUid = t
            },
            SET_CUR_DEV_NAME: function(e, t) {
                e.curDevName = t
            },
            SET_METHOD_SELECT: function(e, t) {
                e.methodSelect = t
            },
            SET_OTP_STATUS: function(e, t) {
                e.otpStatus = t
            },
            SET_SKIP_OTP: function(e, t) {
                e.isSkipOtp = t
            },
            SET_FIDO_ERR: function(e, t) {
                e.fidoErrMsg = t
            },
            SET_INHERIT_STATUS: function(e, t) {
                e.inheritStatus = t
            }
        }
    });
    t.a = s
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/b705dbd6f0a024ec89a772f117d03d35.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/f1cbdb19756532907cf317bd5e5f93da.png"
}, function(e, t, n) {
    "use strict";
    t.a = {
        methods: {
            openUnregisteredMsgBox: function(e) {
                var t;
                t = _S("isLogined") && _S("is_admin") ? String.format(this.TT("authenticator", "private_ip_error_msg_admin_with_params"), '<a class="open-page quickconnect">', "</a>", '<a class="open-page ddns">', "</a>", '<a class="open-page advance-setting">', "</a>") : this.TT("authenticator", "private_ip_error_msg_user");
                var n = e.getMsgBox();
                n.alert(this.TT("authenticator", "register_unavailable_title"), t, null, {
                    useHtml: !0
                }), n.$el.getElementsByClassName("message-box").forEach((function(e) {
                    e.addEventListener("click", (function(e) {
                        e.target.matches(".ddns") ? (e.stopPropagation(), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                            fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                            tab: "ddnstab"
                        })) : e.target.matches(".quickconnect") ? (e.stopPropagation(), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                            fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                            tab: "quickconnecttab"
                        })) : (e.target.matches(".advance-setting") || e.target.parentElement && e.target.parentElement.matches(".advance-setting")) && (e.stopPropagation(), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                            fn: "SYNO.SDS.AdminCenter.PublicAccess.Main",
                            tab: "advancetab"
                        }))
                    }))
                }))
            }
        }
    }
}, function(e, t, n) {
    var i, s, o;

    function r(e) {
        return (r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }
    o = function() {
        "use strict";

        function e() {
            throw new Error("Dynamic requires are not currently supported by rollup-plugin-commonjs")
        }
        var t = function(e, t) {
            return e(t = {
                exports: {}
            }, t.exports), t.exports
        }((function(t, n) {
            t.exports = function t(n, i, s) {
                function o(a, c) {
                    if (!i[a]) {
                        if (!n[a]) {
                            if (!c && e) return e();
                            if (r) return r(a, !0);
                            var d = new Error("Cannot find module '" + a + "'");
                            throw d.code = "MODULE_NOT_FOUND", d
                        }
                        var p = i[a] = {
                            exports: {}
                        };
                        n[a][0].call(p.exports, (function(e) {
                            return o(n[a][1][e] || e)
                        }), p, p.exports, t, n, i, s)
                    }
                    return i[a].exports
                }
                for (var r = e, a = 0; a < s.length; a++) o(s[a]);
                return o
            }({
                1: [function(e, t, n) {
                    t.exports = function() {
                        return "function" == typeof Promise && Promise.prototype && Promise.prototype.then
                    }
                }, {}],
                2: [function(e, t, n) {
                    var i = e("./utils").getSymbolSize;
                    n.getRowColCoords = function(e) {
                        if (1 === e) return [];
                        for (var t = Math.floor(e / 7) + 2, n = i(e), s = 145 === n ? 26 : 2 * Math.ceil((n - 13) / (2 * t - 2)), o = [n - 7], r = 1; r < t - 1; r++) o[r] = o[r - 1] - s;
                        return o.push(6), o.reverse()
                    }, n.getPositions = function(e) {
                        for (var t = [], i = n.getRowColCoords(e), s = i.length, o = 0; o < s; o++)
                            for (var r = 0; r < s; r++) 0 === o && 0 === r || 0 === o && r === s - 1 || o === s - 1 && 0 === r || t.push([i[o], i[r]]);
                        return t
                    }
                }, {
                    "./utils": 21
                }],
                3: [function(e, t, n) {
                    var i = e("./mode"),
                        s = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", " ", "$", "%", "*", "+", "-", ".", "/", ":"];

                    function o(e) {
                        this.mode = i.ALPHANUMERIC, this.data = e
                    }
                    o.getBitsLength = function(e) {
                        return 11 * Math.floor(e / 2) + e % 2 * 6
                    }, o.prototype.getLength = function() {
                        return this.data.length
                    }, o.prototype.getBitsLength = function() {
                        return o.getBitsLength(this.data.length)
                    }, o.prototype.write = function(e) {
                        var t;
                        for (t = 0; t + 2 <= this.data.length; t += 2) {
                            var n = 45 * s.indexOf(this.data[t]);
                            n += s.indexOf(this.data[t + 1]), e.put(n, 11)
                        }
                        this.data.length % 2 && e.put(s.indexOf(this.data[t]), 6)
                    }, t.exports = o
                }, {
                    "./mode": 14
                }],
                4: [function(e, t, n) {
                    function i() {
                        this.buffer = [], this.length = 0
                    }
                    i.prototype = {
                        get: function(e) {
                            var t = Math.floor(e / 8);
                            return 1 == (this.buffer[t] >>> 7 - e % 8 & 1)
                        },
                        put: function(e, t) {
                            for (var n = 0; n < t; n++) this.putBit(1 == (e >>> t - n - 1 & 1))
                        },
                        getLengthInBits: function() {
                            return this.length
                        },
                        putBit: function(e) {
                            var t = Math.floor(this.length / 8);
                            this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), this.length++
                        }
                    }, t.exports = i
                }, {}],
                5: [function(e, t, n) {
                    var i = e("../utils/buffer");

                    function s(e) {
                        if (!e || e < 1) throw new Error("BitMatrix size must be defined and greater than 0");
                        this.size = e, this.data = new i(e * e), this.data.fill(0), this.reservedBit = new i(e * e), this.reservedBit.fill(0)
                    }
                    s.prototype.set = function(e, t, n, i) {
                        var s = e * this.size + t;
                        this.data[s] = n, i && (this.reservedBit[s] = !0)
                    }, s.prototype.get = function(e, t) {
                        return this.data[e * this.size + t]
                    }, s.prototype.xor = function(e, t, n) {
                        this.data[e * this.size + t] ^= n
                    }, s.prototype.isReserved = function(e, t) {
                        return this.reservedBit[e * this.size + t]
                    }, t.exports = s
                }, {
                    "../utils/buffer": 28
                }],
                6: [function(e, t, n) {
                    var i = e("../utils/buffer"),
                        s = e("./mode");

                    function o(e) {
                        this.mode = s.BYTE, this.data = new i(e)
                    }
                    o.getBitsLength = function(e) {
                        return 8 * e
                    }, o.prototype.getLength = function() {
                        return this.data.length
                    }, o.prototype.getBitsLength = function() {
                        return o.getBitsLength(this.data.length)
                    }, o.prototype.write = function(e) {
                        for (var t = 0, n = this.data.length; t < n; t++) e.put(this.data[t], 8)
                    }, t.exports = o
                }, {
                    "../utils/buffer": 28,
                    "./mode": 14
                }],
                7: [function(e, t, n) {
                    var i = e("./error-correction-level"),
                        s = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 1, 2, 2, 4, 1, 2, 4, 4, 2, 4, 4, 4, 2, 4, 6, 5, 2, 4, 6, 6, 2, 5, 8, 8, 4, 5, 8, 8, 4, 5, 8, 11, 4, 8, 10, 11, 4, 9, 12, 16, 4, 9, 16, 16, 6, 10, 12, 18, 6, 10, 17, 16, 6, 11, 16, 19, 6, 13, 18, 21, 7, 14, 21, 25, 8, 16, 20, 25, 8, 17, 23, 25, 9, 17, 23, 34, 9, 18, 25, 30, 10, 20, 27, 32, 12, 21, 29, 35, 12, 23, 34, 37, 12, 25, 34, 40, 13, 26, 35, 42, 14, 28, 38, 45, 15, 29, 40, 48, 16, 31, 43, 51, 17, 33, 45, 54, 18, 35, 48, 57, 19, 37, 51, 60, 19, 38, 53, 63, 20, 40, 56, 66, 21, 43, 59, 70, 22, 45, 62, 74, 24, 47, 65, 77, 25, 49, 68, 81],
                        o = [7, 10, 13, 17, 10, 16, 22, 28, 15, 26, 36, 44, 20, 36, 52, 64, 26, 48, 72, 88, 36, 64, 96, 112, 40, 72, 108, 130, 48, 88, 132, 156, 60, 110, 160, 192, 72, 130, 192, 224, 80, 150, 224, 264, 96, 176, 260, 308, 104, 198, 288, 352, 120, 216, 320, 384, 132, 240, 360, 432, 144, 280, 408, 480, 168, 308, 448, 532, 180, 338, 504, 588, 196, 364, 546, 650, 224, 416, 600, 700, 224, 442, 644, 750, 252, 476, 690, 816, 270, 504, 750, 900, 300, 560, 810, 960, 312, 588, 870, 1050, 336, 644, 952, 1110, 360, 700, 1020, 1200, 390, 728, 1050, 1260, 420, 784, 1140, 1350, 450, 812, 1200, 1440, 480, 868, 1290, 1530, 510, 924, 1350, 1620, 540, 980, 1440, 1710, 570, 1036, 1530, 1800, 570, 1064, 1590, 1890, 600, 1120, 1680, 1980, 630, 1204, 1770, 2100, 660, 1260, 1860, 2220, 720, 1316, 1950, 2310, 750, 1372, 2040, 2430];
                    n.getBlocksCount = function(e, t) {
                        switch (t) {
                            case i.L:
                                return s[4 * (e - 1) + 0];
                            case i.M:
                                return s[4 * (e - 1) + 1];
                            case i.Q:
                                return s[4 * (e - 1) + 2];
                            case i.H:
                                return s[4 * (e - 1) + 3];
                            default:
                                return
                        }
                    }, n.getTotalCodewordsCount = function(e, t) {
                        switch (t) {
                            case i.L:
                                return o[4 * (e - 1) + 0];
                            case i.M:
                                return o[4 * (e - 1) + 1];
                            case i.Q:
                                return o[4 * (e - 1) + 2];
                            case i.H:
                                return o[4 * (e - 1) + 3];
                            default:
                                return
                        }
                    }
                }, {
                    "./error-correction-level": 8
                }],
                8: [function(e, t, n) {
                    n.L = {
                        bit: 1
                    }, n.M = {
                        bit: 0
                    }, n.Q = {
                        bit: 3
                    }, n.H = {
                        bit: 2
                    }, n.isValid = function(e) {
                        return e && void 0 !== e.bit && e.bit >= 0 && e.bit < 4
                    }, n.from = function(e, t) {
                        if (n.isValid(e)) return e;
                        try {
                            return function(e) {
                                if ("string" != typeof e) throw new Error("Param is not a string");
                                switch (e.toLowerCase()) {
                                    case "l":
                                    case "low":
                                        return n.L;
                                    case "m":
                                    case "medium":
                                        return n.M;
                                    case "q":
                                    case "quartile":
                                        return n.Q;
                                    case "h":
                                    case "high":
                                        return n.H;
                                    default:
                                        throw new Error("Unknown EC Level: " + e)
                                }
                            }(e)
                        } catch (e) {
                            return t
                        }
                    }
                }, {}],
                9: [function(e, t, n) {
                    var i = e("./utils").getSymbolSize;
                    n.getPositions = function(e) {
                        var t = i(e);
                        return [
                            [0, 0],
                            [t - 7, 0],
                            [0, t - 7]
                        ]
                    }
                }, {
                    "./utils": 21
                }],
                10: [function(e, t, n) {
                    var i = e("./utils"),
                        s = i.getBCHDigit(1335);
                    n.getEncodedBits = function(e, t) {
                        for (var n = e.bit << 3 | t, o = n << 10; i.getBCHDigit(o) - s >= 0;) o ^= 1335 << i.getBCHDigit(o) - s;
                        return 21522 ^ (n << 10 | o)
                    }
                }, {
                    "./utils": 21
                }],
                11: [function(e, t, n) {
                    var i = e("../utils/buffer");
                    if (i.alloc) var s = i.alloc(512),
                        o = i.alloc(256);
                    else s = new i(512), o = new i(256);
                    ! function() {
                        for (var e = 1, t = 0; t < 255; t++) s[t] = e, o[e] = t, 256 & (e <<= 1) && (e ^= 285);
                        for (t = 255; t < 512; t++) s[t] = s[t - 255]
                    }(), n.log = function(e) {
                        if (e < 1) throw new Error("log(" + e + ")");
                        return o[e]
                    }, n.exp = function(e) {
                        return s[e]
                    }, n.mul = function(e, t) {
                        return 0 === e || 0 === t ? 0 : s[o[e] + o[t]]
                    }
                }, {
                    "../utils/buffer": 28
                }],
                12: [function(e, t, n) {
                    var i = e("./mode"),
                        s = e("./utils");

                    function o(e) {
                        this.mode = i.KANJI, this.data = e
                    }
                    o.getBitsLength = function(e) {
                        return 13 * e
                    }, o.prototype.getLength = function() {
                        return this.data.length
                    }, o.prototype.getBitsLength = function() {
                        return o.getBitsLength(this.data.length)
                    }, o.prototype.write = function(e) {
                        var t;
                        for (t = 0; t < this.data.length; t++) {
                            var n = s.toSJIS(this.data[t]);
                            if (n >= 33088 && n <= 40956) n -= 33088;
                            else {
                                if (!(n >= 57408 && n <= 60351)) throw new Error("Invalid SJIS character: " + this.data[t] + "\nMake sure your charset is UTF-8");
                                n -= 49472
                            }
                            n = 192 * (n >>> 8 & 255) + (255 & n), e.put(n, 13)
                        }
                    }, t.exports = o
                }, {
                    "./mode": 14,
                    "./utils": 21
                }],
                13: [function(e, t, n) {
                    n.Patterns = {
                        PATTERN000: 0,
                        PATTERN001: 1,
                        PATTERN010: 2,
                        PATTERN011: 3,
                        PATTERN100: 4,
                        PATTERN101: 5,
                        PATTERN110: 6,
                        PATTERN111: 7
                    };
                    var i = 3,
                        s = 3,
                        o = 40,
                        r = 10;

                    function a(e, t, i) {
                        switch (e) {
                            case n.Patterns.PATTERN000:
                                return (t + i) % 2 == 0;
                            case n.Patterns.PATTERN001:
                                return t % 2 == 0;
                            case n.Patterns.PATTERN010:
                                return i % 3 == 0;
                            case n.Patterns.PATTERN011:
                                return (t + i) % 3 == 0;
                            case n.Patterns.PATTERN100:
                                return (Math.floor(t / 2) + Math.floor(i / 3)) % 2 == 0;
                            case n.Patterns.PATTERN101:
                                return t * i % 2 + t * i % 3 == 0;
                            case n.Patterns.PATTERN110:
                                return (t * i % 2 + t * i % 3) % 2 == 0;
                            case n.Patterns.PATTERN111:
                                return (t * i % 3 + (t + i) % 2) % 2 == 0;
                            default:
                                throw new Error("bad maskPattern:" + e)
                        }
                    }
                    n.isValid = function(e) {
                        return null != e && "" !== e && !isNaN(e) && e >= 0 && e <= 7
                    }, n.from = function(e) {
                        return n.isValid(e) ? parseInt(e, 10) : void 0
                    }, n.getPenaltyN1 = function(e) {
                        for (var t = e.size, n = 0, s = 0, o = 0, r = null, a = null, c = 0; c < t; c++) {
                            s = o = 0, r = a = null;
                            for (var d = 0; d < t; d++) {
                                var p = e.get(c, d);
                                p === r ? s++ : (s >= 5 && (n += i + (s - 5)), r = p, s = 1), (p = e.get(d, c)) === a ? o++ : (o >= 5 && (n += i + (o - 5)), a = p, o = 1)
                            }
                            s >= 5 && (n += i + (s - 5)), o >= 5 && (n += i + (o - 5))
                        }
                        return n
                    }, n.getPenaltyN2 = function(e) {
                        for (var t = e.size, n = 0, i = 0; i < t - 1; i++)
                            for (var o = 0; o < t - 1; o++) {
                                var r = e.get(i, o) + e.get(i, o + 1) + e.get(i + 1, o) + e.get(i + 1, o + 1);
                                4 !== r && 0 !== r || n++
                            }
                        return n * s
                    }, n.getPenaltyN3 = function(e) {
                        for (var t = e.size, n = 0, i = 0, s = 0, r = 0; r < t; r++) {
                            i = s = 0;
                            for (var a = 0; a < t; a++) i = i << 1 & 2047 | e.get(r, a), a >= 10 && (1488 === i || 93 === i) && n++, s = s << 1 & 2047 | e.get(a, r), a >= 10 && (1488 === s || 93 === s) && n++
                        }
                        return n * o
                    }, n.getPenaltyN4 = function(e) {
                        for (var t = 0, n = e.data.length, i = 0; i < n; i++) t += e.data[i];
                        return Math.abs(Math.ceil(100 * t / n / 5) - 10) * r
                    }, n.applyMask = function(e, t) {
                        for (var n = t.size, i = 0; i < n; i++)
                            for (var s = 0; s < n; s++) t.isReserved(s, i) || t.xor(s, i, a(e, s, i))
                    }, n.getBestMask = function(e, t) {
                        for (var i = Object.keys(n.Patterns).length, s = 0, o = 1 / 0, r = 0; r < i; r++) {
                            t(r), n.applyMask(r, e);
                            var a = n.getPenaltyN1(e) + n.getPenaltyN2(e) + n.getPenaltyN3(e) + n.getPenaltyN4(e);
                            n.applyMask(r, e), a < o && (o = a, s = r)
                        }
                        return s
                    }
                }, {}],
                14: [function(e, t, n) {
                    var i = e("./version-check"),
                        s = e("./regex");
                    n.NUMERIC = {
                        id: "Numeric",
                        bit: 1,
                        ccBits: [10, 12, 14]
                    }, n.ALPHANUMERIC = {
                        id: "Alphanumeric",
                        bit: 2,
                        ccBits: [9, 11, 13]
                    }, n.BYTE = {
                        id: "Byte",
                        bit: 4,
                        ccBits: [8, 16, 16]
                    }, n.KANJI = {
                        id: "Kanji",
                        bit: 8,
                        ccBits: [8, 10, 12]
                    }, n.MIXED = {
                        bit: -1
                    }, n.getCharCountIndicator = function(e, t) {
                        if (!e.ccBits) throw new Error("Invalid mode: " + e);
                        if (!i.isValid(t)) throw new Error("Invalid version: " + t);
                        return t >= 1 && t < 10 ? e.ccBits[0] : t < 27 ? e.ccBits[1] : e.ccBits[2]
                    }, n.getBestModeForData = function(e) {
                        return s.testNumeric(e) ? n.NUMERIC : s.testAlphanumeric(e) ? n.ALPHANUMERIC : s.testKanji(e) ? n.KANJI : n.BYTE
                    }, n.toString = function(e) {
                        if (e && e.id) return e.id;
                        throw new Error("Invalid mode")
                    }, n.isValid = function(e) {
                        return e && e.bit && e.ccBits
                    }, n.from = function(e, t) {
                        if (n.isValid(e)) return e;
                        try {
                            return function(e) {
                                if ("string" != typeof e) throw new Error("Param is not a string");
                                switch (e.toLowerCase()) {
                                    case "numeric":
                                        return n.NUMERIC;
                                    case "alphanumeric":
                                        return n.ALPHANUMERIC;
                                    case "kanji":
                                        return n.KANJI;
                                    case "byte":
                                        return n.BYTE;
                                    default:
                                        throw new Error("Unknown mode: " + e)
                                }
                            }(e)
                        } catch (e) {
                            return t
                        }
                    }
                }, {
                    "./regex": 19,
                    "./version-check": 22
                }],
                15: [function(e, t, n) {
                    var i = e("./mode");

                    function s(e) {
                        this.mode = i.NUMERIC, this.data = e.toString()
                    }
                    s.getBitsLength = function(e) {
                        return 10 * Math.floor(e / 3) + (e % 3 ? e % 3 * 3 + 1 : 0)
                    }, s.prototype.getLength = function() {
                        return this.data.length
                    }, s.prototype.getBitsLength = function() {
                        return s.getBitsLength(this.data.length)
                    }, s.prototype.write = function(e) {
                        var t, n, i;
                        for (t = 0; t + 3 <= this.data.length; t += 3) n = this.data.substr(t, 3), i = parseInt(n, 10), e.put(i, 10);
                        var s = this.data.length - t;
                        s > 0 && (n = this.data.substr(t), i = parseInt(n, 10), e.put(i, 3 * s + 1))
                    }, t.exports = s
                }, {
                    "./mode": 14
                }],
                16: [function(e, t, n) {
                    var i = e("../utils/buffer"),
                        s = e("./galois-field");
                    n.mul = function(e, t) {
                        var n = new i(e.length + t.length - 1);
                        n.fill(0);
                        for (var o = 0; o < e.length; o++)
                            for (var r = 0; r < t.length; r++) n[o + r] ^= s.mul(e[o], t[r]);
                        return n
                    }, n.mod = function(e, t) {
                        for (var n = new i(e); n.length - t.length >= 0;) {
                            for (var o = n[0], r = 0; r < t.length; r++) n[r] ^= s.mul(t[r], o);
                            for (var a = 0; a < n.length && 0 === n[a];) a++;
                            n = n.slice(a)
                        }
                        return n
                    }, n.generateECPolynomial = function(e) {
                        for (var t = new i([1]), o = 0; o < e; o++) t = n.mul(t, [1, s.exp(o)]);
                        return t
                    }
                }, {
                    "../utils/buffer": 28,
                    "./galois-field": 11
                }],
                17: [function(e, t, n) {
                    var i = e("../utils/buffer"),
                        s = e("./utils"),
                        o = e("./error-correction-level"),
                        r = e("./bit-buffer"),
                        a = e("./bit-matrix"),
                        c = e("./alignment-pattern"),
                        d = e("./finder-pattern"),
                        p = e("./mask-pattern"),
                        u = e("./error-correction-code"),
                        l = e("./reed-solomon-encoder"),
                        g = e("./version"),
                        h = e("./format-info"),
                        f = e("./mode"),
                        m = e("./segments"),
                        w = e("isarray");

                    function v(e, t, n) {
                        var i, s, o = e.size,
                            r = h.getEncodedBits(t, n);
                        for (i = 0; i < 15; i++) s = 1 == (r >> i & 1), i < 6 ? e.set(i, 8, s, !0) : i < 8 ? e.set(i + 1, 8, s, !0) : e.set(o - 15 + i, 8, s, !0), i < 8 ? e.set(8, o - i - 1, s, !0) : i < 9 ? e.set(8, 15 - i - 1 + 1, s, !0) : e.set(8, 15 - i - 1, s, !0);
                        e.set(o - 8, 8, 1, !0)
                    }

                    function y(e, t, n) {
                        var o = new r;
                        n.forEach((function(t) {
                            o.put(t.mode.bit, 4), o.put(t.getLength(), f.getCharCountIndicator(t.mode, e)), t.write(o)
                        }));
                        var a = 8 * (s.getSymbolTotalCodewords(e) - u.getTotalCodewordsCount(e, t));
                        for (o.getLengthInBits() + 4 <= a && o.put(0, 4); o.getLengthInBits() % 8 != 0;) o.putBit(0);
                        for (var c = (a - o.getLengthInBits()) / 8, d = 0; d < c; d++) o.put(d % 2 ? 17 : 236, 8);
                        return function(e, t, n) {
                            for (var o = s.getSymbolTotalCodewords(t), r = u.getTotalCodewordsCount(t, n), a = o - r, c = u.getBlocksCount(t, n), d = c - o % c, p = Math.floor(o / c), g = Math.floor(a / c), h = g + 1, f = p - g, m = new l(f), w = 0, v = new Array(c), y = new Array(c), x = 0, b = new i(e.buffer), _ = 0; _ < c; _++) {
                                var S = _ < d ? g : h;
                                v[_] = b.slice(w, w + S), y[_] = m.encode(v[_]), w += S, x = Math.max(x, S)
                            }
                            var k, T, E = new i(o),
                                O = 0;
                            for (k = 0; k < x; k++)
                                for (T = 0; T < c; T++) k < v[T].length && (E[O++] = v[T][k]);
                            for (k = 0; k < f; k++)
                                for (T = 0; T < c; T++) E[O++] = y[T][k];
                            return E
                        }(o, e, t)
                    }

                    function x(e, t, n, i) {
                        var o;
                        if (w(e)) o = m.fromArray(e);
                        else {
                            if ("string" != typeof e) throw new Error("Invalid data");
                            var r = t;
                            if (!r) {
                                var u = m.rawSplit(e);
                                r = g.getBestVersionForData(u, n)
                            }
                            o = m.fromString(e, r || 40)
                        }
                        var l = g.getBestVersionForData(o, n);
                        if (!l) throw new Error("The amount of data is too big to be stored in a QR Code");
                        if (t) {
                            if (t < l) throw new Error("\nThe chosen QR Code version cannot contain this amount of data.\nMinimum version required to store current data is: " + l + ".\n")
                        } else t = l;
                        var h = y(t, n, o),
                            f = s.getSymbolSize(t),
                            x = new a(f);
                        return function(e, t) {
                                for (var n = e.size, i = d.getPositions(t), s = 0; s < i.length; s++)
                                    for (var o = i[s][0], r = i[s][1], a = -1; a <= 7; a++)
                                        if (!(o + a <= -1 || n <= o + a))
                                            for (var c = -1; c <= 7; c++) r + c <= -1 || n <= r + c || (a >= 0 && a <= 6 && (0 === c || 6 === c) || c >= 0 && c <= 6 && (0 === a || 6 === a) || a >= 2 && a <= 4 && c >= 2 && c <= 4 ? e.set(o + a, r + c, !0, !0) : e.set(o + a, r + c, !1, !0))
                            }(x, t),
                            function(e) {
                                for (var t = e.size, n = 8; n < t - 8; n++) {
                                    var i = n % 2 == 0;
                                    e.set(n, 6, i, !0), e.set(6, n, i, !0)
                                }
                            }(x),
                            function(e, t) {
                                for (var n = c.getPositions(t), i = 0; i < n.length; i++)
                                    for (var s = n[i][0], o = n[i][1], r = -2; r <= 2; r++)
                                        for (var a = -2; a <= 2; a++) - 2 === r || 2 === r || -2 === a || 2 === a || 0 === r && 0 === a ? e.set(s + r, o + a, !0, !0) : e.set(s + r, o + a, !1, !0)
                            }(x, t), v(x, n, 0), t >= 7 && function(e, t) {
                                for (var n, i, s, o = e.size, r = g.getEncodedBits(t), a = 0; a < 18; a++) n = Math.floor(a / 3), i = a % 3 + o - 8 - 3, s = 1 == (r >> a & 1), e.set(n, i, s, !0), e.set(i, n, s, !0)
                            }(x, t),
                            function(e, t) {
                                for (var n = e.size, i = -1, s = n - 1, o = 7, r = 0, a = n - 1; a > 0; a -= 2)
                                    for (6 === a && a--;;) {
                                        for (var c = 0; c < 2; c++)
                                            if (!e.isReserved(s, a - c)) {
                                                var d = !1;
                                                r < t.length && (d = 1 == (t[r] >>> o & 1)), e.set(s, a - c, d), -1 == --o && (r++, o = 7)
                                            } if ((s += i) < 0 || n <= s) {
                                            s -= i, i = -i;
                                            break
                                        }
                                    }
                            }(x, h), isNaN(i) && (i = p.getBestMask(x, v.bind(null, x, n))), p.applyMask(i, x), v(x, n, i), {
                                modules: x,
                                version: t,
                                errorCorrectionLevel: n,
                                maskPattern: i,
                                segments: o
                            }
                    }
                    n.create = function(e, t) {
                        if (void 0 === e || "" === e) throw new Error("No input text");
                        var n, i, r = o.M;
                        return void 0 !== t && (r = o.from(t.errorCorrectionLevel, o.M), n = g.from(t.version), i = p.from(t.maskPattern), t.toSJISFunc && s.setToSJISFunction(t.toSJISFunc)), x(e, n, r, i)
                    }
                }, {
                    "../utils/buffer": 28,
                    "./alignment-pattern": 2,
                    "./bit-buffer": 4,
                    "./bit-matrix": 5,
                    "./error-correction-code": 7,
                    "./error-correction-level": 8,
                    "./finder-pattern": 9,
                    "./format-info": 10,
                    "./mask-pattern": 13,
                    "./mode": 14,
                    "./reed-solomon-encoder": 18,
                    "./segments": 20,
                    "./utils": 21,
                    "./version": 23,
                    isarray: 30
                }],
                18: [function(e, t, n) {
                    var i = e("../utils/buffer"),
                        s = e("./polynomial");

                    function o(e) {
                        this.genPoly = void 0, this.degree = e, this.degree && this.initialize(this.degree)
                    }
                    o.prototype.initialize = function(e) {
                        this.degree = e, this.genPoly = s.generateECPolynomial(this.degree)
                    }, o.prototype.encode = function(e) {
                        if (!this.genPoly) throw new Error("Encoder not initialized");
                        var t = new i(this.degree);
                        t.fill(0);
                        var n = i.concat([e, t], e.length + this.degree),
                            o = s.mod(n, this.genPoly),
                            r = this.degree - o.length;
                        if (r > 0) {
                            var a = new i(this.degree);
                            return a.fill(0), o.copy(a, r), a
                        }
                        return o
                    }, t.exports = o
                }, {
                    "../utils/buffer": 28,
                    "./polynomial": 16
                }],
                19: [function(e, t, n) {
                    var i = "(?:[u3000-u303F]|[u3040-u309F]|[u30A0-u30FF]|[uFF00-uFFEF]|[u4E00-u9FAF]|[u2605-u2606]|[u2190-u2195]|u203B|[u2010u2015u2018u2019u2025u2026u201Cu201Du2225u2260]|[u0391-u0451]|[u00A7u00A8u00B1u00B4u00D7u00F7])+",
                        s = "(?:(?![A-Z0-9 $%*+\\-./:]|" + (i = i.replace(/u/g, "\\u")) + ")(?:.|[\r\n]))+";
                    n.KANJI = new RegExp(i, "g"), n.BYTE_KANJI = new RegExp("[^A-Z0-9 $%*+\\-./:]+", "g"), n.BYTE = new RegExp(s, "g"), n.NUMERIC = new RegExp("[0-9]+", "g"), n.ALPHANUMERIC = new RegExp("[A-Z $%*+\\-./:]+", "g");
                    var o = new RegExp("^" + i + "$"),
                        r = new RegExp("^[0-9]+$"),
                        a = new RegExp("^[A-Z0-9 $%*+\\-./:]+$");
                    n.testKanji = function(e) {
                        return o.test(e)
                    }, n.testNumeric = function(e) {
                        return r.test(e)
                    }, n.testAlphanumeric = function(e) {
                        return a.test(e)
                    }
                }, {}],
                20: [function(e, t, n) {
                    var i = e("./mode"),
                        s = e("./numeric-data"),
                        o = e("./alphanumeric-data"),
                        r = e("./byte-data"),
                        a = e("./kanji-data"),
                        c = e("./regex"),
                        d = e("./utils"),
                        p = e("dijkstrajs");

                    function u(e) {
                        return unescape(encodeURIComponent(e)).length
                    }

                    function l(e, t, n) {
                        for (var i, s = []; null !== (i = e.exec(n));) s.push({
                            data: i[0],
                            index: i.index,
                            mode: t,
                            length: i[0].length
                        });
                        return s
                    }

                    function g(e) {
                        var t, n, s = l(c.NUMERIC, i.NUMERIC, e),
                            o = l(c.ALPHANUMERIC, i.ALPHANUMERIC, e);
                        return d.isKanjiModeEnabled() ? (t = l(c.BYTE, i.BYTE, e), n = l(c.KANJI, i.KANJI, e)) : (t = l(c.BYTE_KANJI, i.BYTE, e), n = []), s.concat(o, t, n).sort((function(e, t) {
                            return e.index - t.index
                        })).map((function(e) {
                            return {
                                data: e.data,
                                mode: e.mode,
                                length: e.length
                            }
                        }))
                    }

                    function h(e, t) {
                        switch (t) {
                            case i.NUMERIC:
                                return s.getBitsLength(e);
                            case i.ALPHANUMERIC:
                                return o.getBitsLength(e);
                            case i.KANJI:
                                return a.getBitsLength(e);
                            case i.BYTE:
                                return r.getBitsLength(e)
                        }
                    }

                    function f(e, t) {
                        var n, c = i.getBestModeForData(e);
                        if ((n = i.from(t, c)) !== i.BYTE && n.bit < c.bit) throw new Error('"' + e + '" cannot be encoded with mode ' + i.toString(n) + ".\n Suggested mode is: " + i.toString(c));
                        switch (n !== i.KANJI || d.isKanjiModeEnabled() || (n = i.BYTE), n) {
                            case i.NUMERIC:
                                return new s(e);
                            case i.ALPHANUMERIC:
                                return new o(e);
                            case i.KANJI:
                                return new a(e);
                            case i.BYTE:
                                return new r(e)
                        }
                    }
                    n.fromArray = function(e) {
                        return e.reduce((function(e, t) {
                            return "string" == typeof t ? e.push(f(t, null)) : t.data && e.push(f(t.data, t.mode)), e
                        }), [])
                    }, n.fromString = function(e, t) {
                        for (var s = function(e, t) {
                                for (var n = {}, s = {
                                        start: {}
                                    }, o = ["start"], r = 0; r < e.length; r++) {
                                    for (var a = e[r], c = [], d = 0; d < a.length; d++) {
                                        var p = a[d],
                                            u = "" + r + d;
                                        c.push(u), n[u] = {
                                            node: p,
                                            lastCount: 0
                                        }, s[u] = {};
                                        for (var l = 0; l < o.length; l++) {
                                            var g = o[l];
                                            n[g] && n[g].node.mode === p.mode ? (s[g][u] = h(n[g].lastCount + p.length, p.mode) - h(n[g].lastCount, p.mode), n[g].lastCount += p.length) : (n[g] && (n[g].lastCount = p.length), s[g][u] = h(p.length, p.mode) + 4 + i.getCharCountIndicator(p.mode, t))
                                        }
                                    }
                                    o = c
                                }
                                for (l = 0; l < o.length; l++) s[o[l]].end = 0;
                                return {
                                    map: s,
                                    table: n
                                }
                            }(function(e) {
                                for (var t = [], n = 0; n < e.length; n++) {
                                    var s = e[n];
                                    switch (s.mode) {
                                        case i.NUMERIC:
                                            t.push([s, {
                                                data: s.data,
                                                mode: i.ALPHANUMERIC,
                                                length: s.length
                                            }, {
                                                data: s.data,
                                                mode: i.BYTE,
                                                length: s.length
                                            }]);
                                            break;
                                        case i.ALPHANUMERIC:
                                            t.push([s, {
                                                data: s.data,
                                                mode: i.BYTE,
                                                length: s.length
                                            }]);
                                            break;
                                        case i.KANJI:
                                            t.push([s, {
                                                data: s.data,
                                                mode: i.BYTE,
                                                length: u(s.data)
                                            }]);
                                            break;
                                        case i.BYTE:
                                            t.push([{
                                                data: s.data,
                                                mode: i.BYTE,
                                                length: u(s.data)
                                            }])
                                    }
                                }
                                return t
                            }(g(e, d.isKanjiModeEnabled())), t), o = p.find_path(s.map, "start", "end"), r = [], a = 1; a < o.length - 1; a++) r.push(s.table[o[a]].node);
                        return n.fromArray(function(e) {
                            return e.reduce((function(e, t) {
                                var n = e.length - 1 >= 0 ? e[e.length - 1] : null;
                                return n && n.mode === t.mode ? (e[e.length - 1].data += t.data, e) : (e.push(t), e)
                            }), [])
                        }(r))
                    }, n.rawSplit = function(e) {
                        return n.fromArray(g(e, d.isKanjiModeEnabled()))
                    }
                }, {
                    "./alphanumeric-data": 3,
                    "./byte-data": 6,
                    "./kanji-data": 12,
                    "./mode": 14,
                    "./numeric-data": 15,
                    "./regex": 19,
                    "./utils": 21,
                    dijkstrajs: 29
                }],
                21: [function(e, t, n) {
                    var i, s = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346, 404, 466, 532, 581, 655, 733, 815, 901, 991, 1085, 1156, 1258, 1364, 1474, 1588, 1706, 1828, 1921, 2051, 2185, 2323, 2465, 2611, 2761, 2876, 3034, 3196, 3362, 3532, 3706];
                    n.getSymbolSize = function(e) {
                        if (!e) throw new Error('"version" cannot be null or undefined');
                        if (e < 1 || e > 40) throw new Error('"version" should be in range from 1 to 40');
                        return 4 * e + 17
                    }, n.getSymbolTotalCodewords = function(e) {
                        return s[e]
                    }, n.getBCHDigit = function(e) {
                        for (var t = 0; 0 !== e;) t++, e >>>= 1;
                        return t
                    }, n.setToSJISFunction = function(e) {
                        if ("function" != typeof e) throw new Error('"toSJISFunc" is not a valid function.');
                        i = e
                    }, n.isKanjiModeEnabled = function() {
                        return void 0 !== i
                    }, n.toSJIS = function(e) {
                        return i(e)
                    }
                }, {}],
                22: [function(e, t, n) {
                    n.isValid = function(e) {
                        return !isNaN(e) && e >= 1 && e <= 40
                    }
                }, {}],
                23: [function(e, t, n) {
                    var i = e("./utils"),
                        s = e("./error-correction-code"),
                        o = e("./error-correction-level"),
                        r = e("./mode"),
                        a = e("./version-check"),
                        c = e("isarray"),
                        d = i.getBCHDigit(7973);

                    function p(e, t) {
                        return r.getCharCountIndicator(e, t) + 4
                    }

                    function u(e, t) {
                        var n = 0;
                        return e.forEach((function(e) {
                            var i = p(e.mode, t);
                            n += i + e.getBitsLength()
                        })), n
                    }
                    n.from = function(e, t) {
                        return a.isValid(e) ? parseInt(e, 10) : t
                    }, n.getCapacity = function(e, t, n) {
                        if (!a.isValid(e)) throw new Error("Invalid QR Code version");
                        void 0 === n && (n = r.BYTE);
                        var o = 8 * (i.getSymbolTotalCodewords(e) - s.getTotalCodewordsCount(e, t));
                        if (n === r.MIXED) return o;
                        var c = o - p(n, e);
                        switch (n) {
                            case r.NUMERIC:
                                return Math.floor(c / 10 * 3);
                            case r.ALPHANUMERIC:
                                return Math.floor(c / 11 * 2);
                            case r.KANJI:
                                return Math.floor(c / 13);
                            case r.BYTE:
                            default:
                                return Math.floor(c / 8)
                        }
                    }, n.getBestVersionForData = function(e, t) {
                        var i, s = o.from(t, o.M);
                        if (c(e)) {
                            if (e.length > 1) return function(e, t) {
                                for (var i = 1; i <= 40; i++)
                                    if (u(e, i) <= n.getCapacity(i, t, r.MIXED)) return i
                            }(e, s);
                            if (0 === e.length) return 1;
                            i = e[0]
                        } else i = e;
                        return function(e, t, i) {
                            for (var s = 1; s <= 40; s++)
                                if (t <= n.getCapacity(s, i, e)) return s
                        }(i.mode, i.getLength(), s)
                    }, n.getEncodedBits = function(e) {
                        if (!a.isValid(e) || e < 7) throw new Error("Invalid QR Code version");
                        for (var t = e << 12; i.getBCHDigit(t) - d >= 0;) t ^= 7973 << i.getBCHDigit(t) - d;
                        return e << 12 | t
                    }
                }, {
                    "./error-correction-code": 7,
                    "./error-correction-level": 8,
                    "./mode": 14,
                    "./utils": 21,
                    "./version-check": 22,
                    isarray: 30
                }],
                24: [function(e, t, n) {
                    var i = e("./can-promise"),
                        s = e("./core/qrcode"),
                        o = e("./renderer/canvas"),
                        r = e("./renderer/svg-tag.js");

                    function a(e, t, n, o, r) {
                        var a = [].slice.call(arguments, 1),
                            c = a.length,
                            d = "function" == typeof a[c - 1];
                        if (!d && !i()) throw new Error("Callback required as last argument");
                        if (!d) {
                            if (c < 1) throw new Error("Too few arguments provided");
                            return 1 === c ? (n = t, t = o = void 0) : 2 !== c || t.getContext || (o = n, n = t, t = void 0), new Promise((function(i, r) {
                                try {
                                    var a = s.create(n, o);
                                    i(e(a, t, o))
                                } catch (e) {
                                    r(e)
                                }
                            }))
                        }
                        if (c < 2) throw new Error("Too few arguments provided");
                        2 === c ? (r = n, n = t, t = o = void 0) : 3 === c && (t.getContext && void 0 === r ? (r = o, o = void 0) : (r = o, o = n, n = t, t = void 0));
                        try {
                            var p = s.create(n, o);
                            r(null, e(p, t, o))
                        } catch (e) {
                            r(e)
                        }
                    }
                    n.create = s.create, n.toCanvas = a.bind(null, o.render), n.toDataURL = a.bind(null, o.renderToDataURL), n.toString = a.bind(null, (function(e, t, n) {
                        return r.render(e, n)
                    }))
                }, {
                    "./can-promise": 1,
                    "./core/qrcode": 17,
                    "./renderer/canvas": 25,
                    "./renderer/svg-tag.js": 26
                }],
                25: [function(e, t, n) {
                    var i = e("./utils");
                    n.render = function(e, t, n) {
                        var s = n,
                            o = t;
                        void 0 !== s || t && t.getContext || (s = t, t = void 0), t || (o = function() {
                            try {
                                return document.createElement("canvas")
                            } catch (e) {
                                throw new Error("You need to specify a canvas element")
                            }
                        }()), s = i.getOptions(s);
                        var r = i.getImageWidth(e.modules.size, s),
                            a = o.getContext("2d"),
                            c = a.createImageData(r, r);
                        return i.qrToImageData(c.data, e, s),
                            function(e, t, n) {
                                e.clearRect(0, 0, t.width, t.height), t.style || (t.style = {}), t.height = n, t.width = n, t.style.height = n + "px", t.style.width = n + "px"
                            }(a, o, r), a.putImageData(c, 0, 0), o
                    }, n.renderToDataURL = function(e, t, i) {
                        var s = i;
                        void 0 !== s || t && t.getContext || (s = t, t = void 0), s || (s = {});
                        var o = n.render(e, t, s),
                            r = s.type || "image/png",
                            a = s.rendererOpts || {};
                        return o.toDataURL(r, a.quality)
                    }
                }, {
                    "./utils": 27
                }],
                26: [function(e, t, n) {
                    var i = e("./utils");

                    function s(e, t) {
                        var n = e.a / 255,
                            i = t + '="' + e.hex + '"';
                        return n < 1 ? i + " " + t + '-opacity="' + n.toFixed(2).slice(1) + '"' : i
                    }

                    function o(e, t, n) {
                        var i = e + t;
                        return void 0 !== n && (i += " " + n), i
                    }
                    n.render = function(e, t, n) {
                        var r = i.getOptions(t),
                            a = e.modules.size,
                            c = e.modules.data,
                            d = a + 2 * r.margin,
                            p = r.color.light.a ? "<path " + s(r.color.light, "fill") + ' d="M0 0h' + d + "v" + d + 'H0z"/>' : "",
                            u = "<path " + s(r.color.dark, "stroke") + ' d="' + function(e, t, n) {
                                for (var i = "", s = 0, r = !1, a = 0, c = 0; c < e.length; c++) {
                                    var d = Math.floor(c % t),
                                        p = Math.floor(c / t);
                                    d || r || (r = !0), e[c] ? (a++, c > 0 && d > 0 && e[c - 1] || (i += r ? o("M", d + n, .5 + p + n) : o("m", s, 0), s = 0, r = !1), d + 1 < t && e[c + 1] || (i += o("h", a), a = 0)) : s++
                                }
                                return i
                            }(c, a, r.margin) + '"/>',
                            l = 'viewBox="0 0 ' + d + " " + d + '"',
                            g = '<svg xmlns="http://www.w3.org/2000/svg" ' + (r.width ? 'width="' + r.width + '" height="' + r.width + '" ' : "") + l + ' shape-rendering="crispEdges">' + p + u + "</svg>\n";
                        return "function" == typeof n && n(null, g), g
                    }
                }, {
                    "./utils": 27
                }],
                27: [function(e, t, n) {
                    function i(e) {
                        if ("string" != typeof e) throw new Error("Color should be defined as hex string");
                        var t = e.slice().replace("#", "").split("");
                        if (t.length < 3 || 5 === t.length || t.length > 8) throw new Error("Invalid hex color: " + e);
                        3 !== t.length && 4 !== t.length || (t = Array.prototype.concat.apply([], t.map((function(e) {
                            return [e, e]
                        })))), 6 === t.length && t.push("F", "F");
                        var n = parseInt(t.join(""), 16);
                        return {
                            r: n >> 24 & 255,
                            g: n >> 16 & 255,
                            b: n >> 8 & 255,
                            a: 255 & n,
                            hex: "#" + t.slice(0, 6).join("")
                        }
                    }
                    n.getOptions = function(e) {
                        e || (e = {}), e.color || (e.color = {});
                        var t = void 0 === e.margin || null === e.margin || e.margin < 0 ? 4 : e.margin,
                            n = e.width && e.width >= 21 ? e.width : void 0,
                            s = e.scale || 4;
                        return {
                            width: n,
                            scale: n ? 4 : s,
                            margin: t,
                            color: {
                                dark: i(e.color.dark || "#000000ff"),
                                light: i(e.color.light || "#ffffffff")
                            },
                            type: e.type,
                            rendererOpts: e.rendererOpts || {}
                        }
                    }, n.getScale = function(e, t) {
                        return t.width && t.width >= e + 2 * t.margin ? t.width / (e + 2 * t.margin) : t.scale
                    }, n.getImageWidth = function(e, t) {
                        var i = n.getScale(e, t);
                        return Math.floor((e + 2 * t.margin) * i)
                    }, n.qrToImageData = function(e, t, i) {
                        for (var s = t.modules.size, o = t.modules.data, r = n.getScale(s, i), a = Math.floor((s + 2 * i.margin) * r), c = i.margin * r, d = [i.color.light, i.color.dark], p = 0; p < a; p++)
                            for (var u = 0; u < a; u++) {
                                var l = 4 * (p * a + u),
                                    g = i.color.light;
                                p >= c && u >= c && p < a - c && u < a - c && (g = d[o[Math.floor((p - c) / r) * s + Math.floor((u - c) / r)] ? 1 : 0]), e[l++] = g.r, e[l++] = g.g, e[l++] = g.b, e[l] = g.a
                            }
                    }
                }, {}],
                28: [function(e, t, n) {
                    var i = e("isarray");
                    o.TYPED_ARRAY_SUPPORT = function() {
                        try {
                            var e = new Uint8Array(1);
                            return e.__proto__ = {
                                __proto__: Uint8Array.prototype,
                                foo: function() {
                                    return 42
                                }
                            }, 42 === e.foo()
                        } catch (e) {
                            return !1
                        }
                    }();
                    var s = o.TYPED_ARRAY_SUPPORT ? 2147483647 : 1073741823;

                    function o(e, t, n) {
                        return o.TYPED_ARRAY_SUPPORT || this instanceof o ? "number" == typeof e ? c(this, e) : function(e, t, n, i) {
                            if ("number" == typeof t) throw new TypeError('"value" argument must not be a number');
                            return "undefined" != typeof ArrayBuffer && t instanceof ArrayBuffer ? function(e, t, n, i) {
                                if (n < 0 || t.byteLength < n) throw new RangeError("'offset' is out of bounds");
                                if (t.byteLength < n + (i || 0)) throw new RangeError("'length' is out of bounds");
                                var s;
                                return s = void 0 === n && void 0 === i ? new Uint8Array(t) : void 0 === i ? new Uint8Array(t, n) : new Uint8Array(t, n, i), o.TYPED_ARRAY_SUPPORT ? s.__proto__ = o.prototype : s = d(e, s), s
                            }(e, t, n, i) : "string" == typeof t ? function(e, t) {
                                var n = 0 | u(t),
                                    i = a(e, n),
                                    s = i.write(t);
                                return s !== n && (i = i.slice(0, s)), i
                            }(e, t) : function(e, t) {
                                if (o.isBuffer(t)) {
                                    var n = 0 | r(t.length),
                                        i = a(e, n);
                                    return 0 === i.length || t.copy(i, 0, 0, n), i
                                }
                                if (t) {
                                    if ("undefined" != typeof ArrayBuffer && t.buffer instanceof ArrayBuffer || "length" in t) return "number" != typeof t.length || (s = t.length) != s ? a(e, 0) : d(e, t);
                                    if ("Buffer" === t.type && Array.isArray(t.data)) return d(e, t.data)
                                }
                                var s;
                                throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
                            }(e, t)
                        }(this, e, t, n) : new o(e, t, n)
                    }

                    function r(e) {
                        if (e >= s) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + s.toString(16) + " bytes");
                        return 0 | e
                    }

                    function a(e, t) {
                        var n;
                        return o.TYPED_ARRAY_SUPPORT ? (n = new Uint8Array(t)).__proto__ = o.prototype : (null === (n = e) && (n = new o(t)), n.length = t), n
                    }

                    function c(e, t) {
                        var n = a(e, t < 0 ? 0 : 0 | r(t));
                        if (!o.TYPED_ARRAY_SUPPORT)
                            for (var i = 0; i < t; ++i) n[i] = 0;
                        return n
                    }

                    function d(e, t) {
                        for (var n = t.length < 0 ? 0 : 0 | r(t.length), i = a(e, n), s = 0; s < n; s += 1) i[s] = 255 & t[s];
                        return i
                    }

                    function p(e, t) {
                        var n;
                        t = t || 1 / 0;
                        for (var i = e.length, s = null, o = [], r = 0; r < i; ++r) {
                            if ((n = e.charCodeAt(r)) > 55295 && n < 57344) {
                                if (!s) {
                                    if (n > 56319) {
                                        (t -= 3) > -1 && o.push(239, 191, 189);
                                        continue
                                    }
                                    if (r + 1 === i) {
                                        (t -= 3) > -1 && o.push(239, 191, 189);
                                        continue
                                    }
                                    s = n;
                                    continue
                                }
                                if (n < 56320) {
                                    (t -= 3) > -1 && o.push(239, 191, 189), s = n;
                                    continue
                                }
                                n = 65536 + (s - 55296 << 10 | n - 56320)
                            } else s && (t -= 3) > -1 && o.push(239, 191, 189);
                            if (s = null, n < 128) {
                                if ((t -= 1) < 0) break;
                                o.push(n)
                            } else if (n < 2048) {
                                if ((t -= 2) < 0) break;
                                o.push(n >> 6 | 192, 63 & n | 128)
                            } else if (n < 65536) {
                                if ((t -= 3) < 0) break;
                                o.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128)
                            } else {
                                if (!(n < 1114112)) throw new Error("Invalid code point");
                                if ((t -= 4) < 0) break;
                                o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128)
                            }
                        }
                        return o
                    }

                    function u(e) {
                        return o.isBuffer(e) ? e.length : "undefined" != typeof ArrayBuffer && "function" == typeof ArrayBuffer.isView && (ArrayBuffer.isView(e) || e instanceof ArrayBuffer) ? e.byteLength : ("string" != typeof e && (e = "" + e), 0 === e.length ? 0 : p(e).length)
                    }
                    o.TYPED_ARRAY_SUPPORT && (o.prototype.__proto__ = Uint8Array.prototype, o.__proto__ = Uint8Array, "undefined" != typeof Symbol && Symbol.species && o[Symbol.species] === o && Object.defineProperty(o, Symbol.species, {
                        value: null,
                        configurable: !0,
                        enumerable: !1,
                        writable: !1
                    })), o.prototype.write = function(e, t, n) {
                        void 0 === t || void 0 === n && "string" == typeof t ? (n = this.length, t = 0) : isFinite(t) && (t |= 0, isFinite(n) ? n |= 0 : n = void 0);
                        var i = this.length - t;
                        if ((void 0 === n || n > i) && (n = i), e.length > 0 && (n < 0 || t < 0) || t > this.length) throw new RangeError("Attempt to write outside buffer bounds");
                        return function(e, t, n, i) {
                            return function(e, t, n, i) {
                                for (var s = 0; s < i && !(s + n >= t.length || s >= e.length); ++s) t[s + n] = e[s];
                                return s
                            }(p(t, e.length - n), e, n, i)
                        }(this, e, t, n)
                    }, o.prototype.slice = function(e, t) {
                        var n, i = this.length;
                        if ((e = ~~e) < 0 ? (e += i) < 0 && (e = 0) : e > i && (e = i), (t = void 0 === t ? i : ~~t) < 0 ? (t += i) < 0 && (t = 0) : t > i && (t = i), t < e && (t = e), o.TYPED_ARRAY_SUPPORT)(n = this.subarray(e, t)).__proto__ = o.prototype;
                        else {
                            var s = t - e;
                            n = new o(s, void 0);
                            for (var r = 0; r < s; ++r) n[r] = this[r + e]
                        }
                        return n
                    }, o.prototype.copy = function(e, t, n, i) {
                        if (n || (n = 0), i || 0 === i || (i = this.length), t >= e.length && (t = e.length), t || (t = 0), i > 0 && i < n && (i = n), i === n) return 0;
                        if (0 === e.length || 0 === this.length) return 0;
                        if (t < 0) throw new RangeError("targetStart out of bounds");
                        if (n < 0 || n >= this.length) throw new RangeError("sourceStart out of bounds");
                        if (i < 0) throw new RangeError("sourceEnd out of bounds");
                        i > this.length && (i = this.length), e.length - t < i - n && (i = e.length - t + n);
                        var s, r = i - n;
                        if (this === e && n < t && t < i)
                            for (s = r - 1; s >= 0; --s) e[s + t] = this[s + n];
                        else if (r < 1e3 || !o.TYPED_ARRAY_SUPPORT)
                            for (s = 0; s < r; ++s) e[s + t] = this[s + n];
                        else Uint8Array.prototype.set.call(e, this.subarray(n, n + r), t);
                        return r
                    }, o.prototype.fill = function(e, t, n) {
                        if ("string" == typeof e) {
                            if ("string" == typeof t ? (t = 0, n = this.length) : "string" == typeof n && (n = this.length), 1 === e.length) {
                                var i = e.charCodeAt(0);
                                i < 256 && (e = i)
                            }
                        } else "number" == typeof e && (e &= 255);
                        if (t < 0 || this.length < t || this.length < n) throw new RangeError("Out of range index");
                        if (n <= t) return this;
                        var s;
                        if (t >>>= 0, n = void 0 === n ? this.length : n >>> 0, e || (e = 0), "number" == typeof e)
                            for (s = t; s < n; ++s) this[s] = e;
                        else {
                            var r = o.isBuffer(e) ? e : new o(e),
                                a = r.length;
                            for (s = 0; s < n - t; ++s) this[s + t] = r[s % a]
                        }
                        return this
                    }, o.concat = function(e, t) {
                        if (!i(e)) throw new TypeError('"list" argument must be an Array of Buffers');
                        if (0 === e.length) return a(null, 0);
                        var n;
                        if (void 0 === t)
                            for (t = 0, n = 0; n < e.length; ++n) t += e[n].length;
                        var s = c(null, t),
                            r = 0;
                        for (n = 0; n < e.length; ++n) {
                            var d = e[n];
                            if (!o.isBuffer(d)) throw new TypeError('"list" argument must be an Array of Buffers');
                            d.copy(s, r), r += d.length
                        }
                        return s
                    }, o.byteLength = u, o.prototype._isBuffer = !0, o.isBuffer = function(e) {
                        return !(null == e || !e._isBuffer)
                    }, t.exports = o
                }, {
                    isarray: 30
                }],
                29: [function(e, t, n) {
                    var i = {
                        single_source_shortest_paths: function(e, t, n) {
                            var s = {},
                                o = {};
                            o[t] = 0;
                            var r, a, c, d, p, u, l, g = i.PriorityQueue.make();
                            for (g.push(t, 0); !g.empty();)
                                for (c in a = (r = g.pop()).value, d = r.cost, p = e[a] || {}) p.hasOwnProperty(c) && (u = d + p[c], l = o[c], (void 0 === o[c] || l > u) && (o[c] = u, g.push(c, u), s[c] = a));
                            if (void 0 !== n && void 0 === o[n]) {
                                var h = ["Could not find a path from ", t, " to ", n, "."].join("");
                                throw new Error(h)
                            }
                            return s
                        },
                        extract_shortest_path_from_predecessor_list: function(e, t) {
                            for (var n = [], i = t; i;) n.push(i), e[i], i = e[i];
                            return n.reverse(), n
                        },
                        find_path: function(e, t, n) {
                            var s = i.single_source_shortest_paths(e, t, n);
                            return i.extract_shortest_path_from_predecessor_list(s, n)
                        },
                        PriorityQueue: {
                            make: function(e) {
                                var t, n = i.PriorityQueue,
                                    s = {};
                                for (t in e = e || {}, n) n.hasOwnProperty(t) && (s[t] = n[t]);
                                return s.queue = [], s.sorter = e.sorter || n.default_sorter, s
                            },
                            default_sorter: function(e, t) {
                                return e.cost - t.cost
                            },
                            push: function(e, t) {
                                var n = {
                                    value: e,
                                    cost: t
                                };
                                this.queue.push(n), this.queue.sort(this.sorter)
                            },
                            pop: function() {
                                return this.queue.shift()
                            },
                            empty: function() {
                                return 0 === this.queue.length
                            }
                        }
                    };
                    void 0 !== t && (t.exports = i)
                }, {}],
                30: [function(e, t, n) {
                    var i = {}.toString;
                    t.exports = Array.isArray || function(e) {
                        return "[object Array]" == i.call(e)
                    }
                }, {}]
            }, {}, [24])(24)
        }));
        return {
            name: "qrcode",
            props: {
                value: null,
                options: Object,
                tag: {
                    type: String,
                    default: "canvas"
                }
            },
            render: function(e) {
                return e(this.tag, this.$slots.default)
            },
            watch: {
                $props: {
                    deep: !0,
                    immediate: !0,
                    handler: function() {
                        this.$el && this.generate()
                    }
                }
            },
            methods: {
                generate: function() {
                    var e = this,
                        n = this.options,
                        i = this.tag,
                        s = String(this.value);
                    "canvas" === i ? t.toCanvas(this.$el, s, n, (function(e) {
                        if (e) throw e
                    })) : "img" === i ? t.toDataURL(s, n, (function(t, n) {
                        if (t) throw t;
                        e.$el.src = n
                    })) : t.toString(s, n, (function(t, n) {
                        if (t) throw t;
                        e.$el.innerHTML = n
                    }))
                }
            },
            mounted: function() {
                this.generate()
            }
        }
    }, "object" === r(t) && void 0 !== e ? e.exports = o() : void 0 === (s = "function" == typeof(i = o) ? i.call(t, n, t, e) : i) || (e.exports = s)
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-otp-wizard-scan-qr",
            attrs: {
                "syno-id": "secure-signin-otp-register-wizard-scan-qr",
                "step-key": e.stepKey,
                headline: e.T("personal_settings", "otp_wizard_setup_authenticator"),
                "next-step-key": e.nextStepKey,
                preEnterNextStep: e.onPreNext
            },
            on: {
                activate: e.onActivate
            }
        }, [n("div", {
            staticClass: "step-block"
        }, [n("div", {
            staticClass: "step-title"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_scan_qrcode")) + " ")]), e._v(" "), n("div", {
            staticClass: "step-desc"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_scan_qrcode_with_app")) + " ")])]), e._v(" "), n("div", {
            staticClass: "qrcode-content"
        }, [n("div", {
            staticClass: "qrcode",
            style: e.qrcodeImg
        })]), e._v(" "), n("div", {
            staticClass: "link",
            on: {
                click: e.showOtpSecret
            }
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_scan_qrcode_failed")) + " ")]), e._v(" "), n("div", {
            staticClass: "step-block"
        }, [n("div", {
            staticClass: "step-title"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_confirm_code_title")) + " ")]), e._v(" "), n("div", {
            staticClass: "step-desc"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_confirm_code_desc")) + " ")])]), e._v(" "), n("v-form", {
            staticClass: "otp-code",
            attrs: {
                "syno-id": "pages-auth-page-form-0"
            }
        }, [n("v-form-item", {
            attrs: {
                label: e.T("personal_settings", "otp_verification_code") + ":",
                rules: e.codeRules
            }
        }, [n("v-input", {
            attrs: {
                "syno-id": "pages-auth-page-input-1",
                name: "code",
                placeholder: e.T("login", "enter_otp_desc")
            },
            model: {
                value: e.code,
                callback: function(t) {
                    e.code = t
                },
                expression: "code"
            }
        })], 1)], 1)], 1)
    };
    i._withStripped = !0;
    var s = n(3),
        o = n(0),
        r = n(23),
        a = n.n(r),
        c = n(2);

    function d(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function p(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    d(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    d(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function u(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var l = {
            mixins: [o.a, s.a],
            components: {
                qrcode: a.a
            },
            data: function() {
                return {
                    code: void 0,
                    codeRules: [{
                        required: !0
                    }]
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        u(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(c.mapState)(["signinMode", "methodSelect", "authenticatorId", "fidoUid", "username", "password", "otpImg", "otpSecret"]), {
                qrcodeImg: function() {
                    return String.format("background-image: url(data:image/png;base64,{0})", this.otpImg)
                },
                isShowQrcode: function() {
                    return "" !== this.qrcodeValue
                }
            }),
            props: {
                nextStepKey: String,
                stepKey: String
            },
            methods: {
                onActivate: function() {
                    var e, t = this;
                    return e = _S("isLogined") ? {
                        api: "SYNO.Core.OTP",
                        method: "get_qrcode",
                        version: 3,
                        params: {
                            enable_margin: !1,
                            account: _S("user") + "@" + _S("hostname")
                        }
                    } : {
                        api: "SYNO.Core.OTP.Ex",
                        method: "get_qrcode",
                        version: 1,
                        params: {
                            enable_margin: !1,
                            account: this.username + "@" + _S("hostname"),
                            username: this.username,
                            passwd: this.password
                        },
                        encryption: ["username", "passwd", "account"]
                    }, synowebapi.promises.request(e).then((function(e) {
                        t.$store.commit("SET_OTP_IMG", e.img), t.$store.commit("SET_OTP_NAME", e.appAccount), t.$store.commit("SET_OTP_SECRET", e.key)
                    }))
                },
                onPreNext: function() {
                    var e, t = this;
                    return !!this.code && (e = _S("isLogined") ? {
                        api: "SYNO.Core.OTP",
                        method: "auth_tmp_code",
                        version: 3,
                        params: {
                            code: this.code
                        },
                        encryption: ["code"]
                    } : {
                        api: "SYNO.Core.OTP.Ex",
                        method: "auth_tmp_code",
                        version: 1,
                        params: {
                            code: this.code,
                            username: this.username,
                            passwd: this.password
                        },
                        encryption: ["username", "passwd", "code"]
                    }, this.$emit("show-loading"), synowebapi.promises.request(e).then((function(e) {
                        return t.$store.commit("SET_OTP_STATUS", "on"), t.setSigninMethod("on", t.signinMode, t.username, t.password)
                    })).then(p(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    "" !== t.authenticatorId ? t.nextStepKey = "approve-signin-summary-step" : Number.isNaN(t.fidoUid) || (t.nextStepKey = "usb" === t.methodSelect ? "fido-keyname-step" : "fido-summary-step");
                                case 1:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })))).catch((function(e) {
                        return t.$emit("hide-loading"), t.$emit("show-error", t.getOtpErrorMsg(e.code)), Promise.resolve(!1)
                    })))
                },
                showOtpSecret: function() {
                    this.$emit("show-otp-secret")
                }
            }
        },
        g = (n(122), n(1)),
        h = Object(g.a)(l, i, [], !1, null, null, null);
    h.options.__file = "src/otp-wizard-steps/scan-qr.vue";
    t.a = h.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-otp-wizard-backup-email",
            attrs: {
                "syno-id": "secure-signin-otp-register-wizard-backup-email",
                "step-key": e.stepKey,
                headline: e.T("personal_settings", "otp_wizard_mail_title"),
                "next-step-key": e.nextStepKey,
                "pre-enter-next-step": e.preEnterNextStep
            },
            on: {
                activate: e.onActivate
            }
        }, [n("v-form", {
            ref: "form",
            attrs: {
                "syno-id": "pages-backup-email-step-form-0",
                rules: e.rules
            }
        }, [n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_mail_desc")) + " ")]), e._v(" "), n("v-form-item", {
            attrs: {
                label: e.T("personal_settings", "otp_wizard_rescue_mail") + ":",
                prop: "backupEmail"
            }
        }, [n("v-input", {
            attrs: {
                "syno-id": "pages-backup-email-step-input-1",
                name: "backupEmail"
            },
            model: {
                value: e.backupEmail,
                callback: function(t) {
                    e.backupEmail = t
                },
                expression: "backupEmail"
            }
        })], 1)], 1)], 1)
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(3),
        r = n(7),
        a = n(2);

    function c(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function d(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var p, u, l = {
            mixins: [s.a, o.a],
            props: {
                nextStepKey: String,
                stepKey: String
            },
            data: function() {
                return {
                    rules: {
                        backupEmail: {
                            validator: Object(r.a)({
                                required: !0
                            })
                        }
                    }
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        d(e, t, n[t])
                    }))
                }
                return e
            }({
                backupEmail: {
                    get: function() {
                        return this.$store.state.backupEmail
                    },
                    set: function(e) {
                        this.$store.commit("SET_BACKUP_EMAIL", e)
                    }
                }
            }, Object(a.mapState)(["username", "password"])),
            methods: {
                onActivate: function() {
                    var e = this;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.NormalUser",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        e.$store.commit("SET_BACKUP_EMAIL", t.email), t.ldapServerAddr && e.$store.commit("SET_LDAP_SERVER_ADDR", t.ldapServerAddr), t.userDN && e.$store.commit("SET_USER_DN", t.userDN)
                    }))
                },
                preEnterNextStep: (p = regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.form.validate();
                            case 2:
                                if (!(t = e.sent)) {
                                    e.next = 15;
                                    break
                                }
                                return e.prev = 4, this.$emit("show-loading"), e.next = 8, this.saveMail(this.$store.state, this.username, this.password);
                            case 8:
                                e.next = 15;
                                break;
                            case 10:
                                return e.prev = 10, e.t0 = e.catch(4), this.$emit("hide-loading"), this.$emit("show-error", this.getOtpErrorMsg(e.t0.code)), e.abrupt("return", !1);
                            case 15:
                                return e.abrupt("return", t);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [4, 10]
                    ])
                })), u = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = p.apply(e, t);

                        function o(e) {
                            c(s, n, i, o, r, "next", e)
                        }

                        function r(e) {
                            c(s, n, i, o, r, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return u.apply(this, arguments)
                })
            }
        },
        g = (n(120), n(1)),
        h = Object(g.a)(l, i, [], !1, null, null, null);
    h.options.__file = "src/otp-wizard-steps/backup-email-step.vue";
    t.a = h.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            staticClass: "syno-securesignin-otp-wizard-summary",
            attrs: {
                "syno-id": "secure-signin-otp-register-wizard-summary",
                "step-key": e.stepKey,
                headline: e.TT("wizard", "2fa_has_been_turned_on"),
                finished: e.finished
            }
        }, [n("div", [e._v(" " + e._s(e.T("personal_settings", "otp_wizard_finish_desc")) + " ")]), e._v(" "), n("br"), e._v(" "), n("div", {
            staticClass: "note"
        }, [n("label", {
            staticClass: "syno-ux-note"
        }, [e._v(" " + e._s(e.T("common", "note")) + " ")]), e._v(" "), n("label", [e._v(" " + e._s(e.T("common", "colon")) + " ")]), e._v(" "), n("label", {
            domProps: {
                innerHTML: e._s(e.note_desc)
            }
        })])])
    };
    i._withStripped = !0;
    var s = {
            mixins: [n(0).a],
            props: {
                stepKey: String
            },
            data: function() {
                return {
                    note_desc: this.T("personal_settings", "otp_wizard_finish_tips")
                }
            },
            methods: {
                finished: function() {
                    this.$emit("close")
                }
            }
        },
        o = (n(126), n(1)),
        r = Object(o.a)(s, i, [], !1, null, null, null);
    r.options.__file = "src/otp-wizard-steps/summary-step.vue";
    t.a = r.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-modal-window", {
            ref: "window",
            staticClass: "syno-securesignin-otp-secret-dialog",
            attrs: {
                title: e.title,
                height: "auto",
                width: "580"
            }
        }, [n("v-panel", {
            attrs: {
                "fluid-footer": "",
                confirm: e.onConfirm,
                "confirm-text": e.confirmText,
                cancel: e.onClose,
                "error-text": e.errorText,
                "show-status-bar": e.showStatusBar,
                "status-bar-state": e.statusBarState,
                "loading-type": e.loadingType
            },
            on: {
                "update:showStatusBar": function(t) {
                    e.showStatusBar = t
                },
                "update:show-status-bar": function(t) {
                    e.showStatusBar = t
                }
            },
            scopedSlots: e._u([{
                key: "body",
                fn: function() {
                    return [n("v-form", {
                        staticClass: "otp-code",
                        attrs: {
                            "syno-id": "pages-auth-page-form-0",
                            rules: "rules"
                        }
                    }, [n("v-form-item", {
                        attrs: {
                            hideLabel: "",
                            textonly: ""
                        }
                    }, [e._v("\n\t\t\t\t\t" + e._s(e.T("personal_settings", "otp_edit_desc")) + "\n\t\t\t\t")]), e._v(" "), n("v-form-item", {
                        attrs: {
                            label: e.T("personal_settings", "otp_account_name")
                        }
                    }, [n("v-input", {
                        attrs: {
                            "syno-id": "pages-auth-page-input-1",
                            name: "otpName"
                        },
                        model: {
                            value: e.otpName,
                            callback: function(t) {
                                e.otpName = t
                            },
                            expression: "otpName"
                        }
                    })], 1), e._v(" "), n("v-form-item", {
                        attrs: {
                            label: e.T("personal_settings", "otp_secret_key"),
                            textonly: ""
                        }
                    }, [e._v("\n\t\t\t\t\t" + e._s(e.otpSecret) + "\n\t\t\t\t")])], 1)]
                },
                proxy: !0
            }])
        })], 1)
    };
    i._withStripped = !0;
    var s = n(3),
        o = n(0),
        r = n(2);

    function a(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var c = {
            mixins: [o.a, s.a],
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        a(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(r.mapState)(["otpSecret", "username", "password"]), {
                otpName: {
                    get: function() {
                        return this.$store.state.otpName
                    },
                    set: function(e) {
                        this.$store.commit("SET_OTP_NAME", e)
                    }
                }
            }),
            data: function() {
                return {
                    title: this.T("personal_settings", "otp_wizard_title"),
                    confirmText: this.T("common", "save"),
                    errorText: void 0,
                    statusBarState: "error",
                    showStatusBar: !1,
                    loadingType: "statusbar"
                }
            },
            methods: {
                onClose: function() {
                    this.$refs.window.close()
                },
                onConfirm: function() {
                    var e = this;
                    return this.statusBarState = "loading", this.showStatusBar = !0, this.editSecretKey(this.otpSecret, this.otpName, this.username, this.password).then((function(t) {
                        e.$store.commit("SET_OTP_IMG", t.img), e.$store.commit("SET_OTP_NAME", t.appAccount), e.$store.commit("SET_OTP_SECRET", t.key), e.onClose()
                    })).catch((function(t) {
                        return e.statusBarState = "error", e.errorText = e.T("error", "error_error_system"), Promise.resolve(!1)
                    }))
                }
            }
        },
        d = (n(124), n(1)),
        p = Object(d.a)(c, i, [], !1, null, null, null);
    p.options.__file = "src/otp-wizard-steps/otp-secret-win.vue";
    t.a = p.exports
}, function(e, t, n) {
    "use strict";
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-otp-wizard-welcome",
            attrs: {
                "syno-id": "secure-signin-otp-register-wizard-welcome",
                "step-key": e.stepKey,
                headline: e.title,
                "next-step-key": e.nextStepKey,
                "pre-enter-next-step": e.onPreNext,
                type: e.type
            }
        }, [n("div", {
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.get_desc)
            }
        }), e._v(" "), n("div", {
            staticClass: "welcome_img"
        })])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(3),
        r = n(2);

    function a(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function c(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    a(o, i, s, r, c, "next", e)
                }

                function c(e) {
                    a(o, i, s, r, c, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function d(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var p, u = {
            mixins: [s.a, o.a],
            props: {
                nextStepKey: String,
                stepKey: String,
                type: String,
                windowRef: {}
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        d(e, t, n[t])
                    }))
                }
                return e
            }({
                get_desc: function() {
                    var e = ['<span class="syno-ux-note">' + _T("common", "note") + "</span>", '<a href="http://www.synology.com/knowledgebase/DSM/tutorial/Management/OTP_packages_supportability" target="_blank">', "</a>"];
                    return String.format.apply(String, [this.T("personal_settings", "otp_wizard_welcome_desc")].concat(e))
                },
                title: function() {
                    return "" === this.authenticatorId && Number.isNaN(this.fidoUid) ? this.T("personal_settings", "otp_wizard_welcome_title") : this.TT("wizard", "set_backup_2fa_desc")
                }
            }, Object(r.mapState)(["authenticatorId", "fidoUid", "isSkipOtp"])),
            methods: {
                onPreNext: (p = c(regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (_S("isLogined")) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", !0);
                            case 2:
                                if (!this.isSkipOtp) {
                                    e.next = 4;
                                    break
                                }
                                return e.abrupt("return", !0);
                            case 4:
                                if ("" === this.authenticatorId && Number.isNaN(this.fidoUid)) {
                                    e.next = 11;
                                    break
                                }
                                return e.next = 7, this.getEmailStatus();
                            case 7:
                                if (e.sent) {
                                    e.next = 11;
                                    break
                                }
                                return this.$emit("open-msg-box", null, this.T("notification", "mail_service_not_enable"), {
                                    cancel: {
                                        text: this.T("common", "cancel")
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                }, (function(e) {
                                    if ("confirm" === e) {
                                        var n = t.windowRef.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailWizard, {
                                            firstCreate: !0
                                        }).window;
                                        n && n.$on("close", c(regeneratorRuntime.mark((function e() {
                                            return regeneratorRuntime.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.next = 2, t.getEmailStatus();
                                                    case 2:
                                                        e.sent && t.$refs.step.nextStep();
                                                    case 4:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e, this)
                                        }))))
                                    }
                                })), e.abrupt("return", !1);
                            case 11:
                                return e.abrupt("return", !0);
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return p.apply(this, arguments)
                })
            }
        },
        l = (n(116), n(1)),
        g = Object(l.a)(u, i, [], !1, null, null, null);
    g.options.__file = "src/otp-wizard-steps/welcome-step.vue";
    t.a = g.exports
}, function(e, t, n) {
    var i = n(61);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("6541aa00", i, !1, {})
}, function(e, t, n) {
    var i = n(67);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("2102344f", i, !1, {})
}, function(e, t, n) {
    var i = n(69);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("224a842f", i, !1, {})
}, function(e, t, n) {
    var i = n(71);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("315c363e", i, !1, {})
}, function(e, t, n) {
    var i = n(73);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("737d750f", i, !1, {})
}, function(e, t, n) {
    var i = n(75);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("2bc99d62", i, !1, {})
}, function(e, t, n) {
    var i = n(77);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("682703c5", i, !1, {})
}, function(e, t, n) {
    var i = n(79);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("35b4fb73", i, !1, {})
}, function(e, t, n) {
    var i = n(81);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("4d703a52", i, !1, {})
}, function(e, t, n) {
    var i = n(89);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("f8e9aa5e", i, !1, {})
}, function(e, t, n) {
    var i = n(93);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("4cafbe4a", i, !1, {})
}, function(e, t, n) {
    var i = n(101);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("7bd4868b", i, !1, {})
}, function(e, t, n) {
    var i = n(103);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("45ae5749", i, !1, {})
}, function(e, t, n) {
    var i = n(105);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("eb2298f0", i, !1, {})
}, function(e, t, n) {
    var i = n(107);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("76c61cb6", i, !1, {})
}, function(e, t, n) {
    var i = n(109);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("49644bf0", i, !1, {})
}, function(e, t, n) {
    var i = n(111);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("16a8a470", i, !1, {})
}, function(e, t, n) {
    var i = n(113);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("73956cf0", i, !1, {})
}, function(e, t, n) {
    var i = n(115);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("fa807d74", i, !1, {})
}, function(e, t, n) {
    var i = n(117);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("4516e909", i, !1, {})
}, function(e, t, n) {
    var i = n(121);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("df955c9a", i, !1, {})
}, function(e, t, n) {
    var i = n(123);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("4d734253", i, !1, {})
}, function(e, t, n) {
    var i = n(125);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("c69ac346", i, !1, {})
}, function(e, t, n) {
    var i = n(127);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("279cf081", i, !1, {})
}, function(e, t, n) {
    var i = n(129);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("4ff00e46", i, !1, {})
}, function(e, t, n) {
    var i = n(131);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("01321f4a", i, !1, {})
}, function(e, t, n) {
    var i = n(135);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("02214104", i, !1, {})
}, function(e, t, n) {
    var i = n(137);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("0baef4e0", i, !1, {})
}, function(e, t, n) {
    var i = n(139);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("14da4783", i, !1, {})
}, function(e, t, n) {
    "use strict";
    n.r(t);
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("div", {
            staticClass: "auth-login-panel"
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isWaitTooLong,
                expression: "isWaitTooLong"
            }],
            staticClass: "redirect-content"
        }, [n("div", {
            staticClass: "title"
        }, [e._v(e._s(e.TT("authenticator", "approve_sign_in")))]), e._v(" "), n("v-button", {
            staticClass: "continue",
            attrs: {
                "syno-id": "secure-signin-authenticator-login-button-redirect",
                suffix: "blue"
            },
            on: {
                click: e.doRedirect
            }
        }, [e._v(e._s(e.TT("common", "continue")))])], 1), e._v(" "), n("div", {
            staticClass: "title"
        }, [e._v(e._s(e.title))]), e._v(" "), n("div", {
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.desc)
            }
        }), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isTrustDevice && e.isWaiting,
                expression: "isTrustDevice && isWaiting"
            }],
            staticClass: "icon"
        }), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isUnTrustDevice && e.isWaiting,
                expression: "isUnTrustDevice && isWaiting"
            }],
            staticClass: "verify-number"
        }, [e._v(e._s(e.verifyNumber))]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isFailed,
                expression: "isFailed"
            }],
            staticClass: "invalid"
        }, [n("v-button", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.pkgAvailable,
                expression: "pkgAvailable"
            }],
            staticClass: "try-again",
            attrs: {
                "syno-id": "secure-signin-authenticator-login-try-again-btn",
                type: "footbar",
                suffix: "blue"
            },
            on: {
                click: e.onRetryClick
            }
        }, [e._v(e._s(e.TT("authenticator", "try_again")))])], 1), e._v(" "), n("v-checkbox", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isFailed && e.is2FA && !e.isMobileDevice,
                expression: "!isFailed && is2FA && !isMobileDevice"
            }],
            staticClass: "trust-device",
            attrs: {
                "syno-id": "secure-signin-authenticator-login-trust-device",
                disabled: e.checkedBoxDisabled
            },
            model: {
                value: e.trustDevice,
                callback: function(t) {
                    e.trustDevice = t
                },
                expression: "trustDevice"
            }
        }, [e._v("\n\t\t" + e._s(e.T("login", "trustdevice")) + "\n\t")]), e._v(" "), n("v-checkbox", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isFailed && !e.is2FA && !e.isMobileDevice,
                expression: "!isFailed && !is2FA && !isMobileDevice"
            }],
            staticClass: "field",
            attrs: {
                "syno-id": "secure-signin-authenticator-login-stay-login",
                tabindex: 2,
                disabled: e.checkedBoxDisabled
            },
            model: {
                value: e.stayLogin,
                callback: function(t) {
                    e.stayLogin = t
                },
                expression: "stayLogin"
            }
        }, [e._v("\n\t\t" + e._s(e.T("login", "rememberme")) + "\n\t")]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isWaitTooLong,
                expression: "!isWaitTooLong"
            }],
            staticClass: "tab-footer login-footer"
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.loginErrMessage,
                expression: "loginErrMessage"
            }],
            staticClass: "login-msg-box",
            class: "error",
            domProps: {
                innerHTML: e._s(e.loginErrMessage)
            }
        }), e._v(" "), n("router-link", {
            staticClass: "tab-footer-link",
            attrs: {
                to: "/signin/select-auth",
                replace: ""
            }
        }, [e._v("\n\t\t" + e._s(e.T("login", "other_ways")) + "\n\t\t")])], 1)], 1)
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(3);

    function r(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }
    var a, c, d = {
            mixins: [s.a, o.a],
            name: "AuthenticatorLoginPanel",
            data: function() {
                return {
                    loginParams: null,
                    checkedBoxDisabled: !1,
                    loginErrMessage: "",
                    requestId: "",
                    status: "waiting",
                    retry: !1,
                    verifyNumber: -1,
                    resendTimer: null,
                    pkgAvailable: !0,
                    isWaitTooLong: !1,
                    redirectInfo: null
                }
            },
            computed: {
                isFailed: function() {
                    return this.isDenied || this.isTimeout || this.isRevoked
                },
                isDenied: function() {
                    return "denied" === this.status
                },
                isTrustDevice: function() {
                    return -1 === this.verifyNumber
                },
                isUnTrustDevice: function() {
                    return -1 !== this.verifyNumber
                },
                isWaiting: function() {
                    return "waiting" === this.status
                },
                isTimeout: function() {
                    return "timeout" === this.status
                },
                isRevoked: function() {
                    return "revoked" === this.status
                },
                isApproved: function() {
                    return "approved" === this.status
                },
                is2FA: function() {
                    return "" !== this.$store.state.mainPage.dsmForm.password
                },
                isMobileDevice: function() {
                    return _S("isMobileDevice")
                },
                getDeviceName: function() {
                    var e = "others",
                        t = "others";
                    return Ext.isLinux ? e = "Linux" : Ext.isMac ? e = "Mac" : Ext.isWindows && (e = "Windows"), Ext.isGecko ? t = "FireFox" : Ext.isIE ? t = "IE" : Ext.isChrome ? t = "Chrome" : Ext.isOpera ? t = "Opera" : Ext.isSafari ? t = "Safari" : Ext.isEdge && (t = "Edge"), "".concat(e, "-").concat(t)
                },
                desc: function() {
                    return this.pkgAvailable ? "waiting" === this.status ? -1 !== this.verifyNumber ? String.format(this.TT("authenticator", "request_sent_num_desc"), this.verifyNumber) : this.TT("authenticator", "request_sent_desc") : "denied" === this.status || "revoked" === this.status ? this.TT("authenticator", "request_denied_desc") : "timeout" === this.status ? this.TT("authenticator", "request_timeout_desc") : void 0 : this.is2FA ? this.TT("common", "2fa_package_broken_msg") : this.TT("common", "package_broken_msg")
                },
                title: function() {
                    return this.pkgAvailable ? "waiting" === this.status ? this.TT("authenticator", "approve_sign_in") : "denied" === this.status || "revoked" === this.status ? this.TT("authenticator", "request_denied") : "timeout" === this.status ? this.TT("authenticator", "request_timeout") : void 0 : this.TT("error", "something_wrong")
                },
                trustDevice: {
                    get: function() {
                        return this.$store.state.mainPage.trustDevice
                    },
                    set: function(e) {
                        this.$store.commit("mainPage/updateTrustDevice", e)
                    }
                },
                stayLogin: {
                    get: function() {
                        return this.$store.state.mainPage.stayLogin
                    },
                    set: function(e) {
                        this.$store.commit("mainPage/updateStayLogin", e)
                    }
                }
            },
            beforeRouteEnter: function(e, t, n) {
                n((function(e) {
                    e.login()
                }))
            },
            beforeDestroy: function() {
                this.clearToast(), this.isApproved || this.sendRevoke(this.requestId)
            },
            watch: {
                stayLogin: function(e) {
                    this.loginParams.ui_modify = !0, this.loginParams.rememberme = e ? "1" : "0", synowebapi.request({
                        url: "webapi/entry.cgi?api=SYNO.API.Auth",
                        params: this.loginParams
                    })
                },
                status: function(e) {
                    "waiting" !== e && this.clearToast()
                }
            },
            methods: {
                setTrustDevice: function() {
                    return synowebapi.promises.request({
                        api: "SYNO.Core.TrustDevice",
                        version: 1,
                        method: "create",
                        params: {
                            name: this.getDeviceName
                        }
                    })
                },
                clearToast: function() {
                    var e = this.$root.$refs.view.$refs;
                    Object.prototype.hasOwnProperty.call(e, "toast") && void 0 !== e.toast && e.toast.hideToast(), null !== this.resendTimer && (clearTimeout(this.resendTimer), this.resendTimer = null)
                },
                showResendToast: function() {
                    var e = this,
                        t = Vue.extend({
                            methods: {
                                resend: function() {
                                    e.clearToast(), e.retry = !0, e.sendRevoke(e.requestId), e.requestId = ""
                                }
                            },
                            data: function() {
                                return {
                                    resendBotton: e.TT("authenticator", "login_request_resend_button"),
                                    toastDesc: e.TT("authenticator", "login_request_resend")
                                }
                            },
                            template: '<div class="toast-content" style="margin-right: 0px;"> <div style="display: inline-block; margin-right: 20px;" > {{ toastDesc }} </div> <v-button type="footbar" suffix="blue" @click="resend"> {{ resendBotton }} </v-button> </div>'
                        });
                    this.$emit("show-toast", new t, 45e3)
                },
                sendRevoke: function(e) {
                    if (this.pkgAvailable) {
                        synowebapi.promises.request({
                            api: "SYNO.SecureSignIn.Authenticator.Request",
                            method: "revoke",
                            params: {
                                request_id: e,
                                account: this.$store.state.mainPage.dsmForm.username
                            },
                            version: 1
                        })
                    }
                },
                onRetryClick: function() {
                    this.status = "waiting", this.requestId = "", this.login()
                },
                onLoginFailed: function(e) {
                    var t = this.getLoginErrMsg(e.error.code);
                    "" !== t && (this.loginErrMessage = t)
                },
                login: (a = regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.retry = !1, this.resendTimer = setTimeout(this.showResendToast, 35e3), e.next = 4, this.processLogin();
                            case 4:
                                if (this.retry) {
                                    e.next = 0;
                                    break
                                }
                                case 5:
                                case "end":
                                    return e.stop()
                        }
                    }), e, this)
                })), c = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = a.apply(e, t);

                        function o(e) {
                            r(s, n, i, o, c, "next", e)
                        }

                        function c(e) {
                            r(s, n, i, o, c, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return c.apply(this, arguments)
                }),
                processLogin: function() {
                    var e = this;
                    return this.$emit("spinning", !0), this.sendLoginRequest("get_status").then((function(t) {
                        if (e.$emit("spinning", !1), t.success) return e.requestId = t.data.request_id, Object.prototype.hasOwnProperty.call(t.data, "verify_number") && (e.verifyNumber = t.data.verify_number), e.sendLoginRequest("approved");
                        throw e.onLoginFailed(t), new Error("unexpected error while sending request")
                    })).then((function(t) {
                        if (!e.retry)
                            if (t.success && Object.prototype.hasOwnProperty.call(t.data, "request_status")) e.status = t.data.request_status;
                            else {
                                if (!t.success) throw e.onLoginFailed(t), new Error("unexpected error while approving");
                                e.status = "approved", e.checkedBoxDisabled = !0, e.clearToast(), e.$emit("spinning", !0), e.$emit("enable-bombing-on-done", !0), e.redirectInfo = t, e.$emit("go-desktop", SYNO.SDS.HandShake.GetLoginSynoToken(t)), e.trustDevice && e.setTrustDevice(), e.isMobileDevice && setTimeout((function() {
                                    e.$emit("spinning", !1), e.$emit("enable-bombing-on-done", !1), e.isWaitTooLong = !0
                                }), 3e3)
                            }
                    })).catch((function(t) {
                        e.status = "denied", e.$emit("spinning", !1), e.getPkgStatus().catch((function(t) {
                            102 === t.code && (e.pkgAvailable = !1)
                        }))
                    }))
                },
                sendLoginRequest: function(e) {
                    var t = {
                        account: this.$store.state.mainPage.dsmForm.username,
                        passwd: this.$store.state.mainPage.dsmForm.password,
                        authenticator_token: "",
                        logintype: "local",
                        enable_device_token: this.trustDevice ? "yes" : "no",
                        rememberme: this.stayLogin ? 1 : 0,
                        timezone: this.stdTimezone(),
                        type: "authenticator",
                        application: "DSM",
                        request_id: this.requestId,
                        action: e
                    };
                    return this.loginParams = SYNO.SDS.HandShake.GetLoginParams(t), synowebapi.promises.request({
                        url: "webapi/entry.cgi?api=SYNO.API.Auth",
                        requestFormat: "raw",
                        responseFormat: "raw",
                        method: "POST",
                        params: this.loginParams,
                        encryption: Object.keys(t),
                        encryptionCallback: function(e, t) {
                            e || navigator && !navigator.onLine || window.alert(this.T("login", "error_key_invalid")), t(!0)
                        },
                        scope: this
                    })
                },
                stdTimezone: function() {
                    var e = (new Date).getFullYear(),
                        t = new Date(e, 0, 1).getTimezoneOffset(),
                        n = new Date(e, 6, 1).getTimezoneOffset(),
                        i = t >= n ? t : n;
                    return (i > 0 ? "-" : "+") + ("" + Math.abs(i / 60)).padStart(2, "0") + ":" + ("" + Math.abs(i % 60)).padStart(2, "0")
                },
                doRedirect: function() {
                    this.$emit("go-desktop", SYNO.SDS.HandShake.GetLoginSynoToken(this.redirectInfo))
                }
            }
        },
        p = (n(130), n(1)),
        u = Object(p.a)(d, i, [], !1, null, null, null);
    u.options.__file = "src/login/authenticator-login-panel.vue";
    var l = u.exports,
        g = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", [n("div", [n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.isFailed,
                    expression: "!isFailed"
                }]
            }, [n("div", {
                staticClass: "title"
            }, [e._v(e._s(e.TT("fido", "verifying")))]), e._v(" "), n("div", {
                staticClass: "desc"
            }, [e._v(e._s(e.TT("fido", "complete_login")))])]), e._v(" "), n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.isFailed,
                    expression: "isFailed"
                }],
                staticClass: "failed"
            }, [n("div", {
                staticClass: "title"
            }, [e._v(e._s(e.TT("error", "something_wrong")))]), e._v(" "), n("div", {
                staticClass: "desc",
                domProps: {
                    innerHTML: e._s(e.loginFailedDesc)
                }
            }), e._v(" "), n("div", {
                staticClass: "invalid"
            }, [n("v-button", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.pkgAvailable,
                    expression: "pkgAvailable"
                }],
                staticClass: "try-again",
                attrs: {
                    "syno-id": "secure-signin-fido-login-try-again",
                    type: "footbar",
                    suffix: "blue"
                },
                on: {
                    click: e.onRetryClick
                }
            }, [e._v(e._s(e.TT("authenticator", "try_again")))])], 1)])]), e._v(" "), n("div", {
                staticClass: "tab-footer login-footer"
            }, [n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.loginErrMessage,
                    expression: "loginErrMessage"
                }],
                staticClass: "login-msg-box",
                class: "error",
                domProps: {
                    innerHTML: e._s(e.loginErrMessage)
                }
            }), e._v(" "), n("router-link", {
                staticClass: "tab-footer-link",
                attrs: {
                    to: "/signin/select-auth",
                    replace: ""
                }
            }, [e._v(e._s(e.T("login", "other_ways")))])], 1)])
        };
    g._withStripped = !0;
    var h = n(2),
        f = n(6),
        m = n(7);

    function w(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var v = {
            mixins: [s.a, f.a, o.a],
            name: "FidoLoginPanel",
            data: function() {
                return {
                    status: "",
                    loginErrMessage: "",
                    authUrl: "webapi/entry.cgi?api=SYNO.API.Auth",
                    pkgAvailable: !0
                }
            },
            mounted: function() {
                var e = this;
                Object(m.b)(window.location) ? this.Login() : setTimeout((function() {
                    alert(e.TT("error", "invalid_domain")), e.$router.replace("/signin/select-auth")
                }), 500)
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        w(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(h.mapState)("mainPage", ["activeTabName", "enabledAuthList"]), {
                username: function() {
                    return this.$store.state.mainPage.dsmForm.username
                },
                password: function() {
                    return this.$store.state.mainPage.dsmForm.password
                },
                is2FA: function() {
                    return "" !== this.$store.state.mainPage.dsmForm.password
                },
                isFailed: function() {
                    return "denied" === this.status
                },
                isSupportWebauthn: function() {
                    return "undefined" != typeof PublicKeyCredential
                },
                loginFailedDesc: function() {
                    return this.pkgAvailable ? this.isSupportWebauthn ? this.TT("error", "other_ways_desc") : String.format(this.TT("fido", "platform_key_not_setup_desc"), '<a class="link-font" href="https://fidoalliance.org/fido2/fido2-web-authentication-webauthn/" target="_blank">', "</a>") : this.is2FA ? this.TT("common", "2fa_package_broken_msg") : this.TT("common", "package_broken_msg")
                },
                stayLogin: {
                    get: function() {
                        return this.$store.state.mainPage.stayLogin
                    }
                },
                trustDevice: {
                    get: function() {
                        return this.$store.state.mainPage.trustDevice
                    },
                    set: function(e) {
                        this.$store.commit("mainPage/updateTrustDevice", e)
                    }
                }
            }),
            methods: {
                onRetryClick: function() {
                    this.Login()
                },
                onLoginFailed: function() {
                    this.status = "denied"
                },
                clearStatus: function() {
                    this.loginErrMessage = "", this.status = ""
                },
                Login: function() {
                    var e = this;
                    this.clearStatus();
                    var t = this;
                    t.getAssert("").then((function(n) {
                        if (n.success) return navigator.credentials.get({
                            publicKey: t.getFidoLoginCreds(n.data)
                        });
                        var i = e.getLoginErrMsg(n.error.code);
                        "" !== i && (e.loginErrMessage = i)
                    })).then((function(e) {
                        return t.sendLoginRequest(e)
                    })).catch((function(n) {
                        t.status = "denied", e.getPkgStatus().catch((function(t) {
                            102 === t.code && (e.pkgAvailable = !1)
                        }))
                    }))
                },
                getFidoLoginCreds: function(e) {
                    return e.challenge = this.str2ab(e.challenge), e.allowCredentials.forEach(function(e) {
                        e.id = this.coerceToArrayBuffer(e.id)
                    }.bind(this)), e
                },
                getAssert: function(e) {
                    this.encryptParam = {
                        account: this.username,
                        passwd: this.password,
                        logintype: "local",
                        type: "fido",
                        fido_credentials: e,
                        enable_device_token: this.trustDevice ? "yes" : "no",
                        rememberme: this.stayLogin ? 1 : 0,
                        timezone: this.stdTimezone()
                    };
                    var t = SYNO.SDS.HandShake.GetLoginParams(this.encryptParam);
                    return synowebapi.promises.request({
                        url: this.authUrl,
                        requestFormat: "raw",
                        responseFormat: "raw",
                        method: "POST",
                        params: t,
                        encryption: Object.keys(this.encryptParam),
                        encryptionCallback: function(e, t) {
                            e || navigator && !navigator.onLine || window.alert(this.T("login", "error_key_invalid")), t(!0)
                        },
                        scope: this
                    })
                },
                sendLoginRequest: function(e) {
                    var t = this,
                        n = {
                            id: e.id,
                            rawId: this.coerceToBase64(e.rawId),
                            authenticatorData: this.coerceToBase64(e.response.authenticatorData),
                            clientDataJSON: this.coerceToBase64(e.response.clientDataJSON),
                            signature: this.coerceToBase64(e.response.signature)
                        };
                    if (this.encryptParam) {
                        this.encryptParam.fido_credentials = JSON.stringify(n);
                        var i = SYNO.SDS.HandShake.GetLoginParams(this.encryptParam);
                        return synowebapi.promises.request({
                            url: this.authUrl,
                            requestFormat: "raw",
                            responseFormat: "raw",
                            method: "POST",
                            params: i,
                            encryption: Object.keys(this.encryptParam),
                            encryptionCallback: function(e, t) {
                                e || navigator && !navigator.onLine || window.alert(this.T("login", "error_key_invalid")), t(!0)
                            },
                            scope: this
                        }).then((function(e) {
                            if (e.error) return Promise.reject("login verification failed");
                            t.$emit("spinning", !0), t.$emit("enable-bombing-on-done", !0), t.$emit("go-desktop", SYNO.SDS.HandShake.GetLoginSynoToken(e))
                        }))
                    }
                },
                stdTimezone: function() {
                    var e = (new Date).getFullYear(),
                        t = new Date(e, 0, 1).getTimezoneOffset(),
                        n = new Date(e, 6, 1).getTimezoneOffset(),
                        i = t >= n ? t : n;
                    return (i > 0 ? "-" : "+") + ("" + Math.abs(i / 60)).padStart(2, "0") + ":" + ("" + Math.abs(i % 60)).padStart(2, "0")
                }
            }
        },
        y = (n(134), Object(p.a)(v, g, [], !1, null, "6771b540", null));
    y.options.__file = "src/login/fido-login-panel.vue";
    var x = y.exports,
        b = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                staticClass: "syno-securesignin-enforce-2fa-background"
            }, [n("div", {
                attrs: {
                    id: "sds-login-wallpaper"
                }
            }), e._v(" "), n("v-wizard-window", {
                ref: "window",
                staticClass: "syno-securesignin-enforce-2fa-wizard",
                attrs: {
                    "syno-id": "secure-signin-two-factor-register-wizard-window",
                    title: e.TT("wizard", "2fa_title"),
                    width: "700",
                    height: "554",
                    "before-close": e.onBeforeClose,
                    showClose: !1
                }
            }, [n("v-wizard", {
                ref: "wizard",
                attrs: {
                    "syno-id": "secure-signin-two-factor-register-wizard",
                    "active-step-key": "enforce-2fa-step",
                    "custom-buttons-group": e.customButtonsGroup,
                    "show-left-button": e.showLeftButton,
                    "status-bar-state": e.statusBarState,
                    "show-status-bar": e.showStatusBar,
                    "status-bar-error-text": e.statusBarErrorText
                },
                on: {
                    "current-step": e.onChangeStep,
                    "left-button": e.onLeftButton
                }
            }, [n("enforce-two-factor-welcome-step", {
                attrs: {
                    "step-key": "enforce-2fa-step",
                    "next-step-key": e.welcomeNextStep
                },
                on: {
                    "open-inherit-dialog": e.openInheritDialog
                }
            }), e._v(" "), n("signin-method-step", {
                attrs: {
                    windowRef: e.windowRef,
                    "step-key": "signin-method-step",
                    "signin-method": e.signinMethod,
                    headline: e.TT("wizard", "2fa_desc"),
                    type: "radio",
                    "show-footer": ""
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("approve-signin-welcome-step", {
                attrs: {
                    "step-key": "approve-signin-welcome-step",
                    "next-step-key": "approve-signin-download-app-step",
                    headline: e.TT("authenticator", "sign_in_with_authenticator ")
                }
            }), e._v(" "), n("approve-signin-download-app-step", {
                attrs: {
                    "step-key": "approve-signin-download-app-step",
                    "next-step-key": "approve-signin-scan-qr-step",
                    headline: e.TT("authenticator", "setup_authenticator_desc")
                }
            }), e._v(" "), n("approve-signin-scan-qr-step", {
                attrs: {
                    "step-key": "approve-signin-scan-qr-step",
                    "next-step-key": "approve-signin-summary-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("approve-signin-summary-step", {
                attrs: {
                    "step-key": "approve-signin-summary-step",
                    curDevName: e.curDevName
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("otp-welcome-step", {
                attrs: {
                    "step-key": "otp-welcome-step",
                    "next-step-key": e.jumpStep || "otp-download-app-step"
                }
            }), e._v(" "), n("otp-download-app-step", {
                attrs: {
                    "step-key": "otp-download-app-step",
                    "next-step-key": "otp-qrcode-step",
                    headline: e.T("personal_settings", "otp_wizard_install_app")
                }
            }), e._v(" "), n("otp-qrcode-step", {
                attrs: {
                    "step-key": "otp-qrcode-step",
                    "next-step-key": e.isDomainUser ? "otp-summary-step" : "otp-backup-email-step",
                    headline: e.T("personal_settings", "otp_wizard_install_app")
                },
                on: {
                    "show-otp-secret": e.showOtpSecret,
                    "show-loading": e.showLoading,
                    "hide-loading": e.hideLoading,
                    "show-error": e.showError
                }
            }), e._v(" "), n("otp-backup-email-step", {
                attrs: {
                    "step-key": "otp-backup-email-step",
                    "next-step-key": "otp-summary-step"
                },
                on: {
                    "show-loading": e.showLoading,
                    "hide-loading": e.hideLoading,
                    "show-error": e.showError
                }
            }), e._v(" "), n("otp-summary-step", {
                attrs: {
                    "step-key": "otp-summary-step"
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("fido-select-method-step", {
                attrs: {
                    "step-key": "fido-select-method-step",
                    "next-step-key": "fido-register-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-register-step", {
                attrs: {
                    "step-key": "fido-register-step",
                    "method-select": e.methodSelect
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-keyname-step", {
                attrs: {
                    "step-key": "fido-keyname-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox,
                    close: e.onClose
                }
            }), e._v(" "), n("fido-error-step", {
                attrs: {
                    "step-key": "fido-error-step",
                    "method-select": e.methodSelect,
                    "next-step-key": "fido-register-step"
                }
            }), e._v(" "), n("fido-summary-step", {
                attrs: {
                    "step-key": "fido-summary-step"
                },
                on: {
                    close: e.onClose
                }
            })], 1)], 1)], 1)
        };
    b._withStripped = !0;
    var _ = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-securesignin-enforce-2fa-welcome",
            attrs: {
                "syno-id": "secure-signin-otp-register-wizard-welcome",
                "step-key": e.stepKey,
                headline: e.TT("wizard", "enforce_2fa_headline"),
                "next-step-key": e.nextStepKey,
                type: "welcome",
                preEnterNextStep: e.onPreNext
            }
        }, [n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.TT("wizard", "enforce_2fa_welcome_desc1")) + " ")]), e._v(" "), n("div", {
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.TT("wizard", "enforce_2fa_welcome_desc2"))
            }
        })])
    };

    function S(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    _._withStripped = !0;
    var k = {
            mixins: [o.a, s.a],
            props: {
                nextStepKey: String,
                stepKey: String
            },
            data: function() {
                return {
                    authType: []
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        S(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(h.mapState)(["username", "password", "inheritStatus"])),
            methods: {
                onPreNext: function() {
                    var e = this;
                    return this.getSigninMethod(this.username, this.password).then((function(t) {
                        return !t || (0 === t.auth_type.length || ("done" === e.inheritStatus || (e.$emit("open-inherit-dialog"), !1)))
                    }))
                }
            }
        },
        T = (n(136), Object(p.a)(k, _, [], !1, null, null, null));
    T.options.__file = "src/enforce-2fa-steps/welcome-step.vue";
    var E = T.exports,
        O = n(14),
        N = n(12),
        C = n(9),
        B = n(11),
        P = n(16),
        A = n(28),
        M = n(25),
        z = n(24),
        R = n(27),
        D = n(26),
        I = n(13),
        F = n(18),
        L = n(15),
        j = n(10),
        $ = n(17);

    function q(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function Y(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function K(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    Y(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    Y(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var U, W, H, V, J = {
            mixins: [s.a, o.a],
            components: {
                EnforceTwoFactorWelcomeStep: E,
                SigninMethodStep: O.a,
                approveSigninWelcomeStep: N.a,
                approveSigninDownloadAppStep: C.a,
                approveSigninScanQrStep: B.a,
                approveSigninSummaryStep: P.a,
                otpWelcomeStep: A.a,
                otpBackupEmailStep: M.a,
                otpDownloadAppStep: C.a,
                otpQrcodeStep: z.a,
                otpSummaryStep: D.a,
                fidoSelectMethodStep: I.a,
                fidoRegisterStep: F.a,
                fidoKeynameStep: L.a,
                fidoErrorStep: j.a,
                fidoSummaryStep: $.a
            },
            data: function() {
                return {
                    windowRef: {},
                    disableBack: !1,
                    disableNext: !1,
                    jumpStep: null,
                    nextText: "",
                    showBack: !0,
                    showNext: !0,
                    showStart: !1,
                    showLeftButton: !1,
                    statusBarState: "loading",
                    showStatusBar: !1,
                    statusBarErrorText: this.T("common", "error_system"),
                    curDevName: "",
                    welcomeNextStep: "signin-method-step",
                    serviceAvailable: !1,
                    methodSelect: void 0,
                    isFinished: !1,
                    backgroundStyle: {}
                }
            },
            inject: ["gotoDesktop"],
            props: {
                loginStore: Object
            },
            methods: {
                onChangeStep: function(e) {
                    "enforce-2fa-step" === e.currentStepKey ? (this.showBack = !1, this.showNext = !1, this.showLeftButton = !1, this.showStatusBar = !1) : "signin-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.nextText = this.T("common", "next"), this.showLeftButton = !1, this.showStatusBar = !1) : "approve-signin-welcome-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next")) : "approve-signin-download-app-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.nextText = this.T("common", "next"), this.showLeftButton = !1, this.showStatusBar = !1) : "approve-signin-scan-qr-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.nextText = this.T("common", "next"), this.showLeftButton = !1, this.showStatusBar = !1) : "approve-signin-summary-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.nextText = this.T("common", "done"), this.showLeftButton = !1, this.showStatusBar = !1) : "otp-welcome-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, "" === this.authenticatorId && Number.isNaN(this.fidoUid) ? this.showBack = !this.isOtp : this.showBack = !1, this.showNext = !0, this.showLeftButton = this.otpStepShowLeft, this.showStatusBar = !1) : "otp-backup-email-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1) : "otp-download-app-step" === e.currentStepKey || "otp-qrcode-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1) : "otp-summary-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "done")) : "fido-select-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next")) : "fido-register-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next")) : "fido-keyname-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "done")) : "fido-error-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.TT("authenticator", "try_again")) : "fido-summary-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "done")) : (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next"))
                },
                onBeforeClose: function() {
                    return this.isFinished
                },
                onClose: function() {
                    this.isFinished = !0, this.$refs.window.close(), this.gotoDesktop()
                },
                openInheritDialog: function() {
                    var e = this;
                    this.$refs.window.openModalWindow(SYNO.SDS.SecureSignIn.Register.InheritDialog, {
                        signinMethod: "two-factor",
                        onNotInherit: function() {
                            e.$refs.wizard.currentStep.nextStep()
                        },
                        onInherit: function() {
                            e.$store.commit("SET_INHERIT_STATUS", "done"), e.$refs.window.getMsgBox().confirm(e.TT("wizard", "set_backup_2fa_desc"), String.format(e.TT("wizard", "set_backup_2fa_content"), '<div class="otp-backup-orange">', "</div>"), {
                                cancel: {
                                    text: e.T("common", "no_thanks")
                                },
                                confirm: {
                                    text: e.T("personal_settings", "setup")
                                }
                            }, {
                                useHtml: !0
                            }).then(function() {
                                var t = K(regeneratorRuntime.mark((function t(n) {
                                    return regeneratorRuntime.wrap((function(t) {
                                        for (;;) switch (t.prev = t.next) {
                                            case 0:
                                                "confirm" === n ? (e.welcomeNextStep = "otp-welcome-step", e.$refs.wizard.currentStep.nextStep()) : e.onClose();
                                            case 1:
                                            case "end":
                                                return t.stop()
                                        }
                                    }), t, this)
                                })));
                                return function(e) {
                                    return t.apply(this, arguments)
                                }
                            }())
                        }
                    })
                },
                showLoading: function() {
                    this.statusBarState = "loading", this.showStatusBar = !0, this.showNext && (this.disableNext = !0)
                },
                hideLoading: function() {
                    this.showStatusBar = !1, this.showNext && (this.disableNext = !1)
                },
                showError: function(e) {
                    this.statusBarState = "error", this.showStatusBar = !0, this.statusBarErrorText = e
                },
                openMsgBox: (V = K(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                    var r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.window.getMsgBox().alert(t, n, i, {
                                    useHtml: !0
                                });
                            case 2:
                                r = e.sent, o && o(r);
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t, n, i, s) {
                    return V.apply(this, arguments)
                }),
                openVerifyDialog: (H = K(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                    var r, a, c;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.IdentityVerificationDialog), a = r.window, e.next = 3, a.confirm(t, n, i, {
                                    useHtml: !0
                                });
                            case 3:
                                if ("confirm" === (c = e.sent)) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return");
                            case 6:
                                o && o(c);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t, n, i, s) {
                    return H.apply(this, arguments)
                }),
                showOtpSecret: function() {
                    var e = Vue.extend({
                        template: "<otp-secret-win />",
                        components: {
                            otpSecretWin: R.a
                        },
                        store: this.$store
                    });
                    this.$refs.window.openModalWindow(e)
                },
                initBackground: function() {
                    var e = this.loginStore.state.mainPage.tpl,
                        t = this.getLoginPageSize(),
                        n = t.width,
                        i = t.height;
                    this.backgroundTpl = new SYNO.SDS.BackgroundTpl({
                        el: "#sds-login-wallpaper"
                    }), this.backgroundTpl.setConfig({
                        winW: n,
                        winH: i,
                        type: e.background_pos,
                        imgSrc: e.background_path,
                        bgColor: e.background_color
                    }), e.background_width && 0 < e.background_width && e.background_height && 0 < e.background_height && this.backgroundTpl.setImgSize(e.background_width, e.background_height), window.addEventListener("resize", this.backgroundResizer)
                },
                backgroundResizer: function() {
                    var e = this.getLoginPageSize(),
                        t = e.width,
                        n = e.height;
                    this.backgroundTpl.setConfig({
                        winW: t,
                        winH: n
                    })
                },
                getLoginPageSize: function() {
                    return {
                        width: document.getElementById("sds-login-vue-inst").scrollWidth,
                        height: document.getElementById("sds-login-vue-inst").scrollHeight
                    }
                },
                onLeftButton: (W = K(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.window.getMsgBox().confirmDelete(null, this.TT("otp", "skip_warning_msg"), {
                                    cancel: {
                                        text: this.T("personal_settings", "setup")
                                    },
                                    confirm: {
                                        text: this.T("common", "skip")
                                    }
                                }, {
                                    useHtml: !0
                                });
                            case 2:
                                "confirm" === e.sent && ("" !== this.authenticatorId ? this.jumpStep = "approve-signin-summary-step" : Number.isNaN(this.fidoUid) ? this.jumpStep = "otp-summary-step" : this.jumpStep = "usb" === this.methodSelect ? "fido-keyname-step" : "fido-summary-step", this.$store.commit("SET_SKIP_OTP", !0)), this.$refs.wizard.currentStep.nextStep();
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return W.apply(this, arguments)
                })
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        q(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(h.mapState)(["username", "password", "fidoUid", "authenticatorId"]), {
                otpStepShowLeft: function() {
                    return !!this.authenticatorId || !!this.fidoUid
                },
                customButtonsGroup: function() {
                    return {
                        back: {
                            disabled: this.disableBack,
                            show: this.showBack
                        },
                        next: {
                            disabled: this.disableNext,
                            show: this.showNext,
                            text: this.nextText
                        }
                    }
                },
                isDomainUser: function() {
                    return -1 !== this.$store.state.username.search("\\\\")
                },
                signinMethod: function() {
                    var e = [{
                        title: this.T("personal_settings", "otp_verification_code"),
                        desc: this.T("personal_settings", "verification_code_desc"),
                        nextStep: "otp-welcome-step",
                        extraClass: "otp"
                    }];
                    return this.serviceAvailable && (e.unshift({
                        title: this.TT("authenticator", "approve_sign_in"),
                        desc: this.T("personal_settings", "approve_sign_in_desc"),
                        nextStep: "approve-signin-welcome-step",
                        extraClass: "approved_signin"
                    }), e.push({
                        title: this.TT("fido", "hardware_security_key"),
                        desc: this.TT("wizard", "hardware_security_key_desc"),
                        nextStep: "fido-select-method-step",
                        extraClass: "fido"
                    })), e
                }
            }),
            beforeMount: function() {
                this.$windowManager.setContainerEl(document.body), this.$windowManager.setZIndex(3e4)
            },
            beforeDestroy: function() {
                this.backgroundTpl.$destroy(), window.removeEventListener("resize", this.backgroundResizer)
            },
            mounted: (U = K(regeneratorRuntime.mark((function e() {
                var t, n, i = this;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (this.$store.commit("SET_SIGNIN_MODE", "two-factor"), this.windowRef = this.$refs.window, this.initBackground(), !this.loginStore) {
                                e.next = 17;
                                break
                            }
                            return e.prev = 4, e.next = 7, synowebapi.promises.request({
                                api: "SYNO.SecureSignIn.Method.Ex",
                                version: 1,
                                method: "get_user",
                                params: {
                                    username: this.loginStore.state.mainPage.dsmForm.username,
                                    password: this.loginStore.state.mainPage.dsmForm.password
                                },
                                encryption: ["username", "password"]
                            });
                        case 7:
                            n = e.sent, t = n.username, e.next = 15;
                            break;
                        case 11:
                            e.prev = 11, e.t0 = e.catch(4), console.log(e.t0), t = this.loginStore.state.mainPage.dsmForm.username;
                        case 15:
                            this.$store.commit("SET_USERNAME", t), this.$store.commit("SET_PASSWORD", this.loginStore.state.mainPage.dsmForm.password);
                        case 17:
                            try {
                                this.getPackageStatus(this.username, this.password).then((function(e) {
                                    i.serviceAvailable = e.account_status && e.enabled
                                }))
                            } catch (e) {
                                console.log(e)
                            }
                            case 18:
                            case "end":
                                return e.stop()
                    }
                }), e, this, [
                    [4, 11]
                ])
            }))), function() {
                return U.apply(this, arguments)
            })
        },
        Q = (n(138), Object(p.a)(J, b, [], !1, null, null, null));
    Q.options.__file = "src/login/enforce-2fa-wizard.vue";
    var G = Q.exports,
        Z = n(19);

    function X(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    }

    function ee(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
        }
    }

    function te(e, t, n) {
        return t && ee(e.prototype, t), n && ee(e, n), e
    }
    var ne = function() {
            function e(t) {
                X(this, e), this._itemCallback = this.getItemCallback(t), this._routes = this.getRoutes()
            }
            return te(e, [{
                key: "getItemCallback",
                value: function(e) {
                    return function() {
                        e.replace("/signin/authenticator")
                    }
                }
            }, {
                key: "getRoutes",
                value: function() {
                    return [{
                        path: "/signin/authenticator",
                        component: l,
                        beforeEnter: function(e, t, n) {
                            n()
                        }
                    }]
                }
            }, {
                key: "id",
                get: function() {
                    return "authenticator"
                }
            }, {
                key: "entry",
                get: function() {
                    return "/signin/authenticator"
                }
            }, {
                key: "itemInfo",
                get: function() {
                    return {
                        iconPath: "webman/3rdparty/SecureSignIn/images/1x/icn_32_approve_sign_in.png",
                        icon2xPath: "webman/3rdparty/SecureSignIn/images/2x/icn_32_approve_sign_in.png",
                        description: _TT("authenticator", "authenticator", "login_page_desc"),
                        callback: this._itemCallback
                    }
                }
            }, {
                key: "routes",
                get: function() {
                    return this._routes
                }
            }]), e
        }(),
        ie = function() {
            function e(t) {
                X(this, e), this._itemCallback = this.getItemCallback(t), this._routes = this.getRoutes()
            }
            return te(e, [{
                key: "getItemCallback",
                value: function(e) {
                    return function() {
                        Object(m.b)(window.location) ? e.replace("/signin/fido") : alert(_TT("fido", "error", "invalid_domain"))
                    }
                }
            }, {
                key: "getRoutes",
                value: function() {
                    return [{
                        path: "/signin/fido",
                        component: x,
                        beforeEnter: function(e, t, n) {
                            n()
                        }
                    }]
                }
            }, {
                key: "id",
                get: function() {
                    return "fido"
                }
            }, {
                key: "entry",
                get: function() {
                    return "/signin/fido"
                }
            }, {
                key: "itemInfo",
                get: function() {
                    return {
                        iconPath: "webman/3rdparty/SecureSignIn/images/1x/icn_32_Key.png",
                        icon2xPath: "webman/3rdparty/SecureSignIn/images/2x/icn_32_Key.png",
                        description: _TT("fido", "fido", "login_page_desc"),
                        callback: this._itemCallback
                    }
                }
            }, {
                key: "routes",
                get: function() {
                    return this._routes
                }
            }]), e
        }(),
        se = function() {
            function e(t, n) {
                X(this, e), this._routes = this.getRoutes(n)
            }
            return te(e, [{
                key: "getRoutes",
                value: function(e) {
                    return [{
                        path: "/enforce-2fa-wizard",
                        component: {
                            template: '<EnforceTwoFactorWizard :loginStore="loginStore"/>',
                            components: {
                                EnforceTwoFactorWizard: G
                            },
                            store: Z.a,
                            props: {
                                loginStore: {
                                    type: Object
                                }
                            }
                        },
                        props: {
                            loginStore: e
                        }
                    }]
                }
            }, {
                key: "id",
                get: function() {
                    return "enforce-2fa-wizard"
                }
            }, {
                key: "entry",
                get: function() {
                    return "/enforce-2fa-wizard"
                }
            }, {
                key: "routes",
                get: function() {
                    return this._routes
                }
            }, {
                key: "routeOnly",
                get: function() {
                    return !0
                }
            }]), e
        }();
    SYNO.SDS.LoginPlugins._registerQueue && (SYNO.SDS.LoginPlugins.register(ie), SYNO.SDS.LoginPlugins.register(ne), SYNO.SDS.LoginPlugins.register(se))
}, function(e, t, n) {
    n(142), e.exports = n(58)
}, function(e, t, n) {
    "use strict";
    n(29)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(62)),
        o = i(n(63)),
        r = i(n(64)),
        a = i(n(65));
    t.push([e.i, '.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .content,.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .title,.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method .bold{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .title,.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .syno-cjk .title,.syno-cjk .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method .bold,.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method .syno-cjk .bold{font-weight:600}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-advance-signin-method .signin-desc{font-size:13px;padding-top:4px;padding-bottom:10px;line-height:20px}.syno-securesignin-advance-signin-method .v-toast-text{color:#009E05}.syno-securesignin-advance-signin-method .card-wrapper{margin-bottom:4px}.syno-securesignin-advance-signin-method .method-card-wrapper{border:1px solid rgba(198,212,224,0.7);border-left:3px solid rgba(198,212,224,0.7);max-width:1000px;cursor:pointer}.syno-securesignin-advance-signin-method .method-card-wrapper:nth-of-type(1){border-bottom:1px solid rgba(0,0,0,0)}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card{border-right:1px solid rgba(0,0,0,0);box-sizing:border-box;background:#FFFFFF;display:flex;padding:20px 0px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card:click{background:rgba(5,127,235,0.1)}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card:hover{background:rgba(5,127,235,0.04);border:1px solid #057FEB;border-left:3px solid #057FEB;margin:-1px 0px -1px -3px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card:hover .arrow{background-position-y:-24px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card:active{background:rgba(5,127,235,0.12);border:1px solid #057FEB;border-left:3px solid #057FEB;margin:-1px 0px -1px -3px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card:active .arrow{background-position-y:-24px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card.enabled{border-left:3px solid #057FEB;margin-left:-3px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card.enabled .card-icon{visibility:visible}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-icon{display:inline-block;height:16px;margin:auto 20px auto 19px;visibility:hidden;width:16px;flex:0 0 16px;background-size:16px 16px;background-image:url(' + s + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/method_status.png") image-height("~@/../images/1x/method_status.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/method_status.png") image-height("~@/../images/1x/method_status.png");outline:1px green dashed}}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info{display:inline-block;width:100%}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .title{color:#414b55;font-size:13px;line-height:20px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .content{color:#414b55;font-size:13px;line-height:20px;padding-top:8px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method{color:#414b55;font-size:13px;line-height:20px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .card-info .signin_method.first-step{padding-top:8px}.syno-securesignin-advance-signin-method .method-card-wrapper .method-card .arrow{background-position-x:24px;display:inline-block;height:24px;margin:auto 30px;width:24px;flex:0 0 24px;background-size:48px 48px;background-image:url(' + r + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .arrow{background-image:url(" + a + ');background-size:image-width("~@/../images/1x/bt_prev_next.png") image-height("~@/../images/1x/bt_prev_next.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-advance-signin-method .method-card-wrapper .method-card .arrow{background-image:url(' + a + ');background-size:image-width("~@/../images/1x/bt_prev_next.png") image-height("~@/../images/1x/bt_prev_next.png");outline:1px green dashed}}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/914b083d90de791a1ed10ff699485d97.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/fa560b6715ee1eff438c9fb2330a7bc3.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/e8104ebeb834b453e4c82264dc7636c6.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/b1bb2ad9cb6b7e7093832e990d6c9bf7.png"
}, function(e, t, n) {
    "use strict";
    n(30)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(20)),
        o = i(n(21));
    t.push([e.i, '.authenticator-setting .mask-wrapper .mask-desc-ct div a,.authenticator-setting .signin-field-set .display-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.authenticator-setting .mask-wrapper .mask-desc-ct{margin:24px;padding:17px 19px;max-width:400px;min-height:20px;border:1px solid rgba(198,212,224,0.7);border-radius:3px;box-shadow:0 1px 4px 0 rgba(0,0,0,0.16);background-position:20px 10px;background-repeat:no-repeat;cursor:default}.authenticator-setting .mask-wrapper .mask-desc-ct div{padding:0px;min-height:20px;display:table-cell;vertical-align:middle;word-wrap:break-word;cursor:default;font-size:13px;color:#414b55;line-height:20px}.authenticator-setting .mask-wrapper .mask-desc-ct div a{color:#057FEB}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-2fa-settings .content-wrapper,.syno-securesignin-passwordless-settings .content-wrapper{padding:8px 20px 0px 20px}.syno-securesignin-2fa-settings .content-wrapper .v-fieldset-title-wrapper,.syno-securesignin-passwordless-settings .content-wrapper .v-fieldset-title-wrapper{padding:0px 8px 4px 4px}.syno-securesignin-2fa-settings .content-wrapper .setting-field,.syno-securesignin-passwordless-settings .content-wrapper .setting-field{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .v-fieldset-body,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .v-fieldset-body{padding:8px 0px 0px 0px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn{margin:0px 4px 0px 2px}.syno-securesignin-2fa-settings .v-form,.syno-securesignin-passwordless-settings .v-form{line-height:20px}.syno-securesignin-2fa-settings .v-form .desc,.syno-securesignin-passwordless-settings .v-form .desc{padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time,.syno-securesignin-passwordless-settings .v-form .activated-time{margin:6px 0px 0px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .time,.syno-securesignin-passwordless-settings .v-form .activated-time .time{display:inline-block;line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-label,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-label{line-height:20px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-input .v-form-displayfield,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-input .v-form-displayfield{padding:0px}.syno-securesignin-2fa-settings .v-form .activated-time .btn,.syno-securesignin-passwordless-settings .v-form .activated-time .btn{margin-left:8px}.syno-securesignin-2fa-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-2fa-settings .authenticator-setting-dialog .body-wrapper .data-table{height:169px}.syno-securesignin-passwordless-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-passwordless-settings .authenticator-setting-dialog .body-wrapper .data-table{height:189px}.setting.dialog .empty-style .body-wrapper{align-items:center;display:flex;flex-direction:column;justify-content:center}.setting.dialog .empty-style .body-wrapper .icon{background-size:120px 120px;background-image:url(' + s + ");height:120px;margin:0 auto;width:120px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .setting.dialog .empty-style .body-wrapper .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .setting.dialog .empty-style .body-wrapper .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png");outline:1px green dashed}}.setting.dialog .empty-style .body-wrapper .desc{margin:0px;text-align:center;width:330px;line-height:20px;opacity:60%}.setting.dialog .empty-style .body-wrapper .btn{display:block;margin:16px auto 0px}.setting.dialog .empty-style .fbar-wrapper{margin:0px}.setting.dialog .empty-style.v-panel{padding-top:0px}.setting.dialog .normal-style.v-panel{padding-top:0px}.setting.dialog .normal-style .tbar-wrapper{padding-top:8px}.setting.dialog .cell-vertical-middle td{vertical-align:middle}.authenticator-setting-dialog .body-wrapper{flex-direction:column;overflow:hidden}.authenticator-setting-dialog .body-wrapper .data-table{overflow:hidden}.authenticator-setting{position:relative}.authenticator-setting .v-textfield-input{width:246px}.authenticator-setting .v-ps{padding-right:0}.authenticator-setting .signin-field-set .display-title.signin-in-methods{margin-top:12px}.authenticator-setting .signin-field-set .display-title.second-step{margin-top:12px}.authenticator-setting .signin-field-set .signin-in-methods-desc{margin-bottom:12px}.authenticator-setting .mask-wrapper,.authenticator-setting .mask-wrapper .mask-cover{position:absolute;top:0;bottom:0;left:0;right:0}.authenticator-setting .mask-wrapper{display:flex;justify-content:center;align-items:center}.authenticator-setting .mask-wrapper .mask-cover{opacity:.5;background-color:#fff;z-index:20000}.authenticator-setting .mask-wrapper .mask-desc-ct{background-color:#FFFFFF;z-index:20001}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(31)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-window .setting.dialog .padding-bottom-2{padding-bottom:2px}.syno-securesignin-window .setting.dialog .form-item{padding:8px 0px 6px 0px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(32)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(20)),
        o = i(n(21));
    t.push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-2fa-settings .content-wrapper,.syno-securesignin-passwordless-settings .content-wrapper{padding:8px 20px 0px 20px}.syno-securesignin-2fa-settings .content-wrapper .v-fieldset-title-wrapper,.syno-securesignin-passwordless-settings .content-wrapper .v-fieldset-title-wrapper{padding:0px 8px 4px 4px}.syno-securesignin-2fa-settings .content-wrapper .setting-field,.syno-securesignin-passwordless-settings .content-wrapper .setting-field{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .v-fieldset-body,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .v-fieldset-body{padding:8px 0px 0px 0px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn{margin:0px 4px 0px 2px}.syno-securesignin-2fa-settings .v-form,.syno-securesignin-passwordless-settings .v-form{line-height:20px}.syno-securesignin-2fa-settings .v-form .desc,.syno-securesignin-passwordless-settings .v-form .desc{padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time,.syno-securesignin-passwordless-settings .v-form .activated-time{margin:6px 0px 0px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .time,.syno-securesignin-passwordless-settings .v-form .activated-time .time{display:inline-block;line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-label,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-label{line-height:20px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-input .v-form-displayfield,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-input .v-form-displayfield{padding:0px}.syno-securesignin-2fa-settings .v-form .activated-time .btn,.syno-securesignin-passwordless-settings .v-form .activated-time .btn{margin-left:8px}.syno-securesignin-2fa-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-2fa-settings .authenticator-setting-dialog .body-wrapper .data-table{height:169px}.syno-securesignin-passwordless-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-passwordless-settings .authenticator-setting-dialog .body-wrapper .data-table{height:189px}.setting.dialog .empty-style .body-wrapper{align-items:center;display:flex;flex-direction:column;justify-content:center}.setting.dialog .empty-style .body-wrapper .icon{background-size:120px 120px;background-image:url(' + s + ");height:120px;margin:0 auto;width:120px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .setting.dialog .empty-style .body-wrapper .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .setting.dialog .empty-style .body-wrapper .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png");outline:1px green dashed}}.setting.dialog .empty-style .body-wrapper .desc{margin:0px;text-align:center;width:330px;line-height:20px;opacity:60%}.setting.dialog .empty-style .body-wrapper .btn{display:block;margin:16px auto 0px}.setting.dialog .empty-style .fbar-wrapper{margin:0px}.setting.dialog .empty-style.v-panel{padding-top:0px}.setting.dialog .normal-style.v-panel{padding-top:0px}.setting.dialog .normal-style .tbar-wrapper{padding-top:8px}.setting.dialog .cell-vertical-middle td{vertical-align:middle}.syno-fido-app-msg-box .dialog-content{overflow:hidden;word-break:break-all}.fido-setting-dialog .body-wrapper{flex-direction:column;overflow:hidden}.fido-setting-dialog .body-wrapper .data-table{overflow:hidden}.fido-setting-dialog .body-wrapper .data-table tr.row{height:48px}.fido-setting-dialog .body-wrapper .data-table td{vertical-align:top;padding:4px 0px;height:48px}.fido-setting-dialog .body-wrapper .data-table td .inner-cell{height:40px}.fido-setting-dialog .body-wrapper .data-table td .inner-cell .content-cell{line-height:20px;height:40px}.fido-setting-dialog .body-wrapper .data-table td .inner-cell .content-cell div{height:20px}.fido-setting-dialog .body-wrapper .data-table td.cell-first .content-cell{white-space:normal;word-break:break-word;-webkit-line-clamp:2;-webkit-box-orient:vertical;display:-webkit-box}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(33)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(20)),
        o = i(n(21));
    t.push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-2fa-settings .content-wrapper,.syno-securesignin-passwordless-settings .content-wrapper{padding:8px 20px 0px 20px}.syno-securesignin-2fa-settings .content-wrapper .v-fieldset-title-wrapper,.syno-securesignin-passwordless-settings .content-wrapper .v-fieldset-title-wrapper{padding:0px 8px 4px 4px}.syno-securesignin-2fa-settings .content-wrapper .setting-field,.syno-securesignin-passwordless-settings .content-wrapper .setting-field{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .v-fieldset-body,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .v-fieldset-body{padding:8px 0px 0px 0px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn{margin:0px 4px 0px 2px}.syno-securesignin-2fa-settings .v-form,.syno-securesignin-passwordless-settings .v-form{line-height:20px}.syno-securesignin-2fa-settings .v-form .desc,.syno-securesignin-passwordless-settings .v-form .desc{padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time,.syno-securesignin-passwordless-settings .v-form .activated-time{margin:6px 0px 0px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .time,.syno-securesignin-passwordless-settings .v-form .activated-time .time{display:inline-block;line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-label,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-label{line-height:20px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-input .v-form-displayfield,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-input .v-form-displayfield{padding:0px}.syno-securesignin-2fa-settings .v-form .activated-time .btn,.syno-securesignin-passwordless-settings .v-form .activated-time .btn{margin-left:8px}.syno-securesignin-2fa-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-2fa-settings .authenticator-setting-dialog .body-wrapper .data-table{height:169px}.syno-securesignin-passwordless-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-passwordless-settings .authenticator-setting-dialog .body-wrapper .data-table{height:189px}.setting.dialog .empty-style .body-wrapper{align-items:center;display:flex;flex-direction:column;justify-content:center}.setting.dialog .empty-style .body-wrapper .icon{background-size:120px 120px;background-image:url(' + s + ");height:120px;margin:0 auto;width:120px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .setting.dialog .empty-style .body-wrapper .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .setting.dialog .empty-style .body-wrapper .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png");outline:1px green dashed}}.setting.dialog .empty-style .body-wrapper .desc{margin:0px;text-align:center;width:330px;line-height:20px;opacity:60%}.setting.dialog .empty-style .body-wrapper .btn{display:block;margin:16px auto 0px}.setting.dialog .empty-style .fbar-wrapper{margin:0px}.setting.dialog .empty-style.v-panel{padding-top:0px}.setting.dialog .normal-style.v-panel{padding-top:0px}.setting.dialog .normal-style .tbar-wrapper{padding-top:8px}.setting.dialog .cell-vertical-middle td{vertical-align:middle}.syno-securesignin-passwordless-settings .setting.dialog .empty-style .body-wrapper{height:244px}.syno-securesignin-passwordless-settings .setting.dialog .normal-style .v-spin-wrapper.v-panel-wrapper{height:232px;padding-bottom:12px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(34)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(20)),
        o = i(n(21));
    t.push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-2fa-settings .content-wrapper,.syno-securesignin-passwordless-settings .content-wrapper{padding:8px 20px 0px 20px}.syno-securesignin-2fa-settings .content-wrapper .v-fieldset-title-wrapper,.syno-securesignin-passwordless-settings .content-wrapper .v-fieldset-title-wrapper{padding:0px 8px 4px 4px}.syno-securesignin-2fa-settings .content-wrapper .setting-field,.syno-securesignin-passwordless-settings .content-wrapper .setting-field{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .v-fieldset-body,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .v-fieldset-body{padding:8px 0px 0px 0px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn{margin:0px 4px 0px 2px}.syno-securesignin-2fa-settings .v-form,.syno-securesignin-passwordless-settings .v-form{line-height:20px}.syno-securesignin-2fa-settings .v-form .desc,.syno-securesignin-passwordless-settings .v-form .desc{padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time,.syno-securesignin-passwordless-settings .v-form .activated-time{margin:6px 0px 0px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .time,.syno-securesignin-passwordless-settings .v-form .activated-time .time{display:inline-block;line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-label,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-label{line-height:20px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-input .v-form-displayfield,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-input .v-form-displayfield{padding:0px}.syno-securesignin-2fa-settings .v-form .activated-time .btn,.syno-securesignin-passwordless-settings .v-form .activated-time .btn{margin-left:8px}.syno-securesignin-2fa-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-2fa-settings .authenticator-setting-dialog .body-wrapper .data-table{height:169px}.syno-securesignin-passwordless-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-passwordless-settings .authenticator-setting-dialog .body-wrapper .data-table{height:189px}.setting.dialog .empty-style .body-wrapper{align-items:center;display:flex;flex-direction:column;justify-content:center}.setting.dialog .empty-style .body-wrapper .icon{background-size:120px 120px;background-image:url(' + s + ");height:120px;margin:0 auto;width:120px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .setting.dialog .empty-style .body-wrapper .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .setting.dialog .empty-style .body-wrapper .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png");outline:1px green dashed}}.setting.dialog .empty-style .body-wrapper .desc{margin:0px;text-align:center;width:330px;line-height:20px;opacity:60%}.setting.dialog .empty-style .body-wrapper .btn{display:block;margin:16px auto 0px}.setting.dialog .empty-style .fbar-wrapper{margin:0px}.setting.dialog .empty-style.v-panel{padding-top:0px}.setting.dialog .normal-style.v-panel{padding-top:0px}.setting.dialog .normal-style .tbar-wrapper{padding-top:8px}.setting.dialog .cell-vertical-middle td{vertical-align:middle}.otp-panel{padding:8px 8px 0px 8px}.otp-setting-dialog{height:236px}.otp-setting-dialog .title{font-weight:bold;line-height:28px}.otp-setting-dialog .desc{line-height:20px;margin:10px 0px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(35)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(20)),
        o = i(n(21));
    t.push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-2fa-settings .content-wrapper,.syno-securesignin-passwordless-settings .content-wrapper{padding:8px 20px 0px 20px}.syno-securesignin-2fa-settings .content-wrapper .v-fieldset-title-wrapper,.syno-securesignin-passwordless-settings .content-wrapper .v-fieldset-title-wrapper{padding:0px 8px 4px 4px}.syno-securesignin-2fa-settings .content-wrapper .setting-field,.syno-securesignin-passwordless-settings .content-wrapper .setting-field{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .v-fieldset-body,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .v-fieldset-body{padding:8px 0px 0px 0px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs{margin-top:8px}.syno-securesignin-2fa-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn,.syno-securesignin-passwordless-settings .content-wrapper .setting-field .syno-sds-personal-tabs #tab-approveSignIn{margin:0px 4px 0px 2px}.syno-securesignin-2fa-settings .v-form,.syno-securesignin-passwordless-settings .v-form{line-height:20px}.syno-securesignin-2fa-settings .v-form .desc,.syno-securesignin-passwordless-settings .v-form .desc{padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time,.syno-securesignin-passwordless-settings .v-form .activated-time{margin:6px 0px 0px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .time,.syno-securesignin-passwordless-settings .v-form .activated-time .time{display:inline-block;line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-label,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-label{line-height:20px}.syno-securesignin-2fa-settings .v-form .activated-time .v-form-item-input .v-form-displayfield,.syno-securesignin-passwordless-settings .v-form .activated-time .v-form-item-input .v-form-displayfield{padding:0px}.syno-securesignin-2fa-settings .v-form .activated-time .btn,.syno-securesignin-passwordless-settings .v-form .activated-time .btn{margin-left:8px}.syno-securesignin-2fa-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-2fa-settings .authenticator-setting-dialog .body-wrapper .data-table{height:169px}.syno-securesignin-passwordless-settings .fido-setting-dialog .body-wrapper .data-table,.syno-securesignin-passwordless-settings .authenticator-setting-dialog .body-wrapper .data-table{height:189px}.setting.dialog .empty-style .body-wrapper{align-items:center;display:flex;flex-direction:column;justify-content:center}.setting.dialog .empty-style .body-wrapper .icon{background-size:120px 120px;background-image:url(' + s + ");height:120px;margin:0 auto;width:120px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .setting.dialog .empty-style .body-wrapper .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .setting.dialog .empty-style .body-wrapper .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_empty_default.png") image-height("~@/../images/1x/icn_empty_default.png");outline:1px green dashed}}.setting.dialog .empty-style .body-wrapper .desc{margin:0px;text-align:center;width:330px;line-height:20px;opacity:60%}.setting.dialog .empty-style .body-wrapper .btn{display:block;margin:16px auto 0px}.setting.dialog .empty-style .fbar-wrapper{margin:0px}.setting.dialog .empty-style.v-panel{padding-top:0px}.setting.dialog .normal-style.v-panel{padding-top:0px}.setting.dialog .normal-style .tbar-wrapper{padding-top:8px}.setting.dialog .cell-vertical-middle td{vertical-align:middle}.syno-securesignin-2fa-settings .content-wrapper{padding-right:5px;height:476px}.syno-securesignin-2fa-settings .content-wrapper .otp-field-set .field-set-wrapper .desc{line-height:20px;padding:4px 0px}.syno-securesignin-2fa-settings .content-wrapper .otp-field-set .field-set-wrapper .btn{margin-top:10px}.syno-securesignin-2fa-settings .setting.dialog .empty-style .body-wrapper{height:222px}.syno-securesignin-2fa-settings .setting.dialog .normal-style .v-spin-wrapper.v-panel-wrapper{height:210px;padding-bottom:12px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(36)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.secure-signin-inherit-dialog .v-radio-group{margin-top:16px}.secure-signin-inherit-dialog .v-spin-wrapper.v-table-wrapper{margin:6px 0px}.secure-signin-inherit-dialog .note{margin-top:6px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(37)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(82)),
        o = i(n(83)),
        r = i(n(84)),
        a = i(n(85)),
        c = i(n(86)),
        d = i(n(87));
    t.push([e.i, '.syno-securesignin-wizard-signin-method .card-view .content .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-wizard-signin-method{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-wizard-signin-method .v-form{padding-top:24px}.syno-securesignin-wizard-signin-method .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-wizard-signin-method .card-view{align-items:center;background-repeat:no-repeat;border:2px solid rgba(50,60,70,0.1);box-shadow:0 2px 4px 0 rgba(50,60,70,0.05);border-radius:4px;cursor:pointer;display:flex;height:126px;margin-bottom:12px}.syno-securesignin-wizard-signin-method .card-view.last{margin-bottom:0px}.syno-securesignin-wizard-signin-method .card-view:hover{background:rgba(5,127,235,0.06);border:2px solid #057FEB;box-shadow:0 2px 6px 0 rgba(5,127,235,0.16)}.syno-securesignin-wizard-signin-method .card-view.select{background:rgba(5,127,235,0.06);border:2px solid #057FEB;box-shadow:0 2px 6px 0 rgba(5,127,235,0.16)}.syno-securesignin-wizard-signin-method .card-view.approved_signin .icon{background-size:72px 72px;background-image:url(' + s + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-wizard-signin-method .card-view.approved_signin .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_approve_sign_in_72.png") image-height("~@/../images/1x/icn_approve_sign_in_72.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-wizard-signin-method .card-view.approved_signin .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_approve_sign_in_72.png") image-height("~@/../images/1x/icn_approve_sign_in_72.png");outline:1px green dashed}}.syno-securesignin-wizard-signin-method .card-view.otp .icon{background-size:72px 72px;background-image:url(' + r + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-wizard-signin-method .card-view.otp .icon{background-image:url(" + a + ');background-size:image-width("~@/../images/1x/icn_otp_72.png") image-height("~@/../images/1x/icn_otp_72.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-wizard-signin-method .card-view.otp .icon{background-image:url(' + a + ');background-size:image-width("~@/../images/1x/icn_otp_72.png") image-height("~@/../images/1x/icn_otp_72.png");outline:1px green dashed}}.syno-securesignin-wizard-signin-method .card-view.fido .icon{background-size:72px 72px;background-image:url(' + c + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-wizard-signin-method .card-view.fido .icon{background-image:url(" + d + ');background-size:image-width("~@/../images/1x/icn_security_key_72.png") image-height("~@/../images/1x/icn_security_key_72.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-wizard-signin-method .card-view.fido .icon{background-image:url(' + d + ');background-size:image-width("~@/../images/1x/icn_security_key_72.png") image-height("~@/../images/1x/icn_security_key_72.png");outline:1px green dashed}}.syno-securesignin-wizard-signin-method .card-view .icon{display:inline-block;height:72px;margin:0px 0px 0px 32px;width:72px}.syno-securesignin-wizard-signin-method .card-view .content{display:inline-block;max-width:492px;margin-right:24px}.syno-securesignin-wizard-signin-method .card-view .content .title{color:#414b55;display:inline;font-size:15px;line-height:24px;height:24px;margin-left:32px}.syno-securesignin-wizard-signin-method .card-view .content .recommend{color:#057FEB}.syno-securesignin-wizard-signin-method .card-view .content .desc{color:#414b55;line-height:20px;margin:4px 0px 0px 32px}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/12c5436953348e0a63f0a3c069b75709.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/e2e9f8a2bc4eb592ffcac53601eaa188.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/863562b22aa3dc8bbf58a8dca5da6530.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/63dfa78e320744065369db6fadebbc34.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/a413c2672162c08e3fd8ee969f811799.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/25405223777ddf20c4bb7fc7d24386ea.png"
}, function(e, t, n) {
    "use strict";
    n(38)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(90)),
        o = i(n(91));
    t.push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-authenticator-wizard-welcome{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-authenticator-wizard-welcome .v-form{padding-top:24px}.syno-securesignin-authenticator-wizard-welcome .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-authenticator-wizard-welcome .desc{line-height:20px;padding:4px 0px}.syno-securesignin-authenticator-wizard-welcome .flow{margin:6px 0px 0px 0px;padding:4px 0px;line-height:20px}.syno-securesignin-authenticator-wizard-welcome .welcome_img{background-size:440px 160px;background-image:url(' + s + ");height:160px;margin:12px auto;width:440px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-authenticator-wizard-welcome .welcome_img{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/illu_approve_sign-in.png") image-height("~@/../images/1x/illu_approve_sign-in.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-authenticator-wizard-welcome .welcome_img{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/illu_approve_sign-in.png") image-height("~@/../images/1x/illu_approve_sign-in.png");outline:1px green dashed}}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/750f7a07baece13adf8e4037127f5463.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/b63453239e4b770d6ccb37e4c99e5a22.png"
}, function(e, t, n) {
    "use strict";
    n(39)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(94)),
        o = i(n(95)),
        r = i(n(96)),
        a = i(n(97)),
        c = i(n(98)),
        d = i(n(99));
    t.push([e.i, '.syno-securesignin-authenticator-wizard-download-app .qrcode-box label{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-authenticator-wizard-download-app{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-authenticator-wizard-download-app .v-form{padding-top:24px}.syno-securesignin-authenticator-wizard-download-app .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-authenticator-wizard-download-app .desc{line-height:20px;padding:4px 0px}.syno-securesignin-authenticator-wizard-download-app .qrcode-box{background:#FFFFFF;border:1px solid rgba(198,212,224,0.7);border-radius:4px;display:inline-block;margin:6px 0px 0px 0px;height:98px;width:240px}.syno-securesignin-authenticator-wizard-download-app .qrcode-box:nth-child(2){margin-left:16px}.syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode{display:inline-block;height:82px;margin:8px;width:82px}.syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.ios{background-size:82px 82px;background-image:url(' + s + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.ios{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/qr_ios.png") image-height("~@/../images/1x/qr_ios.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.ios{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/qr_ios.png") image-height("~@/../images/1x/qr_ios.png");outline:1px green dashed}}.syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android{background-size:82px 82px;background-image:url(' + r + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android{background-image:url(" + a + ');background-size:image-width("~@/../images/1x/qr_android.png") image-height("~@/../images/1x/qr_android.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android{background-image:url(' + a + ');background-size:image-width("~@/../images/1x/qr_android.png") image-height("~@/../images/1x/qr_android.png");outline:1px green dashed}}.syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android-cn{background-size:82px 82px;background-image:url(' + c + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android-cn{background-image:url(" + d + ');background-size:image-width("~@/../images/1x/qr_android_cn.png") image-height("~@/../images/1x/qr_android_cn.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-authenticator-wizard-download-app .qrcode-box .qrcode.android-cn{background-image:url(' + d + ');background-size:image-width("~@/../images/1x/qr_android_cn.png") image-height("~@/../images/1x/qr_android_cn.png");outline:1px green dashed}}.syno-securesignin-authenticator-wizard-download-app .qrcode-box label{color:#057FEB;text-decoration:underline;display:inline-block;font-size:13px;line-height:98px;text-align:center;vertical-align:top;width:118px}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/86a68ce39b7e900d7ea78c6f96f1115c.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/d1e3cda46670232da2bb83cb51fb14c3.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/4cebf1eb7c27b40479882f7c3978b3b0.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/137a3bb6e6caa2c44fdfae770ddc085c.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/968c1e5f61e390d26faad52763a59912.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/9164a8aea672733d7416e84646ed87d9.png"
}, function(e, t, n) {
    "use strict";
    n(40)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-authenticator-wizard-scan-qr .syno-ux-note{color:#00A6A6}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-authenticator-wizard-scan-qr{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-authenticator-wizard-scan-qr .v-form{padding-top:24px}.syno-securesignin-authenticator-wizard-scan-qr .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-authenticator-wizard-scan-qr .desc{line-height:20px}.syno-securesignin-authenticator-wizard-scan-qr .qrcode{display:block;height:200px;margin:12px auto;width:200px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(41)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.item-container .block .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-authenticator-wizard-summary{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-authenticator-wizard-summary .v-form{padding-top:24px}.syno-securesignin-authenticator-wizard-summary .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.item-container{margin:12px 0px 0px 0px;font-size:13px}.item-container .login-method{height:28px;border-width:1px 0px 1px 0px;border-style:solid;border-color:rgba(198,212,224,0.4)}.item-container .login-method .title,.item-container .login-method .content{line-height:28px}.item-container .device{min-height:28px;height:auto;border-width:0px 0px 1px 0px;border-style:solid;border-color:rgba(198,212,224,0.4)}.item-container .device .title,.item-container .device .content{line-height:20px;padding:4px 0px}.item-container .block div{display:inline-block}.item-container .block .title div,.item-container .block .content div{padding:0px 8px}.item-container .block .title{width:50%}.item-container .block .content{text-overflow:ellipsis;white-space:nowrap;width:49%;vertical-align:top}.syno-securesignin-authenticator-wizard-summary .desc{font-size:13px}.syno-securesignin-authenticator-wizard-summary .status-error{color:#E64040;font-size:13px;padding-top:4px;padding-bottom:4px;line-height:25px;margin-bottom:4px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(42)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-fido-wizard-select-method .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-fido-wizard-select-method{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-fido-wizard-select-method .v-form{padding-top:24px}.syno-securesignin-fido-wizard-select-method .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-fido-wizard-select-method .v-radio-wrapper{margin-bottom:16px}.syno-securesignin-fido-wizard-select-method .title{line-height:20px}.syno-securesignin-fido-wizard-select-method .desc{line-height:20px;padding:4px 0px;margin:10px 0px 0px 0px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(43)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-fido-wizard-register{margin-top:24px}.syno-securesignin-fido-wizard-register .register-loading-box{height:12px;margin:175px 0px 30px 0px;width:100%}.syno-securesignin-fido-wizard-register .register-loading-box .register-loader{width:12px;height:12px;border-radius:50%;position:relative;animation:loading-u5f9c1897 1s ease alternate infinite;animation-delay:.4s;margin-left:auto;margin-right:auto;top:-12px}.syno-securesignin-fido-wizard-register .register-loading-box .register-loader::after,.syno-securesignin-fido-wizard-register .register-loading-box .register-loader::before{content:\'\';position:absolute;width:12px;height:12px;border-radius:50%;animation:loading-u5f9c1897 1s ease alternate infinite}.syno-securesignin-fido-wizard-register .register-loading-box .register-loader::before{left:-22px;animation-delay:.2s}.syno-securesignin-fido-wizard-register .register-loading-box .register-loader::after{right:-22px;animation-delay:.6s}@keyframes loading-u5f9c1897{0%{box-shadow:0 12px 0 -12px #057FEB}100%{box-shadow:0 12px 0 #057FEB}}.syno-securesignin-fido-wizard-register .scanning-key-box{padding:4px 0px;width:100%;height:40px;font-size:13px;color:#414b55;text-align:center;line-height:20px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(44)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-fido-wizard-keyname{margin-top:14px}.syno-securesignin-fido-wizard-keyname .usbkey{font-size:13px;color:#414b55}.syno-securesignin-fido-wizard-keyname .usbkey.desc{line-height:20px;margin-top:14px;padding:4px 0px}.syno-securesignin-fido-wizard-keyname .usbkey.name{line-height:20px;margin-top:6px;padding:4px 0px}.syno-securesignin-fido-wizard-keyname .keynameBox{margin-top:12px}.syno-securesignin-fido-wizard-keyname .keynameBox .v-form-item-label{display:inline-block;width:230px}.syno-securesignin-fido-wizard-keyname .keynameBox .v-form-item-input{display:inline-block;padding-left:8px}.syno-securesignin-fido-wizard-keyname .keynameBox .v-form-item-input .keynameText .v-textfield-input{width:200px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(45)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-fido-wizard-error{margin-top:24px}.syno-securesignin-fido-wizard-error .fido-wizard-error-desc{line-height:20px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(46)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-fido-wizard-summary{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-fido-wizard-summary .v-form{padding-top:24px}.syno-securesignin-fido-wizard-summary .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(47)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(48)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(118)),
        o = i(n(119));
    t.push([e.i, '.syno-securesignin-otp-wizard-welcome .syno-ux-note,.syno-securesignin-otp-wizard-summary .syno-ux-note{color:#00A6A6}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-otp-wizard-welcome{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-otp-wizard-welcome .v-form{padding-top:24px}.syno-securesignin-otp-wizard-welcome .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-otp-wizard-welcome .desc{line-height:20px}.syno-securesignin-otp-wizard-welcome .welcome_img{background-size:440px 160px;background-image:url(' + s + ");height:160px;margin:16px auto;width:440px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-securesignin-otp-wizard-welcome .welcome_img{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/illu_otp.png") image-height("~@/../images/1x/illu_otp.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-securesignin-otp-wizard-welcome .welcome_img{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/illu_otp.png") image-height("~@/../images/1x/illu_otp.png");outline:1px green dashed}}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/ee23852211280c435dbdb75a4884472b.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/d98a4bfac47d394d5eebdebb7e36daa5.png"
}, function(e, t, n) {
    "use strict";
    n(49)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-otp-wizard-backup-email{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-otp-wizard-backup-email .v-form{padding-top:24px}.syno-securesignin-otp-wizard-backup-email .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-otp-wizard-backup-email .v-form{padding:0px}.syno-securesignin-otp-wizard-backup-email .desc{padding:4px 0px;margin-bottom:12px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(50)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-otp-wizard-scan-qr .step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-otp-wizard-scan-qr{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-otp-wizard-scan-qr .v-form{padding-top:24px}.syno-securesignin-otp-wizard-scan-qr .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-otp-wizard-scan-qr .step-block{margin:4px 0px}.syno-securesignin-otp-wizard-scan-qr .step-desc{text-indent:15px}.syno-securesignin-otp-wizard-scan-qr .qrcode-content{margin:16px auto 0px auto;padding:12px;height:120px;width:120px}.syno-securesignin-otp-wizard-scan-qr .qrcode-content .qrcode{display:inline-block;background-size:contain;height:120px;width:120px}.syno-securesignin-otp-wizard-scan-qr .link{color:#057FEB;cursor:pointer;text-align:center;text-decoration:underline;width:200px;margin:0px auto 12px auto}.syno-securesignin-otp-wizard-scan-qr .otp-code{padding-top:12px;margin-left:15px}.syno-securesignin-otp-wizard-scan-qr .otp-code .v-form-item-label,.syno-securesignin-otp-wizard-scan-qr .otp-code .v-form-item-input input{width:200px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(51)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-otp-secret-dialog .desc{line-height:20px}.syno-securesignin-otp-secret-dialog .code{line-height:20px}.syno-securesignin-otp-secret-dialog .v-form{padding:16px 20px 0px 20px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(52)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-otp-wizard-welcome .syno-ux-note,.syno-securesignin-otp-wizard-summary .syno-ux-note{color:#00A6A6}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-otp-wizard-summary{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-otp-wizard-summary .v-form{padding-top:24px}.syno-securesignin-otp-wizard-summary .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(53)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(54)
}, function(e, t, n) {
    t = e.exports = n(4)(!1);
    var i = n(8),
        s = i(n(132)),
        o = i(n(133));
    t.push([e.i, '.auth-login-panel .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .auth-login-panel .title,.auth-login-panel .syno-cjk .title{font-weight:600}.auth-login-panel .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .auth-login-panel .title,.auth-login-panel .syno-cjk .title{font-weight:600}.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.auth-login-panel .title{font-size:18px;color:#414b55;line-height:28px}.auth-login-panel .desc{color:#414b55;line-height:20px;margin:16px 0px 0px 0px}.auth-login-panel .login-msg-box{margin-bottom:8px}.auth-login-panel .invalid .try-again{float:right;margin:30px 0px 0px 0px}.auth-login-panel .icon{height:50px;margin:20px auto 0px;width:50px;background-size:50px 50px;background-image:url(' + s + ");animation-name:shake;animation-delay:0.3s;animation-iteration-count:infinite;animation-duration:5s}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .auth-login-panel .icon{background-image:url(" + o + ');background-size:image-width("~@/../images/1x/icn_app_icon.png") image-height("~@/../images/1x/icn_app_icon.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .auth-login-panel .icon{background-image:url(' + o + ');background-size:image-width("~@/../images/1x/icn_app_icon.png") image-height("~@/../images/1x/icn_app_icon.png");outline:1px green dashed}}@keyframes shake{4%{-webkit-transform:rotate(10deg);transform:rotate(10deg)}8%{-webkit-transform:rotate(-10deg);transform:rotate(-10deg)}12%{-webkit-transform:rotate(3deg);transform:rotate(3deg)}16%{-webkit-transform:rotate(-3deg);transform:rotate(-3deg)}20%{-webkit-transform:rotate(0deg);transform:rotate(0deg)}to{-webkit-transform:rotate(0deg);transform:rotate(0deg)}}.auth-login-panel .verify-number{background:#EFEFEF;border-radius:999em;color:#414b55;font-size:32px;height:60px;letter-spacing:-0.2px;line-height:60px;margin:20px auto 0px;text-align:center;width:60px}.auth-login-panel .trust-device,.auth-login-panel .field{color:#414b55;margin:24px 0px 0px 0px}.auth-login-panel .trust-device .v-checkbox-label,.auth-login-panel .field .v-checkbox-label{opacity:0.8}.auth-login-panel .redirect-content .continue{font-size:15px;border-radius:100px;width:100%;height:40px;line-height:24px;margin-top:60px}\n', ""])
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/5eba74615fb88765d697f7e7be88d768.png"
}, function(e, t) {
    e.exports = "webman/3rdparty/SecureSignIn/assets/76e1189894596e8148251f6eb596d6fb.png"
}, function(e, t, n) {
    "use strict";
    n(55)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.desc[data-v-6771b540]{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.title[data-v-6771b540]{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif}.title[data-v-6771b540]{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .title[data-v-6771b540]{font-weight:600}.syno-securesignin-window .dialog .tbar-wrapper[data-v-6771b540]{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper[data-v-6771b540]{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl[data-v-6771b540]{display:none}.tab-footer.login-footer[data-v-6771b540]{text-align:center}.tab-footer.login-footer .tab-footer-link[data-v-6771b540]{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul[data-v-6771b540]{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li[data-v-6771b540]{list-style:disc;list-style-position:outside}.open-page[data-v-6771b540]{cursor:pointer}div.otp-backup-orange[data-v-6771b540]{margin-top:6px;color:#F58414}.title[data-v-6771b540]{font-size:18px;color:#414b55;line-height:28px;margin-bottom:16px}.desc[data-v-6771b540]{font-size:13px;color:#414b55;line-height:20px;margin-bottom:24px}.failed .desc[data-v-6771b540]{margin-bottom:0px}.failed .invalid .try-again[data-v-6771b540]{float:right;margin:30px 0px 0px 0px}.login-msg-box[data-v-6771b540]{margin-bottom:8px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(56)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.syno-securesignin-enforce-2fa-welcome{font-size:13px;line-height:20px;padding:24px 0px 20px 0px}.syno-securesignin-enforce-2fa-welcome .v-form{padding-top:24px}.syno-securesignin-enforce-2fa-welcome .v-form-item-input input{width:250px}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-enforce-2fa-welcome .desc{line-height:20px;margin:0px 0px 20px 0px}\n', ""])
}, function(e, t, n) {
    "use strict";
    n(57)
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}.syno-securesignin-enforce-2fa-background{background-size:cover;height:100%;overflow:hidden;position:absolute;width:100%}.syno-securesignin-enforce-2fa-background .syno-securesignin-enforce-2fa-wizard{bottom:0;display:flex !important;left:0;margin:auto;position:absolute;right:0;top:0}.syno-securesignin-enforce-2fa-background .syno-securesignin-enforce-2fa-wizard .v-window-header-wrapper{color:#fff;pointer-events:none;opacity:1}.syno-securesignin-enforce-2fa-background .syno-securesignin-enforce-2fa-wizard .v-window-header-wrapper .v-window-header-text{opacity:0.7}\n', ""])
}, function(e, t, n) {
    var i = n(141);
    "string" == typeof i && (i = [
        [e.i, i, ""]
    ]), i.locals && (e.exports = i.locals);
    (0, n(5).default)("60d68496", i, !1, {})
}, function(e, t, n) {
    (e.exports = n(4)(!1)).push([e.i, '.syno-securesignin-window .dialog .tbar-wrapper{padding:0 20px 8px 20px}.syno-securesignin-window .dialog .body-wrapper{padding:0 20px 0 20px}.syno-securesignin-window .x-window-bl{display:none}.tab-footer.login-footer{text-align:center}.tab-footer.login-footer .tab-footer-link{color:#057FEB}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul{margin:6px 0px;padding-left:18px}div[syno-id^="secure-signin-"] .body-wrapper .dialog-content ul li{list-style:disc;list-style-position:outside}.open-page{cursor:pointer}div.otp-backup-orange{margin-top:6px;color:#F58414}\n', ""])
}, function(e, t, n) {
    "use strict";
    n.r(t);
    var i = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("div", {
            staticClass: "syno-securesignin-advance-signin-method"
        }, [n("div", {
            staticClass: "signin-desc"
        }, [e._v(" " + e._s(e.getSigninDesc) + " ")]), e._v(" "), n("div", {
            staticClass: "card-wrapper"
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.hidePasswordless,
                expression: "!hidePasswordless"
            }],
            staticClass: "method-card-wrapper",
            on: {
                click: e.onSetupPasswordless
            }
        }, [n("div", {
            staticClass: "method-card",
            class: {
                enabled: e.isPasswordless
            }
        }, [n("div", {
            staticClass: "card-icon"
        }), e._v(" "), n("div", {
            staticClass: "card-info"
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.TT("common", "passwordless_signin")) + " ")]), e._v(" "), n("div", {
            staticClass: "content"
        }, [e._v(" " + e._s(e.TT("personal_setting", "passwordless_signin_desc")) + "  ")]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isPasswordless,
                expression: "isPasswordless"
            }],
            staticClass: "signin_method first-step"
        }, [e._v("\n\t\t\t\t\t\t" + e._s(e.TT("authenticator", "sign_in_method")) + ": "), n("span", {
            staticClass: "bold"
        }, [e._v(e._s(e.authTypeList))])])]), e._v(" "), n("div", {
            staticClass: "arrow"
        })])]), e._v(" "), n("div", {
            staticClass: "method-card-wrapper",
            on: {
                click: e.onSetupTwoFactor
            }
        }, [n("div", {
            staticClass: "method-card",
            class: {
                enabled: e.isTwoFactor
            }
        }, [n("div", {
            staticClass: "card-icon"
        }), e._v(" "), n("div", {
            staticClass: "card-info"
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.T("personal_settings", "otp_settings")) + " ")]), e._v(" "), n("div", {
            staticClass: "content"
        }, [e._v(e._s(e.TT("personal_setting", "2fa_desc")))]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isTwoFactor,
                expression: "isTwoFactor"
            }],
            staticClass: "signin_method first-step"
        }, [e._v("\n\t\t\t\t\t\t" + e._s(e.TT("personal_setting", "first_signin_step")) + ": "), n("span", {
            staticClass: "bold"
        }, [e._v(e._s(e.TT("personal_setting", "first_signin_step_desc")))])]), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isTwoFactor,
                expression: "isTwoFactor"
            }],
            staticClass: "signin_method second-step"
        }, [e._v("\n\t\t\t\t\t\t" + e._s(e.TT("personal_setting", "second_signin_step")) + ": "), n("span", {
            staticClass: "bold"
        }, [e._v(e._s(e.authTypeList))])])]), e._v(" "), n("div", {
            staticClass: "arrow"
        })])])])])
    };
    i._withStripped = !0;
    var s = n(0),
        o = n(3);

    function r(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function a(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function a(e) {
                    r(o, i, s, a, c, "next", e)
                }

                function c(e) {
                    r(o, i, s, a, c, "throw", e)
                }
                a(void 0)
            }))
        }
    }
    var c, d, p, u, l, g, h = {
            mixins: [s.a, o.a],
            props: {
                appWindow: Object
            },
            data: function() {
                return {
                    authType: [],
                    signinMethod: {},
                    otpEnabled: !1,
                    firstMounted: !0,
                    secureSigninEnabled: !1,
                    synologyAccountStatus: !1
                }
            },
            computed: {
                authTypeList: function() {
                    var e = this,
                        t = this.authType.map((function(t) {
                            return "authenticator" === t ? e.TT("authenticator", "approve_sign_in") : "fido" === t ? e.TT("fido", "hardware_security_key") : void 0
                        }));
                    return this.otpEnabled && t.push(this.T("personal_settings", "otp_verification_code")), t.join(", ")
                },
                hasAdvanceSigninProfile: function() {
                    return this.isApprovedSigninSetup || this.isSecurityKeySetup
                },
                isServiceAvailable: function() {
                    return this.synologyAccountStatus && this.secureSigninEnabled
                },
                isApprovedSigninSetup: function() {
                    return this.authType.includes("authenticator")
                },
                isPasswordless: function() {
                    return "passwordless" === this.signinMethod.mode && "on" === this.signinMethod.status
                },
                isSecurityKeySetup: function() {
                    return this.authType.includes("fido")
                },
                isTwoFactor: function() {
                    return "two-factor" === this.signinMethod.mode && "on" === this.signinMethod.status
                },
                hidePasswordless: function() {
                    return !this.hasAdvanceSigninProfile && !this.isServiceAvailable
                },
                getSigninDesc: function() {
                    return this.hidePasswordless ? this.TT("personal_setting", "no_sa_signin_method_desc") : this.TT("personal_setting", "signin_method_desc")
                }
            },
            methods: {
                onSetupPasswordless: (g = a(regeneratorRuntime.mark((function e() {
                    var t, n, i = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.isEnforced2faUser();
                            case 2:
                                if (!e.sent) {
                                    e.next = 6;
                                    break
                                }
                                this.appWindow.getMsgBox().alert(null, this.TT("management", "enforce_2fa_by_admin"), {
                                    cancel: {
                                        text: null
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                }), e.next = 33;
                                break;
                            case 6:
                                if (!this.isPasswordless) {
                                    e.next = 14;
                                    break
                                }
                                return e.next = 9, this.verifyDialog();
                            case 9:
                                "confirm" === e.sent.result && this.openWindow(SYNO.SDS.SecureSignIn.Passwordless.Settings), e.next = 33;
                                break;
                            case 14:
                                if (!this.hasAdvanceSigninProfile) {
                                    e.next = 24;
                                    break
                                }
                                return t = "on" === this.signinMethod.status ? this.TT("inherit", "inherit_to_passwordless_title") : this.T("personal_settings", "identity_verification_title"), n = "on" === this.signinMethod.status ? this.TT("inherit", "inherit_to_passwordless_desc") : this.T("personal_settings", "identity_verification_content"), e.next = 19, this.verifyDialog(t, n);
                            case 19:
                                "confirm" === e.sent.result && this.openWindow(SYNO.SDS.SecureSignIn.Register.InheritDialog, {
                                    signinMethod: "passwordless",
                                    onNotInherit: function() {
                                        i.openWindow(SYNO.SDS.SecureSignIn.Register.PasswordlessWizard, {
                                            otpEnabled: i.otpEnabled
                                        })
                                    }
                                }), e.next = 33;
                                break;
                            case 24:
                                if (!this.otpEnabled) {
                                    e.next = 32;
                                    break
                                }
                                return e.next = 27, this.verifyDialog(this.TT("inherit", "inherit_to_passwordless_title"), this.TT("inherit", "inherit_to_passwordless_desc"));
                            case 27:
                                "confirm" === e.sent.result && this.openWindow(SYNO.SDS.SecureSignIn.Register.PasswordlessWizard, {
                                    advanceSigninMethodModule: this,
                                    otpEnabled: this.otpEnabled
                                }), e.next = 33;
                                break;
                            case 32:
                                this.openWindow(SYNO.SDS.SecureSignIn.Register.PasswordlessWizard, {
                                    advanceSigninMethodModule: this,
                                    otpEnabled: this.otpEnabled
                                });
                            case 33:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return g.apply(this, arguments)
                }),
                onSetupTwoFactor: (l = a(regeneratorRuntime.mark((function e() {
                    var t, n, i, s, o, r, c, d, p = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.isTwoFactor) {
                                    e.next = 9;
                                    break
                                }
                                return e.next = 3, this.verifyDialog();
                            case 3:
                                t = e.sent, n = t.result, i = t.component, "confirm" === n && this.openWindow(SYNO.SDS.SecureSignIn.TwoFactor.Settings, {
                                    otpEnabled: this.otpEnabled,
                                    hideAdvanceSigninMethod: this.hidePasswordless,
                                    password: i.password
                                }), e.next = 21;
                                break;
                            case 9:
                                if (!this.hasAdvanceSigninProfile) {
                                    e.next = 20;
                                    break
                                }
                                return s = "on" === this.signinMethod.status ? this.TT("inherit", "inherit_to_2fa_title") : this.T("personal_settings", "identity_verification_title"), o = "on" === this.signinMethod.status ? this.TT("inherit", "inherit_to_2fa_desc") : this.T("personal_settings", "identity_verification_content"), e.next = 14, this.verifyDialog(s, o);
                            case 14:
                                r = e.sent, c = r.result, d = r.component, "confirm" === c && this.openWindow(SYNO.SDS.SecureSignIn.Register.InheritDialog, {
                                    signinMethod: "two-factor",
                                    onNotInherit: function() {
                                        p.openWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                            otpEnabled: p.otpEnabled,
                                            password: d.password
                                        })
                                    },
                                    onInherit: function() {
                                        var e, t, n = p.appWindow.getMsgBox({
                                            doCancel: (t = a(regeneratorRuntime.mark((function e() {
                                                return regeneratorRuntime.wrap((function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            return e.next = 2, p.updateSigninStatus();
                                                        case 2:
                                                            n.onClose();
                                                        case 3:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }), e, this)
                                            }))), function() {
                                                return t.apply(this, arguments)
                                            }),
                                            doConfirm: (e = a(regeneratorRuntime.mark((function e() {
                                                return regeneratorRuntime.wrap((function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            return e.next = 2, p.doOtp(n, d.password);
                                                        case 2:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }), e, this)
                                            }))), function() {
                                                return e.apply(this, arguments)
                                            })
                                        });
                                        n.confirm(p.TT("wizard", "set_backup_2fa_desc"), String.format(p.TT("wizard", "set_backup_2fa_content"), '<div class="otp-backup-orange">', "</div>"), {
                                            cancel: {
                                                text: p.T("common", "no_thanks")
                                            },
                                            confirm: {
                                                text: p.T("personal_settings", "setup")
                                            }
                                        }, {
                                            useHtml: !0
                                        })
                                    }
                                }, !1), e.next = 21;
                                break;
                            case 20:
                                this.openWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                    otpEnabled: this.otpEnabled,
                                    advanceSigninMethodModule: this
                                });
                            case 21:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return l.apply(this, arguments)
                }),
                doOtp: (u = a(regeneratorRuntime.mark((function e(t, n) {
                    var i, s = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.otpEnabled) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return _S("isLogined") || (this.openWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                    otpEnabled: this.otpEnabled,
                                    password: n,
                                    isOtp: !0
                                }), t.onClose()), e.next = 5, this.getEmailStatus();
                            case 5:
                                e.sent ? (this.openWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                    otpEnabled: this.otpEnabled,
                                    password: n,
                                    isOtp: !0
                                }), t.onClose()) : (i = t.getMsgBox(), t.setStatus("loading"), i.confirm(null, this.T("notification", "mail_service_not_enable"), {
                                    cancel: {
                                        text: this.T("common", "cancel")
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                }).then((function(e) {
                                    if ("confirm" === e) {
                                        var o = i.openWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailWizard, {
                                            firstCreate: !0
                                        }).window;
                                        o && o.$on("close", a(regeneratorRuntime.mark((function e() {
                                            return regeneratorRuntime.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.next = 2, s.getEmailStatus();
                                                    case 2:
                                                        e.sent ? (s.openWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                                            otpEnabled: s.otpEnabled,
                                                            password: n,
                                                            isOtp: !0
                                                        }), t.onClose()) : (t.showStatusBar = !1, t.setStatus("clear"));
                                                    case 4:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e, this)
                                        }))))
                                    } else t.showStatusBar = !1, t.setStatus("clear")
                                })));
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t) {
                    return u.apply(this, arguments)
                }),
                openWindow: function(e) {
                    var t = this,
                        n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                        i = !(arguments.length > 2 && void 0 !== arguments[2]) || arguments[2],
                        s = this.appWindow.openModalWindow(e, n),
                        o = s.window;
                    i && o && o.$on("close", a(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, t.updateSigninStatus();
                                case 2:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    }))))
                },
                updateSigninStatus: (p = a(regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.$root.$emit("loading", !0), Promise.all([this.getSigninMethod(), this.getOtpStatus()]).then((function(e) {
                                    void 0 !== e[0] && (t.signinMethod = e[0], t.authType = e[0].auth_type), void 0 !== e[1] && (t.otpEnabled = e[1]), t.$root.$emit("loading", !1)
                                }));
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return p.apply(this, arguments)
                }),
                verifyDialog: (d = a(regeneratorRuntime.mark((function e(t, n) {
                    var i, s, o, r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return i = this.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.IdentityVerificationDialog), s = i.window, o = i.component, e.next = 3, s.confirm(t || this.T("personal_settings", "identity_verification_title"), n || this.T("personal_settings", "identity_verification_content"));
                            case 3:
                                return r = e.sent, e.abrupt("return", {
                                    result: r,
                                    component: o
                                });
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t) {
                    return d.apply(this, arguments)
                })
            },
            beforeMount: (c = a(regeneratorRuntime.mark((function e() {
                var t = this;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return this.getPackageStatus().then((function(e) {
                                t.synologyAccountStatus = e.account_status, t.secureSigninEnabled = e.enabled
                            })), this.getSigninMethod().then((function(e) {
                                t.signinMethod = e, t.authType = e.auth_type
                            })), e.next = 4, this.getOtpStatus();
                        case 4:
                            this.otpEnabled = e.sent;
                        case 5:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return c.apply(this, arguments)
            }),
            watch: {
                signinMethod: function(e, t) {
                    this.firstMounted ? this.firstMounted = !1 : e.status === t.status && e.mode === t.mode || ("on" === e.status ? this.$getToastBox(this.$el, {
                        text: "passwordless" === e.mode ? this.TT("common", "passwordless_on") : this.TT("common", "2fa_on"),
                        animateIn: !0,
                        align: "t->t"
                    }, {
                        constrainMode: !0,
                        absoluteMode: !1
                    }) : this.$getToastBox(this.$el, {
                        text: "passwordless" === e.mode ? this.TT("common", "passwordless_off") : this.TT("common", "2fa_off"),
                        animateIn: !0,
                        align: "t->t"
                    }, {
                        constrainMode: !0,
                        absoluteMode: !1
                    }))
                }
            }
        },
        f = (n(60), n(1)),
        m = Object(f.a)(h, i, [], !1, null, null, null);
    m.options.__file = "src/advance-signin-method.vue";
    var w = m.exports,
        v = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-modal-window", {
                ref: "window",
                class: "syno-securesignin-passwordless-settings",
                attrs: {
                    "syno-id": "secure-signin-passwordless-settings",
                    width: "800",
                    height: "540",
                    title: e.TT("common", "passwordless_signin")
                }
            }, [n("v-panel", {
                attrs: {
                    "fluid-footer": ""
                },
                scopedSlots: e._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "content-wrapper"
                        }, [n("v-fieldset", {
                            attrs: {
                                title: e.T("common", "status"),
                                collapsible: !1
                            }
                        }, [n("v-form", {
                            attrs: {
                                "syno-id": "pages-auth-page-form-0",
                                rules: "rules"
                            }
                        }, [n("div", {
                            staticClass: "desc"
                        }, [e._v(" " + e._s(e.TT("management", "passwordless_settings_general_desc")) + " ")]), e._v(" "), n("v-form-item", {
                            staticClass: "activated-time",
                            attrs: {
                                label: e.TT("management", "passwordless_settings_activated_time"),
                                textonly: ""
                            }
                        }, [n("span", {
                            staticClass: "time"
                        }, [e._v(" " + e._s(e.time) + " ")]), e._v(" "), n("v-button", {
                            staticClass: "btn",
                            on: {
                                click: e.onTurnoff
                            }
                        }, [e._v(" " + e._s(e.TT("common", "turn_off")) + " ")])], 1)], 1)], 1), e._v(" "), n("v-fieldset", {
                            staticClass: "setting-field",
                            attrs: {
                                title: e.TT("management", "passwordless_desc"),
                                collapsible: !1
                            }
                        }, [n("v-tabs", {
                            staticClass: "syno-sds-personal-tabs",
                            attrs: {
                                "syno-id": "src-app-tabs-0",
                                "active-tab-key": e.tabKey,
                                "has-fbar": !1
                            }
                        }, [n("v-tab-pane", {
                            attrs: {
                                "syno-id": "signin-tab-pane-0",
                                "tab-key": "approveSignIn",
                                tab: e.TT("authenticator", "approve_sign_in")
                            }
                        }, [n("authenticator-setting", {
                            attrs: {
                                windowRef: e.windowRef,
                                signinMethod: "passwordless"
                            },
                            on: {
                                dataloaded: e.onDataLoaded
                            }
                        })], 1), e._v(" "), n("v-tab-pane", {
                            attrs: {
                                "syno-id": "signin-tab-pane-1",
                                "tab-key": "fido",
                                tab: e.TT("fido", "hardware_security_key")
                            }
                        }, [n("fido-setting", {
                            attrs: {
                                windowRef: e.windowRef,
                                signinMethod: "passwordless"
                            },
                            on: {
                                dataloaded: e.onDataLoaded
                            }
                        })], 1)], 1)], 1)], 1)]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                type: "footbar"
                            },
                            on: {
                                click: e.onCancel
                            }
                        }, [e._v(" " + e._s(e.T("common", "close")) + " ")])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };
    v._withStripped = !0;
    var y = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("div", {
            staticClass: "setting dialog authenticator-setting"
        }, [n("v-panel", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.isEmpty,
                expression: "isEmpty"
            }],
            staticClass: "empty-style",
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-empty",
                "has-tbar": !1,
                "has-fbar": !1,
                loading: e.loading
            }
        }, [n("template", {
            slot: "body"
        }, [n("div", {
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.empty_text)
            }
        }), e._v(" "), n("v-button", {
            staticClass: "btn",
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-empty-add-btn",
                suffix: "blue"
            },
            on: {
                click: e.onClickAdd
            }
        }, [e._v(e._s(e.T("common", "add")))])], 1)], 2), e._v(" "), n("v-panel", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isEmpty,
                expression: "!isEmpty"
            }],
            staticClass: "authenticator-setting-dialog normal-style",
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-content",
                "has-tbar": !0,
                "has-fbar": !1
            }
        }, [n("template", {
            slot: "tbar"
        }, [n("v-button", {
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-add-btn"
            },
            on: {
                click: e.onClickAdd
            }
        }, [e._v(e._s(e.T("common", "add")))]), e._v(" "), n("v-button", {
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-del-btn",
                disabled: !e.isSelected()
            },
            on: {
                click: e.onClickRemove
            }
        }, [e._v(e._s(e.T("common", "remove")))])], 1), e._v(" "), n("template", {
            slot: "body"
        }, [n("v-data-table", {
            ref: "regDevices",
            staticClass: "data-table",
            attrs: {
                "syno-id": "secure-signin-authenticator-setting-content-table",
                loadingText: e.loadingText,
                data: e.loadAuthenticatorInfo,
                responseParamsName: e.regInfo.paramsName,
                columns: e.regInfo.columns,
                showPagingBar: !1,
                minColumns: 1
            },
            on: {
                rowclick: e.onAuthenticatorClick,
                dataloaded: e.onDataLoaded
            }
        })], 1)], 2), e._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.serviceAvailable,
                expression: "!serviceAvailable"
            }],
            staticClass: "mask-wrapper"
        }, [n("div", {
            staticClass: "mask-cover"
        }), e._v(" "), n("div", {
            staticClass: "mask-desc-ct"
        }, [n("div", {
            staticClass: "mask-desc",
            domProps: {
                innerHTML: e._s(e.mask_text)
            },
            on: {
                click: e.openSecurityPage
            }
        })])])], 1)
    };
    y._withStripped = !0;
    var x = n(22),
        b = n(2),
        _ = n.n(b);

    function S(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }

    function k(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function T(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    k(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    k(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var E, O, N, C = {
            mixins: [s.a, o.a, x.a],
            data: function() {
                return {
                    total: 0,
                    loading: !1,
                    loadingText: this.T("common", "loading"),
                    empty_text: this.TT("authenticator", "management_empty_text"),
                    mask_text: _S("is_admin") ? String.format(this.TT("management", "unavailable_sa_desc_admin"), '<a class="open-page">', "</a>") : this.TT("management", "unavailable_sa_desc_user"),
                    regInfo: {
                        columns: [{
                            title: this.T("common", "name"),
                            field: "name",
                            hideMenuItem: !0,
                            width: 120,
                            tooltip: !0
                        }, {
                            title: this.TT("authenticator", "model"),
                            field: "model",
                            hide: !0,
                            width: 110,
                            tooltip: !0
                        }, {
                            title: this.TT("authenticator", "os_version"),
                            field: "os_version",
                            hide: !0,
                            width: 110,
                            tooltip: !0
                        }, {
                            title: this.TT("authenticator", "app_version"),
                            field: "app_version",
                            hide: !0,
                            width: 110,
                            tooltip: !0
                        }, {
                            title: this.TT("common", "add_time"),
                            fn: function(e) {
                                return SYNO.SDS.DateTimeFormatter(new Date(1e3 * e.add_time), {
                                    type: "datetime"
                                })
                            },
                            width: 140,
                            tooltip: !0
                        }, {
                            title: this.TT("common", "last_used_time"),
                            fn: function(e) {
                                return SYNO.SDS.DateTimeFormatter(new Date(1e3 * e.last_used_time), {
                                    type: "datetime"
                                })
                            },
                            width: 157,
                            tooltip: !0
                        }],
                        paramsName: {
                            results: "authenticators"
                        }
                    },
                    serviceAvailable: !1
                }
            },
            computed: {
                isEmpty: function() {
                    return 0 === this.total
                }
            },
            props: {
                windowRef: {},
                signinMethod: String,
                otpEnabled: {
                    type: Boolean,
                    default: !1
                }
            },
            mounted: (N = T(regeneratorRuntime.mark((function e() {
                var t = this;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            try {
                                this.getPackageStatus().then((function(e) {
                                    t.serviceAvailable = e.account_status && e.enabled
                                }))
                            } catch (e) {
                                console.log(e)
                            }
                            case 1:
                            case "end":
                                return e.stop()
                    }
                }), e, this)
            }))), function() {
                return N.apply(this, arguments)
            }),
            methods: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        S(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(b.mapActions)("AuthenticatorSettingModule", ["selectedAuthenticator", "releasedAuthenticator"]), Object(b.mapGetters)("AuthenticatorSettingModule", ["isSelected"]), {
                loadAuthenticatorInfo: function() {
                    var e = this;
                    return this.loading = !0, synowebapi.promises.request({
                        api: "SYNO.SecureSignIn.Authenticator",
                        method: "list",
                        version: "1"
                    }).then((function(t) {
                        return e.loading = !1, t
                    }))
                },
                onAuthenticatorClick: function(e) {
                    var t = e.row;
                    this.selectedAuthenticator(t)
                },
                onDataLoaded: function(e) {
                    this.releasedAuthenticator(), this.total = e.length, this.$emit("dataloaded", "approved-signin", this.total)
                },
                onClickAdd: (O = T(regeneratorRuntime.mark((function e() {
                    var t, n = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.isAuthencatorRegisterable();
                            case 2:
                                if (e.sent) {
                                    e.next = 5;
                                    break
                                }
                                return this.openUnregisteredMsgBox(this.windowRef), e.abrupt("return");
                            case 5:
                                return t = "two-factor" === this.signinMethod ? SYNO.SDS.SecureSignIn.Register.TwoFactorWizard : SYNO.SDS.SecureSignIn.Register.PasswordlessWizard, e.next = 8, this.windowRef.openModalWindow(t, {
                                    isAuthenticator: !0,
                                    otpEnabled: this.otpEnabled
                                });
                            case 8:
                                e.sent.window.$on("close", (function() {
                                    n.$refs.regDevices.loadData()
                                }));
                            case 11:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return O.apply(this, arguments)
                }),
                onClickRemove: (E = T(regeneratorRuntime.mark((function e(t) {
                    var n, i, s, o, r, a;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return n = this.isSelected(), e.next = 3, this.isEnforced2faUser();
                            case 3:
                                return i = e.sent, s = "authenticator", e.next = 7, this.isTheLast(s, this.total);
                            case 7:
                                return o = e.sent, e.next = 10, this.get_remove_message(s, this.total, this.otpEnabled, n.name, this.signinMethod, i);
                            case 10:
                                if (r = e.sent, !i || !o || this.otpEnabled) {
                                    e.next = 18;
                                    break
                                }
                                return e.next = 14, this.windowRef.getMsgBox().alert("", r, {
                                    cancel: {
                                        text: null
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                });
                            case 14:
                                return a = e.sent, e.abrupt("return");
                            case 18:
                                return e.next = 20, this.windowRef.getMsgBox().confirmDelete("", r, {
                                    confirm: {
                                        text: this.T("common", "remove")
                                    }
                                }, {
                                    useHtml: !0
                                });
                            case 20:
                                a = e.sent;
                            case 21:
                                if ("confirm" === a) {
                                    e.next = 23;
                                    break
                                }
                                return e.abrupt("return");
                            case 23:
                                return this.loading = !0, e.prev = 24, e.next = 27, synowebapi.promises.request({
                                    api: "SYNO.SecureSignIn.Authenticator",
                                    method: "revoke",
                                    params: {
                                        authenticator_id: n.authenticator_id,
                                        type: "all"
                                    },
                                    version: 1
                                });
                            case 27:
                                e.next = 32;
                                break;
                            case 29:
                                e.prev = 29, e.t0 = e.catch(24), this.loadingText = SYNO.API.Errors.core[e.t0.code] || this.T("common", "commfail");
                            case 32:
                                return e.prev = 32, this.loading = !1, this.$refs.regDevices.loadData(), e.finish(32);
                            case 36:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [24, 29, 32, 36]
                    ])
                }))), function(e) {
                    return E.apply(this, arguments)
                }),
                openSecurityPage: function(e) {
                    e.target.matches(".open-page") && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                        fn: "SYNO.SDS.AdminCenter.Security.Main",
                        tab: "SigninTab"
                    })
                }
            })
        },
        B = (n(66), Object(f.a)(C, y, [], !1, null, null, null));
    B.options.__file = "src/management/authenticator-setting.vue";
    var P = B.exports,
        A = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("div", {
                staticClass: "setting dialog"
            }, [n("v-panel", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.isEmpty,
                    expression: "isEmpty"
                }],
                staticClass: "empty-style",
                attrs: {
                    "syno-id": "secure-signin-fido-setting-empty",
                    loading: e.loading,
                    "has-fbar": !1
                }
            }, [n("template", {
                slot: "body"
            }, [n("div", {
                staticClass: "desc",
                domProps: {
                    innerHTML: e._s(e.empty_text)
                }
            }), e._v(" "), n("v-button", {
                staticClass: "btn",
                attrs: {
                    "syno-id": "secure-signin-fido-key-setting-dialog-empty-add-btn",
                    suffix: "blue"
                },
                on: {
                    click: e.onClickAdd
                }
            }, [e._v(e._s(e.T("common", "add")))])], 1)], 2), e._v(" "), n("v-panel", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.isEmpty,
                    expression: "!isEmpty"
                }],
                staticClass: "fido-setting-dialog normal-style",
                attrs: {
                    "syno-id": "secure-signin-fido-key-setting-content",
                    "has-tbar": !0,
                    "has-fbar": !1
                }
            }, [n("template", {
                slot: "tbar"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "secure-signin-fido-key-setting-dialog-add-btn"
                },
                on: {
                    click: e.onClickAdd
                }
            }, [e._v(e._s(e.T("common", "add")))]), e._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "secure-signin-fido-key-setting-dialog-edit-btn",
                    disabled: !e.isSelected()
                },
                on: {
                    click: e.onClickEdit
                }
            }, [e._v(e._s(e.T("common", "alt_edit")))]), e._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "secure-signin-fido-key-setting-dialog-del-btn",
                    disabled: !e.isSelected()
                },
                on: {
                    click: e.onClickRemove
                }
            }, [e._v(e._s(e.T("common", "remove")))])], 1), e._v(" "), n("template", {
                slot: "body"
            }, [n("v-data-table", {
                ref: "regDevices",
                staticClass: "data-table cell-vertical-top",
                attrs: {
                    loadingText: e.loadingText,
                    data: e.loadFidoInfo,
                    responseParamsName: e.regInfo.paramsName,
                    columns: e.regInfo.columns,
                    minColumns: 1,
                    showPagingBar: !1,
                    "syno-id": "secure-signin-fido-key-setting-dialog-content"
                },
                on: {
                    rowclick: e.onFidoClick,
                    dataloaded: e.onDataLoaded
                },
                scopedSlots: e._u([{
                    key: "last_used_time",
                    fn: function(t) {
                        return [n("div", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: e.getTooltip(t),
                                expression: "getTooltip(scope)"
                            }]
                        }, [e._v(e._s(e.formatUnixTimestamp(t.data)))]), e._v(" "), n("div", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: e.getTooltip(t),
                                expression: "getTooltip(scope)"
                            }]
                        }, [e._v(e._s(e.formatLastUsedPlatform(t.row)))])]
                    }
                }])
            })], 1)], 2)], 1)
        };
    A._withStripped = !0;
    var M = n(6),
        z = n(7),
        R = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-modal-window", {
                ref: "window",
                staticClass: "syno-securesignin-window",
                attrs: {
                    "syno-id": "secure-signin-fido-management",
                    width: "480",
                    height: "auto",
                    showClose: !1,
                    title: e.T("common", "alt_edit")
                }
            }, [n("div", {
                staticClass: "setting dialog"
            }, [n("v-panel", {
                ref: "panel",
                attrs: {
                    "syno-id": "secure-signin-fido-management-panel",
                    loadingType: "statusbar",
                    confirmText: e.T("common", "apply"),
                    confirm: e.onConfirm,
                    cancel: e.onClose,
                    loading: e.loading,
                    "show-status-bar": e.showStatusBar,
                    "status-bar-state": e.statusBarState,
                    "fluid-footer": ""
                },
                on: {
                    "update:showStatusBar": function(t) {
                        e.showStatusBar = t
                    },
                    "update:show-status-bar": function(t) {
                        e.showStatusBar = t
                    }
                },
                scopedSlots: e._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-form", {
                            staticClass: "padding-bottom-2",
                            attrs: {
                                "syno-id": "secure-signin-fido-key-edit-form",
                                rules: e.rules
                            }
                        }, [n("v-form-item", {
                            staticClass: "form-item",
                            attrs: {
                                "syno-id": "secure-signin-fido-key-edit-form-item",
                                prop: "devicename",
                                label: e.T("router_tc", "dev_hostname") + ":"
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "secure-signin-fido-key-edit-form-text",
                                name: "devicename",
                                mask: e.devicenameMask,
                                maxlength: 50
                            },
                            model: {
                                value: e.devicename,
                                callback: function(t) {
                                    e.devicename = t
                                },
                                expression: "devicename"
                            }
                        })], 1)], 1)]
                    },
                    proxy: !0
                }])
            })], 1)])
        };
    R._withStripped = !0;
    var D = {
            mixins: [s.a, M.a],
            data: function() {
                var e = this;
                return {
                    rules: {
                        devicename: [{
                            validator: function(t, n, i) {
                                e.isDeviceNameValid(e.devicename) || i(new Error(e.T("user", "error_invalid_device_name"))), i()
                            }
                        }]
                    },
                    devicenameMask: this.getDeviceNameMask(),
                    loading: !1,
                    showStatusBar: !1,
                    statusBarState: "loading"
                }
            },
            props: {
                uid: String,
                devicename: String
            },
            methods: {
                onClose: function() {
                    this.$refs.window.close(), this.$destroy()
                },
                onConfirm: function() {
                    var e = this;
                    this.isDeviceNameValid(this.devicename) ? (this.setStatus("loading"), synowebapi.promises.request({
                        api: "SYNO.SecureSignIn.Fido.Manage",
                        method: "update",
                        params: {
                            keyname: this.devicename,
                            uid: this.uid
                        },
                        version: 1
                    }).then((function(t) {
                        e.setStatus("clear"), e.$root.$emit("confirm"), e.$refs.window.onClose()
                    })).catch((function(t) {
                        SYNO.Debug.error(t), e.setStatus("error", SYNO.API.Errors.core[t.code] || e.getCustomStringInfo(t.code))
                    }))) : this.setStatus("error", this.TT("error", "invalid_device_name"))
                },
                setStatus: function(e, t) {
                    "error" === e && (this.$refs.panel.errorText = t), this.statusBarState = e, this.loading = "loading" === e, this.showStatusBar = "clear" !== e
                }
            }
        },
        I = (n(68), Object(f.a)(D, R, [], !1, null, null, null));
    I.options.__file = "src/management/fido-edit.vue";
    var F = I.exports;

    function L(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function j(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    L(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    L(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function $(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var q = {
            mixins: [s.a, o.a, M.a],
            data: function() {
                var e = this;
                return {
                    total: 0,
                    loading: !1,
                    loadingText: this.T("common", "loading"),
                    empty_text: this.TT("fido", "management_empty_text"),
                    regInfo: {
                        columns: [{
                            title: this.T("common", "name"),
                            field: "keyname",
                            hideMenuItem: !0,
                            width: 120,
                            tooltip: !0
                        }, {
                            title: this.T("personal_settings", "sign_in_method"),
                            fn: function(t) {
                                return "windows" == t.keytype ? e.TT("fido", "method_windows_hello") : "touchID" == t.keytype ? e.TT("fido", "method_touch_id") : e.TT("fido", "method_usb_key")
                            },
                            width: 130,
                            tooltip: !0
                        }, {
                            title: this.T("app_port_alias", "desc_domain"),
                            field: "domain",
                            width: 180,
                            tooltip: !0
                        }, {
                            title: this.TT("common", "add_time"),
                            fn: function(t) {
                                return e.formatUnixTimestamp(t.ctime)
                            },
                            width: 130,
                            tooltip: !0
                        }, {
                            title: this.TT("common", "last_used_time"),
                            field: "last_used_time",
                            width: 170
                        }],
                        paramsName: {
                            results: "fidos"
                        }
                    }
                }
            },
            computed: {
                isEmpty: function() {
                    return 0 === this.total
                }
            },
            props: {
                windowRef: {},
                signinMethod: String,
                otpEnabled: {
                    type: Boolean,
                    default: !1
                }
            },
            methods: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        $(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(b.mapActions)("FidoSettingModule", ["selectedFido", "releasedFido"]), Object(b.mapGetters)("FidoSettingModule", ["isSelected"]), {
                getTooltip: function(e) {
                    return {
                        content: this.formatUnixTimestamp(e.data) + " " + this.formatLastUsedPlatform(e.row)
                    }
                },
                loadFidoInfo: function() {
                    var e = this;
                    return this.loading = !0, synowebapi.promises.request({
                        api: "SYNO.SecureSignIn.Fido.Manage",
                        method: "list",
                        version: "1"
                    }).then((function(t) {
                        return e.loading = !1, t
                    }))
                },
                formatUnixTimestamp: function(e) {
                    return SYNO.SDS.DateTimeFormatter(new Date(1e3 * e), {
                        type: "datetime"
                    })
                },
                formatLastUsedPlatform: function(e) {
                    return e.os || e.browser ? e.os && e.browser ? String.format("{0} on {1}", e.browser, e.os) : e.os || e.browser : "Unknown platform"
                },
                onFidoClick: function(e) {
                    var t = e.row;
                    this.selectedFido(t)
                },
                onDataLoaded: function(e) {
                    this.releasedFido(), this.total = e.length, this.$emit("dataloaded", "fido", this.total)
                },
                onClickAdd: function() {
                    var e = j(regeneratorRuntime.mark((function e() {
                        var t, n, i = this;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if ("https:" === window.location.protocol && !Object(z.d)(window.location.hostname) && !Object(z.c)(window.location.hostname)) {
                                        e.next = 4;
                                        break
                                    }
                                    return e.next = 3, this.openDdnsUnsupportedMsgBox(this.windowRef, this.isDDNSSet);
                                case 3:
                                    return e.abrupt("return");
                                case 4:
                                    return t = "two-factor" === this.signinMethod ? SYNO.SDS.SecureSignIn.Register.TwoFactorWizard : SYNO.SDS.SecureSignIn.Register.PasswordlessWizard, e.next = 7, this.windowRef.openModalWindow(t, {
                                        isFido: !0,
                                        otpEnabled: this.otpEnabled
                                    });
                                case 7:
                                    n = e.sent, n.window.$on("close", (function() {
                                        i.$refs.regDevices.loadData()
                                    }));
                                case 10:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                onClickRemove: function() {
                    var e = j(regeneratorRuntime.mark((function e(t) {
                        var n, i, s, o, r, a, c;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = this.isSelected(), e.next = 3, this.isEnforced2faUser();
                                case 3:
                                    return i = e.sent, s = "fido", e.next = 7, this.isTheLast(s, this.total);
                                case 7:
                                    return o = e.sent, e.next = 10, this.get_remove_message(s, this.total, this.otpEnabled, n.keyname, this.signinMethod, i);
                                case 10:
                                    if (r = e.sent, c = {
                                            customCls: "syno-fido-app-msg-box"
                                        }, !i || !o || this.otpEnabled) {
                                        e.next = 19;
                                        break
                                    }
                                    return e.next = 15, this.windowRef.getMsgBox(c).alert("", r, {
                                        cancel: {
                                            text: null
                                        },
                                        confirm: {
                                            text: this.T("common", "ok")
                                        }
                                    }, {
                                        useHtml: !0
                                    });
                                case 15:
                                    return a = e.sent, e.abrupt("return");
                                case 19:
                                    return e.next = 21, this.windowRef.getMsgBox(c).confirmDelete("", r, {
                                        confirm: {
                                            text: this.T("common", "remove")
                                        }
                                    }, {
                                        useHtml: !0
                                    });
                                case 21:
                                    a = e.sent;
                                case 22:
                                    if ("confirm" === a) {
                                        e.next = 24;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 24:
                                    return this.loading = !0, e.prev = 25, e.next = 28, synowebapi.promises.request({
                                        api: "SYNO.SecureSignIn.Fido.Manage",
                                        method: "delete",
                                        params: {
                                            uid: n.uid
                                        },
                                        version: 1
                                    });
                                case 28:
                                    this.loading = !1, e.next = 34;
                                    break;
                                case 31:
                                    e.prev = 31, e.t0 = e.catch(25), this.loadingText = SYNO.API.Errors.core[e.t0.code] || this.T("common", "commfail");
                                case 34:
                                    return e.prev = 34, this.$refs.regDevices.loadData(), e.finish(34);
                                case 37:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this, [
                            [25, 31, 34, 37]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                onClickEdit: function(e) {
                    var t = this,
                        n = this.isSelected(),
                        i = this.windowRef.openModalWindow(Vue.extend({
                            template: '<FidoEdit :uid="uid" :devicename="devicename"/>',
                            components: {
                                FidoEdit: F
                            },
                            props: ["uid", "devicename"]
                        }), {
                            uid: n.uid,
                            devicename: n.keyname
                        }).window;
                    i && i.$on("close", (function() {
                        t.$refs.regDevices.loadData()
                    }))
                }
            })
        },
        Y = (n(70), Object(f.a)(q, A, [], !1, null, null, null));
    Y.options.__file = "src/management/fido-setting.vue";
    var K = Y.exports,
        U = {
            mixins: [o.a, s.a],
            components: {
                AuthenticatorSetting: P,
                FidoSetting: K
            },
            data: function() {
                return {
                    fidoCount: null,
                    approvedSigninCount: null,
                    tabKey: "approveSignIn",
                    isSelected: !0,
                    windowRef: {},
                    time: 0
                }
            },
            mounted: function() {
                var e = this;
                this.windowRef = this.$refs.window, this.getSigninMethod().then((function(t) {
                    e.signinMethod = t, e.authType = t.auth_type, e.time = SYNO.SDS.DateTimeFormatter(new Date(1e3 * t.time), {
                        type: "datetime"
                    })
                }))
            },
            methods: {
                close: function() {
                    this.$refs.window.close()
                },
                onCancel: function() {
                    this.close()
                },
                onTurnoff: function() {
                    var e = this;
                    this.$refs.window.getMsgBox().confirm(this.TT("management", "alert_disable_passwordless_title"), this.TT("management", "alert_disable_passwordless")).then((function(t) {
                        if ("cancel" !== t) return synowebapi.promises.request({
                            api: "SYNO.SecureSignIn.Method",
                            method: "set",
                            version: 1,
                            params: {
                                mode: "passwordless",
                                status: "off"
                            }
                        }).then((function() {
                            e.close()
                        }));
                        e.isSelected = !0
                    }))
                },
                onDataLoaded: function(e, t) {
                    var n = this;
                    "fido" === e && (this.fidoCount = t), "approved-signin" === e && (this.approvedSigninCount = t), 0 === this.fidoCount && 0 === this.approvedSigninCount && this.setSigninMethod("off", "passwordless").then((function() {
                        n.close()
                    }))
                }
            }
        },
        W = (n(72), Object(f.a)(U, v, [], !1, null, null, null));
    W.options.__file = "src/management/passwordless-settings.vue";
    var H = W.exports,
        V = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-modal-window", {
                ref: "window",
                class: "syno-securesignin-2fa-settings",
                attrs: {
                    "syno-id": "secure-signin-2fa-settings",
                    width: "800",
                    height: "580",
                    title: e.T("personal_settings", "otp_settings")
                }
            }, [n("v-panel", {
                attrs: {
                    "fluid-footer": ""
                },
                scopedSlots: e._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-perfect-scrollbar", [n("div", {
                            staticClass: "content-wrapper"
                        }, [n("v-fieldset", {
                            attrs: {
                                title: e.T("common", "status"),
                                collapsible: !1
                            }
                        }, [n("v-form", {
                            attrs: {
                                "syno-id": "pages-auth-page-form-0"
                            }
                        }, [n("div", {
                            staticClass: "desc"
                        }, [e._v(" " + e._s(e.TT("management", "2fa_settings_general_desc")) + " ")]), e._v(" "), n("v-form-item", {
                            staticClass: "activated-time",
                            attrs: {
                                label: e.TT("management", "passwordless_settings_activated_time"),
                                textonly: ""
                            }
                        }, [n("span", {
                            staticClass: "time"
                        }, [e._v(" " + e._s(e.time) + " ")]), e._v(" "), n("v-button", {
                            staticClass: "btn",
                            attrs: {
                                disabled: e.isEnforcedUser
                            },
                            on: {
                                click: e.onTurnoff
                            }
                        }, [e._v(" " + e._s(e.TT("common", "turn_off")) + " ")])], 1)], 1)], 1), e._v(" "), n("v-fieldset", {
                            staticClass: "otp-field-set",
                            attrs: {
                                title: e.T("personal_settings", "manage_trust_device"),
                                collapsible: !1
                            }
                        }, [n("div", {
                            staticClass: "field-set-wrapper"
                        }, [n("div", {
                            staticClass: "desc"
                        }, [e._v(" " + e._s(e.TT("management", "trusted_device_desc")) + " ")]), e._v(" "), n("v-button", {
                            staticClass: "btn",
                            attrs: {
                                "syno-id": "secure-signin-2fa-settings-trust-device",
                                suffix: "grey"
                            },
                            on: {
                                click: e.onClickTrustDevice
                            }
                        }, [e._v(" " + e._s(e.T("common", "manage")) + " ")])], 1)]), e._v(" "), n("v-fieldset", {
                            staticClass: "signin-field-set setting-field",
                            attrs: {
                                title: e.TT("management", "2fa_desc"),
                                collapsible: !1
                            }
                        }, [n("v-tabs", {
                            staticClass: "syno-sds-personal-tabs",
                            attrs: {
                                "syno-id": "src-app-tabs-0",
                                "active-tab-key": e.tabKey,
                                "has-fbar": !1
                            }
                        }, [n("v-tab-pane", {
                            attrs: {
                                "syno-id": "signin-tab-pane-0",
                                "tab-key": "approveSignIn",
                                tab: e.TT("authenticator", "approve_sign_in"),
                                hidden: e.hideAdvanceSigninMethod
                            }
                        }, [n("authenticator-setting", {
                            attrs: {
                                windowRef: e.windowRef,
                                signinMethod: "two-factor",
                                "otp-enabled": e.otpEnabled
                            },
                            on: {
                                dataloaded: e.onDataLoaded
                            }
                        })], 1), e._v(" "), n("v-tab-pane", {
                            attrs: {
                                "syno-id": "signin-tab-pane-1",
                                "tab-key": "fido",
                                tab: e.TT("fido", "hardware_security_key"),
                                hidden: e.hideAdvanceSigninMethod
                            }
                        }, [n("fido-setting", {
                            attrs: {
                                windowRef: e.windowRef,
                                signinMethod: "two-factor",
                                "otp-enabled": e.otpEnabled
                            },
                            on: {
                                dataloaded: e.onDataLoaded
                            }
                        })], 1), e._v(" "), n("v-tab-pane", {
                            attrs: {
                                "syno-id": "signin-tab-pane-2",
                                "tab-key": "otp",
                                tab: e.T("personal_settings", "otp_verification_code")
                            }
                        }, [n("otp-setting", {
                            attrs: {
                                windowRef: e.windowRef,
                                password: e.password,
                                "otp-enabled": e.otpEnabled
                            },
                            on: {
                                dataloaded: e.onDataLoaded
                            }
                        })], 1)], 1)], 1)], 1)])]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                type: "footbar"
                            },
                            on: {
                                click: e.onCancel
                            }
                        }, [e._v(" " + e._s(e.T("common", "close")) + " ")])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };
    V._withStripped = !0;
    var J = function() {
        var e = this,
            t = e.$createElement,
            n = e._self._c || t;
        return n("div", {
            staticClass: "setting dialog otp-panel"
        }, [n("v-panel", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.otpEnabled,
                expression: "!otpEnabled"
            }],
            staticClass: "empty-style",
            attrs: {
                "syno-id": "secure-signin-otp-setting-empty",
                "has-fbar": !1
            }
        }, [n("template", {
            slot: "body"
        }, [n("div", {
            staticClass: "desc",
            domProps: {
                innerHTML: e._s(e.empty_text)
            }
        }), e._v(" "), n("v-button", {
            staticClass: "btn",
            attrs: {
                "syno-id": "secure-signin-otp-setting-dialog-empty-add-btn",
                suffix: "blue"
            },
            on: {
                click: e.onClickSetup
            }
        }, [e._v(e._s(e.T("personal_settings", "setup")))])], 1)], 2), e._v(" "), n("v-panel", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.otpEnabled,
                expression: "otpEnabled"
            }],
            staticClass: "otp-setting-dialog normal-style",
            attrs: {
                "syno-id": "secure-signin-otp-setting-content",
                "has-tbar": !1,
                "has-fbar": !1,
                loading: e.loading
            }
        }, [n("template", {
            slot: "body"
        }, [n("div", {
            staticClass: "title"
        }, [e._v(" " + e._s(e.TT("management", "change_mobile_device_title")) + " ")]), e._v(" "), n("div", {
            staticClass: "desc"
        }, [e._v(" " + e._s(e.TT("management", "change_mobile_device_desc")) + " ")]), e._v(" "), n("v-button", {
            attrs: {
                "syno-id": "secure-signin-otp-setting-reset-mobile-device",
                suffix: "grey"
            },
            on: {
                click: e.onClickReset
            }
        }, [e._v(" " + e._s(e.TT("management", "reset_current_mobile_device")) + " ")])], 1)], 2)], 1)
    };

    function Q(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function G(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    Q(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    Q(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    J._withStripped = !0;
    var Z, X, ee, te = {
            mixins: [s.a, o.a],
            data: function() {
                return {
                    total: 0,
                    loading: !1,
                    loadingText: this.T("common", "loading"),
                    empty_text: this.TT("otp", "management_empty_text")
                }
            },
            props: {
                windowRef: {},
                otpEnabled: Boolean,
                password: String
            },
            methods: {
                setupOtp: (ee = G(regeneratorRuntime.mark((function e(t) {
                    var n = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.getEmailStatus();
                            case 2:
                                if (!e.sent) {
                                    e.next = 8;
                                    break
                                }
                                return e.next = 6, t();
                            case 6:
                                e.next = 9;
                                break;
                            case 8:
                                this.windowRef.getMsgBox().confirm(null, this.T("notification", "mail_service_not_enable"), {
                                    cancel: {
                                        text: this.T("common", "cancel")
                                    },
                                    confirm: {
                                        text: this.T("common", "ok")
                                    }
                                }, {
                                    useHtml: !0
                                }).then((function(e) {
                                    if ("confirm" === e) {
                                        var i = n.windowRef.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailWizard, {
                                            firstCreate: !0
                                        }).window;
                                        i && i.$on("close", G(regeneratorRuntime.mark((function e() {
                                            return regeneratorRuntime.wrap((function(e) {
                                                for (;;) switch (e.prev = e.next) {
                                                    case 0:
                                                        return e.next = 2, n.getEmailStatus();
                                                    case 2:
                                                        if (!e.sent) {
                                                            e.next = 6;
                                                            break
                                                        }
                                                        return e.next = 6, t();
                                                    case 6:
                                                    case "end":
                                                        return e.stop()
                                                }
                                            }), e, this)
                                        }))))
                                    }
                                }));
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return ee.apply(this, arguments)
                }),
                onClickReset: (X = G(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = G(regeneratorRuntime.mark((function e() {
                                    return regeneratorRuntime.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                this.windowRef.openModalWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                                    isOtp: !0,
                                                    password: this.password
                                                });
                                            case 1:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                }))).bind(this), e.next = 3, this.setupOtp(t);
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return X.apply(this, arguments)
                }),
                onClickSetup: (Z = G(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = G(regeneratorRuntime.mark((function e() {
                                    var t = this;
                                    return regeneratorRuntime.wrap((function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                return e.next = 2, this.windowRef.openModalWindow(SYNO.SDS.SecureSignIn.Register.TwoFactorWizard, {
                                                    isOtp: !0,
                                                    password: this.password
                                                });
                                            case 2:
                                                e.sent.window.$on("close", (function() {
                                                    t.$emit("dataloaded", "otp", 0)
                                                }));
                                            case 5:
                                            case "end":
                                                return e.stop()
                                        }
                                    }), e, this)
                                }))).bind(this), e.next = 3, this.setupOtp(t);
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return Z.apply(this, arguments)
                })
            }
        },
        ne = (n(74), Object(f.a)(te, J, [], !1, null, null, null));
    ne.options.__file = "src/management/otp-setting.vue";
    var ie = ne.exports;

    function se(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function oe(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    se(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    se(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var re, ae = {
            mixins: [s.a, o.a],
            components: {
                AuthenticatorSetting: P,
                FidoSetting: K,
                OtpSetting: ie
            },
            props: {
                hideAdvanceSigninMethod: Boolean,
                otpEnabled: Boolean,
                password: String
            },
            computed: {
                tabKey: function() {
                    return this.hideAdvanceSigninMethod ? "otp" : "approveSignIn"
                }
            },
            data: function() {
                return {
                    windowRef: {},
                    fidoCount: null,
                    approvedSigninCount: null,
                    isEnforcedUser: !1,
                    time: 0
                }
            },
            mounted: function() {
                var e = oe(regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.windowRef = this.$refs.window, e.next = 3, this.isEnforced2faUser();
                            case 3:
                                this.isEnforcedUser = e.sent, this.getSigninMethod().then((function(e) {
                                    t.signinMethod = e, t.authType = e.auth_type, t.time = SYNO.SDS.DateTimeFormatter(new Date(1e3 * e.time), {
                                        type: "datetime"
                                    })
                                }));
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })));
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            methods: {
                close: function() {
                    this.$refs.window.close()
                },
                onCancel: function() {
                    this.close()
                },
                onClickTrustDevice: function() {
                    this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.TrustedDeviceDialog)
                },
                onDataLoaded: (re = oe(regeneratorRuntime.mark((function e(t, n) {
                    var i = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.getOtpStatus();
                            case 2:
                                this.otpEnabled = e.sent, "fido" === t && (this.fidoCount = n), "approved-signin" === t && (this.approvedSigninCount = n), 0 !== this.fidoCount || 0 !== this.approvedSigninCount || this.otpEnabled || this.setSigninMethod("off", "two-factor").then((function() {
                                    i.close()
                                }));
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t) {
                    return re.apply(this, arguments)
                }),
                onTurnoff: function() {
                    var e = this;
                    this.$refs.window.getMsgBox().confirm(this.TT("management", "alert_disable_2fa_title"), this.TT("management", "alert_disable_2fa")).then(function() {
                        var t = oe(regeneratorRuntime.mark((function t(n) {
                            return regeneratorRuntime.wrap((function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if ("cancel" === n) {
                                            t.next = 5;
                                            break
                                        }
                                        if (!e.otpEnabled) {
                                            t.next = 4;
                                            break
                                        }
                                        return t.next = 4, e.revokeOTP();
                                    case 4:
                                        return t.abrupt("return", synowebapi.promises.request({
                                            api: "SYNO.SecureSignIn.Method",
                                            method: "set",
                                            version: 1,
                                            params: {
                                                mode: "two-factor",
                                                status: "off"
                                            }
                                        }).then((function() {
                                            e.close()
                                        })));
                                    case 5:
                                    case "end":
                                        return t.stop()
                                }
                            }), t, this)
                        })));
                        return function(e) {
                            return t.apply(this, arguments)
                        }
                    }())
                }
            }
        },
        ce = (n(76), Object(f.a)(ae, V, [], !1, null, null, null));
    ce.options.__file = "src/management/2fa-settings.vue";
    var de = ce.exports,
        pe = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-message-box-window", {
                ref: "window",
                staticClass: "secure-signin-inherit-dialog",
                attrs: {
                    "syno-id": "dialogs-inherit-window-0",
                    doConfirm: e.onConfirm,
                    doCancel: e.onCancel,
                    width: "680"
                },
                scopedSlots: e._u([{
                    key: "title",
                    fn: function() {
                        return [n("div", {
                            staticClass: "dialog-title"
                        }, [e._v(" " + e._s(e.title) + " ")])]
                    },
                    proxy: !0
                }, {
                    key: "content",
                    fn: function() {
                        return [n("div", {
                            staticClass: "dialog-content"
                        }, [n("div", [e._v(" " + e._s(e.desc) + " ")]), e._v(" "), n("v-radio-group", {
                            model: {
                                value: e.inherit,
                                callback: function(t) {
                                    e.inherit = t
                                },
                                expression: "inherit"
                            }
                        }, [n("v-radio", {
                            attrs: {
                                value: "yes"
                            }
                        }, [n("div", [e._v(" " + e._s(e.yes) + " ")]), e._v(" "), n("v-data-table", {
                            ref: "dataTable",
                            attrs: {
                                columns: e.columns,
                                currentData: e.deviceList,
                                showPagingBar: !1,
                                enableHdMenu: !1
                            }
                        })], 1), e._v(" "), n("v-radio", {
                            attrs: {
                                value: "no"
                            }
                        }, [n("div", [e._v(" " + e._s(e.no) + " ")]), e._v(" "), n("div", {
                            staticClass: "note"
                        }, [e._v(" " + e._s(e.note) + " ")])])], 1)], 1)]
                    },
                    proxy: !0
                }])
            })
        };

    function ue(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function le(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    pe._withStripped = !0;
    var ge, he, fe = {
            mixins: [s.a, o.a],
            props: {
                onInherit: Function,
                onNotInherit: Function,
                signinMethod: String
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = null != arguments[t] ? Object(arguments[t]) : {},
                        i = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(n, e).enumerable
                    })))), i.forEach((function(t) {
                        le(e, t, n[t])
                    }))
                }
                return e
            }({}, Object(b.mapState)(["username", "password"]), {
                desc: function() {
                    return "passwordless" === this.signinMethod ? this.TT("inherit", "passwordless_desc") : this.TT("inherit", "2fa_desc")
                },
                deviceList: function() {
                    return this.authenticators && this.fidos ? this.authenticators.concat(this.fidos) : []
                },
                title: function() {
                    return "passwordless" === this.signinMethod ? this.TT("inherit", "passwordless_title") : this.TT("inherit", "2fa_title")
                },
                yes: function() {
                    return "passwordless" === this.signinMethod ? this.TT("inherit", "passwordless_yes") : this.TT("inherit", "2fa_yes")
                },
                no: function() {
                    return "passwordless" === this.signinMethod ? this.TT("inherit", "passwordless_no") : this.TT("inherit", "2fa_no")
                },
                note: function() {
                    return "passwordless" === this.signinMethod ? this.TT("inherit", "passwordless_note") : this.TT("inherit", "2fa_note")
                }
            }),
            data: function() {
                var e = this;
                return {
                    authenticators: void 0,
                    fidos: void 0,
                    inherit: "yes",
                    columns: [{
                        title: this.T("common", "name"),
                        field: "name"
                    }, {
                        title: this.T("personal_settings", "sign_in_method"),
                        field: "deviceType",
                        fn: function(t) {
                            return "approved_signin" === t.deviceType ? e.TT("authenticator", "approve_sign_in") : "usb" === t.deviceType ? e.TT("fido", "type_usb_key") : "windows" === t.deviceType ? e.TT("fido", "type_windows_hello") : "touchID" === t.deviceType ? e.TT("fido", "type_touch_id") : void 0
                        }
                    }, {
                        title: this.TT("common", "add_time"),
                        fn: function(e) {
                            return _S("isLogined") ? SYNO.SDS.DateTimeFormatter(new Date(1e3 * e.add_time), {
                                type: "datetime"
                            }) : new Date(1e3 * e.add_time).format(_S("date_format") + " " + _S("time_format"))
                        }
                    }, {
                        title: this.TT("common", "last_used_time"),
                        fn: function(e) {
                            return _S("isLogined") ? SYNO.SDS.DateTimeFormatter(new Date(1e3 * e.last_used_time), {
                                type: "datetime"
                            }) : new Date(1e3 * e.last_used_time).format(_S("date_format") + " " + _S("time_format"))
                        }
                    }],
                    paramsName: {
                        results: "deviceInfo"
                    }
                }
            },
            methods: {
                onCancel: function() {
                    return this.$refs.window.close(), new Promise((function() {}))
                },
                onConfirm: (ge = regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (this.inherit) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", new Promise((function() {})));
                            case 2:
                                if ("no" !== this.inherit) {
                                    e.next = 9;
                                    break
                                }
                                return e.next = 5, this.revokeAll(this.authenticators, this.fidos, this.signinMethod, this.username, this.password);
                            case 5:
                                if (!this.onNotInherit) {
                                    e.next = 7;
                                    break
                                }
                                return e.abrupt("return", new Promise((function() {
                                    t.$refs.window.close(), t.onNotInherit()
                                })));
                            case 7:
                                e.next = 13;
                                break;
                            case 9:
                                if ("passwordless" !== this.signinMethod) {
                                    e.next = 12;
                                    break
                                }
                                return e.next = 12, this.revokeOTP();
                            case 12:
                                return e.abrupt("return", new Promise((function() {
                                    t.setSigninMethod("on", t.signinMethod, t.username, t.password).then((function() {
                                        t.$refs.window.close(), t.onInherit && t.onInherit()
                                    }))
                                })));
                            case 13:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), he = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(n, i) {
                        var s = ge.apply(e, t);

                        function o(e) {
                            ue(s, n, i, o, r, "next", e)
                        }

                        function r(e) {
                            ue(s, n, i, o, r, "throw", e)
                        }
                        o(void 0)
                    }))
                }, function() {
                    return he.apply(this, arguments)
                }),
                loadAuthenticatorInfo: function() {
                    var e = this;
                    return this.listAuthenticatorInfo(this.username, this.password).then((function(t) {
                        e.authenticators = t.authenticators.map((function(e) {
                            return {
                                name: e.name,
                                deviceType: "approved_signin",
                                add_time: e.add_time,
                                last_used_time: e.last_used_time,
                                authenticator_id: e.authenticator_id
                            }
                        }))
                    }))
                },
                loadFidoInfo: function() {
                    var e = this;
                    return this.listFidoInfo(this.username, this.password).then((function(t) {
                        e.fidos = t.fidos.map((function(e) {
                            return {
                                name: e.keyname,
                                deviceType: e.keytype,
                                add_time: e.ctime,
                                last_used_time: e.last_used_time,
                                uid: e.uid
                            }
                        }))
                    }))
                }
            },
            mounted: function() {
                this.loadAuthenticatorInfo(), this.loadFidoInfo()
            }
        },
        me = (n(78), Object(f.a)(fe, pe, [], !1, null, null, null));
    me.options.__file = "src/management/inherit-dialog.vue";
    var we = me.exports,
        ve = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-wizard-window", {
                ref: "window",
                attrs: {
                    "syno-id": "secure-signin-passwordless-register-wizard-window",
                    title: e.TT("wizard", "passwordless_title"),
                    width: "700",
                    height: "554"
                }
            }, [n("v-wizard", {
                ref: "wizard",
                attrs: {
                    "syno-id": "secure-signin-passwordless-register-wizard",
                    "active-step-key": e.firstStepKey,
                    "custom-buttons-group": e.customButtonsGroup
                },
                on: {
                    "current-step": e.onChangeStep
                }
            }, [n("signin-method-step", {
                attrs: {
                    windowRef: e.windowRef,
                    "step-key": "signin-method-step",
                    "signin-method": e.signinMethod,
                    headline: e.TT("wizard", "passwordless_desc"),
                    "show-footer": !1
                },
                on: {
                    "open-msg-box": e.openMsgBox,
                    "open-verify-dialog": e.openVerifyDialog
                }
            }), e._v(" "), n("approve-signin-welcome-step", {
                attrs: {
                    "step-key": "approve-signin-welcome-step",
                    "next-step-key": "approve-signin-download-app-step",
                    headline: e.TT("authenticator", "sign_in_with_authenticator "),
                    type: e.authenticatorWelcomeType
                }
            }), e._v(" "), n("approve-signin-download-app-step", {
                attrs: {
                    "step-key": "approve-signin-download-app-step",
                    "next-step-key": "approve-signin-scan-qr-step",
                    headline: e.TT("authenticator", "setup_authenticator_desc")
                }
            }), e._v(" "), n("approve-signin-scan-qr-step", {
                attrs: {
                    "step-key": "approve-signin-scan-qr-step",
                    "next-step-key": "approve-signin-summary-step"
                }
            }), e._v(" "), n("approve-signin-summary-step", {
                attrs: {
                    "step-key": "approve-signin-summary-step",
                    curDevName: e.curDevName
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("fido-select-method-step", {
                attrs: {
                    "step-key": "fido-select-method-step",
                    "next-step-key": "fido-register-step",
                    type: e.fidoWelcomeType
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-register-step", {
                attrs: {
                    "step-key": "fido-register-step",
                    "method-select": e.methodSelect
                }
            }), e._v(" "), n("fido-keyname-step", {
                attrs: {
                    "step-key": "fido-keyname-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox,
                    close: e.onClose
                }
            }), e._v(" "), n("fido-error-step", {
                attrs: {
                    "step-key": "fido-error-step",
                    "method-select": e.methodSelect,
                    "next-step-key": "fido-register-step"
                }
            }), e._v(" "), n("fido-summary-step", {
                attrs: {
                    "step-key": "fido-summary-step"
                },
                on: {
                    close: e.onClose
                }
            })], 1)], 1)
        };
    ve._withStripped = !0;
    var ye = n(14),
        xe = n(12),
        be = n(9),
        _e = n(11),
        Se = n(16),
        ke = n(13),
        Te = n(18),
        Ee = n(15),
        Oe = n(10),
        Ne = n(17);

    function Ce(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function Be(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    Ce(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    Ce(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var Pe, Ae, Me = {
            mixins: [s.a],
            components: {
                signinMethodStep: ye.a,
                approveSigninWelcomeStep: xe.a,
                approveSigninDownloadAppStep: be.a,
                approveSigninScanQrStep: _e.a,
                approveSigninSummaryStep: Se.a,
                fidoSelectMethodStep: ke.a,
                fidoRegisterStep: Te.a,
                fidoKeynameStep: Ee.a,
                fidoErrorStep: Oe.a,
                fidoSummaryStep: Ne.a
            },
            props: {
                isAuthenticator: {
                    type: Boolean,
                    default: !1
                },
                isFido: {
                    type: Boolean,
                    default: !1
                },
                otpEnabled: Boolean
            },
            data: function() {
                return {
                    windowRef: {},
                    disableBack: !1,
                    disableNext: !1,
                    nextText: "",
                    showBack: !0,
                    showNext: !0,
                    showStart: !1,
                    curDevName: "",
                    signinMethod: [{
                        title: this.TT("authenticator", "approve_sign_in"),
                        desc: this.T("personal_settings", "approve_sign_in_desc"),
                        nextStep: "approve-signin-welcome-step",
                        extraClass: "approved_signin"
                    }, {
                        title: this.TT("fido", "hardware_security_key"),
                        desc: this.TT("wizard", "hardware_security_key_desc"),
                        nextStep: "fido-select-method-step",
                        extraClass: "fido"
                    }],
                    methodSelect: ""
                }
            },
            methods: {
                onChangeStep: function(e) {
                    "signin-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !1, this.nextText = "") : "approve-signin-welcome-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !this.isAuthenticator, this.showNext = !this.isAuthenticator, this.showStart = !!this.isAuthenticator, this.nextText = this.T("common", "next")) : "approve-signin-download-app-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "next")) : "approve-signin-scan-qr-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "next")) : "approve-signin-summary-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "finish")) : "fido-select-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !this.isFido, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "next")) : "fido-register-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "next")) : "fido-keyname-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "done")) : "fido-error-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.nextText = this.TT("authenticator", "try_again")) : "fido-summary-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "done")) : (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showStart = !1, this.nextText = this.T("common", "next"))
                },
                onClose: function() {
                    this.$refs.window.close()
                },
                openVerifyDialog: (Ae = Be(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                    var r, a, c;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.IdentityVerificationDialog), a = r.window, e.next = 3, a.confirm(t, n, i, {
                                    useHtml: !0
                                });
                            case 3:
                                if ("confirm" === (c = e.sent)) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return");
                            case 6:
                                o && o(c);
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t, n, i, s) {
                    return Ae.apply(this, arguments)
                }),
                openMsgBox: (Pe = Be(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                    var r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.window.getMsgBox().alert(t, n, i, {
                                    useHtml: !0
                                });
                            case 2:
                                r = e.sent, o && o(r);
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e, t, n, i, s) {
                    return Pe.apply(this, arguments)
                })
            },
            computed: {
                authenticatorWelcomeType: function() {
                    return this.isAuthenticator ? "welcome" : "normal"
                },
                fidoWelcomeType: function() {
                    return this.isFido ? "welcome" : "normal"
                },
                customButtonsGroup: function() {
                    return {
                        start: {
                            show: this.showStart
                        },
                        back: {
                            disabled: this.disableBack,
                            show: this.showBack
                        },
                        next: {
                            disabled: this.disableNext,
                            show: this.showNext,
                            text: this.nextText
                        }
                    }
                },
                firstStepKey: function() {
                    return this.isAuthenticator ? "approve-signin-welcome-step" : this.isFido ? "fido-select-method-step" : "signin-method-step"
                }
            },
            mounted: function() {
                this.$store.commit("RESET"), this.$store.commit("SET_SIGNIN_MODE", "passwordless"), this.$store.commit("SET_OTP_ENABLED", this.otpEnabled), this.windowRef = this.$refs.window
            }
        },
        ze = (n(114), Object(f.a)(Me, ve, [], !1, null, null, null));
    ze.options.__file = "src/passwordless-wizard.vue";
    var Re = ze.exports,
        De = function() {
            var e = this,
                t = e.$createElement,
                n = e._self._c || t;
            return n("v-wizard-window", {
                ref: "window",
                attrs: {
                    "syno-id": "secure-signin-two-factor-register-wizard-window",
                    title: e.TT("wizard", "2fa_title"),
                    width: "700",
                    height: "554"
                }
            }, [n("v-wizard", {
                ref: "wizard",
                attrs: {
                    "syno-id": "secure-signin-two-factor-register-wizard",
                    "active-step-key": e.firstStepKey,
                    "custom-buttons-group": e.customButtonsGroup,
                    "show-left-button": e.showLeftButton,
                    "status-bar-state": e.statusBarState,
                    "show-status-bar": e.showStatusBar,
                    "status-bar-error-text": e.statusBarErrorText
                },
                on: {
                    "current-step": e.onChangeStep,
                    "left-button": e.onLeftButton
                }
            }, [n("signin-method-step", {
                attrs: {
                    windowRef: e.windowRef,
                    "step-key": "signin-method-step",
                    "signin-method": e.signinMethod,
                    headline: e.TT("wizard", "2fa_desc"),
                    "show-footer": !1
                },
                on: {
                    "open-msg-box": e.openMsgBox,
                    "open-verify-dialog": e.openVerifyDialog
                }
            }), e._v(" "), n("approve-signin-welcome-step", {
                attrs: {
                    "step-key": "approve-signin-welcome-step",
                    "next-step-key": "approve-signin-download-app-step",
                    headline: e.TT("authenticator", "sign_in_with_authenticator "),
                    type: e.authenticatorWelcomeType
                }
            }), e._v(" "), n("approve-signin-download-app-step", {
                attrs: {
                    "step-key": "approve-signin-download-app-step",
                    "next-step-key": "approve-signin-scan-qr-step",
                    headline: e.TT("authenticator", "setup_authenticator_desc")
                }
            }), e._v(" "), n("approve-signin-scan-qr-step", {
                attrs: {
                    "step-key": "approve-signin-scan-qr-step",
                    "next-step-key": "approve-signin-summary-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("approve-signin-summary-step", {
                attrs: {
                    "step-key": "approve-signin-summary-step"
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("otp-welcome-step", {
                attrs: {
                    windowRef: e.windowRef,
                    "step-key": "otp-welcome-step",
                    "next-step-key": e.jumpStep || (e.isDomainUser ? "otp-download-app-step" : "otp-backup-email-step"),
                    type: e.otpWelcomeType
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("otp-backup-email-step", {
                attrs: {
                    "step-key": "otp-backup-email-step",
                    "next-step-key": "otp-download-app-step"
                },
                on: {
                    "show-loading": e.showLoading,
                    "hide-loading": e.hideLoading,
                    "show-error": e.showError
                }
            }), e._v(" "), n("otp-download-app-step", {
                attrs: {
                    "step-key": "otp-download-app-step",
                    "next-step-key": "otp-qrcode-step",
                    headline: e.T("personal_settings", "otp_wizard_install_app")
                }
            }), e._v(" "), n("otp-qrcode-step", {
                attrs: {
                    "step-key": "otp-qrcode-step",
                    "next-step-key": "otp-summary-step",
                    headline: e.T("personal_settings", "otp_wizard_install_app")
                },
                on: {
                    "show-otp-secret": e.showOtpSecret,
                    "show-loading": e.showLoading,
                    "hide-loading": e.hideLoading,
                    "show-error": e.showError
                }
            }), e._v(" "), n("otp-summary-step", {
                attrs: {
                    "step-key": "otp-summary-step"
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("fido-select-method-step", {
                attrs: {
                    "step-key": "fido-select-method-step",
                    "next-step-key": "fido-register-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-register-step", {
                attrs: {
                    "step-key": "fido-register-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-keyname-step", {
                attrs: {
                    "step-key": "fido-keyname-step",
                    parentWin: this.$refs.window
                },
                on: {
                    close: e.onClose
                }
            }), e._v(" "), n("fido-error-step", {
                attrs: {
                    "step-key": "fido-error-step",
                    "next-step-key": "fido-register-step"
                },
                on: {
                    "open-msg-box": e.openMsgBox
                }
            }), e._v(" "), n("fido-summary-step", {
                attrs: {
                    "step-key": "fido-summary-step"
                },
                on: {
                    close: e.onClose
                }
            })], 1)], 1)
        };
    De._withStripped = !0;
    var Ie = n(28),
        Fe = n(25),
        Le = n(24),
        je = n(27),
        $e = n(26);

    function qe(e, t, n, i, s, o, r) {
        try {
            var a = e[o](r),
                c = a.value
        } catch (e) {
            return void n(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(i, s)
    }

    function Ye(e) {
        return function() {
            var t = this,
                n = arguments;
            return new Promise((function(i, s) {
                var o = e.apply(t, n);

                function r(e) {
                    qe(o, i, s, r, a, "next", e)
                }

                function a(e) {
                    qe(o, i, s, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function Ke(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = null != arguments[t] ? Object(arguments[t]) : {},
                i = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (i = i.concat(Object.getOwnPropertySymbols(n).filter((function(e) {
                return Object.getOwnPropertyDescriptor(n, e).enumerable
            })))), i.forEach((function(t) {
                Ue(e, t, n[t])
            }))
        }
        return e
    }

    function Ue(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var We, He = {
            mixins: [s.a, o.a],
            components: {
                SigninMethodStep: ye.a,
                approveSigninWelcomeStep: xe.a,
                approveSigninDownloadAppStep: be.a,
                approveSigninScanQrStep: _e.a,
                approveSigninSummaryStep: Se.a,
                otpWelcomeStep: Ie.a,
                otpBackupEmailStep: Fe.a,
                otpDownloadAppStep: be.a,
                otpQrcodeStep: Le.a,
                otpSummaryStep: $e.a,
                fidoSelectMethodStep: ke.a,
                fidoRegisterStep: Te.a,
                fidoKeynameStep: Ee.a,
                fidoErrorStep: Oe.a,
                fidoSummaryStep: Ne.a
            },
            props: {
                password: String,
                otpEnabled: Boolean,
                isAuthenticator: {
                    type: Boolean,
                    default: !1
                },
                isFido: {
                    type: Boolean,
                    default: !1
                },
                isOtp: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    windowRef: {},
                    disableBack: !1,
                    disableNext: !1,
                    jumpStep: null,
                    nextText: "",
                    showBack: !0,
                    showNext: !0,
                    showLeftButton: !1,
                    statusBarState: "loading",
                    showStatusBar: !1,
                    statusBarErrorText: this.T("common", "error_system"),
                    serviceAvailable: !1
                }
            },
            methods: Ke({
                onChangeStep: function(e) {
                    "signin-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !1, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = "") : "approve-signin-welcome-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !this.isAuthenticator, this.showNext = !this.isAuthenticator, this.showStart = !!this.isAuthenticator, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next")) : "approve-signin-download-app-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.showStart = !1, this.nextText = this.T("common", "next")) : "approve-signin-scan-qr-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.showStart = !1, this.nextText = this.T("common", "next")) : "approve-signin-summary-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.showStart = !1, this.nextText = this.T("common", "done")) : "otp-welcome-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, "" === this.authenticatorId && Number.isNaN(this.fidoUid) ? this.showBack = !this.isOtp : this.showBack = !1, this.showNext = !this.isOtp, this.showLeftButton = this.otpStepShowLeft, this.showStatusBar = !1, this.showStart = !!this.isOtp) : "otp-backup-email-step" === e.currentStepKey || "otp-download-app-step" === e.currentStepKey || "otp-qrcode-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.showStart = !1) : "otp-summary-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "done")) : "fido-select-method-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !this.isFido, this.showNext = !0, this.showStart = !1, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next")) : "fido-register-step" === e.currentStepKey ? (this.disableBack = !0, this.disableNext = !0, this.showBack = !0, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next"), this.showStart = !1) : "fido-keyname-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.showStart = !1, this.nextText = this.T("common", "done")) : "fido-error-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.TT("authenticator", "try_again"), this.showStart = !1) : "fido-summary-step" === e.currentStepKey ? (this.disableBack = !1, this.disableNext = !1, this.showBack = !1, this.showNext = !0, this.showStart = !1, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "done")) : (this.disableBack = !1, this.disableNext = !1, this.showBack = !0, this.showNext = !0, this.showStart = !1, this.showLeftButton = !1, this.showStatusBar = !1, this.nextText = this.T("common", "next"))
                },
                onClose: function() {
                    this.$refs.window.close()
                },
                showLoading: function() {
                    this.statusBarState = "loading", this.showStatusBar = !0, this.showNext && (this.disableNext = !0)
                },
                hideLoading: function() {
                    this.showStatusBar = !1, this.showNext && (this.disableNext = !1)
                },
                showError: function(e) {
                    this.statusBarState = "error", this.showStatusBar = !0, this.statusBarErrorText = e
                },
                openMsgBox: function() {
                    var e = Ye(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                        var r;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.window.getMsgBox().alert(t, n, i, {
                                        useHtml: !0
                                    });
                                case 2:
                                    r = e.sent, o && o(r);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function(t, n, i, s, o) {
                        return e.apply(this, arguments)
                    }
                }(),
                openVerifyDialog: function() {
                    var e = Ye(regeneratorRuntime.mark((function e(t, n, i, s, o) {
                        var r, a, c, d;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return r = this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.IdentityVerificationDialog), a = r.window, c = r.component, e.next = 3, a.confirm(t, n, i, {
                                        useHtml: !0
                                    });
                                case 3:
                                    if ("confirm" === (d = e.sent)) {
                                        e.next = 6;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 6:
                                    this.$store.commit("SET_PASSWORD", c.password), o && o(d);
                                case 8:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function(t, n, i, s, o) {
                        return e.apply(this, arguments)
                    }
                }(),
                showOtpSecret: function() {
                    var e = Vue.extend({
                        template: "<otp-secret-win />",
                        components: {
                            otpSecretWin: je.a
                        },
                        store: this.$store
                    });
                    this.$refs.window.openModalWindow(e)
                },
                onLeftButton: (We = Ye(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.$refs.window.getMsgBox().confirmDelete(null, this.TT("otp", "skip_warning_msg"), {
                                    cancel: {
                                        text: this.T("personal_settings", "setup")
                                    },
                                    confirm: {
                                        text: this.T("common", "skip")
                                    }
                                }, {
                                    useHtml: !0
                                });
                            case 2:
                                "confirm" === e.sent && ("" !== this.authenticatorId ? this.jumpStep = "approve-signin-summary-step" : Number.isNaN(this.fidoUid) ? this.jumpStep = "otp-summary-step" : this.jumpStep = "usb" === this.methodSelect ? "fido-keyname-step" : "fido-summary-step", this.$store.commit("SET_SKIP_OTP", !0)), this.$refs.wizard.currentStep.nextStep();
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return We.apply(this, arguments)
                })
            }, Object(b.mapMutations)(["SET_OTP_STATUS"])),
            computed: Ke({
                authenticatorWelcomeType: function() {
                    return this.isAuthenticator ? "welcome" : "normal"
                },
                otpWelcomeType: function() {
                    return this.isOtp ? "welcome" : "normal"
                },
                otpStepShowLeft: function() {
                    return !this.isOtp && (!!this.authenticatorId || !!this.fidoUid)
                },
                customButtonsGroup: function() {
                    return {
                        start: {
                            show: this.showStart
                        },
                        back: {
                            disabled: this.disableBack,
                            show: this.showBack
                        },
                        next: {
                            disabled: this.disableNext,
                            show: this.showNext,
                            text: this.nextText
                        }
                    }
                },
                isDomainUser: function() {
                    return -1 !== _S("user").search("\\\\")
                },
                signinMethod: function() {
                    var e = [{
                        title: this.T("personal_settings", "otp_verification_code"),
                        desc: this.T("personal_settings", "verification_code_desc"),
                        nextStep: "otp-welcome-step",
                        extraClass: "otp"
                    }];
                    return this.serviceAvailable && (e.unshift({
                        title: this.TT("authenticator", "approve_sign_in"),
                        desc: this.T("personal_settings", "approve_sign_in_desc"),
                        nextStep: "approve-signin-welcome-step",
                        extraClass: "approved_signin"
                    }), e.push({
                        title: this.TT("fido", "hardware_security_key"),
                        desc: this.TT("wizard", "hardware_security_key_desc"),
                        nextStep: "fido-select-method-step",
                        extraClass: "fido"
                    })), e
                },
                firstStepKey: function() {
                    return this.isOtp ? "otp-welcome-step" : this.isAuthenticator ? "approve-signin-welcome-step" : this.isFido ? "fido-select-method-step" : "signin-method-step"
                }
            }, Object(b.mapState)(["fidoUid", "authenticatorId", "methodSelect"])),
            mounted: function() {
                var e = Ye(regeneratorRuntime.mark((function e() {
                    var t = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                this.$store.commit("RESET"), this.$store.commit("SET_SIGNIN_MODE", "two-factor"), this.$store.commit("SET_OTP_ENABLED", this.otpEnabled), this.$store.commit("SET_PASSWORD", this.password), this.windowRef = this.$refs.window;
                                try {
                                    this.getPackageStatus().then((function(e) {
                                        t.serviceAvailable = e.account_status && e.enabled
                                    }))
                                } catch (e) {
                                    console.log(e)
                                }
                                case 6:
                                case "end":
                                    return e.stop()
                        }
                    }), e, this)
                })));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        },
        Ve = (n(128), Object(f.a)(He, De, [], !1, null, null, null));
    Ve.options.__file = "src/2fa-wizard.vue";
    var Je = Ve.exports,
        Qe = n(19);

    function Ge(e) {
        return (Ge = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
            return typeof e
        } : function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        })(e)
    }

    function Ze(e) {
        var t = e instanceof Array ? [] : {};
        for (var n in e) null != e[n] && "object" === Ge(e[n]) ? t[n] = Ze(e[n]) : t[n] = e[n];
        return t
    }
    var Xe = {
            AuthenticatorSettingModule: {
                namespaced: !0,
                state: {
                    selected: {
                        authenticator: void 0
                    }
                },
                mutations: {
                    UPDATE_SELECT_AUTHENTICATOR: function(e, t) {
                        e.selected.authenticator = t
                    },
                    RELEASE_SELECT_AUTHENTICATOR: function(e) {
                        e.selected.authenticator = void 0
                    }
                },
                actions: {
                    selectedAuthenticator: function(e, t) {
                        (0, e.commit)("UPDATE_SELECT_AUTHENTICATOR", t)
                    },
                    releasedAuthenticator: function(e) {
                        (0, e.commit)("RELEASE_SELECT_AUTHENTICATOR")
                    }
                },
                getters: {
                    isSelected: function(e) {
                        return e.selected.authenticator
                    }
                }
            },
            FidoSettingModule: {
                namespaced: !0,
                state: {
                    selected: {
                        fido: void 0
                    }
                },
                mutations: {
                    UPDATE_SELECT_FIDO: function(e, t) {
                        e.selected.fido = t
                    },
                    RELEASE_SELECT_FIDO: function(e) {
                        e.selected.fido = void 0
                    }
                },
                actions: {
                    selectedFido: function(e, t) {
                        (0, e.commit)("UPDATE_SELECT_FIDO", t)
                    },
                    releasedFido: function(e) {
                        (0, e.commit)("RELEASE_SELECT_FIDO")
                    }
                },
                getters: {
                    isSelected: function(e) {
                        return e.selected.fido
                    }
                }
            }
        },
        et = Object.create(null);
    for (var tt in Xe) {
        var nt = Xe[tt];
        et[tt] = Ze(nt.state)
    }
    var it = new _.a.Store({
        modules: Xe,
        mutations: {
            RESET: function(e) {
                for (var t in et) {
                    var n = et[t];
                    e[t] = Ze(n)
                }
            }
        }
    });
    n(58), n(140);
    Ext.namespace("SYNO.SDS.SecureSignIn.Register"), Ext.namespace("SYNO.SDS.SecureSignIn.Passwordless"), Ext.namespace("SYNO.SDS.SecureSignIn.TwoFactor"), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.AdvanceSigninMethod = Vue.extend({
            template: '<AdvanceSigninMethod :appWindow="appWindow" />',
            components: {
                AdvanceSigninMethod: w
            },
            props: ["appWindow"]
        }), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.Register.PasswordlessWizard = Vue.extend({
            template: '<PasswordlessWizard :isAuthenticator="isAuthenticator" :isFido="isFido" :otpEnabled="otpEnabled" />',
            components: {
                PasswordlessWizard: Re
            },
            store: Qe.a,
            props: ["isAuthenticator", "isFido", "otpEnabled"]
        }), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.Register.TwoFactorWizard = Vue.extend({
            template: '<TwoFactorWizard :password="password" :isAuthenticator="isAuthenticator" :isFido="isFido" :isOtp="isOtp" :otpEnabled="otpEnabled" />',
            components: {
                TwoFactorWizard: Je
            },
            store: Qe.a,
            props: ["password", "isAuthenticator", "isFido", "isOtp", "otpEnabled"]
        }), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.Register.InheritDialog = Vue.extend({
            template: '<InheritDialog :signinMethod="signinMethod" :onInherit="onInherit" :onNotInherit="onNotInherit" />',
            components: {
                InheritDialog: we
            },
            store: Qe.a,
            props: ["signinMethod", "onInherit", "onNotInherit"]
        }), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.Passwordless.Settings = Vue.extend({
            template: "<PasswordlessSettings/>",
            components: {
                PasswordlessSettings: H
            },
            store: it
        }), // @require: SYNO.SDS.SecureSignIn.Instance
        SYNO.SDS.SecureSignIn.TwoFactor.Settings = Vue.extend({
            template: '<TwoFactorSettings :password="password" :hideAdvanceSigninMethod="hideAdvanceSigninMethod" :otpEnabled="otpEnabled" />',
            components: {
                TwoFactorSettings: de
            },
            store: it,
            props: ["password", "hideAdvanceSigninMethod", "otpEnabled"]
        })
}]);
