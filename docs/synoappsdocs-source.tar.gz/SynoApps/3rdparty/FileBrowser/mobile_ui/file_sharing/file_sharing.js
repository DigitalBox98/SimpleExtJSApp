/* Copyright (c) 2020 Synology Inc. All rights reserved. */

angular.createNameSpace("SYNO.webfm.utils");
angular.apply(SYNO.webfm.utils, {
    getWebAPIErrStr: function(a) {
        if (!a) {
            return _T("error", "error_error_system")
        }
        switch (a.code) {
            case 400:
                return _T("error", "error_error_system");
            case 401:
                return _T("error", "error_error_system");
            case 402:
                return _T("error", "error_system_busy");
            case 403:
                return _T("error", "error_invalid_user_group");
            case 404:
                return _T("error", "error_invalid_user_group");
            case 405:
                return _T("error", "error_invalid_user_group");
            case 406:
                return _T("error", "error_testjoin");
            case 407:
                return _T("error", "error_privilege_not_enough");
            case 408:
                return _T("error", "error_no_path");
            case 409:
                return _T("error", "error_privilege_not_enough");
            case 410:
                return _T("error", "conn_rv_fail");
            case 411:
                return _T("error", "error_fs_ro");
            case 412:
                return _T("error", "error_long_path");
            case 413:
                return _T("error", "error_encryption_long_path");
            case 414:
                return _T("error", "error_file_exist");
            case 415:
                return _T("error", "error_quota_not_enough");
            case 416:
                return _T("error", "error_space_not_enough");
            case 417:
                return _T("error", "error_io");
            case 418:
                return _T("error", "error_reserved_name");
            case 419:
                return _T("error", "error_fat_reserved_name");
            case 420:
                return _T("error", "error_error_system");
            case 421:
                return _T("error", "error_folder_busy");
            case 422:
                return _T("error", "not_support");
            case 423:
                return _T("error", "volume_no_volumes");
            case 424:
                return _T("error", "umount_fail");
            case 425:
                return _T("error", "disconnect_fail");
            case 426:
                return _T("error", "mount_iso_fail");
            case 427:
                return _T("property", "error_save_property");
            case 428:
                return _T("error", "error_mp_external");
            case 429:
                return _T("error", "error_mp_encshare");
            case 430:
                return _T("error", "error_mp_mp");
            case 431:
                return _T("error", "mount_fail_reach_limit");
            case 432:
                return _T("mount", "err_user_home");
            case 433:
                return _T("mount", "err_cloud_station");
            case 434:
                return _T("error", "error_mp_share");
            case 435:
                return _T("mount", "invalid_local_host");
            case 436:
                return _T("mount", "bad_remote_folder");
            case 437:
                return _T("mount", "error_mp_nfs");
            case 438:
                return _T("mount", "err_permission_denied");
            case 439:
                return _T("error", "mount_remote_fail_reach_limit");
            case 440:
                return _T("mount", "err_no_such_device");
            case 441:
                return _T("error", "mount_point_not_empty");
            case 442:
                return _T("error", "error_dest_no_path");
            case 443:
                return _T("error", "error_acl_volume_not_support");
            case 444:
                return _T("error", "error_fat_privilege");
            case 445:
                return _T("error", "error_remote_privilege");
            case 446:
                return _T("error", "error_no_shared_folder");
            case 447:
                return String.format(_T("acl_editor", "error_privilage_mode"), a.errno.arg);
            case 448:
                return _T("property", "error_invalid_domain_user");
            case 449:
                return _T("property", "error_invalid_domain_group");
            case 450:
                return _T("mount", "config_remote_warning");
            case 451:
                return _T("error", "nfs_conn_rv_fail");
            case 452:
                return _T("error", "error_share_quota_not_enough");
            case 453:
                return _T("error", "error_cifs_smb1_disabled");
            case 454:
                return _T("error", "error_c2share_quota_not_enough");
            case 599:
                return "";
            case 600:
                return _T("search", "no_search_cache");
            case 800:
                return String.format(_T("favorite", "same_favorite_path"), Ext.util.Format.htmlEncode(a.errors[0].path), Ext.util.Format.htmlEncode(a.errors[0].name));
            case 801:
                return String.format(_T("favorite", "same_favorite_name"), Ext.util.Format.htmlEncode(a.errors[0].name));
            case 802:
                return _T("favorite", "over_limit");
            case 900:
                return _T("error", "delete_error_rmdir");
            case 1004:
                return _T("error", "error_overwrite_fail");
            case 1005:
                return _T("error", "error_select_conflict");
            case 1006:
                return _T("error", "mvcp_filename_illegal");
            case 1007:
                return _T("error", "mvcp_file_too_big");
            case 1100:
                return _T("error", "error_error_system");
            case 1101:
                return _T("error", "error_too_many_folder");
            case 1200:
                return _T("error", "error_error_system");
            case 1300:
                return _T("error", "error_error_system");
            case 1301:
                return _T("compress", "compress_error_long_name");
            case 1400:
                return _T("error", "error_error_system");
            case 1401:
                return _T("error", "error_invalid_archive");
            case 1402:
                return _T("error", "error_invalid_archive_data");
            case 1403:
                return _T("error", "extract_passwd_missing");
            case 1404:
                return _T("error", "error_error_system");
            case 1405:
                return _T("error", "error_error_system");
            case 1800:
                return _T("upload", "upload_error_data");
            case 1801:
                return _T("upload", "upload_error_timeout");
            case 1802:
                return _T("upload", "upload_nofile");
            case 1803:
                return _T("connections", "kick_connection");
            case 1804:
                return _T("error", "mvcp_file_too_big");
            case 1805:
                return _T("error", "error_select_conflict");
            case 1806:
                return _T("error", "upload_add_vfs_queue");
            case 1807:
                return _T("error", "error_io");
            case 1808:
                return _T("error", "upload_zero_size_file_error");
            case 1809:
                return _T("error", "error_file_exist");
            case 1810:
                return _T("upload", "upload_nofile");
            case 1811:
                return _T("error", "error_no_path");
            case 1812:
                return _T("upload", "upload_exceed_maximum_filesize");
            case 1813:
                return _T("extract", "extract_file_exist");
            case 1900:
                return _T("error", "download_add_vfs_queue");
            case 2001:
                return _T("error", "over_account_limit");
            case 2002:
                return _T("error", "unknown_db_error");
            case 2100:
                return _T("error", "vfs_no_such_server");
            case 2101:
                return _T("error", "vfs_duplicated_connection");
            case 2102:
                return _T("error", "vfs_authentication_failed");
            case 2103:
                return _T("error", "vfs_host_unreachable");
            case 2104:
                return _T("error", "vfs_connection_refused");
            case 2105:
                return _T("error", "vfs_read_config_failed");
            case 2106:
                return _T("error", "vfs_write_config_failed");
            case 2107:
                return _T("error", "vfs_wrong_fingerprint");
            case 2108:
                return _T("error", "vfs_identity_wrong");
            case 2109:
                return _T("error", "vfs_conn_rv_fail");
            case 2110:
                return _T("error", "vfs_reach_max_server_per_protocol");
            case 2111:
                return _T("error", "vfs_proxy_authentication_failed");
            case 2112:
                return _T("error", "vfs_err_ca_wrong");
            case 2113:
                return _T("error", "vfs_duplicated_profile");
            case 2114:
                return _T("error", "vfs_root_ioerror");
            case 2115:
                return _T("error", "vfs_token_expired");
            case 2116:
                return _T("error", "vfs_filesize_too_large");
            case 2117:
                return _T("ddsm", "unsupport_on_non_privileged_mode");
            case 2119:
                return _T("error", "mvcp_filename_illegal");
            default:
                return _T("error", "error_error_system")
        }
    }
});
angular.createNameSpace("SYNO.webfm.utils");
angular.apply(SYNO.webfm.utils, {
    icon_type: ["acc", "ai", "avi", "bmp", "doc", "exe", "fla", "folder", "gif", "htm", "indd", "iso", "jpg", "js", "misc", "mp3", "pdf", "png", "ppt", "psd", "rar", "swf", "tar", "ttf", "txt", "wma", "xls", "ico", "tif", "tiff", "ufo", "raw", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "jpe", "jpeg", "html", "3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "m4v", "mkv", "mp4", "mts", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "aac", "flac", "m4a", "m4b", "aif", "ogg", "pcm", "wav", "cda", "mid", "mp2", "mka", "mpc", "ape", "ra", "ac3", "dts", "bin", "img", "mds", "nrg", "daa", "docx", "wri", "rtf", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw", "xlsx", "xlsm", "xlsb", "xltm", "xlam", "pptx", "pps", "ppsx", "ade", "adp", "adn", "accdr", "accdb", "accdt", "mdb", "mda", "mdn", "mdt", "mdw", "mdf", "mde", "accde", "mam", "maq", "mar", "mat", "maf", "flv", "f4v", "7z", "bz2", "gz", "zip", "tgz", "tbz", "ttc", "otf", "css", "actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "bkpi", "c", "cc", "php", "jsx", "xml", "xhtml", "mhtml", "cpp", "cs", "cxx"],
    archive_type: ["zip", "gz", "tar", "tgz", "tbz", "bz2", "rar", "7z", "iso"],
    image_type: ["iso"],
    DocumentFileTypes: "docx,wri,rtf,xla,xlb,xlc,xld,xlk,xll,xlm,xlt,xlv,xlw,xlsx,xlsm,xlsb,xltm,xlam,pptx,pps,ppsx,pdf,txt,doc,xls,ppt,odt,ods,odp,odg,odc,odf,odb,odi,odm,ott,ots,otp,otg,otc,otf,oti,oth,potx,pptm,ppsm,potm,dotx,dot,pot,ppa,xltx,docm,dotm",
    ImageFileTypes: "ico,tif,tiff,ufo,raw,arw,srf,sr2,dcr,k25,kdc,cr2,crw,nef,mrw,ptx,pef,raf,3fr,erf,mef,mos,orf,rw2,dng,x3f,jpg,jpg,jpeg,png,gif,bmp,psd",
    VideoFileTypes: "3gp,3g2,asf,dat,divx,dvr-ms,m2t,m2ts,m4v,mkv,mp4,mts,mov,qt,tp,trp,ts,vob,wmv,xvid,ac3,amr,rm,rmvb,ifo,mpeg,mpg,mpe,m1v,m2v,mpeg1,mpeg2,mpeg4,ogv,webm,flv,avi,swf,f4v",
    AudioFileTypes: "aac,flac,m4a,m4b,aif,ogg,pcm,wav,cda,mid,mp2,mka,mpc,ape,ra,ac3,dts,wma,mp3,mp1,mp2,mpa,ram,m4p,aiff,dsf,dff",
    WebPageFileTypes: "html,htm,css,actproj,ad,akp,applescript,as,asax,asc,ascx,asm,asmx,asp,aspx,asr,c,cc,php,jsx,xml,xhtml,mhtml,cpp,cs,cxx,js",
    DiscFileTypes: "bin,img,mds,nrg,daa,iso",
    ZippedFileTypes: "7z,bz2,gz,zip,tgz,tbz,rar,tar",
    getFileExtIcon: function(a, b, e) {
        var d = "misc",
            c = (a) ? a.substr(a.lastIndexOf(".") + 1).toLowerCase() : undefined;
        b = (e) ? b * 2 : b;
        if (-1 !== SYNO.webfm.utils.icon_type.indexOf(c)) {
            d = c
        }
        return String.format("../webman/modules/FileBrowser/images/{0}/files_ext_{1}/{2}.png", e ? "2x" : "1x", b, d)
    }
});
angular.module("starter.sharing", ["WebAPIService", "Initialization"]).config(["$stateProvider", "$urlRouterProvider", function(c, a) {
    var b = "webman/3rdparty/FileBrowser/mobile_ui/file_sharing/";
    c.state("file_download", {
        params: {
            url: ""
        },
        views: {
            sharingContent: {
                templateUrl: "sharing/mobile_ui/view/three_part_pane.html",
                controller: "DownloadCtrl"
            },
            "middleView@file_download": {
                templateUrl: b + "view/file_download.html"
            }
        }
    }).state("file_sharing_error", {
        views: {
            sharingContent: {
                templateUrl: "sharing/mobile_ui/view/three_part_pane.html",
                controller: "DownloadCtrl"
            },
            "middleView@file_sharing_error": {
                templateUrl: b + "view/error.html"
            }
        }
    }).state("syno_sds_app_filestation3_instance", {
        views: {
            sharingContent: {
                controller: "FileStationCtrl"
            }
        },
        params: {
            app: null,
            auto_gc: null,
            enable_match_ip: true,
            enabled: true,
            expire_at: "",
            expire_times: 0,
            hash: "",
            owner_user: "",
            project_name: "",
            protect_groups: [],
            protect_title: "",
            protect_type: "",
            protect_users: "",
            redirect_type: "",
            redirect_uri: "",
            start_at: "",
            use_count: 0
        }
    })
}]).run(["$rootScope", "$state", function(a, b) {
    a.$on("initdata", function(d, c) {
        d.preventDefault();
        b.go("syno_sds_app_filestation3_instance", c.Sharing)
    })
}]).controller("FileStationCtrl", ["$scope", "$state", "$stateParams", "$ionicHistory", function(b, d, e, f) {
    var a = e,
        c = String.format("../fsdownload/{0}/{1}", _S("sharing_id"), window.encodeURIComponent(SYNO.SDS.ExtraSession.filename));
    f.nextViewOptions({
        disableAnimate: true,
        disableBack: true
    });
    if (SYNO.SDS.ExtraSession.status !== 0) {
        d.go("file_sharing_error");
        return
    }
    if (a.app.is_folder) {
        window.location.href = c
    } else {
        d.go("file_download", {
            url: c
        })
    }
}]).controller("DownloadCtrl", ["$scope", "$state", "$stateParams", "Init", function(k, a, h, d) {
    var f = SYNO.SDS.ExtraSession,
        g = angular.element(document.getElementsByClassName("syno-mobile-wrapper")),
        c = "#3a83cc",
        i = "../scripts/ext-3/resources/images/default/s.gif",
        b = f.enable_custom_setting && f.status === 0,
        j = b && f.enable_background,
        e = {
            bg_path: (j) ? f.background_path : i,
            bg_color: (j) ? f.background_color : c,
            bg_pos: (j) ? f.background_position : "center",
            tpl_type: (b) ? f.tpl_type : "dark"
        };
    if (f.status === 0) {
        angular.apply(k, {
            file_info: {
                filename: f.filename || "file name",
                ext_path: SYNO.webfm.utils.getFileExtIcon(f.filename, 128, d.getRetinaStatus())
            },
            download_text: _T("filetable", "filetable_download"),
            bg_info: e,
            Download: function() {
                window.location.href = h.url
            }
        })
    } else {
        angular.apply(k, {
            bg_info: e,
            file_info: {
                error_msg: _T("sharing", "unavailable_file")
            }
        })
    }
    g.addClass(k.bg_info.bg_pos)
}]);