/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}
Ext.define("SYNO.SDS.DeployJava", {
    extend: "Object",
    debug: null,
    firefoxJavaVersion: null,
    myInterval: null,
    preInstallJREList: null,
    returnPage: null,
    brand: null,
    locale: null,
    installType: null,
    EAInstallEnabled: !1,
    EarlyAccessURL: null,
    getJavaURL: "http://java.com",
    oldMimeType: "application/npruntime-scriptable-plugin;DeploymentToolkit",
    mimeType: "application/java-deployment-toolkit",
    browserName: null,
    browserName2: null,
    getJREs: function() {
        var e, t, i, r, n = [];
        if (this.isPluginInstalled())
            for (e = this.getPlugin(), t = e.jvms, i = 0; i < t.getLength(); i++) n[i] = t.get(i).version;
        else r = this.getBrowser(), "MSIE" == r ? this.testUsingActiveX("1.7.0") ? n[0] = "1.7.0" : this.testUsingActiveX("1.6.0") ? n[0] = "1.6.0" : this.testUsingActiveX("1.5.0") ? n[0] = "1.5.0" : this.testUsingActiveX("1.4.2") ? n[0] = "1.4.2" : this.testForMSVM() && (n[0] = "1.1") : "Netscape Family" == r && (this.getJPIVersionUsingMimeType(), null != this.firefoxJavaVersion ? n[0] = this.firefoxJavaVersion : this.testUsingMimeTypes("1.7") ? n[0] = "1.7.0" : this.testUsingMimeTypes("1.6") ? n[0] = "1.6.0" : this.testUsingMimeTypes("1.5") ? n[0] = "1.5.0" : this.testUsingMimeTypes("1.4.2") ? n[0] = "1.4.2" : "Safari" == this.browserName2 ? this.testUsingPluginsArray("1.7.0") ? n[0] = "1.7.0" : this.testUsingPluginsArray("1.6") ? n[0] = "1.6.0" : this.testUsingPluginsArray("1.5") ? n[0] = "1.5.0" : this.testUsingPluginsArray("1.4.2") && (n[0] = "1.4.2") : "Opera" == this.browserName2 && this.testOperaUsingMimeTypes() && (n[0] = "0"));
        if (this.debug)
            for (i = 0; i < n.length; ++i) alert("We claim to have detected Java SE " + n[i]);
        return n
    },
    installJRE: function(e) {
        return this.isPluginInstalled() ? !!this.getPlugin().installJRE(e) && (this.refresh(), null != this.returnPage && (document.location = this.returnPage), !0) : this.installLatestJRE()
    },
    installLatestJRE: function() {
        var e, t;
        return this.isPluginInstalled() ? !!this.getPlugin().installLatestJRE() && (this.refresh(), null != this.returnPage && (document.location = this.returnPage), !0) : (e = this.getBrowser(), t = navigator.platform.toLowerCase(), "true" == this.EAInstallEnabled && -1 != t.indexOf("win") && null != this.EarlyAccessURL ? (this.preInstallJREList = this.getJREs(), null != this.returnPage && (this.myInterval = setInterval("this.poll();", 3e3)), location.href = this.EarlyAccessURL, !1) : "MSIE" == e ? this.IEInstall() : "Netscape Family" == e && -1 != t.indexOf("win32") ? this.FFInstall() : (location.href = this.getJavaURL + (null != this.returnPage ? "&returnPage=" + this.returnPage : "") + (null != this.locale ? "&locale=" + this.locale : "") + (null != this.brand ? "&brand=" + this.brand : ""), !1))
    },
    runApplet: function(e, t, i) {
        "undefined" != i && null != i || (i = "1.1");
        var r = /(\d+)(?:\.(\d+)(?:\.(\d+)(?:_(\d+))?)?)?/,
            n = r.exec(i);
        null == this.returnPage && (this.returnPage = document.location);
        var a;
        null != n ? (a = this.getBrowser(), "?" != a && "Safari" != this.browserName2 ? this.versionCheck(i + "+") ? this.writeAppletTag(e, t) : this.installJRE(i + "+") && (this.refresh(), location.href = document.location, this.writeAppletTag(e, t)) : this.writeAppletTag(e, t)) : this.debug && alert("Invalid minimumVersion argument to runApplet():" + i)
    },
    writeAppletTag: function(e, t) {
        var i = "<applet ",
            r = "",
            n = !0;
        for (var a in e) e.hasOwnProperty(a) && (i += " " + a + '="' + e[a] + '"', "code" != a && "java_code" != a || (n = !1));
        if ("undefined" != t && null != t) {
            var s = !1;
            for (var o in t) t.hasOwnProperty(o) && ("codebase_lookup" == o && (s = !0), "object" != o && "java_object" != o || (n = !1), r += '<param name="' + o + '" value="' + t[o] + '"/>', s || (r += '<param name="codebase_lookup" value="false"/>'))
        }
        n && (i += ' code="dummy"'), i += ">", this.documentWrite(i + "\n" + r + "\n</applet>")
    },
    versionCheck: function(e) {
        var t, i, r, n, a = 0,
            s = /(\d+)(?:\.(\d+)(?:\.(\d+)(?:_(\d+))?)?)?(\*|\+)?$/,
            o = s.exec(e);
        if (null != o) {
            for (r = !0, n = [], i = 1; i < o.length; ++i) "string" == typeof o[i] && "" != o[i] && (n[a] = o[i], a++);
            if ("+" == n[n.length - 1] ? (r = !1, n.length--) : "*" == n[n.length - 1] && n.length--, t = this.getJREs(), "0" == t[0]) return !0;
            for (i = 0; i < t.length; ++i)
                if (this.compareVersionToPattern(t[i], n, r)) return !0;
            return !1
        }
        return alert("Invalid versionPattern passed to versionCheck: " + e), !1
    },
    getJPIVersionUsingMimeType: function() {
        var e, t, i, r;
        for (e = 0; e < navigator.mimeTypes.length; ++e)
            if (t = navigator.mimeTypes[e].type, r = /application\/x-java-applet;jpi-version=(.*)/, null != (i = r.exec(t))) {
                this.firefoxJavaVersion = i[1];
                break
            }
    },
    isPluginInstalled: function() {
        var e = this.getPlugin();
        return !(!e || !e.jvms)
    },
    allowPlugin: function() {
        return this.getBrowser(), "Safari" != this.browserName2 && "Opera" != this.browserName2
    },
    getPlugin: function() {
        this.refresh();
        var e = null;
        return this.allowPlugin() && (e = document.getElementById("deployJavaPlugin")), e
    },
    compareVersionToPattern: function(e, t, i) {
        var r, n, a, s, o = /(\d+)(?:\.(\d+)(?:\.(\d+)(?:_(\d+))?)?)?/,
            l = o.exec(e);
        if (null != l) {
            for (a = 0, s = [], r = 1; r < l.length; ++r) "string" == typeof l[r] && "" != l[r] && (s[a] = l[r], a++);
            if (n = Math.min(s.length, t.length), i) {
                for (r = 0; r < n; ++r)
                    if (s[r] != t[r]) return !1;
                return !0
            }
            for (r = 0; r < n; ++r) {
                if (s[r] < t[r]) return !1;
                if (s[r] > t[r]) return !0
            }
            return !0
        }
        return !1
    },
    getBrowser: function() {
        var e;
        return null == this.browserName && (e = navigator.userAgent.toLowerCase(), this.debug && alert("userAgent -> " + e), Ext.isIE11 || Ext.isIE ? (this.browserName = "MSIE", this.browserName2 = "MSIE") : -1 != e.indexOf("firefox") ? (this.browserName = "Netscape Family", this.browserName2 = "Firefox") : -1 != e.indexOf("chrome") ? (this.browserName = "Netscape Family", this.browserName2 = "Chrome") : -1 != e.indexOf("safari") ? (this.browserName = "Netscape Family", this.browserName2 = "Safari") : -1 != e.indexOf("mozilla") ? (this.browserName = "Netscape Family", this.browserName2 = "Other") : -1 != e.indexOf("opera") ? (this.browserName = "Netscape Family", this.browserName2 = "Opera") : (this.browserName = "?", this.browserName2 = "unknown"), this.debug && alert("Detected browser name:" + this.browserName + ", " + this.browserName2)), this.browserName
    },
    testUsingActiveX: function(e) {
        var t = "JavaWebStart.isInstalled." + e + ".0";
        if (!ActiveXObject) return this.debug && alert("Browser claims to be IE, but no ActiveXObject object?"), !1;
        try {
            return null != new ActiveXObject(t)
        } catch (e) {
            return !1
        }
    },
    testForMSVM: function() {
        var e;
        return "undefined" != typeof oClientCaps && ("" != (e = oClientCaps.getComponentVersion("{08B0E5C0-4FCB-11CF-AAA5-00401C608500}", "ComponentID")) && "5,0,5000,0" != e)
    },
    testUsingMimeTypes: function(e) {
        if (!navigator.mimeTypes) return this.debug && alert("Browser claims to be Netscape family, but no mimeTypes[] array?"), !1;
        var t, i, r, n;
        for (t = 0; t < navigator.mimeTypes.length; ++t)
            if (r = navigator.mimeTypes[t].type, n = /application\/x-java-applet\x3Bversion=(1\.8|1\.7|1\.6|1\.5|1\.4\.2)/, null != (i = n.exec(r)) && this.compareVersions(i[1], e)) return !0;
        return !1
    },
    testOperaUsingMimeTypes: function() {
        if (!navigator.mimeTypes) return this.debug && alert("Browser claims to be Netscape family, but no mimeTypes[] array?"), !1;
        var e, t;
        for (e = 0; e < navigator.mimeTypes.length; ++e)
            if (t = navigator.mimeTypes[e].type, -1 != t.indexOf("application/x-java-")) return !0;
        return !1
    },
    testUsingPluginsArray: function(e) {
        if (!navigator.plugins || !navigator.plugins.length) return !1;
        for (var t = navigator.platform.toLowerCase(), i = 0; i < navigator.plugins.length; ++i) {
            var r = navigator.plugins[i].description;
            if (-1 != r.search(/^Java Switchable Plug-in (Cocoa)/)) {
                if (this.compareVersions("1.5.0", e)) return !0
            } else if (-1 != r.search("Java") && -1 != t.indexOf("win") && (this.compareVersions("1.5.0", e) || this.compareVersions("1.6.0", e))) return !0
        }
        return !!this.compareVersions("1.5.0", e)
    },
    IEInstall: function() {
        return location.href = this.getJavaURL + (null != this.returnPage ? "&returnPage=" + this.returnPage : "") + (null != this.locale ? "&locale=" + this.locale : "") + (null != this.brand ? "&brand=" + this.brand : "") + (null != this.installType ? "&type=" + this.installType : ""), !1
    },
    done: function(e, t) {},
    FFInstall: function() {
        return location.href = this.getJavaURL + (null != this.returnPage ? "&returnPage=" + this.returnPage : "") + (null != this.locale ? "&locale=" + this.locale : "") + (null != this.brand ? "&brand=" + this.brand : "") + (null != this.installType ? "&type=" + this.installType : ""), !1
    },
    compareVersions: function(e, t) {
        var i, r = e.split("."),
            n = t.split(".");
        for (i = 0; i < r.length; ++i) r[i] = Number(r[i]);
        for (i = 0; i < n.length; ++i) n[i] = Number(n[i]);
        return 2 == r.length && (r[2] = 0), r[0] > n[0] || !(r[0] < n[0]) && (r[1] > n[1] || !(r[1] < n[1]) && (r[2] > n[2] || !(r[2] < n[2])))
    },
    enableAlerts: function() {
        this.browserName = null, this.debug = !0
    },
    poll: function() {
        this.refresh();
        var e = this.getJREs();
        0 == this.preInstallJREList.length && 0 != e.length && (clearInterval(this.myInterval), null != this.returnPage && (location.href = this.returnPage)), 0 != this.preInstallJREList.length && 0 != e.length && this.preInstallJREList[0] != e[0] && (clearInterval(this.myInterval), null != this.returnPage && (location.href = this.returnPage))
    },
    writePluginTag: function() {
        var e = this.getBrowser();
        "MSIE" == e ? this.documentWrite('<object classid="clsid:CAFEEFAC-DEC7-0000-0000-ABCDEFFEDCBA" id="deployJavaPlugin" width="0" height="0"></object>') : "Netscape Family" == e && this.allowPlugin() && this.writeEmbedTag()
    },
    refresh: function() {
        (navigator.plugins.refresh(!1), "Netscape Family" == this.getBrowser() && this.allowPlugin()) && (null == document.getElementById("deployJavaPlugin") && this.writeEmbedTag())
    },
    writeEmbedTag: function() {
        var e, t = !1;
        if (null != navigator.mimeTypes) {
            for (e = 0; e < navigator.mimeTypes.length; e++) navigator.mimeTypes[e].type == this.mimeType && navigator.mimeTypes[e].enabledPlugin && (this.documentWrite('<embed id="deployJavaPlugin" type="' + this.mimeType + '" style="display: none" />'), t = !0);
            if (!t)
                for (e = 0; e < navigator.mimeTypes.length; e++) navigator.mimeTypes[e].type == this.oldMimeType && navigator.mimeTypes[e].enabledPlugin && this.documentWrite('<embed id="deployJavaPlugin" type="' + this.oldMimeType + '" style="display: none" />')
        }
    },
    do_initialize: function() {
        this.writePluginTag();
        var e;
        if (null == this.locale) {
            if (null == (e = null)) try {
                e = navigator.userLanguage
            } catch (e) {}
            if (null == e) try {
                e = navigator.systemLanguage
            } catch (e) {}
            if (null == e) try {
                e = navigator.language
            } catch (e) {}
            null != e && (e.replace("-", "_"), this.locale = e)
        }
    },
    documentWrite: function(e) {
        Ext.DomHelper.createTemplate(e).append(document.body)
    }
}), window.deployJava = new SYNO.SDS.DeployJava;
var AppletProgram = {};
Ext.apply(AppletProgram, {
    appletID: "applet",
    classname: "main/AppletHandler.class",
    blJava: !1,
    blJavaPermission: 0,
    blSetJavaPermission: 0,
    JavaVersion: "1.5",
    blSet: !1,
    setJava: function(e) {
        this.blSet || (this.blSet = !0, !0 === this.checkJava() && this.runJava(e, this.JavaVersion))
    },
    checkJava: function() {
        return this.blJava ? this.blJava : (Ext.isChrome || Ext.isOpera || Ext.isSafari && Ext.isWindows ? this.blJava = !1 : (deployJava.do_initialize(), this.blJava = this.checkVersion(this.JavaVersion)), this.blJava)
    },
    setJavaPermission: function(e) {
        e ? this.blSetJavaPermission = 1 : (this.blJavaPermission = -1, this.blSetJavaPermission = -1)
    },
    updateFileStation: function(e) {
        !0 === this.checkJava(this.JavaVersion) && this.updateFileStationDefer(e)
    },
    isMatchVerion: function() {
        try {
            var e = document.getElementById(this.appletID).getVersion(),
                t = e.split("-", 2);
            t[1] = t[1] || "s0", t[1] = parseInt(t[1].replace("s", ""), 10);
            var i = (_S("fullversion") || _S("version")).split("-", 2);
            return i[1] = i[1] || "s0", i[1] = parseInt(i[1].replace("s", ""), 10), parseInt(i[0], 10) >= parseInt(t[0], 10) && i[1] >= t[1]
        } catch (e) {
            return !1
        }
    },
    updateFileStationDefer: function(e) {
        this.updateDeferTime && (this.updateStartTime && 500 < (new Date).getTime() - this.updateStartTime && (this.updateDeferTime = (new Date).getTime()), !this.blJavaMsgShown && 2e4 < (new Date).getTime() - this.updateDeferTime && (this.setJavaPermission(!1), this.blJavaMsgShown = !0)), 0 !== this.blSetJavaPermission && this.isRunning() ? (this.blJavaPermission = 1, this.blMatchVersion = this.isMatchVerion(), e.updateLocalEnv.call(e, this.blJavaPermission), e.getDownloadInstance().on("cancel", function(e) {
            AppletProgram.action({
                action: "canceldownload",
                id: e
            })
        }, this)) : (this.updateDeferTime || (this.updateDeferTime = (new Date).getTime()), this.updateStartTime = (new Date).getTime(), this.updateFileStationDefer.createDelegate(this, [e]).defer(100))
    },
    checkVersion: function(e) {
        return deployJava.versionCheck(e + "+")
    },
    runJava: function(e, t) {
        var i = SYNO.SDS.Utils.getPunyBaseURL(),
            r = "sFILEAPP.jar";
        deployJava.versionCheck("1.7.0_45+") && (r = "sFILEAPP2.jar");
        var n = {
                id: this.appletID,
                code: this.classname,
                archive: i + e + r + "?v=" + _S("fullversion"),
                width: 1,
                height: 1,
                MAYSCRIPT: "true",
                style: "position: absolute; left: -10000px;"
            },
            a = {
                host: i,
                baseURL: i + e,
                token: _S("SynoToken") || ""
            };
        this.updateStartTime = (new Date).getTime(), deployJava.runApplet(n, a, t)
    },
    isDefined: function(e) {
        return Ext.isDefined(_typeof(e))
    },
    isRunning: function() {
        try {
            if (this.isDefined(document.getElementById(this.appletID))) {
                if (Ext.isIE || Ext.isModernIE) return document.getElementById(this.appletID).isRunning();
                if (document.getElementById(this.appletID).isRunning) return document.getElementById(this.appletID).isRunning()
            }
            return !1
        } catch (e) {
            return !1
        }
    },
    action: function(e) {
        var t = !1,
            i = null;
        try {
            this.blMatchVersion && (i = document.getElementById(this.appletID).action(Ext.util.JSON.encode(e)), i = i ? Ext.util.JSON.decode(i) : null, t = !0)
        } catch (e) {
            t = !1
        }
        return t || SYNO.SDS.Desktop.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _T("java", "prompt_reopen")), i
    },
    checkResponse: function(e, t) {
        if (this.blMatchVersion) {
            var i = _T("tree", "leaf_filebrowser");
            if (!e) return t && t.owner.getMsgBox().alert(i, _WFT("common", "error_system")), !1;
            if (e.errno && e.errno.section && e.errno.key) {
                if (SYNO.webfm.utils.checkIfNeedRedirect(e.errno.section, e.errno.key, !1)) return !1;
                t && t.owner.getMsgBox().alert(i, _WFT(e.errno.section, e.errno.key))
            }
            return !0
        }
    },
    getUserPath: function(e, t) {
        var i = this.action(e);
        return this.checkResponse(i, t) ? i.userpath : null
    },
    getHostName: function(e, t) {
        var i = this.action(e);
        return this.checkResponse(i, t) ? i.hostname : ""
    },
    getDiskInfo: function(e, t) {
        var i = this.action(e);
        if (this.checkResponse(i, t)) return i
    },
    showFileDialog: function(e, t) {
        this.webfm = e, document.getElementById(this.appletID).showFileDialog(Ext.util.JSON.encode(t)), SYNO.SDS.Desktop && (SYNO.SDS.Desktop.getEl().mask(), SYNO.SDS.TaskBar && SYNO.SDS.TaskBar.getEl().mask())
    },
    uploadFile: function(e, t) {
        (function() {
            (t || this.webfm).FileAction.directlyUpload(e.remoteDir, e.files, e.blOverwrite)
        }).createDelegate(this).defer(50)
    },
    onSelectDest: function(e, t) {
        (function() {
            var i = t || this.webfm;
            if (e) switch (e.action) {
                case "copy":
                case "move":
                    i.FileAction.onJavaMVCP(e.action, e.remoteDir, e.files, e.blOverwrite);
                    break;
                default:
                    i.FileAction.onJavaDownload("copy", e.remoteDir, e.files, e.blOverwrite)
            }
        }).createDelegate(this).defer(50)
    },
    onSelectError: function(e, t) {
        (function() {
            var i = t || this.webfm,
                r = String.format(_WFT("upload", "upload_error_add"), e.files.join(", "));
            i.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), r)
        }).createDelegate(this).defer(50)
    },
    onSelectComplete: function() {
        (function() {
            SYNO.SDS.Desktop && (SYNO.SDS.Desktop.getEl().unmask(), SYNO.SDS.TaskBar && SYNO.SDS.TaskBar.getEl().unmask())
        }).createDelegate(this).defer(50)
    }
}), AppletProgram.DropPanel = Ext.extend(Object, {
    classname: "main/AppletDropPanel.class",
    constructor: function(e) {
        this.webfm = e, this.runJava(e.RELURL)
    },
    getRandomNumber: function() {
        for (var e, t = (new Date).getTime(), i = t; i > 0; i--) {
            e = t.toString() + Math.floor(65535 * Math.random()).toString();
            if (!Ext.getClassByName("AppletProgram.DropPanelInstance_" + e)) return e
        }
    },
    runJava: function(e) {
        if (1 === AppletProgram.blJavaPermission) {
            var t = "applet_" + this.getRandomNumber();
            this.appletID = t, AppletProgram["DropPanelInstance_" + t] = this;
            var i = "sFILEAPP.jar";
            deployJava.versionCheck("1.7.0_45+") && (i = "sFILEAPP2.jar");
            var r = SYNO.SDS.Utils.getPunyBaseURL(),
                n = {
                    id: t,
                    code: this.classname,
                    archive: r + e + i + "?v=" + _S("fullversion"),
                    MAYSCRIPT: "true",
                    style: "position:absolute;z-index:8999;left:-100000px;top:0px;zoom:1;"
                },
                a = {
                    appletid: t,
                    lang: _S("lang")
                };
            deployJava.runApplet(n, a, AppletProgram.JavaVersion)
        }
    },
    showDropPanel: function() {
        var e = this.webfm.viewPanel.getEl();
        if (1 === AppletProgram.blJavaPermission && !e.isMasked()) {
            if (!this.el) {
                this.el = Ext.get(this.appletID);
                e.appendChild(this.el), this.el.setSize("100%", "100%"), this.el.setLeftTop(0, 0), this.el.enableDisplayMode()
            }
            this.el.show()
        }
    },
    hideDropPanel: function() {
        1 === AppletProgram.blJavaPermission && this.el && this.el.hide()
    },
    onSelectError: function(e) {
        (function() {
            this.webfm.el.unmask(), AppletProgram.onSelectError(e, this.webfm)
        }).createDelegate(this).defer(50)
    },
    onDropError: function(e) {
        (function() {
            this.webfm.el.unmask();
            var t = _WFT("error", "error_system_busy");
            e.errno && (t = _WFT(e.errno.section, e.errno.key)), this.webfm.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), t)
        }).createDelegate(this).defer(50)
    },
    onDropFiles: function(e) {
        (function() {
            this.hideDropPanel(), this.webfm.owner.el.unmask();
            var t = !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enableautooverwrite");
            if (!this.webfm.onCheckVFSAction("upload", null, this.webfm.getUploadPath())) return this.webfm.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "not_support")), !1;
            if (!this.webfm.onCheckPrivilege("upload", null, !1, !1)) return this.webfm.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough")), !1;
            var i = new SYNO.FileStation.DropConfirmDialog({
                owner: this.webfm.owner
            }, {
                cb: {
                    fn: function(t, i) {
                        AppletProgram.uploadFile(Ext.apply(e, {
                            remoteDir: this.webfm.getCurrentDir(),
                            blOverwrite: i.overwrite
                        }), this.webfm)
                    },
                    scope: this,
                    files: e.files
                },
                filenames: e.files
            });
            t ? i.upload(t) : i.show(), this.processing = !1
        }).createDelegate(this).defer(50)
    },
    onDropStart: function() {
        this.processing = !0,
            function() {
                this.webfm.owner.el.isMasked() || this.webfm.owner.el.mask(_WFT("common", "loading"), "x-mask-loading")
            }.createDelegate(this).defer(50)
    },
    onDestroy: function() {},
    onDragOver: function() {
        this.webfm.viewPanel.html5cfg.html5uploader.dragstarttime = (new Date).getTime(), this.showDropPanel()
    }
}), AppletProxy = function(e) {
    function t(t) {
        return e.apply(this, arguments)
    }
    return t.toString = function() {
        return e.toString()
    }, t
}(function(e) {
    var t = {};
    t[Ext.data.Api.actions.read] = !0, AppletProxy.superclass.constructor.call(this, {
        api: t
    }), this.webfm = e
}), Ext.extend(AppletProxy, Ext.data.DataProxy, {
    doRequest: function(e, t, i, r, n, a, s) {
        i = i || {},
            function() {
                var t;
                try {
                    var o = AppletProgram.action(i);
                    if (!o) {
                        var l = _T("tree", "leaf_filebrowser");
                        return void this.webfm.owner.getMsgBox().alert(l, _WFT("common", "error_system"))
                    }
                    if (o.errno) return void this.fireEvent("exception", this, "response", e, s, o, null);
                    t = r.readRecords(o)
                } catch (t) {
                    return this.fireEvent("exception", this, "response", e, s, o, t), void n.call(a, null, s, !1)
                }
                n.call(a, t, s, !0)
            }.defer(10, this)
    }
}), AppletTreeLoader = function(e) {
    function t(t, i) {
        return e.apply(this, arguments)
    }
    return t.toString = function() {
        return e.toString()
    }, t
}(function(e, t) {
    this.params = e, this.webfm = t, AppletTreeLoader.superclass.constructor.call(this)
}), Ext.extend(AppletTreeLoader, Ext.tree.TreeLoader, {
    load: function(e, t) {
        if (this.clearOnLoad)
            for (; e.firstChild;) e.removeChild(e.firstChild);
        this.Appletload(e) && "function" == typeof t && t()
    },
    Appletload: function(e) {
        try {
            var t = {
                node: "fm_local_root" === e.id ? "fm_local_root" : e.attributes.path,
                isHome: "localh" === e.attributes.type
            };
            Ext.apply(t, this.params);
            var i = AppletProgram.action(t);
            if (AppletProgram.checkResponse(i, this.webfm)) {
                e.beginUpdate();
                for (var r = 0, n = i.length; r < n; r++) {
                    var a = this["fm_local_root" === e.id && "localh" !== i[r].type ? "createDiskNode" : "createNode"](i[r]);
                    a && e.appendChild(a)
                }
                return e.endUpdate(), !0
            }
            return !1
        } catch (e) {
            return this.webfm.owner.getMsgBox().alert(_T("tree", "leaf_filebrowser"), _WFT("common", "error_system")), !1
        }
    },
    createDiskNode: function(e) {
        var t = AppletProgram.getDiskInfo({
            action: "getfs",
            cwd: e.path
        }, this);
        return t && t.free && t.total && (e.freeSpace = t.free, e.totalSpace = t.total, SYNO.webfm.utils.setSpaceTooltip(e)), Ext.tree.TreeLoader.prototype.createNode.call(this, e)
    }
});