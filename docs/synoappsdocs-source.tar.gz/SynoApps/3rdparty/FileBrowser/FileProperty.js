/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.FileStation"), Ext.define("SYNO.SDS.Snapshot.SnapshotGrid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.createStore(e);
        var t = [{
                header: _T("time", "time_time"),
                dataIndex: "time",
                id: "time",
                width: 150,
                renderer: SYNO.webfm.utils.snapshotTimeRenderer
            }, {
                header: _WFT("common", "desc"),
                dataIndex: "desc",
                id: "desc",
                width: 250
            }],
            i = Ext.apply({
                title: _T("filebrowser", "snapshot"),
                layout: "fit",
                store: this.store,
                width: 700,
                autoExpandColumn: "desc",
                tbar: [{
                    itemId: "browse-btn",
                    xtype: "syno_button",
                    text: _WFT("mount", "browse"),
                    handler: this.onBrowseBtnClick,
                    disabled: !0,
                    scope: this
                }],
                colModel: new Ext.grid.ColumnModel({
                    defaultSortable: !0,
                    defaults: {
                        align: "center"
                    },
                    columns: t
                }),
                selModel: new Ext.grid.RowSelectionModel({
                    singleSelect: !0,
                    listeners: {
                        selectionchange: this.onSelectedChange,
                        scope: this
                    }
                })
            }, e);
        this.callParent([i]), this.store.load({
            path: i.path
        })
    },
    createStore: function(e) {
        this.store = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.FileStation.Snapshot",
                method: "list",
                version: 2
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                id: "time"
            }, [{
                name: "time"
            }, {
                name: "desc"
            }]),
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            baseParams: {
                path: e.path,
                real_path: e.real_path
            }
        })
    },
    onSelectedChange: function(e) {
        var t = e.getSelections();
        this.getTopToolbar().getComponent("browse-btn").setDisabled(1 !== t.length)
    },
    onBrowseBtnClick: function() {
        var e, t = this.getSelectionModel().getSelections(),
            i = this.owner,
            s = i.owner.panelObj;
        1 === t.length && (e = this.path + "/#snapshot/" + t[0].get("time"), i.checkModified() ? i.getMsgBox().confirm(_WFT("filetable", "filetable_properties"), _WFT("common", "confirm_lostchange"), function(t) {
            "yes" == t && (s.onGoToFolder(e), i.close())
        }, this) : (s.onGoToFolder(e), i.close()))
    }
}), Ext.define("SYNO.FileStation.PropertyDialog", {
    extend: "SYNO.SDS.Share.PermissionDialog",
    tabs: null,
    gTargetFiles: null,
    gDirPaths: null,
    constructor: function(e) {
        this.owner = e.owner;
        var t = Ext.applyIf(this.CreateTabsConfig(e.rec, e.source), e),
            i = e.privilegeType;
        this.ns = SYNO.SDS.ControlPanel.Share, this.tabs = function() {
            var s = [];
            return !0 !== e.hideInfoPanel && s.push({
                title: _WFT("property", "heading_general"),
                layout: "fit",
                items: new SYNO.FileStation.PropertyDialog.InfoPage(t, i)
            }), SYNO.SDS.Share.PropertyDialogEnum.privilegeType.acl !== i || e.rec[0].get("is_snapshot") ? e.rec[0].get("isshare") || e.rec[0].get("is_snapshot") || SYNO.SDS.Share.PropertyDialogEnum.privilegeType.posix !== i || s.push({
                title: _WFT("acl_editor", "permission"),
                layout: "fit",
                items: new SYNO.FileStation.PropertyDialog.PosixPrivilege(t)
            }) : s.push({
                title: _WFT("acl_editor", "permission"),
                layout: "fit",
                items: this.aclPanel = new SYNO.SDS.Share.ACLPrivilege(Ext.apply({
                    isFirstLoad: !0,
                    openConfig: e.openConfig
                }, t))
            }), _S("is_admin") && e.rec[0].get("isshare") && !0 !== e.hideAdvPermPanel && (s.push(this.createShareGridPanel()), s.push(this.createAdvPermPanel(e.rec[0]))), e.rec[0].get("isshare") && s.push(this.createSnapshotGridPanel(e.rec[0])), s
        }.call(this);
        var s = _WFT("filetable", "filetable_properties");
        e.isShareForceRO && (s += " (" + _WFT("common", "readonly") + ")");
        var r = Ext.apply({
            width: 750,
            height: _S("diskless") ? 320 : 590,
            shadow: !0,
            minWidth: 600,
            minHeight: _S("diskless") ? 320 : 400,
            collapsible: !1,
            constrainHeader: !0,
            plain: !0,
            title: s,
            layout: "fit",
            items: [{
                xtype: "syno_tabpanel",
                activeTab: 0,
                plain: !0,
                itemId: "tab",
                layoutOnTabChange: !0,
                items: this.tabs,
                deferredRender: !1
            }],
            buttons: [{
                text: _WFT("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                btnStyle: "blue",
                text: _WFT("common", "save"),
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : void 0,
                handler: this.saveHandler
            }],
            keys: [{
                key: 27,
                fn: this.cancelHandler,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                },
                error: {
                    fn: this.errorHandler,
                    scope: this
                },
                beforeclose: {
                    fn: this.beforecloseHandler,
                    scope: this
                }
            }
        }, e);
        SYNO.SDS.Share.PermissionDialog.superclass.constructor.call(this, r);
        var a = this.getComponent("tab");
        a.hideTabStripItem("snapshotgrid"), _S("is_admin") && e.rec[0].get("isshare") && (SYNO.SDS.Share.PropertyDialogEnum.privilegeType.posix === i ? a.unhideTabStripItem("sharegrid") : a.hideTabStripItem("sharegrid")), this.snapshotGridPanel && this.mon(this.snapshotGridPanel.store, "load", function(e, t, i) {
            t.length > 0 && this.getComponent("tab").unhideTabStripItem("snapshotgrid")
        }, this)
    },
    createShareGridPanel: function() {
        return this.gridPanel = new SYNO.SDS.Share.ShareGrid({
            owner: this,
            itemId: "sharegrid",
            hideCustomColumn: !0,
            checkShareModified: function() {
                return 0 !== this.store.getModifiedRecords().length
            }
        }), this.gridPanel
    },
    createSnapshotGridPanel: function(e) {
        return this.snapshotGridPanel = new SYNO.SDS.Snapshot.SnapshotGrid({
            owner: this,
            itemId: "snapshotgrid",
            path: e.get("path"),
            real_path: e.get("real_path")
        }), this.snapshotGridPanel
    },
    createAdvPermPanel: function(e) {
        return this.formPanel = new SYNO.SDS.Share.AdvanceForm({
            owner: this,
            itemId: "advperm",
            checkShareModified: function() {
                return this.getForm().isDirty()
            },
            loadData: function() {
                this.owner.loadPermissionData(e)
            }
        }), this.formPanel
    },
    AlertMsg: function(e) {
        this.owner.getMsgBox().alert(this.title, e)
    },
    cancelHandler: function() {
        this.checkModified() ? this.getMsgBox().confirm(_WFT("filetable", "filetable_properties"), _WFT("common", "confirm_lostchange"), function(e) {
            "yes" == e && this.close()
        }, this) : this.close()
    },
    saveHandler: function() {
        if (_S("demo_mode")) return void this.getMsgBox().alert(_WFT("filetable", "filetable_properties"), _JSLIBSTR("uicommon", "error_demo"));
        if (this.checkModified()) {
            if (!this.validateData()) return;
            this.saveProperty(this.collectData())
        } else this.close()
    },
    errorHandler: function(e) {
        this.getMsgBox().alert(_WFT("error", "error_error"), e, this.close, this)
    },
    load: function() {
        if ("" !== this.rec) {
            var e = SYNO.SDS.Share.PropertyDialogEnum.privilegeType.none === this.privilegeType ? 320 : 590,
                t = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl().getHeight() : Ext.lib.Dom.getViewHeight();
            t < e && (e = t), this.setSize(this.width, e), this.LoadTabs(), this.show().center()
        }
    },
    LoadTabs: function() {
        for (var e = 0; e < this.tabs.length; ++e) Ext.isFunction(this.tabs[e].items.loadData) ? this.tabs[e].items.loadData() : Ext.isFunction(this.tabs[e].loadData) && this.tabs[e].loadData()
    },
    CreateTabsConfig: function(e, t) {
        var i, s, r, a, o = [],
            n = !1,
            l = [],
            h = null,
            d = [];
        if (e.length > 1) {
            for (n = !0, a = 0; a < e.length; a++) o.push(e[a].get("real_path")), r = e[a].get("file_id"), e[0].get("isdir") ? l.push(r) : l.push(r.substr(0, r.lastIndexOf("/"))), d.push(e[a].get("file_id"));
            i = o.join("_SYNOFM_"), h = l.join("_SYNOFM_"), s = d
        } else n = !1, i = e[0].get("real_path"), r = e[0].get("file_id"), h = e[0].get("isdir") ? r : r.substr(0, r.lastIndexOf("/")), s = e[0].get("file_id");
        return SYNO.webfm.utils.isLocalSource(t) ? (1 == e.length && (o[0] = i), this.gTargetFiles = o) : (this.gTargetFiles = i, this.gAPITargetFiles = s, this.gDirPaths = h), {
            owner: this,
            gblMultiFiles: n,
            gTargetFiles: this.gTargetFiles,
            gAPITargetFiles: this.gAPITargetFiles,
            gDirPaths: this.gDirPaths
        }
    },
    checkModified: function(e, t) {
        for (var i = 0; i < this.tabs.length; ++i) {
            var s = null,
                r = null;
            if (Ext.isFunction(this.tabs[i].items.checkModified)) {
                if (!1 === t) continue;
                s = this.tabs[i].items.checkModified, r = this.tabs[i].items
            } else if (Ext.isFunction(this.tabs[i].checkShareModified)) {
                if (!1 === e) continue;
                s = this.tabs[i].checkShareModified, r = this.tabs[i]
            }
            if (Ext.isFunction(s) && !0 === s.call(r)) return !0
        }
        return !1
    },
    validateData: function() {
        for (var e = 0; e < this.tabs.length; ++e)
            if (Ext.isFunction(this.tabs[e].items.validateData) && !1 === this.tabs[e].items.validateData()) return this.getComponent("tab").setActiveTab(e), !1;
        return !0
    },
    collectData: function() {
        for (var e = {
                file_path: this.gTargetFiles,
                files: this.gTargetFiles,
                dirPaths: this.gDirPaths
            }, t = 0; t < this.tabs.length; ++t) Ext.isFunction(this.tabs[t].items.collectData) && Ext.apply(e, this.tabs[t].items.collectData());
        return e
    },
    saveProperty: function(e) {
        var t = this.formPanel && this.formPanel.isAdvPermissionDisabled(),
            i = this.aclPanel && this.aclPanel.checkModified(),
            s = {
                name: this.rec[0].get("name"),
                is_sync_share: this.rec[0].get("is_sync_share"),
                permissions: [],
                no_check_permission: !1
            };
        this.rec[0].get("isshare") && (this.gridPanel && !this.isShareGridHidden() ? s.permissions = this.gridPanel.getModifiedPermissions() : i && (s.permissions = [{
            is_readonly: !1,
            is_deny: !1,
            is_writable: !1,
            is_custom: !0
        }]), t && (s.no_check_permission = !0)), SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, s, {
            dialogTitle: this.title,
            dialogMsg: _T("s2s", "s2s_warn_share_change_priv"),
            dialogOwner: this,
            continueHandler: function() {
                if (this.propertyVal = e, this.checkModified(!0, !1)) return void this.remoteSavePermission();
                this.successHandler()
            },
            abortHandler: Ext.EmptyFn,
            scope: this
        })
    },
    successHandler: function() {
        if (!this.checkModified(!1)) return void this.close();
        var e = SYNO.webfm.utils.getParentDirArr(this.rec);
        if ("aclPrivilege" === this.privilegeType) return void this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "check_self_denied",
            version: 1,
            scope: this,
            params: this.propertyVal,
            callback: function(t, i, s) {
                t && i.is_denied ? this.getMsgBox().confirm("", _WFT("acl_editor", "alert_set_self_denied_acl"), function(t) {
                    "yes" === t && this.setACL(e)
                }, this) : this.setACL(e)
            }
        });
        var t = {};
        Ext.apply(t, this.propertyVal), Ext.apply(t, this.savePropertyExtParams), t.dirPaths && (t.dir_paths = t.dirPaths.split("_SYNOFM_"), delete t.dirPaths), t.files = t.files.split("_SYNOFM_"), t.mode = "" + t.mode, this.sendWebAPI({
            api: "SYNO.FileStation.Property",
            method: "set",
            version: 1,
            params: t,
            scope: this,
            callback: function(t, i, s) {
                s.nodeIdArr = e, s.is_acl = !1, this.savePropertyCB(s, t, i)
            }
        })
    },
    setACL: function(e) {
        this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "set",
            version: 1,
            scope: this,
            params: this.propertyVal,
            callback: function(t, i, s) {
                s.nodeIdArr = e, s.is_acl = !0, this.savePropertyCB(s, t, i)
            }
        })
    },
    savePropertyCB: function(e, t, i) {
        this.fireEvent("callback", e, t, i), this.close()
    },
    beforecloseHandler: function() {
        for (var e = 0; e < this.tabs.length; ++e) Ext.isFunction(this.tabs[e].items.onClose) && this.tabs[e].items.onClose()
    }
}), Ext.define("SYNO.FileStation.PropertyDialog.InfoPage", {
    extend: "SYNO.ux.FormPanel",
    components: null,
    constructor: function(e, t) {
        this.components = [], this.components.push(new SYNO.FileStation.PropertyDialog.InfoPage.InfoFieldset(e)), !1 !== Ext.isDefined(e.rec[0].get("isshare")) && !1 !== e.rec[0].get("isshare") || e.rec[0].get("is_snapshot") || !1 !== SYNO.webfm.VFS.isVFSPath(e.rec[0].get("path")) || (SYNO.SDS.Share.PropertyDialogEnum.privilegeType.posix === t ? this.components.push(new SYNO.FileStation.PropertyDialog.InfoPage.PosixOwnerFieldset(e)) : SYNO.SDS.Share.PropertyDialogEnum.privilegeType.acl === t && this.components.push(new SYNO.FileStation.PropertyDialog.InfoPage.ACLOwnerFieldset(e)));
        var i = Ext.apply({
            layout: "form",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            hideMode: "display",
            hidden: !1,
            border: !1,
            name: "infoPage",
            itemId: "infoPage",
            items: this.components
        }, e);
        SYNO.FileStation.PropertyDialog.InfoPage.superclass.constructor.call(this, i)
    },
    loadData: function() {
        for (var e = 0; e < this.items.length; ++e) this.components[e].loadData()
    },
    checkModified: function() {
        for (var e = 0; e < this.components.length; ++e)
            if (!0 === this.components[e].checkModified()) return !0;
        return !1
    },
    validateData: function() {
        for (var e = 0; e < this.components.length; ++e)
            if (!1 === this.components[e].validateData()) return !1;
        return !0
    },
    collectData: function() {
        for (var e = {}, t = 0; t < this.components.length; ++t) Ext.apply(e, this.components[t].collectData());
        return e
    },
    onClose: function() {
        for (var e = 0; e < this.items.length; ++e) this.components[e].onClose()
    }
}), Ext.define("SYNO.FileStation.PropertyDialog.InfoPage.InfoFieldset", {
    extend: "SYNO.ux.FieldSet",
    md5ThreadId: null,
    sizeTreadId: null,
    constructor: function(e) {
        var t = [{
                xtype: "syno_textfield",
                fieldLabel: _WFT("common", "common_filename"),
                name: "name",
                itemId: "name",
                width: 300,
                readOnly: !0,
                cls: "selectabletext allowDefCtxMenu"
            }, {
                xtype: "syno_textfield",
                fieldLabel: _WFT("property", "file_location"),
                name: "real_path",
                itemId: "real_path",
                width: 300,
                readOnly: !0,
                cls: "selectabletext allowDefCtxMenu"
            }, {
                itemId: "size",
                xtype: "syno_displayfield",
                width: "auto",
                fieldLabel: _WFT("common", "common_filesize"),
                name: "size"
            }, {
                itemId: "disk_size",
                xtype: "syno_displayfield",
                width: "auto",
                fieldLabel: _WFT("property", "file_disk_size"),
                name: "disk_size"
            }, {
                xtype: "syno_displayfield",
                itemId: "mod_time",
                width: "auto",
                fieldLabel: _WFT("filetable", "filetable_mtime"),
                name: "mod_time"
            }, {
                itemId: "folder_access_link",
                cls: "syno-webfm-dir-link",
                border: !1,
                layout: "form",
                items: [{
                    xtype: "syno_displayfield",
                    width: "auto",
                    fieldLabel: _WFT("filetable", "filetable_dir_access_link"),
                    itemId: "link",
                    htmlEncode: !1,
                    listeners: {
                        render: function(e) {
                            var t = e.label.first("a.pathlink");
                            t && this.mon(t, "click", function() {
                                SYNO.webfm.utils.onMailTo(encodeURIComponent(this.folderAccessLinkurl))
                            }, this)
                        },
                        scope: this,
                        single: !0,
                        buffer: 80
                    }
                }]
            }, {
                itemId: "snapshot_desc",
                xtype: "syno_displayfield",
                width: "auto",
                fieldLabel: _T("filebrowser", "snapshot_desc"),
                name: "snapshot_desc",
                hidden: !(1 == e.rec.length && SYNO.webfm.utils.isSnapshotShareFolder(e.rec[0].get("path"), e.rec[0].get("is_snapshot"), e.rec[0].get("is_btrfs_subvol")))
            }, {
                itemId: "md5",
                border: !1,
                cls: "syno-webfm-md5-panel",
                layout: "hbox",
                items: [{
                    xtype: "syno_displayfield",
                    value: "MD5",
                    width: 185
                }, {
                    itemId: "md5_calc_btn",
                    xtype: "syno_button",
                    text: _WFT("common", "calculate"),
                    handler: this.CalcMD5,
                    scope: this
                }, {
                    xtype: "syno_displayfield",
                    name: "md5",
                    itemId: "md5_value",
                    selectable: !0,
                    width: 300
                }]
            }],
            i = SYNO.SDS.Share.PropertyDialogEnum.privilegeType.none === e.privilegeType,
            s = Ext.apply({
                title: _WFT("property", "heading_general"),
                border: !i,
                cls: i ? "syno-sds-fieldset-without-legend" : "",
                hideMode: "display",
                synodefaults: {
                    width: 300
                },
                name: "infoFieldset",
                items: t
            }, e);
        SYNO.FileStation.PropertyDialog.InfoPage.InfoFieldset.superclass.constructor.call(this, s), Ext.EventManager.on(window, "unload", this.handelKillprocess, this), SYNO.SDS.StatusNotifier.on("logout", this.handelKillprocess, this)
    },
    GetSnapshotDesc: function(e) {
        this.addWebAPITask({
            api: "SYNO.FileStation.Snapshot",
            method: "desc",
            version: 2,
            single: !0,
            params: {
                path: this.gAPITargetFiles
            },
            callback: function(e, t, i) {
                e ? this.get("snapshot_desc").setValue(t.desc) : this.get("snapshot_desc").setValue("N/A")
            },
            scope: this
        }).start(!0)
    },
    CalcFileSize: function(e) {
        if (SYNO.webfm.utils.isLocalSource(this.source)) {
            var t = {
                    pathlist: this.gTargetFiles,
                    dialogId: this.id,
                    action: "getSize"
                },
                i = AppletProgram.action(t);
            return void(i && i.success || this.get("size").setValue("N/A"))
        }
        this.addWebAPITask({
            api: "SYNO.FileStation.DirSize",
            method: "start",
            version: 2,
            single: !0,
            params: {
                path: this.gAPITargetFiles
            },
            callback: function(e, t, i) {
                e ? this.calcSizeCallback(t.taskid) : this.get("size").setValue("N/A")
            },
            scope: this
        }).start(!0)
    },
    calcSizeCallback: function(e) {
        var t, i, s, r;
        this.gCalcRequest = this.addWebAPITask({
            api: "SYNO.FileStation.DirSize",
            method: "status",
            version: 2,
            interval: 5e3,
            params: {
                taskid: e
            },
            callback: function(e, a, o) {
                if (this.isDestroyed) return void(this.gCalcRequest && (this.gCalcRequest.stop(), this.gCalcRequest = 0));
                var n = "N/A";
                e ? (a.finished && (this.gCalcRequest.stop(), this.gCalcRequest = 0), (Ext.isNumber(a.total_size) && a.total_size >= 0 || Ext.isNumber(a.num_dir) && a.num_dir > 0 || Ext.isNumber(a.num_file) && a.num_file > 0) && (t = parseInt(a.total_size, 10), r = Ext.util.Format.number(t, "0,000"), i = Ext.util.Format.fileSize(t) + " (" + r + " Bytes)", s = String.format(_WFT("property", "file_statistics"), a.num_file, a.num_dir), n = i + ". " + s), a.finished || (n = _WFT("common", "calculating") + "...  " + String.format(_WFT("property", "file_statistics"), a.num_file, a.num_dir)), this.get("size").setValue(n)) : e && !a.errors || (this.gCalcRequest.stop(), this.gCalcRequest = 0, this.get("size").setValue(n))
            },
            scope: this
        }), this.gCalcRequest.start(!0), this.gCalcSizeTaskId = e
    },
    CalcMD5: function() {
        var e = _WFT("common", "calculatingmd5") + "...",
            t = this.getComponent("md5"),
            i = t.getComponent("md5_calc_btn"),
            s = t.getComponent("md5_value");
        if (i.hide(), t.doLayout(), s.setValue(e), SYNO.webfm.utils.isLocalSource(this.source)) {
            var r = {
                    path: this.gTargetFiles[0],
                    dialogId: this.id,
                    action: "getMD5"
                },
                a = AppletProgram.action(r);
            return void(a && a.success || s.setValue("N/A"))
        }
        this.addWebAPITask({
            api: "SYNO.FileStation.MD5",
            method: "start",
            version: 2,
            single: !0,
            params: {
                file_path: this.gAPITargetFiles
            },
            callback: function(e, t, i) {
                e ? this.CalcMD5Callback(t.taskid) : s.setValue("N/A")
            },
            scope: this
        }).start(!0)
    },
    CalcMD5Callback: function(e) {
        this.gMD5Request = this.addWebAPITask({
            api: "SYNO.FileStation.MD5",
            method: "status",
            version: 2,
            interval: 1e3,
            params: {
                taskid: e
            },
            callback: function(e, t, i) {
                if (this.isDestroyed) return this.gMD5Request.stop(), void(this.gMD5Request = 0);
                e && t.finished && t.md5 ? (this.gMD5Request.stop(), this.gMD5Request = 0, this.get("md5").get("md5_value").setValue(t.md5)) : e && !t.errors || (this.gMD5Request.stop(), this.gMD5Request = 0, this.get("md5").get("md5_value").setValue("N/A"))
            },
            scope: this
        }), this.gMD5Request.start(!0), this.gCalcMD5TaskId = e
    },
    SetFolderQuickAccessLink: function(e) {
        var t, i = e.get("isdir"),
            s = e.get("file_id") + "/",
            r = {
                openfile: s
            },
            a = Ext.isObject(r) ? Ext.urlEncode({
                launchParam: Ext.urlEncode(r)
            }) : "";
        if (!1 !== i) {
            t = SYNO.SDS.Utils.Network.getURLprefix();
            var o = String.format("{0}/index.cgi?launchApp={1}", t, encodeURIComponent("SYNO.SDS.App.FileStation3.Instance"));
            o = window._urlAppend(o, a), this.folderAccessLinkurl = o;
            var n = Ext.util.Format.ellipsis(o, 50),
                l = String.format('<a class="pathlink allowDefCtxMenu" target="_blank" href="{0}">{1}</a>', o, n);
            this.get("folder_access_link").get("link").setValue(l)
        }
    },
    loadData: function() {
        var e, t, i, s, r, a = this.rec,
            o = 0,
            n = 0,
            l = !1,
            h = !1,
            d = 0;
        if (this.get("md5").hide(), this.get("disk_size").hide(), this.gblMultiFiles) {
            this.get("folder_access_link").hide();
            var c = a[0].get("filename"),
                u = a[0].get("real_path").lastIndexOf(c),
                p = 0,
                g = 0;
            for (d = 0; d < a.length; d++) a[d].get("isdir") ? p++ : g++;
            for (e = g + " " + _WFT("common", "file") + ", " + p + " " + _WFT("common", "folder"), t = a[0].get("real_path").substr(0, u), i = "N/A", d = 0; d < a.length; d++) {
                if (SYNO.webfm.VFS.isVFSPath(a[d].get("path"))) {
                    h = !0;
                    break
                }
                if (a[d].get("isdir")) {
                    l = !0;
                    break
                }
                o = parseInt(a[d].get("filesize"), 10), n += o
            }
            l || (s = n)
        } else e = a[0].get("filename"), t = a[0].get("real_path"), i = Ext.isDefined(a[0].get("mt")) ? SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * a[0].get("mt")), {
            type: "datetimesec"
        }) : "N/A", a[0].get("isdir") ? l = !0 : (this.get("md5").show(), s = a[0].get("filesize"), this.sendWebAPI({
            api: "SYNO.FileStation.Property.CompressSize",
            method: "get",
            version: 1,
            params: {
                file: a[0].get("real_path")
            },
            callback: function(e, t, i, s) {
                if (!this.isDestroyed && e && t.diskSize) {
                    var r = t.diskSize,
                        a = Ext.util.Format.number(r, "0,000");
                    this.get("disk_size").setValue(Ext.util.Format.fileSize(r) + " (" + a + " Bytes)"), this.get("disk_size").show()
                }
            },
            scope: this
        })), SYNO.webfm.VFS.isVFSPath(a[0].get("path")) && (h = !0), SYNO.webfm.utils.isLocalSource(this.source) || !0 === a[0].get("isshare") ? this.get("folder_access_link").hide() : !0 === a[0].get("isdir") ? (this.SetFolderQuickAccessLink(a[0]), this.get("folder_access_link").show()) : this.get("folder_access_link").hide();
        h ? ((this.gblMultiFiles || a[0].get("isdir")) && this.get("size").hide(), this.get("md5").hide(), this.get("folder_access_link").hide()) : l && (s = _WFT("common", "calculating") + "...", this.CalcFileSize(a)), 1 === a.length && SYNO.webfm.utils.isSnapshotShareFolder(a[0].get("path"), a[0].get("is_snapshot"), a[0].get("is_btrfs_subvol")) && this.GetSnapshotDesc(a[0]), r = Ext.util.Format.number(s, "0,000"), this.get("name").setValue(e), this.get("real_path").setValue(t), this.get("mod_time").setValue(i), this.get("size").setValue(l ? s : Ext.util.Format.fileSize(s) + " (" + r + " Bytes)"), !1 === this.gblMultiFiles && !0 === a[0].get("isshare") && this.sendWebAPI({
            api: "SYNO.FileStation.Property.Mtime",
            method: "get",
            version: 1,
            params: {
                file: a[0].get("real_path")
            },
            callback: function(e, t, i, s) {
                this.isDestroyed || e && t.mtime && this.get("mod_time").setValue(SYNO.webfm.utils.DateTimeFormatter(new Date(1e3 * t.mtime), {
                    type: "datetimesec"
                }))
            },
            scope: this
        })
    },
    checkModified: function() {
        return !1
    },
    validateData: function() {
        return !0
    },
    collectData: function() {
        return {}
    },
    calcSizeCancel: function(e, t) {
        SYNO.API.currentManager.requestAjaxAPI("SYNO.FileStation.DirSize", "stop", 2, {
            async: t,
            timeout: t ? 30 : 10
        }, {
            taskid: e
        })
    },
    calcMD5Cancel: function(e, t) {
        SYNO.API.currentManager.requestAjaxAPI("SYNO.FileStation.MD5", "stop", 2, {
            async: t,
            timeout: t ? 30 : 10
        }, {
            taskid: e
        })
    },
    handelKillprocess: function() {
        this.killCalcProcess(!1)
    },
    killCalcProcess: function(e) {
        this.gCalcRequest && (this.gCalcRequest.stop(), this.gCalcRequest = 0, this.calcSizeCancel(this.gCalcSizeTaskId, e)), this.gMD5Request && (this.gMD5Request.stop(), this.gMD5Request = 0, this.calcMD5Cancel(this.gCalcMD5TaskId, e))
    },
    onClose: function() {
        if (this.killCalcProcess(!0), Ext.EventManager.un(window, "unload", this.handelKillprocess, this), SYNO.SDS.StatusNotifier.un("logout", this.handelKillprocess, this), SYNO.webfm.utils.isLocalSource(this.source)) {
            if (this.md5ThreadId) {
                var e = {
                    threadId: this.md5ThreadId,
                    action: "stopPropertyThread"
                };
                AppletProgram.action(e), this.md5ThreadId = null
            }
            if (this.sizeThreadId) {
                var t = {
                    threadId: this.sizeThreadId,
                    action: "stopPropertyThread"
                };
                AppletProgram.action(t), this.sizeThreadId = null
            }
        } else;
    }
}), Ext.define("SYNO.FileStation.PropertyDialog.InfoPage.PosixOwnerFieldset", {
    extend: "SYNO.ux.FieldSet",
    dsUserList: null,
    dsGrpList: null,
    gDefUserVal: null,
    gDefGrpVal: null,
    unShow: "----------------",
    constructor: function(e) {
        this.owner = e.owner;
        var t = [{
                xtype: "syno_combobox",
                fieldLabel: _WFT("filetable", "filetable_owner"),
                name: "cmb_owner",
                itemId: "cmb_owner",
                displayField: "name",
                valueField: "name",
                triggerAction: "all",
                mode: "remote",
                readOnly: e.isShareForceRO,
                editable: !0,
                resizable: !0,
                pageSize: 50,
                listEmptyText: _WFT("error", "error_invalid_user"),
                grow: !0,
                listWidth: 360,
                maxHeight: 360,
                minChars: 1,
                typeAhead: !0
            }, {
                xtype: "syno_combobox",
                fieldLabel: _WFT("filetable", "filetable_group"),
                name: "cmb_group",
                itemId: "cmb_group",
                displayField: "name",
                valueField: "name",
                triggerAction: "all",
                mode: "remote",
                readOnly: e.isShareForceRO,
                editable: !0,
                resizable: !0,
                pageSize: 50,
                listEmptyText: _WFT("error", "error_invalid_group"),
                grow: !0,
                listWidth: 360,
                maxHeight: 360,
                minChars: 1,
                typeAhead: !0
            }, {
                xtype: "syno_checkbox",
                boxLabel: _WFT("property", "privilege_recursive"),
                hideMode: "display",
                name: "recursive",
                itemId: "recursive"
            }],
            i = Ext.apply({
                title: _WFT("filetable", "filetable_owner") + " & " + _WFT("filetable", "filetable_group"),
                border: !0,
                hideMode: "display",
                synodefaults: {
                    width: 300
                },
                name: "posixOwnerFieldset",
                items: t
            }, e);
        SYNO.FileStation.PropertyDialog.InfoPage.PosixOwnerFieldset.superclass.constructor.call(this, i)
    },
    InitUserList: function() {
        this.dsUserList = new SYNO.API.Store({
            appWindow: this.owner,
            autoDestroy: !0,
            api: "SYNO.FileStation.UserGrp",
            method: "list_user",
            version: 1,
            baseParams: {
                type: "all"
            },
            reader: new Ext.data.JsonReader({
                root: "users",
                totalProperty: "total",
                id: "name"
            }, [{
                name: "name",
                mapping: "name"
            }]),
            remoteSort: !0,
            pruneModifiedRecords: !0
        })
    },
    InitGrpList: function() {
        this.dsGrpList = new SYNO.API.Store({
            appWindow: this.owner,
            autoDestroy: !0,
            api: "SYNO.FileStation.UserGrp",
            method: "list_group",
            version: 1,
            baseParams: {
                type: "all",
                name_only: !0
            },
            reader: new Ext.data.JsonReader({
                root: "groups",
                totalProperty: "total",
                id: "name"
            }, [{
                name: "name",
                mapping: "name"
            }]),
            remoteSort: !1,
            pruneModifiedRecords: !0
        })
    },
    loadData: function() {
        this.InitUserList(), this.InitGrpList(), this.LoadUsers(), this.LoadGroups(), this.LockFields()
    },
    LoadUsers: function() {
        var e = this.rec,
            t = this.get("cmb_owner"),
            i = "",
            s = "",
            r = 0;
        if (t.store = this.dsUserList, this.gblMultiFiles) {
            var a = !1;
            for (r = 0; r < e.length; r++)
                if (s = e[r].get("owner"), "" === i) i = s;
                else if (i != s) {
                a = !0;
                break
            }
            this.gDefUserVal = a ? this.unShow : i
        } else this.gDefUserVal = e[0].get("owner");
        "" === this.gDefUserVal && (this.gDefUserVal = e[0].get("uid")), t.setValue(this.gDefUserVal), delete t.lastQuery
    },
    LoadGroups: function() {
        var e = this.rec,
            t = this.get("cmb_group"),
            i = "",
            s = "",
            r = 0;
        if (t.store = this.dsGrpList, e.length > 1) {
            var a = !1;
            for (r = 0; r < e.length; r++)
                if (s = e[r].get("group"), "" === i) i = s;
                else if (i != s) {
                a = !0;
                break
            }
            this.gDefGrpVal = a ? this.unShow : i
        } else this.gDefGrpVal = e[0].get("group");
        "" === this.gDefGrpVal && (this.gDefGrpVal = e[0].get("gid")), t.setValue(this.gDefGrpVal), delete t.lastQuery
    },
    LockFields: function() {
        if (this.get("cmb_owner").disable(), this.get("cmb_group").disable(), this.get("recursive").disable(), !0 === _S("is_admin") && (this.get("cmb_owner").enable(), this.get("cmb_group").enable(), !this.isShareForceRO))
            for (var e = 0; e < this.rec.length; ++e) this.rec[e].get("isdir") && this.get("recursive").enable()
    },
    checkModified: function() {
        var e = this.getComponent("recursive").getValue(),
            t = this.getComponent("cmb_owner").getValue(),
            i = this.getComponent("cmb_group").getValue();
        return !(!e || this.unShow === t && this.unShow === i) || (this.gDefUserVal !== t && t !== this.unShow || this.gDefGrpVal !== i && i !== this.unShow)
    },
    validateData: function() {
        var e = this.getComponent("recursive").getValue(),
            t = this.getComponent("cmb_owner"),
            i = this.getComponent("cmb_group"),
            s = t.getValue(),
            r = i.getValue();
        (this.gDefUserVal === s && !e || s === this.unShow) && (s = null), (this.gDefGrpVal === r && !e || r === this.unShow) && (r = null);
        var a = !1,
            o = 0,
            n = 0;
        if (null !== s && this.gDefUserVal !== s) {
            for (o = this.dsUserList.getCount(), a = !1, n = 0; n < o; n++)
                if (this.dsUserList.getAt(n).get("name") === s) {
                    a = !0;
                    break
                } if (!a) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_properties"), _WFT("acl_editor", "error_invalid_user_or_group")), !1
        }
        if (null !== r && this.gDefGrpVal !== r) {
            for (o = this.dsGrpList.getCount(), a = !1, n = 0; n < o; n++)
                if (this.dsGrpList.getAt(n).get("name") === r) {
                    a = !0;
                    break
                } if (!a) return this.owner.getMsgBox().alert(_WFT("filetable", "filetable_properties"), _WFT("acl_editor", "error_invalid_user_or_group")), !1
        }
        return !0
    },
    collectData: function() {
        var e = this.getComponent("recursive").getValue(),
            t = this.getComponent("cmb_owner"),
            i = this.getComponent("cmb_group"),
            s = t.getValue(),
            r = i.getValue();
        return (this.gDefUserVal === s && !e || s === this.unShow) && (s = null), (this.gDefGrpVal === r && !e || r === this.unShow) && (r = null), {
            owner: s,
            group: r,
            posix_owner_recur: e
        }
    },
    onClose: function() {
        this.dsUserList.removeAll(), this.dsGrpList.removeAll()
    }
}), Ext.define("SYNO.FileStation.PropertyDialog.PosixPrivilege", {
    extend: "SYNO.ux.FormPanel",
    fieldArr: ["owner_read", "owner_write", "owner_execute", "group_read", "group_write", "group_execute", "others_read", "others_write", "others_execute"],
    constructor: function(e) {
        var t = Ext.apply({
            layout: "form",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            hideMode: "display",
            hidden: !1,
            border: !1,
            name: "privilege",
            items: [{
                itemId: "fset_posix_mode",
                xtype: "syno_fieldset",
                title: _WFT("acl_editor", "permission"),
                hideMode: "display",
                labelWidth: 110,
                synodefaults: {
                    width: 500
                },
                items: [{
                    xtype: "syno_compositefield",
                    combineErrors: !1,
                    fieldLabel: _WFT("filetable", "filetable_owner"),
                    name: "privilege_owner",
                    defaults: {
                        flex: 1,
                        height: 30
                    },
                    items: [new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_read"),
                        name: "owner_read",
                        value: !1,
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_write"),
                        name: "owner_write",
                        value: !1,
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_execute"),
                        name: "owner_execute",
                        value: !1,
                        triMode: !1
                    })]
                }, {
                    xtype: "syno_compositefield",
                    combineErrors: !1,
                    fieldLabel: _WFT("filetable", "filetable_group"),
                    name: "privilege_group",
                    defaults: {
                        flex: 1,
                        height: 30
                    },
                    items: [new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_read"),
                        name: "group_read",
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_write"),
                        name: "group_write",
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_execute"),
                        name: "group_execute",
                        triMode: !1
                    })]
                }, {
                    xtype: "syno_compositefield",
                    combineErrors: !1,
                    fieldLabel: _WFT("property", "privilege_others"),
                    name: "privilege_others",
                    defaults: {
                        flex: 1,
                        height: 30
                    },
                    items: [new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_read"),
                        name: "others_read",
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_write"),
                        name: "others_write",
                        triMode: !1
                    }), new SYNO.ux.TriModeCheckbox({
                        boxLabel: _WFT("property", "privilege_execute"),
                        name: "others_execute",
                        triMode: !1
                    })]
                }]
            }, {
                xtype: "syno_checkbox",
                boxLabel: _WFT("property", "privilege_recursive"),
                hideMode: "display",
                itemId: "mode_recur",
                name: "mode_recur"
            }]
        }, e);
        SYNO.FileStation.PropertyDialog.PosixPrivilege.superclass.constructor.call(this, t)
    },
    loadData: function() {
        this.LoadPrivilege(), this.LockFields()
    },
    LoadPrivilege: function() {
        function e(e) {
            var t = 0,
                i = 0,
                s = 0,
                r = parseInt(e, 10);
            return r >= 100 && (t = Math.floor(r / 100), r -= 100 * t), r >= 10 && (i = Math.floor(r / 10), r -= 10 * i), s = r, {
                owner_read: !!(4 & t),
                owner_write: !!(2 & t),
                owner_execute: !!(1 & t),
                group_read: !!(4 & i),
                group_write: !!(2 & i),
                group_execute: !!(1 & i),
                others_read: !!(4 & s),
                others_write: !!(2 & s),
                others_execute: !!(1 & s)
            }
        }
        var t = this.rec,
            i = this.fieldArr,
            s = 0;
        for (s = 0; s < this.fieldArr.length; s++) this.form.findField(this.fieldArr[s]).setTriMode(this.gblMultiFiles);
        this.form.setValues(function(t) {
            var s, r = {},
                a = [],
                o = "",
                n = 0;
            for (n = 0; n < i.length; n++) r[i[n]] = null;
            for (n = 0; n < t.length; n++)
                for (o = t[n].get("privilege"), a = e(o), s = 0; s < i.length; s++) 0 === n && (r[i[s]] = a[i[s]]), r[i[s]] != a[i[s]] && (r[i[s]] = null);
            return r
        }(t))
    },
    LockFields: function() {
        var e = 0,
            t = _S("is_admin");
        if (this.form.findField("mode_recur").disable(), !this.isShareForceRO && !0 === t)
            for (e = 0; e < this.rec.length; ++e) this.rec[e].get("isdir") && this.form.findField("mode_recur").enable();
        var i, s, r = this.isShareForceRO;
        for (e = 0; e < this.rec.length; e++) {
            if (SYNO.webfm.VFS.isVFSPath(this.rec[e].get("file_id")) && -1 == SYNO.webfm.VFS.SupportChmodList.indexOf(SYNO.webfm.VFS.getSchemaFromPath(this.rec[e].get("file_id")).toLowerCase())) {
                this.form.findField("mode_recur").disable(), r = !0;
                break
            }
            if (i = Ext.util.Format.lowercase(this.rec[e].get("file_id")), s = i.indexOf("/", 1), s > 0 && (i = i.substr(0, s)), "/photo" === i) {
                r = !0;
                break
            }
        }
        var a = !0;
        for (e = 0; e < this.rec.length; e++)
            if (Ext.isDefined(this.rec[e].get("uid"))) {
                if (this.rec[e].get("uid") != this.userId) {
                    a = !1;
                    break
                }
            } else if (this.rec[e].get("owner") != _S("user")) {
            a = !1;
            break
        }
        for (e = 0; e < this.fieldArr.length; e++) {
            var o = null;
            o = this.form.findField(this.fieldArr[e]), o && (r || !t && !a ? o.disable() : o.enable())
        }
    },
    checkModified: function() {
        return this.form.isDirty()
    },
    validateData: function() {
        return !0
    },
    collectData: function() {
        var e = this.form,
            t = this.fieldArr,
            i = this.getComponent("mode_recur").getValue(),
            s = -1;
        return s = this.gblMultiFiles ? function() {
            var i = [],
                s = 0;
            for (s = 0; s < t.length; s++) {
                var r, a = null;
                if (a = e.findField(t[s])) {
                    if (r = -1, a.isDirty()) switch (r = a.getValue()) {
                        case "true":
                            r = 1;
                            break;
                        case "false":
                            r = 0;
                            break;
                        default:
                            r = -1
                    }
                    i[s] = r
                }
            }
            return i.join(":")
        }() : function(i) {
            var s = [4, 2, 1],
                r = 0,
                a = null,
                o = 0,
                n = 0,
                l = 0;
            if (!(i || e.findField("privilege_owner").isDirty() || e.findField("privilege_group").isDirty() || e.findField("privilege_others").isDirty())) return -1;
            for (o = 0; o < t.length; o++) a = null, a = e.findField(t[o]), a && "true" === a.getValue() && (r |= s[n]), n++, 2 == o ? (r > 0 && (l = 100 * r), n = 0, r = 0) : 5 == o ? (r > 0 && (l += 10 * r), n = 0, r = 0) : o == t.length - 1 && r > 0 && (l += r);
            return l
        }(i), {
            mode: s,
            posix_mode_recur: i
        }
    },
    onClose: function() {
        this.form.reset()
    }
}), Ext.define("SYNO.FileStation.PropertyDialog.InfoPage.ACLOwnerFieldset", {
    extend: "SYNO.ux.FieldSet",
    gDefOwnerVal: null,
    constructor: function(e) {
        Ext.apply(this, e);
        var t = [new SYNO.SDS.Share.ACLPrivilege.UserGrpCombo({
                fieldLabel: _WFT("filetable", "filetable_owner"),
                width: 335,
                listWidth: 335,
                itemId: "owner_cmb",
                queryParam: "prefix"
            }), {
                xtype: "syno_checkbox",
                itemId: "owner_recur",
                boxLabel: _WFT("property", "privilege_recursive"),
                hideMode: "display",
                hidden: _S("diskless"),
                name: "recursive"
            }],
            i = {
                title: _WFT("filetable", "filetable_owner"),
                border: !0,
                hideMode: "display",
                name: "aclOwnerFieldset",
                items: t
            };
        SYNO.FileStation.PropertyDialog.InfoPage.ACLOwnerFieldset.superclass.constructor.call(this, i)
    },
    loadData: function() {
        this.get("owner_cmb").setReadOnly(!0), this.get("owner_recur").disable(), this.sendWebAPI({
            api: "SYNO.FileStation.Property.ACLOwner",
            method: "get",
            version: 1,
            scope: this,
            params: {
                file: this.gTargetFiles.split("_SYNOFM_")[0]
            },
            callback: function(e, t, i, s) {
                this.afterLoadData(e, t, s)
            }
        })
    },
    afterLoadData: function(e, t, i) {
        if (!this.isDestroyed) {
            var s = this.get("owner_cmb");
            if (_S("is_admin") && s.setReadOnly(!1), e) s.setDefaultValue(t.name, t.type, t.value), this.gDefOwnerVal = t.value;
            else if (403 != t.code) this.owner.fireEvent("error", SYNO.webfm.utils.getWebAPIErrStr(e, t, i));
            else {
                var r = SYNO.webfm.utils.getWebAPIErrStr(e, t, i);
                s.setDefaultValue(r, "", r), this.gDefOwnerVal = r
            }
            if (!0 === t.hasPrivilege || !0 === _S("is_admin")) {
                s.setReadOnly(this.isShareForceRO), !this.isShareForceRO && this.rec[0].get("isdir") && this.get("owner_recur").enable();
                var a = function(e, t) {
                    return t.type + ":" + t.name
                };
                _S("is_admin") ? s.store = new Ext.data.Store({
                    autoDestroy: !0,
                    proxy: new SYNO.API.Proxy({
                        api: "SYNO.Core.ACL",
                        method: "list_owners",
                        version: 1
                    }),
                    reader: new Ext.data.JsonReader({
                        root: "owners",
                        totalProperty: "total",
                        id: "value"
                    }, [{
                        name: "type"
                    }, {
                        name: "name"
                    }, {
                        name: "value",
                        convert: a
                    }]),
                    paramNames: {
                        start: "offset",
                        limit: "limit"
                    },
                    remoteSort: !0,
                    baseParams: {
                        include_everyone: !1,
                        include_owner: !1
                    },
                    pruneModifiedRecords: !0
                }) : "user" === t.type && _S("user") === t.name ? s.setReadOnly(!0) : (s.mode = "local", s.pageSize = 0, s.store = new Ext.data.ArrayStore({
                    autoDestroy: !0,
                    fields: ["type", "name", "value"],
                    data: [
                        ["user", _S("user"), "user:" + _S("user")],
                        [t.type, t.name, t.value]
                    ]
                }))
            }
        }
    },
    checkModified: function() {
        if (this.getComponent("owner_recur").isDirty()) return !0;
        var e = this.getComponent("owner_cmb");
        return !(!e.isDirty() || this.gDefOwnerVal === e.getValue())
    },
    validateData: function() {
        var e = this.getComponent("owner_cmb"),
            t = e.getValue(),
            i = t.substr(0, t.indexOf(":")),
            s = t.substr(t.indexOf(":") + 1);
        return !e.valueNotFound() && null !== s && "" !== s && null !== i && "" !== i || (this.owner.getMsgBox().alert(_WFT("error", "error_error"), _WFT("error", "error_invalid_user")), !1)
    },
    collectData: function() {
        if (this.checkModified()) {
            var e = this.getComponent("owner_cmb"),
                t = e.getValue();
            return {
                change_acl_owner: !0,
                acl_owner_type: t.substr(0, t.indexOf(":")),
                acl_owner: t.substr(t.indexOf(":") + 1),
                acl_owner_recur: this.getComponent("owner_recur").getValue()
            }
        }
        return {}
    },
    onClose: function() {
        this.getTaskRunner().stopAll()
    }
}), SYNO.FileStation.localSetThreadId = function(e) {
    var t = Ext.getCmp(e.dialogId);
    "md5" == e.action ? t.md5ThreadId = e.threadId : "size" == e.action && (t.sizeThreadId = e.threadId)
}, SYNO.FileStation.localUpdateEntry = function(e) {
    var t, i, s, r = Ext.getCmp(e.dialogId),
        a = "N/A";
    e.md5 ? (r.get("md5").get("md5_value").setValue(e.md5), r.md5ThreadId = null) : Ext.isEmpty(e.size) || ("N/A" == e.size ? r.get("size").setValue("N/A") : (t = parseInt(e.size, 10), i = Ext.util.Format.fileSize(t), s = String.format(_WFT("property", "file_statistics"), e.files, e.folders), a = i + ". " + s, r.get("size").setValue(a)), r.sizeThreadId = null)
};