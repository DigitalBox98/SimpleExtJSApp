/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Sharing.Custom");
SYNO.SDS.Sharing.Custom.LoginHandler = function(a) {
    function c() {
        var g = SYNO.SDS.Session.lang;
        var f = ["webapi/entry.cgi?api=SYNO.FileStation.UIString&version=1&method=getjs&lang=" + g];
        var e = document.getElementsByTagName("head")[0];
        Ext.each(f, function(i) {
            var h = document.createElement("script");
            h.type = "text/javascript";
            h.src = i;
            if (Ext.isIE8) {
                h.onreadystatechange = function() {
                    if (this.readyState == "complete" || this.readyState == "loaded") {
                        b()
                    }
                }
            } else {
                h.onload = b
            }
            e.appendChild(h)
        })
    }

    function b() {
        if (!SYNO.SDS.ExtraSession.is_sharing_upload) {
            SYNO.FileStation.LoginDialog = new SYNO.FileStation.Sharing.AccessPage({
                _mode: _S("sharing_status"),
                _data: SYNO.SDS.ExtraSession,
                isMobile: window.isMobile()
            })
        } else {
            if (window.isMobile()) {
                SYNO.FileStation.LoginDialog = new SYNO.FileStation.Request.MobileAccessPage()
            } else {
                if ("password" == _S("sharing_status")) {
                    SYNO.FileStation.LoginDialog = new SYNO.FileStation.Request.AccessPage({
                        _mode: _S("sharing_status"),
                        _data: SYNO.SDS.ExtraSession
                    })
                }
            }
        }
    }
    if (window.isMobile()) {
        var d = document.createElement("meta");
        d.name = "viewport";
        d.content = "width=device-width, initial-scale=1.0";
        if (SYNO.SDS.ExtraSession.is_sharing_upload) {
            d.content = "width=device-width, initial-scale=1.0, maximum-scale=1.0"
        }
        document.getElementsByTagName("head")[0].appendChild(d)
    }
    c()
};
window.isMobile = function() {
    var a = false;
    (function(b) {
        if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(b) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(b.substr(0, 4))) {
            a = true
        }
    })(navigator.userAgent || navigator.vendor || window.opera);
    return a
};
Ext.define("SYNO.FileStation.Sharing.AccessPage", {
    extend: "Ext.Container",
    constructor: function(a) {
        var b = [];
        Ext.apply(this, a || {});
        if ("none" === this._mode && this._data.is_folder) {
            this.onDownloadFile();
            return
        }
        this.background = this.createBackground();
        this.dialog = this.createAccessDialog();
        this.logo = this.createLogo();
        this.footer = this.createFooter();
        b.push(this.background);
        b.push(this.dialog);
        b.push(this.logo);
        b.push(this.footer);
        var c = {
            id: "webfm-login",
            renderTo: document.body,
            items: b
        };
        this.callParent([c]);
        this._onResize();
        Ext.EventManager.onWindowResize(this._onResize, this);
        Ext.getBody().addKeyListener(13, this.onKeyDown, this);
        this.bindControllerEvent();
        if (_S("preview")) {
            this.setFormDisabled(true)
        }
    },
    bindControllerEvent: function() {
        this.loginController = new SYNO.SDS.Sharing.LoginController();
        this.mon(this.loginController, "loginerror", this.onLoginError, this);
        this.mon(this.loginController, "login", this.onLoginSuccess, this);
        this.mon(SYNO.SDS.Sharing.Init, "beforeinitdata", this.onInitData, this);
        this.mon(SYNO.SDS.Sharing.Init, "initdata", this.onInitData, this)
    },
    onInitData: function(b) {
        var a = this._data.filename || SYNO.SDS.Sharing.Private.filename || _WFT("sharing", "unavailable_file");
        this.initDownloadPanel(a);
        this.fileNameField.setValue(a);
        Ext.defer(function() {
            this.background.resize();
            this.doAlignLogo(500);
            this.doAlignFooter(500)
        }, 500, this);
        return false
    },
    getTplConfig: function() {
        var a = {};
        if (this._data.enable_custom_setting && this._data.enable_background && 0 === this._data.status) {
            a.background_color = this._data.background_color;
            a.background_path = this._data.background_path;
            a.background_pos = this._data.background_position
        } else {
            a.background_path = Ext.BLANK_IMAGE_URL;
            a.background_color = "#3a8ecc";
            a.background_pos = "center"
        }
        return a
    },
    createBackground: function() {
        return SYNO.SDS.LoginUtils.createBackground(this.getTplConfig(), "webfm-login-background")
    },
    createLogo: function() {
        var b = Ext.BLANK_IMAGE_URL;
        if (this._data.enable_custom_setting && this._data.enable_logo) {
            b = this._data.logo_path
        }
        var a = new Ext.BoxComponent({
            id: "webfm-logo",
            xtype: "box",
            itemId: "webfm-logo",
            name: "webfm-logo",
            cls: "webfm-logo",
            autoEl: {
                tag: "img",
                src: b
            }
        });
        return a
    },
    createFooter: function() {
        var a = new SYNO.ux.DisplayField({
            cls: "webfm-login-footer",
            value: "",
            listeners: {
                afterrender: function() {
                    if (_S("preview")) {
                        var c = this,
                            b = window.location.origin;
                        this.recvMsg = function(f) {
                            if (f.origin === b) {
                                c.updateFooter(a, f.data)
                            }
                            window.removeEventListener("message", this.recvMsg, false)
                        };
                        window.addEventListener("message", this.recvMsg, false);
                        var d = {
                            name: "fbsharing",
                            method: "getFooterMsg"
                        };
                        window.opener.postMessage(JSON.stringify(d), b)
                    } else {
                        this.updateFooter(a, this._data.footer_msg)
                    }
                    if (this.isMobile) {
                        a.addClass("login-mobile")
                    }
                },
                scope: this
            }
        });
        return a
    },
    createTitle: function() {
        return new Ext.Container({
            width: this.getComponentWidth(),
            height: 38,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px"
            },
            cls: "webfm-login-dialog-title",
            html: _WFT("sharing", "secure_access") || "Secure Access"
        })
    },
    createAccessDialog: function() {
        var a = [];
        if ("none" !== this._mode && 0 === this._data.status) {
            a.push(this.createLoginPanel())
        }
        a.push(this.createDownloadPanel());
        this.dialog = new SYNO.ux.Panel({
            id: "webfm-access-dialog",
            cls: this.getDialogCls(),
            width: this.getDialogWidth(),
            height: this.getDialogHeight(),
            style: {
                background: "FFFFFF"
            },
            layout: "card",
            activeItem: 0,
            items: a
        });
        return this.dialog
    },
    getDialogCls: function() {
        var a = "webfm-access-dialog";
        if (this.isMobile) {
            a += " webfm-mobile"
        }
        return a
    },
    getDialogWidth: function() {
        if (this.isMobile) {
            return Ext.lib.Dom.getViewWidth() - 16 * 2
        }
        return 400
    },
    getDialogHeight: function() {
        if (this.isMobile) {
            return 418
        }
        return 438
    },
    getComponentWidth: function() {
        if (this.isMobile) {
            return this.getDialogWidth() - 32 * 2
        }
        return 320
    },
    createLoginPanel: function() {
        this.title = this.createTitle();
        this.descField = this.createDescField();
        this.userInfoField = this.createUserInfoField();
        this.statusField = this.createStatusField();
        this.inputField = this.createInputField();
        this.bottomPanel = this.createBottomPanel();
        var a = [];
        a.push(this.title);
        a.push(this.descField);
        a.push(this.createPadding(10));
        if ("user" === this._mode) {
            a.push(this.userInfoField);
            a.push(this.inputField);
            a.push(this.statusField);
            a.push(this.bottomPanel)
        } else {
            a.push(this.inputField);
            a.push(this.statusField);
            a.push(this.bottomPanel)
        }
        this.enterUser = false;
        var b = {
            width: 400,
            autoHeight: true,
            useGradient: false,
            items: a,
            keys: [{
                key: Ext.EventObject.ENTER,
                fn: "user" === this._mode ? this.onUserLogin : this.onSubmit,
                scope: this
            }],
            listeners: {
                scope: this,
                afterrender: function() {
                    if ("user" === this._mode) {
                        this.userField.focus(false, 1000)
                    } else {
                        this.passField.focus(false, 1000)
                    }
                }
            }
        };
        this.loginPanel = new Ext.Container({
            itemId: "login_panel",
            id: "login-inner-panel",
            cls: "webfm-inner-panel",
            module: this,
            items: [this.title, new Ext.Panel(b)]
        });
        return this.loginPanel
    },
    createInputField: function() {
        var a = [];
        this.userField = this.createUserFields();
        this.passField = this.createPassFields();
        if ("user" === this._mode) {
            a.push(this.userField)
        }
        a.push(this.passField);
        return new Ext.Container({
            style: {
                padding: "10px 0px"
            },
            width: this.getComponentWidth(),
            height: 70,
            items: a
        })
    },
    createBottomPanel: function() {
        var a = [];
        this.loginBtn = this.createLoginBtn(true);
        if ("user" === this._mode) {
            this.userLoginBtn = this.createUserLoginBtn(true);
            a.push(this.userLoginBtn);
            this.loginBtn.hide()
        }
        a.push(this.loginBtn);
        return new Ext.Container({
            layout: {
                type: "vbox",
                align: "center"
            },
            style: {
                padding: "10px 0px"
            },
            width: 368,
            height: 62,
            items: a
        })
    },
    createDownloadPanel: function() {
        var a = [];
        this.downloadBottomPanel = this.createDownloadBottomPanel();
        this.iconBox = this.createIconBox();
        this.fileNameField = this.createFileNameField();
        this.setFileNameClass();
        a.push(this.createPadding(32));
        a.push(this.iconBox);
        a.push(this.createPadding(28));
        a.push(this.fileNameField);
        a.push(this.createPadding(62));
        if (0 === this._data.status) {
            a.push(this.downloadBottomPanel)
        }
        var b = {
            width: 350,
            itemId: "download_panel",
            autoHeight: true,
            useGradient: false,
            id: "download-inner-panel",
            cls: "webfm-inner-panel",
            layout: {
                type: "vbox",
                align: "center"
            },
            items: a
        };
        this.downloadPanel = new SYNO.ux.FormPanel(b);
        return this.downloadPanel
    },
    createIconBox: function() {
        return new Ext.BoxComponent({
            xtype: "box",
            itemId: "thumb",
            name: "thumb",
            cls: "webfm-file-icon",
            height: 128,
            width: 128,
            autoEl: {
                tag: "div"
            }
        })
    },
    createFileNameField: function() {
        return new SYNO.ux.DisplayField({
            xtype: "syno_displayfield",
            cls: "webfm-download-filename",
            width: this.getComponentWidth(),
            height: 48,
            value: "",
            style: {
                padding: "0"
            }
        })
    },
    createStatusField: function() {
        this.errorMsgField = new SYNO.ux.DisplayField({
            cls: "webfm-login-dialog-status error",
            width: this.getComponentWidth(),
            hidden: true
        });
        this.loadingAnimation = new SYNO.ux.DisplayField({
            height: 24,
            htmlEncode: true,
            style: {
                padding: "0"
            },
            html: '<div class="webfm-logining-wrap"><div class="loader-1"><span></span></div></div>'
        });
        this.loadingMsg = new SYNO.ux.DisplayField({
            cls: "webfm-login-msg",
            height: 24,
            style: {
                "margin-left": "6px",
                padding: "2px 0px"
            },
            value: ""
        });
        this.loadingBox = new Ext.Container({
            layout: "hbox",
            width: this.getComponentWidth(),
            hidden: true,
            items: [this.loadingAnimation, this.loadingMsg]
        });
        return new Ext.Container({
            cls: "webfm-login-dialog-status",
            width: this.getComponentWidth(),
            height: 140,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px",
                padding: "10px 0px"
            },
            value: "",
            items: [this.errorMsgField, this.loadingBox],
            listeners: {
                afterrender: function() {
                    this.getEl().setARIA({
                        role: "log",
                        live: "assertive"
                    })
                },
                scope: this
            }
        })
    },
    createUserLoginBtn: function(a) {
        return new SYNO.ux.Button({
            cls: "webfm-login-btn",
            btnStyle: "blue",
            text: _T("common", "next"),
            height: 36,
            scope: this,
            disabled: a,
            handler: this.onUserLogin
        })
    },
    createLoginBtn: function(a) {
        return new SYNO.ux.Button({
            cls: "webfm-login-btn",
            btnStyle: "blue",
            text: _T("common", "next"),
            height: 36,
            scope: this,
            disabled: a,
            handler: this.onSubmit
        })
    },
    createDownloadBtn: function() {
        return new SYNO.ux.Button({
            cls: "webfm-login-btn",
            xtype: "syno_button",
            btnStyle: "blue",
            text: _WFT("filetable", "filetable_download"),
            height: 36,
            scope: this,
            handler: this.onDownloadFile
        })
    },
    createDownloadBottomPanel: function() {
        this.downloadBtn = this.createDownloadBtn();
        return new Ext.Container({
            width: this.isMobile ? this.getComponentWidth() + 48 : 368,
            height: 62,
            layout: {
                type: "vbox",
                align: "center"
            },
            style: {
                padding: "10px 0px"
            },
            items: [this.downloadBtn]
        })
    },
    createUserInfoField: function() {
        this.prevBtn = new SYNO.ux.Button({
            iconCls: "webfm-login-prev-btn-icn",
            width: 24,
            height: 24,
            style: {
                border: "0"
            },
            listeners: {
                scope: this,
                click: this.onPreviousBtnClick
            }
        });
        this.avatarBtn = new SYNO.ux.Button({
            iconCls: "webfm-login-avatar-icn",
            cls: "webfm-login-avatar",
            text: "username",
            height: 24,
            style: {
                border: "0"
            },
            listeners: {
                scope: this,
                click: this.onPreviousBtnClick
            }
        });
        return new Ext.Container({
            layout: "hbox",
            style: {
                padding: "10px 0px"
            },
            hidden: true,
            height: 44,
            items: [{
                cls: "webfm-avatar-btn-wrap",
                items: [this.prevBtn, this.avatarBtn]
            }]
        })
    },
    createUserFields: function() {
        return new SYNO.ux.TextField({
            width: this.getComponentWidth(),
            height: 50,
            cls: "webfm-sharing-login-textfield",
            emptyText: _T("common", "username"),
            emptyClass: "webfm-empty-text",
            enableKeyEvents: true,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px"
            },
            listeners: {
                keyup: function() {
                    var a = 0 === this.userField.getValue().length;
                    this.userLoginBtn.setDisabled(a)
                },
                scope: this
            }
        })
    },
    createPassFields: function() {
        this.loginPassFileld = new SYNO.ux.TextField({
            width: this.getComponentWidth(),
            height: 50,
            cls: "webfm-sharing-login-textfield",
            inputType: "password",
            enableKeyEvents: true,
            emptyText: _T("common", "password"),
            emptyClass: "webfm-empty-text",
            disabledClass: "webfm-disable-textfield",
            hidden: "user" === this._mode,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px"
            },
            listeners: {
                keyup: function() {
                    if (0 < this.loginPassFileld.getValue().length) {
                        this.loginPassFileld.addClass("webfm-password-input");
                        this.loginBtn.setDisabled(false)
                    } else {
                        this.loginPassFileld.removeClass("webfm-password-input");
                        this.loginBtn.setDisabled(true)
                    }
                },
                scope: this
            }
        });
        return this.loginPassFileld
    },
    createDescField: function() {
        var a = {
            width: this.getComponentWidth(),
            height: 40,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px",
                padding: "0"
            },
            xtype: "syno_displayfield",
            value: ("user" === this._mode) ? _WFT("sharing", "dsm_access_desc") : _WFT("sharing", "passwd_access_desc"),
            cls: "webfm-login-desc"
        };
        return new SYNO.ux.DisplayField(a)
    },
    createPadding: function(a) {
        return {
            width: 350,
            height: a,
            style: {
                "margin-left": this.isMobile ? "24px" : "28px"
            }
        }
    },
    onLoginSuccess: function() {
        this.clearMsg();
        if (this._data.is_folder) {
            this.onDownloadFile()
        } else {
            this.dialog.getLayout().setActiveItem(1);
            var a = SYNO.SDS.Sharing.Private.filename || _WFT("sharing", "unavailable_file");
            this.initDownloadPanel(a);
            this.fileNameField.setValue(a)
        }
    },
    onLoginError: function(a, b) {
        this.setError(b);
        this.setFormDisabled(false)
    },
    onSubmit: function() {
        if (0 === this.passField.getValue().length) {
            return
        }
        this.setFormDisabled(true);
        this.setMsg(_T("common", "msg_waiting"));
        var a = {
            sharing_id: _S("sharing_id")
        };
        if ("password" === this._mode) {
            Ext.apply(a, {
                password: this.passField.getValue()
            })
        } else {
            Ext.apply(a, {
                dsm_username: this.userField.getValue(),
                dsm_password: this.passField.getValue()
            })
        }
        this.loginController.submit(a);
        return false
    },
    onKeyDown: function() {
        var a = this.dialog.getLayout().activeItem.itemId;
        if (a === "download_panel" && !this.downloadBtn.disabled) {
            this.onDownloadFile();
            return
        }
    },
    onUserLogin: function() {
        if (true === this.enterUser) {
            if (0 < this.passField.getValue().length) {
                this.onSubmit()
            }
        } else {
            if (0 < this.userField.getValue().length) {
                this.enterUser = true;
                this.userInfoField.show();
                this.userField.hide();
                this.passField.show();
                this.passField.focus();
                this.userLoginBtn.hide();
                this.loginBtn.show();
                this.bottomPanel.doLayout();
                this.statusField.setHeight(96);
                this.avatarBtn.setText(this.userField.getValue())
            }
        }
    },
    onPreviousBtnClick: function() {
        this.enterUser = false;
        this.userInfoField.hide();
        this.passField.reset();
        this.passField.hide();
        this.userField.show();
        this.userField.focus();
        this.loginBtn.hide();
        this.userLoginBtn.show();
        this.statusField.setHeight(140)
    },
    onDownloadFile: function() {
        var b = window.location.href.replace("/sharing/", "/fsdownload/");
        var a = b.indexOf("?");
        if (-1 !== a) {
            b = b.substr(0, a)
        }
        b += "/" + window.encodeURIComponent(this._data.filename || SYNO.SDS.Sharing.Private.filename);
        window.location.href = b;
        if (this.downloadBtn) {
            this.downloadBtn.setDisabled(true)
        }
    },
    _onResize: function() {
        var b;
        if (this.isMobile) {
            b = Ext.lib.Dom.getViewHeight() * 0.06;
            Ext.fly("webfm-access-dialog").alignTo(document.body, "t-t", [0, b]);
            Ext.defer(function() {
                Ext.fly("webfm-access-dialog").alignTo(document.body, "t-t", [0, b])
            }, 500, this)
        } else {
            var a = 0.45;
            b = Ext.lib.Dom.getViewHeight() * (a - 0.5);
            Ext.fly("webfm-access-dialog").alignTo(document.body, "c-c", [0, -30 + b]);
            Ext.defer(function() {
                Ext.fly("webfm-access-dialog").alignTo(document.body, "c-c", [0, -30 + b])
            }, 500, this);
            this.background.resize()
        }
        this.doAlignFooter()
    },
    initDownloadPanel: function(b) {
        var c = SYNO.FileStation.Sharing.Utils.GetThumbName(b, false);
        var d = 'url("../webman/modules/FileBrowser/images/' + c + '")';
        var a = this.downloadPanel.getComponent("thumb");
        a.getEl().setStyle("background-image", d);
        if (!Ext.isEmpty(b)) {
            this.fileNameField.getEl().dom.setAttribute("ext:qtip", Ext.util.Format.htmlEncode(b))
        }
        this.doAlignLogo(300)
    },
    setFileNameClass: function() {
        var b = "15px verdana";
        var e = this.fileNameField.getValue();
        var d = this.getTextWidth("a", b);
        var c = this.getTextWidth(e, b);
        var a = (0 !== d) ? (c / d) : 0;
        if (a < 31) {
            this.fileNameField.addClass("one-line")
        } else {
            if (a < 62) {
                this.fileNameField.addClass("two-line")
            } else {
                this.fileNameField.addClass("three-line")
            }
        }
    },
    getTextWidth: function(e, a) {
        var b, c, d;
        b = document.createElement("canvas");
        if (!b || !b.getContext) {
            return 0
        }
        c = b.getContext("2d");
        if (!c || !c.measureText) {
            return 0
        }
        c.font = a;
        d = c.measureText(e);
        return d.width
    },
    setError: function(a) {
        this.errorMsgField.setValue(a);
        this.loadingBox.hide();
        this.errorMsgField.show()
    },
    setMsg: function(a) {
        this.errorMsgField.hide();
        this.loadingMsg.setValue(a);
        this.loadingBox.show()
    },
    clearMsg: function() {
        this.loadingMsg.setValue("");
        this.errorMsgField.hide();
        this.loadingBox.hide()
    },
    setFormDisabled: function(b, a) {
        this.userField.setDisabled(b);
        this.passField.setDisabled(b);
        this.loginBtn.setDisabled(b)
    },
    doAlignLogo: function(a) {
        var b = "br-br";
        if (this.isMobile || !this._data.enable_custom_setting || 0 !== this._data.status) {
            this.logo.hide();
            return
        }
        this.logo.getEl().setStyle("maxWidth", "300px");
        this.logo.getEl().setStyle("maxHeight", "100px");
        if ("rightup" === this._data.logo_position) {
            b = "tr-tr"
        } else {
            if ("leftbottom" == this._data.logo_position) {
                b = "bl-bl"
            } else {
                if ("leftup" === this._data.logo_position) {
                    b = "tl-tl"
                }
            }
        }
        this.logo.getEl().alignTo(document.body, b, [0, 0]);
        if (Ext.isNumber(a)) {
            Ext.defer(function() {
                this.logo.getEl().alignTo(document.body, b, [0, 0])
            }, a, this)
        }
    },
    doAlignFooter: function(a) {
        this.footer.getEl().alignTo(document.body, "b-b", [0, 0]);
        if (Ext.isNumber(a)) {
            Ext.defer(function() {
                this.footer.getEl().alignTo(document.body, "b-b", [0, 0])
            }, a, this)
        }
    },
    updateFooter: function(b, a) {
        if (this._data.enable_footer_html) {
            b.update(a)
        } else {
            b.setValue(a)
        }
    },
    destroy: function() {}
});
Ext.define("SYNO.FileStation.Sharing.Utils", {
    statics: {
        icon_type: ["acc", "ai", "avi", "bmp", "doc", "exe", "fla", "folder", "gif", "htm", "indd", "iso", "jpg", "js", "misc", "mp3", "pdf", "png", "ppt", "psd", "rar", "swf", "tar", "ttf", "txt", "wma", "xls", "ico", "tif", "tiff", "ufo", "raw", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "jpe", "jpeg", "html", "3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "m4v", "mkv", "mp4", "mts", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "aac", "flac", "m4a", "m4b", "aif", "ogg", "pcm", "wav", "cda", "mid", "mp2", "mka", "mpc", "ape", "ra", "ac3", "dts", "bin", "img", "mds", "nrg", "daa", "docx", "wri", "rtf", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw", "xlsx", "xlsm", "xlsb", "xltm", "xlam", "pptx", "pps", "ppsx", "ade", "adp", "adn", "accdr", "accdb", "accdt", "mdb", "mda", "mdn", "mdt", "mdw", "mdf", "mde", "accde", "mam", "maq", "mar", "mat", "maf", "flv", "f4v", "7z", "bz2", "gz", "zip", "tgz", "tbz", "ttc", "otf", "css", "actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "bkpi", "c", "cc", "php", "jsx", "xml", "xhtml", "mhtml", "cpp", "cs", "cxx"],
        archive_type: ["zip", "gz", "tar", "tgz", "tbz", "bz2", "rar", "7z", "iso"],
        image_type: ["iso"],
        DocumentFileTypes: "docx,wri,rtf,xla,xlb,xlc,xld,xlk,xll,xlm,xlt,xlv,xlw,xlsx,xlsm,xlsb,xltm,xlam,pptx,pps,ppsx,pdf,txt,doc,xls,ppt",
        ImageFileTypes: "ico,tif,tiff,ufo,raw,arw,srf,sr2,dcr,k25,kdc,cr2,crw,nef,mrw,ptx,pef,raf,3fr,erf,mef,mos,orf,rw2,dng,x3f,jpg,jpg,jpeg,png,gif,bmp",
        VideoFileTypes: "3gp,3g2,asf,dat,divx,dvr-ms,m2t,m2ts,m4v,mkv,mp4,mts,mov,qt,tp,trp,ts,vob,wmv,xvid,ac3,amr,rm,rmvb,ifo,mpeg,mpg,mpe,m1v,m2v,mpeg1,mpeg2,mpeg4,ogv,webm,flv,avi,swf,f4v",
        AudioFileTypes: "aac,flac,m4a,m4b,aif,ogg,pcm,wav,cda,mid,mp2,mka,mpc,ape,ra,ac3,dts,wma,mp3",
        WebPageFileTypes: "html,htm,css,actproj,ad,akp,applescript,as,asax,asc,ascx,asm,asmx,asp,aspx,asr,c,cc,php,jsx,xml,xhtml,mhtml,cpp,cs,cxx,js",
        DiscFileTypes: "bin,img,mds,nrg,daa,iso",
        ZippedFileTypes: "7z,bz2,gz,zip,tgz,tbz,rar,tar",
        GetThumbName: function(b, g) {
            var f, e;
            var d = SYNO.FileStation.Sharing.Utils.isRetina();
            var c = (d) ? "2x" : "1x";
            var a = (d) ? "files_ext_256" : "files_ext_128";
            if ("true" === g) {
                f = c + "/" + a + "/folder.png"
            } else {
                if (Ext.isEmpty(b)) {
                    f = c + "/icon_error.png"
                } else {
                    e = b.substr(b.lastIndexOf(".") + 1);
                    e = e.toLowerCase();
                    if (-1 !== SYNO.FileStation.Sharing.Utils.icon_type.indexOf(e)) {
                        f = e + ".png"
                    } else {
                        f = "misc.png"
                    }
                    f = c + "/" + a + "/" + f
                }
            }
            return f
        },
        isRetina: function() {
            var a = false;
            var b = "(-webkit-min-device-pixel-ratio: 1.5),(min--moz-device-pixel-ratio: 1.5),(-o-min-device-pixel-ratio: 3/2),(min-resolution: 1.5dppx)";
            if (window.devicePixelRatio >= 1.5) {
                a = true
            }
            if (window.matchMedia && window.matchMedia(b).matches) {
                a = true
            }
            return a
        }
    }
});
Ext.define("SYNO.FileStation.Request.AccessPage", {
    extend: "Ext.Container",
    constructor: function(a) {
        var b = [];
        Ext.apply(this, a || {});
        this.dialog = this.createAccessDialog();
        b.push(this.dialog);
        var c = {
            id: "webfm-login",
            renderTo: document.body,
            items: b
        };
        this.callParent([c]);
        this._onResize();
        Ext.EventManager.onWindowResize(this._onResize, this);
        this.bindControllerEvent()
    },
    bindControllerEvent: function() {
        this.loginController = new SYNO.SDS.Sharing.LoginController();
        this.mon(this.loginController, "loginerror", this.onLoginError, this);
        this.mon(this.loginController, "login", this.onLoginSuccess, this);
        this.mon(SYNO.SDS.Sharing.Init, "beforeinitdata", this.onInitData, this);
        this.mon(SYNO.SDS.Sharing.Init, "initdata", this.onInitData, this)
    },
    onInitData: function(a) {
        return true
    },
    createAccessDialog: function() {
        if (0 !== this._data.status) {
            return {}
        }
        this.dialog = new Ext.Container({
            layout: {
                type: "fit"
            },
            width: 800,
            id: "webfm-request-access-dialog",
            cls: "webfm-request-access-dialog",
            items: [this.createLoginPanel()]
        });
        return this.dialog
    },
    createLoginPanel: function() {
        this.title = this.createTitle();
        this.descField = this.createDescField();
        this.passField = this.createPassFields();
        this.statusField = this.createStatusField();
        this.loginBtn = this.createLoginBtn(true);
        this.iconBox = this.createIconBox();
        var a = {
            id: "webfm-request-panel",
            items: [{
                id: "webfm-request-top-panel",
                xtype: "container",
                boxMinHeight: 86,
                layout: {
                    type: "vbox",
                    align: "center"
                },
                items: [this.title, this.descField]
            }, {
                xtype: "container",
                boxMinHeight: 435,
                layout: {
                    type: "vbox",
                    align: "center"
                },
                items: [this.iconBox, this.createPadding(24), this.passField, this.createPadding(72), this.loginBtn, this.createPadding(24), this.statusField]
            }],
            keys: [{
                key: Ext.EventObject.ENTER,
                fn: this.onSubmit,
                scope: this
            }],
            listeners: {
                scope: this,
                afterrender: function() {
                    this.passField.focus(false, 1000)
                }
            }
        };
        this.loginPanel = new Ext.Panel(a);
        return this.loginPanel
    },
    createTitle: function() {
        return new Ext.Container({
            width: 320,
            height: 34,
            style: {
                "text-align": "center",
                "padding-bottom": "8px"
            },
            cls: "webfm-login-dialog-title",
            html: _WFT("sharing", "file_request_login_title")
        })
    },
    createDescField: function() {
        var a = {
            boxMaxWidth: 800,
            width: 720,
            height: 72,
            style: {
                "text-align": "center"
            },
            xtype: "syno_displayfield",
            value: _WFT("sharing", "request_pass_access_subtitle") || "Please enter password to access this file request page",
            cls: "webfm-login-desc"
        };
        return new SYNO.ux.DisplayField(a)
    },
    createIconBox: function() {
        return new SYNO.ux.DisplayField({
            cls: "webfm-sharing-upload-login-icon"
        })
    },
    createStatusField: function() {
        this.errorMsgField = new SYNO.ux.DisplayField({
            cls: "webfm-login-dialog-status error",
            width: 340,
            hidden: true
        });
        this.loadingAnimation = new SYNO.ux.DisplayField({
            height: 24,
            htmlEncode: true,
            style: {
                padding: "0"
            },
            html: '<div class="webfm-logining-wrap"><div class="loader-1"><span></span></div></div>'
        });
        this.loadingMsg = new SYNO.ux.DisplayField({
            cls: "webfm-login-msg",
            height: 24,
            style: {
                "margin-left": "6px",
                padding: "2px 0px"
            },
            value: ""
        });
        this.loadingBox = new Ext.Container({
            layout: "hbox",
            width: 320,
            hidden: true,
            items: [this.loadingAnimation, this.loadingMsg]
        });
        return new Ext.Container({
            cls: "webfm-login-dialog-status",
            width: 340,
            height: 60,
            value: "",
            items: [this.errorMsgField, this.loadingBox],
            listeners: {
                afterrender: function() {
                    this.el.setARIA({
                        role: "log",
                        live: "assertive"
                    })
                },
                scope: this
            }
        })
    },
    createLoginBtn: function(a) {
        return new SYNO.ux.Button({
            cls: "webfm-login-btn",
            btnStyle: "blue",
            text: _T("common", "next"),
            height: 36,
            scope: this,
            disabled: a,
            handler: this.onSubmit
        })
    },
    createPassFields: function() {
        this.loginPassFileld = new SYNO.ux.TextField({
            width: 420,
            height: 50,
            cls: "webfm-sharing-login-textfield",
            inputType: "password",
            enableKeyEvents: true,
            emptyText: _T("common", "password"),
            emptyClass: "webfm-empty-text",
            disabledClass: "webfm-disable-textfield",
            listeners: {
                keyup: function() {
                    if (0 < this.loginPassFileld.getValue().length) {
                        this.loginPassFileld.addClass("webfm-password-input");
                        this.loginBtn.setDisabled(false)
                    } else {
                        this.loginPassFileld.removeClass("webfm-password-input");
                        this.loginBtn.setDisabled(true)
                    }
                },
                scope: this
            }
        });
        return this.loginPassFileld
    },
    createPadding: function(a) {
        return {
            xtype: "container",
            width: 340,
            height: a,
            style: {
                border: "0"
            }
        }
    },
    onLoginSuccess: function() {
        this.clearMsg()
    },
    onLoginError: function(a, b) {
        this.setError(b);
        this.setFormDisabled(false)
    },
    onSubmit: function() {
        if (0 === this.passField.getValue().length) {
            return
        }
        this.setFormDisabled(true);
        this.setMsg(_T("common", "msg_waiting"));
        var a = {
            sharing_id: _S("sharing_id")
        };
        if ("password" === this._mode) {
            Ext.apply(a, {
                password: this.passField.getValue()
            })
        }
        this.loginController.submit(a);
        return false
    },
    _onResize: function() {
        var b = 0.25;
        var c = Ext.lib.Dom.getViewHeight() * b;
        var a = Ext.fly("webfm-request-top-panel").dom.offsetHeight;
        Ext.fly("webfm-request-panel").alignTo(document.body, "t-t", [0, -a + c]);
        Ext.defer(function() {
            Ext.fly("webfm-request-panel").alignTo(document.body, "t-t", [0, -a + c])
        }, 500, this)
    },
    setError: function(a) {
        this.errorMsgField.setValue(a);
        this.loadingBox.hide();
        this.errorMsgField.show()
    },
    setMsg: function(a) {
        this.errorMsgField.hide();
        this.loadingMsg.setValue(a);
        this.loadingBox.show()
    },
    clearMsg: function() {
        this.loadingMsg.setValue("");
        this.errorMsgField.hide();
        this.loadingBox.hide()
    },
    setFormDisabled: function(b, a) {
        this.passField.setDisabled(b);
        this.loginBtn.setDisabled(b)
    },
    destroy: function() {}
});
Ext.define("SYNO.FileStation.Request.MobileAccessPage", {
    extend: "Ext.Container",
    constructor: function(a) {
        var b = {
            id: "webfm-login",
            renderTo: document.body,
            items: this.createVueContent()
        };
        this.callParent([b]);
        this._onResize();
        Ext.EventManager.onWindowResize(this._onResize, this)
    },
    createVueContent: function() {
        this.vueContent = new Ext.Container({
            id: "desktop",
            layout: "fit",
            listeners: {
                afterrender: function(a) {
                    a.getEl().createChild({
                        id: "file-request-mobile",
                        tag: "div"
                    });
                    SYNO.FileStation.Request.Mobile.Vue.Init()
                }
            }
        });
        return this.vueContent
    },
    _onResize: function() {
        this.vueContent.setHeight(Ext.lib.Dom.getViewHeight());
        this.vueContent.getEl().alignTo(document.body, "t-t")
    }
});