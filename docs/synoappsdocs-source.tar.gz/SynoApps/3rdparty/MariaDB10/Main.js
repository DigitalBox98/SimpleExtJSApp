/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.MARIADB10.PasswordWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = Ext.apply({
            title: this.title,
            width: 465,
            height: 250,
            resizable: false,
            layout: "fit",
            items: [this.mainPanel],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                btnStyle: "blue",
                xtype: "syno_button",
                text: _T("common", "apply"),
                scope: this,
                handler: function() {
                    if (!this.mainPanel.getForm().isValid()) {
                        return
                    }
                    this.clickHandler()
                }
            }]
        }, a);
        this.callParent([b])
    },
    clickHandler: function() {
        if ("" === this.mainPanel.getForm().findField("password").getValue()) {
            var a = {
                yes: SYNO.SDS.MARIADB10.GetString("ui", "skip"),
                no: SYNO.SDS.MARIADB10.GetString("common", "no")
            };
            this.getMsgBox().confirm("MariaDB10", SYNO.SDS.MARIADB10.GetString("ui", "dbpass_empty_confirm"), function(b, c) {
                if (b === "yes") {
                    this.clickAction()
                }
            }, this, a)
        } else {
            this.clickAction()
        }
    }
});
Ext.define("SYNO.SDS.MARIADB10.PasswordPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.passwordFieldID = Ext.id();
        this.itemsArray.push({
            id: this.passwordFieldID,
            xtype: "syno_textfield",
            textType: "password",
            name: "password",
            fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "db_new_password"),
            validator: this.isPasswordValid
        }, {
            xtype: "syno_textfield",
            textType: "password",
            name: "password_confirm",
            fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "db_confirm_password"),
            invalidText: _T("error", "error_repswd"),
            initialPin: this.passwordFieldID,
            validator: function(d) {
                if (this.initialPin) {
                    var c = Ext.getCmp(this.initialPin).getValue();
                    return (d === c)
                }
                return true
            }
        });
        var b = Ext.apply({
            border: false,
            items: this.itemsArray
        }, a);
        this.callParent([b])
    },
    isPasswordValid: function(b) {
        var e = 10;
        var d = {
            mixed_case: -1 !== b.search("(?=.*[a-z])(?=.*[A-Z])"),
            included_special_char: -1 !== b.search("(?=.*[^A-Za-z0-9])"),
            included_numeric_char: -1 !== b.search("(?=.*[0-9])"),
            min_length_enable: -1 !== b.search("(?=.{" + e + ",})")
        };
        var f = [];
        var c = "";
        var a = true;
        for (c in d) {
            if (false === d[c]) {
                if (c === "min_length_enable") {
                    f.push(_T("passwd", c) + " " + e)
                } else {
                    f.push(_T("passwd", c))
                }
                a = false
            }
        }
        if (0 !== f.length) {
            return _T("passwd", "passwd_strength_warn") + f.join(", ") + _T("common", "period")
        }
        return a
    }
});
Ext.define("SYNO.SDS.MARIADB10.ChangePasswordWindow", {
    extend: "SYNO.SDS.MARIADB10.PasswordWindow",
    mainPanel: null,
    constructor: function(a) {
        this.title = SYNO.SDS.MARIADB10.GetString("ui", "change_password");
        this.mainPanel = new SYNO.SDS.MARIADB10.ChangePasswordPanel({
            owner: this,
            users: a.users
        });
        this.callParent(arguments)
    },
    clickAction: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "change_password",
            encryption: ["password", "dbpass"],
            params: {
                username: this.mainPanel.getForm().findField("username").getValue(),
                password: this.mainPanel.getForm().findField("password").getValue(),
                dbpass: this.dbpass
            },
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(a.code));
                    return
                }
                this.close()
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.MARIADB10.ChangePasswordPanel", {
    extend: "SYNO.SDS.MARIADB10.PasswordPanel",
    constructor: function(a) {
        this.users = a.users;
        this.itemsArray = [];
        this.itemsArray.push({
            xtype: "syno_combobox",
            name: "username",
            forceSelection: true,
            valueField: "name",
            displayField: "name",
            store: new Ext.data.JsonStore({
                fields: ["name"],
                data: this.users
            }),
            value: this.users[0].name,
            fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "db_username")
        });
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.MARIADB10.LoginWindow", {
    extend: "SYNO.SDS.ModalWindow",
    mainPanel: null,
    constructor: function(a) {
        var c = [{
            xtype: "syno_textfield",
            textType: "password",
            name: "dbpass",
            fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "db_password")
        }];
        this.mainPanel = new SYNO.SDS.Utils.FormPanel({
            border: false,
            items: c
        });
        var b = Ext.apply({
            title: SYNO.SDS.MARIADB10.GetString("ui", "db_login"),
            width: 465,
            height: 210,
            resizable: false,
            layout: "fit",
            items: [this.mainPanel],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                btnStyle: "blue",
                xtype: "syno_button",
                text: _T("common", "next"),
                scope: this,
                handler: this.login
            }]
        }, a);
        this.callParent([b])
    },
    login: function() {
        var a = this.mainPanel.getForm().findField("dbpass").getValue();
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "get_user",
            encryption: ["dbpass"],
            params: {
                dbpass: a
            },
            callback: function(d, c) {
                this.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(c.code));
                    return
                }
                var b = new SYNO.SDS.MARIADB10.ChangePasswordWindow({
                    owner: this.owner,
                    users: c.user,
                    dbpass: a
                });
                b.open();
                this.close()
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.MARIADB10.ResetPasswordWindow", {
    extend: "SYNO.SDS.MARIADB10.PasswordWindow",
    mainPanel: null,
    constructor: function(a) {
        this.title = SYNO.SDS.MARIADB10.GetString("ui", "reset_root_password");
        this.mainPanel = new SYNO.SDS.MARIADB10.ResetPasswordPanel({
            owner: this
        });
        this.callParent(arguments)
    },
    clickAction: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "reset_root_password",
            encryption: ["password"],
            params: {
                password: this.mainPanel.getForm().findField("password").getValue()
            },
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(a.code));
                    return
                }
                this.close()
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.MARIADB10.ResetPasswordPanel", {
    extend: "SYNO.SDS.MARIADB10.PasswordPanel",
    constructor: function(a) {
        this.itemsArray = [];
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.MARIADB10.RemoveDatabaseWindow", {
    extend: "SYNO.SDS.MARIADB10.PasswordWindow",
    mainPanel: null,
    constructor: function(a) {
        this.title = SYNO.SDS.MARIADB10.GetString("ui", "reset_database");
        this.mainPanel = new SYNO.SDS.MARIADB10.RemoveDatabasePanel({
            owner: this
        });
        this.callParent(arguments)
    },
    clickAction: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "rebuild",
            encryption: ["password"],
            params: {
                password: this.mainPanel.getForm().findField("password").getValue()
            },
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(a.code));
                    return
                }
                this.close()
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.MARIADB10.RemoveDatabasePanel", {
    extend: "SYNO.SDS.MARIADB10.PasswordPanel",
    constructor: function(a) {
        this.itemsArray = [];
        this.itemsArray.push({
            xtype: "syno_displayfield",
            value: SYNO.SDS.MARIADB10.GetString("ui", "reset_database_desc")
        });
        this.callParent(arguments)
    }
});
Ext.ns("SYNO.SDS.MARIADB10");
SYNO.SDS.MARIADB10.GetString = function(b, a) {
    if (b === "ui") {
        return _TT("SYNO.SDS.MARIADB10.Instance", b, a)
    }
    return _T(b, a)
};
Ext.form.VTypes.portWithAutoText = String.format(SYNO.SDS.MARIADB10.GetString("ui", "bad_port"), "1024", "65535");
Ext.form.VTypes.portWithAuto = function(b) {
    var a = parseInt(b, 10);
    return 1024 <= a && a <= 65535
};
/**
 * @class SYNO.SDS.MARIADB10.Instance
 * @extends SYNO.SDS.AppInstance
 * MariaDB10 application instance class
 *
 */  
Ext.define("SYNO.SDS.MARIADB10.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.MARIADB10.Main",
    constructor: function() {
        this.callParent(arguments)
    }
});
SYNO.SDS.MARIADB10.GetErrorString = function(b, a) {
    switch (b) {
        case 1000:
        case 1001:
            return SYNO.SDS.MARIADB10.GetString("error", "error_unknown");
        case 1002:
            return SYNO.SDS.MARIADB10.GetString("ui", "db_connect_error");
        case 1003:
            return String.format(SYNO.SDS.MARIADB10.GetString("ui", "container_port_conflict"), a);
        default:
            return SYNO.SDS.MARIADB10.GetString("error", "error_unknown")
    }
};
Ext.define("SYNO.SDS.MARIADB10.Main", {
    extend: "SYNO.SDS.AppWindow",
    appInstance: null,
    mainPanel: null,
    constructor: function(a) {
        this.appInstance = a.appInstance;
        this.mainPanel = new SYNO.SDS.MARIADB10.MainPanel({
            owner: this
        });
        var b = Ext.apply({
            resizable: false,
            maximizable: false,
            minimizable: true,
            width: 600,
            height: 500,
            layout: "fit",
            items: [this.mainPanel]
        }, a);
        this.callParent([b])
    }
});
Ext.define("SYNO.SDS.MARIADB10.MainPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        var b = Ext.apply({
            border: false,
            useDefaultBtn: true,
            items: [{
                xtype: "syno_fieldset",
                itemId: "fieldset",
                title: SYNO.SDS.MARIADB10.GetString("ui", "user_db"),
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "button_desc",
                    value: SYNO.SDS.MARIADB10.GetString("ui", "action_desc")
                }, {
                    xtype: "syno_button",
                    itemId: "change_btn",
                    text: SYNO.SDS.MARIADB10.GetString("ui", "change_user_password"),
                    handler: function() {
                        var c = new SYNO.SDS.MARIADB10.LoginWindow({
                            owner: this.owner
                        });
                        c.open()
                    },
                    scope: this
                }, {
                    xtype: "syno_button",
                    itemId: "reset_password_btn",
                    text: SYNO.SDS.MARIADB10.GetString("ui", "reset_root_password"),
                    handler: function() {
                        var c = new SYNO.SDS.MARIADB10.ResetPasswordWindow({
                            owner: this.owner
                        });
                        c.open()
                    },
                    scope: this
                }, {
                    xtype: "syno_button",
                    itemId: "delete_btn",
                    btnStyle: "red",
                    text: SYNO.SDS.MARIADB10.GetString("ui", "reset_database"),
                    handler: function() {
                        var c = new SYNO.SDS.MARIADB10.RemoveDatabaseWindow({
                            owner: this.owner
                        });
                        c.open()
                    },
                    scope: this
                }]
            }, {
                xtype: "syno_fieldset",
                itemId: "info",
                title: SYNO.SDS.MARIADB10.GetString("ui", "information"),
                items: [{
                    name: "enable_networking",
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.MARIADB10.GetString("ui", "enable_tcp_ip_connection")
                }, {
                    name: "port",
                    indent: 1,
                    xtype: "syno_numberfield",
                    vtype: "portWithAuto",
                    fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "port")
                }, {
                    itemId: "socket_setting",
                    xtype: "syno_displayfield",
                    fieldLabel: SYNO.SDS.MARIADB10.GetString("ui", "socket"),
                    value: "/run/mysqld/mysqld.sock"
                }]
            }]
        }, a);
        this.owner = a.owner;
        this.callParent([b])
    },
    doLoad: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "get_info",
            params: {},
            callback: function(d, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(c.code))
                } else {
                    var a = c.port;
                    var b = c.skip_networking;
                    this.getForm().setValues({
                        port: a,
                        enable_networking: !b
                    })
                }
            },
            scope: this
        })
    },
    addTip: function() {
        SYNO.SDS.Utils.AddTip(this.getForm().findField("enable_networking").getEl(), SYNO.SDS.MARIADB10.GetString("ui", "tooltip_enable_tcp_ip_connection"))
    },
    applyHandler: function(c, a) {
        if (false === this.onBeforeAction(this.getForm(), "set")) {
            return false
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.MARIADB10.GetString("common", "msg_waiting")
        });
        var d = this.getForm().getValues();
        var b = parseInt(d.port, 10);
        if (b) {
            d.port = b
        }
        if (d.enable_networking) {
            d.skip_networking = 0
        } else {
            d.skip_networking = 1
        }
        d.enable_networking = null;
        this.sendWebAPI({
            api: "SYNO.MariaDB10.lib",
            version: 1,
            method: "apply",
            params: d,
            callback: function(f, e) {
                this.owner.clearStatusBusy();
                if (!f) {
                    if (e.code === 1003) {
                        this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(e.code, b))
                    } else {
                        this.owner.getMsgBox().alert(this.owner.title, SYNO.SDS.MARIADB10.GetErrorString(e.code))
                    }
                    return
                }
                this.doLoad()
            },
            scope: this
        })
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function() {
            this.checkPort = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_networking", ["port"]);
            this.addTip();
            this.doLoad()
        }, this, {
            single: true
        })
    }
});
