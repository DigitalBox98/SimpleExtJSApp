/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Backup.Client.Fuse.MountWindow
 * @extends SYNO.SDS.ModalWindow
 * HyperBackup client fuse mount window class
 *
 */
Ext.define("SYNO.SDS.Backup.Client.Fuse.MountWindow", {
    version: 1,
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.panel = this.getComponent("formpanel");
        this.defineBehaviors()
    },
    fillConfig: function(a) {
        var d = [{
            xtype: "container",
            cls: "syno-sds-backup-fuse-mount-to",
            layout: "column",
            itemId: "mount_point_path_field",
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-sds-backup-fuse-mount-to-label",
                width: 195,
                height: 28,
                value: SYNO.SDS.Backup.Client.Fuse.Utils.GetString("fuse", "mp_label") + ":"
            }, {
                xtype: "syno_textfield",
                cls: "syno-sds-backup-fuse-mount-to-textfield selectabletext",
                name: "mount_point",
                width: 350,
                height: 30,
                readOnly: true
            }, {
                xtype: "syno_button",
                cls: "syno-sds-backup-fuse-mount-to-btn",
                width: 107,
                text: SYNO.SDS.Backup.Client.Fuse.Utils.GetString("fuse", "browse"),
                scope: this,
                handler: this.openFolderSelector
            }]
        }, {
            xtype: "syno_textfield",
            name: "mount_point_real_path",
            hidden: true
        }, {
            xtype: "syno_textfield",
            name: "abs_path",
            hidden: true
        }, {
            xtype: "syno_textfield",
            name: "target_id",
            hidden: true
        }, {
            xtype: "container",
            cls: "syno-sds-backup-fuse-password",
            layout: "column",
            itemId: "manual_passwd",
            hidden: true,
            hideLabel: true,
            items: [{
                xtype: "syno_radio",
                cls: "syno-sds-backup-fuse-password-label",
                name: "decrypt_method",
                width: 195,
                height: 28,
                inputValue: "manual",
                boxLabel: SYNO.SDS.Backup.Client.Fuse.Utils.GetString("app", "task_password_input"),
                checked: true
            }, {
                xtype: "syno_textfield",
                cls: "syno-sds-backup-fuse-password-textfield",
                textType: "password",
                name: "password",
                width: 350,
                height: 30,
                minLength: 8,
                maxLength: 64,
                allowBlank: false
            }]
        }, {
            xtype: "container",
            cls: "syno-sds-backup-fuse-keyfile",
            layout: "column",
            itemId: "keyfile_passwd",
            hidden: true,
            hideLabel: true,
            items: [{
                xtype: "syno_radio",
                cls: "syno-sds-backup-fuse-keyfile-label",
                name: "decrypt_method",
                width: 195,
                height: 28,
                inputValue: "keyfile",
                boxLabel: SYNO.SDS.Backup.Client.Fuse.Utils.GetString("app", "task_private_input")
            }, {
                xtype: "syno_filebutton",
                cls: "syno-sds-backup-fuse-keyfile-file-btn",
                height: 30,
                allowBlank: false,
                name: "private_key",
                buttonConfig: {
                    width: 107
                },
                textConfig: {
                    width: 334
                }
            }]
        }, {
            xtype: "syno_displayfield",
            cls: "syno-sds-backup-fuse-notice-message",
            name: "notice_message",
            htmlEncode: false,
            value: '<span class="red-status">' + SYNO.SDS.Backup.Client.Fuse.Utils.GetString("fuse", "ro_warning") + "</span>"
        }];
        var c = new SYNO.SDS.Utils.FormPanel({
            itemId: "formpanel",
            fileUpload: true,
            webapi: {
                api: "SYNO.SDS.Backup.Client.Fuse.Target",
                method: "mount_by_private",
                version: 1,
                scope: this
            },
            items: d,
            onApiSuccess: this.onActionComplete,
            onApiFailure: this.onFormFailed
        });
        var b = {
            width: 710,
            height: 280,
            resizable: false,
            title: SYNO.SDS.Backup.Client.Fuse.Utils.GetString("fuse", "mount_window_title"),
            cls: SYNO.SDS.Backup.Client.Fuse.Utils.GetFuseCls() + " syno-sds-backup-fuse",
            layout: "fit",
            items: c,
            keys: [{
                key: Ext.EventObject.ENTER,
                scope: this,
                handler: this.onSubmit
            }],
            buttons: [{
                itemId: "cancel",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                itemId: "apply",
                btnStyle: "blue",
                text: _T("common", "ok"),
                scope: this,
                handler: this.onSubmit
            }]
        };
        Ext.apply(b, a);
        return b
    },
    defineBehaviors: function() {
        this.mon(this, "afterlayout", function(a, c) {
            var b = this.panel.getForm();
            new SYNO.ux.Utils.EnableRadioGroup(b, "decrypt_method", {
                manual: ["password"],
                keyfile: ["private_key"]
            })
        }, this, {
            single: true
        })
    },
    getErrString: function(a) {
        if (a.errors && a.errors.sec && a.errors.key) {
            return SYNO.SDS.Backup.Client.Fuse.Utils.GetString(a.errors.sec, a.errors.key)
        } else {
            return SYNO.SDS.Backup.Client.Fuse.Utils.GetErrorString(a.code)
        }
    },
    responseError: function(a) {
        if (a.code === SYNO.SDS.Backup.ERR_TARGET_EXIST) {
            this.getMsgBox().confirm(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Fuse.Utils.GetString("fuse", "redirect_confirm"), function(b) {
                if (b !== "yes") {
                    this.close();
                    return
                }
                SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                    opendir: a.errors.mount_point
                }, true);
                this.close()
            }, this);
            return
        }
        this.setStatusError({
            text: this.getErrString(a)
        })
    },
    onOpen: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Fuse.Target",
            version: 1,
            method: "get_avail_mountpoint",
            params: {
                target_id: this.target_id,
                abs_path: this.repo_path
            },
            callback: function(c, a, b) {
                if (!c) {
                    this.clearStatusBusy();
                    this.getMsgBox().alert(_T("leaf", "backup"), this.getErrString(a), function() {
                        this.close()
                    }, this);
                    return
                }
                this.panel.getForm().setValues(a);
                this.data_enc = this.data_enc || a.is_enc;
                if (this.data_enc) {
                    this.panel.getComponent("manual_passwd").show();
                    this.panel.getComponent("keyfile_passwd").show();
                    this.panel.getForm().findField("password").focus(false, 100)
                }
                this.clearStatusBusy()
            },
            scope: this
        });
        this.callParent(arguments)
    },
    onSubmit: function() {
        var c;
        var a;
        var b = this.panel.getForm();
        b.findField("abs_path").setValue(this.repo_path);
        b.findField("target_id").setValue(this.target_id);
        if (this.data_enc) {
            if (!b.isValid()) {
                return
            }
            c = b.findField("decrypt_method").getGroupValue();
            if (c === "keyfile") {
                if (!b.findField("private_key").getValue()) {
                    return
                }
                this.setStatusBusy({
                    text: _T("common", "msg_waiting")
                });
                this.get("formpanel").upload();
                return
            } else {
                a = b.findField("password").getValue();
                if (!a) {
                    return
                }
            }
        } else {
            b.findField("decrypt_method").disable()
        }
        this.doSubmitEncryption(c, a)
    },
    doSubmitEncryption: function(c, a) {
        var b = {};
        Ext.copyTo(b, this.panel.getForm().getValues(), ["mount_point_real_path", "abs_path", "target_id", "password"]);
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Fuse.Target",
            version: "1",
            method: "mount_by_password",
            encryption: this.data_enc ? ["password"] : undefined,
            params: b,
            scope: this,
            callback: function(h, e, g, f) {
                if (!h) {
                    this.clearStatusBusy();
                    this.responseError(e);
                    return
                }
                var d = this.callback;
                this.clearStatusBusy();
                this.close();
                if (Ext.isFunction(d)) {
                    d(e)
                }
            }
        })
    },
    onActionComplete: function(c, b, a) {
        if (Ext.isFunction(this.ownerCt.callback)) {
            this.ownerCt.callback(b)
        }
        this.ownerCt.clearStatusBusy();
        this.ownerCt.close()
    },
    onFormFailed: function(c, b, a) {
        this.ownerCt.clearStatusBusy();
        this.ownerCt.responseError(b);
        return false
    },
    openFolderSelector: function() {
        var a = new SYNO.SDS.Utils.FileChooser.Chooser({
            title: _T("common", "choose"),
            owner: this,
            folderToolbar: true,
            enumColdStorage: true,
            usage: {
                type: "chooseDir"
            },
            listeners: {
                scope: this,
                choose: this.onFolderSelected
            }
        });
        a.show()
    },
    onFolderSelected: function(c, b) {
        var a = b.fullpath;
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Fuse.Target",
            version: 1,
            method: "get_avail_mountpoint",
            params: {
                target_id: this.target_id,
                abs_path: this.repo_path,
                mount_point_parent: a
            },
            callback: function(f, d, e) {
                if (!f) {
                    this.clearStatusBusy();
                    this.responseError(d);
                    return
                }
                this.panel.getForm().setValues(d);
                this.clearStatusBusy()
            },
            scope: this
        });
        c.close()
    }
});
Ext.ns("SYNO.SDS.Backup.Client.Fuse.Utils");
Ext.apply(SYNO.SDS.Backup.Client.Fuse.Utils, {
    isTarget: function(a, c) {
        var b = a.split(".");
        if (1 === b.length) {
            return false
        }
        var d = b[b.length - 1].toLowerCase();
        if (c) {
            if ("hbk" !== d) {
                return false
            }
        } else {
            if ("bkpi" !== d) {
                return false
            }
        }
        return true
    },
    isThisPkgNewer: function() {
        if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Backup.Application")) {
            return false
        }
        if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.BackupService.Instance")) {
            return true
        }
        var b = 0;
        var a = SYNO.SDS.Backup.Client.Fuse.MountWindow.prototype.version;
        if (SYNO.SDS.Backup.Server && SYNO.SDS.Backup.Server.Fuse && SYNO.SDS.Backup.Server.Fuse.MountWindow) {
            b = SYNO.SDS.Backup.Server.Fuse.MountWindow.prototype.version
        }
        if (a <= b) {
            return false
        }
        return true
    },
    bundleCheckFn: function(a, b) {
        if (!_S("is_admin")) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isThisPkgNewer()) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isTarget(b[0].get("filename"), b[0].get("isdir"))) {
            return false
        }
        return true
    },
    bundleLaunchFn: function(d) {
        var f = d[0].get("real_path");
        var a = f.split("/");
        var e = "";
        var c = "";
        if (d[0].get("isdir")) {
            e = a.slice(0, -1).join("/");
            c = a[a.length - 1]
        } else {
            e = a.slice(0, -2).join("/");
            c = a[a.length - 2]
        }
        var b = new SYNO.SDS.Backup.Client.Fuse.MountWindow({
            owner: this.owner,
            repo_path: e,
            target_id: c,
            callback: Ext.createDelegate(function(g) {
                if (g && g.mount_point) {
                    this.onChangeDir(g.mount_point)
                } else {
                    SYNO.Debug("unexpected data", g)
                }
            }, this)
        });
        b.open()
    },
    vtCheckFn: function(a, b) {
        if (!_S("is_admin")) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isThisPkgNewer()) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isVT(b[0].get("mountType"))) {
            return false
        }
        return true
    },
    vtLaunchFn: function(d) {
        var c = d[0].get("real_path");
        var b = "/" + d[0].get("path").split("/")[1];
        var a = function(g, e, f) {
            if (!g) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(e.code));
                return
            }
            this.refreshTreeNode([b], true);
            this.refreshGrid();
            this.owner.clearStatusBusy()
        };
        this.owner.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("fuse", "umount_confirm"), function(e) {
            if (e !== "yes") {
                return
            }
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.SDS.Backup.Client.Fuse.Target",
                version: 1,
                method: "umount",
                params: {
                    mount_point_real_path: c
                },
                callback: a,
                scope: this
            })
        }, this)
    },
    isVT: function(a) {
        if (a !== "bkpfuse") {
            return false
        }
        return true
    },
    vtGetIconFn: function(b, c, a) {
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isVT(c.get("mountType"))) {
            return false
        }
        if (SYNO.SDS.UIFeatures.test("isRetina")) {
            return "webman/3rdparty/HyperBackup/images/2x/mount_point_icon.png"
        } else {
            return "webman/3rdparty/HyperBackup/images/1x/mount_point_icon.png"
        }
    },
    vtCheckThumbnailFn: function(a) {
        if (!SYNO.SDS.Backup.Client.Fuse.Utils.isVT(a.mountType)) {
            return false
        }
        return true
    },
    vtGetThumbnailFn: function() {
        if (SYNO.SDS.UIFeatures.test("isRetina")) {
            return "webman/3rdparty/HyperBackup/images/2x/mount_point_thumb.png"
        } else {
            return "webman/3rdparty/HyperBackup/images/1x/mount_point_thumb.png"
        }
    },
    GetErrorString: function(a, b) {
        if (SYNO.SDS.Backup.GetErrorString) {
            return SYNO.SDS.Backup.GetErrorString(a, b)
        } else {
            return ""
        }
    },
    GetString: function(b, a) {
        if (SYNO.SDS.Backup.String) {
            return SYNO.SDS.Backup.String(b, a)
        } else {
            return ""
        }
    },
    GetFuseCls: function() {
        return "syno-sds-backup-client-fuse"
    }
});
