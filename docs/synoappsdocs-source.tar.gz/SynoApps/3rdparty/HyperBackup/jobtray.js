/* Copyright (c) 2020 Synology Inc. All rights reserved. */

(function() {
    var a = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    var c = SYNO.SDS.Backup.Client.Explore.Utils.GetJobTrayCls;
    var b = function(e) {
        if ("copy" === e) {
            return a("explorer", "tray_copy_status")
        } else {
            if ("restore" === e) {
                return a("explorer", "tray_restore_status")
            } else {
                if ("download" === e) {
                    return a("explorer", "tray_download_status")
                } else {
                    return a("explorer", "tray_wait_status")
                }
            }
        }
    };
    var d = function(e) {
        if ("waiting" === e) {
            return "waiting"
        } else {
            return "running"
        }
    };
    Ext.define("SYNO.SDS.Backup.Client.JobTray.AppInstance", {
        extend: "SYNO.SDS.AppInstance",
        appTrayItemName: "SYNO.SDS.Backup.Client.JobTray.TrayItem",
        start: function(e) {
            this.trayItem.monitor(e)
        },
        addDownloadId: function(e) {
            this.trayItem.addDownloadId(e)
        },
        isPreparingDownload: function() {
            return !Ext.isEmpty(this.trayItem.getDownloadIds())
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.JobTray.TrayItem", {
        extend: "SYNO.SDS.Tray.ArrowTray",
        downloadIds: {},
        panelAlign: "t-b",
        constructor: function() {
            this.launched = false;
            this.jsConfig = {};
            this.jsConfig.iconCls = "sds-tray-item-ani-upload";
            this.cancelList = [];
            this.callParent(arguments)
        },
        initPanel: function() {
            var e = new SYNO.SDS.Backup.Client.JobTray.Panel({
                cls: c() + " syno-sds-backup-jobtray-panel",
                trayitem: this
            });
            return e
        },
        monitor: function(e) {
            Ext.apply(this, e);
            this.setTaskButtonVisible(true);
            this.onStopPolling();
            this.onStartPolling();
            this.launched = false
        },
        addDownloadId: function(e) {
            this.downloadIds[e] = true
        },
        onBeforeDestroy: function() {
            this.onStopPolling();
            this.callParent(arguments)
        },
        onStartPolling: function() {
            if (!this.pollingID) {
                this.pollingID = this.pollReg({
                    webapi: {
                        api: "SYNO.SDS.Backup.Client.Explore.Job",
                        version: 1,
                        method: "list",
                        params: {
                            backend: this.backend,
                            download_ids: this.getDownloadIds()
                        }
                    },
                    interval: 2,
                    immediate: true,
                    scope: this,
                    status_callback: this.onPollingDone
                })
            }
        },
        onStopPolling: function() {
            if (!this.pollingID) {
                return
            }
            this.pollUnreg(this.pollingID);
            this.pollingID = null
        },
        onPollingDone: function(i, f, h, g) {
            if (!i) {}
            var e = this.cancelList;
            f.job_list = f.job_list.filter(function(j) {
                return (0 > e.indexOf(j.id))
            });
            this.panel.store.loadData(f);
            this.updateDownloadIds(f.job_list);
            this.updateView(f.job_list.length)
        },
        getDownloadIds: function() {
            var e = [];
            Ext.iterate(this.downloadIds, function(f, g) {
                e.push(f)
            });
            return e
        },
        updateDownloadIds: function(e) {
            var f = {};
            Ext.each(e, function(g) {
                if ("download" !== g.status) {
                    return true
                }
                f[g.download_id] = true
            });
            this.downloadIds = f
        },
        updateView: function(e) {
            if (9 < e) {
                e = 9
            }
            this.panel.setHeight(e * 83 + 43);
            this.panel.updateScroller();
            if (0 === e) {
                this.hideTrayIcon()
            } else {
                if (!this.launched) {
                    this.showTrayIcon()
                }
            }
        },
        hideTrayIcon: function() {
            this.taskButton.toggle(false);
            this.panel.hide();
            this.setTaskButtonVisible(false);
            this.onStopPolling();
            this.launched = false;
            this.cancelList = []
        },
        showTrayIcon: function() {
            this.panel.show();
            this.panel.el.anchorTo(this.taskButton.el, this.arrowAlignPosition, [0, 11]);
            this.launched = true
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.JobTray.Panel", {
        extend: "SYNO.SDS.Tray.Panel",
        width: 304,
        layout: "fit",
        style: "padding: 0",
        autoFlexcroll: true,
        constructor: function() {
            this.callParent(arguments);
            this.addClass("syno-ux-panel")
        },
        scrollTo: function(e) {
            this.fleXcrollTo(e)
        },
        initComponent: function() {
            this.callParent(arguments);
            this.gridPanel = new SYNO.SDS.Backup.Client.JobTray.GridPanel({
                plugins: [new SYNO.CellActions({
                    actionWidth: 24,
                    tpl: '<div class="ux-cell-value"><div class="ux-cell-actions"><tpl for="actions"><div class="ux-cell-action {cls}" ext:qtip="{qtip}" style="{style}">&nbsp;</div></tpl></div></div>',
                    listeners: {
                        action: {
                            fn: function(e, i, h, g) {
                                var j = e.getSelectionModel();
                                var f = e.store;
                                j.selectRow(f.indexOf(i), true);
                                this.removeTask(f, i)
                            },
                            scope: this
                        }
                    },
                    isRecordAlreadyClicked: function() {
                        return true
                    },
                    align: "center"
                })],
                colModel: this.initColumnModel(),
                store: this.getStore(),
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: true
                }),
                autoHeight: true,
                title: a("app", "backup_explorer"),
                bbar: []
            });
            this.add(this.gridPanel)
        },
        removeTask: function(e, f) {
            this.sendWebAPI({
                api: "SYNO.SDS.Backup.Client.Explore.Job",
                version: 1,
                method: "cancel",
                params: {
                    unique: f.data.unique,
                    backend: this.trayitem.backend
                }
            });
            e.remove(f);
            this.trayitem.cancelList.push(f.data.id);
            this.trayitem.updateView(e.getCount())
        },
        getStore: function() {
            if (!this.store) {
                this.store = new Ext.data.JsonStore({
                    root: "job_list",
                    fields: ["id", "unique", "name", "processed_size", "total_size", "status", "can_cancel"],
                    autoDestroy: true,
                    idProperty: "id",
                    listeners: {
                        load: {
                            scope: this,
                            fn: function(f, e) {
                                Ext.each(e, function(h) {
                                    if (!h.data.can_cancel) {
                                        var g = this.gridPanel.getStore();
                                        this.gridPanel.getView().getRow(g.indexOf(h)).classList.add("disable-cancel")
                                    }
                                }, this)
                            }
                        }
                    }
                })
            }
            return this.store
        },
        initColumnModel: function() {
            var e = new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: true,
                    sortable: false
                },
                columns: [{
                    id: "name",
                    dataIndex: "id",
                    align: "left",
                    width: 249,
                    renderer: this.nameRenderer.createDelegate(this),
                    scope: this
                }, {
                    dataIndex: "id",
                    align: "left",
                    css: "vertical-align: bottom;",
                    width: 35,
                    cellActions: [{
                        iconCls: "sds-progress-cancel",
                        qtip: _T("common", "cancel")
                    }]
                }]
            });
            return e
        },
        nameRenderer: function(h, l, i, n, e, m) {
            var f = 0;
            if (0 < i.data.total_size) {
                f = Math.floor((i.data.processed_size / i.data.total_size) * 100)
            }
            var j = new SYNO.SDS.Utils.ProgressBar({
                barWidth: 185,
                barHeight: 16,
                showValueText: true
            });
            var g = b(i.data.status);
            var k = new Ext.XTemplate('<div class="jobtray-item"><div class="jobtray-file-text">{name}</div><div class="jobtray-status-text {statusCss}">{statusText}</div></div><table><tbody><tr><td>{progressBar}</td></tr></tbody></table>');
            return k.apply({
                name: SYNO.SDS.Backup.Explore.widthEllipsis(i.data.name, 256),
                statusText: g,
                statusCss: d(i.data.status),
                progressBar: j.fill(f),
                invvalue: 100 - f
            })
        }
    });
/**
 * @class SYNO.SDS.Backup.Client.JobTray.GridPanel
 * @extends SYNO.ux.GridPanel
 * HyperBackup client jobtray grid panel 
 *
 */    
    Ext.define("SYNO.SDS.Backup.Client.JobTray.GridPanel", {
        extend: "SYNO.ux.GridPanel",
        cls: "jobtray-grid-panel",
        hideHeaders: true,
        header: true,
        forceFit: true,
        getView: function() {
            if (!this.view) {
                this.view = new SYNO.ux.FleXcroll.grid.GridView(Ext.apply(this.viewConfig || {}, {
                    autoFlexcroll: false,
                    initTemplates: function() {
                        Ext.grid.GridView.prototype.initTemplates.apply(this, arguments);
                        var e = ['<tr class="x-grid3-row-body-tr" style="{bodyStyle}">', '<td colspan="{cols}" class="x-grid3-body-cell" tabIndex="0" hidefocus="on">', '<div class="x-grid3-row-body">{body}</div>', "</td>", "</tr>"].join(""),
                            f = ['<table class="x-grid3-row-table" border="0" cellspacing="0" cellpadding="0" style="{tstyle}">', "<tbody>", "<tr>{cells}</tr>", this.enableRowBody ? e : "", "</tbody>", "</table>"].join("");
                        this.templates.row = new Ext.Template('<div class="x-grid3-row {alt}" style="{tstyle}">' + f + "</div>");
                        this.templates.row.disableFormats = true;
                        this.templates.row.compile()
                    },
                    onLayout: function() {
                        this.scrollOffset = 0;
                        this.fitColumns(false)
                    }
                }))
            }
            return this.view
        }
    })
})();
