/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Backup.Client.Common.Utils");
Ext.apply(SYNO.SDS.Backup.Client.Common.Utils, {
    GetErrorString: function(a, b) {
        if (SYNO.SDS.Backup.GetErrorString) {
            return SYNO.SDS.Backup.GetErrorString(a, b)
        } else {
            return ""
        }
    },
    GetString: function(b, a) {
        if (SYNO.SDS.Backup.String) {
            return SYNO.SDS.Backup.String(b, a)
        } else {
            return ""
        }
    },
    GetVersionApi: function() {
        return "SYNO.Backup.Version"
    },
    LaunchExplorer: function(b, c) {
        var a = b.owner.getCurrentTask();
        SYNO.SDS.AppLaunch("SYNO.SDS.Backup.Client.Explore.AppInstance", {
            launchInstance: b,
            taskId: b.taskId,
            defaultVersion: c,
            sess_id: a.sess_id,
            sess_key: a.sess_key,
            launcher: "BackupAndRestore",
            backend: "HyperBackup-backend"
        })
    }
});
/**
 * @class SYNO.SDS.Backup.Client.Common.FormPanel
 * @extends SYNO.ux.FormPanel
 * HyperBackup client common form panel
 *
 */
Ext.define("SYNO.SDS.Backup.Client.Common.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    initEvents: function() {
        this.callParent(arguments);
        this.initFieldGroup()
    },
    initFieldGroup: function() {
        var a = {},
            b = {};
        this.getForm().items.each(function(c) {
            if (c instanceof SYNO.ux.Radio && Ext.isArray(c.groupFields)) {
                a[c.name] = a[c.name] || {};
                a[c.name][c.inputValue] = c.groupFields
            }
            if (c instanceof SYNO.ux.Checkbox && Ext.isObject(c.groupFields)) {
                b[c.name] = [];
                b[c.name][0] = c.groupFields.enable;
                b[c.name][1] = c.groupFields.disable
            }
        });
        this.mon(this, "afterlayout", function() {
            var c;
            Ext.iterate(a, function(e, d) {
                c = new SYNO.ux.Utils.EnableRadioGroup(this.getForm(), e, d)
            }, this);
            Ext.iterate(b, function(d, e) {
                c = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), d, e[0], e[1])
            }, this)
        }, this, {
            single: true
        })
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Tag", {
    extend: "Ext.Container",
    cls: "syno-backup-client-common-tag-item-container",
    constructor: function(a) {
        this.read_only = a.read_only;
        this.callParent([a])
    },
    initComponent: function() {
        this.callParent(arguments);
        this.tag = new Ext.Container({
            cls: "syno-backup-tag-item",
            style: {
                "max-width": (this.maxWidth) ? this.maxWidth.toString() + "px" : "none",
                padding: this.read_only ? "0px 8px 0px 8px" : "0px 26px 0px 8px"
            },
            html: this.htmlEncode(this.text),
            listeners: {
                afterrender: function(b) {
                    var c = b.getEl();
                    c.dom.setAttribute("tabindex", "-1");
                    c.addClassOnOver("hover");
                    c.on("focus", function() {
                        b.addClass("focus")
                    });
                    c.on("blur", function() {
                        b.removeClass("focus")
                    })
                }
            }
        });
        var a = this;
        if (!this.read_only) {
            this.tagClose = new Ext.Container({
                cls: "syno-ux-superboxselect-item-close",
                listeners: {
                    afterrender: function(b) {
                        b.getEl().on("click", function() {
                            a.destroySelf()
                        })
                    }
                }
            });
            this.tag.add(this.tagClose)
        }
        this.add(this.tag)
    },
    htmlEncode: function(b) {
        var a = Ext.util.Format.htmlEncode(b);
        return a.replace(/ /g, "&nbsp")
    },
    destroySelf: function() {
        if (Ext.isDefined(this.callback)) {
            this.callback(this.text)
        }
        this.destroy()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.QuickTip", {
    extend: Ext.QuickTip,
    tagConfig: {
        namespace: "",
        attribute: "synotcqtip",
        width: "qwidth",
        target: "target",
        title: "qtitle",
        hide: "hide",
        cls: "qclass",
        align: "qalign",
        anchor: "anchor"
    }
});
SYNO.SDS.Backup.Client.Common.QuickTips = function() {
    var b, a = false;
    return {
        init: function(c) {
            if (!b) {
                if (!Ext.isReady) {
                    Ext.onReady(function() {
                        SYNO.SDS.Backup.Client.Common.QuickTips.init(c)
                    });
                    return
                }
                b = new SYNO.SDS.Backup.Client.Common.QuickTip({
                    elements: "header,body",
                    disabled: a
                });
                if (c !== false) {
                    b.render(Ext.getBody())
                }
            }
        },
        ddDisable: function() {
            if (b && !a) {
                b.disable()
            }
        },
        ddEnable: function() {
            if (b && !a) {
                b.enable()
            }
        },
        enable: function() {
            if (b) {
                b.enable()
            }
            a = false
        },
        disable: function() {
            if (b) {
                b.disable()
            }
            a = true
        },
        isEnabled: function() {
            return b !== undefined && !b.disabled
        },
        getQuickTip: function() {
            return b
        },
        register: function() {
            b.register.apply(b, arguments)
        },
        unregister: function() {
            b.unregister.apply(b, arguments)
        },
        tips: function() {
            b.register.apply(b, arguments)
        }
    }
}();
Ext.define("SYNO.SDS.Backup.Client.Common.Space.Chart", {
    extend: "Ext.BoxComponent",
    constructor: function(a) {
        SYNO.SDS.Backup.Client.Common.QuickTips.init();
        var b = this.svgConfig || {
            width: this.width,
            height: this.height
        };
        this.cls = a.cls || "chart";
        this.svgWidth = Ext.isNumber(b.width) ? b.width : "100%";
        this.svgHeight = Ext.isNumber(b.height) ? b.height : "100%";
        this.svgMargins = this.svgConfig && this.svgConfig.margin ? this.svgConfig.margin : {
            top: 0,
            bottom: 0,
            left: 0,
            right: 0
        };
        this.callParent(a);
        this.colorArray = SYNO.SDS.Backup.Client.Common.Utils.Space.Config.COLORS;
        this.d3 = SYNO.SDS.DataDrivenDocuments.DrawHelper
    },
    innerFormatValue: function(a) {
        return Ext.isNumber(a) ? a : 0
    },
    onRender: function(b, a) {
        var c = this.d3;
        this.callParent(arguments);
        this.svg = c.select("#" + this.id).attr("class", this.cls).append("svg").attr("width", this.svgWidth).attr("height", this.svgHeight);
        var e = this.innerFormatValue(this.svgMargins.left);
        var d = this.innerFormatValue(this.svgMargins.top);
        this.svgGraphics = this.svg.append("g").attr("transform", "translate(" + e + "," + d + ")")
    },
    afterRender: function() {
        this.callParent(arguments);
        this.loadData()
    },
    onResize: function(d, b, a, c) {
        this.callParent(arguments);
        this.draw()
    },
    loadData: Ext.emptyFn,
    draw: Ext.emptyFn
});
Ext.define("SYNO.SDS.Backup.Client.Common.Space.PieChart", {
    extend: "SYNO.SDS.Backup.Client.Common.Space.Chart",
    svgConfig: {
        margin: {
            top: 0,
            left: 0,
            right: 0,
            bottom: 0
        },
        border: 2,
        shadow: 1,
        width: 166,
        height: 166,
        radius: 80
    },
    constructor: function(a) {
        Ext.apply(this, a);
        this.callParent(arguments);
        this.data = []
    },
    loadData: function(c, b, a) {
        if (!Ext.isDefined(c)) {
            return
        }
        this.data = c;
        this.totalSize = a;
        this.draw(b)
    },
    initShadowEffect: function() {
        var b = this.svg;
        var a = b.append("defs");
        this.shadowId = "shadow" + Ext.id();
        var c = a.append("filter").attr("id", this.shadowId);
        c.append("feGaussianBlur").attr("in", "SourceAlpha").attr("stdDeviation", 2).attr("result", "blur");
        c.append("feOffset").attr("in", "blur").attr("dx", 0).attr("dy", 0).attr("result", "offsetBlur");
        var d = c.append("feMerge");
        d.append("feMergeNode").attr("in", "offsetBlur");
        d.append("feMergeNode").attr("in", "SourceGraphic");
        this.svgShadow = a
    },
    draw: function(v) {
        if (!v) {
            return
        }
        var u = this.d3,
            m = this.svgConfig.width,
            l = this.svgConfig.height,
            b = this.svgConfig.radius,
            n = this.svgConfig.border,
            h = (b + this.svgConfig.margin.left + this.svgConfig.border + this.svgConfig.shadow),
            g = (b + this.svgConfig.margin.top + this.svgConfig.border + this.svgConfig.shadow);
        var o = this.colorArray;
        if (this.svgGraphics) {
            this.svgGraphics.remove();
            this.svgGraphics = null
        }
        if (!this.svgShadow) {
            this.initShadowEffect()
        }
        this.svgEle = this.svg.data([v]).attr("width", m).attr("height", l);
        this.svgGraphics = this.svgEle.append("svg:g").attr("transform", "translate(" + h + "," + g + ")");
        if (!Ext.isEmpty(v)) {
            var k = SYNO.SDS.Backup.Client.Common.Utils.getConvertSize(this.totalSize);
            var j = SYNO.SDS.Backup.Client.Common.Utils.getUnit(this.totalSize);
            var s = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "total_usage");
            var e = this.svgGraphics.append("g");
            e.append("text").attr("y", function(w) {
                return -18
            }).attr("text-anchor", "middle").classed("svg_space_total", true).text(s);
            var f = Ext.id();
            var q = Ext.id();
            e.append("text").attr("y", function(w) {
                return 11
            }).attr("id", f).classed("svg_space_number", true).text(k);
            var c = Ext.getDom(f).getBBox().width;
            e.append("text").attr("y", function(w) {
                return 11
            }).attr("id", q).classed("svg_space_unit", true).text(j);
            var a = Ext.getDom(q).getBBox().width;
            var t = -Math.round(a / 2);
            e.select("#" + f).attr("transform", "translate(" + t + " 0)").attr("text-anchor", "middle");
            e.select("#" + q).attr("transform", "translate(" + (t + Math.round(c / 2) + 2) + " 0)").attr("text-anchor", "start")
        }
        var d = u.svg.arc().outerRadius(b).innerRadius(58);
        var i = u.layout.pie().value(function(w) {
            return w.used_size
        }).sort(null);
        var p = this.svgGraphics.selectAll("g.slice").data(i).enter().append("svg:g").attr("class", "slice");
        var r = "url(#" + this.shadowId + ")";
        p.append("svg:path").attr("fill", function(x, w) {
            return x.color || o[Math.min(w, 9)]
        }).attr("stroke", "#FFFFFF").attr("stroke-width", "0px").attr("d", d).on("mouseover", function(y, x, w) {
            this.parentNode.parentNode.appendChild(this.parentNode);
            u.select(this).transition().duration(300).attr("stroke-width", n + "px").attr("filter", r)
        }).on("mouseout", function(y, x, w) {
            u.select(this).transition().duration(300).attr("stroke-width", "0px").attr("filter", "")
        })
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Space.Legend", {
    extend: "Ext.BoxComponent",
    constructor: function(a) {
        var b = {
            autoFlexcroll: false
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    loadData: function(a) {
        this.update(a)
    },
    onRender: function() {
        this.callParent(arguments);
        this.tpl = new Ext.XTemplate("", '<tpl for=".">', '<div class="legend-w">', '<span class="rect" ', ' style="background-color:{[this.getColor(xindex, values)]};"></span>', '<span class="name" ext:qtip="{show_name}">', "{show_name}", "</span>", '<span class="desc" ext:qtip="{sizeTips}">', "&nbsp-&nbsp{sizeTips}", "</span>", '<div class="detail" ext:qtip="{sizeDetail}">', "{sizeDetail}", "</div>", "</div>", "</tpl>", "", {
            getColor: function(a, b) {
                return SYNO.SDS.Backup.Client.Common.Utils.Space.Config.COLORS[a - 1] || SYNO.SDS.Backup.Client.Common.Utils.Space.Config.DEFAULT_COLOR
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.ErrorReportWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.task_id = a.task_id;
        this.version_id = a.version_id;
        var b = {
            width: 680,
            height: 390,
            layout: "fit",
            useStatusBar: false,
            minWidth: 680,
            minHeight: 390,
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "missing_window_title"),
            items: [{
                xtype: "syno_gridpanel",
                store: this.getStore(),
                loadMask: true,
                enableHdMenu: false,
                enableColumnMove: false,
                enableColumnResize: true,
                disableSelection: true,
                trackMouseOver: true,
                colModel: this.getColumnModel(),
                bbar: new SYNO.ux.PagingToolbar({
                    store: this.getStore(),
                    displayInfo: true,
                    pageSize: 50,
                    showRefreshBtn: true
                })
            }]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    getColumnModel: function() {
        var a = new Ext.grid.ColumnModel({
            columns: [{
                sortable: true,
                width: 128,
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "missing_type_field"),
                dataIndex: "type",
                align: "left",
                renderer: function(f, c, b, g, e, d) {
                    return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", f)
                }
            }, {
                sortable: true,
                width: 192,
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "missing_src_field"),
                dataIndex: "path",
                align: "left"
            }, {
                width: 320,
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "missing_cause_field"),
                dataIndex: "cause",
                align: "left",
                renderer: function(g, d, c, h, f, e) {
                    var b = Ext.util.Format.htmlEncode(SYNO.SDS.Backup.Client.Common.Utils.convertMissingCauseToStr(g, c.json.cause_arg));
                    return String.format('<div ext:qtip="{0}">{1}</div>', b, b)
                }
            }]
        });
        return a
    },
    getStore: function() {
        if (this.store) {
            return this.store
        }
        var b = {
            task_id: this.task_id,
            limit: 50,
            start: 0
        };
        if (this.version_id) {
            b.version_id = this.version_id
        }
        var a = new Ext.data.JsonStore({
            proxy: new SYNO.API.Proxy({
                api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
                method: "detail",
                version: 1
            }),
            fields: ["type", "path", "cause"],
            root: "error_cause",
            autoDestroy: true,
            autoLoad: true,
            totalProperty: "total",
            remoteSort: true,
            baseParams: b
        });
        this.store = a;
        return this.store
    }
});
Ext.namespace("SYNO.SDS.Backup.Client.Common.Utils");
Ext.ns("SYNO.SDS.Backup.Client.Common.Utils.Space");
Ext.ns("SYNO.SDS.Backup.Client.Common.Utils.Space.Config");
SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip = function(a) {
    var c = Ext.util.Format.htmlEncode(a);
    var b = Ext.util.Format.htmlEncode(c);
    return b
};
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_SUN = "0";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_MON = "1";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_TUE = "2";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_WED = "3";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_THU = "4";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_FRI = "5";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_SAT = "6";
SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_EVERYDAY = "0,1,2,3,4,5,6";
SYNO.SDS.Backup.Client.Common.Utils.WeekArray = [
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_SUN, _T("schedule", "schedule_sun")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_MON, _T("schedule", "schedule_mon")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_TUE, _T("schedule", "schedule_tue")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_WED, _T("schedule", "schedule_wed")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_THU, _T("schedule", "schedule_thu")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_FRI, _T("schedule", "schedule_fri")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_SAT, _T("schedule", "schedule_sat")],
    [SYNO.SDS.Backup.Client.Common.Utils.SYNO_SCHEDULE_EVERYDAY, _T("schedule", "schedule_daily")]
];
SYNO.SDS.Backup.Client.Common.Utils.GenWeekString = function(c) {
    var a = true;
    var d = "";
    var b;
    for (b = 0; b < SYNO.SDS.Backup.Client.Common.Utils.WeekArray.length; b++) {
        if (0 <= c.search(SYNO.SDS.Backup.Client.Common.Utils.WeekArray[b][0])) {
            if (false === a) {
                d += ","
            } else {
                a = false
            }
            d += SYNO.SDS.Backup.Client.Common.Utils.WeekArray[b][1]
        }
    }
    return d
};
SYNO.SDS.Backup.Client.Common.Utils.DateScheduleToString = function(c) {
    var a = "";
    var b = c.week_name;
    a += _T("schedule", "schedule_date") + ": ";
    if (0 === c.date_type) {
        if (b) {
            if ("0,1,2,3,4,5,6" === b) {
                a += _T("schedule", "schedule_daily")
            } else {
                if ("1,2,3,4,5" === b) {
                    a += _T("schedule", "schedule_weekdays")
                } else {
                    if ("0,6" === b) {
                        a += _T("schedule", "schedule_weekend")
                    } else {
                        a += SYNO.SDS.Backup.Client.Common.Utils.GenWeekString(b)
                    }
                }
            }
        }
    } else {
        if (c.date.getMonth) {
            a += SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(c.date, {
                type: "date"
            })
        } else {
            a += SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(c.date, {
                type: "date"
            })
        }
        a += " ";
        if (1 === c.repeat) {
            a += _T("schedule", "repeat_monthly")
        } else {
            if (2 === c.repeat) {
                a += _T("schedule", "repeat_yearly")
            } else {
                if (3 === c.repeat) {
                    a += _T("schedule", "repeat_half_year")
                } else {
                    if (5 === c.repeat) {
                        a += _T("schedule", "repeat_tri_monthly")
                    } else {
                        a += _T("schedule", "no_repeat")
                    }
                }
            }
        }
    }
    return a
};
SYNO.SDS.Backup.Client.Common.Utils.TimeScheduleToString = function(c) {
    var b = "";
    var a = function(d, f) {
        var e = new Date();
        e.setHours(d);
        e.setMinutes(f);
        return SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(e, {
            type: "time"
        })
    };
    b += _T("schedule", "schedule_time") + ": ";
    if (0 === c.repeat_hour) {
        b += a(c.hour, c.min)
    } else {
        b += a(c.hour, c.min) + " ~ " + a(c.last_work_hour, c.min);
        b += " " + _T("schedule", "schedule_every_each") + " " + c.repeat_hour + " " + _T("schedule", "schedule_hour")
    }
    return b
};
SYNO.SDS.Backup.Client.Common.Utils.getScheduleStr = function(a) {
    if (!a || !a.schedule_enable) {
        return _T("widget", "no_backup")
    }
    return SYNO.SDS.Backup.Client.Common.Utils.TimeScheduleToString(a.schedule) + " " + SYNO.SDS.Backup.Client.Common.Utils.DateScheduleToString(a.schedule)
};
SYNO.SDS.Backup.Client.Common.Utils.getConvertSize = function(b) {
    if (!b) {
        return 0
    }
    var a = parseInt(Math.floor(Math.log(b) / Math.log(1024)), 10);
    if (a === 0) {
        return (b / Math.pow(1024, a))
    }
    return parseFloat((b / Math.pow(1024, a)).toFixed(1))
};
SYNO.SDS.Backup.Client.Common.Utils.getUnit = function(b) {
    if (!b) {
        return "B"
    }
    var c = ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
    var a = parseInt(Math.floor(Math.log(b) / Math.log(1024)), 10);
    return c[a]
};
SYNO.SDS.Backup.Client.Common.Utils.getPercentage = function(b, a) {
    if (!Ext.isNumber(b)) {
        return b
    }
    var c = 0;
    if (0 < a) {
        c = (b / a) * 100
    }
    if (1 <= c) {
        c = Math.floor(c)
    } else {
        if (0.1 <= c) {
            c = c.toFixed(1)
        } else {
            if (0.01 <= c) {
                c = c.toFixed(2)
            } else {
                c = "< 0.01"
            }
        }
    }
    return String.format("({0}%)", c)
};
SYNO.SDS.Backup.Client.Common.Utils.Space.Config = {
    DEFAULT_COLOR: "#bfbfbf",
    COLORS: ["#426FDB", "#19A1C0", "#FFC214"]
};
SYNO.SDS.Backup.Client.Common.Utils.AccountMeta = {
    ABILITY_DISABLE: "disable",
    ABILITY_ENABLE: "enable",
    SCHEDULE_NONE: "none",
    SCHEDULE_ONCE_A_DAY: "once_a_day",
    SCHEDULE_UNLIMITED: "unlimited",
    ROTATION_NONE: "none",
    ROTATION_BASIC: "basic",
    ROTATION_CUSTOM: "custom",
    STATISTICS_SOURCE: "source",
    STATISTICS_TARGET: "target",
    STATISTICS_ALL: "all",
    SPACE_SOURCE: "source",
    SPACE_TARGET: "target"
};
SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta = function() {
    var g = SYNO.SDS.Backup.Client.Common.Utils.AccountMeta;
    var f = [g.ABILITY_DISABLE, g.ABILITY_ENABLE];
    var c = [g.SCHEDULE_NONE, g.SCHEDULE_ONCE_A_DAY, g.SCHEDULE_UNLIMITED];
    var e = [g.ROTATION_NONE, g.ROTATION_BASIC, g.ROTATION_CUSTOM];
    var b = [g.STATISTICS_SOURCE, g.STATISTICS_TARGET, g.STATISTICS_ALL];
    var d = [g.SPACE_SOURCE, g.SPACE_TARGET];
    var a = {
        scheduleRule: g.SCHEDULE_UNLIMITED,
        versionDelete: g.ABILITY_ENABLE,
        versionLock: g.ABILITY_ENABLE,
        versionRotation: g.ROTATION_CUSTOM,
        statisticsDisplay: g.STATISTICS_ALL,
        spaceUsage: g.SPACE_TARGET,
        quota: 0,
        expireTime: 0,
        planGroup: "",
        planPeriod: "",
        account: "",
        isFresh: false,
        setSynoCloudDefault: function() {
            this.scheduleRule = g.SCHEDULE_ONCE_A_DAY;
            this.versionDelete = g.ABILITY_DISABLE;
            this.versionLock = g.ABILITY_DISABLE;
            this.versionRotation = g.ROTATION_NONE;
            this.statisticsDisplay = g.STATISTICS_SOURCE;
            this.spaceUsage = g.SPACE_SOURCE
        },
        setSynoCloudData: function(i) {
            if (Ext.isEmpty(i["x-backup-plan-group"])) {
                return
            }
            var h = {};
            h.plan_group = i["x-backup-plan-group"];
            if (!Ext.isEmpty(i["x-backup-synoaccount"])) {
                h.synoaccount = i["x-backup-synoaccount"]
            }
            if (!Ext.isEmpty(i["x-backup-plan-period"])) {
                h.plan_period = i["x-backup-plan-period"]
            }
            if (!Ext.isEmpty(i["x-backup-expired-time"])) {
                h.expire_time = i["x-backup-expired-time"]
            }
            if (!Ext.isEmpty(i["x-backup-statistics-display"])) {
                h.statistics_display = i["x-backup-statistics-display"]
            }
            if (!Ext.isEmpty(i["x-backup-schedule-constraint"])) {
                if ("none" === i["x-backup-schedule-constraint"]) {
                    h.schedule_rule = g.SCHEDULE_UNLIMITED
                } else {
                    if ("daily" === i["x-backup-schedule-constraint"]) {
                        h.schedule_rule = g.SCHEDULE_ONCE_A_DAY
                    } else {
                        h.schedule_rule = g.SCHEDULE_NONE
                    }
                }
            }
            if (!Ext.isEmpty(i["x-backup-version-constraint"])) {
                h.version_delete = g.ABILITY_DISABLE;
                h.version_lock = g.ABILITY_DISABLE;
                h.version_rotation = g.ROTATION_NONE;
                if ("none" === i["x-backup-version-constraint"]) {
                    h.version_delete = g.ABILITY_ENABLE;
                    h.version_lock = g.ABILITY_ENABLE;
                    h.version_rotation = g.ROTATION_CUSTOM
                } else {
                    if ("smart" === i["x-backup-version-constraint"]) {
                        h.version_rotation = g.ROTATION_BASIC
                    }
                }
            }
            if ("business" === h.plan_group) {
                h.quota = i["x-backup-target-quota"];
                h.space_usage = g.SPACE_TARGET
            } else {
                h.quota = i["x-backup-source-quota"];
                h.space_usage = g.SPACE_SOURCE
            }
            this.setData(h)
        },
        setData: function(h) {
            this.setScheduleRule(h.schedule_rule);
            this.setVersionDelete(h.version_delete);
            this.setVersionLock(h.version_lock);
            this.setVersionRotation(h.version_rotation);
            this.setStatisticsDisplay(h.statistics_display);
            this.setSpaceUsage(h.space_usage);
            if (!Ext.isEmpty(h.quota)) {
                this.quota = h.quota
            }
            if (!Ext.isEmpty(h.expire_time)) {
                this.expireTime = h.expire_time
            }
            if (!Ext.isEmpty(h.plan_group)) {
                this.planGroup = h.plan_group
            }
            if (!Ext.isEmpty(h.plan_period)) {
                this.planPeriod = h.plan_period
            }
            if (!Ext.isEmpty(h.synoaccount)) {
                this.account = h.synoaccount
            }
            if (!Ext.isEmpty(h.is_fresh)) {
                this.isFresh = h.is_fresh
            }
        },
        setScheduleRule: function(h) {
            if (-1 === c.indexOf(h)) {
                SYNO.Debug("Error: setScheduleRule unknown value: [" + h + "]");
                return
            }
            this.scheduleRule = h
        },
        setVersionDelete: function(h) {
            if (-1 === f.indexOf(h)) {
                SYNO.Debug("Error: setVersionDelete unknown value: [" + h + "]");
                return
            }
            this.versionDelete = h
        },
        setVersionLock: function(h) {
            if (-1 === f.indexOf(h)) {
                SYNO.Debug("Error: setVersionLock unknown value: [" + h + "]");
                return
            }
            this.versionLock = h
        },
        setVersionRotation: function(h) {
            if (-1 === e.indexOf(h)) {
                SYNO.Debug("Error: setVersionRotation unknown value: [" + h + "]");
                return
            }
            this.versionRotation = h
        },
        setStatisticsDisplay: function(h) {
            if (-1 === b.indexOf(h)) {
                SYNO.Debug("Error: setStatisticsDisplay unknown value: [" + h + "]");
                return
            }
            this.statisticsDisplay = h
        },
        setSpaceUsage: function(h) {
            if (-1 === d.indexOf(h)) {
                SYNO.Debug("Error: setSpaceUsage unknown value: [" + h + "]");
                return
            }
            this.spaceUsage = h
        }
    };
    return a
};
SYNO.SDS.Backup.Client.Common.Utils.convertMissingCauseToStr = function(a, b) {
    switch (a) {
        case 0:
        case 1:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "src_folder_not_exist");
        case 2:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "status_source_not_mounted");
        case 3:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "status_invalid_source");
        case 4:
            return b;
        case 5:
        case 6:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_system_error");
        case 7:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_system_busy");
        case 8:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_bad_param");
        case 9:
            return _T("backup", "app_err_install");
        case 10:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "broken_app");
        case 11:
            return _T("pkgmgr", "pkgmgr_pkg_stop_failed");
        case 12:
            return _T("pkgmgr", "pkgmgr_pkg_start_failed");
        case 13:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_file_not_found");
        case 14:
            return _T("backup", "err_connect");
        case 15:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_network_disconnected");
        case 16:
            return _T("backup", "err_server_name");
        case 17:
            return _T("backup", "imgbkp_account_pass_fail");
        case 18:
            return _T("netbackup", "err_share_perm_denied");
        case 19:
            return _TT("SYNO.SDS.Backup.Application", "error", "err_ip_denied");
        case 20:
            return _T("backup", "err_serivce_disable");
        case 21:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "client_no_space");
        case 22:
            return _T("backup", "app_err_no_volume");
        case 23:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_plugin_crash");
        case 24:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "app_version_old");
        case 25:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_depend_no_plugin");
        case 26:
            return SYNO.SDS.Backup.String("error", "app_err_no_version_found");
        case 27:
            return _T("usbbackup", "usbbkp_cancel");
        case 28:
            return _T("pkgmgr", "broken_desc");
        case 29:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_share_lost"), b);
        case 30:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_filesystem_not_support");
        case 31:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_self_requirement");
        case 32:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "restore_version_old");
        case 33:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_depend_app_backup_fail"), b);
        case 34:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "not_support_new_framework");
        case 35:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_depend_app_restore_fail"), b);
        case 36:
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_info_invalid_format");
        case 37:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_folder_lost"), b);
        case 38:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_share_unmounted"), b);
        case 39:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_depend_app_backup_fail_need_enable"), b, b);
        case 40:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_depend_on_dest_share"), b);
        case 41:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "c2_share_offline"), b);
        case 42:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "azure_share_end_with_dot"), b);
        case 43:
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "app_not_exist"), b)
    }
    return b
};
SYNO.SDS.Backup.Client.Common.Utils.observeEvent = function(b, a) {
    Ext.util.Observable.capture(b, a)
};
SYNO.SDS.Backup.Client.Common.Utils.getRepoTargetPermissionMsg = function(c, a, d, f) {
    var b = "";
    var e = "";
    if ("rw" === a) {
        b = "permission_read_write"
    } else {
        if ("r" === a) {
            b = "permission_read"
        }
    }
    if ("repo" === d) {
        e = "shared_folder"
    } else {
        if ("target" === d) {
            e = "directory"
        }
    }
    return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "user_no_permission"), c, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", b), SYNO.SDS.Backup.Client.Common.Utils.GetString("app", e), f)
};
SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter = SYNO.SDS.DateTimeFormatter || function(a, c) {
    if (!a || Object.prototype.toString.call(a) !== "[object Date]") {
        return ""
    }
    var b = c && c.type;
    var d;
    if (b === "date") {
        d = "Y-m-d"
    } else {
        if (b === "time") {
            d = "H:i"
        } else {
            if (b === "datetimesec") {
                d = "Y-m-d H:i:s"
            } else {
                if (b === "datetimesecms") {
                    d = "Y-m-d H:i:s.u"
                } else {
                    if (b === "timesec") {
                        d = "H:i:s"
                    } else {
                        if (b === "timesecms") {
                            d = "H:i:s.u"
                        } else {
                            d = "Y-m-d H:i"
                        }
                    }
                }
            }
        }
    }
    return a.format(d)
};
SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString = function(a, c) {
    var b = new Date(a);
    if (isNaN(b)) {
        return ""
    }
    return SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(b, c)
};
SYNO.SDS.Backup.Client.Common.Utils.isABBFuseFolder = function(b) {
    if (Ext.isEmpty(b)) {
        return false
    }
    var a = b.split("/");
    if (3 === a.length && a[2] === "ActiveBackupData") {
        return true
    }
    return false
};
SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder = function(b) {
    if (Ext.isEmpty(b)) {
        return false
    }
    var a = b.split("/");
    if (3 === a.length && a[2] === "@ActiveBackup") {
        return true
    }
    return false
};
Ext.define("SYNO.SDS.Backup.Client.Common.Password.Window", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.panel = this.getComponent("formpanel");
        this.defineBehaviors()
    },
    fillConfig: function(a) {
        var c = new SYNO.SDS.Utils.FormPanel({
            itemId: "formpanel",
            trackResetOnLoad: true,
            fileUpload: true,
            autoFlexcroll: false,
            webapi: {
                api: "SYNO.SDS.Backup.Client.Common.Target",
                method: "private_key_verify",
                encryption: ["pwd", "secret"],
                version: 1,
                scope: this
            },
            items: [{
                xtype: "container",
                layout: "column",
                hideLabel: true,
                items: [{
                    xtype: "syno_radio",
                    name: "decrypt_method",
                    width: 200,
                    inputValue: "manual",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "task_password_input"),
                    checked: true
                }, {
                    xtype: "syno_textfield",
                    textType: "password",
                    name: "password",
                    minLength: 8,
                    maxLength: 64,
                    allowBlank: false
                }, {
                    xtype: "syno_textfield",
                    name: "target_id",
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "repo_id",
                    value: -1,
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "task_id",
                    value: -1,
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "connect_params",
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "uni_key",
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "is_relink",
                    value: "F",
                    hidden: true
                }]
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "container",
                layout: "column",
                hideLabel: true,
                items: [{
                    xtype: "syno_radio",
                    name: "decrypt_method",
                    width: 200,
                    inputValue: "keyfile",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "task_private_input")
                }, {
                    xtype: "syno_filebutton",
                    allowBlank: false,
                    name: "private_key",
                    textConfig: {
                        width: 192
                    }
                }]
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_displayfield",
                name: "verify_hint"
            }],
            onApiSuccess: this.onActionComplete,
            onApiFailure: this.onFormFailed
        });
        var b = {
            width: 600,
            height: 230,
            minWidth: 600,
            minHeight: 230,
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "task_encrypt_input_title"),
            layout: "fit",
            items: c,
            keys: [{
                key: Ext.EventObject.ENTER,
                scope: this,
                handler: this.onSubmit
            }],
            buttons: [{
                itemId: "cancel",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                itemId: "apply",
                btnStyle: "blue",
                text: _T("common", "ok"),
                scope: this,
                handler: this.onSubmit
            }]
        };
        Ext.apply(b, a);
        return b
    },
    defineBehaviors: function() {
        this.mon(this, "afterlayout", function(a, c) {
            var b = this.panel.getForm();
            new SYNO.ux.Utils.EnableRadioGroup(b, "decrypt_method", {
                manual: ["password"],
                keyfile: ["private_key", "target_id", "repo_id", "task_id", "uni_key", "is_relink", "connect_params"]
            })
        }, this, {
            single: true
        })
    },
    onOpen: function() {
        this.callParent(arguments);
        this.panel.getForm().findField("password").focus(false, 100);
        if (!Ext.isEmpty(this.verify_hint)) {
            this.panel.getForm().findField("verify_hint").setValue(this.verify_hint);
            this.setHeight(260)
        }
    },
    onSubmit: function() {
        var b = this.panel.getForm();
        if (!b.isValid()) {
            return
        }
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        var c = b.findField("decrypt_method").getGroupValue();
        if (c === "keyfile") {
            if (!b.findField("private_key").getValue()) {
                return
            }
            b.findField("target_id").setValue(this.verify_params.target_id);
            if (!Ext.isEmpty(this.verify_params.repo_id)) {
                b.findField("repo_id").setValue(this.verify_params.repo_id)
            }
            if (!Ext.isEmpty(this.verify_params.task_id)) {
                b.findField("task_id").setValue(this.verify_params.task_id)
            }
            b.findField("uni_key").setValue(this.verify_params.uni_key);
            b.findField("is_relink").setValue(this.verify_params.is_relink ? "T" : "F");
            b.findField("connect_params").setValue(JSON.stringify(this.verify_params));
            this.get("formpanel").upload()
        } else {
            var a = b.findField("password").getValue();
            if (!a) {
                return
            }
            this.doSubmitEncryption(c, a)
        }
    },
    doSubmitEncryption: function(b, a) {
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Common.Target",
            version: "1",
            method: "password_verify",
            encryption: ["password", "pwd", "secret"],
            params: Ext.apply(this.panel.getForm().getValues(), this.verify_params),
            scope: this,
            callback: function(g, d, f, e) {
                if (!g) {
                    this.clearStatusBusy();
                    this.setStatusError({
                        text: SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(d.code)
                    });
                    return false
                }
                if (Ext.isFunction(this.setter)) {
                    this.setter(d)
                }
                var c = this.callback;
                this.clearStatusBusy();
                this.close();
                if (Ext.isFunction(c)) {
                    c(d)
                }
            }
        })
    },
    onActionComplete: function(c, b, a) {
        if (Ext.isFunction(this.ownerCt.setter)) {
            this.ownerCt.setter(b)
        }
        if (Ext.isFunction(this.ownerCt.callback)) {
            this.ownerCt.callback(b)
        }
        this.ownerCt.clearStatusBusy();
        this.ownerCt.close()
    },
    onFormFailed: function(d, c, b) {
        this.ownerCt.clearStatusBusy();
        var a = SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(c.code);
        if (SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "task_password_invalid") === a) {
            a = SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "task_private_invalid")
        }
        this.ownerCt.setStatusError({
            text: a
        });
        return false
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.FilterSetting", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.filterLimit = 10;
        this.read_only = a.disable_modified_source;
        var b = {
            cls: "syno-backup-client-common-filter-setting-panel",
            bodyStyle: "padding-right: 0px",
            itemId: "filter_setting_main_page",
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-backup-filter-setting-desc-text",
                value: (this.read_only) ? SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "file_filter_shown_below") : SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "file_filter_desc")
            }, {
                xtype: "syno_displayfield",
                cls: "syno-backup-filter-setting-mask-text",
                value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "include_mask")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                hidden: this.read_only,
                items: [{
                    xtype: "syno_textfield",
                    validator: this.validator.bind(this),
                    validationEvent: false,
                    maxLength: 1024,
                    id: (this.include_input = Ext.id()),
                    disabled: this.read_only,
                    cls: "syno-backup-filter-setting-textfield"
                }, {
                    xtype: "syno_button",
                    id: (this.include_add = Ext.id()),
                    disabled: this.read_only,
                    cls: "syno-backup-filter-setting-create-btn"
                }]
            }, {
                xtype: "container",
                cls: "syno-backup-filter-setting-pool",
                itemId: "include_pool"
            }, {
                xtype: "syno_displayfield",
                cls: "syno-backup-filter-setting-exclude-mask-text syno-backup-filter-setting-mask-text",
                value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "exclude_mask")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                hidden: this.read_only,
                items: [{
                    xtype: "syno_textfield",
                    validator: this.validator.bind(this),
                    validationEvent: false,
                    maxLength: 1024,
                    id: (this.exclued_input = Ext.id()),
                    disabled: this.read_only,
                    cls: "syno-backup-filter-setting-textfield"
                }, {
                    xtype: "syno_button",
                    id: (this.exclude_add = Ext.id()),
                    disabled: this.read_only,
                    cls: "syno-backup-filter-setting-create-btn"
                }]
            }, {
                xtype: "container",
                cls: "syno-backup-filter-setting-pool",
                itemId: "exclude_pool"
            }]
        };
        this.fieldArray = [{
            fieldName: "whitelist",
            inputField: this.include_input,
            button: this.include_add,
            pool: "include_pool",
            data: this.getStore()
        }, {
            fieldName: "exclude_list",
            inputField: this.exclued_input,
            button: this.exclude_add,
            pool: "exclude_pool",
            data: this.getStore()
        }];
        b = Ext.apply(b, a);
        this.callParent([b])
    },
    getStore: function() {
        return new Ext.data.ArrayStore({
            autoLoad: false,
            fields: ["pattern"]
        })
    },
    initComponent: function() {
        this.callParent(arguments);
        this.setPreviousTags(this.backupFilter)
    },
    initEvents: function() {
        this.callParent(arguments);
        var a = function(b) {
            this.fieldToCheck = b;
            var c;
            if (!(c = this.checkAndGetInput(b))) {
                return
            }
            this.AddTagAndRender(b, c);
            this.cleanTextField(b)
        };
        Ext.each(this.fieldArray, function(b) {
            Ext.getCmp(b.inputField).on("specialkey", function(c, d) {
                if (d.getKey() === d.ENTER) {
                    a.call(this, b)
                }
            }, this);
            Ext.getCmp(b.button).on("click", function() {
                a.call(this, b)
            }, this)
        }, this)
    },
    AddTagAndRender: function(a, b) {
        a.data.loadData([
            [b]
        ], true);
        this.getComponent(a.pool).add(new SYNO.SDS.Backup.Client.Common.Tag({
            text: b,
            maxWidth: 394,
            read_only: this.read_only,
            callback: this.closeTagCb.createDelegate(a.data)
        }));
        this.doLayout()
    },
    checkAndGetInput: function(a) {
        if (!Ext.getCmp(a.inputField).isValid()) {
            return false
        }
        var b = Ext.getCmp(a.inputField).getValue();
        return b
    },
    cleanTextField: function(a) {
        this.rightAfterAddTag = true;
        Ext.getCmp(a.inputField).setValue("")
    },
    closeTagCb: function(a) {
        this.removeAt(this.findExact("pattern", a))
    },
    isInPool: function(a, b) {
        return -1 !== a.findExact("pattern", b)
    },
    validator: function(a) {
        if (this.rightAfterAddTag) {
            this.rightAfterAddTag = false;
            return true
        }
        if (a.length === 0) {
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "filter_content_empty_warn")
        }
        if (-1 !== a.indexOf("/")) {
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "filter_contain_invalid_character")
        }
        if (this.filterLimit <= this.fieldToCheck.data.getCount()) {
            var b = ("whitelist" === this.fieldToCheck.fieldName) ? "filter_include_reach_limit" : "filter_exclude_reach_limit";
            return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", b), this.filterLimit)
        }
        if (this.isInPool(this.fieldToCheck.data, a)) {
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "filter_duplicated_warn")
        }
        return true
    },
    setPreviousTags: function(a) {
        if (!a) {
            return
        }
        Ext.each(this.fieldArray, function(b) {
            Ext.each(a[b.fieldName], function(c) {
                this.AddTagAndRender(b, c)
            }, this)
        }, this)
    },
    getParams: function() {
        var a = {};
        Ext.each(this.fieldArray, function(b) {
            a[b.fieldName] = [];
            b.data.each(function(c) {
                a[b.fieldName].push(c.get("pattern"))
            })
        }, this);
        return a
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.FilterSettingWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.read_only = a.disable_modified_source;
        var b = {
            height: (this.read_only) ? 502 : 570,
            width: 498,
            bodyCssClass: "syno-backup-client-common-filter-setting-window-body",
            resizable: false,
            layout: "fit",
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "file_filter_title"),
            items: [new SYNO.SDS.Backup.Client.Common.FilterSetting(a)],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                scope: this,
                hidden: this.read_only,
                handler: this.close
            }, {
                xtype: "syno_button",
                text: _T("common", "ok"),
                btnStyle: "blue",
                scope: this,
                handler: this.passParamsAndClose
            }]
        };
        b = Ext.apply(b, a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterrender", function() {
            var a = Ext.select(".syno-backup-client-common-filter-setting-window-body");
            if (a) {
                a.setStyle("padding-top", "0px");
                this.doLayout()
            }
        }, this)
    },
    passParamsAndClose: function() {
        if (!this.read_only) {
            var a = this.getComponent("filter_setting_main_page").getParams();
            this.fireEvent("savefilterparams", a)
        }
        this.close()
    }
});
(function() {
    var c = function(f) {
        switch (f) {
            case "earliest":
                return 0;
            case "year":
                return 365 * 24 * 60 * 60;
            case "month":
                return 28 * 24 * 60 * 60;
            case "week":
                return 7 * 24 * 60 * 60;
            case "day":
                return 24 * 60 * 60;
            case "hour":
                return 60 * 60;
            default:
                return 0
        }
    };
    var d = function(i) {
        if (0 === i) {
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "time_from_earliest")
        }
        var h = function(k, j) {
            if (!j) {
                switch (k) {
                    case "year":
                        return _T("common", "time_year");
                    case "month":
                        return _T("common", "time_month");
                    case "week":
                        return _T("common", "time_week");
                    case "day":
                        return _T("common", "time_day");
                    case "hour":
                        return _T("common", "time_hour")
                }
            } else {
                switch (k) {
                    case "year":
                        return _T("common", "time_years");
                    case "month":
                        return _T("common", "time_months");
                    case "week":
                        return _T("common", "time_weeks");
                    case "day":
                        return _T("common", "time_days");
                    case "hour":
                        return _T("common", "time_hours")
                }
            }
        };
        var g = ["year", "month", "week", "day", "hour"];
        var f = "";
        Ext.each(g, function(m) {
            var k = c(m);
            if ((i % k) === 0) {
                var j = i / k;
                var l = h(m, j !== 1);
                f = String.format("{0} {1}", j, l);
                return false
            }
        });
        return f
    };
    var b = [
        [SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "time_from_earliest"), "earliest"],
        [_T("common", "time_year"), "year"],
        [_T("common", "time_month"), "month"],
        [_T("common", "time_week"), "week"],
        [_T("common", "time_day"), "day"],
        [_T("common", "time_hour"), "hour"]
    ];
    var e = function() {
        return new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: b
        })
    };
    var a = function() {
        var f = b.slice();
        f.shift();
        return new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: f
        })
    };
    Ext.define("SYNO.SDS.Backup.Client.Common.RetentionSetting.CustomizedWindow", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(f) {
            var g = this.fillConfig(f);
            this.callParent([g])
        },
        fillConfig: function(f) {
            this.read_only = false;
            if (Ext.isBoolean(f.read_only) && f.read_only) {
                this.read_only = true
            }
            var g = Ext.apply({
                cls: "syno-backup-client-common-customized-retention-setting-window",
                width: 680,
                height: 460,
                resizable: false,
                useStatusBar: true,
                layout: "fit",
                items: [new SYNO.SDS.Backup.Client.Common.RetentionSetting.CustomizedPanel({
                    itemId: "customized_retention_setting_panel",
                    owner: this,
                    appWin: f.appWin,
                    read_only: this.read_only,
                    retention_rules: f.retention_rules
                })],
                buttons: [{
                    itemId: "cancel",
                    text: _T("common", "cancel"),
                    scope: this,
                    handler: this.close,
                    hidden: this.read_only
                }, {
                    itemId: "apply",
                    btnStyle: "blue",
                    text: _T("common", "ok"),
                    scope: this,
                    handler: this.onSubmit
                }]
            }, f);
            return g
        },
        onSubmit: function() {
            if (this.read_only) {
                this.close();
                return
            }
            var f = this.getComponent("customized_retention_setting_panel").getParams();
            if (f.rotate_customize_retention.length === 0) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "customized_retention_rule_not_zero"))
            } else {
                this.fireEvent("setCustomizedRetention", f);
                this.close()
            }
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Common.RetentionSetting.CustomizedPanel", {
        extend: "SYNO.SDS.Backup.Client.Common.FormPanel",
        retention_rules: [],
        constructor: function(f) {
            this.retention_rules = f.retention_rules;
            this.read_only = f.read_only;
            this.sortRetentionRules();
            var g = this.fillConfig(f);
            this.callParent([g])
        },
        initEvents: function() {
            this.callParent(arguments);
            this.mon(this.getComponent("customized_retention_grid"), "rowclick", function(g, j, i) {
                var h = Ext.fly(i.target);
                if (!h) {
                    return
                }
                var f = this.gridStore.getAt(j);
                if (h.hasClass("syno-backup-customized-retention-delete-btn")) {
                    this.OnRemoveRule(f.get("duration"), f.get("version_interval"), f.get("version_number"))
                }
            }, this)
        },
        fillConfig: function(f) {
            var g = this.read_only ? "default" : "syno-backup-customized-retention-grid";
            var h = Ext.apply({
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-backup-customized-retention-description",
                    hidden: this.read_only,
                    value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "customized_retention_description")
                }, {
                    xtype: "syno_gridpanel",
                    itemId: "customized_retention_grid",
                    cls: g,
                    enableHdMenu: false,
                    enableColumnMove: false,
                    enableColumnResize: false,
                    trackMouseOver: true,
                    disableSelection: true,
                    loadMask: true,
                    height: 224,
                    store: this.getGridStore(),
                    colModel: this.getGridColModel()
                }, {
                    xtype: "container",
                    cls: "syno-backup-customized-retention-add-bar-title-container",
                    layout: "hbox",
                    hidden: this.read_only,
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-backup-customized-retention-add-bar-duration-title",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "duration"),
                        width: 255
                    }, {
                        xtype: "syno_displayfield",
                        cls: "syno-backup-customized-retention-add-bar-version-interval-title",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "version_interval"),
                        width: 350
                    }]
                }, {
                    xtype: "container",
                    cls: "syno-backup-customized-retention-add-bar",
                    layout: "column",
                    hidden: this.read_only,
                    items: [{
                        xtype: "syno_numberfield",
                        name: "duration_value",
                        cls: "duration-value",
                        allowBlank: false,
                        disabled: true,
                        value: 1,
                        minValue: 1,
                        maxValue: 99,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "2"
                        },
                        width: 40,
                        height: 30
                    }, {
                        xtype: "syno_combobox",
                        name: "duration_scale",
                        displayField: "display",
                        valueField: "value",
                        value: "earliest",
                        store: e(),
                        width: 180,
                        height: 28,
                        tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip(values.display)]}" class="x-combo-list-item syno-backup-enabled-list-item">{display:htmlEncode}</div></tpl>',
                        listeners: {
                            select: function(j, i, l) {
                                var k = (function(m) {
                                    return this.getForm().findField(m)
                                }).createDelegate(this);
                                if ("earliest" === i.get("value")) {
                                    k("duration_value").setDisabled(true)
                                } else {
                                    k("duration_value").setDisabled(false)
                                }
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_numberfield",
                        name: "version_interval_value",
                        cls: "version-interval-value",
                        allowBlank: false,
                        value: 1,
                        minValue: 1,
                        maxValue: 99,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "2"
                        },
                        width: 40,
                        height: 30,
                        enableKeyEvents: true,
                        listeners: {
                            keyup: function(l, i, k) {
                                var j = (function(m) {
                                    return this.getForm().findField(m)
                                }).createDelegate(this);
                                j("version_interval_value").clearInvalid();
                                j("version_interval_scale").clearInvalid()
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_combobox",
                        name: "version_interval_scale",
                        displayField: "display",
                        valueField: "value",
                        value: "year",
                        store: a(),
                        width: 180,
                        height: 28,
                        tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip(values.display)]}" class="x-combo-list-item syno-backup-enabled-list-item">{display:htmlEncode}</div></tpl>',
                        listeners: {
                            select: function(j, i, l) {
                                var k = (function(m) {
                                    return this.getForm().findField(m)
                                }).createDelegate(this);
                                k("version_interval_value").clearInvalid();
                                k("version_interval_scale").clearInvalid()
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_button",
                        cls: "add-rule-btn",
                        text: _T("common", "add"),
                        handler: this.OnAddRule,
                        scope: this
                    }]
                }]
            }, f);
            return h
        },
        getGridStore: function() {
            if (!this.gridStore) {
                this.gridStore = new Ext.data.ArrayStore({
                    fields: ["duration", "version_interval", "version_number"],
                    data: this.retention_rules
                })
            }
            return this.gridStore
        },
        getGridColModel: function() {
            var f = function(k, j, h) {
                var i = new Ext.XTemplate('<span ext:qtip="{[SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip(values.text)]}">{text:htmlEncode}</span>');
                return i.apply({
                    text: d(k)
                })
            };
            var g;
            if (!this.read_only) {
                g = function(k, j, h) {
                    var i = new Ext.XTemplate('<div class="{textCls}" ext:qtip="{[SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip(values.text)]}">{text:htmlEncode}</div><div class="{deleteCls}" ext:qtip="{deleteQtip}"></div>');
                    return i.apply({
                        text: d(k),
                        textCls: "syno-backup-customized-retention-version-interval-string",
                        deleteCls: "syno-backup-customized-retention-delete-btn",
                        deleteQtip: _T("common", "delete")
                    })
                }
            } else {
                g = function(k, j, h) {
                    var i = new Ext.XTemplate('<div class="{textCls}" ext:qtip="{[SYNO.SDS.Backup.Client.Common.Utils.htmlEncodeTip(values.text)]}">{text:htmlEncode}</div>');
                    return i.apply({
                        text: d(k),
                        textCls: "syno-backup-customized-retention-version-interval-string"
                    })
                }
            }
            return new Ext.grid.ColumnModel([{
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "duration"),
                dataIndex: "duration",
                width: 250,
                resizable: false,
                align: "left",
                renderer: f
            }, {
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "version_interval"),
                dataIndex: "version_interval",
                width: 350,
                align: "left",
                renderer: g
            }])
        },
        OnAddRule: function() {
            var i = (function(j) {
                return this.getForm().findField(j).getValue()
            }).createDelegate(this);
            var g = (function(j) {
                return this.getForm().findField(j)
            }).createDelegate(this);
            var f = [i("duration_value") * c(i("duration_scale")), i("version_interval_value") * c(i("version_interval_scale")), 1];
            g("version_interval_value").clearInvalid();
            g("version_interval_scale").clearInvalid();
            if (f[0] !== 0 && f[0] < f[1]) {
                g("version_interval_value").markInvalid(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "max_version_interval"));
                g("version_interval_scale").markInvalid(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "max_version_interval"));
                return
            }
            var h = false;
            Ext.each(this.retention_rules, (function(k, j) {
                if (k[0] === f[0] && k[1] === f[1] && k[2] === f[2]) {
                    h = true;
                    this.rowFocusAnimation(j);
                    return false
                }
            }).createDelegate(this));
            if (false === h) {
                if (this.retention_rules.length < 7) {
                    this.retention_rules.push(f);
                    this.updateRetentionResult()
                } else {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "customized_retention_reach_max_rules"))
                }
            }
        },
        rowFocusAnimation: function(f) {
            var g = Ext.get(this.getComponent("customized_retention_grid").getView().getRow(f));
            if (g && g.isVisible()) {
                Ext.Element.prototype.frame.apply(g, ["#000", 1, {
                    duration: 0.35
                }])
            }
        },
        OnRemoveRule: function(g, h, f) {
            Ext.each(this.retention_rules, (function(k, i, j) {
                if (k[0] === g && k[1] === h && k[2] === f) {
                    this.retention_rules.splice(i, 1);
                    return false
                }
            }).createDelegate(this));
            this.updateRetentionResult()
        },
        updateRetentionResult: function() {
            this.sortRetentionRules();
            this.gridStore.loadData(this.retention_rules)
        },
        sortRetentionRules: function() {
            this.retention_rules.sort(function(g, f) {
                if (g[0] === f[0]) {
                    return f[1] - g[1]
                } else {
                    if (g[0] === 0 || f[0] === 0) {
                        return g[0] - f[0]
                    }
                }
                return f[0] - g[0]
            })
        },
        getParams: function() {
            var f = {};
            f.rotate_customize_retention = this.retention_rules;
            return f
        }
    })
})();
(function() {
    var a = function(d) {
        var c = 0,
            b = 1,
            e = " ";
        if (Ext.isString(d)) {
            d = parseFloat(d)
        }
        while (d >= 1024 && c !== 5) {
            d /= 1024;
            c++
        }
        if (d >= 100) {
            b = 0
        }
        if (d >= 1000) {
            e = ""
        }
        if (0 === c) {
            return d.toFixed(b) + e + "B"
        } else {
            if (1 === c) {
                return d.toFixed(b) + e + "KB"
            } else {
                if (2 === c) {
                    return d.toFixed(b) + e + "MB"
                } else {
                    if (3 === c) {
                        return d.toFixed(b) + e + "GB"
                    } else {
                        if (4 === c) {
                            return d.toFixed(b) + e + "TB"
                        } else {
                            return d.toFixed(b) + e + "PB"
                        }
                    }
                }
            }
        }
    };
    Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.BaseLineChart", {
        extend: "Ext.BoxComponent",
        parseYearData: Ext.emptyFn,
        parseData: Ext.emptyFn,
        getXAxisData: Ext.emptyFn,
        getYAxisData: Ext.emptyFn,
        getYDomain: Ext.emptyFn,
        getYTickFormat: Ext.emptyFn,
        getTooltipHTML: Ext.emptyFn,
        getInterpolationPoint: Ext.emptyFn,
        cacheMonthData: null,
        cacheYearData: null,
        dateInfo: null,
        isSetData: false,
        constructor: function(b) {
            this.d3 = SYNO.SDS.DataDrivenDocuments.DrawHelper;
            this.svgWidth = "100%";
            this.svgHeight = Ext.isNumber(b.height) ? b.height : 250;
            this.svgMargins = {
                top: 2,
                bottom: 30,
                left: 52,
                right: 9
            };
            this.dataNodePosition = 8;
            this.tooltipXShift = 25;
            this.tooltipAxisShift = 10;
            var c = Ext.apply({
                cls: "syno-backup-statistic-line-chart"
            }, b);
            this.callParent([c])
        },
        setData: function(c, b) {
            this.dateInfo = b;
            this.isSetData = true;
            if ("year" === b.timeRange) {
                if (!this.cacheYearData) {
                    this.cacheYearData = this.parseYearData(c)
                }
            } else {
                this.cacheMonthData = this.parseData(c)
            }
        },
        getStartDate: function() {
            if (!Ext.isObject(this.dateInfo)) {
                SYNO.Debug.error("invalid call no dateInfo");
                return null
            }
            return this.dateInfo.getStartDate()
        },
        redraw: function() {
            if (this.isSetData) {
                if ("month" === this.dateInfo.timeRange) {
                    this._draw(this.cacheMonthData.dataList, this.cacheMonthData.previousNode, this.cacheMonthData.nextNode)
                } else {
                    if ("year" === this.dateInfo.timeRange) {
                        this._draw(this.cacheYearData.dataList, this.cacheYearData.previousNode, this.cacheYearData.nextNode)
                    } else {
                        SYNO.Debug.error("unknown time range");
                        this._draw([], null, null)
                    }
                }
            } else {
                this._draw([], null, null)
            }
        },
        _draw: function(G, o, v) {
            var N = this.d3;
            var j = this.svgMargins;
            var b = this.getWidth() - j.left - j.right;
            var d = this.getHeight() - j.top - j.bottom;
            var l = this,
                Q;
            var h = Ext.isObject(this.dateInfo) ? this.dateInfo.getSelectMonthDateCount() : 31;
            if (Ext.isObject(this.dateInfo) && "year" === this.dateInfo.timeRange) {
                h = 24
            }
            var f = null;
            if ("target" === l.lineChart && l.isSetData && l.enableTargetLimit) {
                f = l.getYDomain(G, o, v, l.targetMaxSize)
            } else {
                f = l.getYDomain(G, o, v)
            }
            var p = [Math.ceil(f[0] + ((f[1] - f[0]) / 4)), Math.ceil(f[0] + ((f[1] - f[0]) / 2)), Math.ceil(f[0] + (((f[1] - f[0]) / 4) * 3))];
            var O = [];
            var z = [];
            if (this.isSetData) {
                for (Q = 1; Q <= h; Q += 1) {
                    if (Ext.isObject(l.dateInfo) && "month" === l.dateInfo.timeRange) {
                        if (Q % 2 === 1) {
                            O.push(Q)
                        }
                    } else {
                        if (this.xAxisMapping[Q]) {
                            O.push(Q)
                        }
                    }
                }
                z = [f[0], Math.ceil((f[0] + f[1]) / 2), f[1]]
            }
            if (this.svgGraphic) {
                this.svgGraphic.remove()
            }
            this.svgGraphic = this.svg.append("g").attr("transform", "translate(" + this.svgMargins.left + "," + this.svgMargins.top + ")");
            var g = this.svgGraphic;
            if (this.svgGraphicTouchPanel) {
                this.svgGraphicTouchPanel.remove()
            }
            this.svgGraphicTouchPanel = this.touchPanel.append("g").attr("transform", "translate(" + this.svgMargins.left + "," + this.svgMargins.top + ")");
            var e = this.svgGraphicTouchPanel;
            var K = N.scale.linear().range([0, b]).domain([0, h + 1]);
            if (Ext.isObject(l.dateInfo) && "month" === l.dateInfo.timeRange) {
                K = (function() {
                    var x = 26 + 8;
                    var i = N.scale.linear().range([0, x, b - x, b]).domain([0, 1, h, h + 1]);
                    return i
                }())
            }
            var C = 0,
                s = 0,
                F = 0;
            if (l.isValidNode(o) || l.isValidNode(v)) {
                if (Ext.isObject(this.dateInfo) && "year" === this.dateInfo.timeRange) {
                    C = this.getStartDate().add(Date.MONTH, -1).add(Date.DAY, 15).getTime() / 1000;
                    s = this.getStartDate().getTime() / 1000;
                    F = this.getStartDate().add(Date.MONTH, 12).getTime() / 1000
                } else {
                    C = this.getStartDate().add(Date.DAY, -1).getTime() / 1000;
                    s = this.getStartDate().getTime() / 1000;
                    F = this.getStartDate().getLastDateOfMonth().add(Date.DAY, 1).getTime() / 1000
                }
            }
            var J = N.scale.linear().range([d, 0]).domain(f);
            var R = null;
            if (Ext.isObject(this.dateInfo) && "year" === l.dateInfo.timeRange) {
                R = function(i) {
                    return K(l.getYearIndex(l.getStartDate(), i))
                }
            } else {
                R = function(i) {
                    return K(l.getMonthIndex(l.getStartDate(), i))
                }
            }
            var w = N.svg.axis().scale(K).orient("top").tickValues("").tickSize(0, 0);
            var M = N.svg.axis().scale(J).orient("right").tickValues(p).tickFormat("").tickSize(-b, 0);
            var u = N.svg.axis().scale(K).orient("bottom").tickValues(O).tickSize(-4, 0).tickPadding(10);
            if (Ext.isObject(this.dateInfo) && "year" === this.dateInfo.timeRange) {
                u.tickFormat(function(i) {
                    return l.xAxisMapping[i]
                })
            } else {
                u.tickFormat(function(i) {
                    return ("0" + i).slice(-2)
                })
            }
            var m = N.svg.axis().scale(J).orient("left").tickValues(z).tickSize(0, 0).tickPadding(5).tickFormat(l.getYTickFormat);
            g.append("rect").attr("x", 0).attr("y", 0).attr("width", b).attr("height", d).style("fill", "#FAFCFF");
            g.append("g").attr("class", "x axis").attr("transform", "translate(0," + d + ")").call(u).selectAll("text").style({
                "font-size": "12px"
            });
            g.append("g").attr("class", "y axis").call(m).selectAll("text").style({
                "font-size": "12px"
            });
            g.append("g").attr("class", "x-top axis").call(w);
            g.append("g").attr("class", "y-right axis").attr("transform", "translate(" + b + ", 0)").call(M);
            g.select(".y.axis").select("[transform='translate(0,0)']").attr("transform", "translate(0,5)");
            var q = g.append("line").attr("class", "data-node-verticle-line").attr("x1", K(1)).attr("y1", 0).attr("x2", K(1)).attr("y2", d);
            Ext.each(l.lineNodeList, function(y) {
                var x = N.svg.line().x(function(U) {
                    return R(U)
                }).y(function(U) {
                    return J(y.fn(U))
                });
                g.append("path").datum(G).attr("class", "line " + y.line_css).attr("d", x);
                var i = [],
                    T;
                if (l.isValidNode(o) && 0 < G.length) {
                    T = l.getInterpolationPoint(o, G[0], s);
                    T.end_time = C;
                    i = [T, G[0]];
                    g.append("path").datum(i).attr("class", "line " + y.line_css).attr("d", x)
                }
                if (l.isValidNode(v) && 0 < G.length) {
                    T = l.getInterpolationPoint(G[G.length - 1], v, F);
                    i = [T, G[G.length - 1]];
                    g.append("path").datum(i).attr("class", "line " + y.line_css).attr("d", x)
                }
                if (l.isValidNode(v) && l.isValidNode(o) && 0 === G.length) {
                    i.push(l.getInterpolationPoint(o, v, C));
                    i.push(l.getInterpolationPoint(o, v, F));
                    g.append("path").datum(i).attr("class", "line " + y.line_css).attr("d", x)
                }
                if (!l.isValidNode(o) && 0 < G.length) {
                    g.append("circle").attr("cx", R(G[0])).attr("cy", J(y.fn(G[0]))).attr("r", 5).attr("class", "endpoint-node " + y.node_css)
                }
                if (!l.isValidNode(v) && 0 < G.length) {
                    g.append("circle").attr("cx", R(G[G.length - 1])).attr("cy", J(y.fn(G[G.length - 1]))).attr("r", 5).attr("class", "endpoint-node " + y.node_css)
                }
                if (y.node) {
                    Ext.destroy(y.node)
                }
                y.node = l.el.createChild({
                    cls: "data-node-base " + y.node_css
                });
                y.node.createChild({
                    cls: "inner-node " + y.node_css
                })
            });
            if (this.emptyMessage) {
                Ext.destroy(this.emptyMessage)
            }
            if (0 === G.length && l.isSetData && (!l.isValidNode(o) || !l.isValidNode(v))) {
                this.emptyMessage = l.el.createChild({
                    cls: "empty-page-position"
                }).setStyle("top", this.svgMargins.top + "px").setStyle("left", this.svgMargins.left + "px");
                this.emptyMessage.createChild({
                    cls: "empty-page-parent"
                }).setStyle("width", b + "px").setStyle("height", d + "px").createChild({
                    cls: "empty-page-text"
                }).setStyle("width", b + "px").update(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "no_data_desc"))
            } else {
                if ("target" === l.lineChart && l.isSetData && l.enableTargetLimit) {
                    g.append("line").attr("class", "line target-limit").attr("x1", 0).attr("x2", b).attr("y1", J(l.targetMaxSize)).attr("y2", J(l.targetMaxSize))
                }
            }
            if (this.tooltip) {
                Ext.destroy(this.tooltip)
            }
            l.tooltip = l.el.createChild({
                cls: "data-node-tooltip " + l.lineChart
            });
            var S = l.tooltip.getWidth();
            var r = l.tooltip.getHeight();
            var H = this.tooltipXShift;
            var k = Math.ceil(r / 2);
            var D = this.tooltipAxisShift;
            var E = 26;
            var L;
            var t = function(i, x) {
                for (Q = 0; Q < G.length; Q++) {
                    L = R(G[Q]);
                    if ((L - x) <= i && i < (L + x)) {
                        return G[Q]
                    }
                }
                return null
            };
            var c = function() {
                var x = N.mouse(this);
                var T = t(x[0], l.dataNodePosition);
                if (null !== T) {
                    L = R(T);
                    q.attr("x1", L).attr("x2", L).style("display", "block");
                    var y = Number.MAX_VALUE;
                    Ext.each(l.lineNodeList, function(W) {
                        var V = J(W.fn(T));
                        W.node.setStyle("visibility", "visible").setStyle("top", (l.svgMargins.top + V - l.dataNodePosition) + "px").setStyle("left", (l.svgMargins.left + L - l.dataNodePosition) + "px");
                        if (V < y) {
                            y = V
                        }
                    });
                    var U = L + H;
                    var i = y - k;
                    if ((b - E - L) < (S + H)) {
                        U = L - S - H
                    }
                    if ((y - k) < 0) {
                        i = D
                    } else {
                        if ((d - i) < r) {
                            i = d - r - D
                        }
                    }
                    l.tooltip.setStyle("left", (U + l.svgMargins.left) + "px").setStyle("top", (i + l.svgMargins.top) + "px").setStyle("visibility", "visible");
                    if (Ext.isObject(l.dateInfo) && "year" === l.dateInfo.timeRange) {
                        l.tooltip.update(l.getTooltipYearHTML(T, l.tooltip)).setStyle("visibility", "visible")
                    } else {
                        l.tooltip.update(l.getTooltipHTML(T, l.tooltip)).setStyle("visibility", "visible")
                    }
                }
            };
            var I = function() {
                l.tooltip.setStyle("visibility", "hidden");
                q.style("display", "none");
                Ext.each(l.lineNodeList, function(i) {
                    i.node.setStyle("visibility", "hidden")
                })
            };
            var B = e.append("rect").attr("x", 0).attr("y", 0).attr("width", b).attr("height", d).attr("opacity", 0);
            B.on("mousemove", c);
            B.on("mouseleave", I);
            if (this.monthBtnNext && this.monthBtnPrevious) {
                Ext.destroy(this.monthBtnNext);
                Ext.destroy(this.monthBtnPrevious)
            }
            if (Ext.isObject(this.dateInfo) && "month" === this.dateInfo.timeRange) {
                var P = 36;
                var n = 36;
                var A = 12;
                this.monthBtnNext = l.el.createChild({
                    cls: "month-change-arrow next"
                }).setStyle("left", (this.svgMargins.left + b - (P + A)) + "px").setStyle("top", (this.svgMargins.top + Math.ceil(d / 2) - n / 2) + "px");
                if (l.isValidNode(v)) {
                    this.mon(this.monthBtnNext, "click", function() {
                        l.fireEvent("click_change_month_btn", "next")
                    })
                } else {
                    this.monthBtnNext.addClass("disable")
                }
                this.monthBtnPrevious = l.el.createChild({
                    cls: "month-change-arrow back"
                }).setStyle("left", this.svgMargins.left + A + "px").setStyle("top", (this.svgMargins.top + Math.ceil(d / 2) - n / 2) + "px");
                if (l.isValidNode(o)) {
                    this.mon(this.monthBtnPrevious, "click", function() {
                        l.fireEvent("click_change_month_btn", "back")
                    })
                } else {
                    this.monthBtnPrevious.addClass("disable")
                }
            }
        },
        isValidNode: function(b) {
            if (Ext.isEmpty(b)) {
                return false
            }
            return (0 !== this.getXAxisData(b))
        },
        onRender: function(c, b) {
            var d = this.d3;
            this.callParent(arguments);
            this.svg = d.select("#" + this.id).append("svg").attr("width", this.svgWidth).attr("height", this.svgHeight).attr("class", "syno-backup-statistic-svg syno-backup-statistic-svg-main-panel");
            this.touchPanel = d.select("#" + this.id).append("svg").attr("width", this.svgWidth).attr("height", this.svgHeight).attr("class", "syno-backup-statistic-svg syno-backup-statistic-svg-touch-panel")
        },
        onResize: function(e, c, b, d) {
            if (this.svgHeight !== c || this.svgHeight !== e) {
                this.svgHeight = c;
                this.svgWidth = e;
                this.svg = this.d3.select("#" + this.id + " svg");
                this.d3.selectAll("#" + this.id + " svg").attr("width", this.svgWidth).attr("height", this.svgHeight);
                if (this.ownerCt.ownerCt.activeTab === this.ownerCt) {
                    this.redraw()
                }
            }
            this.callParent(arguments)
        },
        genYearXLabel: function(d, f) {
            var e, c;
            var b = [];
            for (e = 1, c = d; e <= f; e++) {
                if (c.getDate() < 16) {
                    b[e] = c.format("m/Y");
                    c = c.add(Date.DAY, 15)
                } else {
                    b[e] = undefined;
                    c = c.add(Date.MONTH, 1).getFirstDateOfMonth()
                }
            }
            return b
        },
        genYearTipLabel: function(c, f) {
            var e, b;
            var d = [];
            for (e = 1, b = c; e <= f; e++) {
                if (b.getDate() < 16) {
                    d[e] = b.format("m/d") + " - " + b.add(Date.DAY, 14).format("m/d");
                    b = b.add(Date.DAY, 15)
                } else {
                    d[e] = b.format("m/d") + " - " + b.getLastDateOfMonth().format("m/d");
                    b = b.add(Date.MONTH, 1).getFirstDateOfMonth()
                }
            }
            return d
        },
        getYearIndex: function(c, b) {
            function d(f) {
                return f.getYear() * 24 + f.getMonth() * 2 + ((f.getDate() > 15) ? 1 : 0)
            }
            var e = new Date(b.end_time * 1000);
            return 1 + d(e) - d(c)
        },
        getMonthIndex: function(c, b) {
            var d = new Date(b.end_time * 1000);
            return 1 + Math.floor((d.getTime() - c.getTime()) / 1000 / 86400)
        },
        mergeYearData: function(h, b, f, j, e) {
            var g = [],
                c = [],
                d;
            Ext.each(h, function(i) {
                var k = j(b, i);
                if (k <= 0 || k > f) {
                    return
                }
                e(g, k, i)
            });
            for (d = 1; d <= f; d++) {
                if (Ext.isDefined(g[d])) {
                    c.push(g[d])
                }
            }
            return c
        },
        _parseYearData: function(f, g, c, e) {
            if (!Ext.isObject(f) || !Ext.isObject(this.dateInfo)) {
                SYNO.Debug.error("invalud input");
                return
            }
            var b = this.getStartDate();
            this.xAxisMapping = this.genYearXLabel(b, 24);
            this.tooltipMapping = this.genYearTipLabel(b, 24);
            var d = g(f);
            if (!Ext.isObject(d) || !Ext.isArray(d.dataList)) {
                SYNO.Debug.error("bad data returned");
                return
            }
            d.dataList = this.mergeYearData(d.dataList, b, 24, c, e);
            return d
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.TargetLineChart", {
        extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseLineChart",
        lineChart: "target",
        lineNodeList: null,
        xAxisMapping: null,
        tooltipMapping: null,
        enableTargetLimit: null,
        targetMaxSize: null,
        constructor: function(b) {
            this.lineNodeList = [{
                fn: this.getYAxisData,
                line_css: "target-size",
                node_css: "blue",
                node: null
            }];
            this.callParent([b])
        },
        parseYearData: function(c) {
            function b(g, e, d) {
                var f = g[e];
                if (!Ext.isDefined(f)) {
                    g[e] = d
                } else {
                    if (f.end_time < d.end_time) {
                        g[e] = d
                    }
                }
            }
            return this._parseYearData(c, function(d) {
                return {
                    dataList: c.target_list,
                    previousNode: c.target_previous_next_list[0],
                    nextNode: c.target_previous_next_list[1]
                }
            }, this.getYearIndex, b)
        },
        parseData: function(b) {
            if (!Ext.isObject(b)) {
                return
            }
            return {
                dataList: b.target_list,
                previousNode: b.target_previous_next_list[0],
                nextNode: b.target_previous_next_list[1]
            }
        },
        getInterpolationPoint: function(e, c, b) {
            var d = this.d3.scale.linear().domain([e.end_time, c.end_time]).range([e.target_size, c.target_size]);
            return {
                end_time: b,
                target_size: d(b)
            }
        },
        getXAxisData: function(b) {
            return b.end_time
        },
        getYAxisData: function(b) {
            return b.target_size
        },
        getYDomain: function(g, d, c, f) {
            if (0 === g.length && !Ext.isEmpty(d) && !this.isValidNode(d) && !Ext.isEmpty(c) && !this.isValidNode(c)) {
                return [0, 1024 * 1024 * 1024]
            }
            var h = [];
            h = h.concat(g, [d, c]);
            h = h.filter((function(j) {
                return this.isValidNode(j)
            }).createDelegate(this));
            var i = this._getListMaxMinValue(h);
            if (Ext.isNumber(f)) {
                i.max = Ext.max([f, i.max]);
                i.min = Ext.min([f, i.min])
            }
            var b = Math.ceil(i.max * 1.18);
            var e = Math.floor(i.min * 0.9);
            if (0 === b && 0 === e) {
                return [0, 1024 * 1024]
            } else {
                if (b < 100) {
                    return [0, 100]
                }
            }
            return [e, b]
        },
        _getListMaxMinValue: function(d) {
            var b = 0;
            var c = Number.MAX_VALUE;
            Ext.each(d, function(e) {
                b = Ext.max([this.getYAxisData(e), b]);
                c = Ext.min([this.getYAxisData(e), c])
            }, this);
            return {
                max: b,
                min: c
            }
        },
        getYTickFormat: function(b) {
            if (b === 0) {
                return ""
            }
            return a(b * 1024)
        },
        getTooltipYearHTML: function(e) {
            var d = this.tooltipMapping[this.getYearIndex(this.getStartDate(), e)];
            var c = Ext.util.Format.fileSize(e.target_size * 1024);
            var b = c.split(" ");
            return "<div class='title'>" + d + "</div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text blue'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size") + ":</span><span class='right'><font class='target-size'>" + b[0] + "</font> " + b[1] + "</span></div></div>"
        },
        getTooltipHTML: function(f) {
            var b = new Date(f.end_time * 1000);
            var e = (b.getMonth() + 1) + "/" + b.getDate();
            var d = Ext.util.Format.fileSize(f.target_size * 1024);
            var c = d.split(" ");
            return "<div class='title'><span class='left'>" + e + "</span></div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text blue'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size") + ":</span><span class='right'><font class='target-size'>" + c[0] + "</font> " + c[1] + "</span></div></div>"
        },
        setTargetMaxSize: function(b, c) {
            this.enableTargetLimit = b;
            this.targetMaxSize = parseFloat(c)
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.SourceLineChart", {
        extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseLineChart",
        lineChart: "source",
        lineNodeList: null,
        constructor: function(b) {
            this.lineNodeList = [{
                fn: this.getYAxisData,
                line_css: "source-size",
                node_css: "red",
                node: null
            }];
            this.callParent([b])
        },
        parseYearData: function(c) {
            function b(g, e, d) {
                var f = g[e];
                if (!Ext.isDefined(f)) {
                    g[e] = d
                } else {
                    if (f.end_time < d.end_time) {
                        g[e] = d
                    }
                }
            }
            return this._parseYearData(c, function(d) {
                return {
                    dataList: c.source_list,
                    previousNode: c.source_previous_next_list[0],
                    nextNode: c.source_previous_next_list[1]
                }
            }, this.getYearIndex, b)
        },
        parseData: function(b) {
            if (!Ext.isObject(b)) {
                return
            }
            return {
                dataList: b.source_list,
                previousNode: b.source_previous_next_list[0],
                nextNode: b.source_previous_next_list[1]
            }
        },
        getInterpolationPoint: function(e, c, b) {
            var d = this.d3.scale.linear().domain([e.end_time, c.end_time]).range([e.source_size, c.source_size]);
            return {
                end_time: b,
                source_size: d(b)
            }
        },
        getXAxisData: function(b) {
            return b.end_time
        },
        getYAxisData: function(b) {
            return b.source_size
        },
        getYDomain: function(f, d, c) {
            if (0 === f.length && !Ext.isEmpty(d) && !this.isValidNode(d) && !Ext.isEmpty(c) && !this.isValidNode(c)) {
                return [0, 1024 * 1024 * 1024]
            }
            var g = [];
            g = g.concat(f, [d, c]);
            g = g.filter((function(i) {
                return this.isValidNode(i)
            }).createDelegate(this));
            var h = this._getListMaxMinValue(g);
            var b = Math.ceil(h.max * 1.18);
            var e = Math.floor(h.min * 0.9);
            if (0 === b && 0 === e) {
                return [0, 1024 * 1024]
            } else {
                if (b < 100) {
                    return [0, 100]
                }
            }
            return [e, b]
        },
        _getListMaxMinValue: function(d) {
            var b = 0;
            var c = Number.MAX_VALUE;
            Ext.each(d, function(e) {
                b = Ext.max([this.getYAxisData(e), b]);
                c = Ext.min([this.getYAxisData(e), c])
            }, this);
            return {
                max: b,
                min: c
            }
        },
        getYTickFormat: function(b) {
            if (b === 0) {
                return ""
            }
            return a(b * 1024)
        },
        getTooltipYearHTML: function(e) {
            var d = this.tooltipMapping[this.getYearIndex(this.getStartDate(), e)];
            var c = Ext.util.Format.fileSize(e.source_size * 1024);
            var b = c.split(" ");
            return "<div class='title'>" + d + "</div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text red'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size") + ":</span><span class='right'><font class='source-size'>" + b[0] + "</font> " + b[1] + "</span></div></div>"
        },
        getTooltipHTML: function(f) {
            var b = new Date(f.end_time * 1000);
            var e = (b.getMonth() + 1) + "/" + b.getDate();
            var d = Ext.util.Format.fileSize(f.source_size * 1024);
            var c = d.split(" ");
            return "<div class='title'><span class='left'>" + e + "</span></div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text red'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size") + ":</span><span class='right'><font class='source-size'>" + c[0] + "</font> " + c[1] + "</span></div></div>"
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.SourceChangeLineChart", {
        extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseLineChart",
        lineChart: "source-change",
        lineNodeList: null,
        constructor: function(b) {
            this.lineNodeList = [{
                fn: this.getYAxisDataNewCount,
                line_css: "new-count",
                node_css: "blue",
                node: null
            }, {
                fn: this.getYAxisDataModifyCount,
                line_css: "modify-count",
                node_css: "green",
                node: null,
                fo: null
            }, {
                fn: this.getYAxisDataDeleteCount,
                line_css: "delete-count",
                node_css: "red",
                node: null,
                fo: null
            }];
            this.callParent([b])
        },
        parseYearData: function(c) {
            function b(g, e, d) {
                var f = g[e];
                if (!Ext.isDefined(f)) {
                    g[e] = d
                } else {
                    Ext.each(["delete_count", "modify_count", "new_count"], function(h) {
                        f[h] += d[h]
                    });
                    if (f.end_time < d.end_time) {
                        f.end_time = d.end_time
                    }
                }
            }
            return this._parseYearData(c, function(d) {
                return {
                    dataList: c.source_list,
                    previousNode: c.source_previous_next_list[0],
                    nextNode: c.source_previous_next_list[1]
                }
            }, this.getYearIndex, b)
        },
        parseData: function(b) {
            if (!Ext.isObject(b)) {
                return
            }
            return {
                dataList: b.source_list,
                previousNode: b.source_previous_next_list[0],
                nextNode: b.source_previous_next_list[1]
            }
        },
        getInterpolationPoint: function(f, e, c) {
            var d = {
                end_time: c
            };
            var b = this;
            Ext.each(["delete_count", "modify_count", "new_count"], function(g) {
                var h = b.d3.scale.linear().domain([f.end_time, e.end_time]).range([f[g], e[g]]);
                d[g] = h(c)
            });
            return d
        },
        getXAxisData: function(b) {
            return b.end_time
        },
        getYAxisDataNewCount: function(b) {
            return b.new_count
        },
        getYAxisDataModifyCount: function(b) {
            return b.modify_count
        },
        getYAxisDataDeleteCount: function(b) {
            return b.delete_count
        },
        getYDomain: function(f, d, c) {
            if (0 === f.length && !Ext.isEmpty(d) && !this.isValidNode(d) && !Ext.isEmpty(c) && !this.isValidNode(c)) {
                return [0, 100]
            }
            var g = [];
            g = g.concat(f, [d, c]);
            g = g.filter((function(i) {
                return this.isValidNode(i)
            }).createDelegate(this));
            var h = this._getListMaxMinValue(g);
            var b = Math.ceil(h.max * 1.18);
            var e = Math.floor(h.min * 0.9);
            if (0 === b && 0 === e) {
                return [0, 100]
            } else {
                if (b < 20) {
                    return [0, 20]
                }
            }
            return [e, b]
        },
        _getListMaxMinValue: function(d) {
            var b = 0;
            var c = Number.MAX_VALUE;
            Ext.each(d, function(g) {
                var e = Ext.max([this.getYAxisDataNewCount(g), this.getYAxisDataModifyCount(g), this.getYAxisDataDeleteCount(g)]);
                var f = Ext.min([this.getYAxisDataNewCount(g), this.getYAxisDataModifyCount(g), this.getYAxisDataDeleteCount(g)]);
                b = Ext.max([e, b]);
                c = Ext.min([f, c])
            }, this);
            return {
                max: b,
                min: c
            }
        },
        getYTickFormat: function(b) {
            if (b === 0) {
                return ""
            }
            if (b >= 1000000) {
                return b.toExponential(1)
            }
            return b
        },
        getTooltipYearHTML: function(f, e) {
            var d = this.tooltipMapping[this.getYearIndex(this.getStartDate(), f)];
            var c, b, g;
            if (10000 <= Ext.max([f.new_count, f.modify_count, f.delete_count])) {
                e.addClass("bigger")
            } else {
                e.removeClass("bigger")
            }
            c = (f.new_count >= 100000000) ? f.new_count.toExponential(3) : f.new_count;
            b = (f.modify_count >= 100000000) ? f.modify_count.toExponential(3) : f.modify_count;
            g = (f.delete_count >= 100000000) ? f.delete_count.toExponential(3) : f.delete_count;
            return "<div class='title'>" + d + "</div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text blue'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_new") + ":</span><span class='right'><font class='new-count'>" + c + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div><div class='text-item tooltip-text green'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_modify") + ":</span><span class='right'><font class='modify-count'>" + b + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div><div class='text-item tooltip-text red'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_delete") + ":</span><span class='right'><font class='delete-count'>" + g + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div></div>"
        },
        getTooltipHTML: function(g, f) {
            var d = new Date(g.end_time * 1000);
            var e = (d.getMonth() + 1) + "/" + d.getDate();
            var c, b, h;
            if (10000 <= Ext.max([g.new_count, g.modify_count, g.delete_count])) {
                f.addClass("bigger")
            } else {
                f.removeClass("bigger")
            }
            c = (g.new_count >= 100000000) ? g.new_count.toExponential(3) : g.new_count;
            b = (g.modify_count >= 100000000) ? g.modify_count.toExponential(3) : g.modify_count;
            h = (g.delete_count >= 100000000) ? g.delete_count.toExponential(3) : g.delete_count;
            return "<div class='title'><span class='left'>" + e + "</span></div><hr class='divider'><div class='text-field'><div class='text-item tooltip-text blue'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_new") + ":</span><span class='right'><font class='new-count'>" + c + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div><div class='text-item tooltip-text green'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_modify") + ":</span><span class='right'><font class='modify-count'>" + b + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div><div class='text-item tooltip-text red'><span class='left'>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_delete") + ":</span><span class='right'><font class='delete-count'>" + h + "</font> " + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_files") + "</span></div></div>"
        }
    })
})();
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.TargetParamsPanel", {
    extend: "SYNO.SDS.Backup.Client.Common.FormPanel",
    isDisableNotify: false,
    isAddedTooltip: false,
    cacheData: null,
    readOnly: false,
    autoFlexcroll: false,
    constructor: function(a) {
        var b = this;
        var c;
        if (!a.readOnly) {
            c = Ext.apply({
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_size"),
                    name: "enable_target_max_size",
                    groupFields: {
                        enable: ["target_max_size", "target_max_size_scale"]
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    indent: 1,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "target_max_size_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "limit_target_size") + ": "
                    }, {
                        xtype: "syno_numberfield",
                        name: "target_max_size",
                        allowBlank: false,
                        allowDecimals: true,
                        width: 80,
                        value: 0,
                        minValue: 0,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "8"
                        },
                        validator: function(e) {
                            var d = function(f) {
                                return b.getForm().findField(f)
                            };
                            if (Ext.isObject(b.cacheData)) {
                                return b.sizeValidater(d("target_max_size").getValue(), d("target_max_size_scale").getValue())
                            }
                        }
                    }, {
                        xtype: "syno_combobox",
                        name: "target_max_size_scale",
                        width: 60,
                        valueField: "value",
                        displayField: "display",
                        value: 2,
                        store: new Ext.data.SimpleStore({
                            autoDestroy: true,
                            fields: ["value", "display"],
                            data: [
                                [0, "KB"],
                                [1, "MB"],
                                [2, "GB"],
                                [3, "TB"],
                                [4, "PB"]
                            ]
                        })
                    }, {
                        xtype: "syno_displayfield",
                        name: "target_volume_size_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "current_target_size") + ": "
                    }, {
                        xtype: "syno_displayfield",
                        name: "target_volume_size",
                        value: ""
                    }]
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_growth"),
                    name: "enable_target_growth",
                    groupFields: {
                        enable: ["target_growth_size", "target_growth_size_scale"]
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    indent: 1,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "target_growth_size_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "limit_target_growth") + ": "
                    }, {
                        xtype: "syno_numberfield",
                        name: "target_growth_size",
                        allowBlank: false,
                        allowDecimals: true,
                        width: 80,
                        value: 500,
                        minValue: 0,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "8"
                        },
                        validator: function(e) {
                            var d = function(f) {
                                return b.getForm().findField(f)
                            };
                            if (Ext.isObject(b.cacheData)) {
                                return b.sizeValidater(d("target_growth_size").getValue(), d("target_growth_size_scale").getValue())
                            }
                        }
                    }, {
                        xtype: "syno_combobox",
                        name: "target_growth_size_scale",
                        width: 60,
                        valueField: "value",
                        displayField: "display",
                        value: 1,
                        store: new Ext.data.SimpleStore({
                            autoDestroy: true,
                            fields: ["value", "display"],
                            data: [
                                [0, "KB"],
                                [1, "MB"],
                                [2, "GB"],
                                [3, "TB"],
                                [4, "PB"]
                            ]
                        })
                    }]
                }]
            }, a)
        } else {
            c = Ext.apply({
                items: [{
                    xtype: "syno_displayfield",
                    name: "enable_target_max_size_description"
                }, {
                    xtype: "syno_displayfield",
                    name: "enable_target_growth_description"
                }]
            }, a)
        }
        this.callParent([c]);
        this.mon(this, "activate", function() {
            var e = this;
            var d = function(g) {
                return e.getForm().findField(g)
            };
            var f = function(i, g) {
                var h = e.getForm().findField(i);
                if (h && h.getEl()) {
                    SYNO.ux.AddTip(h.getEl(), g)
                }
            };
            if (!this.readOnly) {
                d("target_volume_size").hide();
                d("target_volume_size_label").hide()
            }
            if (!this.isDisableNotify) {
                f("enable_target_growth", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_target_growth"));
                this.isAddedTooltip = true
            }
        }, this, {
            single: true
        })
    },
    changeTooltip: function(d, c) {
        var f = this.getForm().findField(d);
        var a = f.getEl();
        var b = Ext.getDom(a).parentNode.childNodes;
        var e = b[b.length - 1];
        if ("A" === e.tagName) {
            e = e.childNodes[0];
            e.setAttribute("ext:qtip", c);
            e.setAttribute("alt", c)
        } else {
            SYNO.ux.AddTip(a, c)
        }
    },
    disableNotify: function() {
        var b = this;
        var a = function(d) {
            return b.getForm().findField(d)
        };
        var c = function() {
            b.changeTooltip("enable_target_max_size", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_notification_disable"));
            b.changeTooltip("enable_target_growth", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_notification_disable"));
            a("enable_target_max_size").setDisabled(true);
            a("enable_target_growth").setDisabled(true);
            a("target_max_size_label").setDisabled(true);
            a("target_max_size").setDisabled(true);
            a("target_max_size_scale").setDisabled(true);
            a("target_growth_size_label").setDisabled(true);
            a("target_growth_size").setDisabled(true);
            a("target_growth_size_scale").setDisabled(true);
            a("target_volume_size_label").setDisabled(true);
            a("target_volume_size").setDisabled(true)
        };
        this.isDisableNotify = true;
        if (this.isAddedTooltip) {
            c()
        } else {
            this.mon(this, "activate", function() {
                c();
                b.isAddedTooltip = true
            }, this, {
                single: true
            })
        }
    },
    scaleToStr: function(a) {
        switch (a) {
            case 0:
                return "KB";
            case 1:
                return "MB";
            case 2:
                return "GB";
            case 3:
                return "TB";
            case 4:
                return "PB";
            default:
                return "GB"
        }
        return "GB"
    },
    loadNotifyData: function(d) {
        var i = this;
        this.cacheData = d;
        var f = 0,
            b, c;
        var a = function(j) {
            return i.getForm().findField(j)
        };
        var e = function(j) {
            var k = 0;
            while (j >= 1024 && k !== 4) {
                j /= 1024;
                k++
            }
            if (j === 0) {
                k = 2
            }
            return {
                value: j,
                scale: k
            }
        };
        var h = function(l, m, k) {
            if (Ext.isNumber(k)) {
                var j = e(k);
                a(l).setValue(j.value);
                a(m).setValue(j.scale)
            }
        };
        var g = function(n, m, l) {
            if (Ext.isNumber(l)) {
                var j = e(l);
                var k = String.format(m, j.value, i.scaleToStr(j.scale));
                a(n).setValue(k)
            }
        };
        if (!this.readOnly) {
            if (d.support_volume_size) {
                if (!d.volume_unlimit) {
                    a("target_volume_size").setValue(Ext.util.Format.fileSize(d.volume_size));
                    f = d.volume_size / 1024
                } else {
                    a("target_volume_size").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "unlimited"))
                }
                a("target_volume_size").show();
                a("target_volume_size_label").show()
            }
            b = parseFloat(d.target_max_size_value);
            c = parseFloat(d.target_growth_value);
            if (b >= 0 || c >= 0) {
                this.getForm().setValues(d);
                h("target_max_size", "target_max_size_scale", b);
                h("target_growth_size", "target_growth_size_scale", c)
            } else {
                if (d.support_volume_size && !d.volume_unlimit) {
                    h("target_max_size", "target_max_size_scale", f * 0.7);
                    h("target_growth_size", "target_growth_size_scale", f * 0.05)
                } else {
                    h("target_max_size", "target_max_size_scale", 0);
                    h("target_growth_size", "target_growth_size_scale", 512000)
                }
            }
        } else {
            if (d.enable_target_max_size) {
                b = parseFloat(d.target_max_size_value);
                if (b >= 0) {
                    g("enable_target_max_size_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_size_set"), b)
                }
            } else {
                a("enable_target_max_size_description").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_size_not_set"))
            }
            if (d.enable_target_growth) {
                c = parseFloat(d.target_growth_value);
                if (c >= 0) {
                    g("enable_target_growth_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_growth_set"), c)
                }
            } else {
                a("enable_target_growth_description").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_target_growth_not_set"))
            }
            this.changeTooltip("enable_target_growth_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_target_growth"));
            this.isAddedTooltip = true
        }
    },
    getParams: function() {
        if (this.readOnly) {
            return {}
        }
        var e = this.getForm(),
            f = function(h) {
                return e.findField(h).getValue()
            };
        var a = 0;
        var g = 0;
        var c = f("target_max_size");
        var d = f("target_max_size_scale");
        var b;
        for (b = 0; b < d; b++) {
            c *= 1024
        }
        a = c;
        c = f("target_growth_size");
        d = f("target_growth_size_scale");
        for (b = 0; b < d; b++) {
            c *= 1024
        }
        g = c;
        return {
            enable_target_max_size: f("enable_target_max_size"),
            enable_target_growth: f("enable_target_growth"),
            target_max_size_value: a,
            target_growth_value: g
        }
    },
    isValid: function() {
        var b = this;
        var a = function(c) {
            return b.getForm().findField(c)
        };
        return this.getForm().isValid() && a("target_max_size").isValid() && a("target_growth_size").isValid()
    },
    sizeValidater: function(d, e) {
        var c = function(f, g) {
            while (g > 0) {
                f *= 1024;
                g--
            }
            return f
        };
        var b, a;
        b = c(d, e);
        if (this.cacheData.support_volume_size) {
            if (!this.cacheData.volume_unlimit) {
                a = this.cacheData.volume_size / 1024;
                if (b > a) {
                    return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "maxnumber"), Ext.util.Format.fileSize(this.cacheData.volume_size))
                }
            }
        } else {
            if (b > 1099511627776000) {
                return String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "maxnumber"), Ext.util.Format.fileSize(1099511627776000 * 1024))
            }
        }
        return true
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.SourceChangeParamsPanel", {
    extend: "SYNO.SDS.Backup.Client.Common.FormPanel",
    isDisableNotify: false,
    isAddedTooltip: false,
    readOnly: false,
    autoFlexcroll: false,
    constructor: function(a) {
        var b;
        if (!a.readOnly) {
            b = Ext.apply({
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_new"),
                    name: "enable_new_count",
                    groupFields: {
                        enable: ["new_count_percent"]
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    indent: 1,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "new_count_percent_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "limit_file_new") + ": "
                    }, {
                        xtype: "syno_numberfield",
                        name: "new_count_percent",
                        allowBlank: false,
                        allowDecimals: false,
                        width: 50,
                        value: 50,
                        minValue: 0,
                        maxValue: 100,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "3"
                        }
                    }, {
                        xtype: "syno_displayfield",
                        name: "new_percent_label",
                        value: "%"
                    }]
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_modify"),
                    name: "enable_modify_count",
                    groupFields: {
                        enable: ["modify_count_percent"]
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    indent: 1,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "modify_count_percent_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "limit_file_modify") + ": "
                    }, {
                        xtype: "syno_numberfield",
                        name: "modify_count_percent",
                        allowBlank: false,
                        allowDecimals: false,
                        width: 50,
                        value: 50,
                        minValue: 0,
                        maxValue: 100,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "3"
                        }
                    }, {
                        xtype: "syno_displayfield",
                        name: "modify_percent_label",
                        value: "%"
                    }]
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_delete"),
                    name: "enable_delete_count",
                    groupFields: {
                        enable: ["delete_count_percent"]
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    indent: 1,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "delete_count_percent_label",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "limit_file_delete") + ": "
                    }, {
                        xtype: "syno_numberfield",
                        name: "delete_count_percent",
                        allowBlank: false,
                        allowDecimals: false,
                        width: 50,
                        value: 50,
                        minValue: 0,
                        maxValue: 100,
                        autoCreate: {
                            tag: "input",
                            type: "text",
                            autocomplete: "off",
                            maxlength: "3"
                        }
                    }, {
                        xtype: "syno_displayfield",
                        name: "delete_percent_label",
                        value: "%"
                    }]
                }]
            }, a)
        } else {
            b = Ext.apply({
                items: [{
                    xtype: "syno_displayfield",
                    name: "enable_new_count_description"
                }, {
                    xtype: "syno_displayfield",
                    name: "enable_modify_count_description"
                }, {
                    xtype: "syno_displayfield",
                    name: "enable_delete_count_description"
                }]
            }, a)
        }
        this.callParent([b]);
        this.mon(this, "activate", function() {
            var c = this;
            var d = function(g, e) {
                var f = c.getForm().findField(g);
                if (f && f.getEl()) {
                    SYNO.ux.AddTip(f.getEl(), e)
                }
            };
            if (this.readOnly) {
                d("enable_new_count_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_new_file_alert_contain_meta"));
                d("enable_modify_count_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_modify_file_alert_contain_meta"));
                d("enable_delete_count_description", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_delete_file_alert_contain_meta"));
                this.isAddedTooltip = true
            }
            if (!this.isDisableNotify) {
                d("enable_new_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_new_file_alert_contain_meta"));
                d("enable_modify_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_modify_file_alert_contain_meta"));
                d("enable_delete_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_delete_file_alert_contain_meta"));
                this.isAddedTooltip = true
            }
        }, this, {
            single: true
        })
    },
    changeTooltip: function(d, c) {
        var f = this.getForm().findField(d);
        var a = f.getEl();
        var b = Ext.getDom(a).parentNode.childNodes;
        var e = b[b.length - 1];
        if ("A" === e.tagName) {
            e = e.childNodes[0];
            e.setAttribute("ext:qtip", c);
            e.setAttribute("alt", c)
        } else {
            SYNO.ux.AddTip(a, c)
        }
    },
    disableNotify: function() {
        var b = this;
        var a = function(d) {
            return b.getForm().findField(d)
        };
        var c = function() {
            b.changeTooltip("enable_new_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_notification_disable"));
            b.changeTooltip("enable_modify_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_notification_disable"));
            b.changeTooltip("enable_delete_count", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "qtip_notification_disable"));
            a("enable_new_count").setDisabled(true);
            a("enable_modify_count").setDisabled(true);
            a("enable_delete_count").setDisabled(true);
            a("new_count_percent").setValue(0);
            a("new_count_percent_label").setDisabled(true);
            a("new_count_percent").setDisabled(true);
            a("new_percent_label").setDisabled(true);
            a("modify_count_percent").setValue(0);
            a("modify_count_percent_label").setDisabled(true);
            a("modify_count_percent").setDisabled(true);
            a("modify_percent_label").setDisabled(true);
            a("delete_count_percent").setValue(0);
            a("delete_count_percent_label").setDisabled(true);
            a("delete_count_percent").setDisabled(true);
            a("delete_percent_label").setDisabled(true)
        };
        this.isDisableNotify = true;
        if (this.isAddedTooltip) {
            c()
        } else {
            this.mon(this, "activate", function() {
                c();
                b.isAddedTooltip = true
            }, this, {
                single: true
            })
        }
    },
    loadNotifyData: function(d) {
        var b = this;
        var a = function(e) {
            return b.getForm().findField(e)
        };
        if (!this.readOnly) {
            a("enable_new_count").setValue(d.enable_new_count);
            a("enable_modify_count").setValue(d.enable_modify_count);
            a("enable_delete_count").setValue(d.enable_delete_count);
            if (d.new_count_percent >= 0) {
                a("new_count_percent").setValue(d.new_count_percent)
            } else {
                a("new_count_percent").setValue(50)
            }
            if (d.modify_count_percent >= 0) {
                a("modify_count_percent").setValue(d.modify_count_percent)
            } else {
                a("modify_count_percent").setValue(50)
            }
            if (d.delete_count_percent >= 0) {
                a("delete_count_percent").setValue(d.delete_count_percent)
            } else {
                a("delete_count_percent").setValue(50)
            }
        } else {
            var c = "";
            if (d.enable_new_count && d.new_count_percent >= 0) {
                c = String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_new_set"), d.new_count_percent);
                a("enable_new_count_description").setValue(c)
            } else {
                a("enable_new_count_description").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_new_not_set"))
            }
            if (d.enable_modify_count && d.modify_count_percent >= 0) {
                c = String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_modify_set"), d.modify_count_percent);
                a("enable_modify_count_description").setValue(c)
            } else {
                a("enable_modify_count_description").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_modify_not_set"))
            }
            if (d.enable_delete_count && d.delete_count_percent >= 0) {
                c = String.format(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_delete_set"), d.delete_count_percent);
                a("enable_delete_count_description").setValue(c)
            } else {
                a("enable_delete_count_description").setValue(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "alert_file_delete_not_set"))
            }
        }
    },
    getParams: function() {
        if (this.readOnly) {
            return {}
        }
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            enable_new_count: b("enable_new_count"),
            enable_modify_count: b("enable_modify_count"),
            enable_delete_count: b("enable_delete_count"),
            new_count_percent: b("new_count_percent"),
            modify_count_percent: b("modify_count_percent"),
            delete_count_percent: b("delete_count_percent")
        }
    },
    isValid: function() {
        return this.getForm().isValid()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.TopBar", {
    extend: "Ext.Container",
    constructor: function(a) {
        var c = [];
        Ext.each(a.legend, function(d) {
            var e = '<div class="statistic-legend-text">{1}</div><div class="statistic-legend-circle {0}"></div>';
            e = String.format(e, d.legend_rect_css, d.legend_text);
            c.push({
                xtype: "container",
                width: 116,
                html: e
            })
        });
        var b = Ext.apply({
            itemId: "statistics_panel_topbar",
            layout: {
                type: "hbox",
                flex: "ratio",
                align: "stretch"
            },
            items: [new Ext.Container({
                cls: "syno-backup-statistic-topbar-left-container",
                itemId: "statistics_topbar_left",
                flex: 1,
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-backup-statistic-title",
                    itemId: "statistics_graph_title",
                    hidden: true,
                    hideMode: "visibility",
                    value: "none"
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-backup-statistic-y-axis-title",
                    itemId: "statistics_y_axis_title",
                    value: ""
                }]
            }), new Ext.Container({
                cls: "syno-backup-statistic-topbar-right-container",
                itemId: "statistics_topbar_right",
                width: 384,
                layout: {
                    type: "vbox",
                    pack: "start",
                    align: "stretch"
                },
                items: [new Ext.Container({
                    cls: "syno-backup-statistic-topbar-right-top-container",
                    itemId: "statistics_topbar_right_top",
                    flex: 1,
                    layout: {
                        type: "hbox",
                        pack: "start",
                        align: "top"
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-backup-statistic-graph-time-range-title",
                        flex: 2,
                        height: 28,
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "time_range") + ":"
                    }, {
                        xtype: "syno_combobox",
                        cls: "syno-backup-statistic-graph-time-range-combobox",
                        itemId: "statistics_graph_time_range",
                        flex: 1,
                        height: 28,
                        width: 162,
                        name: "time_range",
                        valueField: "value",
                        displayField: "display",
                        value: "month",
                        store: new Ext.data.SimpleStore({
                            autoDestroy: true,
                            fields: ["value", "display"],
                            data: [
                                ["month", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "time_range_month")],
                                ["year", SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "time_range_year")]
                            ]
                        }),
                        listeners: {
                            select: function(f, d, e) {
                                this.fireEvent("select_time_range", d.data.value)
                            },
                            scope: this
                        }
                    }]
                }), new Ext.Container({
                    cls: "syno-backup-statistic-topbar-right-bottom-container",
                    flex: 1,
                    layout: {
                        type: "hbox",
                        pack: "end",
                        align: "middle"
                    },
                    items: c
                })]
            })]
        }, a);
        this.callParent([b])
    },
    setStatisticTitle: function(a) {
        this.getComponent("statistics_topbar_left").getComponent("statistics_graph_title").setValue(a);
        this.getComponent("statistics_topbar_left").getComponent("statistics_graph_title").setVisible(true)
    },
    setYAxisTitle: function(a) {
        this.getComponent("statistics_topbar_left").getComponent("statistics_y_axis_title").setValue(a)
    },
    setTimeRange: function(a) {
        this.getComponent("statistics_topbar_right").getComponent("statistics_topbar_right_top").getComponent("statistics_graph_time_range").setValue(a)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.BaseTabPanel", {
    extend: "SYNO.ux.Panel",
    autoFlexcroll: true,
    constructor: function(a) {
        this.callParent([a])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", this.onActivate, this);
        this.mon(this.lineChart, "click_change_month_btn", this.onChangeMonthBtnClick, this);
        this.mon(this.topBar, "select_time_range", this.onTimeRangeSelect, this)
    },
    redraw: function() {
        this.lineChart.redraw()
    },
    loadStatisticsData: function(b, a) {
        if ("month" === a.timeRange) {
            this.topBar.setStatisticTitle(a.getMonthTitle())
        } else {
            if ("year" === a.timeRange) {
                this.topBar.setStatisticTitle(a.getYearTitle())
            }
        }
        this.topBar.setTimeRange(a.timeRange);
        this.lineChart.setData(b, a)
    },
    onResize: function(f, d, b, e) {
        var a = this.readOnly ? d - 252 : d - 204;
        var c = 10;
        this.lineChart.setSize(f - c, a);
        this.callParent(arguments)
    },
    onActivate: function() {
        this.lineChart.redraw();
        if (!Ext.isEmpty(this.paramsPanel)) {
            this.paramsPanel.fireEvent("activate")
        }
    },
    onChangeMonthBtnClick: function(a) {
        this.fireEvent("click_change_month_btn", a)
    },
    onTimeRangeSelect: function(a) {
        this.fireEvent("select_time_range", a)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.TargetPanel", {
    extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseTabPanel",
    topBar: null,
    lineChart: null,
    paramsPanel: null,
    constructor: function(a) {
        this.topBar = new SYNO.SDS.Backup.Client.Common.Statistic.TopBar({
            cls: "syno-backup-statistic-topbar-container",
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 60,
            legend: this.getLegend()
        });
        this.lineChart = new SYNO.SDS.Backup.Client.Common.Statistic.TargetLineChart({
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 200
        });
        this.paramsPanel = new SYNO.SDS.Backup.Client.Common.Statistic.TargetParamsPanel({
            cls: "syno-backup-statistic-params-panel",
            readOnly: a.readOnly,
            appWin: a.appWin,
            owner: this
        });
        var b = Ext.apply({
            items: [this.topBar, this.lineChart, this.paramsPanel]
        }, a);
        this.callParent([b])
    },
    afterRender: function() {
        this.callParent(arguments);
        this.topBar.setYAxisTitle(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size"))
    },
    getLegend: function() {
        return [{
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_space"),
            legend_rect_css: "red"
        }, {
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_target"),
            legend_rect_css: "blue"
        }]
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.SourcePanel", {
    extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseTabPanel",
    topBar: null,
    lineChart: null,
    paramsPanel: null,
    constructor: function(a) {
        this.topBar = new SYNO.SDS.Backup.Client.Common.Statistic.TopBar({
            cls: "syno-backup-statistic-topbar-container",
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 60,
            legend: this.getLegend()
        });
        this.lineChart = new SYNO.SDS.Backup.Client.Common.Statistic.SourceLineChart({
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 200
        });
        var b = Ext.apply({
            items: [this.topBar, this.lineChart],
            bbar: {
                items: {
                    xtype: "syno_displayfield",
                    htmlEncode: false,
                    cls: "syno-backup-statistic-source-bbar",
                    value: '<span class="syno-ux-note">' + SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "note") + " </span>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "source_size_contain_metadata")
                }
            }
        }, a);
        this.callParent([b])
    },
    afterRender: function() {
        this.callParent(arguments);
        this.topBar.setYAxisTitle(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tooltip_size"))
    },
    getLegend: function() {
        return [{
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_source"),
            legend_rect_css: "red"
        }]
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.SourceChangePanel", {
    extend: "SYNO.SDS.Backup.Client.Common.Statistic.BaseTabPanel",
    topBar: null,
    lineChart: null,
    paramsPanel: null,
    constructor: function(a) {
        this.topBar = new SYNO.SDS.Backup.Client.Common.Statistic.TopBar({
            cls: "syno-backup-statistic-topbar-container",
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 60,
            legend: this.getLegend()
        });
        this.lineChart = new SYNO.SDS.Backup.Client.Common.Statistic.SourceChangeLineChart({
            appWin: a.appWin,
            mainWindow: a.mainWindow,
            owner: this,
            height: 200
        });
        this.paramsPanel = new SYNO.SDS.Backup.Client.Common.Statistic.SourceChangeParamsPanel({
            cls: "syno-backup-statistic-params-panel",
            readOnly: a.readOnly,
            appWin: a.appWin,
            owner: this
        });
        var b = Ext.apply({
            items: [this.topBar, this.lineChart, this.paramsPanel]
        }, a);
        this.callParent([b])
    },
    afterRender: function() {
        this.callParent(arguments);
        this.topBar.setYAxisTitle(SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "scale_file_count"))
    },
    getLegend: function() {
        return [{
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_new"),
            legend_rect_css: "blue"
        }, {
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_modify"),
            legend_rect_css: "green"
        }, {
            legend_text: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "line_file_delete"),
            legend_rect_css: "red"
        }]
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.DateInfo", {
    _selectedMonth: null,
    _selectedYear: null,
    timeRange: null,
    constructor: function() {
        this._selectedMonth = new Date();
        this._selectedYear = new Date();
        this.timeRange = "month"
    },
    clone: function() {
        var a = new SYNO.SDS.Backup.Client.Common.Statistic.DateInfo();
        Ext.apply(a, this);
        return a
    },
    getSelectMonthDateCount: function() {
        return this._selectedMonth.getLastDateOfMonth().getDate()
    },
    getMonthTitle: function() {
        return _T("login", "mon_" + (this._selectedMonth.getMonth() + 1)) + " " + this._selectedMonth.getFullYear()
    },
    getYearTitle: function() {
        var c = "";
        var a = this.getStartDate();
        var b = this.getEndDate();
        b = b.add(Date.MONTH, -1);
        c += (a.getFullYear() + "." + _T("login", "mon_" + (a.getMonth() + 1)));
        c += " - ";
        c += (b.getFullYear() + "." + _T("login", "mon_" + (b.getMonth() + 1)));
        return c
    },
    move: function(a, b) {
        this._selectedMonth = this._selectedMonth.add(a, b)
    },
    getStartDate: function() {
        if ("year" === this.timeRange) {
            var a = this._selectedYear;
            if (a.getDate() > 15) {
                a = a.add(Date.MONTH, 1).add(Date.YEAR, -1).getFirstDateOfMonth()
            } else {
                a = a.add(Date.YEAR, -1).getFirstDateOfMonth().add(Date.DAY, 15)
            }
            return a
        } else {
            if ("month" === this.timeRange) {
                return this._selectedMonth.getFirstDateOfMonth()
            } else {
                SYNO.Debug.error("Unknown time range setting");
                return new Date(0)
            }
        }
    },
    getEndDate: function() {
        if ("year" === this.timeRange) {
            var a = this._selectedYear;
            if (a.getDate() > 15) {
                a = a.add(Date.MONTH, 1).getFirstDateOfMonth()
            } else {
                a = a.getFirstDateOfMonth().add(Date.DAY, 15)
            }
            return a
        } else {
            if ("month" === this.timeRange) {
                return this.getStartDate().add(Date.MONTH, 1).getFirstDateOfMonth()
            } else {
                SYNO.Debug.error("Unknown time range setting");
                return new Date(0)
            }
        }
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Statistic.MainWindow", {
    extend: "SYNO.SDS.ModalWindow",
    lastParams: null,
    webapi_data: null,
    dateInfo: null,
    supportTargetStatistic: true,
    readOnly: false,
    constructor: function(b) {
        var e = Ext.isNumber(b.width) ? b.width : 800;
        var a = Ext.isNumber(b.height) ? b.height : 580;
        this.componentSize = b.readOnly ? 92 : 140;
        this.dateInfo = new SYNO.SDS.Backup.Client.Common.Statistic.DateInfo();
        var d = [new SYNO.SDS.Backup.Client.Common.Statistic.TargetPanel({
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tab_target"),
            cls: "syno-backup-statistic-panel",
            itemId: "target_panel",
            readOnly: b.readOnly,
            appWin: b.appWin,
            mainWindow: this,
            owner: this
        }), new SYNO.SDS.Backup.Client.Common.Statistic.SourcePanel({
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tab_source_disk"),
            cls: "syno-backup-statistic-panel syno-backup-statistic-source-size-panel",
            itemId: "source_panel",
            readOnly: b.readOnly,
            appWin: b.appWin,
            mainWindow: this,
            owner: this
        }), new SYNO.SDS.Backup.Client.Common.Statistic.SourceChangePanel({
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("statistics", "tab_sourcechange"),
            cls: "syno-backup-statistic-panel",
            itemId: "sourcechange_panel",
            readOnly: b.readOnly,
            appWin: b.appWin,
            mainWindow: this,
            owner: this
        })];
        var c = Ext.apply({
            cls: "syno-backup-client-common-statistic-window",
            width: e,
            height: a,
            resizable: true,
            minWidth: e,
            minHeight: a,
            items: [{
                xtype: "syno_tabpanel",
                itemId: "statistics_tab_panel",
                activeTab: 0,
                items: d
            }],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                text: _T("common", "commit"),
                btnStyle: "blue",
                hidden: b.readOnly,
                scope: this,
                handler: this.onApplyClick
            }]
        }, b);
        this.callParent([c])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this.getTargetPanel(), "click_change_month_btn", this.onChangeMonthBtnClick, this);
        this.mon(this.getSourcePanel(), "click_change_month_btn", this.onChangeMonthBtnClick, this);
        this.mon(this.getSourceChangePanel(), "click_change_month_btn", this.onChangeMonthBtnClick, this);
        this.mon(this.getTargetPanel(), "select_time_range", this.onTimeRangeSelect, this);
        this.mon(this.getSourcePanel(), "select_time_range", this.onTimeRangeSelect, this);
        this.mon(this.getSourceChangePanel(), "select_time_range", this.onTimeRangeSelect, this)
    },
    loadNotifyData: function(a) {
        this.getTargetPanel().paramsPanel.loadNotifyData(a);
        this.getTargetPanel().lineChart.setTargetMaxSize(a.enable_target_max_size, a.target_max_size_value);
        this.getSourceChangePanel().paramsPanel.loadNotifyData(a)
    },
    loadStatisticsData: function(b, a) {
        this.getTargetPanel().loadStatisticsData(b, a);
        this.getSourcePanel().loadStatisticsData(b, a);
        this.getSourceChangePanel().loadStatisticsData(b, a);
        var c = this.getComponent("statistics_tab_panel").getActiveTab();
        c.redraw()
    },
    getTargetPanel: function() {
        return this.getComponent("statistics_tab_panel").getComponent("target_panel")
    },
    getSourcePanel: function() {
        return this.getComponent("statistics_tab_panel").getComponent("source_panel")
    },
    getSourceChangePanel: function() {
        return this.getComponent("statistics_tab_panel").getComponent("sourcechange_panel")
    },
    getParams: function() {
        var a = {};
        Ext.apply(a, this.getTargetPanel().paramsPanel.getParams());
        Ext.apply(a, this.getSourceChangePanel().paramsPanel.getParams());
        return a
    },
    moveByMonthAction: function(a, b) {
        if ("month" === b.timeRange) {
            if ("next" === a) {
                b.move(Date.MONTH, 1)
            } else {
                if ("back" === a) {
                    b.move(Date.MONTH, -1)
                } else {}
            }
        }
        return b
    },
    sendStatisticsWebapi: function(b) {
        this.setStatusBusy();
        var a = this.dateInfo.clone();
        this.moveByMonthAction(b, a);
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Common.Statistic",
            version: 1,
            method: "get",
            params: {
                task_id: this.taskId,
                start_time: a.getStartDate().getTime() / 1000,
                end_time: a.getEndDate().getTime() / 1000
            },
            timeout: 120000,
            callback: this.statisticsWebapiCallback,
            scope: this,
            month_args: b
        })
    },
    statisticsWebapiCallback: function(d, a, c, b) {
        if (!d) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        this.moveByMonthAction(b.month_args, this.dateInfo);
        this.loadStatisticsData(a, this.dateInfo);
        this.clearStatusBusy()
    },
    onApplyClick: function() {
        if (this.readOnly) {
            return
        }
        var a = this.getParams();
        if (Ext.encode(this.lastParams) === Ext.encode(a)) {
            this.setStatusError({
                text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "edit_no_change")
            });
            return
        }
        if (!this.getTargetPanel().paramsPanel.isValid()) {
            this.getComponent("statistics_tab_panel").setActiveTab("target_panel");
            return
        }
        if (!this.getSourceChangePanel().paramsPanel.isValid()) {
            this.getComponent("statistics_tab_panel").setActiveTab("sourcechange_panel");
            return
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.SDS.Backup.Client.Common.Statistic",
            version: 1,
            method: "config_set",
            params: {
                task_id: this.taskId,
                statistic_params: a
            },
            timeout: 120000,
            callback: this.onApplyDone,
            scope: this
        })
    },
    onApplyDone: function(f, a, c, b) {
        if (!f) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"));
            return
        }
        var e = this.getParams();
        if (this.lastParams.enable_target_max_size !== e.enable_target_max_size || this.lastParams.target_max_size_value !== e.target_max_size_value) {
            this.getTargetPanel().lineChart.setTargetMaxSize(e.enable_target_max_size, e.target_max_size_value);
            var d = this.getComponent("statistics_tab_panel").getActiveTab();
            if ("target_panel" === d.itemId) {
                d.redraw()
            }
        }
        this.lastParams = e;
        this.clearStatusBusy();
        this.setStatusOK()
    },
    onOpen: function() {
        this.setStatusBusy();
        if (false === this.supportTargetStatistic) {
            this.getComponent("statistics_tab_panel").setActiveTab("sourcechange_panel");
            this.getComponent("statistics_tab_panel").hideTabStripItem("target_panel")
        }
        var a = [{
            api: "SYNO.SDS.Backup.Client.Common.Statistic",
            version: 1,
            method: "config_get",
            scope: this,
            params: {
                task_id: this.taskId
            }
        }, {
            api: "SYNO.SDS.Backup.Client.Common.Statistic",
            version: 1,
            method: "get",
            params: {
                task_id: this.taskId,
                start_time: this.dateInfo.getStartDate().getTime() / 1000,
                end_time: this.dateInfo.getEndDate().getTime() / 1000,
                additional: ["volume_size"]
            }
        }];
        this.sendWebAPI({
            compound: {
                stopwhenerror: false,
                mode: "parallel",
                params: a
            },
            timeout: 120000,
            scope: this,
            callback: this.onOpenDone
        });
        this.callParent(arguments)
    },
    onOpenDone: function(g, a, f, c) {
        if (!g) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        var b = true;
        Ext.each(a.result, function(h) {
            if (!h.success) {
                this.clearStatusBusy();
                this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(h.error.code), function() {
                    this.close()
                }, this);
                b = false;
                return false
            }
        }, this);
        if (!b) {
            return
        }
        var e = a.result[0].data.statistic_params;
        var d = a.result[1].data;
        Ext.copyTo(e, d, ["support_volume_size", "volume_unlimit", "volume_size"]);
        this.loadNotifyData(e);
        this.loadStatisticsData(d, this.dateInfo);
        this.lastParams = this.getParams();
        this.clearStatusBusy()
    },
    onChangeMonthBtnClick: function(a) {
        this.sendStatisticsWebapi(a)
    },
    onTimeRangeSelect: function(a) {
        this.dateInfo.timeRange = a;
        this.sendStatisticsWebapi()
    },
    onResize: function(d, b, a, c) {
        this.getTargetPanel().setSize(d - 40, b - this.componentSize);
        this.getSourcePanel().setSize(d - 40, b - this.componentSize);
        this.getSourceChangePanel().setSize(d - 40, b - this.componentSize);
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Version.SourceInfoPanel", {
    extend: "Ext.Container",
    constructor: function(a) {
        var b = {
            cls: "syno-backup-client-common-source-info-panel",
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-backup-source-info-title",
                value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "source_size_detail")
            }, new SYNO.SDS.Backup.Client.Common.Version.SourceSpace({
                itemId: "source_space"
            }), {
                xtype: "syno_displayfield",
                cls: "syno-backup-source-filter-hint",
                hidden: (!a.source || (Ext.isEmpty(a.source.whitelist) && Ext.isEmpty(a.source.exclude_list))),
                html: "<div>" + SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "file_filtered_hint") + '&nbsp<span class="syno-backup-source-filter-view-more">(' + SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "view_more") + ")</span></div>",
                listeners: {
                    scope: this,
                    afterrender: function(c) {
                        var d = a.source ? a.source : {};
                        c.getEl().select("span").on("click", function() {
                            var e = new SYNO.SDS.Backup.Client.Common.FilterSettingWindow({
                                disable_modified_source: true,
                                owner: a.owner,
                                backupFilter: Ext.copyTo({}, d, "whitelist, exclude_list")
                            });
                            e.open()
                        })
                    }
                }
            }]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    loadData: function(a) {
        this.getComponent("source_space").loadData(a)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Version.SourceSpace", {
    extend: "Ext.BoxComponent",
    constructor: function(a) {
        var b = {
            height: 166
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    initComponent: function() {
        this.callParent(arguments);
        this.pieChart = new SYNO.SDS.Backup.Client.Common.Space.PieChart({
            owner: this
        });
        this.legend = new SYNO.SDS.Backup.Client.Common.Space.Legend({
            owner: this
        })
    },
    onRender: function() {
        this.autoEl = {
            cls: "syno-backup-client-common-source-usage-info",
            cn: [{
                tag: "div",
                cls: "block pie-chart"
            }, {
                tag: "div",
                cls: "block legend"
            }]
        };
        this.callParent(arguments);
        this.pieChartEl = this.el.select("div.pie-chart").first();
        this.pieChart.render(this.pieChartEl);
        this.legendEl = this.el.select("div.legend").first();
        this.legend.render(this.legendEl)
    },
    loadData: function(b) {
        var a = this.getTotalSize(b);
        this.processData(b, a);
        this.pieChart.loadData(b, b, a);
        this.legend.loadData(b)
    },
    getTotalSize: function(b) {
        var a = 0;
        Ext.each(b, function(c) {
            var d = Ext.isNumber(c.used_size) ? c.used_size : 0;
            a += d
        }, this);
        return a
    },
    processData: function(b, a) {
        Ext.each(b, function(e) {
            var c = SYNO.SDS.Backup.Client.Common.Utils.getConvertSize(e.used_size);
            var d = SYNO.SDS.Backup.Client.Common.Utils.getUnit(e.used_size);
            e.sizeDisplay = SYNO.SDS.Backup.Client.Common.Utils.getPercentage(e.used_size, a);
            e.sizeTips = String.format("{0} {1}", c, d);
            e.sizeDetail = (e.detail) ? e.detail.join(", ") : ""
        }, this)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Version.VersionInfoPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b = {
            cls: "syno-backup-version-info-panel",
            itemId: "version_panel",
            items: this.getPanelList(a)
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    getPanelList: function(b) {
        var a = [];
        this.summaryPanel = null;
        if (!Ext.isEmpty(b.statistics)) {
            this.summaryFieldset = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "summary"),
                cls: "syno-backup-version-summary-fieldset",
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "source",
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "source_size"),
                    value: this.getSizeText(this.sumStatisticsAttr(b.statistics, "total_size"), true)
                }, {
                    xtype: "syno_displayfield",
                    itemId: "trg_increase",
                    hidden: !b.isShowTrgInc,
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "target_increase_size"),
                    value: this.getSizeText(b.statistics.target_increase_size * 1024, true)
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "new_shared_data"),
                    value: String.format("{0} ({1})", b.statistics.summary.share.new_cnt, this.getSizeText(b.statistics.summary.share.new_size, false))
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "mod_shared_data"),
                    value: String.format("{0} ({1})", b.statistics.summary.share.mod_cnt, this.getSizeText(b.statistics.summary.share.mod_size, false))
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "del_shared_data"),
                    value: String.format("{0} ({1})", b.statistics.summary.share.del_cnt, this.getSizeText(b.statistics.summary.share.del_size, false))
                }, {
                    xtype: "syno_displayfield",
                    itemId: "mod_app_data",
                    fieldLabel: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "mod_app_data"),
                    value: this.getSizeText(b.statistics.summary.app.new_size + b.statistics.summary.app.mod_size, false)
                }, {
                    xtype: "container",
                    layout: "hbox",
                    cls: "syno-backup-version-summary-download",
                    itemId: "summary-download",
                    items: [{
                        xtype: "container",
                        cls: "syno-backup-version-summary-download-icon"
                    }, {
                        xtype: "syno_displayfield",
                        cls: "syno-backup-version-summary-download-text-disabled",
                        value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "download_file_change_detail"),
                        itemId: "download-text",
                        disabled: true
                    }]
                }]
            });
            this.summaryPanel = new SYNO.ux.FormPanel({
                owner: this,
                appWin: b.appWin,
                height: 306,
                autoWidth: true,
                labelWidth: 280,
                cls: "syno-backup-version-summary-panel",
                items: this.summaryFieldset
            });
            a.push(this.summaryPanel)
        }
        var e = new Ext.grid.ColumnModel({
            columns: [{
                dataIndex: "action",
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "backingup_action_menu"),
                align: "left",
                renderer: function(j, i, f, h, k, g) {
                    if ("start" === j) {
                        return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "start_time")
                    } else {
                        if ("suspend" === j) {
                            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "suspend_time")
                        } else {
                            if ("resume" === j) {
                                return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "resume_time")
                            } else {
                                if ("cancel" === j) {
                                    return _T("common", "cancel")
                                } else {
                                    if ("failed" === j) {
                                        return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "task_status_error")
                                    } else {
                                        if ("complete" === j) {
                                            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "complete_time")
                                        } else {
                                            return ""
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }, {
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "time_info_time"),
                dataIndex: "timestamp",
                align: "left",
                renderer: this.formatTime
            }]
        });
        var c = new Ext.data.JsonStore({
            proxy: new SYNO.API.Proxy({
                api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi() + ".History",
                method: "get",
                version: 1
            }),
            fields: ["action", "timestamp"],
            root: "version_history_list",
            autoDestroy: true,
            autoLoad: true,
            totalProperty: "total",
            remoteSort: true,
            baseParams: {
                task_id: b.taskId,
                version_id: b.versionId,
                limit: 10,
                start: 0
            }
        });
        var d = new SYNO.ux.GridPanel({
            cls: "syno-backup-version-history-grid-panel",
            itemId: "version_grid",
            height: 147,
            loadMask: true,
            enableHdMenu: false,
            enableColumnMove: false,
            enableColumnResize: false,
            disableSelection: true,
            colModel: e,
            store: c,
            bbar: new SYNO.ux.PagingToolbar({
                store: c,
                displayInfo: true,
                pageSize: 10,
                showRefreshBtn: true
            })
        });
        this.historyPanel = new SYNO.ux.Panel({
            owner: this,
            appWin: b.appWin,
            layout: "fit",
            padding: "8px",
            cls: "syno-backup-version-history-panel",
            header: true,
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "time_info"),
            items: d
        });
        a.push(this.historyPanel);
        return a
    },
    onResize: function(e, c, b, d) {
        var a = 0;
        if (this.summaryPanel && this.summaryPanel.getResizeEl()) {
            a = this.summaryPanel.getSize().height;
            this.summaryFieldset.setWidth(e - 16)
        }
        if (this.historyPanel.getResizeEl()) {
            this.historyPanel.setSize(e, c - a)
        }
    },
    formatTime: function(b) {
        var a = new Date(b * 1000);
        return SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(a, {
            type: "datetimesec"
        })
    },
    downloadFileLog: function() {
        var a = {
            support_utf8_name: Ext.isChrome || Ext.isGecko || Ext.isSafari,
            task_id: this.taskId,
            version_id: this.versionId,
            sess_id: this.sessId,
            sess_key: this.sessKey
        };
        this.findAppWindow().downloadWebAPI({
            webapi: {
                api: "SYNO.SDS.Backup.Client.Common.Version",
                version: 1,
                method: "download_file_log",
                params: a
            },
            scope: this,
            callback: function(d, c, e, b) {
                if (!e && b) {
                    this.findAppWindow().getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(b.code), function() {}, this);
                    return
                }
            }
        })
    },
    getSizeText: function(c, a) {
        if (c < 0) {
            return SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "not_available")
        }
        var b = a ? " " : "";
        return String.format("{0}{1}{2}", SYNO.SDS.Backup.Client.Common.Utils.getConvertSize(c), b, SYNO.SDS.Backup.Client.Common.Utils.getUnit(c))
    },
    sumStatisticsAttr: function(c, a) {
        var b = c.summary;
        return b.app[a] + b.share[a] + b.ea[a]
    },
    afterRender: function() {
        if (!Ext.isEmpty(this.statistics)) {
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.SDS.Backup.Client.Common.Version",
                version: 1,
                method: "check_file_log",
                params: {
                    task_id: this.taskId,
                    version_id: this.versionId
                },
                callback: this.onCheckFileLogDone,
                scope: this
            })
        }
        return this.callParent(arguments)
    },
    onCheckFileLogDone: function(e, a, c) {
        if (!e) {
            this.owner.clearStatusBusy();
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(a.code), function() {
                this.close()
            }, this);
            return
        }
        var d = this.summaryFieldset.getComponent("summary-download").getComponent("download-text");
        if (a.can_download) {
            d.removeClass("syno-backup-version-summary-download-text-disabled");
            d.addClass("syno-backup-version-summary-download-text");
            d.setDisabled(false);
            d.getEl().on("click", this.downloadFileLog, this)
        } else {
            var b = "version_log_disable";
            if (!Ext.isEmpty(a.reason)) {
                switch (a.reason) {
                    case "version_not_complete":
                        b = "version_log_version_not_complete";
                        break;
                    case "log_disable":
                        b = "version_log_disable";
                        break
                }
            }
            SYNO.ux.AddTip(d, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", b));
            this.doLayout()
        }
        this.owner.clearStatusBusy()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Version.VersionInfoWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        var a = Ext.isEmpty(b.statistics) ? 270 : 570;
        this.isShowTrgInc = Ext.isEmpty(b.accountMeta) ? true : (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.SPACE_SOURCE !== b.accountMeta.spaceUsage);
        var c = {
            cls: "syno-backup-client-common-version-info-window",
            width: 580,
            height: a,
            resizable: false,
            layout: "fit",
            minWidth: 580,
            minHeight: a,
            title: _T("backup", "version_info"),
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }],
            items: new SYNO.SDS.Backup.Client.Common.Version.VersionInfoPanel({
                owner: this,
                itemId: "version_panel",
                taskId: b.taskId,
                versionId: b.versionId,
                source: b.source,
                statistics: b.statistics,
                accountMeta: b.accountMeta,
                sessId: b.sessId,
                sessKey: b.sessKey,
                isShowTrgInc: this.isShowTrgInc
            })
        };
        Ext.apply(c, b);
        this.callParent([c])
    },
    setSourceTipContent: function(a) {
        var b = new SYNO.SDS.Backup.Client.Common.Version.SourceInfoPanel({
            owner: this,
            source: this.source,
            id: (this.sourceInfoPanelId = Ext.id())
        });
        this.add(b);
        this.doLayout();
        b.loadData(a);
        this.remove(b, false);
        this.doLayout();
        SYNO.ux.AddWhiteTipWithItem(this.getComponent("version_panel").summaryFieldset.getComponent("source"), b, 514)
    },
    setSourceAndTargetTip: function(a) {
        if (a) {
            var b = function(e, d) {
                this.source[d] = this.source[d].filter(function(f) {
                    var g = false;
                    Ext.each(a, function(h) {
                        if (e === h.type && h.path === f) {
                            g = true;
                            return false
                        }
                    });
                    return !g
                })
            };
            b.call(this, "folder", "backup_shares");
            b.call(this, "application", "backup_apps")
        }
        var c = [{
            used_size: this.statistics.summary.share.total_size,
            show_name: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "shared_folder_size"),
            detail: this.source.backup_shares
        }, {
            used_size: this.statistics.summary.app.total_size,
            show_name: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "application_size"),
            detail: this.source.backup_apps
        }, {
            used_size: this.statistics.summary.ea.total_size,
            show_name: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "meta_size")
        }];
        this.setSourceTipContent(c);
        if (this.isShowTrgInc) {
            SYNO.SDS.Utils.AddTip(this.getComponent("version_panel").summaryFieldset.getComponent("trg_increase").getEl(), String.format("{0}: {1}{2}, {3}: {4}", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "dedup_size"), SYNO.SDS.Backup.Client.Common.Utils.getConvertSize(this.statistics.dedup_size), SYNO.SDS.Backup.Client.Common.Utils.getUnit(this.statistics.dedup_size), SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "compression_ratio"), this.statistics.compress_ratio.toFixed(2)))
        }
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", function() {
            if (Ext.isEmpty(this.statistics)) {
                this.doLayout();
                return
            }
            var a = new SYNO.SDS.Backup.Client.Common.Version.SourceInfoPanel({
                owner: this,
                source: this.source,
                id: (this.sourceInfoPanelId = Ext.id())
            });
            a.addClass("syno-backup-pre-draw-panel");
            this.add(a);
            this.doLayout();
            if (this.isPartial) {
                this.setStatusBusy();
                this.sendWebAPI({
                    api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
                    method: "detail",
                    version: 1,
                    params: {
                        task_id: this.taskId,
                        version_id: this.versionId,
                        limit: 50,
                        start: 0
                    },
                    scope: this,
                    callback: function(e, b, d, c) {
                        if (!e) {
                            this.clearStatusBusy();
                            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(b.code), function() {
                                this.close()
                            }, this);
                            return
                        }
                        this.setSourceAndTargetTip(b.error_cause);
                        this.clearStatusBusy()
                    }
                })
            } else {
                this.setSourceAndTargetTip()
            }
            SYNO.SDS.Utils.AddTip(this.getComponent("version_panel").summaryFieldset.getComponent("mod_app_data").getEl(), SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "mod_app_data_include_info"))
        }, this, {
            single: true
        });
        this.mon(this, "close", function() {
            if (!Ext.isEmpty(this.sourceInfoPanelId)) {
                Ext.getCmp(this.sourceInfoPanelId).destroy()
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Version.MainWindow", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    pageSize: 50,
    constructor: function(a) {
        this.isPolling = false;
        this.hideVersionDelete = a.hideVersionDelete;
        this.hideVersionLock = a.hideVersionLock;
        this.accountMeta = a.accountMeta;
        this.sessId = a.sessId;
        this.sessKey = a.sessKey;
        this.openVersion = a.openVersion;
        var b = Ext.apply({
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "version_list"),
            cls: "syno-backup-client-common-version-list-window",
            width: 830,
            height: 540,
            layout: "fit",
            useStatusBar: true,
            minWidth: 830,
            minHeight: 540,
            items: [{
                xtype: "syno_gridpanel",
                cls: "syno-backup-version-list-grid-panel",
                itemId: "version_grid",
                store: this.getStore(),
                loadMask: true,
                viewConfig: {
                    trackResetOnLoad: false
                },
                autoExpandColumn: "timestamp",
                enableHdMenu: false,
                enableColumnMove: false,
                enableColumnResize: false,
                disableSelection: true,
                trackMouseOver: true,
                defaults: {
                    sortable: false
                },
                colModel: this.getColModel(false),
                bbar: new SYNO.ux.PagingToolbar({
                    store: this.getStore(),
                    displayInfo: true,
                    pageSize: this.pageSize,
                    listeners: {
                        beforechange: {
                            fn: this.addGridLoadMask,
                            scope: this
                        }
                    },
                    showRefreshBtn: true
                })
            }],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }],
            listeners: {
                close: this.stopPolling,
                scope: this
            }
        }, a);
        this.callParent([b])
    },
    getColModel: function(b) {
        var a = 40;
        return new Ext.grid.ColumnModel([{
            header: "",
            dataIndex: "locked",
            width: a,
            hidden: b,
            resizable: false,
            align: "center",
            renderer: this.renderLocked.createDelegate(this)
        }, {
            header: _T("backup", "version_time"),
            dataIndex: "timestamp",
            width: b ? (214 + a) : 214,
            align: "left",
            renderer: this.formatTime
        }, {
            header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "version_complete_time"),
            dataIndex: "complete_time",
            width: 214,
            align: "left",
            renderer: {
                fn: function(h, d, c, i, f, e) {
                    var g = c.get("complete_time");
                    if (0 !== g) {
                        return this.formatTime(g)
                    }
                    return ("suspend" === c.get("status")) ? "-" : ""
                },
                scope: this
            }
        }, {
            header: _T("backup", "version_status"),
            dataIndex: "status",
            width: 305,
            resizable: false,
            align: "left",
            renderer: this.statusToStr.createDelegate(this)
        }])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this.getGrid(), "rowclick", function(b, f, d) {
            var c = Ext.fly(d.target);
            if (!c) {
                return
            }
            var a = this.store.getAt(f);
            if (c.hasClass("syno-backup-version-browse")) {
                this.onFileRestore(a.get("timestamp"))
            } else {
                if (c.hasClass("syno-backup-version-delete")) {
                    this.onVersionDelete(a.get("version_id"), a.get("timestamp"), a.get("status"))
                } else {
                    if (c.hasClass("syno-backup-version-lock")) {
                        this.onVersionUnLock(a.get("version_id"))
                    } else {
                        if (c.hasClass("syno-backup-version-unlock")) {
                            this.lockVersion(a.get("version_id"), true)
                        } else {
                            if (c.hasClass("syno-backup-version-detail-link")) {
                                this.launchDetailWindow(a.get("version_id"))
                            } else {
                                if (c.hasClass("syno-backup-version-info")) {
                                    this.launchVersionInfoWindow(a.get("version_id"))
                                }
                            }
                        }
                    }
                }
            }
        }, this);
        this.mon(this.getGrid(), "rowdblclick", function(a, f, c) {
            var d = a.getStore().getAt(f);
            var b = Ext.fly(c.target);
            if (b && (b.hasClass("syno-backup-version-lock") || b.hasClass("syno-backup-version-unlock") || b.hasClass("syno-backup-version-lock-disable") || b.hasClass("syno-backup-version-delete") || b.hasClass("syno-backup-version-delete-disable") || b.hasClass("syno-backup-version-detail-link") || b.hasClass("syno-backup-version-info"))) {
                return true
            }
            if (d.get("status") === "success" || d.get("status") === "partial") {
                this.onFileRestore(d.get("timestamp"))
            }
        }, this)
    },
    onShow: function() {
        if (this.getGrid().loadMask) {
            this.getGrid().loadMask.show()
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
            version: 2,
            method: "list",
            params: {
                repo_id: this.repoId,
                task_id: this.taskId,
                target_id: this.targetId,
                offset: 0,
                limit: this.pageSize,
                additional: ["version_operate_property", "skip_check_key", "source", "statistics"],
                filter_name: "available",
                account_meta: this.accountMeta
            },
            scope: this,
            callback: function(d, b, c) {
                if (this.getGrid().loadMask) {
                    this.getGrid().loadMask.hide()
                }
                this.clearStatusBusy();
                if (!d) {
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(b.code), function() {
                        this.close()
                    }, this);
                    return
                }
                this.supportLock = b.support_lock;
                this.permitDelete = b.permit_delete.permitted;
                if (!b.permit_delete.permitted && b.permit_delete.error) {
                    this.permitDeleteError = b.permit_delete.error
                }
                if (this.hideVersionLock) {
                    this.getGrid().reconfigure(this.getStore(), this.getColModel(true))
                }
                this.getStore().loadData(b, false);
                if (undefined !== this.openVersion) {
                    var a = false;
                    this.getStore().each(function(e) {
                        if (this.openVersion === e.get("version_id")) {
                            a = true;
                            this.launchVersionInfoWindow(this.openVersion);
                            return false
                        }
                    }, this);
                    if (!a) {
                        this.getMsgBox().alert("", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "backup_version_not_exist"))
                    }
                }
            }
        })
    },
    adjustStatusStringWdith: function() {
        var b = this.getEl();
        var a = b.select(".syno-backup-version-status");
        Ext.each(a.elements, function(f) {
            var e = Ext.get(f);
            var g = e.select(".syno-backup-version-detail-link");
            if (0 === g.elements.length) {
                return true
            }
            var d = Ext.get(g.elements[0]);
            var c = Ext.get(e.select(".status-str").elements[0]);
            c.setStyle("max-width", (e.getWidth() - d.getWidth()) + "px")
        }, this);
        this.doLayout()
    },
    onFileRestore: function(a) {
        SYNO.SDS.Backup.Client.Common.Utils.LaunchExplorer(this, a)
    },
    onVersionDelete: function(b, c, a) {
        this.getMsgBox().confirmDelete(this.title, String.format(_T("common", "remove_cfrmrmv") + "<br />" + this.formatTime(c)), function(d) {
            if ("yes" === d) {
                this.deleteVersion(b, a)
            }
        }, this)
    },
    onVersionUnLock: function(a) {
        this.getMsgBox().confirm(this.title, _T("backup", "confirm_unlock_version"), function(b) {
            if ("yes" === b) {
                this.lockVersion(a, false)
            }
        }, this)
    },
    lockVersion: function(b, a) {
        this.setStatusBusy();
        this.stopPolling();
        this.sendWebAPI({
            api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
            version: 1,
            method: "lock",
            params: {
                task_id: this.taskId,
                repo_id: this.repoId,
                target_id: this.targetId,
                version_id: b,
                sess_id: this.sessId,
                lock: a
            },
            callback: function(e, c, d) {
                if (!e) {
                    this.startPolling();
                    this.clearStatusBusy();
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(c.code), function() {
                        if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === c.code) {
                            this.owner.clearCurTaskSession();
                            this.close()
                        }
                    }, this);
                    return
                }
                var f = this.store.find("version_id", b);
                if (-1 < f) {
                    this.store.data.itemAt(f).data.locked = a;
                    this.getGrid().getView().refreshRow(f)
                }
                this.startPolling();
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    formatTime: function(b) {
        var a = new Date(b * 1000);
        return SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(a, {
            type: "datetimesec"
        })
    },
    getStore: function() {
        if (!this.store) {
            this.store = new SYNO.API.Store({
                api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
                version: 2,
                method: "list",
                baseParams: {
                    offset: 0,
                    limit: this.pageSize,
                    filter_name: "available",
                    additional: ["version_operate_property", "skip_check_key", "source", "statistics"]
                },
                appWindow: false,
                autoLoad: false,
                reader: new Ext.data.JsonReader({
                    idProperty: "version_id",
                    root: "version_info_list",
                    totalProperty: "total",
                    fields: ["version_id", "timestamp", "modify", "status", "locked", "complete_time", "has_history", "permit_delete", "source", "statistics"]
                }),
                listeners: {
                    scope: this,
                    beforeload: this.onBeforeLoad,
                    loadexception: this.onLoadException,
                    load: this.onLoadDone
                }
            })
        }
        return this.store
    },
    getGrid: function() {
        return this.getComponent("version_grid")
    },
    deleteVersion: function(b, a) {
        this.setStatusBusy();
        this.stopPolling();
        if ("suspend" === a) {
            this.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Task",
                version: 1,
                method: "discard",
                params: {
                    task_id: this.taskId
                },
                scope: this,
                callback: function(e, c, d) {
                    this.clearStatusBusy();
                    if (!e) {
                        this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(c.code));
                        return
                    }
                    this.close()
                }
            });
            return
        }
        this.sendWebAPI({
            api: SYNO.SDS.Backup.Client.Common.Utils.GetVersionApi(),
            version: 1,
            method: "delete",
            params: {
                task_id: this.taskId,
                repo_id: this.repoId,
                target_id: this.targetId,
                sess_id: this.sessId,
                version_id_list: [b]
            },
            callback: function(e, c, d) {
                if (!e) {
                    this.startPolling();
                    this.clearStatusBusy();
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(c.code), function() {
                        if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === c.code) {
                            this.owner.clearCurTaskSession();
                            this.close()
                        }
                    }, this);
                    return
                }
                var f = this.store.find("version_id", b);
                if (-1 < f) {
                    this.store.data.itemAt(f).data.status = "deleting";
                    this.getGrid().getView().refreshRow(f)
                }
                this.clearStatusBusy();
                this.startPolling()
            },
            scope: this
        })
    },
    getVersionStatus: function(c) {
        var b = this.taskState === "restore_only" || this.taskState === "error_detect";
        var d = '<span class="status-str {0}" ext:qtip="{1}">{1}</span>{2}';
        var a = {
            none: {
                msg: String.format(d, "blue-status", _T("common", "none"), ""),
                deleteCls: "syno-backup-version-delete-hide",
                browserCls: "syno-backup-version-browse-hide",
                versionInfoCls: "syno-backup-version-info-hide"
            },
            backup: {
                msg: String.format(d, "blue-status", _T("backup", "version_status_backing_up"), ""),
                deleteCls: "syno-backup-version-delete-disable",
                browserCls: "syno-backup-version-browse-disable",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            success: {
                msg: String.format(d, "green-status", _T("backup", "version_status_success"), ""),
                deleteCls: (c.get("locked") || b ? "syno-backup-version-delete-disable" : "syno-backup-version-delete"),
                browserCls: "syno-backup-version-browse",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            failed: {
                msg: String.format(d, "red-status", _T("backup", "version_status_failed"), ""),
                deleteCls: (b ? "syno-backup-version-delete-disable" : "syno-backup-version-delete"),
                browserCls: "syno-backup-version-browse-hide",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            partial: {
                msg: String.format(d, "orange-status", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "partial_success"), "<a class='syno-backup-version-detail-link'>&nbsp(" + SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "version_detail") + ")</a>"),
                deleteCls: (c.get("locked") || b ? "syno-backup-version-delete-disable" : "syno-backup-version-delete"),
                browserCls: "syno-backup-version-browse",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            cancel: {
                msg: String.format(d, "red-status", _T("backup", "version_status_canceled"), ""),
                deleteCls: (b ? "syno-backup-version-delete-disable" : "syno-backup-version-delete"),
                browserCls: "syno-backup-version-browse-hide",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            deleting: {
                msg: String.format(d, "blue-status", _T("backup", "version_deleting"), ""),
                deleteCls: "syno-backup-version-delete-disable",
                browserCls: "syno-backup-version-browse-hide",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            del_fail: {
                msg: String.format(d, "red-status", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "deletion_fail"), ""),
                deleteCls: (b ? "syno-backup-version-delete-disable" : "syno-backup-version-delete"),
                browserCls: "syno-backup-version-browse-hide",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            },
            suspend: {
                msg: String.format(d, "orange-status", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "suspend_button_title"), ""),
                deleteCls: "syno-backup-version-delete",
                browserCls: "syno-backup-version-browse-disable",
                versionInfoCls: c.get("has_history") ? "syno-backup-version-info" : "syno-backup-version-info-hide"
            }
        };
        if (c.get("status") in a) {
            return a[c.get("status")]
        } else {
            return a.none
        }
    },
    statusToStr: function(g, e, c) {
        var b = this.getVersionStatus(c);
        var f = "";
        if (this.hideVersionDelete) {
            f = ""
        } else {
            if (this.permitDelete && c.get("permit_delete")) {
                f = '<div class="{deleteCls}" ext:qtip="{deleteQtip}"></div>'
            } else {
                if (this.permitDelete && !c.get("permit_delete")) {
                    f = '<div class="syno-backup-version-delete-disable" ext:qtip="' + SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "has_suspended_version_to_delete") + '"></div>'
                } else {
                    if (!this.permitDelete && this.permitDeleteError) {
                        var a = "";
                        f = '<div class="syno-backup-version-delete-disable" ';
                        switch (this.permitDeleteError.code) {
                            case 0:
                                a = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "unable_delete_version");
                                break;
                            case 1:
                                a = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "unable_delete_version") + "&nbsp" + SYNO.SDS.Backup.Client.Common.Utils.getRepoTargetPermissionMsg(this.permitDeleteError.params.user, this.permitDeleteError.params.permission, this.permitDeleteError.params.type, this.permitDeleteError.params.dirname);
                                break;
                            case 2:
                                f = '<div class="syno-backup-version-delete-disable hidden" ';
                                break
                        }
                        f = f + 'ext:qtip="' + a + '"></div>'
                    } else {
                        f = ""
                    }
                }
            }
        }
        var d = new Ext.XTemplate('<div class="syno-backup-version-status">{msg}</div>' + f + '<div class="{browserCls}" ext:qtip="{browserQtip}"></div><div class="{versionInfoCls}" ext:qtip="{versionInfoQtip}"></div>');
        if (b.deleteCls !== "syno-backup-version-delete-hide") {
            if (c.get("locked")) {
                b.deleteQtip = SYNO.SDS.Backup.Client.Common.Utils.GetString("error", "version_lock_delete_fail")
            } else {
                b.deleteQtip = _T("common", "delete")
            }
        }
        if (b.browserCls !== "syno-backup-version-browse-hide") {
            b.browserQtip = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "backup_explorer")
        }
        if (b.versionInfoCls !== "syno-backup-version-info-hide") {
            b.versionInfoQtip = _T("backup", "version_info")
        }
        return d.apply(b)
    },
    renderLocked: function(f, e, b) {
        var d = new Ext.XTemplate('<div class="{lockCls}" ext:qtip="{lockQtip}"></div>');
        var a = "";
        var g = "";
        if (this.hideVersionLock) {
            a = "syno-backup-version-lock-hidden"
        } else {
            if (this.supportLock) {
                var c = function(i, j) {
                    var h = "";
                    switch (j.code) {
                        case 0:
                        case 2:
                            h = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", i);
                            break;
                        case 1:
                            h = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", i) + "&nbsp" + SYNO.SDS.Backup.Client.Common.Utils.getRepoTargetPermissionMsg(j.params.user, j.params.permission, j.params.type, j.params.dirname);
                            break
                    }
                    return h
                };
                switch (b.get("status")) {
                    case "backup":
                    case "success":
                    case "partial":
                        if (f) {
                            if (this.permitDelete) {
                                a = "syno-backup-version-lock";
                                g = _T("backup", "backup_lock_qtip")
                            } else {
                                if (this.permitDeleteError) {
                                    a = "syno-backup-version-locked-display-only";
                                    g = c("unable_unlock_version", this.permitDeleteError)
                                } else {
                                    a = "syno-backup-version-locked-display-only"
                                }
                            }
                        } else {
                            if (this.permitDelete) {
                                a = "syno-backup-version-unlock";
                                g = _T("backup", "backup_unlock_qtip")
                            } else {
                                if (this.permitDeleteError) {
                                    a = "syno-backup-version-lock-disable";
                                    g = c("unable_lock_version", this.permitDeleteError)
                                } else {
                                    a = "syno-backup-version-lock-hidden"
                                }
                            }
                        }
                        break;
                    case "none":
                    case "failed":
                    case "cancel":
                    case "deleting":
                    case "del_fail":
                    case "suspend":
                        a = "syno-backup-version-lock-disable";
                        break
                }
            } else {
                a = "syno-backup-version-lock-disable";
                g = _T("backup", "version_lock_not_support")
            }
        }
        return d.apply({
            lockCls: a,
            lockQtip: g
        })
    },
    onBeforeLoad: function(a) {
        a.setBaseParam("repo_id", this.repoId);
        a.setBaseParam("task_id", this.taskId);
        a.setBaseParam("target_id", this.targetId)
    },
    addGridLoadMask: function() {
        if (this.getGrid().initialConfig.loadMask) {
            if (this.getGrid().loadMask) {
                this.getGrid().loadMask.destroy()
            }
            this.getGrid().loadMask = new Ext.LoadMask(this.getGrid().bwrap, Ext.apply({}, {
                store: this.getStore()
            }, true))
        }
    },
    onLoadDone: function(b, a, c) {
        this.adjustStatusStringWdith();
        if (this.getGrid() && this.getGrid().loadMask) {
            this.getGrid().loadMask.destroy();
            this.getGrid().loadMask = false
        }
        if (this.isTaskRunning()) {
            this.startPolling()
        } else {
            this.stopPolling()
        }
        if (this.isPolling && c.isPollReload) {
            setTimeout((function() {
                if (this.isTaskRunning()) {
                    b.reload({
                        isPollReload: true
                    })
                }
            }).createDelegate(this), 3000)
        }
    },
    onLoadException: function(c, b, a) {
        this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.Client.Common.Utils.GetErrorString(a.code), function() {
            this.close()
        }, this)
    },
    isTaskRunning: function() {
        if (undefined === this.getGrid()) {
            return false
        }
        var a = false;
        this.getStore().each(function(c) {
            var b = c.get("status");
            if ("deleting" === b || "backup" === b) {
                a = true;
                return false
            }
        });
        return a
    },
    startPolling: function() {
        if (this.isPolling) {
            return
        }
        this.isPolling = true;
        if (undefined !== this.getGrid()) {
            this.getStore().reload({
                isPollReload: true
            });
            this.adjustStatusStringWdith()
        }
    },
    stopPolling: function() {
        if (!this.isPolling) {
            return
        }
        this.isPolling = false
    },
    launchDetailWindow: function(b) {
        var a = new SYNO.SDS.Backup.Client.Common.ErrorReportWindow({
            task_id: this.taskId,
            version_id: b,
            owner: this
        });
        a.open()
    },
    launchVersionInfoWindow: function(b) {
        var a = new SYNO.SDS.Backup.Client.Common.Version.VersionInfoWindow({
            owner: this,
            taskId: this.taskId,
            versionId: b,
            source: this.getStore().getById(b).get("source"),
            statistics: this.getStore().getById(b).get("statistics"),
            isPartial: "partial" === this.getStore().getById(b).get("status"),
            accountMeta: this.accountMeta,
            sessId: this.sessId,
            sessKey: this.sessKey
        });
        a.open()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() === Ext.EventObject.ENTER) {
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof Ext.form.DateField) {
                    if (d.menu && c.within(d.menu.getEl())) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [6, 0]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.SearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        };
        this.dataRange = [
            [this.dateType.custom, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_custom")],
            [this.dateType.today, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_today")],
            [this.dateType.yesterday, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_yesterday")],
            [this.dateType.lastweek, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_lastweek")],
            [this.dateType.lastmonth, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_lastmonth")]
        ];
        this.logLevelType = {
            info: "1",
            warn: "2",
            error: "3"
        };
        this.logLevel = [
            [this.logLevelType.info, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_info_level")],
            [this.logLevelType.warn, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_warn_level")],
            [this.logLevelType.error, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_error_level")]
        ];
        this.defaultAnimation = ["#000", 1, {
            duration: 0.35
        }];
        Ext.apply(this, a || {});
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.defineBehaviors()
    },
    initComponent: function() {
        this.callParent([this]);
        this.addEvents("search")
    },
    fillConfig: function(b) {
        var a, f, g, e;
        var c = [];
        a = this.createKeyword();
        f = this.createFriendlyDate();
        g = this.createCustDate();
        e = this.createLevel();
        c.push(a);
        c.push(f);
        c.push(g);
        c.push(e);
        c.push({
            xtype: "toolbar",
            border: false,
            itemId: "btns",
            toolbarCls: "search-panel-fbar-btnPanel",
            items: [{
                xtype: "tbfill"
            }, {
                xtype: "syno_button",
                minWidth: 80,
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                style: "margin-right: 10px",
                text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_stop"),
                itemId: "btn_stop",
                hidden: true,
                handler: this.onStop,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                style: "margin-right: 10px",
                text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_search"),
                itemId: "btn_search",
                handler: this.onSearch,
                scope: this
            }]
        });
        var d = {
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            border: true,
            bodyStyle: "padding: 20px; padding-top: 0px; font-size: 24px;",
            autoFlexcroll: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            items: c,
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        this.doLayout()
                    },
                    single: true
                },
                show: {
                    fn: this.doLayout,
                    single: true
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    if (!this.isVisible()) {
                        return
                    }
                    if (!this.btnSearch.hidden && !this.btnSearch.disabled) {
                        this.onSearch()
                    } else {
                        if (!this.btnStop.hidden && !this.btnStop.disabled) {
                            this.onStop()
                        }
                    }
                },
                scope: this
            }]
        };
        return d
    },
    setComboBoxValue: function(b, a) {
        this.frameAnimation(b.el, this.defaultAnimation);
        if (b.setMultiValue) {
            b.setMultiValue(a.split(","))
        }
    },
    getComboBoxValue: function(b) {
        var a = this.getForm().findField(b);
        return a.getMultiValue ? a.getMultiValue().toString() : a.getValue()
    },
    multiSelect: function(c, e, a, d, b) {
        Ext.applyIf(c, {
            setMultiValue: function(f) {
                if (!Ext.isArray(f)) {
                    f = [f]
                }
                this.multiValue = f
            },
            getMultiValue: function() {
                return this.multiValue && this.multiValue.length > 0 ? this.multiValue : this.getValue().split(",")
            }
        });
        if ("more" === e.get("value")) {
            this.attriWin = new SYNO.SDS.LogCenter.MultiSelectedDialog({
                title: d,
                combo: c,
                emptyValue: b,
                anim: this.defaultAnimation,
                owner: this.owner.appInst
            });
            this.attriWin.showUp();
            c.collapse();
            return false
        }
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText:htmlEncode}">', "{displayText:htmlEncode}", "</div>", "</tpl>")
    },
    logSelect: function(c, a, b) {
        this.setComboBoxValue(c, c.getValue())
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            msgTarget: "qtip",
            validateOnBlur: true,
            validationEvent: "blur",
            name: "keyword",
            flex: 2,
            vaule: ""
        }]
    },
    setDate: function(c, b, a) {
        if (a === true) {
            this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation);
            this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)
        }
        this.form.findField("searchdatefrom").setMaxValue(b);
        this.form.findField("searchdateto").setMinValue(c);
        this.form.findField("searchdatefrom").setValue(c);
        this.form.findField("searchdateto").setValue(b)
    },
    getFromToDate: function(c) {
        var e, d, b = new Date();
        if (c === this.dateType.today) {
            e = b;
            d = b
        } else {
            if (c === this.dateType.yesterday) {
                e = b.add(Date.DAY, -1);
                d = e
            } else {
                if (c === this.dateType.lastweek) {
                    var a = b.getDay();
                    e = b.add(Date.DAY, -7 - a);
                    d = e.add(Date.DAY, 6)
                } else {
                    if (c === this.dateType.lastmonth) {
                        b = b.add(Date.MONTH, -1);
                        e = b.getFirstDateOfMonth();
                        d = b.getLastDateOfMonth()
                    }
                }
            }
        }
        return {
            from: e,
            to: d
        }
    },
    friendlyDateSelect: function(c, e, a) {
        var b = e.get("id"),
            d = this.getFromToDate(b);
        this.setDate(d.from, d.to, true)
    },
    getFriendlyDateStore: function() {
        var a = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    },
    createFriendlyDate: function() {
        this.FriendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "dateRange",
            tpl: this.createTpl(),
            resizable: true,
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            lazyRender: true,
            flex: 6,
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.friendlyDateSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_range") + _T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        var a = {
            name: "searchdatefrom",
            editable: false,
            emptyText: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_from"),
            value: "",
            listeners: {
                scope: this,
                select: function(d, c) {
                    this.form.findField("searchdateto").setMinValue(c)
                }
            }
        };
        var b = {
            name: "searchdateto",
            editable: false,
            emptyText: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(d, c) {
                    this.form.findField("searchdatefrom").setMaxValue(c)
                }
            }
        };
        if (!SYNO.SDS.DateTimeUtils) {
            a.format = "m/d/Y";
            b.format = "m/d/Y"
        }
        this.DateFrom = new SYNO.ux.DateTimeField(a);
        this.DateTo = new SYNO.ux.DateTimeField(b);
        return [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_time") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    getLogLevelStore: function() {
        var a = this.logLevel.slice(0, this.logLevel.length);
        if (a.length > 1) {
            a.splice(0, 0, ["", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_all_level")])
        }
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiLogLevelSelect: function(b, c, a) {
        this.multiSelect(b, c, a, SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_level_type"), "")
    },
    createLevel: function() {
        this.LogLevel = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            mode: "local",
            editable: false,
            name: "logLevel",
            tpl: this.createTpl(),
            resizable: true,
            store: this.getLogLevelStore(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: 3,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiLogLevelSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "logLevelLabel",
            value: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_level_type") + _T("common", "colon"),
            flex: 1
        }, this.LogLevel]
    },
    hideItems: function(b) {
        var c;
        if (!Ext.isArray(b)) {
            b = [b]
        }
        for (var a = b.length - 1; a >= 0; a--) {
            c = this.form.findField(b[a]);
            if (c) {
                c.setVisible(false)
            }
        }
    },
    frameAnimation: function(a, b) {
        if (a && a.isVisible()) {
            Ext.Element.prototype.frame.apply(a, b)
        }
    },
    defineBehaviors: function() {
        var a = this.get("btns");
        this.btnSearch = a.get("btn_search");
        this.btnStop = a.get("btn_stop")
    },
    setKeyWord: function(a) {
        var b = this.form.findField("keyword");
        if (b && Ext.isString(a)) {
            b.setValue(a)
        }
        b.focus("", 1)
    },
    onShowHideBtn: function(a) {
        if (a) {
            this.btnSearch.hide();
            this.btnStop.show()
        } else {
            this.btnSearch.show();
            this.btnStop.hide()
        }
    },
    onEnableDisableBtn: function(a) {
        if (a) {
            this.btnSearch.enable();
            this.btnStop.enable()
        } else {
            this.btnSearch.disable();
            this.btnStop.disable()
        }
    },
    isOwnerDestroyed: function() {
        return (this.owner && this.owner.isDestroyed)
    },
    showMsg: function(b, a) {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().alert(b, a)
        }
    },
    hideMsg: function() {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().hide()
        }
    },
    isFieldDirty: function(a) {
        return this.form.findField(a).isDirty()
    },
    validateForm: function() {
        if (!this.form.isValid()) {
            return false
        }
        return this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto") || this.isFieldDirty("keyword")
    },
    onSearch: function(c, f) {
        var d, b, i, h, a;
        var g;
        d = this.getForm();
        b = d.findField("keyword").getValue();
        a = this.getComboBoxValue("logLevel");
        i = d.findField("searchdatefrom").getRawValue();
        h = d.findField("searchdateto").getRawValue();
        g = {
            filter_keyword: b,
            filter_level: a,
            filter_date_from: i ? new Date(i + " 00:00:00").getTime() / 1000 : 0,
            filter_date_to: h ? new Date(h + " 23:59:59").getTime() / 1000 : 0
        };
        this.fireEvent("search", this, g)
    },
    onReset: function() {
        this.form.items.each(function(a) {
            if (a.isDirty()) {
                this.frameAnimation(a.el, this.defaultAnimation)
            }
        }, this);
        this.form.reset();
        this.form.findField("searchdatefrom").setMaxValue(null);
        this.form.findField("searchdateto").setMinValue(null);
        this.form.findField("logLevel").multiValue = ""
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.BaseLogUI", {
    extend: "Ext.Panel",
    itemsPerPage: 1000,
    title: undefined,
    itemId: undefined,
    appWin: undefined,
    topwin: undefined,
    store: undefined,
    columnModel: undefined,
    constructor: function(a) {
        Ext.copyTo(this, a, ["topwin", "appWin", "title", "itemId"]);
        this.store = a.ds;
        this.columnModel = a.cm;
        this.itemsPerPage = a.appWin.appInstance.getUserSettings(this.itemId + "-dsPageLimit") || this.itemsPerPage;
        Ext.apply(a, this);
        this.callParent([a]);
        this.mon(this, "resize", function(b, d, c) {
            this.updatePagingToolbarItems(d)
        }, this)
    },
    initComponent: function() {
        this.searchPanel = this.initSearchForm();
        this.paging = this.initPagingToolbar();
        this.enablePagingToolbarItems(false);
        this.grid = new SYNO.ux.GridPanel({
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                rowHeight: 27,
                scrollDelay: 30,
                hideSortIcons: true,
                borderHeight: 1
            }),
            cls: "syno-backup-log-gridview",
            height: 455,
            region: "center",
            store: this.store,
            bbar: this.paging,
            colModel: this.columnModel,
            loadMask: true,
            stripeRows: true
        });
        Ext.apply(this, {
            itemId: this.itemId,
            border: false,
            header: false,
            layout: "fit",
            items: [this.grid]
        });
        this.callParent([this])
    },
    initSearchForm: function() {
        var a = new SYNO.SDS.Backup.Client.Common.Log.SearchFormPanel({
            cls: "syno-backup-client-common-adv-search-panel",
            renderTo: Ext.getBody(),
            shadow: false,
            hidden: true,
            owner: this
        });
        return a
    },
    initPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            displayInfo: true,
            showRefreshBtn: true,
            store: this.store,
            pageSize: this.itemsPerPage,
            items: ["-", _T("common", "items_perpage"), this.initPageComboBox(this.getPageRecordStore()), "-", {
                xtype: "tbtext",
                text: "",
                itemId: "infoLevel"
            }, "-", {
                xtype: "tbtext",
                text: "",
                itemId: "warnLevel"
            }, "-", {
                xtype: "tbtext",
                text: "",
                itemId: "errorLevel"
            }, "-"]
        });
        return a
    },
    initPageComboBox: function(a) {
        var b = new SYNO.ux.ComboBox({
            name: "page_rec",
            hiddenName: "page_rec",
            hiddenId: Ext.id(),
            store: a,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: this.itemsPerPage,
            editable: false,
            width: 72,
            mode: "local",
            listeners: {
                select: {
                    fn: this.onChangeDisplayRecord,
                    scope: this
                }
            }
        });
        return b
    },
    getPageRecordStore: function() {
        var a = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [100, 100],
                [500, 500],
                [1000, 1000],
                [3000, 3000]
            ]
        });
        return a
    },
    getPagingToolBarCompoent: function(a) {
        return this.paging.getComponent(a)
    },
    updatePagingToolbarItems: function(a) {
        if (!this.isVisible()) {
            return
        }
        if (a > 950) {
            this.enablePagingToolbarItems(true)
        } else {
            this.enablePagingToolbarItems(false)
        }
    },
    enablePagingToolbarItems: function(a) {
        var e = this.paging.items.indexOfKey("infoLevel");
        var d = this.paging.items.indexOfKey("errorLevel");
        if (e < 0 || d < 0) {
            return
        }
        for (var b = e - 1; b <= d + 1; b++) {
            var c = this.paging.items.get(b);
            if (!Ext.isEmpty(c)) {
                c.setVisible(a)
            }
        }
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.BaseLog", {
    extend: "SYNO.SDS.Backup.Client.Common.Log.BaseLogUI",
    searchBuffer: 200,
    constructor: function(a) {
        this.callParent([a]);
        this.searchBuffer = a.searchBuffer || this.searchBuffer
    },
    initEvents: function() {
        this.mon(this.searchPanel, "search", this.onSearch, this, {
            buffer: this.searchBuffer
        });
        this.mon(this.grid.getStore(), "load", this.onAfterStoreLoad, this);
        this.mon(this.grid.getStore(), "beforeload", this.onBeforeStoreLoad, this)
    },
    onChangeDisplayRecord: function(c, d, b) {
        var a = this.grid.getStore();
        if (this.itemsPerPage !== c.getValue()) {
            this.itemsPerPage = c.getValue();
            this.paging.pageSize = this.itemsPerPage;
            a.load({
                params: {
                    offset: 0
                }
            });
            this.appWin.appInstance.setUserSettings(this.itemId + "-dsPageLimit", this.itemsPerPage)
        }
    },
    isTheSame: function(b, a) {
        var c;
        for (c in a) {
            if (a[c] !== b[c]) {
                return false
            }
        }
        return true
    },
    onSearch: function(b, c) {
        var a = this.grid.getStore();
        if (!this.isTheSame(a.baseParams, c)) {
            Ext.apply(a.baseParams, c);
            a.load()
        }
    },
    onBeforeStoreLoad: function(a, b) {
        this.grid.getGridEl().unmask();
        b.params.limit = this.itemsPerPage
    },
    onAfterStoreLoad: function(a, e, c) {
        var d, b;
        if (e.length < 1) {
            this.grid.getGridEl().mask(SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "no_log_available"))
        } else {
            this.grid.getGridEl().unmask()
        }
        d = a.reader.jsonData;
        b = '<div class="{0}" style="width:40px;" ext:qtip="{1}">{2}</div>';
        this.setLogLevelText(this.getPagingToolBarCompoent("infoLevel"), b, "syno-log-info", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_info_level"), d.info_count);
        this.setLogLevelText(this.getPagingToolBarCompoent("warnLevel"), b, "syno-log-warn", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_warn_level"), d.warn_count);
        this.setLogLevelText(this.getPagingToolBarCompoent("errorLevel"), b, "syno-log-err", SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_error_level"), d.error_count);
        this.setPagingToolbar(a, this.grid, this.paging)
    },
    setLogLevelText: function(b, a, c, e, d) {
        if (b) {
            d = d || "0";
            b.setText(String.format(a, c, e, d))
        }
    },
    setPagingToolbar: function(a, b, c) {
        this.setPagingToolbarVisible(c, a.getTotalCount() > this.itemsPerPage)
    },
    setPagingToolbarVisible: function(b, c) {
        var a = 0;
        for (a = 0; a < 13; a++) {
            if (a === 9 || a === 10 || a === 11) {
                continue
            }
            b.items.items[a].setVisible(c)
        }
        b.setButtonsVisible(true)
    },
    onExportCSV: function() {
        this.onExportLog("csv")
    },
    onExportHtml: function() {
        this.onExportLog("html")
    },
    onExportLog: function(a) {
        if (_S("demo_mode")) {
            this.appWin.getMsgBox().alert(this.appWin.title, _JSLIBSTR("uicommon", "error_demo"));
            return
        }
        this.doExport(a)
    },
    doExport: function(d) {
        var c = this.grid.getStore();
        var e = c.baseParams.filter_level;
        var b = c.baseParams.filter_target_id;
        var f = c.baseParams.filter_keyword;
        var g = c.baseParams.filter_date_from;
        var a = c.baseParams.filter_date_to;
        var h = d;
        this.appWin.downloadWebAPI({
            webapi: {
                api: "SYNO.SDS.Backup.Client.Common.Log",
                version: 1,
                method: "export",
                params: {
                    filter_level: e,
                    filter_target_id: b,
                    filter_keyword: f,
                    filter_date_from: g,
                    filter_date_to: a,
                    format: h
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.LogsWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        var a = {
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_name"),
            cls: "syno-backup-client-common-log-window",
            width: 860,
            height: 530,
            padding: "8px 20px 0px 20px",
            resizable: true,
            minWidth: 860,
            minHeight: 300,
            maximizable: true,
            layout: "fit",
            items: [new SYNO.SDS.Backup.Client.Common.Log.LogsPage({
                appWin: b.appWin,
                owner: b.owner,
                filterParams: b.filterParams
            })],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }]
        };
        Ext.apply(b, a);
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.LogsPage", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        Ext.apply(this, a);
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var c = new SYNO.SDS.Backup.Client.Common.Log.GeneralLogBuilder();
        this.generalLog = c.create({
            topwin: this,
            appWin: this.appWin,
            filterParams: this.filterParams
        });
        var b = {
            title: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_backup"),
            border: false,
            trackResetOnLoad: true,
            tbar: this.initToolbar(),
            layout: "fit",
            activeItem: 0,
            items: [this.generalLog]
        };
        Ext.apply(b, a);
        return b
    },
    initToolbar: function() {
        var a = new SYNO.ux.Toolbar();
        this.ExportButton = new SYNO.ux.SplitButton({
            xtype: "syno_splitbutton",
            text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_export"),
            handler: this.onExportHtml,
            scope: this,
            menu: {
                items: [{
                    text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_html_type"),
                    handler: this.onExportHtml,
                    scope: this
                }, {
                    text: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_csv_type"),
                    handler: this.onExportCSV,
                    scope: this
                }]
            }
        });
        this.SearchField = new SYNO.SDS.Backup.Client.Common.Log.AdvancedSearchField({
            iconStyle: "filter",
            owner: this
        });
        this.SearchField.searchPanel = this.generalLog.searchPanel;
        a.add(this.ExportButton);
        a.add("->");
        a.add(this.SearchField);
        return a
    },
    onExportHtml: function() {
        this.generalLog.onExportHtml()
    },
    onExportCSV: function() {
        this.generalLog.onExportCSV()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Common.Log.GeneralLogBuilder", {
    extend: "Object",
    create: function(d) {
        var g = SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_backup");
        var f = "backup";
        var c = d.filterParams;
        delete d.filterParams;
        var b = this.getStore(c);
        var e = this.getColumnModel();
        var a = {
            title: g,
            itemId: f,
            ds: b,
            cm: e
        };
        Ext.applyIf(d, a);
        return new SYNO.SDS.Backup.Client.Common.Log.BaseLog(d)
    },
    getStore: function(a) {
        var c = {
            offset: 0,
            limit: 0
        };
        Ext.apply(c, a);
        var b = new SYNO.API.Store({
            api: "SYNO.SDS.Backup.Client.Common.Log",
            version: 1,
            method: "list",
            baseParams: c,
            appWindow: false,
            autoLoad: true,
            remoteSort: false,
            reader: new Ext.data.JsonReader({
                idProperty: "id",
                root: "log_list",
                totalProperty: "total",
                fields: [{
                    name: "level",
                    mapping: "level"
                }, {
                    name: "time",
                    mapping: "time",
                    convert: function(e, d) {
                        return SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(e, {
                            type: "datetimesec"
                        })
                    }
                }, {
                    name: "user",
                    mapping: "user"
                }, {
                    name: "event",
                    mapping: "event"
                }]
            })
        });
        return b
    },
    getColumnModel: function() {
        var a = new Ext.grid.ColumnModel({
            columns: [{
                menuText: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_level_type"),
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_level_type"),
                dataIndex: "level",
                fixed: true,
                width: 100,
                renderer: this.logLevelRenderer
            }, {
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_time_date"),
                dataIndex: "time",
                fixed: true,
                width: 200,
                renderer: this.htmlEncodeRender
            }, {
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_account"),
                dataIndex: "user",
                width: 100,
                renderer: this.htmlEncodeRender
            }, {
                id: "descr",
                header: SYNO.SDS.Backup.Client.Common.Utils.GetString("app", "log_action"),
                dataIndex: "event",
                css: "white-space:normal;",
                width: 300,
                renderer: this.htmlEncodeRender
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    },
    logLevelRenderer: function(a) {
        switch (a) {
            case "emerg":
            case "alert":
            case "crit":
            case "err":
                return "<span class='red-status'>Error</span>";
            case "warn":
            case "warning":
            case "notice":
                return "<span class='orange-status'>Warning</span>";
            case "info":
            case "debug":
                return "<span class='info-status'>Information</span>";
            default:
                return "Undefined"
        }
    },
    htmlEncodeRender: function(c, b) {
        var a = "<span>" + Ext.util.Format.htmlEncode(c) + "</span>";
        b.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
        return a
    }
});
