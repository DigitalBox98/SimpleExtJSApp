/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.Backup.Addon.base.Restore.DestStep
 * @extends SYNO.ux.FormPanel
 * HyperBackup addon base restore
 * @xtype syno_button
 *
 */
Ext.define("SYNO.Backup.Addon.base.Restore.DestStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        var b = Ext.apply({
            cls: "syno-backup-restore-dest-setting",
            bodyStyle: "padding-top: 24px"
        }, a);
        this.callParent([b])
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(c) {
        var f = 450,
            a = 200;
        this.s3key = c.key;
        this.s3secret = c.secret;
        this.support_region = c.support_region;
        this.region_system = c.region_system;
        this.addon_id = c.addon_id;
        this.transfer_type = c.transfer_type;
        this.remote_url = c.remote_url;
        this.signature_version = c.signature_version;
        this.request_style = c.request_style;
        var d = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_bucket"),
            validator: function(g) {
                if (-1 !== g.search(/(\.\.|\.\-|\-\.)/)) {
                    return _T("netbackup", "s3_bucket_name_period_limit")
                } else {
                    return true
                }
            },
            owner: this
        }];
        if (this.support_region && this.transfer_type === "aws_s3") {
            var b = "";
            if (this.region_system === "s3_china") {
                b = "cn-north-1"
            }
            d.push({
                xtype: "syno_combobox",
                name: "region",
                fieldLabel: SYNO.SDS.Backup.String("aws_s3", "s3_select_region"),
                store: this.getRegionStore(),
                displayField: "region",
                valueField: "value",
                value: b,
                owner: this
            })
        }
        var e = Ext.apply({
            title: _T("backup", "s3_create_bucket"),
            width: f,
            height: a,
            minWidth: f,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: d
            }],
            buttons: [{
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }, {
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }]
        }, c);
        return this.callParent([e])
    },
    getRegionStore: function() {
        if (!this.support_region || this.transfer_type !== "aws_s3") {
            return undefined
        }
        var a = [
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_us_east_virginia"), ""],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_us_east_ohio"), "us-east-2"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_us_west_california"), "us-west-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_us_west_oregon"), "us-west-2"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_canada_central"), "ca-central-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_eu_ireland"), "eu-west-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_eu_frankfurt"), "eu-central-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_eu_london"), "eu-west-2"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_eu_paris"), "eu-west-3"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_eu_stockholm"), "eu-north-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_tokyo"), "ap-northeast-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_seoul"), "ap-northeast-2"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_hongkong"), "ap-east-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_singapore"), "ap-southeast-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_sydney"), "ap-southeast-2"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_asia_mumbai"), "ap-south-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_south_america_sao_paulo"), "sa-east-1"],
            [SYNO.SDS.Backup.String("aws_s3", "s3_region_middle_east_bahrain"), "me-south-1"]
        ];
        if (this.region_system === "s3_china") {
            a = [
                [SYNO.SDS.Backup.String("aws_s3", "s3_region_china_beijing"), "cn-north-1"],
                [SYNO.SDS.Backup.String("aws_s3", "s3_region_china_ningxia"), "cn-northwest-1"]
            ]
        }
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["region", "value"],
                data: a
            })
        }
        return this.regionStore
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            key: this.s3key,
            secret: this.s3secret,
            transfer_type: this.transfer_type,
            bucket: this.items.get(0).getForm().findField("bucket").getValue()
        };
        if (this.remote_url) {
            a.remote_url = this.remote_url
        }
        if (this.signature_version) {
            a.signature_version = this.signature_version
        }
        if (this.support_region && this.transfer_type === "aws_s3") {
            a.region = this.items.get(0).getForm().findField("region").getValue();
            a.region_system = this.region_system
        } else {
            if (this.support_region && this.transfer_type === "jdcloud_s3") {
                a.region = this.region_system;
                a.region_system = this.region_system
            }
        }
        a.request_style = this.request_style;
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "create",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(e, b, c) {
                var d;
                if (this.support_region && this.transfer_type === "aws_s3") {
                    this.items.get(0).getForm().findField("region").getValue()
                }
                var f = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!e) {
                    this.showPossibleBucketError(b.code, f, d);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(b, e, c) {
        if (this.customizedBucketErrorFilter && Ext.isFunction(this.customizedBucketErrorFilter)) {
            return this.customizedBucketErrorFilter(b, e, c)
        }
        var d = "";
        var a = /([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){2}[.]([1-9][0-9]{0,1}|1[0-9]{2}|2[0-4][0-9]|25[0-5])/;
        if (!e.match(/^[a-z0-9\.-]*$/)) {
            d = d.concat("<BR>- ", _T("netbackup", "s3_bucket_name_non_us_standard_letter_limit"))
        }
        if (!e.match(/^[a-z0-9]/) || !e.match(/[a-z0-9]$/)) {
            d = d.concat("<BR>- ", _T("netbackup", "s3_bucket_name_leading_letter_limit"))
        }
        if (3 > e.length || 63 < e.length) {
            d = d.concat("<BR>- ", String.format(_T("netbackup", "s3_bucket_name_length_limit"), "3", "63"))
        }
        if (e.match(a)) {
            d = d.concat("<BR>- ", _T("netbackup", "s3_bucket_name_ip_limit"))
        }
        if (-1 !== e.search(/(\.\.|\.\-|\-\.)/)) {
            d = d.concat("<BR>- ", _T("netbackup", "s3_bucket_name_period_limit"))
        }
        if (d.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "s3_bucket_name_invalid_short") + " " + _T("netbackup", "s3_bucket_name_meet_condition") + " " + _T("common", "colon") + d);
            return
        }
        if (b === SYNO.SDS.Backup.ERR_NAME_NOT_VALID || b === SYNO.SDS.Backup.ERR_PARAM) {
            d = _T("netbackup", "s3_bucket_name_invalid_short");
            this.getMsgBox().alert(_T("tree", "leaf_backup"), d);
            return
        }
        d = SYNO.SDS.Backup.GetErrorString(b);
        this.getMsgBox().alert(_T("tree", "leaf_backup"), d);
        return
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateStep", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        this.addon_id = a.addon_id;
        var c = Ext.apply({
            height: 410,
            items: [{
                xtype: "syno_fieldset",
                title: SYNO.Backup.Addon.Util.getString(this.addon_id, "repo_wizard_headline"),
                collapsible: false,
                defaults: {
                    labelWidth: 300
                },
                items: [{
                    xtype: "syno_textfield",
                    name: "name",
                    value: SYNO.Backup.Addon.Util.getString(this.addon_id, "repo_name_prefix") || "My Storage",
                    allowBlank: false,
                    fieldLabel: _T("backup", "repo_name"),
                    maxLength: 32,
                    vtype: "backup_destination",
                    hidden: true
                }, {
                    xtype: "syno_combobox",
                    name: "server",
                    allowBlank: false,
                    store: this.getServerStore(),
                    fieldLabel: _T("backup", "s3_server"),
                    displayField: "server",
                    valueField: "value",
                    value: "aws_s3",
                    editable: false,
                    listeners: {
                        select: function(f, d, e) {
                            this.changeLayout(d.get("value"))
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_textfield",
                    name: "remote_url",
                    allowBlank: false,
                    fieldLabel: SYNO.SDS.Backup.String("aws_s3", "url"),
                    hidden: true,
                    disabled: true
                }, {
                    xtype: "syno_combobox",
                    name: "signature_version",
                    allowBlank: false,
                    store: this.getSignatureStore(),
                    fieldLabel: SYNO.SDS.Backup.String("aws_s3", "signature_version"),
                    displayField: "version",
                    valueField: "value",
                    value: "v2",
                    editable: false,
                    hidden: true,
                    disabled: true
                }, {
                    xtype: "syno_textfield",
                    name: "key",
                    allowBlank: false,
                    fieldLabel: _T("backup", "s3_access_key")
                }, {
                    xtype: "syno_textfield",
                    name: "secret",
                    allowBlank: false,
                    inputType: "password",
                    fieldLabel: _T("backup", "s3_secret_key")
                }, {
                    xtype: "syno_combobox",
                    name: "bucket",
                    fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
                    store: this.getBucketStore(),
                    displayField: "bucket",
                    allowBlank: false,
                    valueField: "bucket",
                    scope: this,
                    onTriggerClick: function() {
                        if (this.readOnly || this.disabled) {
                            return
                        }
                        if (this.scope.needReloadBucket()) {
                            this.scope.loadBucketStore()
                        } else {
                            SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                        }
                    },
                    listeners: {
                        select: function(f, d, e) {
                            if (e === 0) {
                                this.createBucket();
                                return
                            }
                        },
                        beforeselect: function(e, d, f) {
                            if (d.get("status") > 0) {
                                return false
                            }
                        },
                        scope: this
                    },
                    tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
                }]
            }]
        }, a);
        var b = this.callParent([c]);
        this.mon(this, "activate", function() {
            var d = this.getForm().findField("server");
            d.setValue("aws_s3")
        }, this, {
            single: true
        });
        return b
    },
    getServerStore: function() {
        if (!this.serverStore) {
            this.serverStore = new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "name"), "aws_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "name") + " " + SYNO.SDS.Backup.String("aws_s3", "s3_region_system_china"), "aws_cn_s3"],
                    [SYNO.SDS.Backup.String("hicloud_s3", "name"), "hicloud_s3"],
                    [SYNO.SDS.Backup.String("sfr_s3", "name"), "sfr_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "custom_address"), "s3_compatible"]
                ]
            })
        }
        return this.serverStore
    },
    getSignatureStore: function() {
        if (!this.signatureStore) {
            this.signatureStore = new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["v2", "v2"],
                    ["v4", "v4"]
                ]
            })
        }
        return this.signatureStore
    },
    changeLayout: function(e) {
        var d = this.getForm();
        var c = this;
        var a = function(g, f) {
            d.findField(g).setDisabled(!f);
            d.findField(g).setVisible(f);
            c.doLayout()
        };
        var b = function(f) {
            a("remote_url", f);
            a("signature_version", f)
        };
        if ("s3_compatible" === e) {
            b(true)
        } else {
            b(false)
        }
    },
    createBucket: function() {
        var b = this.getParams();
        b.owner = this.owner;
        var a = new SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateBucket(b);
        this.mon(a, "close", function() {
            var c = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField("bucket").clearValue();
            this.loadBucketStore(c)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        if (!b.key || !b.secret) {
            return
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "list",
            params: b,
            scope: this,
            callback: function(h, c, d) {
                var g = this.getForm().findField("bucket");
                var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                var f = new e({
                    bucket: _T("backup", "s3_create_bucket"),
                    status: 0,
                    conflict_repo: ""
                });
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                this.getBucketStore().insert(0, f);
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    getParams: function() {
        var b = {};
        b = this.getForm().getFieldValues();
        var a = this.getForm().findField("server").getValue();
        if ("hicloud_s3" === a || "sfr_s3" === a) {
            b.transfer_type = a;
            b.support_region = false
        } else {
            if ("aws_s3" === a) {
                b.transfer_type = "aws_s3";
                b.support_region = true;
                b.region_system = "s3_global"
            } else {
                if ("aws_cn_s3" === a) {
                    b.transfer_type = "aws_s3";
                    b.support_region = true;
                    b.region_system = "s3_china"
                } else {
                    b.transfer_type = "aws_s3";
                    b.support_region = false;
                    b.remote_url = b.remote_url;
                    b.signature_version = b.signature_version
                }
            }
        }
        b.action = "create";
        b.repo_name = b.name;
        b.addon_id = "aws_s3";
        delete b.server;
        delete b.name;
        return b
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.owner.loadAppParams();
        return this.nextId
    },
    isValid: function() {
        return this.getForm().isValid()
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.transferType = a.transferType;
        this.targetType = "cloud";
        var b = Ext.apply({
            height: 400,
            trackResetOnLoad: true,
            items: this.createItems()
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        return []
    },
    loadData: function(a) {
        this.getForm().setValues(a);
        this.orgName = a.name
    },
    getApplyApi: function() {
        var a = this.getForm();
        var b = a.getFieldValues(true);
        b.name = this.orgName;
        b.task_id = this.taskId;
        b.repo_id = this.repoId;
        b.transfer_type = this.transferType;
        b.target_type = this.targetType;
        return {
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "set",
            params: b
        }
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.S3.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    S3_BUCKET_LENGTH: 63,
    constructor: function(b) {
        var a = [];
        this.target_type = "cloud";
        Ext.copyTo(this, b, "owner");
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)]);
        this.mon(this, "activate", function() {
            var c = this.getForm().findField("server");
            c.setValue("aws_s3")
        }, this, {
            single: true
        })
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            name: "server",
            width: this.comboboxWidth,
            allowBlank: false,
            store: this.getServerStore(),
            fieldLabel: _T("backup", "s3_server"),
            displayField: "server",
            valueField: "value",
            value: "aws_s3",
            editable: false,
            listeners: {
                select: function(d, b, c) {
                    this.changeLayout(b.get("value"))
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            width: this.comboboxWidth,
            name: "remote_url",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "url"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            name: "signature_version",
            width: this.comboboxWidth,
            allowBlank: false,
            store: this.getSignatureStore(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "signature_version"),
            displayField: "version",
            valueField: "value",
            value: "v2",
            editable: false,
            hidden: true,
            disabled: true,
            listeners: {
                scope: this,
                select: function(c, b) {
                    if ("v4" === b.get("value")) {
                        this.getForm().findField("request_style").setVisible(true);
                        this.getForm().findField("request_style").setDisabled(false)
                    } else {
                        this.getForm().findField("request_style").setVisible(false);
                        this.getForm().findField("request_style").setDisabled(true)
                    }
                    this.doLayout()
                }
            }
        }, {
            xtype: "syno_combobox",
            name: "request_style",
            width: 270,
            allowBlank: false,
            store: this.getUrlStyleStore(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "request_style"),
            displayField: "style",
            valueField: "value",
            value: "virtual_host_style",
            editable: false,
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_access_key"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_secret_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            name: "bktselect",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            maxlength: this.S3_BUCKET_LENGTH,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            width: this.comboboxWidth,
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getServerStore: function() {
        if (!this.serverStore) {
            this.serverStore = new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "name"), "aws_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "name") + " " + SYNO.SDS.Backup.String("aws_s3", "s3_region_system_china"), "aws_cn_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "custom_address"), "s3_compatible"]
                ]
            })
        }
        return this.serverStore
    },
    getSignatureStore: function() {
        if (!this.signatureStore) {
            this.signatureStore = new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["v2", "v2"],
                    ["v4", "v4"]
                ]
            })
        }
        return this.signatureStore
    },
    getUrlStyleStore: function() {
        if (!this.urlStyleStore) {
            this.urlStyleStore = new Ext.data.ArrayStore({
                fields: ["style", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "virtual_host_style"), "virtual_host_style"],
                    [SYNO.SDS.Backup.String("aws_s3", "path_style"), "path_style"]
                ]
            })
        }
        return this.urlStyleStore
    },
    getRequestStyleValue: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        if ("s3_compatible" === b("server") && "v4" === b("signature_version")) {
            return b("request_style")
        } else {
            return "virtual_host_style"
        }
    },
    changeLayout: function(e) {
        var d = this.getForm();
        var c = this;
        var a = function(g, f) {
            d.findField(g).setDisabled(!f);
            d.findField(g).setVisible(f);
            c.doLayout()
        };
        var b = function(f) {
            a("remote_url", f);
            a("signature_version", f)
        };
        if ("s3_compatible" === e) {
            b(true)
        } else {
            b(false)
        }
        if ("s3_compatible" === e && "v4" === d.findField("signature_version").getValue()) {
            a("request_style", true)
        } else {
            a("request_style", false)
        }
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image";
            this.owner.setSingle(false)
        } else {
            this.target_type = "cloud";
            this.owner.setSingle(true)
        }
        if ("image" === b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            c = function(e) {
                return a.findField(e).getValue()
            };
        var d = {
            key: c("accesskey"),
            secret: c("secretkey"),
            bucket: c("bktselect"),
            target_id: c("target"),
            target_type: this.target_type,
            addon_id: "aws_s3"
        };
        var b = c("server");
        if ("aws_s3" === b) {
            d.transfer_type = "aws_s3";
            d.support_region = true;
            d.region_system = "s3_global"
        } else {
            if ("aws_cn_s3" === b) {
                d.transfer_type = "aws_s3";
                d.support_region = true;
                d.region_system = "s3_china"
            } else {
                d.transfer_type = "aws_s3";
                d.support_region = false;
                d.remote_url = c("remote_url");
                d.signature_version = c("signature_version")
            }
        }
        d.request_style = this.getRequestStyleValue(b);
        return d
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("aws_s3", "repo_type_name"));
        if (Ext.isEmpty(b.remote_url)) {
            a.append(_T("netbackup", "netbkp_slct_server"), SYNO.Backup.Addon.Util.getString(b.transfer_type, "name"))
        } else {
            a.append(_T("netbackup", "netbkp_slct_server"), b.remote_url)
        }
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = this.getParams();
        delete a.bucket;
        delete a.target_id;
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("netbackup", "s3_retrieve_bucket")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.base.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.FormPanel",
    isAnchor: true,
    action: "create",
    target_type: null,
    transfer_type: null,
    createFields: [],
    relinkFields: [],
    supportCreate: true,
    supportRelink: true,
    supportExport: true,
    helpEnableClientEncrypt: false,
    constructor: function(a) {
        var b = Ext.apply({
            height: 410
        }, a);
        this.callParent([b])
    },
    initComponent: function() {
        var a = [];
        if (this.supportCreate) {
            a = a.concat(this.getCreateFields())
        }
        if (this.supportRelink) {
            a = a.concat(this.getRelinkFields())
        }
        if (this.supportExport) {
            a = a.concat(this.getExportFields())
        }
        this.items = [{
            xtype: "syno_fieldset",
            collapsible: false,
            bwrapStyle: "padding: 0px",
            defaults: {
                labelWidth: 208
            },
            items: [a]
        }];
        this.callParent(arguments);
        if (this.supportCreate) {
            this.updateFieldView(["create_fields"], ["relink_fields", "export_fields"])
        } else {
            if (this.supportRelink) {
                this.updateFieldView(["relink_fields"], ["create_fields", "export_fields"])
            } else {
                if (this.supportExport) {
                    this.updateFieldView(["export_fields"], ["create_fields", "relink_fields"])
                }
            }
        }
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", function() {
            if (this.supportCreate) {
                this.updateFieldView(["create_fields"], ["relink_fields", "export_fields"])
            } else {
                if (this.supportRelink) {
                    this.updateFieldView(["relink_fields"], ["create_fields", "export_fields"])
                } else {
                    if (this.supportExport) {
                        this.updateFieldView(["export_fields"], ["create_fields", "relink_fields"])
                    }
                }
            }
        }, this, {
            single: true
        });
        this.mon(this, "afterlayout", this.onAfterLayout, this, {
            single: true,
            buffer: 1
        })
    },
    getCreateFields: function() {
        var b = this.createFields.concat([{
            xtype: "syno_textfield",
            name: "target_id",
            indent: 1,
            fieldLabel: _T("backup", "backup_dest_directory"),
            maxLength: 32,
            width: 270,
            allowBlank: false,
            vtype: "backup_target"
        }]);
        if (!Ext.isEmpty(this.descriptionFields)) {
            b = b.concat(this.descriptionFields)
        }
        var a = [{
            xtype: "syno_radio",
            name: "creating_action",
            boxLabel: SYNO.SDS.Backup.String("app", "wizard_create_option"),
            inputValue: "create",
            checked: true,
            listeners: {
                check: function(d, c) {
                    if (c) {
                        this.action = "create";
                        this.updateFieldView(["create_fields"], ["relink_fields", "export_fields"])
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_fieldset",
            name: "create_fields",
            collapsible: false,
            defaults: {
                labelWidth: 208
            },
            bwrapStyle: {
                padding: 0
            },
            items: b
        }];
        return a
    },
    getRelinkFields: function() {
        var a = [{
            xtype: "syno_radio",
            name: "creating_action",
            id: (this.relinkComboId = Ext.id()),
            boxLabel: SYNO.SDS.Backup.String("app", "wizard_relink_option"),
            hidden: !this.supportCreate && !this.supportExport,
            inputValue: "relink",
            listeners: {
                check: function(c, b) {
                    if (b) {
                        this.action = "relink";
                        this.updateFieldView(["relink_fields"], ["create_fields", "export_fields"])
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_fieldset",
            name: "relink_fields",
            collapsible: false,
            defaults: {
                labelWidth: 208
            },
            bwrapStyle: {
                padding: 0
            },
            items: this.relinkFields.concat([this.relink_target_id = new SYNO.ux.ComboBox({
                name: "target_id",
                indent: this.getFieldIndent(),
                allowBlank: false,
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                forceSelection: true,
                owner: this.owner,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"]
                }),
                clickValidator: this.relinkValidator,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                mode: "local",
                onTriggerClick: function() {
                    if (this.readOnly || this.disabled) {
                        return
                    }
                    if (this.scope.relinkNeedReloadTarget()) {
                        this.scope.updateRelinkTarget()
                    } else {
                        SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                    }
                },
                scope: this,
                tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
            })])
        }];
        return a
    },
    getExportFields: function() {
        var a = [{
            xtype: "syno_radio",
            name: "creating_action",
            boxLabel: SYNO.SDS.Backup.String("app", "wizard_export_option"),
            inputValue: "export",
            listeners: {
                check: function(c, b) {
                    if (b) {
                        this.action = "export";
                        this.updateFieldView(["export_fields"], ["create_fields", "relink_fields"])
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_fieldset",
            name: "export_fields",
            defaults: {
                labelWidth: 208
            },
            bwrapStyle: {
                padding: 0
            },
            collapsible: false,
            items: [new SYNO.SDS.Backup.ComboBox({
                name: "export_share",
                fieldLabel: _T("tree", "leaf_sharefolder"),
                allowBlank: false,
                indent: 1,
                width: 270,
                forceSelection: true,
                owner: this.owner,
                store: this.getExportShareStore(),
                displayField: "share",
                valueField: "share",
                listeners: {
                    select: function(d, b, c) {
                        this.updateExportTarget(b.get("share"))
                    },
                    beforeselect: function(c, b, d) {
                        if (0 !== b.get("status")) {
                            return false
                        }
                    },
                    scope: this
                },
                tpl: SYNO.SDS.Backup.getShareListTpl("share")
            }), {
                xtype: "syno_textfield",
                name: "export_dir",
                indent: 1,
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }];
        return a
    },
    getFieldIndent: function() {
        if ("import" === this.action) {
            return 0
        } else {
            return 1
        }
    },
    onAfterLayout: function() {
        var a = Ext.getCmp(this.relinkComboId);
        if (a && a.getEl()) {
            SYNO.ux.AddTip(a.getEl(), SYNO.SDS.Backup.String("app", "non_owner_relink_tip"))
        }
    },
    updateFieldView: function(b, a) {
        if (!Ext.isArray(b) || !Ext.isArray(a)) {
            return
        }
        this.get(0).items.each(function(c) {
            if (0 <= a.indexOf(c.name)) {
                c.hide();
                c.disable();
                c.items.each(function(d) {
                    d.disable()
                })
            }
            if (0 <= b.indexOf(c.name)) {
                c.show();
                c.enable();
                c.items.each(function(d) {
                    d.enable()
                });
                if (Ext.isFunction(this.onFieldsetSelected)) {
                    this.onFieldsetSelected(c)
                }
            }
        }, this);
        if ("import" === this.action) {
            this.relink_target_id.disable()
        }
    },
    launchPasswordWindow: function(b, a) {
        var d = Ext.apply(this.owner.getParams(), this.getParams());
        Ext.apply(d, {
            is_relink: b,
            uni_key: this.uni_key
        });
        var c = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: d,
            setter: Ext.createDelegate(this.setSession, this),
            callback: Ext.createDelegate(a, this)
        });
        c.open()
    },
    setSession: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key;
        if ("relink" !== this.action) {
            this.owner.appWin.setCurTaskSession(a)
        }
    },
    updateTarget: function() {
        var a = Ext.apply(this.owner.getParams(), this.getParams());
        delete a.isDestEncShare;
        delete a.clientEncrypt;
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "get_candidate_dir",
            encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], a),
            params: a,
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.code));
                    return
                }
                this.getForm().findField("target_id").setValue(b.candidate_dir)
            }
        })
    },
    relinkNeedReloadTarget: function() {
        var a = this.getParams();
        delete a.target_id;
        return this.lastRelinkTargetParams !== Ext.encode(a)
    },
    updateRelinkTarget: function() {
        var a = this.getParams();
        delete a.target_id;
        delete a.isDestEncShare;
        delete a.clientEncrypt;
        if ("synocloud_swift" !== this.transfer_type && !a.container && !a.bucket && !a.share && !a.volume && !a.module) {
            return
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd", "secret", "remote_refresh_token", "remote_access_token"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c));
                    delete this.lastRelinkTargetParams;
                    return
                }
                this.lastRelinkTargetParams = Ext.encode(a);
                this.loadRelinkTargetData(c)
            },
            scope: this
        })
    },
    loadRelinkTargetData: function(a) {
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(this.relink_target_id, a.target_list, "target_id")
    },
    getExportShareStore: function() {
        if (!this.exportShareStore) {
            this.exportShareStore = new Ext.data.ArrayStore({
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.Backup.Storage.Share.Local",
                    method: "list",
                    version: 1
                }),
                root: "share_list",
                autoDestroy: true,
                autoLoad: false,
                fields: ["share", "status", "conflict_repo", "volume", "is_data_enc"],
                listeners: {
                    load: function(b, a, c) {
                        if (0 === a.length) {
                            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
                        } else {
                            Ext.each(a, function(e, d) {
                                if (0 === e.get("status")) {
                                    return false
                                }
                                if (d === a.length - 1) {
                                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
                                }
                            }, this)
                        }
                    },
                    scope: this
                }
            })
        }
        return this.exportShareStore
    },
    updateExportTarget: function(a) {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "get_candidate_dir",
            params: {
                target_type: "image",
                transfer_type: "image_local",
                share: a
            },
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                this.getForm().findField("export_dir").setValue(b.candidate_dir)
            }
        })
    },
    checkExportDestDataEnc: function() {
        var c = this.getForm();
        var b = this.getExportShareStore();
        var a = b.getAt(b.find("share", c.findField("export_share").getValue()));
        return (a) ? a.get("is_data_enc") : false
    },
    needEnableClientEncrypt: function(a) {
        return this.helpEnableClientEncrypt && !a.isDestEncShare
    },
    getParams: function() {
        var b = {};
        var a = this.getForm().getFieldValues();
        b.action = this.action;
        b.target_type = this.target_type;
        b.transfer_type = this.transfer_type;
        if ("import" === this.action) {
            b.target_id = this.relink_target_id.value
        } else {
            b.target_id = a.target_id
        }
        if ("relink" === this.action || "import" === this.action) {
            if (this.uni_key) {
                b.uni_key = this.uni_key
            }
        } else {
            if ("export" == this.action) {
                b.share = a.export_share;
                b.target_id = a.export_dir;
                b.export_transfer_type = this.transfer_type;
                b.isDestEncShare = this.checkExportDestDataEnc()
            }
        }
        if (this.action !== "relink" && this.action !== "import" && !Ext.isEmpty(b.target_id)) {
            b.target_id += ".hbk"
        }
        b.clientEncrypt = this.needEnableClientEncrypt(b);
        return b
    },
    onDestCheck: function(i, c, a) {
        this.owner.clearStatusBusy();
        var h = c.result[0];
        var d = c.result[1];
        var f = c.result[2];
        if (!i) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(d.error.code));
            return
        }
        if (!h.success) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(h.error.code));
            return
        }
        this.owner.is_usb_share = h.data.is_usb_share;
        this.owner.support_compression = h.data.support_compression;
        this.owner.support_app_share = h.data.support_app_share;
        this.owner.support_detect_time_limit = h.data.support_detect_time_limit;
        this.owner.support_error_detect = h.data.support_error_detect;
        this.owner.support_version_file_log = h.data.support_version_file_log;
        if (!Ext.isEmpty(h.data.account_meta)) {
            this.owner.accountMeta.setData(h.data.account_meta)
        } else {
            this.owner.accountMeta = SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta()
        }
        if ("create" === this.action || "export" === this.action) {
            if ((!d.success && SYNO.SDS.Backup.ERR_TARGET_BROKEN === d.error.code) || (!f.success && SYNO.SDS.Backup.ERR_TARGET_BROKEN === f.error.code)) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "share_exist"))
            } else {
                if (!d.success && !f.success) {
                    if (SYNO.SDS.Backup.ERR_TARGET_NOT_EXIST === d.error.code && SYNO.SDS.Backup.ERR_TARGET_NOT_EXIST === f.error.code) {
                        this.goToNextStep(this.nextId)
                    } else {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(d.error.code))
                    }
                } else {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(SYNO.SDS.Backup.ERR_TARGET_EXIST))
                }
            }
        } else {
            if ("relink" === this.action || "import" === this.action) {
                if (!d.success) {
                    if (SYNO.SDS.Backup.ERR_TARGET_BROKEN === d.error.code) {
                        var g = SYNO.SDS.Backup.String("error", "target_unrelinkable") + "<br />" + SYNO.SDS.Backup.String("error", "target_not_support");
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), g)
                    } else {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorStringEx(d.error))
                    }
                } else {
                    this.owner.data_enc = d.data.data_enc;
                    this.owner.data_comp = d.data.data_comp;
                    if (d.data.relinkable) {
                        if ("relink" === this.action) {
                            if (d.data.task_config && d.data.task_config.storage_class) {
                                this.owner.storage_class = d.data.task_config.storage_class
                            }
                            this.owner.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("app", "relink_confirm"), function(j) {
                                if ("yes" === j) {
                                    this.uni_key = d.data.uni_key;
                                    if (d.data.data_enc) {
                                        this.launchPasswordWindow(true, function() {
                                            this.goToNextStep(this.nextId)
                                        })
                                    } else {
                                        this.goToNextStep(this.nextId)
                                    }
                                }
                            }, this)
                        } else {
                            this.uni_key = d.data.uni_key;
                            if (d.data.data_enc) {
                                this.launchPasswordWindow(false, function() {
                                    this.goToNextStep(this.nextId)
                                })
                            } else {
                                this.goToNextStep(this.nextId)
                            }
                        }
                    } else {
                        var e = SYNO.SDS.Backup.String("error", "target_unrelinkable");
                        if (d.data.target_not_support) {
                            if ("single" === d.data.format_type) {
                                e += "<br />" + SYNO.SDS.Backup.String("error", "not_support_relink_single_version")
                            } else {
                                if ("image" === d.data.format_type) {
                                    var b = String.format(SYNO.SDS.Backup.String("error", "not_support_relink_image"), SYNO.SDS.Backup.String("local", "repo_type_name_2"), SYNO.SDS.Backup.String("remote", "repo_type_name_2"));
                                    e += "<br />" + b
                                } else {
                                    if ("cloud_image" === d.data.format_type) {
                                        e += "<br />" + SYNO.SDS.Backup.String("error", "not_support_relink_cloud")
                                    } else {
                                        e += "<br />" + SYNO.SDS.Backup.String("error", "target_not_support")
                                    }
                                }
                            }
                        } else {
                            e += "<br />" + SYNO.SDS.Backup.GetErrorString(d.data.relink_error)
                        }
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), e)
                    }
                }
            } else {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"))
            }
        }
        return
    },
    goToNextStep: function() {
        this.owner.loadAppParams();
        this.owner.goNext(this.nextId)
    },
    checkDest: function(c) {
        if ("export" === c.action) {
            if ("image_remote" === c.transfer_type) {
                c.transfer_type = "image_local"
            } else {
                c.transfer_type = "local"
            }
        }
        var b = Ext.apply({}, c);
        var a = Ext.apply({}, c);
        a.target_id = a.target_id.slice(0, a.target_id.lastIndexOf(".hbk"));
        delete c.isDestEncShare;
        delete c.clientEncrypt;
        this.owner.setStatusBusy();
        this.sendWebAPI({
            compound: {
                stopwhenerror: false,
                mode: "parallel",
                params: [{
                    api: "SYNO.Backup.Repository",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], c),
                    params: Ext.apply(b, {
                        additional: ["is_usb_share", "support_compression", "support_app_share", "support_error_detect", "support_detect_time_limit", "account_meta", "support_version_file_log"]
                    })
                }, {
                    api: "SYNO.Backup.Target",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], c),
                    params: Ext.apply(c, {
                        additional: ["relinkable", "task_config"]
                    })
                }, {
                    api: "SYNO.Backup.Target",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], a),
                    params: a
                }]
            },
            timeout: 240000,
            scope: this,
            callback: this.onDestCheck
        })
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        var a = Ext.apply(this.owner.getParams(), this.getParams());
        if (a.isDestEncShare && (this.action === "create" || this.action === "export")) {
            this.owner.getMsgBox().confirm("", SYNO.SDS.Backup.String("app", "suggest_client_encrypt_than_enc_folder"), function(b) {
                if ("yes" === b) {
                    this.checkDest(a)
                } else {
                    this.helpEnableClientEncrypt = true;
                    return
                }
            }, this)
        } else {
            this.checkDest(a)
        }
        return false
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.Image.S3.Repository.CreateStep", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: null,
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "key",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            inputType: "password",
            fieldLabel: _T("backup", "s3_secret_key")
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            width: 270,
            indent: this.getFieldIndent(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    createBucket: function() {
        var b = this.getParams();
        b.owner = this.owner;
        var a = new SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateBucket(b);
        this.mon(a, "close", function() {
            var c = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField("create_bucket").clearValue();
            this.loadBucketStore(c)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField("create_bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: _T("backup", "s3_create_bucket"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField("relink_bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm();
        var a = function(e) {
            return b.findField(c + e).isValid()
        };
        if (a("key") && a("secret")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("key") && a("secret") && a("bucket")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var b = this.callParent();
        var a = this.getForm().getFieldValues();
        if ("create" === this.action) {
            b.key = a.create_key;
            b.secret = a.create_secret;
            b.bucket = a.create_bucket
        } else {
            if ("relink" === this.action || "import" === this.action) {
                b.key = a.relink_key;
                b.secret = a.relink_secret;
                b.bucket = a.relink_bucket
            }
        }
        b.server = this.transfer_type;
        b.transfer_type = this.transfer_type;
        b.support_region = false;
        b.request_style = "virtual_host_style";
        return b
    }
});
Ext.define("SYNO.Backup.Addon.Legacy.base.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.FormPanel",
    schedSetDefault: false,
    action: "create",
    pushSimpleSched: true,
    constructor: function(a) {
        if (a.owner.configWizard && this.pushSimpleSched) {
            this.configCreateModeSchedule(a.items[0].items)
        }
        this.choocedType = "";
        return this.callParent([a])
    },
    activate: function() {
        if (!this.schedSetDefault) {
            this.setSchedDefault();
            this.schedSetDefault = true
        }
        this.setDefaultTaskName();
        var a = this.owner.getParams();
        this.target_type = a.target_type;
        this.transfer_type = a.transfer_type;
        this.action = a.action;
        if ("export" !== a.action && ("cloud_image" === a.target_type || "image" === a.target_type)) {
            this.nextId = "rotate"
        } else {
            this.nextId = null
        }
        Ext.each(this.get(0).items.items, function(b, c, d) {
            if ("schedule_fieldset" === b.name) {
                if ("export" === this.action) {
                    b.disable();
                    b.hide()
                } else {
                    b.enable();
                    b.show()
                }
            }
        }, this);
        this.addToolTips();
        this.doLayout()
    },
    addToolTips: function() {
        if (this.isAddTips) {
            return
        }
        var i = this.getForm().findField("backup_meta");
        var a = this.getForm().findField("backup_thumb");
        var h = this.getForm().findField("enable_notify");
        var b = this.getForm().findField("enable_version_file_log");
        var d = this.getForm().findField("bkp_config");
        var c = this.getForm().findField("incrbkp_enable");
        var e = this.getForm().findField("storage_class");
        var g = this.getForm().findField("dest_auto_unmount");
        var f = this.getForm().findField("incheck_schedule_enable");
        if (i && i.getEl()) {
            SYNO.ux.AddTip(i.getEl(), _T("backup", "backup_metadata_info"))
        }
        if (a && a.getEl()) {
            SYNO.ux.AddTip(a.getEl(), _T("backup", "backup_synoea_info"))
        }
        if (h && h.getEl()) {
            SYNO.ux.AddTip(h.getEl(), SYNO.SDS.Backup.String("app", "enable_notify_info"))
        }
        if (b && b.getEl()) {
            if (b.disabled) {
                SYNO.ux.AddTip(b.getEl(), SYNO.SDS.Backup.String("error", "server_version_old"))
            } else {
                SYNO.ux.AddTip(b.getEl(), SYNO.SDS.Backup.String("app", "enable_version_file_log_tip"))
            }
        }
        if (d && d.getEl()) {
            SYNO.ux.AddTip(d.getEl(), SYNO.SDS.Backup.String("app", "bkp_config_info"))
        }
        if (c && c.getEl()) {
            SYNO.ux.AddTip(c.getEl(), _T("backup", "incrbkp_desc"))
        }
        if (e && e.getEl()) {
            SYNO.ux.AddTip(e.getEl(), SYNO.SDS.Backup.String("aws_s3", "storage_class_desc"))
        }
        if (g && g.getEl()) {
            SYNO.ux.AddTip(g.getEl(), _T("backup", "support_auto_unmount_dest_tip"))
        }
        if (f && f.getEl()) {
            SYNO.SDS.Utils.AddTip(f.getEl(), SYNO.SDS.Backup.String("app", "incheck_schedule_tip"))
        }
        this.isAddTips = true
    },
    setDefaultTaskName: function() {
        if ("import" === this.action) {
            return
        }
        var b = this.owner.getRepoInfo();
        var d = SYNO.Backup.Addon.Util.getInfoByTargetAndTransfer(b.target_type, b.transfer_type);
        if ("" !== this.getForm().getValues().task_name && this.choosedType === d.id) {
            return
        }
        this.choosedType = d.id;
        var c = SYNO.SDS.Backup.String(d.stringSection, "task_name_prefix");
        if ("" === c) {
            c = "My Backup"
        } else {
            if (!Ext.isEmpty(b.remote_url) && "aws_s3" === b.transfer_type) {
                c = "S3 Backup"
            }
        }
        var a = this.owner.createTaskDefaultName(c);
        if ("synocloud_swift" === b.transfer_type) {
            a = c
        }
        this.getForm().setValues({
            task_name: a
        })
    },
    configCreateModeSchedule: function(a) {
        a.push(this.simpleSchedule = new SYNO.SDS.Backup.SimpleScheduleComponent({
            canUnckeckSchedule: true,
            owner: this
        }))
    },
    setSchedDefault: function() {
        var a = {};
        a.schedule_type = "basic";
        a.basic_weekday = "0,1,2,3,4,5,6";
        a.hour = 3;
        a.minute = 0;
        this.getForm().loadRecord({
            data: a
        })
    },
    getScheduleParams: function() {
        if (this.simpleSchedule) {
            return this.simpleSchedule.getData()
        }
        return {}
    },
    getNext: function() {
        var a = function(l) {
            var m = l.split("<br/>");
            if (4 === m.length) {
                return String.format("{0}<br/>{1}<br/><span class='red-status'>{2}</span><br/>{3}", m[0], m[1], m[2], m[3])
            } else {
                if (2 == m.length) {
                    return String.format("<span class='red-status'>{0}</span><br/>{1}", m[0], m[1])
                }
            }
        };
        if (!this.getForm().isValid()) {
            var c = this.getForm().findField("enable_data_encrypt");
            if (!c || !c.getValue()) {
                return false
            }
            var g = this.getForm().findField("encrypt_password");
            var e = this.getForm().findField("encrypt_password_confirm");
            if (!g.isValid() || !e.isValid()) {
                this.scrollTo(c.getEl())
            }
            return false
        }
        var d = this.getParams();
        if (!this.owner.isTaskNameValid(d.name)) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("localbkp", "localbkp_bkpset_exist"));
            return false
        }
        var k = this.getForm().findField("enable_data_encrypt");
        var h = (k && true === k.getValue());
        var b = (SYNO.Backup.Util.IsImage(this.owner.getParams().target_type)) ? "source_repo_image" : "source_repo_legacy";
        var i = this.owner.getStep(b).getWarnEncList();
        var j = function(m) {
            var l = "task_encrypt_warning";
            if (m.action === "relink" || m.action === "import") {
                l = "relink_encrypt_warning"
            }
            m.owner.getMsgBox().confirm(_T("leaf", "backup"), a(SYNO.SDS.Backup.String("app", l)), function(n) {
                if ("yes" === n) {
                    m.owner.goNext(m.nextId)
                }
            }, m);
            return false
        };
        if (true === h) {
            return j(this)
        }
        if (0 < i.length && (this.action === "create" || this.action === "export")) {
            var f = this.owner.getParams().isDestEncShare;
            if (!f) {
                this.owner.getMsgBox().confirm(_T("leaf", "backup"), String.format(SYNO.SDS.Backup.String("app", "warn_bkp_enc_source_no_client_enc"), "<b>" + i.join(", ") + "</b>"), function(l) {
                    if ("yes" === l) {
                        this.owner.goNext(this.nextId)
                    }
                }, this);
                return false
            }
            return this.nextId
        }
        return this.nextId
    },
    getParams: function() {
        var e = {};
        var a = this.getForm().getFieldValues();
        var c = this.getForm().findField("bandwidthcheck");
        var b = this.getForm().findField("part_size");
        var d = this.getForm().findField("enable_data_compress");
        if (a.task_name) {
            e.name = a.task_name;
            delete a.task_name
        }
        if (this.owner.configWizard && "export" !== this.action) {
            e.schedule = this.getScheduleParams()
        }
        delete a.schedule_enable;
        delete a.basic_weekday;
        a.delete_on_target = !a.incrbkp_enable;
        delete a.incrbkp_enable;
        delete a.incrbkp_desc;
        if (c && true === c.getValue()) {
            a.bw_limit = this.getForm().findField("bw_limit").getValue()
        }
        if (b) {
            a.part_size = this.getForm().findField("part_size").getValue()
        }
        if (d) {
            a.enable_data_compress = d.getValue()
        }
        e.backup_params = a;
        return e
    }
});
Ext.define("SYNO.Backup.Addon.base.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    pushSimpleSched: false,
    constructor: function(a) {
        this.containerLabelWidth = 300;
        var b = [{
            xtype: "syno_fieldset",
            itemId: "fieldset",
            collapsible: false,
            bwrapStyle: {
                padding: "0px"
            },
            items: this.configImageFields(a)
        }];
        var c = Ext.apply({
            disableDataComp: false,
            hideDataComp: false,
            cls: "syno-backup-task-setting",
            items: b
        }, a);
        this.lastAnchor = "";
        return this.callParent([c])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", this.addTips, this, {
            single: true
        })
    },
    getFieldset: function() {
        return this.getComponent("fieldset")
    },
    getSettingConfig: function() {
        return []
    },
    configImageFields: function(a) {
        var c = [];
        c = c.concat([{
            xtype: "syno_fieldset",
            labelWidth: 150,
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                value: a.defaultName,
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                labelWidth: 246,
                width: 270,
                allowBlank: false,
                maxLength: 32,
                vtype: "taskname"
            }]
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_version_file_log",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_version_file_log"),
            checked: false
        }, {
            xtype: "syno_checkbox",
            name: "bkp_config",
            checked: true,
            disabled: true,
            hidden: true,
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_checkbox",
            name: "dest_auto_unmount",
            boxLabel: SYNO.SDS.Backup.String("app", "support_auto_unmount_dest"),
            checked: false,
            hidden: false
        }, {
            xtype: "syno_checkbox",
            name: "enable_data_compress",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_data_compress"),
            checked: true,
            disabled: a.disableDataComp,
            hidden: a.hideDataComp
        }]);
        c = c.concat(this.getSettingConfig(a));
        if (a.owner.configWizard) {
            this.configCreateModeSchedule(c);
            c.push(this.incheckSchedule = new SYNO.SDS.Backup.SimpleIntegrityCheckPanel({
                owner: this,
                targetType: a.owner.getParams().target_type,
                containerLabelWidth: this.containerLabelWidth
            }))
        }
        var b = Ext.id();
        var d = {};
        if (a.hideDataEnc) {
            d = {
                enable: [b]
            }
        } else {
            d = {
                enable: ["encrypt_password", "encrypt_password_confirm"]
            }
        }
        c = c.concat([{
            xtype: "syno_checkbox",
            name: "enable_data_encrypt",
            itemId: "enable_data_encrypt",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_data_encrypt"),
            checked: false,
            disabled: a.hideDataEnc,
            listeners: {
                check: function() {
                    var e = ["encrypt_password", "encrypt_password_confirm"];
                    this.updateCheckboxFieldView(e, this.getForm().findField("enable_data_encrypt").getValue(), true)
                },
                scope: this
            },
            groupFields: d
        }, {
            xtype: "syno_button",
            id: b,
            text: SYNO.SDS.Backup.String("app", "download_encryption_key"),
            handler: function(f) {
                var e = this.findAppWindow().getCurrentTask();
                var g = new SYNO.SDS.Backup.PrivateKeyDownloadWindow({
                    owner: this.owner,
                    appWin: this.owner,
                    task_id: e.task_id,
                    file_name: e.name
                });
                g.open()
            },
            hidden: !a.hideDataEnc,
            scope: this,
            indent: 1
        }, {
            xtype: "syno_textfield",
            name: "encrypt_password",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            labelWidth: 246,
            width: 270,
            hidden: true,
            disabled: true,
            allowBlank: false,
            minLength: 8,
            maxLength: 64,
            indent: 1,
            inputType: "password"
        }, {
            xtype: "syno_textfield",
            name: "encrypt_password_confirm",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_confirm_input"),
            labelWidth: 246,
            width: 270,
            hidden: true,
            disabled: true,
            allowBlank: false,
            minLength: 8,
            maxLength: 64,
            indent: 1,
            inputType: "password",
            validator: function(e) {
                if (e !== this.ownerCt.ownerCt.getForm().findField("encrypt_password").getValue()) {
                    return SYNO.SDS.Backup.String("error", "task_password_confirm_fail")
                }
                return true
            }
        }, {
            xtype: "syno_displayfield",
            htmlEncode: false,
            value: SYNO.SDS.Backup.NoteStyleString("app", "task_setting_config_backup")
        }]);
        return c
    },
    updateCheckboxFieldView: function(a, c, d) {
        if (!Ext.isArray(a)) {
            return
        }
        var b = false;
        if (d) {
            if (this.owner instanceof SYNO.SDS.Backup.TaskCreateWizard) {
                var e = this.owner.getParams();
                b = ("relink" === e.action || "import" === e.action)
            } else {
                b = true
            }
        }
        Ext.each(a, function(f) {
            if (c && !b) {
                this.getForm().findField(f).show()
            } else {
                this.getForm().findField(f).hide()
            }
        }, this);
        this.doLayout()
    },
    activate: function() {
        var a = this.owner.getParams();
        if (this.lastAnchor !== this.owner.getWizardAnchor()) {
            if ("relink" === a.action || "import" === a.action) {
                this.getForm().findField("encrypt_password").setValue("");
                this.getForm().findField("encrypt_password_confirm").setValue("");
                this.getForm().findField("encrypt_password").setDisabled(true);
                this.getForm().findField("encrypt_password").setVisible(false);
                this.getForm().findField("encrypt_password_confirm").setDisabled(true);
                this.getForm().findField("encrypt_password_confirm").setVisible(false);
                this.getForm().findField("enable_data_encrypt").setValue(this.owner.data_enc);
                this.getForm().findField("enable_data_encrypt").setDisabled(true);
                this.getForm().findField("enable_data_compress").setValue(this.owner.data_comp);
                this.getForm().findField("enable_data_compress").setDisabled(true);
                this.getForm().findField("enable_data_compress").setVisible(!this.hideDataComp);
                this.getForm().findField("enable_version_file_log").setDisabled(!this.owner.support_version_file_log)
            } else {
                this.getForm().findField("encrypt_password").setValue("");
                this.getForm().findField("encrypt_password_confirm").setValue("");
                this.getForm().findField("enable_data_encrypt").setValue(a.clientEncrypt);
                this.getForm().findField("enable_data_encrypt").setDisabled(false);
                this.getForm().findField("enable_data_compress").setValue(true);
                this.getForm().findField("enable_data_compress").setDisabled(this.disableDataComp);
                this.getForm().findField("enable_data_compress").setVisible(!this.hideDataComp);
                this.getForm().findField("enable_version_file_log").setDisabled(!this.owner.support_version_file_log)
            }
            this.lastAnchor = this.owner.getWizardAnchor()
        }
        if (!Ext.isEmpty(this.incheckSchedule)) {
            if (a.action !== "export" && this.owner.support_error_detect) {
                this.incheckSchedule.show()
            } else {
                this.incheckSchedule.hide()
            }
        }
        this.callParent(arguments)
    },
    addTips: function() {
        var a = this.getForm().findField("enable_version_file_log");
        if (a && a.getEl()) {
            if (this.isSuspended) {
                SYNO.ux.AddTip(a.getEl(), SYNO.SDS.Backup.String("app", "suspend_cannot_modify_setting_tip"))
            } else {
                if (a.disabled) {
                    SYNO.ux.AddTip(a.getEl(), SYNO.SDS.Backup.String("error", "server_version_old"))
                } else {
                    SYNO.ux.AddTip(a.getEl(), SYNO.SDS.Backup.String("app", "enable_version_file_log_tip"))
                }
            }
        }
    },
    getParams: function() {
        var a = this.callParent();
        if (!Ext.isEmpty(this.incheckSchedule)) {
            if (!Ext.isEmpty(a.backup_params)) {
                delete a.backup_params.incheck_schedule_enable;
                delete a.backup_params.incheck_frequency;
                delete a.backup_params.incheck_data_enable
            }
            if (!this.incheckSchedule.hidden) {
                a.incheck_schedule = this.incheckSchedule.getData()
            }
        }
        return a
    }
});
Ext.define("SYNO.Backup.Addon.Cloud.base.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Task.SettingPanel",
    incheckSchedSetDefault: false,
    constructor: function() {
        this.callParent(arguments)
    },
    activate: function() {
        if (!this.schedSetDefault) {
            this.checkIsBusiness()
        }
        this.callParent(arguments)
    },
    checkIsBusiness: function() {
        if (SYNO.SDS.isBusinessModel || false === _S("is_admin")) {
            this.setSchedRandom(true)
        } else {
            if ("yes" !== _D("support_btrfs")) {
                this.setSchedRandom(false)
            } else {
                this.owner.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.Core.Package",
                    version: 2,
                    method: "list",
                    scope: this,
                    callback: function(d, b, c) {
                        this.owner.clearStatusBusy();
                        if (!d) {
                            this.setSchedRandom(false);
                            return
                        }
                        var a = true;
                        Ext.each(b.packages, function(e) {
                            if (e.id === "SynologyMoments" || e.id === "PhotoStation" || e.id === "AudioStation" || e.id === "VideoStation" || e.id === "DownloadStation") {
                                a = false;
                                return
                            }
                        }, this);
                        this.setSchedRandom(a)
                    }
                })
            }
        }
    },
    setSchedRandom: function(a) {
        if (a) {
            var b = Math.floor(100 * Math.random());
            if (30 > b) {
                this.backup_hour = 19
            } else {
                if (50 > b) {
                    this.backup_hour = 20
                } else {
                    if (70 > b) {
                        this.backup_hour = 21
                    } else {
                        if (90 > b) {
                            this.backup_hour = 22
                        } else {
                            this.backup_hour = 23
                        }
                    }
                }
            }
        } else {
            var c = Math.floor(9 * Math.random());
            this.backup_hour = 9 + c
        }
        var d = Math.floor(6 * Math.random());
        if (0 === d) {
            if (0 === Math.floor(10 * Math.random())) {
                this.backup_minute = 0
            } else {
                this.backup_minute = 40
            }
        } else {
            this.backup_minute = d * 10
        }
        this.setIncheckSchedDefault();
        this.setSchedDefault();
        this.schedSetDefault = true
    },
    setIncheckSchedDefault: function() {
        var a = {};
        if (0 === Math.floor(2 * Math.random())) {
            a.incheck_basic_weekday = 0
        } else {
            a.incheck_basic_weekday = 6
        }
        a.incheck_weekday_hour = (this.backup_hour + 2) % 24;
        a.incheck_weekday_min = this.backup_minute;
        this.getForm().loadRecord({
            data: a
        })
    },
    setSchedDefault: function() {
        var a = {};
        a.schedule_type = "basic";
        a.basic_weekday = "0,1,2,3,4,5,6";
        a.hour = this.backup_hour;
        a.minute = this.backup_minute;
        this.getForm().loadRecord({
            data: a
        })
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.Image.S3.Backup.ParamsPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        this.partSizeStore = new Ext.data.SimpleStore({
            fields: ["partsize", "partsizeValue"]
        });
        this.loadPartSizeStore();
        return [{
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "s3_multipart_size"),
            name: "part_size",
            width: 80,
            displayField: "partsize",
            valueField: "partsizeValue",
            value: 512,
            store: this.partSizeStore
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        c.backup_params.part_size = b("part_size");
        return c
    },
    activate: function() {
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "trans_encrypt", false);
            c(a, "part_size", false)
        } else {
            c(a, "trans_encrypt", true);
            c(a, "part_size", true)
        }
        if (this.lastAnchor !== this.owner.getWizardAnchor()) {
            this.setDefaultSizeStore()
        }
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Backup.Addon.Util.Image.S3.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    addon_id: null,
    target_type: null,
    transfer_type: null,
    comboboxWidth: 270,
    S3_BUCKET_LENGTH: 63,
    constructor: function(b) {
        var a = [];
        this.target_type = "cloud";
        Ext.copyTo(this, b, "owner, transfer_type, addon_id");
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_access_key"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_secret_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            name: "bktselect",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            maxlength: this.S3_BUCKET_LENGTH,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            width: this.comboboxWidth,
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image";
            this.owner.setSingle(false)
        } else {
            this.target_type = "cloud";
            this.owner.setSingle(true)
        }
        if ("image" === b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = {
            key: b("accesskey"),
            secret: b("secretkey"),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            addon_id: this.addon_id
        };
        c.transfer_type = this.transfer_type;
        c.support_region = false;
        c.request_style = "virtual_host_style";
        return c
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.Backup.Addon.Util.getString(this.addon_id, "repo_type_name"));
        a.append(_T("netbackup", "netbkp_slct_server"), SYNO.Backup.Addon.Util.getString(b.transfer_type, "name"));
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = this.getParams();
        delete a.bucket;
        delete a.target_id;
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("netbackup", "s3_retrieve_bucket")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Backup");
SYNO.SDS.Backup.Addon.Util.Image.OpenStack.ibm_softlayer_region_list = function() {
    return [
        ["ams01", "Amsterdam 1"],
        ["che01", "Chennai 1"],
        ["dal05", "Dallas 5"],
        ["fra02", "Frankfurt 2"],
        ["hkg02", "Hong Kong 2"],
        ["par01", "Paris 1"],
        ["lon02", "London 2"],
        ["mel01", "Melbourne 1"],
        ["mil01", "Milan 1"],
        ["mon01", "Montreal 1"],
        ["mex01", "Mexico 1"],
        ["osl01", "Oslo 1"],
        ["sao01", "Sao Paulo 1"],
        ["seo01", "Seoul 1"],
        ["sng01", "Singapore 1"],
        ["syd01", "Sydney 1"],
        ["sjc01", "San Jose 1"],
        ["tor01", "Toronto 1"],
        ["tok02", "Toyko 2"],
        ["wdc", "Washington 1"]
    ]
};
SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping = function(a) {
    var d = {
        ORD: "Chicago",
        DFW: "Dallas-Fort Worth",
        HKG: "Hong Kong",
        IAD: "Northern Virginia",
        SYD: "Sydney",
        LON: "London",
        "region-b.geo-1": "US East",
        "region-a.geo-1": "US West",
        ams01: "Amsterdam 1",
        che01: "Chennai 1",
        dal05: "Dallas 5",
        fra02: "Frankfurt 2",
        hkg02: "Hong Kong 2",
        par01: "Paris 1",
        lon02: "London 2",
        mel01: "Melbourne 1",
        mil01: "Milan 1",
        mon01: "Montreal 1",
        mex01: "Mexico 1",
        osl01: "Oslo 1",
        sao01: "Sao Paulo 1",
        seo01: "Seoul 1",
        sng01: "Singapore 1",
        syd01: "Sydney 1",
        sjc01: "San Jose 1",
        tor01: "Toronto 1",
        tok02: "Toyko 2",
        wdc: "Washington 1"
    };
    var b = [];
    for (var c = 0; c < a.length; c++) {
        var e = d[a[c][0]];
        if (e === undefined) {
            b.push([a[c][0], a[c][0]])
        } else {
            b.push([a[c][0], e])
        }
    }
    return b
};
Ext.define("SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Backup.ParamsPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel"
});
Ext.define("SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.remote_url = b.remote_url;
        this.region = b.region;
        this.s3key = b.s3key;
        this.s3secret = b.s3secret;
        this.tenant_id = b.tenant_id;
        this.tenant_name = b.tenant_name;
        this.domain_id = b.domain_id;
        this.domain_name = b.domain_name;
        this.auth_version = b.auth_version;
        this.transfer_type = b.transfer_type;
        var c = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("openstack", "container_name_letter_limit")
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.SDS.Backup.String("openstack", "create_container"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_url: this.remote_url,
            region: this.region,
            key: this.s3key,
            secret: this.s3secret,
            tenant_id: this.tenant_id,
            tenant_name: this.tenant_name,
            domain_id: this.domain_id,
            domain_name: this.domain_name,
            auth_version: this.auth_version,
            transfer_type: this.transfer_type,
            container: this.items.get(0).getForm().findField("bucket").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "create",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                var e = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!d) {
                    this.showPossibleBucketError(b.code, e);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, c) {
        var b = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            b = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
            return
        }
        if (c.match(/[//]/)) {
            b = b.concat("<BR>- ", SYNO.SDS.Backup.String("openstack", "container_name_letter_limit"))
        }
        if (1 > c.length || 256 < c.length) {
            b = b.concat("<BR>- ", String.format(SYNO.SDS.Backup.String("openstack", "container_name_length_limit"), "1", "256"))
        }
        if (b.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("openstack", "container_name_invalid_short") + " " + SYNO.SDS.Backup.String("openstack", "container_name_meet_condition") + " " + _T("common", "colon") + b);
            return
        }
        b = SYNO.SDS.Backup.String("openstack", "container_name_invalid_short");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.Config");
SYNO.Backup.Addon.Config.addon_list = [{
    id: "local",
    target_type: "image",
    transfer_type: "image_local",
    category: "syno_nas",
    destIconCls: "syno-backup-destination-local",
    taskIconCls: "syno-backup-task-local",
    stringSection: "local",
    displayName: SYNO.SDS.Backup.String("local", "repo_type_name_2"),
    options: {
        supportUSBStation: false
    }
}, {
    id: "remote",
    target_type: "image",
    transfer_type: "image_remote",
    category: "syno_nas",
    destIconCls: "syno-backup-destination-remote",
    taskIconCls: "syno-backup-task-remote",
    stringSection: "remote",
    displayName: SYNO.SDS.Backup.String("remote", "repo_type_name_2")
}, {
    id: "legacy_local",
    target_type: "share",
    transfer_type: "local",
    category: "syno_nas",
    destIconCls: "syno-backup-destination-legacy-local",
    taskIconCls: "syno-backup-task-legacy-local",
    stringSection: "legacy_local",
    displayName: SYNO.SDS.Backup.String("legacy_local", "repo_type_name_2"),
    options: {
        supportRestore: false
    }
}, {
    id: "synocloud",
    target_type: "cloud_image",
    transfer_type: "synocloud_swift",
    category: "syno_nas",
    destIconCls: "syno-backup-destination-synocloud",
    taskIconCls: "syno-backup-task-synocloud",
    stringSection: "synocloud",
    displayName: SYNO.SDS.Backup.String("synocloud", "repo_type_name_2"),
    oauth: {
        url: ((function() {
            var a = Ext.urlDecode(location.search.substr(1)).everest;
            if (a === "daily") {
                return "https://account.c2.synology.com/hb/?everest=daily&origin={2}&version=HyperBackup/{3}"
            } else {
                if (a === "c2test") {
                    return "https://account.c2test.synology.com/hb/?origin={2}&version=HyperBackup/{3}"
                } else {
                    if (a === "c2testdaily") {
                        return "https://account.c2test.synology.com/hb/?everest=daily&origin={2}&version=HyperBackup/{3}"
                    } else {
                        return "https://account.c2.synology.com/hb/?origin={2}&version=HyperBackup/{3}"
                    }
                }
            }
        })())
    },
    options: {
        regionWebLink: "https://{0}.c2.synology.com/backupservice",
        blockedLanguage: ["chs"],
        popupIcon: true
    }
}, {
    id: "rsync",
    target_type: "cloud_image",
    transfer_type: "rsync",
    category: "file_server",
    destIconCls: "syno-backup-destination-rsync",
    taskIconCls: "syno-backup-task-rsync",
    stringSection: "rsync",
    displayName: SYNO.SDS.Backup.String("rsync", "repo_type_name_2")
}, {
    id: "webdav",
    target_type: "cloud_image",
    transfer_type: "webdav",
    category: "file_server",
    destIconCls: "syno-backup-destination-webdav",
    taskIconCls: "syno-backup-task-webdav",
    stringSection: "webdav",
    displayName: SYNO.SDS.Backup.String("webdav", "repo_type_name")
}, {
    id: "legacy_rsync",
    target_type: "share",
    transfer_type: "rsync",
    category: "file_server",
    destIconCls: "syno-backup-destination-legacy-rsync",
    taskIconCls: "syno-backup-task-legacy-rsync",
    stringSection: "legacy_rsync",
    displayName: SYNO.SDS.Backup.String("legacy_rsync", "repo_type_name_2"),
    options: {
        dest_setting_nextId: "legacy_rsync::dest_folder_setting",
        supportRestore: false
    }
}, {
    id: "legacy_rsync_ds",
    target_type: "share",
    transfer_type: "rsync_ds",
    category: "file_server",
    destIconCls: "syno-backup-destination-legacy-rsync",
    taskIconCls: "syno-backup-task-legacy-rsync",
    stringSection: "legacy_rsync",
    displayName: SYNO.SDS.Backup.String("legacy_rsync", "repo_type_name_2"),
    displayMode: "private",
    options: {
        dest_setting_nextId: "legacy_rsync::dest_folder_setting",
        supportRestore: false
    }
}, {
    id: "rsync_ds",
    target_type: "cloud_image",
    transfer_type: "rsync_ds",
    category: "file_server",
    destIconCls: "syno-backup-destination-rsync",
    taskIconCls: "syno-backup-task-rsync",
    stringSection: "rsync",
    displayName: SYNO.SDS.Backup.String("rsync", "repo_type_name_2"),
    displayMode: "private"
}, {
    id: "aws_s3",
    target_type: "cloud_image",
    transfer_type: "aws_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-aws-s3",
    taskIconCls: "syno-backup-task-aws_s3",
    stringSection: "aws_s3",
    displayName: SYNO.SDS.Backup.String("aws_s3", "repo_type_name")
}, {
    id: "azure_blob",
    target_type: "cloud_image",
    transfer_type: "azure_blob",
    category: "cloud",
    destIconCls: "syno-backup-destination-azure-blob",
    taskIconCls: "syno-backup-task-azure_blob",
    stringSection: "azure",
    displayName: SYNO.SDS.Backup.String("azure", "repo_type_name")
}, {
    id: "azure_cn_blob",
    target_type: "cloud_image",
    transfer_type: "azure_cn_blob",
    category: "cloud",
    destIconCls: "syno-backup-destination-azure-blob",
    taskIconCls: "syno-backup-task-azure_blob",
    stringSection: "azure",
    displayName: SYNO.SDS.Backup.String("azure", "repo_type_name"),
    displayMode: "private"
}, {
    id: "openstack",
    target_type: "cloud_image",
    transfer_type: "openstack_swift",
    category: "file_server",
    destIconCls: "syno-backup-destination-openstack",
    taskIconCls: "syno-backup-task-openstack",
    stringSection: "openstack",
    displayName: SYNO.SDS.Backup.String("openstack", "repo_type_name")
}, {
    id: "ibm_softlayer",
    target_type: "cloud_image",
    transfer_type: "ibm_softlayer_swift",
    category: "cloud",
    destIconCls: "syno-backup-destination-ibm-softlayer",
    taskIconCls: "syno-backup-task-ibm_softlayer",
    stringSection: "ibm_softlayer",
    displayMode: "private",
    displayName: SYNO.SDS.Backup.String("ibm_softlayer", "repo_type_name")
}, {
    id: "rackspace",
    target_type: "cloud_image",
    transfer_type: "rackspace_swift",
    category: "cloud",
    destIconCls: "syno-backup-destination-rackspace",
    taskIconCls: "syno-backup-task-rackspace",
    stringSection: "rackspace",
    displayName: SYNO.SDS.Backup.String("rackspace", "repo_type_name")
}, {
    id: "dropbox",
    target_type: "cloud_image",
    transfer_type: "dropbox",
    category: "cloud",
    destIconCls: "syno-backup-destination-dropbox",
    taskIconCls: "syno-backup-task-dropbox",
    stringSection: "dropbox",
    displayName: SYNO.SDS.Backup.String("dropbox", "repo_type_name"),
    oauth: {
        url: "https://www.dropbox.com/1/oauth2/authorize?response_type=code&client_id={0}&redirect_uri={1}&state={2}&force_reapprove=true",
        client_id: "hzp1h2mds8a9vaj",
        redirect: "https://synooauth.synology.com/HyperBackup/oauth_v2/dropbox.php"
    }
}, {
    id: "google_drive",
    target_type: "cloud_image",
    transfer_type: "google_drive",
    category: "cloud",
    destIconCls: "syno-backup-destination-googledrive",
    taskIconCls: "syno-backup-task-google_drive",
    stringSection: "google_drive",
    displayName: SYNO.SDS.Backup.String("google_drive", "repo_type_name"),
    oauth: {
        url: "https://accounts.google.com/o/oauth2/auth?client_id={0}&redirect_uri={1}&state={2}&scope=https://www.googleapis.com/auth/drive&response_type=code&access_type=offline&prompt=consent",
        client_id: "535720510400-mmsdiolabfk3ua33u7jpgifqahfnb8eb.apps.googleusercontent.com",
        redirect: "https://synooauth.synology.com/HyperBackup/oauth_v2/google_drive.php"
    }
}, {
    id: "hubic",
    target_type: "cloud_image",
    transfer_type: "hubic_swift",
    category: "cloud",
    destIconCls: "syno-backup-destination-hubic",
    taskIconCls: "syno-backup-task-hubic",
    stringSection: "hubic",
    displayName: SYNO.SDS.Backup.String("hubic", "repo_type_name"),
    oauth: {
        url: "https://api.hubic.com/oauth/auth?client_id={0}&scope=usage.r,account.r,getAllLinks.r,credentials.r,activate.w,links.drw&response_type=code&state={2}&redirect_uri={1}",
        client_id: "api_hubic_t0IBbQ2jxSp54HpuShHk3JQujuhc4PC6",
        redirect: "https://synooauth.synology.com/HyperBackup/oauth_v2/hubic.php"
    }
}, {
    id: "hidrive",
    target_type: "cloud_image",
    transfer_type: "hidrive",
    category: "cloud",
    destIconCls: "syno-backup-destination-hidrive",
    taskIconCls: "syno-backup-task-hidrive",
    stringSection: "hidrive",
    displayName: SYNO.SDS.Backup.String("hidrive", "repo_type_name")
}, {
    id: "sfr_s3",
    target_type: "cloud_image",
    transfer_type: "sfr_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-sfr-s3",
    taskIconCls: "syno-backup-task-sfr_s3",
    stringSection: "sfr_s3",
    displayName: SYNO.SDS.Backup.String("sfr_s3", "repo_type_name")
}, {
    id: "hicloud_s3",
    target_type: "cloud_image",
    transfer_type: "hicloud_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-hicloud-s3",
    taskIconCls: "syno-backup-task-hicloud_s3",
    stringSection: "hicloud_s3",
    displayName: SYNO.SDS.Backup.String("hicloud_s3", "repo_type_name")
}, {
    id: "jdcloud_s3",
    target_type: "cloud_image",
    transfer_type: "jdcloud_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-jdcloud-s3",
    taskIconCls: "syno-backup-task-jdcloud_s3",
    stringSection: "jdcloud_s3",
    displayName: SYNO.SDS.Backup.String("jdcloud_s3", "repo_type_name")
}, {
    id: "legacy_aws_s3",
    target_type: "cloud",
    transfer_type: "aws_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-aws-s3",
    taskIconCls: "syno-backup-task-aws_s3",
    stringSection: "aws_s3",
    displayName: SYNO.SDS.Backup.String("aws_s3", "repo_type_name"),
    displayMode: "protect",
    options: {
        supportRestore: false
    }
}, {
    id: "legacy_sfr_s3",
    target_type: "cloud",
    transfer_type: "sfr_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-sfr-s3",
    taskIconCls: "syno-backup-task-sfr_s3",
    stringSection: "sfr_s3",
    displayName: SYNO.SDS.Backup.String("sfr_s3", "repo_type_name"),
    displayMode: "private",
    options: {
        supportRestore: false
    }
}, {
    id: "legacy_hicloud_s3",
    target_type: "cloud",
    transfer_type: "hicloud_s3",
    category: "cloud",
    destIconCls: "syno-backup-destination-hicloud-s3",
    taskIconCls: "syno-backup-task-hicloud_s3",
    stringSection: "hicloud_s3",
    displayName: SYNO.SDS.Backup.String("hicloud_s3", "repo_type_name"),
    displayMode: "private",
    options: {
        supportRestore: false
    }
}, {
    id: "legacy_azure_blob",
    target_type: "cloud",
    transfer_type: "azure_blob",
    category: "cloud",
    destIconCls: "syno-backup-destination-azure-blob",
    taskIconCls: "syno-backup-task-azure_blob",
    stringSection: "azure",
    displayName: SYNO.SDS.Backup.String("azure", "repo_type_name"),
    displayMode: "protect",
    options: {
        supportRestore: false
    }
}];
SYNO.Backup.Addon.Config.supportProtectType = Ext.urlDecode(location.search.substr(1)).supportProtectType === "true" ? true : false;
Ext.each(SYNO.Backup.Addon.Config.addon_list, function(c, b, d) {
    var a = Ext.apply({
        id: null,
        target_type: null,
        transfer_type: null,
        category: null,
        destIconCls: null,
        taskIconCls: null,
        stringSection: null,
        displayName: null,
        displayMode: "public",
        hidden: false,
        oauth: null,
        options: {}
    }, c);
    if ("private" === a.displayMode) {
        a.hidden = true
    } else {
        if ("protect" === a.displayMode && false === SYNO.Backup.Addon.Config.supportProtectType) {
            a.hidden = true
        } else {
            if ("yes" === _D("usbstation") && false === a.options.supportUSBStation) {
                a.hidden = true
            } else {
                if (Ext.isArray(a.options.blockedLanguage) && -1 !== a.options.blockedLanguage.indexOf(SYNO.SDS.Session.lang)) {
                    a.hidden = true
                }
            }
        }
    }
    d[b] = a
});
SYNO.Backup.Addon.Config.addon_list_templete = JSON.stringify(SYNO.Backup.Addon.Config.addon_list);
SYNO.Backup.Addon.Config.updateAllowList = function(c, b) {
    var a = {
        legacy_local: "single_local",
        legacy_rsync: "single_rsync",
        legacy_rsync_ds: "single_rsync",
        local: "image_local",
        remote: "image_remote",
        rsync: "image_rsync",
        rsync_ds: "image_rsync",
        synocloud: "synocloud",
        hidrive: "hidrive",
        legacy_hicloud_s3: "hidrive",
        jdcloud_s3: "jd_cloud_oss",
        openstack: "openstask_swift",
        rackspace: "rackspace",
        webdav: "webdav",
        google_drive: "google_drive",
        amazon_cloud_drive: "amazon_drive",
        azure_blob: "azure_storage",
        azure_cn_blob: "azure_storage",
        legacy_azure_blob: "azure_storage",
        dropbox: "dropbox",
        hicloud_s3: "hicloud_s3",
        aws_s3: "s3_storage",
        legacy_aws_s3: "s3_storage",
        sfr_s3: "sfr_nas_backup",
        legacy_sfr_s3: "sfr_nas_backup",
        ibm_softlayer: "ibm_softlayer"
    };
    var d = JSON.parse(SYNO.Backup.Addon.Config.addon_list_templete);
    if (true !== c) {
        Ext.each(d, function(g, f, h) {
            var e = g;
            if (e.hidden === false) {
                if (!a.hasOwnProperty(e.id) || -1 === b.indexOf(a[e.id])) {
                    e.hidden = true
                }
            }
            h[f] = e
        })
    }
    SYNO.Backup.Addon.Config.addon_list = d
};
Ext.define("SYNO.Backup.Addon.amazon_cloud_drive.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "amazon_cloud_drive",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "amazon_cloud_drive";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "container",
            fieldLabel: SYNO.SDS.Backup.String("amazon_cloud_drive", "root_folder_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainers()) {
                    this.scope.loadContainers()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectContainer,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectContainer: function(a) {
        this.loadTarget(a.getValue())
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["remote_access_token", "remote_refresh_token"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            target_id: b("target"),
            container: b("container"),
            remote_access_token: this.access_token,
            remote_refresh_token: this.refresh_token,
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("amazon_cloud_drive", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.container + " / " + b.target_id)
    },
    getListContainerRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "target_type,transfer_type,remote_access_token,remote_refresh_token,container");
        return a
    },
    needReloadContainers: function() {
        var a = this.getListContainerRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadContainers: function() {
        var a = this.getListContainerRequest();
        if (!a.remote_access_token || !a.remote_refresh_token) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("amazon_cloud_drive", "load_root_folders")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.AmazonCloudDrive.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["remote_access_token", "remote_refresh_token"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadContainerData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadContainerData(b)
            }
        })
    },
    loadContainerData: function(b) {
        var a = this.getForm().findField("container");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.container_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(a) {
        var b = this.getLoadTargetParams();
        if (!b.container) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(b)) {
            return
        }
        this.lastQueryTarget = Ext.encode(b);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: b,
            encryption: ["remote_access_token", "remote_refresh_token"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(b);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token;
        this.refresh_token = a.refresh_token
    }
});
Ext.define("SYNO.Backup.Addon.aws_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "aws_s3",
            support_region: true
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.Backup.Addon.azure_blob.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "azure_blob",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud";
        this.transfer_type = "azure_blob";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "server",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "provider"),
            store: new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name"), "azure_blob"],
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name_cn"), "azure_cn_blob"]
                ]
            }),
            value: "azure_blob",
            displayField: "server",
            valueField: "value",
            editable: false,
            listeners: {
                select: function(d, b, c) {
                    this.transfer_type = b.get("value")
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "storage_account"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "access_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "bktselect",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.target_type = "cloud"
        }
        if ("image" === b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle("cloud" === this.target_type);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            key: b("accesskey"),
            secret: b("secretkey"),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("azure", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "key,secret,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.Backup.Addon.Util.getString(this.addon_id, "load_containers")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    testConnection: function() {
        var a = this.getListBucketRequest();
        this.owner.setStatusBusy({
            text: _T("netbackup", "netbkp_connection_testing")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(e, b, c) {
                var d = this.getForm();
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.reportError(b);
                    return
                }
                this.owner.setSingle(true);
                this.owner.goNext(this.nextId);
                d.setValues(d.setValues())
            }
        })
    }
});
Ext.ns("SYNO.Backup.Addon.dropbox.Restore");
Ext.define("SYNO.Backup.Addon.dropbox.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "dropbox",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "dropbox";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "container",
            fieldLabel: SYNO.SDS.Backup.String("dropbox", "root_folder_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"],
                sortInfo: {
                    field: "value",
                    direction: "ASC"
                }
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainers()) {
                    this.scope.loadContainers()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectContainer,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectContainer: function(a) {
        this.loadTarget(a.getValue())
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["remote_access_token"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            target_id: b("target"),
            container: b("container"),
            remote_access_token: this.access_token,
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("dropbox", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.container + " / " + b.target_id)
    },
    getListContainerRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "target_type,transfer_type,remote_access_token,container");
        return a
    },
    needReloadContainers: function() {
        var a = this.getListContainerRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadContainers: function() {
        var a = this.getListContainerRequest();
        if (!a.remote_access_token) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("dropbox", "load_root_folders")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Dropbox.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["remote_access_token"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadContainerData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadContainerData(b)
            }
        })
    },
    loadContainerData: function(b) {
        var a = this.getForm().findField("container");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.container_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(a) {
        var b = this.getLoadTargetParams();
        if (!b.container) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(b)) {
            return
        }
        this.lastQueryTarget = Ext.encode(b);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: b,
            encryption: ["remote_access_token"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(b);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token
    }
});
Ext.ns("SYNO.Backup.Addon.google_drive.Restore");
Ext.define("SYNO.Backup.Addon.google_drive.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "google_drive",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "google_drive";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "container",
            fieldLabel: SYNO.SDS.Backup.String("google_drive", "root_folder_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainers()) {
                    this.scope.loadContainers()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectContainer,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectContainer: function(a) {
        this.loadTarget(a.getValue())
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["remote_access_token", "remote_refresh_token"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            target_id: b("target"),
            container: b("container"),
            remote_access_token: this.access_token,
            remote_refresh_token: this.refresh_token,
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("google_drive", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.container + " / " + b.target_id)
    },
    getListContainerRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "target_type,transfer_type,remote_access_token,remote_refresh_token,container");
        return a
    },
    needReloadContainers: function() {
        var a = this.getListContainerRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadContainers: function() {
        var a = this.getListContainerRequest();
        if (!a.remote_access_token || !a.remote_refresh_token) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("google_drive", "load_root_folders")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.GoogleDrive.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["remote_access_token", "remote_refresh_token"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadContainerData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadContainerData(b)
            }
        })
    },
    loadContainerData: function(b) {
        var a = this.getForm().findField("container");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.container_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(a) {
        var b = this.getLoadTargetParams();
        if (!b.container) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(b)) {
            return
        }
        this.lastQueryTarget = Ext.encode(b);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: b,
            encryption: ["remote_access_token", "remote_refresh_token"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(b);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token;
        this.refresh_token = a.refresh_token
    }
});
Ext.define("SYNO.Backup.Addon.hicloud_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_hicloud",
            transfer_type: "hicloud_s3"
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.Backup.Addon.jdcloud_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_jdcloud",
            transfer_type: "jdcloud_s3"
        }, a);
        return this.callParent([b])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            name: "region",
            width: this.comboboxWidth,
            allowBlank: false,
            store: this.getRegionStore(),
            fieldLabel: _T("backup", "s3_server_region"),
            displayField: "region",
            valueField: "value",
            value: "cn-north-1",
            editable: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_access_key"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: _T("backup", "s3_secret_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            name: "bktselect",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            maxlength: this.S3_BUCKET_LENGTH,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            width: this.comboboxWidth,
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["region", "value"],
                data: [
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_north_1"), "cn-north-1"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_east_1"), "cn-east-1"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_east_2"), "cn-east-2"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_south_1"), "cn-south-1"]
                ]
            })
        }
        return this.regionStore
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = {
            region_system: b("region"),
            key: b("accesskey"),
            secret: b("secretkey"),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            addon_id: this.addon_id
        };
        c.transfer_type = this.transfer_type;
        c.support_region = true;
        c.request_style = "virtual_host_style";
        return c
    }
});
Ext.define("SYNO.Backup.Addon.hidrive.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "hidrive",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "hidrive";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            name: "dest",
            value: "rsync.hidrive.strato.com",
            editable: false,
            hidden: true
        }, {
            xtype: "syno_checkbox",
            name: "encrypt_connect",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            checked: true,
            editable: false,
            hidden: true
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "username"),
            name: "account",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            name: "pwd",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "module",
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "root_folder_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["pwd"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            dest: b("dest"),
            encrypt_connect: b("encrypt_connect"),
            account: b("account"),
            pwd: b("pwd"),
            module: "/users/" + b("account") + "/" + b("module"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("hidrive", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.module + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "dest,encrypt_connect,account,pwd,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.account || !a.pwd) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("hidrive", "load_root_folders")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.HiDrive.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["pwd"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("module");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.account || !a.pwd || !a.module) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.hubic.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "hubic_swift",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "hubic_swift";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "container",
            fieldLabel: SYNO.SDS.Backup.String("hubic", "container"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainers()) {
                    this.scope.loadContainers()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectContainer,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onSelectContainer: function(a) {
        this.loadTarget(a.getValue())
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["remote_refresh_token"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            target_id: b("target"),
            container: b("container"),
            remote_refresh_token: this.refresh_token,
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("hubic", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.container + " / " + b.target_id)
    },
    getListContainerRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "target_type,transfer_type,remote_refresh_token,container");
        return a
    },
    needReloadContainers: function() {
        var a = this.getListContainerRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadContainers: function() {
        var a = this.getListContainerRequest();
        if (!a.remote_refresh_token) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("hubic", "load_containers")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.hubiC.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["remote_refresh_token"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadContainerData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadContainerData(b)
            }
        })
    },
    loadContainerData: function(b) {
        var a = this.getForm().findField("container");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.container_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(a) {
        var b = this.getLoadTargetParams();
        if (!b.container) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(b)) {
            return
        }
        this.lastQueryTarget = Ext.encode(b);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: b,
            encryption: ["remote_refresh_token"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(b);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    setOauthResponse: function(a) {
        this.refresh_token = a.refresh_token
    }
});
Ext.define("SYNO.Backup.Addon.ibm_softlayer.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "ibm_softlayer_swift",
    target_type: "cloud_image",
    transfer_type: "ibm_softlayer_swift",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            name: "region_ibm",
            width: this.comboboxWidth,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: SYNO.SDS.Backup.Addon.Util.Image.OpenStack.ibm_softlayer_region_list(),
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            }),
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            displayField: "display",
            valueField: "value",
            editable: false
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "bktselect",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getRemoteUrlValue: function() {
        return ""
    },
    getRegionValue: function() {
        var a = this.getForm().getFieldValues();
        return a.region_ibm
    },
    getUsernameValue: function() {
        var a = this.getForm().getFieldValues();
        return a.accesskey
    },
    getSecretValue: function() {
        var a = this.getForm().getFieldValues();
        return a.secretkey
    },
    getTenantId: function() {
        return ""
    },
    getTenantName: function() {
        return ""
    },
    getDomainId: function() {
        return ""
    },
    getDomainName: function() {
        return ""
    },
    getAuthVersion: function() {
        return ""
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            key: this.getUsernameValue(),
            secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("ibm_softlayer", "repo_type_name"));
        a.append(_T("netbackup", "netbkp_slct_server"), SYNO.Backup.Addon.Util.getString(b.transfer_type, "name"));
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,region,key,secret,tenant_id,tenant_name,domain_id,domain_name,auth_version,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("openstack", "load_containers")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.legacy_hicloud_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            provider: "hicloud",
            addon_id: "hicloud_s3"
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.Backup.Addon.legacy_sfr_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            provider: "sfr",
            addon_id: "sfr_s3"
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.Backup.Addon.local.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    constructor: function(b) {
        Ext.copyTo(this, b, "owner");
        this.setDefault();
        var a = [];
        this.addLocalBackupFields(a);
        this.callParent([Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    setDefault: function() {
        this.target_type = "image";
        this.transfer_type = "image_local";
        this.repo_path = ""
    },
    addLocalBackupFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "local_restore_rcvr_folder"),
            name: "share",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            displayField: "value",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            width: this.comboboxWidth,
            listeners: {
                scope: this,
                select: this.onShareSelect
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            emptyText: SYNO.SDS.Backup.String("app", "no_target_available"),
            name: "local_target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            width: this.comboboxWidth,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    onShareSelect: function(c, a, b) {
        this.loadLocalTarget(c.getValue())
    },
    getOption: function() {
        return this.target_type
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.setDefault();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: Ext.apply(this.getParams(), {
                additional: ["repo_path"]
            }),
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "image";
            this.transfer_type = "image_local"
        } else {
            this.target_type = "share";
            this.transfer_type = "local"
        }
        if ("cloud_image" === b.format_type) {
            this.transfer_type = "browse_local";
            this.repo_path = b.repo_path
        }
        this.owner.setSingle("share" === this.target_type);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = {
            target_type: this.target_type,
            transfer_type: this.transfer_type,
            share: b("share"),
            target_id: b("local_target")
        };
        if ("browse_local" === this.transfer_type) {
            Ext.apply(c, {
                abs_path: this.repo_path
            })
        }
        return c
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("local", "repo_type_name_2"));
        a.append(_T("backup", "backup_restore_source"), b.share + " / " + b.target_id)
    },
    loadData: function(b) {
        var a;
        if (this.loadShareData(b.result[0].result_list[0])) {
            a = a || "share"
        }
        if (a) {
            this.getForm().setValues({
                target_type: a
            });
            return true
        } else {
            return false
        }
    },
    loadShareData: function(c) {
        var a = this.getForm().findField("share");
        var b = this.getForm().findField("local_target");
        SYNO.SDS.Backup.Util.comboboxLoadData(a, c.share_list);
        SYNO.Backup.Util.HBKDisplayComboboxLoadData(b, c.target_list, "target_id");
        if (c.share_list && c.share_list.length > 0) {
            b.lastSelectShare = c.share_list[0];
            return true
        } else {
            return false
        }
    },
    loadLocalTarget: function(a) {
        if (this.lastSelectedShare === a) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            params: {
                target_type: "image",
                transfer_type: "image_local",
                share: a
            },
            version: 1,
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.api.alert(c);
                    return
                }
                this.lastSelectShare = a;
                this.loadLocalTargetData(c)
            },
            scope: this
        })
    },
    loadLocalTargetData: function(b) {
        var a = this.getForm().findField("local_target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.openstack.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "openstack_swift",
    target_type: "cloud_image",
    transfer_type: "openstack_swift",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            name: "remote_url",
            width: this.comboboxWidth,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "url")
        }, {
            xtype: "syno_combobox",
            name: "auth_version",
            width: this.comboboxWidth,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["1.0", "1.0"],
                    ["2.0", "2.0"],
                    ["3.0", "3.0"]
                ]
            }),
            fieldLabel: SYNO.SDS.Backup.String("openstack", "identity_service_version"),
            displayField: "version",
            valueField: "value",
            value: "1.0",
            editable: false,
            listeners: {
                select: function(d, b, c) {
                    this.changeVersionLayout(b.get("value"));
                    this.doLayout()
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            name: "secretkey_pw",
            width: this.comboboxWidth,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            name: "tenant_compositefield",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "tenant"),
            items: [{
                xtype: "syno_combobox",
                name: "tenant_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "tenant_id"],
                        ["name", "tenant_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "tenant_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: "tenant_value",
                width: this.comboboxWidth - 80 - 6,
                allowBlank: true
            }],
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            name: "domain_compositefield",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "domain"),
            items: [{
                xtype: "syno_combobox",
                name: "domain_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "domain_id"],
                        ["name", "domain_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "domain_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: "domain_value",
                width: this.comboboxWidth - 80 - 6,
                allowBlank: false
            }],
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            name: "region_cust",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            store: this.getRegionStore(),
            displayField: "display",
            allowBlank: false,
            valueField: "value",
            editable: false,
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadRegion()) {
                    this.scope.loadRegionStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "bktselect",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    changeVersionLayout: function(d) {
        var c = this.getForm();
        var a = function(f, e) {
            c.findField(f).setDisabled(!e);
            c.findField(f).setVisible(e)
        };
        var b = function(f, h, g, i, e) {
            a("secretkey", f);
            a("secretkey_pw", h);
            a("tenant_compositefield", g);
            a("domain_compositefield", i);
            a("region_cust", e)
        };
        if ("1.0" === d) {
            b(true, false, false, false, false)
        } else {
            if ("2.0" === d) {
                b(false, true, true, false, true)
            } else {
                if ("3.0" === d) {
                    b(false, true, true, true, true)
                } else {
                    return
                }
            }
        }
    },
    getRemoteUrlValue: function() {
        var a = this.getForm().getFieldValues();
        var b = a.remote_url.trim();
        if (b.substring(0, 7) !== "http://" && b.substring(0, 8) !== "https://") {
            return "https://" + b
        }
        return b
    },
    getRegionValue: function() {
        var a = this.getForm().getFieldValues();
        if ("2.0" === a.auth_version || "3.0" === a.auth_version) {
            return a.region_cust
        }
        return ""
    },
    getUsernameValue: function() {
        var a = this.getForm().getFieldValues();
        return a.accesskey
    },
    getSecretValue: function() {
        var a = this.getForm().getFieldValues();
        if ("2.0" === a.auth_version || "3.0" === a.auth_version) {
            return a.secretkey_pw
        }
        return a.secretkey
    },
    getTenantId: function() {
        var a = this.getForm().getFieldValues();
        var b = this.getForm(),
            c = function(d) {
                return b.findField(d).getValue()
            };
        if (("2.0" === a.auth_version || "3.0" === a.auth_version) && "tenant_id" === c("tenant_option")) {
            return c("tenant_value")
        }
        return ""
    },
    getTenantName: function() {
        var a = this.getForm().getFieldValues();
        var b = this.getForm(),
            c = function(d) {
                return b.findField(d).getValue()
            };
        if (("2.0" === a.auth_version || "3.0" === a.auth_version) && "tenant_name" === c("tenant_option")) {
            return c("tenant_value")
        }
        return ""
    },
    getDomainId: function() {
        var a = this.getForm().getFieldValues();
        var b = this.getForm(),
            c = function(d) {
                return b.findField(d).getValue()
            };
        if ("3.0" === a.auth_version && "domain_id" === c("domain_option")) {
            return c("domain_value")
        }
        return ""
    },
    getDomainName: function() {
        var a = this.getForm().getFieldValues();
        var b = this.getForm(),
            c = function(d) {
                return b.findField(d).getValue()
            };
        if ("3.0" === a.auth_version && "domain_name" === c("domain_option")) {
            return c("domain_value")
        }
        return ""
    },
    getAuthVersion: function() {
        var a = this.getForm().getFieldValues();
        return a.auth_version
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            key: this.getUsernameValue(),
            secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("openstack", "repo_type_name"));
        a.append(_T("netbackup", "netbkp_slct_server"), b.remote_url);
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["value", "display"],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            })
        }
        return this.regionStore
    },
    getLoadRegionParams: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,key,secret,tenant_id,tenant_name,domain_id,domain_name,auth_version,transfer_type");
        return a
    },
    needReloadRegion: function() {
        var a = this.getLoadRegionParams();
        return this.lastRegionQuery !== Ext.encode(a)
    },
    loadRegionStore: function() {
        var a = this.getLoadRegionParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Region",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(e, b, c) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.reportError(b);
                    return
                }
                this.lastRegionQuery = Ext.encode(a);
                this.getRegionStore().loadData(SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping(b.region_list));
                var d = this.getForm().findField("region_cust");
                d.el.focus();
                d.expand();
                d.restrictHeight()
            }
        })
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,region,key,secret,tenant_id,tenant_name,domain_id,domain_name,auth_version,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("openstack", "load_containers")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.rackspace.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "rackspace_swift",
    target_type: "cloud_image",
    transfer_type: "rackspace_swift",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username"),
            name: "accesskey",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key"),
            name: "secretkey",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            name: "region_cust",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            store: this.getRegionStore(),
            displayField: "display",
            allowBlank: false,
            valueField: "value",
            editable: false,
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadRegion()) {
                    this.scope.loadRegionStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            }
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "bktselect",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getRemoteUrlValue: function() {
        return ""
    },
    getRegionValue: function() {
        var a = this.getForm().getFieldValues();
        return a.region_cust
    },
    getUsernameValue: function() {
        var a = this.getForm().getFieldValues();
        return a.accesskey
    },
    getSecretValue: function() {
        var a = this.getForm().getFieldValues();
        return a.secretkey
    },
    getTenantId: function() {
        return ""
    },
    getTenantName: function() {
        return ""
    },
    getDomainId: function() {
        return ""
    },
    getDomainName: function() {
        return ""
    },
    getAuthVersion: function() {
        return ""
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            key: this.getUsernameValue(),
            secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            bucket: b("bktselect"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("rackspace", "repo_type_name"));
        a.append(_T("netbackup", "netbkp_slct_server"), SYNO.Backup.Addon.Util.getString(b.transfer_type, "name"));
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["value", "display"],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            })
        }
        return this.regionStore
    },
    getLoadRegionParams: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,key,secret,tenant_id,tenant_name,domain_id,domain_name,auth_version,transfer_type");
        return a
    },
    needReloadRegion: function() {
        var a = this.getLoadRegionParams();
        return this.lastRegionQuery !== Ext.encode(a)
    },
    loadRegionStore: function() {
        var a = this.getLoadRegionParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Region",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(e, b, c) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.reportError(b);
                    return
                }
                this.lastRegionQuery = Ext.encode(a);
                this.getRegionStore().loadData(SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping(b.region_list));
                var d = this.getForm().findField("region_cust");
                d.el.focus();
                d.expand();
                d.restrictHeight()
            }
        })
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,region,key,secret,tenant_id,tenant_name,domain_id,domain_name,auth_version,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.key || !a.secret) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("openstack", "load_containers")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["secret"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bktselect");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.key || !a.secret || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.define("SYNO.Backup.Addon.remote.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        this.repoType = "share";
        this.fieldLabelWidth = 300;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: this.fieldLabelWidth
                },
                items: [new SYNO.SDS.Backup.HostCombobox({
                    name: "server",
                    width: this.comboboxWidth,
                    owner: this.owner
                }), {
                    xtype: "syno_combobox",
                    name: "sslcheck",
                    width: this.comboboxWidth,
                    fieldLabel: SYNO.SDS.Backup.String("remote", "transfer_encryption"),
                    allowBlank: false,
                    store: new Ext.data.ArrayStore({
                        fields: ["text", "value"],
                        data: [
                            [SYNO.SDS.Backup.String("app", "on"), true],
                            [SYNO.SDS.Backup.String("app", "off"), false]
                        ]
                    }),
                    displayField: "text",
                    valueField: "value",
                    editable: false,
                    value: false
                }, {
                    xtype: "syno_numberfield",
                    width: this.comboboxWidth,
                    maxlength: 5,
                    vtype: "port",
                    name: "port",
                    value: 6281,
                    allowBlank: false,
                    fieldLabel: _T("common", "port")
                }, {
                    xtype: "syno_displayfield",
                    name: "account",
                    hidden: true
                }, {
                    xtype: "syno_displayfield",
                    name: "password",
                    hidden: true
                }, {
                    xtype: "syno_displayfield",
                    name: "is_webapi_authen",
                    value: "false",
                    hidden: true
                }, {
                    xtype: "syno_compositefield",
                    fieldLabel: SYNO.SDS.Backup.String("app", "authenticate"),
                    width: this.comboboxWidth,
                    items: [{
                        xtype: "syno_displayfield",
                        name: "account_display_name"
                    }, {
                        xtype: "syno_button",
                        name: "account_authen",
                        text: SYNO.SDS.Backup.String("app", "login"),
                        itemId: "authenticate_button",
                        handler: this.onAuthenBtnClick,
                        scope: this
                    }]
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _T("netbackup", "restore_share_folder"),
                    name: "share",
                    forceSelection: true,
                    editable: false,
                    allowBlank: false,
                    store: new Ext.data.ArrayStore({
                        fields: ["value"]
                    }),
                    displayField: "value",
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: this.comboboxWidth,
                    onTriggerClick: function() {
                        if (this.readOnly || this.disabled) {
                            return
                        }
                        if (this.scope.needReloadShare()) {
                            this.scope.loadShare()
                        } else {
                            SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                        }
                    },
                    listeners: {
                        scope: this,
                        select: this.onShareSelect
                    },
                    scope: this,
                    tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _T("backup", "backup_dest_directory"),
                    name: "network_target",
                    forceSelection: true,
                    editable: false,
                    allowBlank: false,
                    store: new Ext.data.ArrayStore({
                        fields: ["display", "value"]
                    }),
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: this.comboboxWidth,
                    onTriggerClick: function() {
                        if (this.readOnly || this.disabled) {
                            return
                        }
                        if (this.scope.needReloadTarget()) {
                            this.scope.loadTarget()
                        } else {
                            SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                        }
                    },
                    scope: this,
                    tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
                }]
            }]
        }, a);
        return b
    },
    authenCB: function(a) {
        if (!("code" in a)) {
            this.getForm().findField("account").setValue(a.username);
            SYNO.Backup.Util.DisplayAccount(this.getForm().findField("account_display_name"), a.username, 15);
            this.getForm().findField("password").setValue(a.id);
            this.getForm().findField("is_webapi_authen").setValue(true);
            this.doLayout()
        }
        this.owner.clearStatusBusy()
    },
    onAuthenBtnClick: function() {
        var a = this.getForm().findField("server");
        if (!a.isValid()) {
            a.markInvalid(_T("netbackup", "netbkp_err_host_str"));
            return
        }
        this.owner.setStatusBusy();
        var b = this.getParams();
        b.ip = a.getValue();
        b.port = this.getForm().findField("port").getValue();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.LoginPort",
            version: 1,
            method: "get",
            params: b,
            scope: this,
            callback: function(g, c, e) {
                if (!g) {
                    if (c.code == SYNO.SDS.Backup.ERR_NO_RESPONSE) {
                        c.code = SYNO.SDS.Backup.ERR_SERVICE_DISABLE
                    }
                    this.owner.reportError(c);
                    this.owner.clearStatusBusy();
                    return false
                }
                var d = "";
                var f = false;
                if (c.port > 0) {
                    d = "https://" + b.ip + ":" + c.port
                } else {
                    f = true
                }
                this.owner.clearStatusBusy();
                synocredential.Issue({
                    url: d,
                    forceLegacyMode: f,
                    mustHaveCredential: true,
                    session: "HyperBackupVault",
                    appWin: this.owner,
                    callback: this.authenCB.bind(this),
                    redirect_uri: window.location.origin
                })
            }
        })
    },
    getHostParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = {
            dest: a.findField("server").getHostAddress(),
            port: b("port"),
            account: b("account"),
            pwd: b("password"),
            is_webapi_authen: b("is_webapi_authen"),
            target_type: this.target_type,
            transfer_type: this.transfer_type,
            sslcheck: b("sslcheck")
        };
        return c
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.getHostParams();
        Ext.apply(c, {
            share: b("share"),
            target_id: b("network_target")
        });
        if ("rsync_ds" === c.transfer_type) {
            if (c.sslcheck) {
                c.encrypt_connect = true
            } else {
                c.encrypt_connect = false
            }
            c.port = 0;
            delete c.sslcheck
        }
        if ("volume" === this.repoType) {
            c.volume = b("share");
            delete c.share
        }
        return c
    },
    needReloadShare: function() {
        var a = this.getHostParams();
        return this.lastShareParams !== Ext.encode(a)
    },
    needReloadTarget: function() {
        var a = this.getParams();
        delete a.target_id;
        return this.lastTargetParams !== Ext.encode(a)
    },
    loadShare: function() {
        var a = this.getHostParams();
        Ext.apply(a, {
            connect_list: [{
                target_type: a.target_type,
                transfer_type: a.transfer_type,
                port: a.port
            }],
            additional: ["support_ssl"]
        });
        if (!a.account || !a.dest || Ext.isEmpty(a.port, false)) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("netbackup", "netbkp_wait_server")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Repository",
            method: "find",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.api.alert(c);
                    return
                }
                if (0 === c.result_list[0].share_list.length && 0 === c.result_list[0].volume_list.length) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "dest_no_repo"));
                    return
                }
                if (!c.result_list[0].support_ssl) {
                    this.getForm().findField("sslcheck").setValue(false)
                }
                this.lastShareParams = Ext.encode(this.getHostParams());
                this.loadShareData(c.result_list[0])
            },
            scope: this
        })
    },
    loadTarget: function() {
        var a = this.getParams();
        delete a.target_id;
        if (!a.account || !a.dest || Ext.isEmpty(a.port, false) || (!a.share && !a.volume)) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.removeTargetData();
                    this.owner.api.alert(c);
                    delete this.lastTargetParams;
                    return
                }
                this.lastTargetParams = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    onShareSelect: function() {
        if (this.needReloadTarget()) {
            this.loadTarget()
        }
    },
    loadShareData: function(a) {
        var b = this.getForm().findField("share");
        var c = this.getForm().findField("network_target");
        if (a.share_list && a.share_list.length > 0) {
            this.repoType = "share";
            SYNO.SDS.Backup.Util.comboboxLoadData(b, a.share_list)
        } else {
            if (a.volume_list && a.volume_list.length > 0) {
                this.repoType = "volume";
                SYNO.SDS.Backup.Util.comboboxLoadData(b, a.volume_list)
            } else {
                SYNO.SDS.Backup.Util.comboboxLoadData(b, []);
                SYNO.SDS.Backup.Util.comboboxLoadData(c, []);
                if (a.code) {
                    this.owner.api.alert(SYNO.SDS.Backup.GetErrorString(a.code))
                } else {
                    this.owner.api.alert(_T("netbackup", "err_no_share"))
                }
            }
        }
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("network_target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    removeTargetData: function() {
        var a = this.getForm().findField("network_target");
        a.getStore().removeAll();
        a.setValue("")
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["pwd"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if ("cloud_image" === b.format_type) {
            this.transfer_type = "rsync_ds";
            this.target_type = "cloud_image"
        } else {
            if ("single" === b.format_type) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
                this.owner.clearStatusBusy();
                return false
            }
        }
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
    },
    launchPasswordWindow: function(a) {
        var d = Ext.apply(this.getParams(), {
            uni_key: this.owner.uni_key
        });
        var b = function(e) {
            this.owner.sess_id = e.sess_id;
            this.owner.sess_key = e.sess_key
        };
        var c = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: d,
            setter: Ext.createDelegate(b, this),
            callback: Ext.createDelegate(a, this)
        });
        c.open()
    },
    summary: function(a) {
        var b = this.getParams();
        if ("rsync_ds" === b.transfer_type) {
            a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("rsync", "repo_type_name_2"));
            a.append(_T("netbackup", "netbkp_slct_server"), String.format(SYNO.SDS.Backup.String("rsync", "synology_rsync_server"), _D("company_title")))
        } else {
            a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("remote", "repo_type_name_2"));
            a.append(_T("netbackup", "netbkp_slct_server"), String.format(_T("netbackup", "synology_server"), _D("company_title")))
        }
        a.append(_T("backup", "backup_server_name"), b.dest);
        if ("rsync_ds" !== b.transfer_type) {
            a.append(_T("common", "port"), b.port)
        }
        a.append(_T("netbackup", "netbkp_account"), b.account);
        if (b.share) {
            a.append(_T("backup", "backup_restore_source"), b.share + " / " + b.target_id)
        } else {
            a.append(_T("backup", "backup_restore_source"), b.volume.substring(1) + " / " + b.target_id)
        }
    }
});
Ext.define("SYNO.Backup.Addon.rsync.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    constructor: function(b) {
        this.transfer_type = "rsync_ds";
        this.target_type = "cloud_image";
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.fieldLabelWidth = 300;
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: this.fieldLabelWidth
                },
                items: a
            }]
        }, b)]);
        this.mon(this, "activate", function() {
            var c = this.getForm().findField("network_type");
            c.setValue("rsync_ds")
        }, this, {
            single: true
        })
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "network_type",
            fieldLabel: _T("netbackup", "netbkp_slct_server"),
            allowBlank: false,
            store: this.getServerStore(),
            displayField: "server",
            valueField: "value",
            value: "rsync_ds",
            editable: false,
            listeners: {
                scope: this,
                select: function(c, b, d) {
                    this.changeLayout(b.get("value"))
                }
            }
        }, new SYNO.SDS.Backup.HostCombobox({
            width: this.comboboxWidth,
            name: "server",
            owner: this.owner
        }), {
            xtype: "syno_combobox",
            name: "encrypt_connect",
            width: this.comboboxWidth,
            fieldLabel: SYNO.SDS.Backup.String("rsync", "transfer_encryption"),
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["text", "value"],
                data: [
                    [SYNO.SDS.Backup.String("app", "on"), true],
                    [SYNO.SDS.Backup.String("app", "off"), false]
                ]
            }),
            displayField: "text",
            valueField: "value",
            editable: false,
            value: false,
            listeners: {
                scope: this,
                select: function(c, b, d) {
                    this.changeEncTransLayout(b.get("value"))
                }
            }
        }, {
            xtype: "syno_numberfield",
            width: this.comboboxWidth,
            maxlength: 5,
            vtype: "port",
            name: "port",
            value: 873,
            allowBlank: false,
            fieldLabel: _T("common", "port")
        }, {
            xtype: "syno_numberfield",
            width: this.comboboxWidth,
            maxlength: 5,
            vtype: "port",
            name: "enc_port",
            value: 22,
            allowBlank: false,
            fieldLabel: _T("common", "port"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_textfield",
            width: this.comboboxWidth,
            fieldLabel: _T("netbackup", "netbkp_account"),
            name: "account",
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            width: this.comboboxWidth,
            fieldLabel: _T("common", "password"),
            name: "password",
            allowBlank: true,
            inputType: "password"
        }, new SYNO.SDS.Backup.ComboBox({
            owner: this.owner,
            width: this.comboboxWidth,
            fieldLabel: _T("netbackup", "restore_share_folder"),
            name: "share",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            busyText: _T("netbackup", "netbkp_search_folder"),
            store: this.getShareModuleStore("share"),
            displayField: "value",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            getParams: {
                handler: this.getLoadShareParams,
                scope: this
            },
            listeners: {
                select: this.loadShareTarget,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }), {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            width: this.comboboxWidth,
            name: "network_target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadShareTarget()) {
                    this.scope.loadShareTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        }, new SYNO.SDS.Backup.ComboBox({
            owner: this.owner,
            name: "module",
            fieldLabel: _T("netbackup", "netbkp_module"),
            width: this.comboboxWidth,
            busyText: _T("netbackup", "rsync_get_module_mask"),
            store: this.getShareModuleStore("module"),
            valueField: "value",
            displayField: "value",
            editable: true,
            triggerAction: "all",
            mode: "local",
            hidden: true,
            disabled: true,
            getParams: {
                handler: this.getListModuleParams,
                scope: this
            },
            listeners: {
                select: this.loadTarget,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }), {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "backup_dest_directory"),
            width: this.comboboxWidth,
            name: "rsync_target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            hidden: true,
            disabled: true,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getServerStore: function() {
        if (!this.serverStore) {
            this.serverStore = new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [String.format(SYNO.SDS.Backup.String("rsync", "synology_rsync_server"), _D("company_title")), "rsync_ds"],
                    [_T("netbackup", "rsync_compatible_server"), "rsync"]
                ]
            })
        }
        return this.serverStore
    },
    changeLayout: function(d) {
        var c = this.getForm();
        var a = function(f, e) {
            c.findField(f).setDisabled(!e);
            c.findField(f).setVisible(e)
        };
        var b = function(h, e, f, g) {
            a("share", h);
            a("network_target", e);
            a("module", f);
            a("rsync_target", g)
        };
        if ("rsync_ds" === d) {
            b(true, true, false, false)
        } else {
            if ("rsync" === d) {
                b(false, false, true, true)
            }
        }
    },
    changeEncTransLayout: function(d) {
        var c = this.getForm();
        var a = function(f, e) {
            c.findField(f).setDisabled(!e);
            c.findField(f).setVisible(e)
        };
        var b = function(e, f) {
            a("port", e);
            a("enc_port", f)
        };
        if (d) {
            b(false, true)
        } else {
            b(true, false)
        }
    },
    getLoadNextParam: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.getHostParams();
        c.transfer_type = b("network_type");
        c.target_type = "cloud_image";
        if ("rsync_ds" === c.transfer_type) {
            c.module = b("share");
            c.target_id = b("network_target")
        } else {
            c.module = b("module");
            c.target_id = b("rsync_target")
        }
        return c
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getLoadNextParam(),
            encryption: ["pwd"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.api.alert(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image";
            this.owner.setSingle(false)
        } else {
            this.target_type = "share";
            this.owner.setSingle(true)
        }
        this.transfer_type = this.getForm().findField("network_type").getValue();
        if ("image" === b.format_type) {
            if ("rsync_ds" === this.transfer_type) {
                this.transfer_type = "image_remote";
                this.target_type = "image"
            } else {
                this.owner.api.alert(SYNO.SDS.Backup.String("error", "restore_not_match_target_type"));
                this.owner.clearStatusBusy();
                return false
            }
        }
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            c = function(d) {
                return a.findField(d).getValue()
            };
        var b = this.getHostParams();
        b.transfer_type = this.transfer_type;
        b.target_type = this.target_type;
        if ("rsync_ds" === c("network_type")) {
            b.module = c("share");
            b.target_id = c("network_target");
            if ("image_remote" === b.transfer_type) {
                if (Ext.isDefined(b.encrypt_connect)) {
                    b.sslcheck = b.encrypt_connect;
                    delete b.encrypt_connect
                }
                if (Ext.isDefined(b.port)) {
                    b.port = 6281
                } else {
                    if (Ext.isDefined(b.enc_port)) {
                        b.port = 6281;
                        delete b.enc_port
                    }
                }
            }
        } else {
            b.module = c("module");
            b.target_id = c("rsync_target")
        }
        return b
    },
    summary: function(a) {
        var b = this.owner.getParams();
        if ("image_remote" === b.transfer_type) {
            a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("remote", "repo_type_name_2"));
            a.append(_T("netbackup", "netbkp_slct_server"), String.format(_T("netbackup", "synology_server"), _D("company_title")))
        } else {
            a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("rsync", "repo_type_name_2"));
            if ("rsync_ds" === b.transfer_type) {
                a.append(_T("netbackup", "netbkp_slct_server"), String.format(SYNO.SDS.Backup.String("rsync", "synology_rsync_server"), _D("company_title")))
            } else {
                a.append(_T("netbackup", "netbkp_slct_server"), _T("netbackup", "rsync_compatible_server"))
            }
        }
        a.append(_T("backup", "backup_server_name"), b.dest);
        a.append(_T("common", "port"), b.port ? b.port : b.enc_port);
        a.append(_T("netbackup", "netbkp_account"), b.account);
        a.append(_T("backup", "backup_restore_source"), b.module + " / " + b.target_id)
    },
    getHostParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = {};
        c.dest = a.findField("server").getHostAddress();
        c.account = b("account");
        c.pwd = b("password");
        c.encrypt_connect = b("encrypt_connect");
        if (c.encrypt_connect) {
            c.enc_port = b("enc_port")
        } else {
            c.port = b("port")
        }
        return c
    },
    getLoadShareParams: function() {
        var a = this.getHostParams();
        var c = Ext.copyTo({}, a, "dest,account,pwd");
        var b = {
            target_type: "share",
            transfer_type: "rsync_ds"
        };
        Ext.copyTo(b, a, "encrypt_connect,port,enc_port");
        c = Ext.apply({
            connect_list: [b]
        }, c);
        return c
    },
    getListModuleParams: function() {
        var a = this.getHostParams();
        var c = Ext.copyTo({}, a, "dest,account,pwd");
        var b = {
            target_type: "share",
            transfer_type: "rsync"
        };
        Ext.copyTo(b, a, "encrypt_connect,port,enc_port");
        c = Ext.apply({
            connect_list: [b]
        }, c);
        return c
    },
    getShareModuleStore: function(a) {
        return new SYNO.API.Store({
            api: "SYNO.Backup.Repository",
            method: "find",
            version: 1,
            encryption: ["pwd"],
            appWindow: this.owner.findAppWindow() || false,
            autoLoad: false,
            autoDestroy: true,
            comboBoxId: a,
            reader: new Ext.data.JsonReader({
                root: "result_list[0].share_list",
                fields: [{
                    name: "value",
                    convert: function(c, b) {
                        return b
                    }
                }]
            }),
            listeners: {
                beforeload: function(b, c) {
                    var d = this.getHostParams();
                    if (!d.account || !d.dest || !Ext.isDefined(d.encrypt_connect) || (Ext.isEmpty(d.port, false) && Ext.isEmpty(d.enc_port, false))) {
                        return false
                    }
                    this.getForm().findField(b.comboBoxId).clearValue()
                },
                load: function(c, b, d) {
                    var e = this.getForm().findField(c.comboBoxId);
                    if (0 === b.length) {
                        e.emptyText = _T("netbackup", "netbkp_no_folder");
                        e.applyEmptyText();
                        e.setValue("")
                    } else {
                        e.emptyText = " ";
                        e.applyEmptyText()
                    }
                },
                scope: this
            }
        })
    },
    getLoadTargetParam: function() {
        var a = this.getHostParams();
        a.transfer_type = "rsync";
        a.target_type = "cloud_image";
        a.module = this.getForm().findField("module").getValue();
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParam();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function() {
        var a = this.getLoadTargetParam();
        if (!a.account || !a.dest || !Ext.isDefined(a.encrypt_connect) || (Ext.isEmpty(a.port, false) && Ext.isEmpty(a.enc_port, false)) || !a.module) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadTargetData([], "rsync_target");
                    this.owner.api.alert(c);
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c, "rsync_target")
            },
            scope: this
        })
    },
    loadTargetData: function(c, b) {
        var a = this.getForm().findField(b);
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, c.target_list, "target_id")
    },
    getLoadShareTargetParams: function() {
        var a = this.getHostParams();
        a.transfer_type = "rsync_ds";
        a.target_type = "cloud_image";
        a.module = this.getForm().findField("share").getValue();
        return a
    },
    needReloadShareTarget: function() {
        var a = this.getLoadShareTargetParams();
        return this.lastSelectedShare !== Ext.encode(a)
    },
    loadShareTarget: function() {
        var a = this.getLoadShareTargetParams();
        if (!a.account || !a.dest || !Ext.isDefined(a.encrypt_connect) || (Ext.isEmpty(a.port, false) && Ext.isEmpty(a.enc_port, false)) || !a.module) {
            return
        }
        if (this.lastSelectedShare === Ext.encode(a)) {
            return
        }
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadTargetData([], "network_target");
                    this.owner.api.alert(c);
                    delete this.lastSelectedShare;
                    return
                }
                this.lastSelectedShare = Ext.encode(a);
                this.loadTargetData(c, "network_target")
            },
            scope: this
        })
    }
});
Ext.define("SYNO.Backup.Addon.sfr_s3.Restore.DestStep", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Restore.DestStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_sfr",
            transfer_type: "sfr_s3"
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.Backup.Addon.webdav.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "webdav",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "webdav";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("webdav", "url"),
            name: "remote_url",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("webdav", "username"),
            name: "account",
            width: this.comboboxWidth,
            allowBlank: false
        }, {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            name: "pwd",
            width: this.comboboxWidth,
            inputType: "password",
            allowBlank: false
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            name: "bucket",
            fieldLabel: SYNO.SDS.Backup.String("webdav", "root_folder_name"),
            store: new Ext.data.ArrayStore({
                fields: ["value"]
            }),
            forceSelection: false,
            valueField: "value",
            displayField: "value",
            allowBlank: false,
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadBuckets()) {
                    this.scope.loadBuckets()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: this.onSelectBucket,
                scope: this
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{value:htmlEncode}</div></tpl>'
        }, {
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getRemoteUrlValue: function() {
        var a = this.getForm().getFieldValues();
        var b = a.remote_url.trim();
        while (0 < b.length && b[b.length - 1] == "/") {
            b = b.slice(0, -1)
        }
        if (b.substring(0, 7) !== "http://" && b.substring(0, 8) !== "https://") {
            return "http://" + b
        }
        return b
    },
    onSelectBucket: function(a) {
        this.loadTarget(a.getValue())
    },
    activate: function() {},
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["pwd"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            remote_url: this.getRemoteUrlValue(),
            account: b("account"),
            pwd: b("pwd"),
            bucket: b("bucket"),
            target_id: b("target"),
            target_type: this.target_type,
            transfer_type: this.transfer_type
        }
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("webdav", "repo_type_name"));
        a.append(_T("backup", "backup_restore_source"), b.bucket + " / " + b.target_id)
    },
    getListBucketRequest: function() {
        var a = Ext.copyTo({}, this.getParams(), "remote_url,account,pwd,transfer_type");
        return a
    },
    needReloadBuckets: function() {
        var a = this.getListBucketRequest();
        return this.lastQueryModule !== Ext.encode(a)
    },
    loadBuckets: function() {
        var a = this.getListBucketRequest();
        if (!a.account || !a.pwd) {
            return
        }
        this.owner.setStatusBusy({
            text: SYNO.SDS.Backup.String("webdav", "load_root_folders")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.WebDAV.Container",
            version: 1,
            method: "list",
            params: a,
            encryption: ["pwd"],
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.loadBucketsData();
                    this.owner.reportError(b);
                    delete this.lastQueryModule;
                    return
                }
                this.lastQueryModule = Ext.encode(a);
                this.loadBucketsData(b)
            }
        })
    },
    loadBucketsData: function(b) {
        var a = this.getForm().findField("bucket");
        return SYNO.SDS.Backup.Util.comboboxLoadData(a, b ? b.bucket_list : [], 0)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(b) {
        var a = this.getLoadTargetParams();
        if (!a.remote_url || !a.account || !a.pwd || !a.bucket) {
            return
        }
        if (this.lastQueryTarget === Ext.encode(a)) {
            return
        }
        this.lastQueryTarget = Ext.encode(a);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: a,
            encryption: ["pwd"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(a);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    }
});
Ext.ns("SYNO.Backup.Addon.synocloud.Restore");
Ext.define("SYNO.Backup.Addon.synocloud.Restore.DestStep", {
    extend: "SYNO.Backup.Addon.base.Restore.DestStep",
    comboboxWidth: 270,
    addon_id: "synocloud",
    constructor: function(b) {
        var a = [];
        Ext.copyTo(this, b, "owner");
        this.target_type = "cloud_image";
        this.transfer_type = "synocloud_swift";
        this.configFields(a);
        this.callParent([Ext.apply({
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_fieldset",
                defaults: {
                    labelWidth: 300
                },
                items: a
            }]
        }, b)])
    },
    configFields: function(a) {
        a.push({
            xtype: "syno_combobox",
            width: this.comboboxWidth,
            fieldLabel: _T("backup", "backup_dest_directory"),
            name: "target",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["display", "value"]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            mode: "local",
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadTarget()) {
                    this.scope.loadTarget()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            scope: this,
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.value)]}" class="x-combo-list-item">{display:htmlEncode}</div></tpl>'
        })
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        if (!this.getForm().isDirty()) {
            return this.nextId
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            method: "get",
            version: 1,
            params: this.getParams(),
            encryption: ["secret"],
            callback: this.onTargetGet,
            scope: this
        });
        return false
    },
    onTargetGet: function(c, b, a) {
        if (!c) {
            this.owner.targetGetErrorHandle(b);
            this.owner.clearStatusBusy();
            return false
        }
        if (b.support_multi_version) {
            this.target_type = "cloud_image"
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        if ("cloud_image" !== b.format_type) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_not_support"));
            this.owner.clearStatusBusy();
            return false
        }
        this.owner.setSingle(false);
        this.owner.clearStatusBusy();
        this.owner.data_enc = b.data_enc;
        this.owner.uni_key = b.uni_key;
        if (b.data_enc) {
            this.launchPasswordWindow(function() {
                this.owner.goNext(this.nextId)
            })
        } else {
            this.owner.goNext(this.nextId)
        }
        return false
    },
    launchPasswordWindow: function(a) {
        var c = this.getParams();
        Ext.apply(c, {
            uni_key: this.owner.uni_key
        });
        var b = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: c,
            setter: Ext.createDelegate(this.setEncKey, this),
            callback: Ext.createDelegate(a, this)
        });
        b.open()
    },
    setEncKey: function(a) {
        this.owner.sess_id = a.sess_id;
        this.owner.sess_key = a.sess_key
    },
    getParams: function() {
        var b = this.getForm(),
            c = function(e) {
                return b.findField(e).getValue()
            };
        var d = {};
        d.target_id = c("target");
        d.key = this.key;
        d.secret = this.secret;
        d.tenant_id = this.tenant_id;
        d.target_type = this.target_type;
        d.transfer_type = this.transfer_type;
        d.region = this.region;
        var a = Ext.urlDecode(location.search.substr(1)).everest;
        if (a === "c2test") {
            d.remote_url = String.format("https://api.{0}.c2test.synology.com", d.region)
        } else {
            if (a === "insecure") {
                d.verify_cert = false
            }
        }
        return d
    },
    summary: function(a) {
        var b = this.getParams();
        a.append(_T("backup", "restore_type"), SYNO.SDS.Backup.String("synocloud", "repo_type_name_2"));
        a.append(_T("backup", "backup_restore_source"), b.target_id)
    },
    getLoadTargetParams: function() {
        var a = this.getParams();
        delete a.target_id;
        return a
    },
    needReloadTarget: function() {
        var a = this.getLoadTargetParams();
        return this.lastQueryTarget !== Ext.encode(a)
    },
    loadTarget: function(a) {
        var b = this.getLoadTargetParams();
        if (this.lastQueryTarget === Ext.encode(b)) {
            return
        }
        this.lastQueryTarget = Ext.encode(b);
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send({
            api: "SYNO.Backup.Target",
            method: "list",
            version: 1,
            params: b,
            encryption: ["secret"],
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.api.alert(c);
                    this.loadTargetData({
                        target_list: []
                    });
                    delete this.lastQueryTarget;
                    return
                }
                this.lastQueryTarget = Ext.encode(b);
                this.loadTargetData(c)
            },
            scope: this
        })
    },
    loadTargetData: function(b) {
        var a = this.getForm().findField("target");
        return SYNO.Backup.Util.HBKDisplayComboboxLoadData(a, b.target_list, "target_id")
    },
    setOauthResponse: function(a) {
        this.key = a.access_token;
        this.secret = a.refresh_token;
        this.tenant_id = a.openstack_token;
        this.region = "eu";
        if (!Ext.isEmpty(a.region)) {
            this.region = a.region
        }
    }
});
Ext.ns("SYNO.Backup.Addon.aws_s3.Destination");
Ext.define("SYNO.Backup.Addon.aws_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "aws_s3"
        }, a);
        return this.callParent([b])
    },
    getSignatureStore: function() {
        if (!this.signatureStore) {
            this.signatureStore = new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["v2", "v2"],
                    ["v4", "v4"]
                ]
            })
        }
        return this.signatureStore
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        a.push({
            xtype: "syno_combobox",
            name: "signature_version",
            width: this.comboboxWidth,
            allowBlank: false,
            store: this.getSignatureStore(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "signature_version"),
            displayField: "version",
            valueField: "value",
            value: "v2",
            editable: false,
            hidden: true,
            disabled: true
        });
        return a
    },
    loadData: function(b) {
        this.callParent(arguments);
        if (!Ext.isEmpty(b.remote_url)) {
            var a = this.getForm().findField("signature_version");
            a.setDisabled(false);
            a.setVisible(true)
        }
    }
});
Ext.ns("SYNO.Backup.Addon.azure_blob.Destination");
Ext.define("SYNO.Backup.Addon.azure_blob.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "azure_blob"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString("azure", "storage_account")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString("azure", "access_key"),
            width: 200
        });
        return a
    }
});
Ext.define("SYNO.Backup.Addon.azure_cn_blob.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.azure_blob.Destination.EditPanel"
});
Ext.ns("SYNO.Backup.Addon.hicloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.hicloud_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_hicloud"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.jdcloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.jdcloud_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_jdcloud"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.hidrive.Destination");
Ext.define("SYNO.Backup.Addon.hidrive.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "account",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "username")
        });
        a.push({
            xtype: "syno_textfield",
            name: "pwd",
            width: 200,
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input")
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.ibm_softlayer.Destination");
Ext.define("SYNO.Backup.Addon.ibm_softlayer.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: "secret",
            width: 200,
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        });
        return a
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.legacy_aws_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_aws_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "aws_s3"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_azure_blob.Destination");
Ext.define("SYNO.Backup.Addon.legacy_azure_blob.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "azure_blob"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString("azure_blob", "storage_account")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString("azure_blob", "access_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.legacy_hicloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_hicloud_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "hicloud_s3"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.legacy_sfr_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_sfr_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "sfr_s3"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.define("SYNO.Backup.Addon.base.Destination.EditPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        var b = Ext.apply({
            height: 400,
            trackResetOnLoad: true,
            items: this.createItems(a)
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        return []
    },
    loadData: function(a) {
        this.getForm().setValues(a);
        this.orgName = a.name
    },
    getApplyApi: function() {
        var a = this.getForm();
        var b = a.getFieldValues(true);
        b.name = this.orgName;
        b.task_id = this.taskId;
        b.repo_id = this.repoId;
        b.transfer_type = this.transferType;
        b.target_type = this.targetType;
        if (Ext.isFunction(this.getApplyParams)) {
            Ext.apply(b, this.getApplyParams())
        }
        return {
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "set",
            params: b
        }
    }
});
Ext.define("SYNO.Backup.Addon.rsync.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.EditPanel",
    createItems: function(b) {
        var a = b.transferType;
        return [{
            xtype: "syno_textfield",
            name: "dest",
            allowBlank: false,
            fieldLabel: _T("netbackup", "netbkp_set_ip"),
            width: 200,
            validator: function(c) {
                return SYNO.SDS.Backup.Util.isHostnameValid(c, false)
            },
            scope: this
        }, {
            xtype: "syno_combobox",
            name: "encrypt_connect",
            fieldLabel: SYNO.SDS.Backup.String("rsync", "transfer_encryption"),
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["text", "value"],
                data: [
                    [SYNO.SDS.Backup.String("app", "on"), true],
                    [SYNO.SDS.Backup.String("app", "off"), false]
                ]
            }),
            displayField: "text",
            valueField: "value",
            editable: false,
            value: false,
            listeners: {
                scope: this,
                select: function(d, c, e) {
                    this.changeEncTransLayout(c.get("value"))
                }
            }
        }, {
            xtype: "syno_numberfield",
            maxlength: 5,
            vtype: "port",
            name: "port",
            value: 873,
            allowBlank: false,
            fieldLabel: _T("common", "port")
        }, {
            xtype: "syno_numberfield",
            maxlength: 5,
            vtype: "port",
            name: "enc_port",
            value: 22,
            allowBlank: false,
            fieldLabel: _T("common", "port"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_textfield",
            name: "account",
            allowBlank: false,
            fieldLabel: _T("netbackup", "netbkp_account"),
            width: 200,
            validator: function(d) {
                var c = d;
                if ("rsync" === a) {
                    c = c.replace(/%/g, "a")
                }
                return Ext.form.VTypes.username_ext(c)
            },
            invalidText: Ext.form.VTypes.username_extText
        }, {
            xtype: "syno_textfield",
            name: "pwd",
            fieldLabel: _T("common", "password"),
            width: 200,
            inputType: "password"
        }]
    },
    changeEncTransLayout: function(d) {
        var c = this.getForm();
        var a = function(f, e) {
            c.findField(f).setDisabled(!e);
            c.findField(f).setVisible(e)
        };
        var b = function(e, f) {
            a("port", e);
            a("enc_port", f)
        };
        if (d) {
            b(false, true)
        } else {
            b(true, false)
        }
    },
    onQueryHostnameDone: function(c, b) {
        var a = [];
        if (!c || b === undefined || !Ext.isArray(b.nif)) {
            return
        }
        this.selfHostName = b.hostname.toLowerCase();
        Ext.each(b.nif, function(d) {
            a.push(d.addr);
            if (Ext.isArray(d.ipv6)) {
                Ext.each(d.ipv6, function(e) {
                    a.push(e.addr)
                })
            }
        });
        this.selfIPs = a
    },
    onTrustBtnClick: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.Certificate",
            version: 1,
            method: "verify",
            params: {
                repo_id: this.repoId,
                trust_cert: true
            },
            callback: this.verifyCertCB,
            scope: this
        })
    },
    verifyCertCB: function(d, a, b) {
        this.owner.clearStatusBusy();
        if (!d) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.GetErrorString(a.code));
            return
        }
        var c = this.getForm().findField("verify_cert");
        if (c) {
            c.removeClass("syno-backup-orange-status");
            c.removeClass("syno-backup-green-status");
            if (true === a.verify_cert) {
                c.addClass("syno-backup-green-status");
                c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_pass"))
            } else {
                c.addClass("syno-backup-orange-status");
                c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_failed"));
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("error", "ssl_verify_fail"))
            }
        }
    },
    loadData: function(a) {
        if (Ext.isDefined(a.remoteshell) && this.getForm().findField("encrypt_connect")) {
            if (a.remoteshell) {
                a.encrypt_connect = true;
                this.getForm().findField("encrypt_connect").setDisabled(true)
            }
        }
        if (this.getForm().findField("enc_port")) {
            if (Ext.isDefined(a.enc_port)) {
                if (0 === a.enc_port) {
                    a.enc_port = 22
                }
            } else {
                a.enc_port = 22
            }
        }
        if (this.getForm().findField("port") && !Ext.isDefined(a.port)) {
            a.port = 873
        }
        this.getForm().setValues(a);
        this.orgName = a.name;
        this.deststatus = a.deststatus;
        if (this.getForm().findField("encrypt_connect")) {
            this.changeEncTransLayout(this.getForm().findField("encrypt_connect").getValue())
        }
    },
    afterRender: function() {
        this.owner.setStatusBusy();
        var a = [{
            api: "SYNO.Core.System",
            method: "info",
            version: 1,
            params: {
                type: "network"
            }
        }];
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: a
            },
            scope: this,
            callback: this.onRenderDone
        });
        return this.callParent(arguments)
    },
    onRenderDone: function(c, a, b) {
        if (!c) {
            this.owner.clearStatusBusy();
            this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        this.onQueryHostnameDone(a.result[0].success, a.result[0].data);
        this.owner.clearStatusBusy()
    },
    getApplyParams: function() {
        var b = {};
        var a = this.getForm();
        if (a.findField("encrypt_connect")) {
            b.encrypt_connect = a.findField("encrypt_connect").getValue();
            if (b.encrypt_connect) {
                b.enc_port = a.findField("enc_port").getValue()
            } else {
                b.port = a.findField("port").getValue()
            }
        }
        return b
    }
});
Ext.define("SYNO.Backup.Addon.rsync_ds.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.rsync.Destination.EditPanel"
});
Ext.define("SYNO.Backup.Addon.legacy_rsync.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.rsync.Destination.EditPanel"
});
Ext.define("SYNO.Backup.Addon.legacy_rsync_ds.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.rsync.Destination.EditPanel"
});
Ext.ns("SYNO.Backup.Addon.openstack.Destination");
Ext.define("SYNO.Backup.Addon.openstack.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: "secret_pw",
            inputType: "password",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_textfield",
            name: "secret",
            width: 200,
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        }, {
            xtype: "syno_compositefield",
            name: "tenant_compositefield",
            width: 200,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "tenant"),
            items: [{
                xtype: "syno_combobox",
                name: "tenant_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "tenant_id"],
                        ["name", "tenant_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "tenant_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: "tenant_value",
                width: 114,
                allowBlank: true
            }],
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            name: "domain_compositefield",
            width: 200,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "domain"),
            items: [{
                xtype: "syno_combobox",
                name: "domain_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "domain_id"],
                        ["name", "domain_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "domain_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: "domain_value",
                width: 114,
                allowBlank: false
            }],
            hidden: true,
            disabled: true
        });
        return a
    },
    loadData: function(b) {
        var f = this.getForm();
        var e = function(h, g) {
            f.findField(h).setDisabled(!g);
            f.findField(h).setVisible(g)
        };
        this.getForm().findField("key").setValue(b.key);
        var a = b.auth_version;
        if ("1.0" === a) {
            e("secret", true);
            e("secret_pw", false);
            e("tenant_compositefield", false);
            e("domain_compositefield", false);
            f.findField("secret").setValue(b.secret)
        } else {
            if ("2.0" === a || "3.0" === a) {
                e("secret", false);
                e("secret_pw", true);
                f.findField("secret_pw").setValue(b.secret);
                e("tenant_compositefield", true);
                if (!Ext.isEmpty(b.tenant_name)) {
                    f.findField("tenant_option").setValue("tenant_name");
                    f.findField("tenant_value").setValue(b.tenant_name)
                } else {
                    if (!Ext.isEmpty(b.tenant_id)) {
                        f.findField("tenant_option").setValue("tenant_id");
                        f.findField("tenant_value").setValue(b.tenant_id)
                    } else {
                        var c = f.findField("tenant_option");
                        c.setValue(c.getValue())
                    }
                }
                e("domain_compositefield", ("3.0" === a));
                if ("3.0" === a) {
                    if (!Ext.isEmpty(b.domain_name)) {
                        f.findField("domain_option").setValue("domain_name");
                        f.findField("domain_value").setValue(b.domain_name)
                    } else {
                        if (!Ext.isEmpty(b.domain_id)) {
                            f.findField("domain_option").setValue("domain_id");
                            f.findField("domain_value").setValue(b.domain_id)
                        } else {
                            var d = f.findField("domain_option");
                            d.setValue(d.getValue())
                        }
                    }
                }
            }
        }
        this.orgName = b.name
    },
    getApplyApi: function() {
        var b = this.getForm();
        var a = b.getFieldValues(true);
        var c = {};
        if (a.key) {
            c.key = a.key
        }
        if (a.secret) {
            c.secret = a.secret
        } else {
            if (a.secret_pw) {
                c.secret = a.secret_pw
            }
        }
        if (!b.findField("tenant_compositefield").disabled) {
            if ("tenant_name" === b.findField("tenant_option").getValue()) {
                c.tenant_name = b.findField("tenant_value").getValue();
                c.tenant_id = ""
            } else {
                if ("tenant_id" === b.findField("tenant_option").getValue()) {
                    c.tenant_name = "";
                    c.tenant_id = b.findField("tenant_value").getValue()
                }
            }
        }
        if (!b.findField("domain_compositefield").disabled) {
            if ("domain_name" === b.findField("domain_option").getValue()) {
                c.domain_name = b.findField("domain_value").getValue();
                c.domain_id = ""
            } else {
                if ("domain_id" === b.findField("domain_option").getValue()) {
                    c.domain_name = "";
                    c.domain_id = b.findField("domain_value").getValue()
                }
            }
        }
        c.name = this.orgName;
        c.task_id = this.taskId;
        c.repo_id = this.repoId;
        c.transfer_type = this.transferType;
        c.target_type = this.targetType;
        return {
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "set",
            params: c
        }
    }
});
Ext.ns("SYNO.Backup.Addon.rackspace.Destination");
Ext.define("SYNO.Backup.Addon.rackspace.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: "secret",
            width: 200,
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.remote.Destination");
Ext.define("SYNO.Backup.Addon.remote.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.EditPanel",
    createItems: function(a) {
        this.is_verify_cert = true;
        return [{
            xtype: "syno_textfield",
            name: "dest",
            allowBlank: false,
            fieldLabel: _T("netbackup", "netbkp_set_ip"),
            width: 200,
            validator: function(b) {
                return SYNO.SDS.Backup.Util.isHostnameValid(b, false)
            },
            scope: this
        }, {
            xtype: "syno_combobox",
            name: "sslcheck",
            fieldLabel: SYNO.SDS.Backup.String("remote", "transfer_encryption"),
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["text", "value"],
                data: [
                    [SYNO.SDS.Backup.String("app", "on"), true],
                    [SYNO.SDS.Backup.String("app", "off"), false]
                ]
            }),
            displayField: "text",
            valueField: "value",
            editable: false,
            value: false,
            listeners: {
                select: function(c, b, d) {
                    this.showFieldCert(b.json[1])
                },
                scope: this
            }
        }, {
            xtype: "syno_numberfield",
            maxlength: 5,
            vtype: "port",
            name: "port",
            value: 6281,
            allowBlank: false,
            fieldLabel: _T("common", "port")
        }, {
            xtype: "syno_displayfield",
            name: "account",
            hidden: true
        }, {
            xtype: "syno_displayfield",
            name: "pwd",
            hidden: true
        }, {
            xtype: "syno_displayfield",
            name: "is_webapi_authen",
            value: "false",
            hidden: true
        }, {
            xtype: "syno_compositefield",
            fieldLabel: SYNO.SDS.Backup.String("app", "authenticate"),
            items: [{
                xtype: "syno_displayfield",
                name: "account_display_name"
            }, {
                xtype: "syno_button",
                name: "account_authen",
                text: SYNO.SDS.Backup.String("app", "login"),
                itemId: "authenticate_button",
                handler: this.onAuthenBtnClick,
                scope: this
            }]
        }, {
            xtype: "syno_displayfield",
            name: "verify_cert",
            fieldLabel: SYNO.SDS.Backup.String("app", "certificate_auth")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            style: "margin-left: 185px",
            name: "cert_buttons",
            items: [{
                xtype: "syno_button",
                hideLabel: true,
                text: SYNO.SDS.Backup.String("app", "trust"),
                itemId: "trust_button",
                handler: this.onTrustBtnClick,
                scope: this
            }, {
                xtype: "syno_button",
                hideLabel: true,
                text: SYNO.SDS.Backup.String("app", "ignore"),
                itemId: "ignore_button",
                handler: this.onIgnoreCertBtnClick,
                scope: this
            }]
        }, {
            xtype: "syno_displayfield",
            height: 10
        }, {
            xtype: "syno_displayfield",
            name: "white_list_edit_hint",
            value: _T("backup", "repo_white_list_hint")
        }]
    },
    showFieldCert: function(b) {
        var c = this.getForm().findField("verify_cert");
        var a = this.getForm().findField("cert_buttons");
        if (b) {
            c.show();
            a.show()
        } else {
            c.hide();
            a.hide()
        }
        this.doLayout()
    },
    onQueryHostnameDone: function(c, b) {
        var a = [];
        if (!c || b === undefined || !Ext.isArray(b.nif)) {
            return
        }
        this.selfHostName = b.hostname.toLowerCase();
        Ext.each(b.nif, function(d) {
            a.push(d.addr);
            if (Ext.isArray(d.ipv6)) {
                Ext.each(d.ipv6, function(e) {
                    a.push(e.addr)
                })
            }
        });
        this.selfIPs = a
    },
    onIgnoreCertBtnClick: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.Certificate",
            version: 1,
            method: "ignore",
            params: {
                repo_id: this.repoId,
                ignore_cert: true
            },
            callback: this.ignoreCertCB,
            scope: this
        })
    },
    ignoreCertCB: function(e, a, c) {
        this.owner.clearStatusBusy();
        if (!e) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.GetErrorString(a.code));
            return
        }
        var d = this.getForm().findField("verify_cert");
        d.removeClass("syno-backup-orange-status");
        d.removeClass("syno-backup-red-status");
        d.removeClass("syno-backup-green-status");
        d.addClass("syno-backup-orange-status");
        d.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_always_ignore"));
        this.is_verify_cert = false;
        var b = this.getForm().findField("sslcheck");
        if (b.disabled) {
            b.setDisabled(false);
            b.setValue(this.sslCheck)
        }
    },
    authenCB: function(a) {
        if (!("code" in a)) {
            this.getForm().findField("account").setValue(a.username);
            SYNO.Backup.Util.DisplayAccount(this.getForm().findField("account_display_name"), a.username, 12);
            this.getForm().findField("pwd").setValue(a.id);
            this.getForm().findField("is_webapi_authen").setValue(true);
            this.doLayout()
        }
        this.owner.clearStatusBusy()
    },
    onAuthenBtnClick: function() {
        var a = this.getForm().findField("dest");
        if (!a.isValid()) {
            a.markInvalid(_T("netbackup", "netbkp_err_host_str"));
            return
        }
        this.owner.setStatusBusy();
        var b = this.owner.getParams();
        b.ip = this.getForm().findField("dest").getValue();
        b.port = this.getForm().findField("port").getValue();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.LoginPort",
            version: 1,
            method: "get",
            params: b,
            scope: this,
            callback: function(g, c, e) {
                if (!g) {
                    if (c.code == SYNO.SDS.Backup.ERR_NO_RESPONSE) {
                        c.code = SYNO.SDS.Backup.ERR_SERVICE_DISABLE
                    }
                    this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.GetErrorString(c.code));
                    return false
                }
                var d = "";
                var f = false;
                if (c.port > 0) {
                    d = "https://" + b.ip + ":" + c.port
                } else {
                    f = true
                }
                this.owner.clearStatusBusy();
                synocredential.Issue({
                    url: d,
                    forceLegacyMode: f,
                    mustHaveCredential: true,
                    session: "HyperBackupVault",
                    appWin: this.owner,
                    callback: this.authenCB.bind(this),
                    redirect_uri: window.location.origin
                })
            }
        })
    },
    onTrustBtnClick: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.Certificate",
            version: 1,
            method: "verify",
            params: {
                repo_id: this.repoId,
                trust_cert: true
            },
            callback: this.verifyCertCB,
            scope: this
        })
    },
    verifyCertCB: function(e, a, c) {
        this.owner.clearStatusBusy();
        if (!e) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.GetErrorString(a.code));
            return
        }
        this.is_verify_cert = true;
        var d = this.getForm().findField("verify_cert");
        if (d) {
            d.removeClass("syno-backup-orange-status");
            d.removeClass("syno-backup-red-status");
            d.removeClass("syno-backup-green-status");
            d.addClass("syno-backup-green-status");
            d.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_pass"));
            var b = this.getForm().findField("sslcheck");
            if (b.disabled) {
                b.setDisabled(false);
                b.setValue(this.sslCheck)
            }
        }
    },
    loadData: function(b) {
        this.getForm().setValues(b);
        if (this.getForm().findField("sslcheck")) {
            if (!b.support_ssl) {
                this.getForm().findField("sslcheck").setValue(false);
                this.getForm().findField("sslcheck").setDisabled(true)
            } else {
                this.getForm().findField("sslcheck").setDisabled(false)
            }
        }
        if (this.getForm().findField("port") && !Ext.isDefined(b.port)) {
            b.port = 6281
        }
        var a = this.getForm().findField("account_display_name");
        if (a.getEl()) {
            SYNO.Backup.Util.DisplayAccount(a, b.account, 12);
            this.doLayout()
        }
        this.is_verify_cert = !b.ignore_cert;
        var c = this.getForm().findField("verify_cert");
        if (c) {
            c.removeClass("syno-backup-orange-status");
            c.removeClass("syno-backup-red-status");
            c.removeClass("syno-backup-green-status");
            if (b.sslcheck) {
                if (true === b.ignore_cert) {
                    c.addClass("syno-backup-orange-status");
                    c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_always_ignore"))
                } else {
                    if (true === b.verify_cert) {
                        c.addClass("syno-backup-green-status");
                        c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_pass"))
                    } else {
                        c.addClass("syno-backup-red-status");
                        c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_failed"));
                        this.cert_err_reason = SYNO.Backup.Util.getCertErrReason(b.verify_err_code, b.cert)
                    }
                }
                delete b.verify_cert
            } else {
                c.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_not_yet"))
            }
            this.showFieldCert(b.sslcheck)
        }
        this.orgName = b.name;
        this.deststatus = b.deststatus;
        this.sslCheck = b.sslcheck
    },
    afterRender: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.System",
            method: "info",
            version: 1,
            params: {
                type: "network"
            },
            callback: this.onRenderDone,
            scope: this
        });
        return this.callParent(arguments)
    },
    onRenderDone: function(d, a, b) {
        if (!d) {
            this.owner.clearStatusBusy();
            this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        var c = this.getForm().findField("verify_cert");
        if (c && !Ext.isEmpty(this.cert_err_reason)) {
            SYNO.ux.AddTip(c.getEl(), this.cert_err_reason)
        }
        SYNO.Backup.Util.DisplayAccount(this.getForm().findField("account_display_name"), this.getForm().findField("account").getValue(), 12);
        this.doLayout();
        this.onQueryHostnameDone(a.success, a.data);
        this.owner.clearStatusBusy()
    },
    getApplyParams: function() {
        var b = this.getForm();
        var c = b.getFieldValues(false);
        var a = false;
        if (!this.sslCheck && c.sslcheck) {
            a = true
        } else {
            if (c.sslcheck && this.is_verify_cert) {
                a = true
            }
        }
        return {
            verify_cert: a
        }
    }
});
Ext.ns("SYNO.Backup.Addon.sfr_s3.Destination");
Ext.define("SYNO.Backup.Addon.sfr_s3.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "image_sfr"
        }, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "key",
            width: 200,
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        });
        a.push({
            xtype: "syno_textfield",
            name: "secret",
            inputType: "password",
            allowBlank: false,
            fieldLabel: _T("backup", "s3_secret_key"),
            width: 200
        });
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.webdav.Destination");
Ext.define("SYNO.Backup.Addon.webdav.Destination.EditPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.EditDialog",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    createItems: function() {
        var a = this.callParent();
        a.push({
            xtype: "syno_textfield",
            name: "remote_url",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "url")
        });
        a.push({
            xtype: "syno_textfield",
            name: "account",
            width: 200,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "username")
        });
        a.push({
            xtype: "syno_textfield",
            name: "pwd",
            width: 200,
            inputType: "password",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input")
        });
        return a
    },
    getApplyApi: function() {
        var b = this.getForm();
        var a = b.getFieldValues(true);
        var d = {};
        if (a.remote_url) {
            var c = a.remote_url.trim();
            while (0 < c.length && c[c.length - 1] == "/") {
                c = c.slice(0, -1)
            }
            if (c.substring(0, 7) !== "http://" && c.substring(0, 8) !== "https://") {
                d.remote_url = "http://" + c
            } else {
                d.remote_url = c
            }
        }
        if (a.account) {
            d.account = a.account
        }
        if (a.pwd) {
            d.pwd = a.pwd
        }
        d.name = this.orgName;
        d.task_id = this.taskId;
        d.repo_id = this.repoId;
        d.transfer_type = this.transferType;
        d.target_type = this.targetType;
        return {
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "set",
            params: d
        }
    }
});
Ext.ns("SYNO.Backup.Addon.synocloud.Destination");
Ext.define("SYNO.Backup.Addon.synocloud.Destination.EditPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.EditPanel",
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", function() {
            this.checkAccountInfoFresh()
        }, this, {
            single: true
        })
    },
    checkAccountInfoFresh: function() {
        if (!this.owner.accountMeta.isFresh) {
            this.mask_ = new Ext.LoadMask(this.getEl());
            this.mask_.show();
            this.owner.sendWebAPI({
                api: "SYNO.Backup.Target",
                method: "get",
                version: 1,
                params: {
                    task_id: this.taskId,
                    additional: ["update_account_meta", "account_meta"]
                },
                scope: this,
                callback: function(c, a) {
                    if (!c) {
                        this.mask_.hide();
                        return
                    }
                    if (a.account_meta) {
                        var b = SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta();
                        b.setData(a.account_meta);
                        this.form.findField("account").setValue(b.account);
                        this.form.findField("plan").setValue(this.getPlanString(b.planGroup, b.quota));
                        this.form.findField("period").setValue(this.getPeriodString(b.planPeriod))
                    }
                    this.mask_.hide()
                }
            })
        }
    },
    createItems: function(a) {
        return [{
            xtype: "syno_displayfield",
            name: "account",
            value: SYNO.SDS.Backup.String("app", "unable_get_details"),
            fieldLabel: SYNO.SDS.Backup.String("app", "account")
        }, {
            xtype: "syno_displayfield",
            name: "plan",
            value: SYNO.SDS.Backup.String("app", "unable_get_details"),
            fieldLabel: SYNO.SDS.Backup.String("app", "plan")
        }, {
            xtype: "syno_displayfield",
            name: "period",
            value: SYNO.SDS.Backup.String("app", "unable_get_details"),
            fieldLabel: SYNO.Backup.Addon.Util.getString("synocloud", "subscription_cycle")
        }]
    },
    getPeriodString: function(b) {
        var a = (b == "yearly") ? SYNO.Backup.Addon.Util.getString("synocloud", "plan_period_yearly") : SYNO.Backup.Addon.Util.getString("synocloud", "plan_period_monthly");
        return a
    },
    getPlanString: function(c, b) {
        var a = SYNO.SDS.Backup.ConverSize(b, 0);
        var d = (c == "personal") ? SYNO.Backup.Addon.Util.getString("synocloud", "plan_group_personal") : SYNO.Backup.Addon.Util.getString("synocloud", "plan_group_business");
        return String.format("{0} - {1}", d, a)
    },
    loadData: function(b, a) {
        if (a.account !== "" && a.planGroup !== "" && a.planPeriod !== "" && a.quota !== 0) {
            this.form.findField("account").setValue(a.accountMeta.account);
            this.form.findField("plan").setValue(this.getPlanString(a.accountMeta.planGroup, a.accountMeta.quota));
            this.form.findField("period").setValue(this.getPeriodString(a.accountMeta.planPeriod))
        } else {
            var c = b.account_meta;
            if (c) {
                if (c.synoaccount) {
                    this.form.findField("account").setValue(c.synoaccount)
                }
                if (c.plan_group && c.quota) {
                    this.form.findField("plan").setValue(this.getPlanString(c.plan_group, c.quota))
                }
                if (c.plan_period) {
                    this.form.findField("period").setValue(this.getPeriodString(c.plan_period))
                }
            }
        }
    },
    getApplyApi: function() {}
});
Ext.ns("SYNO.Backup.Addon.amazon_cloud_drive.Task");
Ext.define("SYNO.Backup.Addon.amazon_cloud_drive.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.aws_s3.Task");
Ext.define("SYNO.Backup.Addon.aws_s3.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        this.partSizeStore = new Ext.data.SimpleStore({
            data: [
                ["8", 8],
                ["16", 16],
                ["32", 32],
                ["64", 64],
                ["128", 128],
                ["256", 256],
                ["512", 512]
            ],
            fields: ["partsize", "partsizeValue"]
        });
        return [{
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, new SYNO.SDS.Backup.ComboBoxAndDisplayField({
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "storage_class"),
            itemId: "storage_class",
            store: new Ext.data.SimpleStore({
                fields: ["storage_class_name", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "standard_storage"), "STANDARD"],
                    [SYNO.SDS.Backup.String("aws_s3", "intelligent_tiering_storage"), "INTELLIGENT_TIERING"],
                    [SYNO.SDS.Backup.String("aws_s3", "reduced_redundancy_storage"), "REDUCED_REDUNDANCY"],
                    [SYNO.SDS.Backup.String("aws_s3", "infrequent_access_storage"), "STANDARD_IA"],
                    [SYNO.SDS.Backup.String("aws_s3", "onezone_infrequent_access_storage"), "ONEZONE_IA"]
                ]
            }),
            displayField: "storage_class_name",
            valueField: "value",
            value: "STANDARD",
            hidden: true
        }), {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "s3_multipart_size"),
            name: "part_size",
            width: 80,
            displayField: "partsize",
            valueField: "partsizeValue",
            value: 512,
            store: this.partSizeStore
        }]
    },
    getParams: function() {
        var a = this.getFieldset().getComponent("storage_class").getValue();
        var b = this.getForm(),
            c = function(e) {
                return b.findField(e).getValue()
            };
        var d = this.callParent(arguments);
        d.backup_params.part_size = c("part_size");
        if (a) {
            d.backup_params.storage_class = a
        }
        return d
    },
    activate: function() {
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "trans_encrypt", false);
            c(a, "part_size", false)
        } else {
            c(a, "trans_encrypt", true);
            c(a, "part_size", true)
        }
        if (b.remote_url || "export" === b.action) {
            this.getFieldset().getComponent("storage_class").setVisibleAndEnable(false)
        } else {
            if ("relink" === b.action && !Ext.isEmpty(this.owner.storage_class)) {
                this.getFieldset().getComponent("storage_class").setValue(this.owner.storage_class);
                this.getFieldset().getComponent("storage_class").transToText()
            } else {
                this.getFieldset().getComponent("storage_class").transToComboBox()
            }
        }
        if (this.lastAnchor !== this.owner.getWizardAnchor()) {
            this.getForm().findField("part_size").setValue(512)
        }
        this.callParent(arguments)
    }
});
Ext.ns("SYNO.Backup.Addon.auzre_blob.Task");
Ext.define("SYNO.Backup.Addon.azure_blob.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            checked: true,
            name: "trans_encrypt",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission")
        }]
    },
    activate: function() {
        this.callParent(arguments);
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "trans_encrypt", false)
        } else {
            c(a, "trans_encrypt", true)
        }
    }
});
Ext.ns("SYNO.Backup.Addon.auzre_cn_blob.Task");
Ext.define("SYNO.Backup.Addon.azure_cn_blob.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.azure_blob.Task.SettingPanel"
});
Ext.ns("SYNO.Backup.Addon.dropbox.Task");
Ext.define("SYNO.Backup.Addon.dropbox.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.google_drive.Task");
Ext.define("SYNO.Backup.Addon.google_drive.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.hicloud_s3.Task");
Ext.define("SYNO.Backup.Addon.hicloud_s3.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Backup.ParamsPanel",
    loadPartSizeStore: function() {
        this.partSizeStore.loadData([
            ["8", 8],
            ["16", 16],
            ["32", 32],
            ["64", 64],
            ["128", 128],
            ["256", 256],
            ["512", 512]
        ])
    },
    setDefaultSizeStore: function() {
        this.getForm().findField("part_size").setValue(512)
    }
});
Ext.ns("SYNO.Backup.Addon.jdcloud_s3.Task");
Ext.define("SYNO.Backup.Addon.jdcloud_s3.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Backup.ParamsPanel",
    loadPartSizeStore: function() {
        this.partSizeStore.loadData([
            ["8", 8],
            ["16", 16],
            ["32", 32],
            ["64", 64],
            ["128", 128],
            ["256", 256],
            ["512", 512]
        ])
    },
    setDefaultSizeStore: function() {
        this.getForm().findField("part_size").setValue(512)
    }
});
Ext.ns("SYNO.Backup.Addon.hidrive.Task");
Ext.define("SYNO.Backup.Addon.hidrive.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("netbackup", "compression_enable"),
            name: "trans_compress",
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            name: "bandwidth_composite",
            items: [{
                xtype: "syno_checkbox",
                name: "bandwidthcheck",
                boxLabel: _T("backup", "limit_the_bandwidth"),
                scope: this,
                handler: function(c, b) {
                    if (b) {
                        this.getForm().findField("bw_limit").enable()
                    } else {
                        this.getForm().findField("bw_limit").disable()
                    }
                }
            }, {
                xtype: "syno_numberfield",
                disabled: true,
                name: "bw_limit",
                allowBlank: false,
                width: 100,
                minValue: 1,
                maxValue: 2147483647
            }, {
                xtype: "syno_displayfield",
                value: "KB/s"
            }]
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        if (b("bandwidthcheck")) {
            c.backup_params.bw_limit = b("bw_limit")
        } else {
            c.backup_params.bw_limit = 0
        }
        return c
    },
    activate: function() {
        this.callParent(arguments);
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "bandwidth_composite", false)
        } else {
            c(a, "bandwidth_composite", true);
            this.getForm().findField("bw_limit").setDisabled(!this.getForm().findField("bandwidthcheck").getValue())
        }
    }
});
Ext.ns("SYNO.Backup.Addon.hubic.Task");
Ext.define("SYNO.Backup.Addon.hubic.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.ibm_softlayer.Task");
Ext.define("SYNO.Backup.Addon.ibm_softlayer.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Backup.ParamsPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_aws_s3.Task");
Ext.define("SYNO.Backup.Addon.legacy_aws_s3.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                labelWidth: 300,
                collapsible: false,
                items: this.configS3Fields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configS3Fields: function(a) {
        var b = new Ext.data.SimpleStore({
            data: [
                ["8", 8],
                ["16", 16],
                ["32", 32],
                ["64", 64],
                ["128", 128],
                ["256", 256],
                ["512", 512]
            ],
            fields: ["partsize", "partsizeValue"]
        });
        return [{
            xtype: "syno_fieldset",
            labelWidth: 150,
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                value: a.defaultName,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "incrbkp_enable"),
            labelSeparator: "",
            name: "incrbkp_enable"
        }, {
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }, {
            xtype: "syno_checkbox",
            name: "is_rrs",
            boxLabel: _T("backup", "s3_use_rrs")
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "s3_multipart_size"),
            name: "part_size",
            width: 80,
            displayField: "partsize",
            valueField: "partsizeValue",
            value: 512,
            store: b
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        c.backup_params.part_size = b("part_size");
        return c
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_azure_blob.Task");
Ext.define("SYNO.Backup.Addon.legacy_azure_blob.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                labelWidth: 300,
                collapsible: false,
                items: this.configS3Fields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configS3Fields: function(a) {
        return [{
            xtype: "syno_fieldset",
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            labelWidth: 150,
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                value: a.defaultName,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                maxLength: 32,
                width: 270,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "incrbkp_enable"),
            labelSeparator: "",
            name: "incrbkp_enable"
        }, {
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }]
    },
    getParams: function() {
        var a = this.callParent(arguments);
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_hicloud_s3.Task");
Ext.define("SYNO.Backup.Addon.legacy_hicloud_s3.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                labelWidth: 300,
                collapsible: false,
                items: this.configS3Fields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configS3Fields: function(a) {
        var b = new Ext.data.SimpleStore({
            data: [
                ["8", 8],
                ["16", 16],
                ["32", 32],
                ["64", 64],
                ["128", 128],
                ["256", 256],
                ["512", 512]
            ],
            fields: ["partsize", "partsizeValue"]
        });
        return [{
            xtype: "syno_fieldset",
            bwrapStyle: "padding: 0;",
            style: "margin: 0;",
            labelWidth: 150,
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                value: a.defaultName,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "incrbkp_enable"),
            labelSeparator: "",
            name: "incrbkp_enable"
        }, {
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "s3_multipart_size"),
            name: "part_size",
            width: 80,
            displayField: "partsize",
            valueField: "partsizeValue",
            value: 512,
            store: b
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        c.backup_params.part_size = b("part_size");
        return c
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_local.Task");
Ext.define("SYNO.Backup.Addon.legacy_local.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                collapsible: false,
                bwrapStyle: "padding: 0px;",
                items: this.configLocalFields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configLocalFields: function(b) {
        var a = [{
            xtype: "syno_fieldset",
            labelWidth: 150,
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                labelWidth: 240,
                width: 270,
                maxLength: 32,
                value: b.defaultName,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                labelWidth: 240,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            name: "incrbkp_enable",
            boxLabel: _T("backup", "incrbkp_enable")
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            labelWidth: 246,
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }, {
            xtype: "syno_checkbox",
            name: "dest_auto_unmount",
            boxLabel: SYNO.SDS.Backup.String("app", "support_auto_unmount_dest"),
            checked: false,
            hidden: true
        }];
        return a
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_rsync.Task");
Ext.define("SYNO.Backup.Addon.legacy_rsync.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                collapsible: false,
                bwrapStyle: "padding: 0px;",
                items: this.configNetFields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configNetFields: function(a) {
        return [{
            xtype: "syno_fieldset",
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                labelWidth: 240,
                width: 270,
                value: a.defaultName,
                maxLength: 32,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                labelWidth: 240,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("netbackup", "compression_enable"),
            name: "trans_compress"
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "blockbkp_enable"),
            name: "trans_delta"
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "incrbkp_enable"),
            name: "incrbkp_enable"
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            items: [{
                xtype: "syno_checkbox",
                name: "bandwidthcheck",
                boxLabel: _T("backup", "limit_the_bandwidth"),
                scope: this,
                handler: function(c, b) {
                    if (b) {
                        this.getForm().findField("bw_limit").enable()
                    } else {
                        this.getForm().findField("bw_limit").disable()
                    }
                }
            }, {
                xtype: "syno_numberfield",
                disabled: true,
                name: "bw_limit",
                allowBlank: false,
                width: 100,
                minValue: 1,
                maxValue: 2147483647
            }, {
                xtype: "syno_displayfield",
                value: "KB/s"
            }]
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            labelWidth: 246,
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        if (b("bandwidthcheck")) {
            c.backup_params.bw_limit = b("bw_limit")
        } else {
            c.backup_params.bw_limit = 0
        }
        return c
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_rsync_ds.Task");
Ext.define("SYNO.Backup.Addon.legacy_rsync_ds.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.legacy_rsync.Task.SettingPanel"
});
Ext.ns("SYNO.Backup.Addon.legacy_sfr_s3.Task");
Ext.define("SYNO.Backup.Addon.legacy_sfr_s3.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Legacy.base.Task.SettingPanel",
    constructor: function(a) {
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: a.subTitle,
                labelWidth: 300,
                collapsible: false,
                items: this.configS3Fields(a)
            }]
        }, a);
        return this.callParent([b])
    },
    configS3Fields: function(a) {
        var b = new Ext.data.SimpleStore({
            data: [
                ["8", 8],
                ["16", 16],
                ["32", 32],
                ["64", 64]
            ],
            fields: ["partsize", "partsizeValue"]
        });
        return [{
            xtype: "syno_fieldset",
            bwrapStyle: "padding: 0;",
            style: "margin: 0;",
            labelWidth: 150,
            items: [{
                xtype: "syno_textfield",
                name: "task_name",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                value: a.defaultName,
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "taskname"
            }, {
                xtype: "syno_textfield",
                name: "task_dir",
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("backup", "incrbkp_enable"),
            labelSeparator: "",
            name: "incrbkp_enable"
        }, {
            xtype: "syno_checkbox",
            checked: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt"
        }, {
            xtype: "syno_checkbox",
            name: "backup_meta",
            boxLabel: _T("backup", "backup_metadata_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "backup_thumb",
            boxLabel: _T("backup", "backup_synoea_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_notify",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_notify_option"),
            checked: true
        }, {
            xtype: "syno_checkbox",
            checked: true,
            disabled: true,
            name: "bkp_config",
            boxLabel: SYNO.SDS.Backup.String("app", "backup_config_option_mandatory")
        }, {
            xtype: "syno_numberfield",
            name: "max_dss_version",
            indent: "1",
            fieldLabel: _T("backup", "max_version"),
            allowBlank: false,
            minValue: 1,
            maxValue: 30,
            value: 1,
            width: 50
        }, {
            xtype: "syno_combobox",
            fieldLabel: _T("backup", "s3_multipart_size"),
            name: "part_size",
            width: 80,
            displayField: "partsize",
            valueField: "partsizeValue",
            value: 64,
            store: b
        }]
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        c.backup_params.part_size = b("part_size");
        return c
    }
});
Ext.ns("SYNO.Backup.Addon.local.Task");
Ext.define("SYNO.Backup.Addon.local.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Task.SettingPanel"
});
Ext.ns("SYNO.Backup.Addon.openstack.Task");
Ext.define("SYNO.Backup.Addon.openstack.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Backup.ParamsPanel"
});
Ext.ns("SYNO.Backup.Addon.openstack.Task");
Ext.define("SYNO.Backup.Addon.rackspace.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Backup.ParamsPanel",
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }]
    }
});
Ext.ns("SYNO.Backup.Addon.remote.Task");
Ext.define("SYNO.Backup.Addon.remote.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Task.SettingPanel",
    getSettingConfig: function(a) {
        var b = [{
            xtype: "syno_checkbox",
            name: "trans_encrypt",
            hidden: true,
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission")
        }, {
            xtype: "syno_fieldset",
            labelWidth: 150,
            style: "margin: 0;",
            bwrapStyle: "padding: 0;",
            hidden: a.appWin !== undefined,
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.Backup.String("app", "auto_resume_retry_limit_desc")
            }, {
                xtype: "syno_numberfield",
                name: "max_auto_resume_retry",
                value: 5,
                minValue: 0,
                maxValue: 10,
                width: 40,
                allowBlank: false,
                fieldLabel: SYNO.SDS.Backup.String("app", "max_number")
            }]
        }];
        return b
    },
    activate: function() {
        var c = this.owner.getParams();
        var a = this.owner.getRepoInfo();
        var b = this.getForm();
        if ("export" !== c.action) {
            if (Ext.isDefined(a.sslcheck) && a.sslcheck && b.findField("trans_encrypt")) {
                b.findField("trans_encrypt").setValue(true)
            } else {
                b.findField("trans_encrypt").setValue(false)
            }
        }
        this.callParent(arguments)
    }
});
Ext.define("SYNO.Backup.Addon.rsync.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    getSettingConfig: function() {
        var a = [{
            xtype: "syno_checkbox",
            boxLabel: _T("netbackup", "compression_enable"),
            name: "trans_compress",
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            name: "bandwidth_composite",
            items: [{
                xtype: "syno_checkbox",
                name: "bandwidthcheck",
                boxLabel: _T("backup", "limit_the_bandwidth"),
                scope: this,
                handler: function(c, b) {
                    if (b) {
                        this.getForm().findField("bw_limit").enable()
                    } else {
                        this.getForm().findField("bw_limit").disable()
                    }
                }
            }, {
                xtype: "syno_numberfield",
                disabled: true,
                name: "bw_limit",
                allowBlank: false,
                width: 100,
                minValue: 1,
                maxValue: 2147483647
            }, {
                xtype: "syno_displayfield",
                value: "KB/s"
            }]
        }];
        return a
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        if (b("bandwidthcheck")) {
            c.backup_params.bw_limit = b("bw_limit")
        } else {
            c.backup_params.bw_limit = 0
        }
        return c
    },
    activate: function() {
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "bandwidth_composite", false)
        } else {
            c(a, "bandwidth_composite", true);
            this.getForm().findField("bw_limit").setDisabled(!this.getForm().findField("bandwidthcheck").getValue())
        }
        this.callParent(arguments)
    }
});
Ext.define("SYNO.Backup.Addon.rsync_ds.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.rsync.Task.SettingPanel"
});
Ext.ns("SYNO.Backup.Addon.sfr_s3.Task");
Ext.define("SYNO.Backup.Addon.sfr_s3.Task.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Backup.ParamsPanel",
    loadPartSizeStore: function() {
        this.partSizeStore.loadData([
            ["8", 8],
            ["16", 16],
            ["32", 32],
            ["64", 64]
        ])
    },
    setDefaultSizeStore: function() {
        this.getForm().findField("part_size").setValue(64)
    }
});
Ext.ns("SYNO.Backup.Addon.webdav.Task");
Ext.define("SYNO.Backup.Addon.webdav.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel"
});
Ext.ns("SYNO.Backup.Addon.synocloud.Task");
Ext.define("SYNO.Backup.Addon.synocloud.Task.SettingPanel", {
    extend: "SYNO.Backup.Addon.Cloud.base.Task.SettingPanel",
    constructor: function(a) {
        a.disableDataComp = true;
        a.hideDataComp = true;
        return this.callParent([a])
    },
    getSettingConfig: function(a) {
        return [{
            xtype: "syno_checkbox",
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            labelSeparator: "",
            name: "trans_encrypt",
            checked: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            name: "bandwidth_composite",
            items: [{
                xtype: "syno_checkbox",
                name: "bandwidthcheck",
                boxLabel: _T("backup", "limit_the_bandwidth"),
                scope: this,
                handler: function(c, b) {
                    if (b) {
                        this.getForm().findField("bw_limit").enable();
                        this.getForm().findField("bw_limit_unit").enable()
                    } else {
                        this.getForm().findField("bw_limit").disable();
                        this.getForm().findField("bw_limit_unit").disable()
                    }
                }
            }, {
                xtype: "syno_numberfield",
                disabled: true,
                name: "bw_limit",
                allowBlank: false,
                width: 100,
                value: 256,
                minValue: 1,
                maxValue: 2147483647,
                validator: function(b) {
                    if ("KB" === this.ownerCt.get(2).value && 64 > b) {
                        return String.format(this.minText, "64 KB/s")
                    }
                    return true
                }
            }, {
                xtype: "syno_combobox",
                disabled: true,
                name: "bw_limit_unit",
                allowBlank: false,
                width: 80,
                displayField: "display",
                valueField: "value",
                value: "KB",
                store: new Ext.data.ArrayStore({
                    fields: ["value", "display"],
                    data: [
                        ["KB", "KB/s"],
                        ["MB", "MB/s"]
                    ]
                }),
                listeners: {
                    select: function() {
                        this.ownerCt.get(1).validate()
                    }
                }
            }]
        }]
    },
    activate: function() {
        var b = this.owner.getParams();
        var a = this.getForm();
        var c = function(f, e, d) {
            f.findField(e).setDisabled(!d);
            f.findField(e).setVisible(d)
        };
        if ("export" === b.action) {
            c(a, "bandwidth_composite", false)
        } else {
            c(a, "bandwidth_composite", true);
            this.getForm().findField("bw_limit").setDisabled(!this.getForm().findField("bandwidthcheck").getValue());
            this.getForm().findField("bw_limit_unit").setDisabled(!this.getForm().findField("bandwidthcheck").getValue())
        }
        this.callParent(arguments);
        if (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_CUSTOM !== this.owner.accountMeta.versionRotation) {
            this.nextId = null
        }
    },
    getParams: function() {
        var a = this.getForm(),
            b = function(d) {
                return a.findField(d).getValue()
            };
        var c = this.callParent(arguments);
        if (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_CUSTOM !== this.owner.accountMeta.versionRotation) {
            c.rotate_params = {};
            c.rotate_params.enable_rotate = true;
            c.rotate_params.rotate_option = "rotate_customize_retention";
            c.rotate_params.rotate_action = [
                [4838400, 604800, 1],
                [604800, 86400, 1]
            ];
            c.rotate_params.rotate_customized_rules = [
                [4838400, 604800, 1],
                [604800, 86400, 1]
            ];
            c.rotate_params.rotate_condition = [1, 14]
        }
        if (b("bandwidthcheck")) {
            if ("KB" === b("bw_limit_unit")) {
                c.backup_params.bw_limit = b("bw_limit") * 1024
            } else {
                c.backup_params.bw_limit = b("bw_limit") * 1024 * 1024
            }
        } else {
            c.backup_params.bw_limit = 0
        }
        return c
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.amazon_cloud_drive.Repository");
Ext.define("SYNO.SDS.Backup.Addon.amazon_cloud_drive.Repository.CreateContainer", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.access_token = b.access_token;
        this.refresh_token = b.refresh_token;
        this.addon_id = b.addon_id;
        var c = [{
            xtype: "syno_textfield",
            name: "container",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("validator", "name_no_slash")
                } else {
                    if (1 > f.length || 280 < f.length) {
                        return String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "280")
                    }
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_access_token: this.access_token,
            remote_refresh_token: this.refresh_token,
            transfer_type: this.addon_id,
            container: this.items.get(0).getForm().findField("container").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.AmazonCloudDrive.Container",
            version: 1,
            method: "create",
            encryption: ["remote_access_token", "remote_refresh_token"],
            params: a,
            scope: this,
            callback: function(e, c, d) {
                var b = this.items.get(0).getForm().findField("container").getValue();
                this.clearStatusBusy();
                if (!e) {
                    this.showPossibleContainerError(c.code, b);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleContainerError: function(a, b) {
        var c = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            c = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
            return
        }
        if (b.match(/[//]/)) {
            c = c.concat("<BR>- ", SYNO.SDS.Backup.String("validator", "name_no_slash"))
        }
        if (1 > b.length || 280 < b.length) {
            c = c.concat("<BR>- ", String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "280"))
        }
        if (c.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("amazon_cloud_drive", "folder_name_invalid") + " " + SYNO.SDS.Backup.String("amazon_cloud_drive", "name_meet_condition") + " " + _T("common", "colon") + c);
            return
        }
        c = SYNO.SDS.Backup.String("amazon_cloud_drive", "folder_name_invalid");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.amazon_cloud_drive.Destination");
Ext.define("SYNO.Backup.Addon.amazon_cloud_drive.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "amazon_cloud_drive",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "container",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            store: this.getContainerStore(),
            displayField: "container",
            allowBlank: false,
            valueField: "container",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainer()) {
                    this.scope.loadContainerStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createContainer();
                            return
                        }
                        this.updateTarget(c.get("bucket"))
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.container)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{container:htmlEncode}</div></tpl>'
        }];
        return a
    },
    createContainer: function() {
        var a = new SYNO.SDS.Backup.Addon.amazon_cloud_drive.Repository.CreateContainer({
            access_token: this.access_token,
            refresh_token: this.refresh_token,
            addon_id: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var c = this.getLayoutPrefix(this.action);
            var b = a.items.get(0).getForm().findField("container").getValue();
            this.getForm().findField(c + "container").clearValue();
            this.loadContainerStore(b)
        }, this);
        a.open()
    },
    getContainerStore: function() {
        if (!this.containerStore) {
            this.containerStore = new Ext.data.ArrayStore({
                fields: ["container", "status", "conflict_repo"]
            })
        }
        return this.containerStore
    },
    getLoadContainerParams: function() {
        var a = this.getParams();
        delete a.container;
        delete a.target_id;
        return a
    },
    needReloadContainer: function() {
        var a = this.getLoadContainerParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadContainerStore: function(a) {
        var b = this.getLoadContainerParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.AmazonCloudDrive.Container",
            version: 1,
            method: "list",
            encryption: ["remote_access_token", "remote_refresh_token"],
            params: b,
            scope: this,
            callback: function(i, c, d) {
                this.owner.clearStatusBusy();
                if (!i) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                var h;
                var g = this.getLayoutPrefix(this.action);
                this.getContainerStore().loadData(c.container_list);
                if ("create" === this.action) {
                    h = this.getForm().findField(g + "container");
                    var e = new Ext.data.Record.create(["container", "status", "conflict_repo"]);
                    var f = new e({
                        container: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getContainerStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        h = this.getForm().findField(g + "container")
                    }
                }
                if (a && -1 !== this.getContainerStore().findExact("container", a) && 0 === this.getContainerStore().getAt(this.getContainerStore().findExact("container", a)).get("status")) {
                    h.setValue(a);
                    h.collapse();
                    this.updateTarget()
                } else {
                    if (h) {
                        h.el.focus();
                        h.expand();
                        h.restrictHeight()
                    }
                }
            }
        })
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("container")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token;
        this.refresh_token = a.refresh_token
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_access_token = this.access_token;
            d.remote_refresh_token = this.refresh_token;
            d.container = c("container")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.aws_s3.Destination");
Ext.define("SYNO.Backup.Addon.aws_s3.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "aws_s3",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "server",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            store: this.getServerStore(),
            fieldLabel: _T("backup", "s3_server"),
            displayField: "server",
            valueField: "value",
            value: "aws_s3",
            editable: false,
            listeners: {
                select: function(e, c, d) {
                    this.changeLayout(this.action, c.get("value"))
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            name: b + "remote_url",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "url"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            name: b + "signature_version",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            store: this.getSignatureStore(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "signature_version"),
            displayField: "version",
            valueField: "value",
            value: "v2",
            editable: false,
            hidden: true,
            disabled: true,
            listeners: {
                scope: this,
                select: function(d, c) {
                    if ("v4" === c.get("value")) {
                        this.getForm().findField(b + "request_style").setVisible(true);
                        this.getForm().findField(b + "request_style").setDisabled(false)
                    } else {
                        this.getForm().findField(b + "request_style").setVisible(false);
                        this.getForm().findField(b + "request_style").setDisabled(true)
                    }
                    this.doLayout()
                }
            }
        }, {
            xtype: "syno_combobox",
            name: b + "request_style",
            indent: 1,
            width: 270,
            allowBlank: false,
            store: this.getUrlStyleStore(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "request_style"),
            displayField: "style",
            valueField: "value",
            value: "virtual_host_style",
            editable: false,
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_textfield",
            name: b + "key",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            inputType: "password",
            fieldLabel: _T("backup", "s3_secret_key")
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            width: 270,
            indent: this.getFieldIndent(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    onFieldsetSelected: function(a) {
        var b = a.get(0);
        if (!b) {
            return
        }
        if ("create_fields" === a.name || "relink_fields" === a.name) {
            this.changeLayout(this.action, b.getValue())
        }
    },
    getServerStore: function() {
        if (!this.serverStore) {
            this.serverStore = new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "name"), "aws_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "name") + " " + SYNO.SDS.Backup.String("aws_s3", "s3_region_system_china"), "aws_cn_s3"],
                    [SYNO.SDS.Backup.String("aws_s3", "custom_address"), "s3_compatible"]
                ]
            })
        }
        return this.serverStore
    },
    getSignatureStore: function() {
        if (!this.signatureStore) {
            this.signatureStore = new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["v2", "v2"],
                    ["v4", "v4"]
                ]
            })
        }
        return this.signatureStore
    },
    getUrlStyleStore: function() {
        if (!this.urlStyleStore) {
            this.urlStyleStore = new Ext.data.ArrayStore({
                fields: ["style", "value"],
                data: [
                    [SYNO.SDS.Backup.String("aws_s3", "virtual_host_style"), "virtual_host_style"],
                    [SYNO.SDS.Backup.String("aws_s3", "path_style"), "path_style"]
                ]
            })
        }
        return this.urlStyleStore
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    changeLayout: function(g, f) {
        var e = this.getLayoutPrefix(g);
        var d = this.getForm();
        var c = this;
        var a = function(i, h) {
            d.findField(e + i).setDisabled(!h);
            d.findField(e + i).setVisible(h);
            c.doLayout()
        };
        var b = function(h) {
            a("remote_url", h);
            a("signature_version", h)
        };
        if ("s3_compatible" === f) {
            b(true)
        } else {
            b(false)
        }
        if ("s3_compatible" === f && "v4" === d.findField(e + "signature_version").getValue()) {
            a("request_style", true)
        } else {
            a("request_style", false)
        }
    },
    getRemoteUrlValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("s3_compatible" === c("server")) {
            return c("remote_url")
        }
        return ""
    },
    getSignatureValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("s3_compatible" === c("server")) {
            return c("signature_version")
        }
        return ""
    },
    getRequestStyleValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("s3_compatible" === c("server") && "v4" === c("signature_version")) {
            return c("request_style")
        } else {
            return "virtual_host_style"
        }
    },
    createBucket: function() {
        var b = this.getParams();
        b.owner = this.owner;
        var a = new SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateBucket(b);
        this.mon(a, "close", function() {
            var c = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField("create_bucket").clearValue();
            this.loadBucketStore(c)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.S3.Bucket",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField("create_bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: _T("backup", "s3_create_bucket"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField("relink_bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(e) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            d = function(g) {
                return b.findField(c + g).getValue()
            };
        var a = function(g) {
            return b.findField(c + g).isValid()
        };
        if ("s3_compatible" === d("server")) {
            if (a("server") && a("remote_url") && a("key") && a("secret") && a("signature_version")) {
                return true
            }
        } else {
            if (a("server") && a("key") && a("secret")) {
                return true
            }
        }
        e.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if ("s3_compatible" === d.transfer_type) {
            if (a("server") && a("remote_url") && a("key") && a("secret") && a("signature_version") && a("bucket")) {
                return true
            }
        } else {
            if (a("server") && a("key") && a("secret") && a("bucket")) {
                return true
            }
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var c = this.callParent();
        var a = this.getForm().getFieldValues();
        if ("create" === this.action) {
            c.server = a.create_server;
            c.key = a.create_key;
            c.secret = a.create_secret;
            c.bucket = a.create_bucket
        } else {
            if ("relink" === this.action || "import" === this.action) {
                c.server = a.relink_server;
                c.key = a.relink_key;
                c.secret = a.relink_secret;
                c.bucket = a.relink_bucket
            }
        }
        var b = c.server;
        if ("aws_s3" === b) {
            c.transfer_type = "aws_s3";
            c.support_region = true;
            c.region_system = "s3_global";
            c.remote_url = undefined;
            c.signature_version = undefined
        } else {
            if ("aws_cn_s3" === b) {
                c.transfer_type = "aws_s3";
                c.support_region = true;
                c.region_system = "s3_china";
                c.remote_url = undefined;
                c.signature_version = undefined
            } else {
                c.transfer_type = "aws_s3";
                c.support_region = false;
                c.remote_url = this.getRemoteUrlValue();
                c.signature_version = this.getSignatureValue()
            }
        }
        c.request_style = this.getRequestStyleValue(b);
        return c
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.image_azure_blob.Repository");
Ext.define("SYNO.SDS.Backup.Addon.image_azure_blob.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.s3key = b.s3key;
        this.s3secret = b.s3secret;
        this.addon_id = b.addon_id;
        this.transfer_type = b.transfer_type;
        var c = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container"),
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_container"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            key: this.s3key,
            secret: this.s3secret,
            transfer_type: this.transfer_type,
            container: this.items.get(0).getForm().findField("bucket").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "create",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                var e = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!d) {
                    this.showPossibleBucketError(b.code, e);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, c) {
        var b = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            b = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
            return
        }
        if (!c.match(/^[a-z0-9-]*$/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_letter_limit"))
        }
        if (!c.match(/^[a-z0-9]/) || !c.match(/[a-z0-9]$/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_leading_letter_limit"))
        }
        if (3 > c.length || 63 < c.length) {
            b = b.concat("<BR>- ", String.format(_T("netbackup", "s3_bucket_name_length_limit"), "3", "63"))
        }
        if (c.match(/--/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_dash_limit"))
        }
        if (b.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_invalid_short") + " " + SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_meet_condition") + " " + _T("common", "colon") + b);
            return
        }
        b = SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_invalid_short");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.azure_blob.Destination");
Ext.define("SYNO.Backup.Addon.azure_blob.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "azure_blob",
    constructor: function(a) {
        this.uni_key = null;
        this.createFields = this.getCreateAuthFields();
        this.relinkFields = this.getRelinkAuthFields();
        return this.callParent(arguments)
    },
    getCreateAuthFields: function() {
        var a = [{
            xtype: "syno_combobox",
            indent: 1,
            width: 270,
            name: "server",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "provider"),
            store: new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name"), "azure_blob"],
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name_cn"), "azure_cn_blob"]
                ]
            }),
            value: "azure_blob",
            displayField: "server",
            valueField: "value",
            editable: false,
            listeners: {
                select: function(d, b, c) {
                    this.transfer_type = b.get("value")
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            name: "create_key",
            indent: 1,
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "storage_account")
        }, {
            xtype: "syno_textfield",
            name: "create_secret",
            indent: 1,
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "access_key")
        }, {
            xtype: "syno_combobox",
            name: "create_bucket",
            indent: 1,
            width: 270,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(d, b, c) {
                    if (c === 0) {
                        this.createBucket();
                        return
                    }
                    if ("create" === this.action) {
                        this.updateTarget(b.get("bucket"))
                    }
                },
                beforeselect: function(c, b, d) {
                    if (b.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getRelinkAuthFields: function() {
        var a = [{
            xtype: "syno_combobox",
            indent: 1,
            width: 270,
            name: "server",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "provider"),
            store: new Ext.data.ArrayStore({
                fields: ["server", "value"],
                data: [
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name"), "azure_blob"],
                    [SYNO.Backup.Addon.Util.getString(this.addon_id, "name_cn"), "azure_cn_blob"]
                ]
            }),
            value: "azure_blob",
            displayField: "server",
            valueField: "value",
            editable: false,
            listeners: {
                select: function(d, b, c) {
                    this.transfer_type = b.get("value")
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            name: "relink_key",
            indent: 1,
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "storage_account")
        }, {
            xtype: "syno_textfield",
            name: "relink_secret",
            indent: 1,
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "access_key")
        }, {
            xtype: "syno_combobox",
            name: "relink_bucket",
            indent: 1,
            width: 270,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                beforeselect: function(c, b, d) {
                    if (b.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    createBucket: function() {
        var a = new SYNO.SDS.Backup.Addon.image_azure_blob.Repository.CreateBucket({
            s3key: this.getForm().findField("create_key").getValue(),
            s3secret: this.getForm().findField("create_secret").getValue(),
            addon_id: this.addon_id,
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var b = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField("create_bucket").clearValue();
            this.loadBucketStore(b)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                var g;
                this.getBucketStore().loadData(c.bucket_list);
                if ("create" === this.action) {
                    g = this.getForm().findField("create_bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_container"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField("relink_bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(b) {
        var a = b.ownerCt;
        if (a.get(1).isValid() && a.get(2).isValid()) {
            return true
        } else {
            b.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        }
        return false
    },
    relinkValidator: function(b, c) {
        var a = b.ownerCt;
        if (a.get(1).isValid() && a.get(2).isValid() && a.get(3).isValid()) {
            return true
        } else {
            b.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        }
        return false
    },
    getParams: function() {
        var b = this.callParent();
        var a = this.getForm().getFieldValues();
        if ("create" === this.action) {
            b.key = a.create_key;
            b.secret = a.create_secret;
            b.bucket = a.create_bucket
        } else {
            if ("relink" === this.action || "import" === this.action) {
                b.key = a.relink_key;
                b.secret = a.relink_secret;
                b.bucket = a.relink_bucket
            }
        }
        return b
    }
});
Ext.ns("SYNO.Backup.Addon.azure_cn_blob.Destination");
Ext.define("SYNO.Backup.Addon.azure_cn_blob.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.azure_blob.Destination.SettingPanel"
});
Ext.ns("SYNO.SDS.Backup.Addon.dropbox.Repository");
Ext.define("SYNO.SDS.Backup.Addon.dropbox.Repository.CreateContainer", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.access_token = b.access_token;
        this.addon_id = b.addon_id;
        var c = [{
            xtype: "syno_textfield",
            name: "container",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("validator", "name_no_slash")
                } else {
                    if (f.match(/[\\]/)) {
                        return SYNO.SDS.Backup.String("validator", "name_no_backslash")
                    } else {
                        if (1 > f.length || 255 < f.length) {
                            return String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "255")
                        }
                    }
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_access_token: this.access_token,
            transfer_type: this.addon_id,
            container: this.items.get(0).getForm().findField("container").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Dropbox.Container",
            version: 1,
            method: "create",
            encryption: ["remote_access_token"],
            params: a,
            scope: this,
            callback: function(e, c, d) {
                var b = this.items.get(0).getForm().findField("container").getValue();
                this.clearStatusBusy();
                if (!e) {
                    this.showPossibleContainerError(c.code, b);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleContainerError: function(a, b) {
        var c = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            c = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
            return
        }
        if (b.match(/[//]/)) {
            c = c.concat("<BR>- ", SYNO.SDS.Backup.String("validator", "name_no_slash"))
        }
        if (b.match(/[\\]/)) {
            c = c.concat("<BR>- ", SYNO.SDS.Backup.String("validator", "name_no_backslash"))
        }
        if (1 > b.length || 255 < b.length) {
            c = c.concat("<BR>- ", String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "255"))
        }
        if (c.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("dropbox", "folder_name_invalid") + " " + SYNO.SDS.Backup.String("dropbox", "name_meet_condition") + " " + _T("common", "colon") + c);
            return
        }
        c = SYNO.SDS.Backup.String("dropbox", "folder_name_invalid");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.dropbox.Destination");
Ext.define("SYNO.Backup.Addon.dropbox.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "dropbox",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "container",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            store: this.getContainerStore(),
            displayField: "container",
            allowBlank: false,
            valueField: "container",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainer()) {
                    this.scope.loadContainerStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createContainer();
                            return
                        }
                        this.updateTarget(c.get("bucket"))
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.container)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{container:htmlEncode}</div></tpl>'
        }];
        return a
    },
    createContainer: function() {
        var a = new SYNO.SDS.Backup.Addon.dropbox.Repository.CreateContainer({
            access_token: this.access_token,
            addon_id: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var c = this.getLayoutPrefix(this.action);
            var b = a.items.get(0).getForm().findField("container").getValue();
            this.getForm().findField(c + "container").clearValue();
            this.loadContainerStore(b)
        }, this);
        a.open()
    },
    getContainerStore: function() {
        if (!this.containerStore) {
            this.containerStore = new Ext.data.ArrayStore({
                fields: ["container", "status", "conflict_repo"],
                sortInfo: {
                    field: "container",
                    direction: "ASC"
                }
            })
        }
        return this.containerStore
    },
    getLoadContainerParams: function() {
        var a = this.getParams();
        delete a.container;
        delete a.target_id;
        return a
    },
    needReloadContainer: function() {
        var a = this.getLoadContainerParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadContainerStore: function(a) {
        var b = this.getLoadContainerParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Dropbox.Container",
            version: 1,
            method: "list",
            encryption: ["remote_access_token"],
            params: b,
            scope: this,
            callback: function(i, c, d) {
                this.owner.clearStatusBusy();
                if (!i) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                var h;
                var g = this.getLayoutPrefix(this.action);
                this.getContainerStore().loadData(c.container_list);
                if ("create" === this.action) {
                    h = this.getForm().findField(g + "container");
                    var e = new Ext.data.Record.create(["container", "status", "conflict_repo"]);
                    var f = new e({
                        container: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getContainerStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        h = this.getForm().findField(g + "container")
                    }
                }
                if (a && -1 !== this.getContainerStore().findExact("container", a) && 0 === this.getContainerStore().getAt(this.getContainerStore().findExact("container", a)).get("status")) {
                    h.setValue(a);
                    h.collapse();
                    this.updateTarget()
                } else {
                    if (h) {
                        h.el.focus();
                        h.expand();
                        h.restrictHeight()
                    }
                }
            }
        })
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("container")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_access_token = this.access_token;
            d.container = c("container")
        }
        return d
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.google_drive.Repository");
Ext.define("SYNO.SDS.Backup.Addon.google_drive.Repository.CreateContainer", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.access_token = b.access_token;
        this.refresh_token = b.refresh_token;
        this.addon_id = b.addon_id;
        var c = [{
            xtype: "syno_textfield",
            name: "container",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("validator", "name_no_slash")
                } else {
                    if (1 > f.length || 255 < f.length) {
                        return String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "255")
                    }
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_access_token: this.access_token,
            remote_refresh_token: this.refresh_token,
            transfer_type: this.addon_id,
            container: this.items.get(0).getForm().findField("container").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.GoogleDrive.Container",
            version: 1,
            method: "create",
            encryption: ["remote_access_token", "remote_refresh_token"],
            params: a,
            scope: this,
            callback: function(e, c, d) {
                var b = this.items.get(0).getForm().findField("container").getValue();
                this.clearStatusBusy();
                if (!e) {
                    this.showPossibleContainerError(c.code, b);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleContainerError: function(a, b) {
        var c = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            c = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
            return
        }
        if (b.match(/[//]/)) {
            c = c.concat("<BR>- ", SYNO.SDS.Backup.String("validator", "name_no_slash"))
        }
        if (1 > b.length || 255 < b.length) {
            c = c.concat("<BR>- ", String.format(SYNO.SDS.Backup.String("validator", "name_length_limit"), "1", "255"))
        }
        if (c.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("google_drive", "folder_name_invalid") + " " + SYNO.SDS.Backup.String("google_drive", "name_meet_condition") + " " + _T("common", "colon") + c);
            return
        }
        c = SYNO.SDS.Backup.String("google_drive", "folder_name_invalid");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.google_drive.Destination");
Ext.define("SYNO.Backup.Addon.google_drive.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "google_drive",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "container",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "root_folder_name"),
            store: this.getContainerStore(),
            displayField: "container",
            allowBlank: false,
            valueField: "container",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainer()) {
                    this.scope.loadContainerStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createContainer();
                            return
                        }
                        this.updateTarget(c.get("bucket"))
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.container)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{container:htmlEncode}</div></tpl>'
        }];
        return a
    },
    createContainer: function() {
        var a = new SYNO.SDS.Backup.Addon.google_drive.Repository.CreateContainer({
            access_token: this.access_token,
            refresh_token: this.refresh_token,
            addon_id: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var c = this.getLayoutPrefix(this.action);
            var b = a.items.get(0).getForm().findField("container").getValue();
            this.getForm().findField(c + "container").clearValue();
            this.loadContainerStore(b)
        }, this);
        a.open()
    },
    getContainerStore: function() {
        if (!this.containerStore) {
            this.containerStore = new Ext.data.ArrayStore({
                fields: ["container", "status", "conflict_repo"]
            })
        }
        return this.containerStore
    },
    getLoadContainerParams: function() {
        var a = this.getParams();
        delete a.container;
        delete a.target_id;
        return a
    },
    needReloadContainer: function() {
        var a = this.getLoadContainerParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadContainerStore: function(a) {
        var b = this.getLoadContainerParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.GoogleDrive.Container",
            version: 1,
            method: "list",
            encryption: ["remote_access_token", "remote_refresh_token"],
            params: b,
            scope: this,
            callback: function(i, c, d) {
                this.owner.clearStatusBusy();
                if (!i) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                var h;
                var g = this.getLayoutPrefix(this.action);
                this.getContainerStore().loadData(c.container_list);
                if ("create" === this.action) {
                    h = this.getForm().findField(g + "container");
                    var e = new Ext.data.Record.create(["container", "status", "conflict_repo"]);
                    var f = new e({
                        container: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_root_folder"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getContainerStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        h = this.getForm().findField(g + "container")
                    }
                }
                if (a && -1 !== this.getContainerStore().findExact("container", a) && 0 === this.getContainerStore().getAt(this.getContainerStore().findExact("container", a)).get("status")) {
                    h.setValue(a);
                    h.collapse();
                    this.updateTarget()
                } else {
                    if (h) {
                        h.el.focus();
                        h.expand();
                        h.restrictHeight()
                    }
                }
            }
        })
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("container")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    setOauthResponse: function(a) {
        this.access_token = a.access_token;
        this.refresh_token = a.refresh_token
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_refresh_token = this.refresh_token;
            d.container = c("container")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.hicloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.hicloud_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Repository.CreateStep",
    addon_id: "image_hicloud"
});
Ext.ns("SYNO.Backup.Addon.jdcloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.jdcloud_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Repository.CreateStep",
    addon_id: "image_jdcloud",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.descriptionFields = this.getDescriptionFields();
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "region",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            store: this.getRegionStore(),
            fieldLabel: _T("backup", "s3_server_region"),
            displayField: "region",
            valueField: "value",
            value: "cn-north-1",
            editable: false
        }, {
            xtype: "syno_textfield",
            name: b + "key",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            fieldLabel: _T("backup", "s3_access_key")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            inputType: "password",
            fieldLabel: _T("backup", "s3_secret_key")
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            width: 270,
            indent: this.getFieldIndent(),
            fieldLabel: SYNO.SDS.Backup.String("aws_s3", "bucket_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getDescriptionFields: function() {
        var a = [{
            xtype: "syno_displayfield",
            indent: this.getFieldIndent(),
            cls: "syno-backup-base-destination-description",
            htmlEncode: false,
            name: "get_keys",
            value: '<font class="note-font">' + _T("common", "note") + ": </font>" + SYNO.SDS.Backup.String("jdcloud_s3", "get_keys_desc")
        }];
        return a
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["region", "value"],
                data: [
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_north_1"), "cn-north-1"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_east_1"), "cn-east-1"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_east_2"), "cn-east-2"],
                    [SYNO.SDS.Backup.String("jdcloud_s3", "region_cn_south_1"), "cn-south-1"]
                ]
            })
        }
        return this.regionStore
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm();
        var a = function(e) {
            return b.findField(c + e).isValid()
        };
        if (a("region") && a("key") && a("secret")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("region") && a("key") && a("secret") && a("bucket")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var b = this.callParent();
        var a = this.getForm().getFieldValues();
        if ("create" === this.action) {
            b.region_system = a.create_region;
            b.key = a.create_key;
            b.secret = a.create_secret;
            b.bucket = a.create_bucket
        } else {
            if ("relink" === this.action || "import" === this.action) {
                b.region_system = a.relink_region;
                b.key = a.relink_key;
                b.secret = a.relink_secret;
                b.bucket = a.relink_bucket
            }
        }
        b.request_style = "virtual_host_style";
        b.server = this.transfer_type;
        b.transfer_type = this.transfer_type;
        b.support_region = true;
        return b
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.hidrive.Repository");
Ext.define("SYNO.SDS.Backup.Addon.hidrive.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.dest = b.dest;
        this.encrypt_connect = b.encrypt_connect;
        this.account = b.account;
        this.pwd = b.pwd;
        this.transfer_type = b.transfer_type;
        var c = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "root_folder"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("hidrive", "root_folder_name_letter_limit")
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.SDS.Backup.String("hidrive", "create_root_folder"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            dest: this.dest,
            encrypt_connect: this.encrypt_connect,
            account: this.account,
            pwd: this.pwd,
            transfer_type: this.transfer_type,
            container: this.items.get(0).getForm().findField("bucket").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.HiDrive.Container",
            version: 1,
            method: "create",
            encryption: ["pwd"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                var e = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!d) {
                    this.showPossibleBucketError(b.code, e);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, c) {
        var b = SYNO.SDS.Backup.GetErrorString(a);
        this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.hidrive.Destination");
Ext.define("SYNO.Backup.Addon.hidrive.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "dest",
            indent: this.getFieldIndent(),
            width: 270,
            value: "rsync.hidrive.strato.com",
            editable: false,
            hidden: true
        }, {
            xtype: "syno_checkbox",
            name: b + "encrypt_connect",
            indent: this.getFieldIndent(),
            boxLabel: SYNO.SDS.Backup.String("app", "enable_encrypted_transmission"),
            checked: true,
            editable: false,
            hidden: true
        }, {
            xtype: "syno_textfield",
            name: b + "account",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "username")
        }, {
            xtype: "syno_textfield",
            name: b + "pwd",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input")
        }, {
            xtype: "syno_combobox",
            name: b + "module",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("hidrive", "root_folder_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget(c.get("bucket"))
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    createBucket: function() {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            d = function(e) {
                return b.findField(c + e).getValue()
            };
        var a = new SYNO.SDS.Backup.Addon.hidrive.Repository.CreateBucket({
            dest: d("dest"),
            encrypt_connect: d("encrypt_connect"),
            account: d("account"),
            pwd: d("pwd"),
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var e = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField(this.getLayoutPrefix(this.action) + "module").clearValue();
            this.loadBucketStore(e)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.HiDrive.Container",
            version: 1,
            method: "list",
            encryption: ["pwd"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField(this.getLayoutPrefix(this.action) + "module");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.SDS.Backup.String("hidrive", "create_root_folder"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField(this.getLayoutPrefix(this.action) + "module")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            a = function(e) {
                return b.findField(c + e).isValid()
            };
        if (a("dest") && a("encrypt_connect") && a("account") && a("pwd")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("dest") && a("encrypt_connect") && a("account") && a("pwd") && a("module")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.dest = c("dest");
            d.encrypt_connect = c("encrypt_connect");
            d.account = c("account");
            d.pwd = c("pwd");
            d.module = "/users/" + c("account") + "/" + c("module")
        }
        return d
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.hubic_swift.Repository");
Ext.define("SYNO.SDS.Backup.Addon.hubic_swift.Repository.CreateContainer", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.refresh_token = b.refresh_token;
        this.addon_id = b.addon_id;
        var c = [{
            xtype: "syno_textfield",
            name: "container",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("hubic", "container"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("hubic", "container_name_letter_limit")
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.SDS.Backup.String("hubic", "create_container"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_refresh_token: this.refresh_token,
            transfer_type: this.addon_id,
            container: this.items.get(0).getForm().findField("container").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.hubiC.Container",
            version: 1,
            method: "create",
            encryption: ["remote_refresh_token"],
            params: a,
            scope: this,
            callback: function(e, b, c) {
                var d = this.items.get(0).getForm().findField("container").getValue();
                this.clearStatusBusy();
                if (!e) {
                    this.showPossibleBucketError(b.code, d);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, b) {
        var c = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            c = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
            return
        }
        if (b.match(/[//]/)) {
            c = c.concat("<BR>- ", SYNO.SDS.Backup.String("hubic", "container_name_letter_limit"))
        }
        if (1 > b.length || 256 < b.length) {
            c = c.concat("<BR>- ", String.format(SYNO.SDS.Backup.String("hubic", "container_name_length_limit"), "1", "256"))
        }
        if (c.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("hubic", "container_name_invalid_short") + " " + SYNO.SDS.Backup.String("hubic", "container_name_meet_condition") + " " + _T("common", "colon") + c);
            return
        }
        c = SYNO.SDS.Backup.String("hubic", "container_name_invalid_short");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), c);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.hubic.Destination");
Ext.define("SYNO.Backup.Addon.hubic.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    addon_id: "hubic_swift",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        if (false === SYNO.Backup.Addon.Config.supportProtectType && "create" === this.action) {
            this.supportCreate = false;
            this.supportExport = false
        }
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getRelinkFields: function() {
        var a = this.callParent(arguments);
        a[0].hidden = (a[0].hidden && "import" === this.action);
        if (!a[0].hidden && false === SYNO.Backup.Addon.Config.supportProtectType && "create" === this.action) {
            a[0].checked = true;
            this.action = "relink"
        }
        return a
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_combobox",
            name: b + "container",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("hubic", "container"),
            store: this.getContainerStore(),
            displayField: "container",
            allowBlank: false,
            valueField: "container",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (this.scope.needReloadContainer()) {
                    this.scope.loadContainerStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createContainer();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.container)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{container:htmlEncode}</div></tpl>'
        }];
        return a
    },
    createContainer: function() {
        var a = new SYNO.SDS.Backup.Addon.hubic_swift.Repository.CreateContainer({
            refresh_token: this.refresh_token,
            addon_id: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var c = this.getLayoutPrefix(this.action);
            var b = a.items.get(0).getForm().findField("container").getValue();
            this.getForm().findField(c + "container").clearValue();
            this.loadContainerStore(b)
        }, this);
        a.open()
    },
    getContainerStore: function() {
        if (!this.containerStore) {
            this.containerStore = new Ext.data.ArrayStore({
                fields: ["container", "status", "conflict_repo"]
            })
        }
        return this.containerStore
    },
    getLoadContainerParams: function() {
        var a = this.getParams();
        delete a.container;
        delete a.target_id;
        return a
    },
    needReloadContainer: function() {
        var a = this.getLoadContainerParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadContainerStore: function(a) {
        var b = this.getLoadContainerParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.hubiC.Container",
            version: 1,
            method: "list",
            encryption: ["remote_refresh_token"],
            params: b,
            scope: this,
            callback: function(i, c, d) {
                this.owner.clearStatusBusy();
                if (!i) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                var h;
                var g = this.getLayoutPrefix(this.action);
                this.getContainerStore().loadData(c.container_list);
                if ("create" === this.action) {
                    h = this.getForm().findField(g + "container");
                    var e = new Ext.data.Record.create(["container", "status", "conflict_repo"]);
                    var f = new e({
                        container: SYNO.SDS.Backup.String("hubic", "create_container"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getContainerStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        h = this.getForm().findField(g + "container")
                    }
                }
                if (a && -1 !== this.getContainerStore().findExact("container", a) && 0 === this.getContainerStore().getAt(this.getContainerStore().findExact("container", a)).get("status")) {
                    h.setValue(a);
                    h.collapse();
                    this.updateTarget()
                } else {
                    if (h) {
                        h.el.focus();
                        h.expand();
                        h.restrictHeight()
                    }
                }
            }
        })
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("container")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    setOauthResponse: function(a) {
        this.refresh_token = a.refresh_token
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_refresh_token = this.refresh_token;
            d.container = c("container")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.ibm_softlayer.Destination");
Ext.define("SYNO.Backup.Addon.ibm_softlayer.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "key",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        }, {
            xtype: "syno_combobox",
            name: b + "region_ibm",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: SYNO.SDS.Backup.Addon.Util.Image.OpenStack.ibm_softlayer_region_list(),
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            }),
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            displayField: "display",
            valueField: "value",
            editable: false
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    getRemoteUrlValue: function() {
        return ""
    },
    getRegionValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("region_ibm")
    },
    getUsernameValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("key")
    },
    getSecretValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("secret")
    },
    getTenantId: function() {
        return ""
    },
    getTenantName: function() {
        return ""
    },
    getDomainId: function() {
        return ""
    },
    getDomainName: function() {
        return ""
    },
    getAuthVersion: function() {
        return ""
    },
    createBucket: function() {
        var a = new SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Repository.CreateBucket({
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            s3key: this.getUsernameValue(),
            s3secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var b = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket").clearValue();
            this.loadBucketStore(b)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastBucketQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastBucketQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.SDS.Backup.String("openstack", "create_container"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm();
        var a = function(e) {
            return b.findField(c + e).isValid()
        };
        if (a("region_ibm") && a("key") && a("secret")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("region_ibm") && a("key") && a("secret") && a("bucket")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_url = this.getRemoteUrlValue();
            d.region = this.getRegionValue();
            d.key = this.getUsernameValue();
            d.secret = this.getSecretValue();
            d.tenant_id = this.getTenantId();
            d.tenant_name = this.getTenantName();
            d.domain_id = this.getDomainId();
            d.domain_name = this.getDomainName();
            d.auth_version = this.getAuthVersion();
            d.bucket = c("bucket")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_aws_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_aws_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "aws_s3",
            support_region: true
        }, a);
        return this.callParent([b])
    }
});
Ext.ns("SYNO.SDS.Backup.Addon.azure_blob.Repository");
Ext.define("SYNO.SDS.Backup.Addon.azure_blob.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.s3key = b.s3key;
        this.s3secret = b.s3secret;
        this.addon_id = b.addon_id;
        var c = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container"),
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_container"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            key: this.s3key,
            secret: this.s3secret,
            transfer_type: this.addon_id,
            container: this.items.get(0).getForm().findField("bucket").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "create",
            params: a,
            scope: this,
            callback: function(d, b, c) {
                var e = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!d) {
                    this.showPossibleBucketError(b.code, e);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, c) {
        var b = "";
        if (a !== SYNO.SDS.Backup.ERR_NAME_NOT_VALID) {
            b = SYNO.SDS.Backup.GetErrorString(a);
            this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
            return
        }
        if (!c.match(/^[a-z0-9-]*$/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_letter_limit"))
        }
        if (!c.match(/^[a-z0-9]/) || !c.match(/[a-z0-9]$/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_leading_letter_limit"))
        }
        if (3 > c.length || 63 < c.length) {
            b = b.concat("<BR>- ", String.format(_T("netbackup", "s3_bucket_name_length_limit"), "3", "63"))
        }
        if (c.match(/--/)) {
            b = b.concat("<BR>- ", SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_dash_limit"))
        }
        if (b.length > 0) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_invalid_short") + " " + SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_meet_condition") + " " + _T("common", "colon") + b);
            return
        }
        b = SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name_invalid_short");
        this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_azure_blob.Destination");
Ext.define("SYNO.Backup.Addon.legacy_azure_blob.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        this.addon_id = "azure_blob";
        var b = Ext.apply({
            items: [{
                xtype: "syno_fieldset",
                title: SYNO.Backup.Addon.Util.getString(this.addon_id, "repo_wizard_headline"),
                collapsible: false,
                defaults: {
                    labelWidth: 300
                },
                items: [{
                    xtype: "syno_textfield",
                    name: "name",
                    value: SYNO.Backup.Addon.Util.getString(this.addon_id, "repo_name_prefix") || "My Storage",
                    allowBlank: false,
                    fieldLabel: _T("backup", "repo_name"),
                    maxLength: 32,
                    vtype: "backup_destination",
                    hidden: true
                }, {
                    xtype: "syno_textfield",
                    name: "key",
                    allowBlank: false,
                    fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "storage_account")
                }, {
                    xtype: "syno_textfield",
                    name: "secret",
                    allowBlank: false,
                    inputType: "password",
                    fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "access_key")
                }, {
                    xtype: "syno_combobox",
                    name: "bucket",
                    fieldLabel: SYNO.Backup.Addon.Util.getString(this.addon_id, "container_name"),
                    store: this.getBucketStore(),
                    displayField: "bucket",
                    allowBlank: false,
                    valueField: "bucket",
                    scope: this,
                    onTriggerClick: function() {
                        if (this.readOnly || this.disabled) {
                            return
                        }
                        if (this.scope.needReloadBucket()) {
                            this.scope.loadBucketStore()
                        } else {
                            SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                        }
                    },
                    listeners: {
                        select: function(e, c, d) {
                            if (d === 0) {
                                this.createBucket();
                                return
                            }
                        },
                        beforeselect: function(d, c, e) {
                            if (c.get("status") > 0) {
                                return false
                            }
                        },
                        scope: this
                    },
                    tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
                }]
            }]
        }, a);
        return this.callParent([b])
    },
    createBucket: function() {
        var a = new SYNO.SDS.Backup.Addon.azure_blob.Repository.CreateBucket({
            s3key: this.getForm().findField("key").getValue(),
            s3secret: this.getForm().findField("secret").getValue(),
            addon_id: this.addon_id,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var b = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField("bucket").clearValue();
            this.loadBucketStore(b)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getForm(),
            b = function(c) {
                return a.findField(c).getValue()
            };
        return {
            key: b("key"),
            secret: b("secret"),
            transfer_type: this.addon_id
        }
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        if (!b.key || !b.secret) {
            return
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Azure.Container",
            version: 1,
            method: "list",
            params: b,
            scope: this,
            callback: function(h, c, d) {
                var g = this.getForm().findField("bucket");
                var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                var f = new e({
                    bucket: SYNO.Backup.Addon.Util.getString(this.addon_id, "create_container"),
                    status: 0,
                    conflict_repo: ""
                });
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                this.getBucketStore().insert(0, f);
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    getParams: function() {
        var a = {};
        a = this.getForm().getFieldValues();
        a.action = "create";
        a.target_type = "cloud";
        a.transfer_type = this.transfer_type;
        a.repo_name = a.name;
        delete a.name;
        return a
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.owner.loadAppParams();
        return this.nextId
    },
    isValid: function() {
        return this.getForm().isValid()
    }
});
Ext.ns("SYNO.Backup.Addon.legacy_hicloud_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_hicloud_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "hicloud_s3",
            support_region: false
        }, a);
        return this.callParent([b])
    }
});
(function() {
    var a = "Local Archiving Storage";
    Ext.ns("SYNO.Backup.Addon.legacy_local.Destination");
    Ext.define("SYNO.Backup.Addon.legacy_local.Destination.SettingPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(b) {
            Ext.copyTo(this, b, "owner");
            this.loaded = false;
            var c = Ext.apply({
                height: 410,
                bodyStyle: "padding-top: 24px",
                items: [{
                    xtype: "syno_fieldset",
                    collapsible: false,
                    defaults: {
                        labelWidth: 300
                    },
                    items: []
                }]
            }, b);
            this.addLocalBackupFields(c);
            this.callParent([c])
        },
        activate: function() {
            if (!this.loaded) {
                this.loadLocalRepoOptions()
            }
        },
        addLocalBackupFields: function(b) {
            b.items[0].items.push({
                xtype: "syno_displayfield",
                value: _T("backup", "local_backup_desc")
            }, {
                xtype: "syno_textfield",
                name: "local_backup_name",
                allowBlank: false,
                fieldLabel: _T("backup", "repo_name"),
                value: a,
                maxlength: 32,
                vtype: "backup_destination",
                hidden: true
            }, {
                xtype: "syno_combobox",
                name: "share",
                allowBlank: false,
                fieldLabel: _T("tree", "leaf_sharefolder"),
                width: 270,
                forceSelection: true,
                store: this.getShareStore(),
                displayField: "share",
                valueField: "share",
                listeners: {
                    beforeselect: function(d, c, e) {
                        if (0 !== c.get("status")) {
                            return false
                        }
                    },
                    select: function(d, c, e) {
                        var f = this.owner.getParams();
                        this.sendWebAPI({
                            api: "SYNO.Backup.Target",
                            version: 1,
                            method: "get_candidate_dir",
                            params: Ext.apply(f, {
                                share: c.get("share")
                            }),
                            scope: this,
                            callback: function(i, g, h) {
                                this.owner.setDestFolderName(g.candidate_dir, f.target_type, f.transfer_type)
                            }
                        });
                        this.shareVolume = c.get("volume")
                    },
                    scope: this
                },
                tpl: SYNO.SDS.Backup.getShareListTpl("share")
            })
        },
        getShareStore: function() {
            if (!this.shareStore) {
                this.shareStore = new Ext.data.ArrayStore({
                    autoDestroy: true,
                    autoLoad: false,
                    fields: ["share", "status", "conflict_repo", "volume", "is_data_enc"]
                })
            }
            return this.shareStore
        },
        getParams: function() {
            var b = {};
            b = this.getForm().getFieldValues();
            b.action = "create";
            b.target_type = "share";
            b.transfer_type = "local";
            b.repo_name = b.local_backup_name;
            delete b.local_backup_name;
            delete b["undefined"];
            return b
        },
        getNext: function() {
            if (!this.getForm().isValid()) {
                return false
            }
            this.owner.loadAppParams();
            return this.nextId
        },
        getLocalRepoVolume: function() {
            if (this.getForm().getFieldValues().volume) {
                return this.getForm().getFieldValues().volume
            }
            return this.shareVolume
        },
        loadLocalRepoOptions: function() {
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Storage.Share.Local",
                method: "list",
                version: 1,
                params: {
                    additional: ["legacy"]
                },
                callback: this.loadLocalRepoOptionsHandler,
                scope: this
            })
        },
        loadLocalRepoOptionsHandler: function(d, b, c) {
            if (!d || b.has_fail) {
                this.owner.clearStatusBusy();
                this.owner.reportError(b);
                return false
            }
            this.loadData(b);
            this.loaded = true;
            this.owner.clearStatusBusy()
        },
        loadData: function(b) {
            var d = this,
                c, e = {};
            if (0 === b.share_list.length) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"));
                return false
            }
            d.getShareStore().loadData(b.share_list);
            c = d.getShareStore().findExact("status", 0);
            if (c !== -1) {
                e.target_type = e.target_type || "share";
                e.share = d.getShareStore().getAt(c).get("share");
                d.shareVolume = d.getShareStore().getAt(c).get("volume")
            } else {
                d.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
            }
            d.getForm().setValues(e);
            d.loaded = true;
            return Ext.isDefined(e.share)
        }
    })
})();
(function() {
    var b = "Remote Share Storage",
        a = "Rsync Compatible Storage";
    Ext.ns("SYNO.Backup.Addon.legacy_rsync.Destination");
    Ext.define("SYNO.Backup.Addon.legacy_rsync.Destination.SettingPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(c) {
            Ext.copyTo(this, c, "owner");
            this.fieldLabelWidth = 300;
            this.callParent([this.fillConfig(c)]);
            this.mon(this, "activate", function() {
                var d = this.getForm().findField("network_type");
                d.setValue("rsync_ds")
            }, this, {
                single: true
            })
        },
        fillConfig: function(c) {
            return Ext.apply({
                trackResetOnLoad: true,
                height: 410,
                bodyStyle: "padding-top: 24px",
                defaults: {
                    labelWidth: this.fieldLabelWidth
                },
                items: [{
                    xtype: "syno_fieldset",
                    collapsible: false,
                    items: [{
                        xtype: "syno_combobox",
                        name: "network_type",
                        fieldLabel: _T("netbackup", "netbkp_slct_server"),
                        allowBlank: false,
                        store: this.getServerStore(),
                        displayField: "server",
                        valueField: "value",
                        value: "rsync_ds",
                        editable: false,
                        listeners: {
                            scope: this,
                            select: function(e, d, f) {
                                this.changeLayout(d.get("value"))
                            }
                        }
                    }, new SYNO.SDS.Backup.HostCombobox({
                        name: "dest",
                        owner: this.owner
                    }), {
                        xtype: "syno_combobox",
                        name: "encrypt_connect",
                        fieldLabel: SYNO.SDS.Backup.String("rsync", "transfer_encryption"),
                        allowBlank: false,
                        store: new Ext.data.ArrayStore({
                            fields: ["text", "value"],
                            data: [
                                [SYNO.SDS.Backup.String("app", "on"), true],
                                [SYNO.SDS.Backup.String("app", "off"), false]
                            ]
                        }),
                        displayField: "text",
                        valueField: "value",
                        editable: false,
                        value: false,
                        listeners: {
                            scope: this,
                            select: function(e, d, f) {
                                this.changeEncTransLayout(d.get("value"))
                            }
                        }
                    }, {
                        xtype: "syno_numberfield",
                        maxlength: 5,
                        vtype: "port",
                        name: "port",
                        value: 873,
                        allowBlank: false,
                        fieldLabel: _T("common", "port")
                    }, {
                        xtype: "syno_numberfield",
                        maxlength: 5,
                        vtype: "port",
                        name: "enc_port",
                        value: 22,
                        allowBlank: false,
                        fieldLabel: _T("common", "port"),
                        hidden: true,
                        disabled: true
                    }, {
                        xtype: "syno_textfield",
                        name: "account",
                        allowBlank: false,
                        fieldLabel: _T("netbackup", "netbkp_account"),
                        validator: (function(e) {
                            var d = e;
                            if (this.getForm().findField("network_type").getValue() === "rsync") {
                                d = d.replace(/%/g, "a")
                            }
                            return Ext.form.VTypes.username_ext(d)
                        }).createDelegate(this),
                        invalidText: Ext.form.VTypes.username_extText
                    }, {
                        xtype: "syno_textfield",
                        name: "pwd",
                        allowBlank: true,
                        fieldLabel: _T("common", "password"),
                        inputType: "password"
                    }, {
                        xtype: "syno_displayfield",
                        value: ""
                    }, {
                        xtype: "syno_textfield",
                        name: "rsync_backup_name",
                        allowBlank: false,
                        fieldLabel: _T("backup", "repo_name"),
                        value: a,
                        maxLength: 32,
                        maxlength: 32,
                        hidden: true,
                        disabled: true,
                        vtype: "backup_destination"
                    }, {
                        xtype: "syno_combobox",
                        name: "module",
                        fieldLabel: _T("netbackup", "netbkp_module"),
                        allowBlank: false,
                        store: this.getModuleStore(),
                        displayField: "share",
                        valueField: "share",
                        editable: true,
                        hidden: true,
                        disabled: true,
                        onTriggerClick: function() {
                            if (this.readOnly || this.disabled) {
                                return
                            }
                            if (this.scope.needReloadModule()) {
                                this.scope.loadModuleStore()
                            } else {
                                SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                            }
                        },
                        scope: this,
                        listeners: {
                            beforeselect: function(e, d, f) {
                                if (d.get("status") !== 0) {
                                    return false
                                }
                            }
                        },
                        tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.share)]}" class="x-combo-list-item {[values.status === 0 ? "syno-backup-enabled-list-item" : "syno-backup-disabled-list-item"]}">{share:htmlEncode}</div></tpl>'
                    }]
                }]
            }, c)
        },
        getNext: function() {
            var c = this.getForm();
            if (!c.isValid()) {
                return false
            }
            this.owner.loadAppParams();
            if ("rsync_ds" === c.findField("network_type").getValue()) {
                this.loadOptions();
                return false
            } else {
                var d = Ext.apply(this.getParams(), this.owner.getParams());
                this.owner.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.Backup.Repository",
                    version: 1,
                    method: "get",
                    params: d,
                    scope: this,
                    callback: function(g, e, f) {
                        this.owner.clearStatusBusy();
                        if (!g) {
                            this.owner.reportError(e);
                            return false
                        }
                        if ("offline" === e.deststatus) {
                            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(e.desterror));
                            return false
                        }
                        if (this.nextId === this.skipId) {
                            this.owner.goNext(this.nextId)
                        } else {
                            this.owner.goNext(this.owner.getStep(this.nextId).nextId)
                        }
                    }
                });
                return false
            }
        },
        getParams: function() {
            var c = this.getForm(),
                d = function(g) {
                    return c.findField(g).getValue()
                };
            var e = {};
            e.action = "create";
            e.transfer_type = d("network_type");
            e.dest = c.findField("dest").getHostAddress();
            e.account = d("account");
            e.pwd = d("pwd");
            e.encrypt_connect = d("encrypt_connect");
            if (e.encrypt_connect) {
                e.enc_port = d("enc_port")
            } else {
                e.port = d("port")
            }
            if ("rsync" === e.transfer_type) {
                e.repo_name = d("rsync_backup_name");
                e.module = d("module");
                if ("/" === e.module.charAt(0)) {
                    e.remoteshell = true;
                    e.encrypt_connect = true;
                    if (!Ext.isDefined(e.enc_port)) {
                        e.enc_port = 22;
                        delete e.port
                    }
                }
            }
            return e
        },
        getServerStore: function() {
            if (!this.serverStore) {
                this.serverStore = new Ext.data.ArrayStore({
                    fields: ["server", "value"],
                    data: [
                        [String.format(SYNO.SDS.Backup.String("rsync", "synology_rsync_server"), _D("company_title")), "rsync_ds"],
                        [_T("netbackup", "rsync_compatible_server"), "rsync"]
                    ]
                })
            }
            return this.serverStore
        },
        changeLayout: function(c) {
            if ("rsync_ds" === c) {
                this.getForm().findField("module").setVisible(false);
                this.getForm().findField("module").setDisabled(true);
                if (this.nextId === this.skipId) {
                    this.nextId = this.continueId
                }
                this.owner.getButton("next").setText(_T("common", "next"))
            } else {
                if ("rsync" === c) {
                    this.getForm().findField("module").setVisible(true);
                    this.getForm().findField("module").setDisabled(false);
                    if (this.nextId === this.continueId && null !== this.nextId && null === this.owner.getStep(this.nextId).nextId) {
                        this.nextId = this.skipId;
                        this.owner.getButton("next").setText(_T("common", "commit"))
                    }
                }
            }
            this.doLayout()
        },
        changeEncTransLayout: function(f) {
            var e = this.getForm();
            var c = function(h, g) {
                e.findField(h).setDisabled(!g);
                e.findField(h).setVisible(g)
            };
            var d = function(g, h) {
                c("port", g);
                c("enc_port", h)
            };
            if (f) {
                d(false, true)
            } else {
                d(true, false)
            }
        },
        loadOptions: function() {
            var c = this.getParams();
            var e = Ext.apply({
                dest: c.dest,
                account: c.account,
                pwd: c.pwd
            }, this.owner.getParams());
            var d = {
                target_type: e.target_type
            };
            Ext.copyTo(d, c, "transfer_type,encrypt_connect,port,enc_port");
            e = Ext.apply({
                connect_list: [d]
            }, e);
            delete e.target_type;
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Storage.Connect.Network",
                version: 1,
                method: "list",
                params: e,
                callback: this.onLoadOptions,
                scope: this
            })
        },
        onLoadOptions: function(f, c, d) {
            var e = this;
            e.owner.clearStatusBusy();
            if (!f) {
                e.owner.reportError(c);
                return false
            }
            if (e.owner.getStep(e.nextId).loadData(c) !== false) {
                e.owner.goNext(e.nextId)
            }
        },
        getModuleStore: function() {
            if (!this.moduleStore) {
                this.moduleStore = new Ext.data.ArrayStore({
                    fields: ["share", "status", "conflict_repo"]
                })
            }
            return this.moduleStore
        },
        getModuleParams: function() {
            var c = this.getParams();
            var e = Ext.apply({
                dest: c.dest,
                account: c.account,
                pwd: c.pwd
            }, this.owner.getParams());
            var d = {
                target_type: e.target_type
            };
            Ext.copyTo(d, c, "transfer_type,encrypt_connect,port,enc_port");
            e = Ext.apply({
                connect_list: [d]
            }, e);
            delete e.target_type;
            return e
        },
        needReloadModule: function() {
            var c = this.getModuleParams();
            return this.lastQuery !== Ext.encode(c)
        },
        loadModuleStore: function() {
            var c = this.getModuleParams();
            if (Ext.isEmpty(c.dest, false) || Ext.isEmpty(c.account, false) || !Ext.isDefined(c.connect_list[0].encrypt_connect) || (Ext.isEmpty(c.connect_list[0].port, false) && Ext.isEmpty(c.connect_list[0].enc_port, false))) {
                return
            }
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Storage.Connect.Network",
                version: 1,
                method: "list",
                params: c,
                scope: this,
                callback: function(g, d, e) {
                    var f = this.getForm().findField("module");
                    this.owner.clearStatusBusy();
                    if (!g) {
                        this.owner.reportError(d);
                        return
                    }
                    if (0 === d.connect_list[0].list.length) {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_modules_available"));
                        return
                    }
                    this.lastQuery = Ext.encode(c);
                    this.getModuleStore().loadData(d.connect_list[0].list);
                    f.el.focus();
                    f.expand();
                    f.restrictHeight()
                }
            })
        }
    });
    Ext.define("SYNO.SDS.Backup.Repository.NetworkCreateStep", {
        extend: "SYNO.ux.FormPanel",
        volumeDestChanged: true,
        shareDestChanged: true,
        constructor: function(c) {
            var d = Ext.apply({
                items: [{
                    xtype: "syno_fieldset",
                    collapsible: false,
                    defaults: {
                        labelWidth: 300
                    },
                    items: []
                }]
            }, c);
            this.addNetworkBackupFields(d);
            return this.callParent([d])
        },
        addNetworkBackupFields: function(c) {
            c.items[0].items.push({
                xtype: "syno_displayfield",
                value: _T("backup", "network_backup_desc")
            }, {
                xtype: "syno_textfield",
                name: "network_backup_name",
                allowBlank: false,
                fieldLabel: _T("backup", "repo_name"),
                value: b,
                maxLength: 32,
                hidden: true,
                vtype: "backup_destination"
            }, {
                xtype: "syno_combobox",
                name: "share",
                width: 270,
                allowBlank: false,
                fieldLabel: _T("tree", "leaf_sharefolder"),
                forceSelection: true,
                store: this.getShareStore(),
                displayField: "share",
                valueField: "share",
                listeners: {
                    beforeselect: function(e, d, f) {
                        if (d.get("status") !== 0) {
                            return false
                        }
                    }
                },
                tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.share)]}" class="x-combo-list-item {[values.status === 0 ? "syno-backup-enabled-list-item" : "syno-backup-disabled-list-item"]}">{share:htmlEncode}</div></tpl>'
            }, {
                xtype: "syno_displayfield",
                name: "network_backup_error_message",
                value: "",
                style: {
                    color: "red"
                },
                hidden: true
            })
        },
        initEvents: function() {
            this.callParent(arguments);
            this.mon(this, "afterlayout", function() {
                var c;
                c = new SYNO.ux.Utils.EnableRadioGroup(this.getForm(), "target_type", {
                    image: ["version_backup_name", "volume"],
                    share: ["network_backup_name", "share"]
                })
            }, this, {
                single: true
            })
        },
        getShareStore: function() {
            if (!this.shareStore) {
                this.shareStore = new Ext.data.ArrayStore({
                    fields: ["share", "status", "conflict_repo"]
                })
            }
            return this.shareStore
        },
        getParams: function() {
            var c = Ext.copyTo({}, this.owner.getStep("legacy_rsync::dest_setting").getParams(), "transfer_type,dest,account,pwd,encrypt_connect,port,enc_port");
            c.repo_name = this.getForm().findField("network_backup_name").getValue();
            c.share = this.getForm().findField("share").getValue();
            return c
        },
        getNext: function() {
            if (!this.getForm().isValid()) {
                return false
            }
            return this.nextId
        },
        loadData: function(c) {
            var e = this,
                d, f = {};
            e.loaded = true;
            e.getShareStore().removeAll();
            if (0 === c.connect_list[0].list.length) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"));
                return false
            }
            e.getShareStore().loadData(c.connect_list[0].list);
            d = e.getShareStore().findExact("status", 0, false, false);
            if (d !== -1) {
                f.target_type = f.target_type || "share";
                f.share = e.getShareStore().getAt(d).get("share")
            }
            e.getForm().setValues(f);
            return Ext.isDefined(f.share)
        }
    });
    Ext.define("SYNO.Backup.Addon.legacy_rsync_ds.Destination.SettingPanel", {
        extend: "SYNO.Backup.Addon.legacy_rsync.Destination.SettingPanel"
    })
}());
Ext.ns("SYNO.Backup.Addon.legacy_sfr_s3.Destination");
Ext.define("SYNO.Backup.Addon.legacy_sfr_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.S3.Repository.CreateStep",
    constructor: function(a) {
        var b = Ext.apply({
            addon_id: "sfr_s3",
            support_region: false
        }, a);
        return this.callParent([b])
    }
});
Ext.ns("SYNO.Backup.Addon.local.Destination");
Ext.define("SYNO.Backup.Addon.local.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    supportExport: false,
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.loaded = false;
        this.createFields = this.getAuthFields();
        this.relinkFields = this.getAuthFields();
        return this.callParent(arguments)
    },
    activate: function() {
        if (!this.loaded) {
            this.loadLocalRepoOptions()
        }
    },
    getAuthFields: function() {
        var a = [{
            xtype: "syno_combobox",
            name: "share",
            allowBlank: false,
            indent: this.getFieldIndent(),
            fieldLabel: _T("tree", "leaf_sharefolder"),
            width: 270,
            forceSelection: true,
            store: this.getShareStore(),
            displayField: "share",
            valueField: "share",
            listeners: {
                beforeselect: function(c, b, d) {
                    if (0 !== b.get("status")) {
                        return false
                    }
                },
                select: function(c, b, d) {
                    if ("create" === this.action) {
                        this.updateTarget()
                    }
                    this.shareVolume = b.get("volume")
                },
                scope: this
            },
            tpl: SYNO.SDS.Backup.getShareListTpl("share")
        }];
        return a
    },
    getShareStore: function() {
        if (!this.shareStore) {
            this.shareStore = new Ext.data.ArrayStore({
                autoDestroy: true,
                autoLoad: false,
                fields: ["share", "status", "conflict_repo", "volume", "is_data_enc"]
            })
        }
        return this.shareStore
    },
    getLocalRepoVolume: function() {
        if (this.getForm().getFieldValues().volume) {
            return this.getForm().getFieldValues().volume
        }
        return this.shareVolume
    },
    loadLocalRepoOptions: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Share.Local",
            method: "list",
            version: 1,
            callback: this.loadLocalRepoOptionsHandler,
            scope: this
        })
    },
    loadLocalRepoOptionsHandler: function(c, a, b) {
        if (!c || a.has_fail) {
            this.owner.clearStatusBusy();
            this.owner.reportError(a);
            return false
        }
        this.loadData(a);
        this.loaded = true;
        this.owner.clearStatusBusy()
    },
    loadData: function(a) {
        var c = this,
            b, d = {};
        if (0 === a.share_list.length) {
            c.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"));
            return false
        }
        if ("create" !== this.action) {
            return true
        }
        c.getShareStore().loadData(a.share_list);
        b = c.getShareStore().findExact("status", 0);
        if (b !== -1) {
            d.target_type = d.target_type || "share";
            d.share = c.getShareStore().getAt(b).get("share");
            c.shareVolume = c.getShareStore().getAt(b).get("volume")
        } else {
            c.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
        }
        c.getForm().setValues(d);
        c.loaded = true;
        if (b !== -1) {
            c.updateTarget()
        }
        return Ext.isDefined(d.share)
    },
    relinkValidator: function(b, c) {
        var a = b.ownerCt;
        if (a.get(0).isValid()) {
            return true
        } else {
            b.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        }
    },
    getParams: function() {
        var c = this.callParent();
        var a = this.getForm().getFieldValues();
        if ("export" !== this.action) {
            c.share = a.share;
            var b = this.getShareStore().getAt(this.getShareStore().find("share", a.share));
            if (b) {
                c.isDestEncShare = b.get("is_data_enc")
            }
        }
        c.clientEncrypt = this.needEnableClientEncrypt(c);
        return c
    }
});
Ext.ns("SYNO.Backup.Addon.openstack.Destination");
Ext.define("SYNO.Backup.Addon.openstack.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "remote_url",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "url")
        }, {
            xtype: "syno_combobox",
            name: b + "auth_version",
            width: 270,
            indent: this.getFieldIndent(),
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["version", "value"],
                data: [
                    ["1.0", "1.0"],
                    ["2.0", "2.0"],
                    ["3.0", "3.0"]
                ]
            }),
            fieldLabel: SYNO.SDS.Backup.String("openstack", "identity_service_version"),
            displayField: "version",
            valueField: "value",
            value: "1.0",
            editable: false,
            listeners: {
                select: function(e, c, d) {
                    this.changeVersionLayout(this.action, c.get("value"));
                    this.doLayout()
                },
                scope: this
            }
        }, {
            xtype: "syno_textfield",
            name: b + "key",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        }, {
            xtype: "syno_textfield",
            name: b + "secret_pw",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            name: b + "tenant_compositefield",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "tenant"),
            items: [{
                xtype: "syno_combobox",
                name: b + "tenant_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "tenant_id"],
                        ["name", "tenant_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "tenant_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: b + "tenant_value",
                width: 184,
                allowBlank: true
            }],
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_compositefield",
            name: b + "domain_compositefield",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "domain"),
            items: [{
                xtype: "syno_combobox",
                name: b + "domain_option",
                width: 80,
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        ["id", "domain_id"],
                        ["name", "domain_name"]
                    ]
                }),
                displayField: "display",
                valueField: "value",
                value: "domain_id",
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_textfield",
                name: b + "domain_value",
                width: 184,
                allowBlank: false
            }],
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            name: b + "region_cust",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            store: this.getRegionStore(),
            displayField: "display",
            allowBlank: false,
            valueField: "value",
            editable: false,
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.regionValidator(this)) {
                    return
                }
                if (this.scope.needReloadRegion()) {
                    this.scope.loadRegionStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            hidden: true,
            disabled: true
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    onFieldsetSelected: function(a) {
        var d = this.getLayoutPrefix(this.action);
        var c = this.getForm();
        if ("create_fields" === a.name || "relink_fields" === a.name) {
            var b = c.findField(d + "auth_version");
            this.changeVersionLayout(this.action, b.getValue())
        }
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    changeVersionLayout: function(e, f) {
        var d = this.getLayoutPrefix(e);
        var c = this.getForm();
        var a = function(h, g) {
            c.findField(d + h).setDisabled(!g);
            c.findField(d + h).setVisible(g)
        };
        var b = function(h, g, j, k, i) {
            a("secret", h);
            a("secret_pw", g);
            a("tenant_compositefield", j);
            a("domain_compositefield", k);
            a("region_cust", i)
        };
        if ("1.0" === f) {
            b(true, false, false, false, false)
        } else {
            if ("2.0" === f) {
                b(false, true, true, false, true)
            } else {
                if ("3.0" === f) {
                    b(false, true, true, true, true)
                } else {
                    return
                }
            }
        }
    },
    getRemoteUrlValue: function() {
        var c = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            d = function(e) {
                return a.findField(c + e).getValue()
            };
        var b = d("remote_url").trim();
        if (b.substring(0, 7) !== "http://" && b.substring(0, 8) !== "https://") {
            return "https://" + b
        }
        return b
    },
    getRegionValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("2.0" === c("auth_version") || "3.0" === c("auth_version")) {
            return c("region_cust")
        }
        return ""
    },
    getUsernameValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("key")
    },
    getSecretValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("2.0" === c("auth_version") || "3.0" === c("auth_version")) {
            return c("secret_pw")
        }
        return c("secret")
    },
    getTenantId: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if (("2.0" === c("auth_version") || "3.0" === c("auth_version")) && "tenant_id" === c("tenant_option")) {
            return c("tenant_value")
        }
        return ""
    },
    getTenantName: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if (("2.0" === c("auth_version") || "3.0" === c("auth_version")) && "tenant_name" === c("tenant_option")) {
            return c("tenant_value")
        }
        return ""
    },
    getDomainId: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("3.0" === c("auth_version") && "domain_id" === c("domain_option")) {
            return c("domain_value")
        }
        return ""
    },
    getDomainName: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if ("3.0" === c("auth_version") && "domain_name" === c("domain_option")) {
            return c("domain_value")
        }
        return ""
    },
    getAuthVersion: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("auth_version")
    },
    createBucket: function() {
        var a = new SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Repository.CreateBucket({
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            s3key: this.getUsernameValue(),
            s3secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var b = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket").clearValue();
            this.loadBucketStore(b)
        }, this);
        a.open()
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["value", "display"],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            })
        }
        return this.regionStore
    },
    getLoadRegionParams: function() {
        var a = this.getParams();
        delete a.region;
        delete a.bucket;
        return a
    },
    needReloadRegion: function() {
        var a = this.getLoadRegionParams();
        return this.lastRegionQuery !== Ext.encode(a)
    },
    loadRegionStore: function() {
        var a = this.getLoadRegionParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Region",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(e, b, c) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.reportError(b);
                    return
                }
                this.lastRegionQuery = Ext.encode(a);
                this.getRegionStore().loadData(SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping(b.region_list));
                var d = this.getForm().findField(this.getLayoutPrefix(this.action) + "region_cust");
                d.el.focus();
                d.expand();
                d.restrictHeight()
            }
        })
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastBucketQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastBucketQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.SDS.Backup.String("openstack", "create_container"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    regionValidator: function(e) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            d = function(g) {
                return b.findField(c + g).getValue()
            };
        var a = function(g) {
            return b.findField(c + g).isValid()
        };
        if (a("remote_url") && a("key")) {
            if ("2.0" === d("auth_version") && a("secret_pw") && a("tenant_value")) {
                return true
            } else {
                if ("3.0" === d("auth_version") && a("secret_pw") && a("tenant_value") && a("domain_value")) {
                    return true
                }
            }
        }
        e.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    shareValidator: function(e) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            d = function(g) {
                return b.findField(c + g).getValue()
            };
        var a = function(g) {
            return b.findField(c + g).isValid()
        };
        if (a("remote_url") && a("key")) {
            if ("1.0" === d("auth_version") && a("secret")) {
                return true
            } else {
                if ("2.0" === d("auth_version") && a("secret_pw") && a("tenant_value") && a("region_cust")) {
                    return true
                } else {
                    if ("3.0" === d("auth_version") && a("secret_pw") && a("tenant_value") && a("domain_value") && a("region_cust")) {
                        return true
                    }
                }
            }
        }
        e.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(e, f) {
        var c = "create" === f.action ? "create_" : "relink_";
        var d = function(g) {
            return e.ownerCt.find("name", c + g)[0].getValue()
        };
        var b = function(g) {
            return e.ownerCt.find("name", c + g)[0].isValid()
        };
        var a = function(g) {
            return e.ownerCt.find("name", c + g)[0].items.items[1].isValid()
        };
        if (b("remote_url") && b("key")) {
            if ("1.0" === d("auth_version") && b("secret") && b("bucket")) {
                return true
            } else {
                if ("2.0" === d("auth_version") && b("secret_pw") && a("tenant_compositefield") && b("region_cust") && b("bucket")) {
                    return true
                } else {
                    if ("3.0" === d("auth_version") && b("secret_pw") && a("tenant_compositefield") && a("domain_compositefield") && b("region_cust") && b("bucket")) {
                        return true
                    }
                }
            }
        }
        e.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_url = this.getRemoteUrlValue();
            d.region = this.getRegionValue();
            d.key = this.getUsernameValue();
            d.secret = this.getSecretValue();
            d.tenant_id = this.getTenantId();
            d.tenant_name = this.getTenantName();
            d.domain_id = this.getDomainId();
            d.domain_name = this.getDomainName();
            d.auth_version = this.getAuthVersion();
            d.bucket = c("bucket")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.rackspace.Destination");
Ext.define("SYNO.Backup.Addon.rackspace.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "key",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "username")
        }, {
            xtype: "syno_textfield",
            name: b + "secret",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("openstack", "api_key")
        }, {
            xtype: "syno_combobox",
            name: b + "region_cust",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "region"),
            store: this.getRegionStore(),
            displayField: "display",
            allowBlank: false,
            valueField: "value",
            editable: false,
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.regionValidator(this)) {
                    return
                }
                if (this.scope.needReloadRegion()) {
                    this.scope.loadRegionStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            }
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("openstack", "container_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget()
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    getRemoteUrlValue: function() {
        return ""
    },
    getRegionValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("region_cust")
    },
    getUsernameValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("key")
    },
    getSecretValue: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        return c("secret")
    },
    getTenantId: function() {
        return ""
    },
    getTenantName: function() {
        return ""
    },
    getDomainId: function() {
        return ""
    },
    getDomainName: function() {
        return ""
    },
    getAuthVersion: function() {
        return ""
    },
    createBucket: function() {
        var a = new SYNO.SDS.Backup.Addon.Util.Image.OpenStack.Repository.CreateBucket({
            remote_url: this.getRemoteUrlValue(),
            region: this.getRegionValue(),
            s3key: this.getUsernameValue(),
            s3secret: this.getSecretValue(),
            tenant_id: this.getTenantId(),
            tenant_name: this.getTenantName(),
            domain_id: this.getDomainId(),
            domain_name: this.getDomainName(),
            auth_version: this.getAuthVersion(),
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var b = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket").clearValue();
            this.loadBucketStore(b)
        }, this);
        a.open()
    },
    getRegionStore: function() {
        if (!this.regionStore) {
            this.regionStore = new Ext.data.ArrayStore({
                fields: ["value", "display"],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            })
        }
        return this.regionStore
    },
    getLoadRegionParams: function() {
        var a = this.getParams();
        delete a.region;
        delete a.bucket;
        return a
    },
    needReloadRegion: function() {
        var a = this.getLoadRegionParams();
        return this.lastRegionQuery !== Ext.encode(a)
    },
    loadRegionStore: function() {
        var a = this.getLoadRegionParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Region",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: a,
            scope: this,
            callback: function(e, b, c) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.reportError(b);
                    return
                }
                this.lastRegionQuery = Ext.encode(a);
                this.getRegionStore().loadData(SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping(b.region_list));
                var d = this.getForm().findField(this.getLayoutPrefix(this.action) + "region_cust");
                d.el.focus();
                d.expand();
                d.restrictHeight()
            }
        })
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastBucketQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.OpenStack.Container",
            version: 1,
            method: "list",
            encryption: ["secret"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastBucketQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.SDS.Backup.String("openstack", "create_container"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    regionValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            a = function(e) {
                return b.findField(c + e).isValid()
            };
        if (a("key") && a("secret")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            a = function(e) {
                return b.findField(c + e).isValid()
            };
        if (a("region_cust") && a("key") && a("secret")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("region_cust") && a("key") && a("secret") && a("bucket")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_url = this.getRemoteUrlValue();
            d.region = this.getRegionValue();
            d.key = this.getUsernameValue();
            d.secret = this.getSecretValue();
            d.tenant_id = this.getTenantId();
            d.tenant_name = this.getTenantName();
            d.domain_id = this.getDomainId();
            d.domain_name = this.getDomainName();
            d.auth_version = this.getAuthVersion();
            d.bucket = c("bucket")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.remote.Destination");
Ext.define("SYNO.Backup.Addon.remote.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.createlastQuery = null;
        this.relinklastQuery = null;
        this.verify_cert = false;
        this.ssl_trust_mode = "none";
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [new SYNO.SDS.Backup.HostCombobox({
            name: b + "dest",
            indent: this.getFieldIndent(),
            width: 270,
            owner: this.owner
        }), {
            xtype: "syno_combobox",
            name: b + "sslcheck",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("remote", "transfer_encryption"),
            allowBlank: false,
            store: new Ext.data.ArrayStore({
                fields: ["text", "value"],
                data: [
                    [SYNO.SDS.Backup.String("app", "on"), true],
                    [SYNO.SDS.Backup.String("app", "off"), false]
                ]
            }),
            displayField: "text",
            valueField: "value",
            editable: false,
            value: false,
            listeners: {
                select: function(d, c, e) {
                    if (false === c.json[1]) {
                        var f = this.getLayoutPrefix(this.action);
                        var g = this.getForm().findField(f + "verify_cert");
                        g.removeClass("syno-backup-orange-status");
                        g.removeClass("syno-backup-red-status");
                        g.removeClass("syno-backup-green-status");
                        g.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_not_yet"));
                        this.ssl_trust_mode = "none";
                        this.showFieldCert(false)
                    } else {
                        this.showFieldCert(true)
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_displayfield",
            name: b + "verify_cert",
            indent: this.getFieldIndent(),
            hidden: true,
            fieldLabel: SYNO.SDS.Backup.String("app", "certificate_auth"),
            value: SYNO.SDS.Backup.String("app", "certificate_auth_not_yet")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            style: "margin-left: 213px",
            name: b + "cert_buttons",
            hidden: true,
            items: [{
                xtype: "syno_button",
                hideLabel: true,
                text: SYNO.SDS.Backup.String("app", "trust"),
                itemId: "trust_button",
                handler: this.onTrustBtnClick,
                scope: this
            }, {
                xtype: "syno_button",
                hideLabel: true,
                text: SYNO.SDS.Backup.String("app", "ignore"),
                itemId: "ignore_button",
                handler: this.onIgnoreCertBtnClick,
                scope: this
            }]
        }, {
            xtype: "syno_numberfield",
            maxlength: 5,
            vtype: "port",
            name: b + "port",
            indent: this.getFieldIndent(),
            value: 6281,
            width: 270,
            allowBlank: false,
            fieldLabel: _T("common", "port")
        }, {
            xtype: "syno_displayfield",
            name: b + "account",
            hidden: true
        }, {
            xtype: "syno_displayfield",
            name: b + "pwd",
            hidden: true
        }, {
            xtype: "syno_displayfield",
            name: b + "is_webapi_authen",
            value: "false",
            hidden: true
        }, {
            xtype: "syno_compositefield",
            fieldLabel: SYNO.SDS.Backup.String("app", "authenticate"),
            indent: this.getFieldIndent(),
            items: [{
                xtype: "syno_displayfield",
                name: b + "account_display_name"
            }, {
                xtype: "syno_button",
                name: b + "account_authen",
                text: SYNO.SDS.Backup.String("app", "login"),
                itemId: "authenticate_button",
                handler: this.onAuthenBtnClick,
                scope: this
            }]
        }, {
            xtype: "syno_combobox",
            name: b + "share",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: _T("tree", "leaf_sharefolder"),
            forceSelection: true,
            store: this.getShareStore(),
            displayField: "share",
            valueField: "share",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadShare()) {
                    this.scope.loadShareStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                beforeselect: function(d, c, e) {
                    if (0 !== c.get("status")) {
                        return false
                    }
                },
                select: function(d, c, e) {
                    if ("create" === this.action) {
                        this.updateTarget()
                    }
                },
                scope: this
            },
            tpl: SYNO.SDS.Backup.getShareListTpl("share")
        }];
        return a
    },
    authenCB: function(a) {
        var b = this.getLayoutPrefix(this.action);
        if (!("code" in a)) {
            this.getForm().findField(b + "account").setValue(a.username);
            SYNO.Backup.Util.DisplayAccount(this.getForm().findField(b + "account_display_name"), a.username, 15);
            this.getForm().findField(b + "pwd").setValue(a.id);
            this.getForm().findField(b + "is_webapi_authen").setValue(true);
            this.doLayout()
        }
        this.owner.clearStatusBusy()
    },
    onAuthenBtnClick: function() {
        var a = this.getLayoutPrefix(this.action);
        var b = this.getForm().findField(a + "dest");
        if (!b.isValid()) {
            b.markInvalid(_T("netbackup", "netbkp_err_host_str"));
            return
        }
        this.owner.setStatusBusy();
        var c = this.owner.getParams();
        c.ip = this.getForm().findField(a + "dest").getValue();
        c.port = this.getForm().findField(a + "port").getValue();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.LoginPort",
            version: 1,
            method: "get",
            params: c,
            scope: this,
            callback: function(h, d, f) {
                if (!h) {
                    if (d.code == SYNO.SDS.Backup.ERR_NO_RESPONSE) {
                        d.code = SYNO.SDS.Backup.ERR_SERVICE_DISABLE
                    }
                    this.owner.reportError(d);
                    this.owner.clearStatusBusy();
                    return false
                }
                var e = "";
                var g = false;
                if (d.port > 0) {
                    e = "https://" + c.ip + ":" + d.port
                } else {
                    g = true
                }
                this.owner.clearStatusBusy();
                synocredential.Issue({
                    url: e,
                    forceLegacyMode: g,
                    mustHaveCredential: true,
                    session: "HyperBackupVault",
                    appWin: this.owner,
                    callback: this.authenCB.bind(this),
                    redirect_uri: window.location.origin
                })
            }
        })
    },
    showFieldCert: function(b) {
        var c = this.getLayoutPrefix(this.action);
        var d = this.getForm().findField(c + "verify_cert");
        var a = this.getForm().findField(c + "cert_buttons");
        if (b) {
            d.show();
            a.show()
        } else {
            d.hide();
            a.hide()
        }
        this.doLayout()
    },
    onCertVerifyFailed: function(a, b) {
        var c = this.getLayoutPrefix(this.action);
        var d = this.getForm().findField(c + "verify_cert");
        d.removeClass("syno-backup-orange-status");
        d.removeClass("syno-backup-red-status");
        d.removeClass("syno-backup-green-status");
        d.addClass("syno-backup-red-status");
        d.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_failed"));
        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "certificate_check_failed"));
        if (!Ext.isEmpty(a)) {
            SYNO.ux.AddTip(d.getEl(), SYNO.Backup.Util.getCertErrReason(a, b))
        }
        this.ssl_trust_mode = "failed"
    },
    onTrustBtnClick: function() {
        var a = this.getLayoutPrefix(this.action);
        var b = this.getForm().findField(a + "verify_cert");
        b.removeClass("syno-backup-orange-status");
        b.removeClass("syno-backup-red-status");
        b.removeClass("syno-backup-green-status");
        b.addClass("syno-backup-green-status");
        b.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_pass"));
        this.ssl_trust_mode = "trust"
    },
    onIgnoreCertBtnClick: function() {
        var a = this.getLayoutPrefix(this.action);
        var b = this.getForm().findField(a + "verify_cert");
        b.removeClass("syno-backup-orange-status");
        b.removeClass("syno-backup-red-status");
        b.removeClass("syno-backup-green-status");
        b.addClass("syno-backup-orange-status");
        b.setValue(SYNO.SDS.Backup.String("app", "certificate_auth_always_ignore"));
        this.ssl_trust_mode = "ignore"
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    needReloadShare: function() {
        var a = this.getAuthParams();
        if ("create" === this.action) {
            return this.createlastQuery !== Ext.encode(a)
        } else {
            return this.relinklastQuery !== Ext.encode(a)
        }
    },
    getAuthParams: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        var d = this.owner.getParams();
        d.transfer_type = this.transfer_type;
        d.dest = a.findField(b + "dest").getHostAddress();
        d.port = c("port");
        d.account = c("account");
        d.pwd = c("pwd");
        d.is_webapi_authen = c("is_webapi_authen");
        return d
    },
    loadShareStore: function() {
        var a = this.getAuthParams();
        if (Ext.isEmpty(a.dest, false) || Ext.isEmpty(a.port, false) || Ext.isEmpty(a.account, false)) {
            return
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.Share.Network",
            version: 1,
            method: "list",
            encryption: ["pwd"],
            params: a,
            scope: this,
            callback: function(g, b, c) {
                this.owner.clearStatusBusy();
                if (!g) {
                    if (b.code == SYNO.SDS.Backup.ERR_NO_RESPONSE) {
                        b.code = SYNO.SDS.Backup.ERR_SERVICE_DISABLE
                    }
                    this.owner.reportError(b);
                    return false
                }
                if (!b.capabilities.support_backup_to_share) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(SYNO.SDS.Backup.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD));
                    return false
                }
                if (0 === b.share_list.length) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"));
                    return false
                }
                Ext.each(b.share_list, function(i, h) {
                    if (0 === i[1]) {
                        return false
                    }
                    if (h === b.share_list.length - 1) {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
                    }
                }, this);
                if ("create" === this.action) {
                    this.createlastQuery = Ext.encode(a)
                } else {
                    this.relinklastQuery = Ext.encode(a)
                }
                this.getShareStore().loadData(b.share_list);
                var e = this.getLayoutPrefix(this.action);
                if ("create" === this.action) {
                    var f = this.getForm().findField(e + "share");
                    f.el.focus();
                    f.expand();
                    f.restrictHeight()
                }
                this.owner.support_rotate = b.capabilities.support_rotate;
                this.owner.support_ssl = b.capabilities.support_ssl;
                if (false === this.owner.support_ssl) {
                    this.getForm().findField(e + "sslcheck").setValue(false)
                }
                var d = {};
                this.getForm().setValues(d)
            }
        })
    },
    getShareStore: function() {
        if (!this.shareStore) {
            this.shareStore = new Ext.data.ArrayStore({
                fields: ["share", "status", "conflict_repo", "is_data_enc"]
            })
        }
        return this.shareStore
    },
    hasAuthen: function() {
        var a = this.getLayoutPrefix(this.action);
        return "true" == this.getForm().findField(a + "is_webapi_authen").getValue()
    },
    shareValidator: function(b) {
        var a = b.ownerCt;
        if (a.get(0).isValid() && a.get(2).isValid() && a.get(3).isValid() && a.get(4).isValid()) {
            if (!this.hasAuthen()) {
                b.markInvalid(SYNO.SDS.Backup.String("error", "loss_login"))
            }
            return true
        } else {
            b.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        }
        return false
    },
    relinkValidator: function(b, c) {
        var a = b.ownerCt;
        if (a.get(0).isValid() && a.get(2).isValid() && a.get(3).isValid() && a.get(4).isValid() && a.get(5).isValid()) {
            return true
        } else {
            b.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        }
        return false
    },
    getNext: function() {
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(d) {
                return a.findField(b + d).getValue()
            };
        if (!c("sslcheck") || ("trust" === this.ssl_trust_mode) || ("ignore" === this.ssl_trust_mode) || ("pass" === this.ssl_trust_mode)) {
            return this.callParent(arguments)
        }
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository.Certificate",
            version: 1,
            method: "verify",
            params: {
                action: "for_create",
                transfer_type: "image_remote",
                target_type: "image",
                dest: a.findField(b + "dest").getHostAddress(),
                port: c("port"),
                account: c("account"),
                pwd: c("pwd"),
                verify_cert: true
            },
            callback: function(f, d, e) {
                if (!f || !d.verify_success) {
                    this.onCertVerifyFailed(d.verify_err_reason, d.err_cert);
                    this.owner.clearStatusBusy();
                    return
                }
                this.ssl_trust_mode = "pass";
                this.getNext();
                this.owner.clearStatusBusy()
            },
            scope: this
        });
        return false
    },
    getParams: function() {
        var e = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            d = function(g) {
                return a.findField(b + g).getValue()
            };
        e.verify_cert = this.verify_cert;
        if ("export" !== this.action) {
            e.share = d("share");
            e.dest = a.findField(b + "dest").getHostAddress();
            e.port = d("port");
            e.account = d("account");
            e.pwd = d("pwd");
            e.sslcheck = d("sslcheck");
            e.is_webapi_authen = d("is_webapi_authen");
            if (e.sslcheck) {
                e.ssl_trust_mode = this.ssl_trust_mode
            }
            var c = this.getShareStore().getAt(this.getShareStore().find("share", d("share")));
            if (c) {
                e.isDestEncShare = c.get("is_data_enc")
            }
        }
        e.clientEncrypt = this.needEnableClientEncrypt(e);
        return e
    }
});
(function() {
    Ext.define("SYNO.Backup.Addon.rsync.Destination.SettingPanel", {
        extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
        constructor: function(a) {
            Ext.copyTo(this, a, "owner,action");
            this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
            this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
            return this.callParent(arguments)
        },
        getAuthFields: function(b) {
            var a = [{
                xtype: "syno_combobox",
                name: b + "network_type",
                indent: this.getFieldIndent(),
                width: 270,
                fieldLabel: _T("netbackup", "netbkp_slct_server"),
                allowBlank: false,
                store: this.getServerStore(),
                displayField: "server",
                valueField: "value",
                value: "rsync_ds",
                editable: false,
                listeners: {
                    scope: this,
                    select: function(d, c, e) {
                        this.changeLayout(this.action, c.get("value"))
                    }
                }
            }, new SYNO.SDS.Backup.HostCombobox({
                width: 270,
                name: b + "dest",
                indent: this.getFieldIndent(),
                owner: this.owner
            }), {
                xtype: "syno_combobox",
                name: b + "encrypt_connect",
                indent: this.getFieldIndent(),
                width: 270,
                fieldLabel: SYNO.SDS.Backup.String("rsync", "transfer_encryption"),
                allowBlank: false,
                store: new Ext.data.ArrayStore({
                    fields: ["text", "value"],
                    data: [
                        [SYNO.SDS.Backup.String("app", "on"), true],
                        [SYNO.SDS.Backup.String("app", "off"), false]
                    ]
                }),
                displayField: "text",
                valueField: "value",
                editable: false,
                value: false,
                listeners: {
                    scope: this,
                    select: function(d, c, e) {
                        this.changeEncTransLayout(this.action, c.get("value"))
                    }
                }
            }, {
                xtype: "syno_numberfield",
                maxlength: 5,
                vtype: "port",
                name: b + "port",
                indent: this.getFieldIndent(),
                value: 873,
                width: 270,
                allowBlank: false,
                fieldLabel: _T("common", "port")
            }, {
                xtype: "syno_numberfield",
                maxlength: 5,
                vtype: "port",
                name: b + "enc_port",
                indent: this.getFieldIndent(),
                value: 22,
                width: 270,
                allowBlank: false,
                fieldLabel: _T("common", "port"),
                hidden: true,
                disabled: true
            }, {
                xtype: "syno_textfield",
                name: b + "account",
                indent: this.getFieldIndent(),
                width: 270,
                allowBlank: false,
                fieldLabel: _T("netbackup", "netbkp_account"),
                validator: (function(d) {
                    var c = d;
                    if (this.getForm().findField(b + "network_type").getValue() === "rsync") {
                        c = c.replace(/%/g, "a")
                    }
                    return Ext.form.VTypes.username_ext(c)
                }).createDelegate(this),
                invalidText: Ext.form.VTypes.username_extText
            }, {
                xtype: "syno_textfield",
                name: b + "pwd",
                indent: this.getFieldIndent(),
                width: 270,
                allowBlank: true,
                fieldLabel: _T("common", "password"),
                inputType: "password"
            }, new SYNO.SDS.Backup.ComboBox({
                name: b + "module",
                indent: this.getFieldIndent(),
                width: 270,
                owner: this.owner,
                fieldLabel: _T("netbackup", "netbkp_module"),
                allowBlank: false,
                store: this.getModuleStore(),
                displayField: "share",
                valueField: "share",
                editable: true,
                hidden: true,
                disabled: true,
                scope: this,
                clickValidator: this.shareValidator,
                getParams: {
                    scope: this,
                    handler: this.getAuthParams
                },
                listeners: {
                    scope: this,
                    beforeselect: function(d, c, e) {
                        if (c.get("status") !== 0) {
                            return false
                        }
                    },
                    select: function(e, c, d) {
                        if ("create" === this.action) {
                            this.updateTarget()
                        }
                    }
                },
                tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.share)]}" class="x-combo-list-item {[values.status === 0 ? "syno-backup-enabled-list-item" : "syno-backup-disabled-list-item"]}">{share:htmlEncode}</div></tpl>'
            }), new SYNO.SDS.Backup.ComboBox({
                name: b + "share",
                indent: this.getFieldIndent(),
                width: 270,
                allowBlank: false,
                owner: this.owner,
                fieldLabel: _T("tree", "leaf_sharefolder"),
                forceSelection: true,
                store: this.getShareStore(),
                displayField: "share",
                valueField: "share",
                clickValidator: this.shareValidator,
                getParams: {
                    scope: this,
                    handler: this.getAuthParams
                },
                scope: this,
                listeners: {
                    scope: this,
                    beforeselect: function(d, c, e) {
                        if (c.get("status") !== 0) {
                            return false
                        }
                    },
                    select: function(e, c, d) {
                        if ("create" === this.action) {
                            this.updateTarget()
                        }
                    }
                },
                tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.share)]}" class="x-combo-list-item {[values.status === 0 ? "syno-backup-enabled-list-item" : "syno-backup-disabled-list-item"]}">{share:htmlEncode}</div></tpl>'
            })];
            return a
        },
        getModuleStore: function() {
            if (!this.moduleStore) {
                this.moduleStore = new Ext.data.ArrayStore({
                    proxy: new SYNO.API.Proxy({
                        api: "SYNO.Backup.Storage.Share.Rsync",
                        version: 1,
                        method: "list",
                        encryption: ["pwd"]
                    }),
                    root: "share_list",
                    autoDestroy: true,
                    autoLoad: false,
                    fields: ["share", "status", "conflict_repo"],
                    listeners: {
                        load: function(b, a, c) {
                            if (0 === a.length) {
                                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_modules_available"))
                            }
                        },
                        scope: this
                    }
                })
            }
            return this.moduleStore
        },
        getShareStore: function() {
            if (!this.shareStore) {
                this.shareStore = new Ext.data.ArrayStore({
                    proxy: new SYNO.API.Proxy({
                        api: "SYNO.Backup.Storage.Share.Rsync",
                        version: 1,
                        method: "list",
                        encryption: ["pwd"]
                    }),
                    root: "share_list",
                    autoDestroy: true,
                    autoLoad: false,
                    fields: ["share", "status", "conflict_repo"],
                    listeners: {
                        load: function(b, a, c) {
                            if (0 === a.length) {
                                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "no_shared_folder_available"))
                            }
                        },
                        scope: this
                    }
                })
            }
            return this.shareStore
        },
        onFieldsetSelected: function(a) {
            var b = a.get(0);
            if (!b) {
                return
            }
            if ("create_fields" === a.name || "relink_fields" === a.name) {
                this.changeLayout(this.action, b.getValue())
            }
        },
        getServerStore: function() {
            if (!this.serverStore) {
                this.serverStore = new Ext.data.ArrayStore({
                    fields: ["server", "value"],
                    data: [
                        [String.format(SYNO.SDS.Backup.String("rsync", "synology_rsync_server"), _D("company_title")), "rsync_ds"],
                        [_T("netbackup", "rsync_compatible_server"), "rsync"]
                    ]
                })
            }
            return this.serverStore
        },
        getLayoutPrefix: function(a) {
            return "create" === a ? "create_" : "relink_"
        },
        changeLayout: function(f, e) {
            var d = this.getLayoutPrefix(f);
            var c = this.getForm();
            var a = function(h, g) {
                c.findField(d + h).setDisabled(!g);
                c.findField(d + h).setVisible(g)
            };
            var b = function(h, g) {
                a("share", h);
                a("module", g)
            };
            if ("rsync_ds" === e) {
                b(true, false)
            } else {
                if ("rsync" === e) {
                    b(false, true)
                }
            }
        },
        changeEncTransLayout: function(f, d) {
            var e = this.getLayoutPrefix(f);
            var c = this.getForm();
            var a = function(h, g) {
                c.findField(e + h).setDisabled(!g);
                c.findField(e + h).setVisible(g)
            };
            var b = function(g, h) {
                a("port", g);
                a("enc_port", h)
            };
            if (d) {
                b(false, true)
            } else {
                b(true, false)
            }
        },
        getAuthParams: function() {
            var a = Ext.copyTo({}, this.getParams(), "transfer_type,dest,account,pwd,encrypt_connect,port,enc_port");
            a.action = this.action;
            return a
        },
        shareValidator: function(d, e) {
            var b = "create" === e.action ? "create_" : "relink_";
            var c = function(g) {
                return d.ownerCt.find("name", b + g)[0].getValue()
            };
            var a = function(g) {
                return d.ownerCt.find("name", b + g)[0].isValid()
            };
            if (a("network_type") && a("dest") && (c("encrypt_connect") ? a("enc_port") : a("port")) && a("account")) {
                return true
            }
            d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        },
        relinkValidator: function(d, e) {
            var b = "create" === e.action ? "create_" : "relink_";
            var c = function(g) {
                return d.ownerCt.find("name", b + g)[0].getValue()
            };
            var a = function(g) {
                return d.ownerCt.find("name", b + g)[0].isValid()
            };
            if ("rsync_ds" === e.transfer_type) {
                if (a("network_type") && a("dest") && (c("encrypt_connect") ? a("enc_port") : a("port")) && a("account") && a("share")) {
                    return true
                }
            } else {
                if ("rsync" === e.transfer_type) {
                    if (a("network_type") && a("dest") && (c("encrypt_connect") ? a("enc_port") : a("port")) && a("account") && a("module")) {
                        return true
                    }
                }
            }
            d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
            return false
        },
        getParams: function() {
            var d = this.callParent();
            var b = this.getLayoutPrefix(this.action);
            var a = this.getForm(),
                c = function(e) {
                    return a.findField(b + e).getValue()
                };
            if ("export" !== this.action) {
                d.transfer_type = c("network_type");
                d.dest = a.findField(b + "dest").getHostAddress();
                d.account = c("account");
                d.pwd = c("pwd");
                d.encrypt_connect = c("encrypt_connect");
                if (d.encrypt_connect) {
                    d.enc_port = c("enc_port")
                } else {
                    d.port = c("port")
                }
                if ("rsync_ds" === d.transfer_type) {
                    d.share = c("share")
                } else {
                    d.module = c("module");
                    if ("/" === d.module.charAt(0)) {
                        d.remoteshell = true;
                        d.encrypt_connect = true;
                        if (!Ext.isDefined(d.enc_port)) {
                            d.enc_port = 22;
                            delete d.port
                        }
                    }
                }
            }
            return d
        }
    });
    Ext.define("SYNO.Backup.Addon.rsync_ds.Destination.SettingPanel", {
        extend: "SYNO.Backup.Addon.rsync.Destination.SettingPanel"
    })
}());
Ext.ns("SYNO.Backup.Addon.sfr_s3.Destination");
Ext.define("SYNO.Backup.Addon.sfr_s3.Destination.SettingPanel", {
    extend: "SYNO.SDS.Backup.Addon.Util.Image.S3.Repository.CreateStep",
    addon_id: "image_sfr"
});
Ext.ns("SYNO.SDS.Backup.Addon.webdav.Repository");
Ext.define("SYNO.SDS.Backup.Addon.webdav.Repository.CreateBucket", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(b) {
        var e = 450,
            a = 200;
        this.remote_url = b.remote_url;
        this.account = b.account;
        this.pwd = b.pwd;
        this.transfer_type = b.transfer_type;
        var c = [{
            xtype: "syno_textfield",
            name: "bucket",
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "root_folder"),
            validator: function(f) {
                if (f.match(/[//]/)) {
                    return SYNO.SDS.Backup.String("webdav", "root_folder_name_letter_limit")
                }
                return true
            },
            owner: this
        }];
        var d = Ext.apply({
            title: SYNO.SDS.Backup.String("webdav", "create_root_folder"),
            width: e,
            height: a,
            minWidth: e,
            minHeight: a,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: true,
                itemId: "form_panel",
                items: c
            }],
            buttons: [{
                itemId: "btn_apply",
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onCreate
            }, {
                text: _T("common", "cancel"),
                handler: function() {
                    this.close()
                },
                scope: this
            }]
        }, b);
        return this.callParent([d])
    },
    onCreate: function() {
        if (!this.items.get(0).getForm().isValid()) {
            return
        }
        this.setStatusBusy();
        var a = {
            remote_url: this.remote_url,
            account: this.account,
            pwd: this.pwd,
            transfer_type: this.transfer_type,
            container: this.items.get(0).getForm().findField("bucket").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.WebDAV.Container",
            version: 1,
            method: "create",
            encryption: ["pwd"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                var e = this.items.get(0).getForm().findField("bucket").getValue();
                this.clearStatusBusy();
                if (!d) {
                    this.showPossibleBucketError(b.code, e);
                    return false
                }
                this.close()
            }
        })
    },
    showPossibleBucketError: function(a, c) {
        var b = SYNO.SDS.Backup.GetErrorString(a);
        this.getMsgBox().alert(_T("tree", "leaf_backup"), b);
        return
    }
});
Ext.ns("SYNO.Backup.Addon.webdav.Destination");
Ext.define("SYNO.Backup.Addon.webdav.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,action");
        this.uni_key = null;
        this.createFields = this.getAuthFields(this.getLayoutPrefix("create"));
        this.relinkFields = this.getAuthFields(this.getLayoutPrefix("relink"));
        return this.callParent(arguments)
    },
    getAuthFields: function(b) {
        var a = [{
            xtype: "syno_textfield",
            name: b + "remote_url",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "url")
        }, {
            xtype: "syno_textfield",
            name: b + "account",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "username")
        }, {
            xtype: "syno_textfield",
            name: b + "pwd",
            indent: this.getFieldIndent(),
            width: 270,
            allowBlank: false,
            inputType: "password",
            fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input")
        }, {
            xtype: "syno_combobox",
            name: b + "bucket",
            indent: this.getFieldIndent(),
            width: 270,
            fieldLabel: SYNO.SDS.Backup.String("webdav", "root_folder_name"),
            store: this.getBucketStore(),
            displayField: "bucket",
            allowBlank: false,
            valueField: "bucket",
            scope: this,
            onTriggerClick: function() {
                if (this.readOnly || this.disabled) {
                    return
                }
                if (!this.scope.shareValidator(this)) {
                    return
                }
                if (this.scope.needReloadBucket()) {
                    this.scope.loadBucketStore()
                } else {
                    SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
                }
            },
            listeners: {
                select: function(e, c, d) {
                    if ("create" === this.action) {
                        if (d === 0) {
                            this.createBucket();
                            return
                        }
                        this.updateTarget(c.get("bucket"))
                    }
                },
                beforeselect: function(d, c, e) {
                    if (c.get("status") > 0) {
                        return false
                    }
                },
                scope: this
            },
            tpl: '<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.status === 1 ? String.format(_T("backup", "repo_already_exist") + " [" + values.conflict_repo + "]") : values.bucket)]}" class="x-combo-list-item {[values.status === 1 ? "syno-backup-disabled-list-item" : "syno-backup-enabled-list-item"]}">{bucket:htmlEncode}</div></tpl>'
        }];
        return a
    },
    getLayoutPrefix: function(a) {
        return "create" === a ? "create_" : "relink_"
    },
    getRemoteUrlValue: function() {
        var c = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            d = function(e) {
                return a.findField(c + e).getValue()
            };
        var b = d("remote_url").trim();
        while (0 < b.length && b[b.length - 1] == "/") {
            b = b.slice(0, -1)
        }
        if (b.substring(0, 7) !== "http://" && b.substring(0, 8) !== "https://") {
            return "http://" + b
        }
        return b
    },
    createBucket: function() {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            d = function(e) {
                return b.findField(c + e).getValue()
            };
        var a = new SYNO.SDS.Backup.Addon.webdav.Repository.CreateBucket({
            remote_url: this.getRemoteUrlValue(),
            account: d("account"),
            pwd: d("pwd"),
            transfer_type: this.transfer_type,
            owner: this.owner
        });
        this.mon(a, "close", function() {
            var e = a.items.get(0).getForm().findField("bucket").getValue();
            this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket").clearValue();
            this.loadBucketStore(e)
        }, this);
        a.open()
    },
    getBucketStore: function() {
        if (!this.bucketStore) {
            this.bucketStore = new Ext.data.ArrayStore({
                fields: ["bucket", "status", "conflict_repo"]
            })
        }
        return this.bucketStore
    },
    getLoadBucketParams: function() {
        var a = this.getParams();
        delete a.bucket;
        return a
    },
    needReloadBucket: function() {
        var a = this.getLoadBucketParams();
        return this.lastQuery !== Ext.encode(a)
    },
    loadBucketStore: function(a) {
        var b = this.getLoadBucketParams();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Storage.WebDAV.Container",
            version: 1,
            method: "list",
            encryption: ["pwd"],
            params: b,
            scope: this,
            callback: function(h, c, d) {
                this.owner.clearStatusBusy();
                if (!h) {
                    this.owner.reportError(c);
                    return
                }
                this.lastQuery = Ext.encode(b);
                this.getBucketStore().loadData(c.bucket_list);
                var g;
                if ("create" === this.action) {
                    g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket");
                    var e = new Ext.data.Record.create(["bucket", "status", "conflict_repo"]);
                    var f = new e({
                        bucket: SYNO.SDS.Backup.String("webdav", "create_root_folder"),
                        status: 0,
                        conflict_repo: ""
                    });
                    this.getBucketStore().insert(0, f)
                } else {
                    if ("relink" === this.action || "import" === this.action) {
                        g = this.getForm().findField(this.getLayoutPrefix(this.action) + "bucket")
                    }
                }
                if (a && -1 !== this.getBucketStore().findExact("bucket", a) && 0 === this.getBucketStore().getAt(this.getBucketStore().findExact("bucket", a)).get("status")) {
                    g.setValue(a);
                    g.collapse();
                    this.updateTarget()
                } else {
                    if (g) {
                        g.el.focus();
                        g.expand();
                        g.restrictHeight()
                    }
                }
            }
        })
    },
    shareValidator: function(d) {
        var c = this.getLayoutPrefix(this.action);
        var b = this.getForm(),
            a = function(e) {
                return b.findField(c + e).isValid()
            };
        if (a("remote_url") && a("account") && a("pwd")) {
            return true
        }
        d.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    relinkValidator: function(c, d) {
        var b = "create" === d.action ? "create_" : "relink_";
        var a = function(e) {
            return c.ownerCt.find("name", b + e)[0].isValid()
        };
        if (a("remote_url") && a("account") && a("pwd") && a("bucket")) {
            return true
        }
        c.markInvalid(SYNO.SDS.Backup.String("error", "loss_auth_info"));
        return false
    },
    getParams: function() {
        var d = this.callParent();
        var b = this.getLayoutPrefix(this.action);
        var a = this.getForm(),
            c = function(e) {
                return a.findField(b + e).getValue()
            };
        if ("export" !== this.action) {
            d.transfer_type = this.transfer_type;
            d.remote_url = this.getRemoteUrlValue();
            d.account = c("account");
            d.pwd = c("pwd");
            d.bucket = c("bucket")
        }
        return d
    }
});
Ext.ns("SYNO.Backup.Addon.synocloud.Destination");
Ext.define("SYNO.Backup.Addon.synocloud.Destination.SettingPanel", {
    extend: "SYNO.Backup.Addon.base.Destination.SettingPanel",
    constructor: function(a) {
        this.uni_key = null;
        this.createFields = [];
        this.relinkFields = [];
        this.export_quota_threshold = 20 * 1024 * 1024 * 1024 * 1024;
        this.default_target = null;
        return this.callParent(arguments)
    },
    initComponent: function() {
        this.callParent(arguments);
        this.displayExportOption(false)
    },
    setOauthResponse: function(a) {
        this.key = a.access_token;
        this.secret = a.refresh_token;
        this.tenant_id = a.openstack_token;
        this.region = "eu";
        if (!Ext.isEmpty(a.region)) {
            this.region = a.region
        }
        if (!Ext.isEmpty(a.account_meta)) {
            this.owner.accountMeta.setSynoCloudData(Ext.util.JSON.decode(a.account_meta))
        } else {
            this.owner.accountMeta = SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta()
        }
        if ("import" !== this.action) {
            this.updateDefaultTarget()
        }
    },
    updateDefaultTarget: function() {
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Core.System",
            method: "info",
            version: 1,
            params: {
                type: "network"
            },
            callback: this.updateDefaultTargetDone,
            scope: this
        })
    },
    updateDefaultTargetDone: function(d, c, b) {
        this.owner.clearStatusBusy();
        if (!d || c === undefined || !Ext.isArray(c.nif)) {
            this.owner.getMsgBox().alert(this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system")));
            return
        }
        this.default_target = c.hostname.toLowerCase() + new Date().format("_Ymd_His");
        this.getForm().findField("target_id").setValue(this.default_target);
        var a = Ext.urlDecode(location.search.substr(1)).c2export;
        if (a === "true") {
            this.displayExportOption(true)
        }
    },
    getExportFieldsExunit: function() {
        var a = [{
            xtype: "syno_radio",
            name: "creating_action",
            boxLabel: SYNO.SDS.Backup.String("app", "wizard_export_option_c2_exunit"),
            inputValue: "export",
            listeners: {
                check: function(c, b) {
                    if (b) {
                        this.action = "export";
                        this.export_method = "exunit";
                        this.updateFieldView(["export_fields_exunit"], ["create_fields", "relink_fields", "export_fields_fireball"])
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_fieldset",
            name: "export_fields_exunit",
            defaults: {
                labelWidth: 300
            },
            bwrapStyle: {
                padding: 0
            },
            collapsible: false,
            items: [new SYNO.SDS.Backup.ComboBox({
                name: "export_share",
                fieldLabel: _T("tree", "leaf_sharefolder"),
                allowBlank: false,
                indent: 1,
                width: 270,
                forceSelection: true,
                owner: this.owner,
                store: this.getExportShareStore(),
                displayField: "share",
                valueField: "share",
                listeners: {
                    enable: function(c, b) {
                        this.updateExportShareStore()
                    },
                    beforeselect: function(c, b, d) {
                        if (0 !== b.get("status")) {
                            return false
                        }
                    },
                    scope: this
                },
                tpl: SYNO.SDS.Backup.getShareListTpl("share")
            }), {
                xtype: "syno_textfield",
                name: "export_dir",
                indent: 1,
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target"
            }]
        }];
        return a
    },
    getExportFieldsFireball: function() {
        var a = [{
            xtype: "syno_radio",
            name: "creating_action",
            boxLabel: SYNO.SDS.Backup.String("app", "wizard_export_option_c2_fireball"),
            inputValue: "export",
            listeners: {
                check: function(c, b) {
                    if (b) {
                        this.action = "export";
                        this.export_method = "fireball";
                        this.updateFieldView(["export_fields_fireball"], ["create_fields", "relink_fields", "export_fields_exunit"])
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_fieldset",
            name: "export_fields_fireball",
            defaults: {
                labelWidth: 300
            },
            bwrapStyle: {
                padding: 0
            },
            collapsible: false,
            items: [{
                xtype: "syno_textfield",
                name: "export_fireball_url",
                fieldLabel: SYNO.SDS.Backup.String("synocloud", "url"),
                allowBlank: false,
                indent: 1,
                width: 270
            }, {
                xtype: "syno_textfield",
                name: "export_dir_fireball",
                indent: 1,
                fieldLabel: _T("backup", "backup_dest_directory"),
                width: 270,
                maxLength: 32,
                allowBlank: false,
                vtype: "backup_target",
                listeners: {
                    enable: function(c, b) {
                        this.updateExportTarget("export_dir_fireball")
                    },
                    scope: this
                }
            }]
        }];
        return a
    },
    getExportFields: function() {
        var a = [];
        a = a.concat(this.getExportFieldsExunit());
        a = a.concat(this.getExportFieldsFireball());
        return a
    },
    displayExportOption: function(a) {
        this.get(0).items.each(function(b) {
            if ("creating_action" === b.name && "export" === b.inputValue) {
                if (a === true) {
                    b.show();
                    b.enable()
                } else {
                    b.hide();
                    b.disable()
                }
            }
        }, this)
    },
    updateFieldView: function(c, b) {
        var a = b.indexOf("export_fields");
        if (0 <= a) {
            b.splice(a, 1, "export_fields_exunit", "export_fields_fireball")
        }
        this.callParent(arguments)
    },
    updateExportShareStore: function() {
        var a = this.getExportShareStore();
        a.load({
            scope: this,
            callback: function(c, b, d) {
                this.updateExportTarget("export_dir");
                Ext.each(c, function(g, f) {
                    var e = g.get("share");
                    if (e.startsWith("synology_cloud_export_share")) {
                        this.getForm().findField("export_share").setValue(e);
                        return
                    }
                }, this)
            }
        })
    },
    checkFireball: function() {
        var a = this.getParams();
        delete a.isDestEncShare;
        delete a.clientEncrypt;
        a.fireball_url = this.getForm().findField("export_fireball_url").getValue();
        a.fireball_mount_source = ":/volume1/synology_cloud_export_share";
        a.fireball_mount_target = "/mnt/synology_cloud_export_share";
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "mount_fireball",
            params: a,
            scope: this,
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.code));
                    return
                }
                this.checkExportDest()
            }
        })
    },
    updateExportTarget: function(a) {
        if (this.getForm().findField(a).isDirty()) {
            return
        }
        var b = Ext.apply(this.owner.getParams(), this.getParams());
        delete b.isDestEncShare;
        delete b.clientEncrypt;
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "get_candidate_dir",
            encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], b),
            params: b,
            scope: this,
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c.code));
                    return
                }
                this.getForm().findField(a).setValue(c.candidate_dir)
            }
        })
    },
    getParams: function() {
        var c = this.callParent();
        c.transfer_type = this.transfer_type;
        c.key = this.key;
        c.secret = this.secret;
        c.tenant_id = this.tenant_id;
        c.region = this.region;
        var b = Ext.urlDecode(location.search.substr(1)).everest;
        if (b === "c2test") {
            c.remote_url = String.format("https://api.{0}.c2test.synology.com", c.region)
        } else {
            if (b === "insecure") {
                c.verify_cert = false
            }
        }
        if ("export" == this.action) {
            var a = this.getForm().getFieldValues();
            if ("exunit" === this.export_method) {
                c.share = a.export_share;
                c.target_id = a.export_dir
            } else {
                if ("fireball" === this.export_method) {
                    if (!Ext.isEmpty(a.export_fireball_url)) {
                        c.dest = a.export_fireball_url
                    }
                    c.share = "/mnt/synology_cloud_export_share";
                    c.target_id = a.export_dir_fireball
                }
            }
            c.target_id += ".hbk"
        }
        return c
    },
    checkExportDest: function() {
        var d = Ext.apply(this.owner.getParams(), this.getParams());
        delete d.isDestEncShare;
        delete d.clientEncrypt;
        var a = Ext.apply({}, d);
        var c = Ext.apply({}, d);
        var b = Ext.apply({}, d);
        b.transfer_type = "local";
        this.owner.setStatusBusy();
        this.sendWebAPI({
            compound: {
                stopwhenerror: false,
                mode: "parallel",
                params: [{
                    api: "SYNO.Backup.Repository",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], d),
                    params: Ext.apply(a, {
                        additional: ["is_usb_share", "support_compression", "support_app_share", "support_error_detect", "support_detect_time_limit", "support_version_file_log"]
                    })
                }, {
                    api: "SYNO.Backup.Target",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], d),
                    params: Ext.apply(c, {
                        additional: ["relinkable", "task_config"]
                    })
                }, {
                    api: "SYNO.Backup.Target",
                    version: 1,
                    method: "get",
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], d),
                    params: Ext.apply(b, {
                        additional: ["relinkable", "task_config"]
                    })
                }]
            },
            timeout: 240000,
            scope: this,
            callback: this.checkExportDestDone
        })
    },
    checkExportDestDone: function(f, e, d) {
        this.owner.clearStatusBusy();
        var b = e.result[0];
        var c = e.result[1];
        var a = e.result[2];
        if (!f) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c.error.code));
            return
        }
        if (!b.success) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.error.code));
            return
        }
        this.owner.is_usb_share = b.data.is_usb_share;
        this.owner.support_compression = b.data.support_compression;
        this.owner.support_app_share = b.data.support_app_share;
        this.owner.support_detect_time_limit = b.data.support_detect_time_limit;
        this.owner.support_error_detect = b.data.support_error_detect;
        this.owner.support_version_file_log = b.data.support_version_file_log;
        if ("export" === this.action) {
            if (c.success) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(SYNO.SDS.Backup.ERR_TARGET_EXIST))
            } else {
                if (a.success) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "target_exist_export_dest"))
                } else {
                    if (SYNO.SDS.Backup.ERR_TARGET_BROKEN === c.error.code) {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "share_exist"))
                    } else {
                        if (SYNO.SDS.Backup.ERR_TARGET_BROKEN === a.error.code) {
                            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("error", "share_exist_export_dest"))
                        } else {
                            if (SYNO.SDS.Backup.ERR_TARGET_NOT_EXIST === c.error.code && SYNO.SDS.Backup.ERR_TARGET_NOT_EXIST === a.error.code) {
                                this.goToNextStep(this.nextId)
                            } else {
                                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c.error.code))
                            }
                        }
                    }
                }
            }
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"))
        }
        return
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        var a = Ext.apply(this.owner.getParams(), this.getParams());
        if ("create" === a.action && this.getForm().findField("target_id").getValue() === this.default_target) {
            this.owner.support_compression = true;
            this.owner.support_app_share = true;
            this.owner.support_detect_time_limit = true;
            this.owner.support_error_detect = true;
            this.owner.support_version_file_log = true;
            this.owner.loadAppParams();
            return this.nextId
        }
        if ("export" !== a.action) {
            return this.callParent(arguments)
        }
        if ("fireball" === this.export_method) {
            this.checkFireball()
        } else {
            this.checkExportDest()
        }
        return false
    }
});
Ext.ns("SYNO.Backup.Addon.base.Destination");
SYNO.Backup.Addon.base.Destination.getInfo = function(b, d) {
    var c = [];
    if ("rsync" === b.transferType || "rsync_ds" === b.transferType || !("cloud" === b.targetType || "cloud_image" === b.targetType)) {
        c = c.concat(d)
    } else {
        if (!Ext.isEmpty(b.repository.remote_url)) {
            c.push({
                key: SYNO.Backup.Addon.Util.getString(b.stringSection, "url"),
                text: b.repository.remote_url
            })
        } else {
            c.push({
                key: _T("backup", "s3_provider"),
                text: SYNO.Backup.Addon.Util.getString(b.stringSection, "name"),
                regionWebLink: b.regionWebLink
            })
        }
        if ("exportable" === b.taskState || "importable" === b.taskState) {
            c.push({
                key: _T("tree", "leaf_sharefolder"),
                text: b.repository.share ? b.repository.share : _T("common", "loading")
            })
        } else {
            c = c.concat(d)
        }
        c.push({
            key: _T("backup", "backup_dest_directory"),
            text: b.targetId ? b.targetId : _T("common", "loading")
        })
    }
    if (b.isImage) {
        c.push({
            id: "space",
            key: SYNO.SDS.Backup.String("app", "space_usage"),
            text: b.spaceUsage ? b.spaceUsage : _T("backup", "calculating")
        });
        var a = b.lastDetectTime ? b.lastDetectTime : _T("backup", "calculating");
        c.push({
            id: "last_detect_time",
            key: SYNO.SDS.Backup.String("app", "last_detect_time"),
            text: a
        })
    }
    return c
};
Ext.ns("SYNO.Backup.Addon.amazon_cloud_drive.Destination");
SYNO.Backup.Addon.amazon_cloud_drive.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "root_folder_name"),
        text: a.repository.container ? a.repository.container : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.aws_s3.Destination");
SYNO.Backup.Addon.aws_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.azure_blob.Destination");
SYNO.Backup.Addon.azure_blob.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "container"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.azure_cn_blob.Destination");
SYNO.Backup.Addon.azure_cn_blob.Destination.getInfo = SYNO.Backup.Addon.azure_blob.Destination.getInfo;
Ext.ns("SYNO.Backup.Addon.dropbox.Destination");
SYNO.Backup.Addon.dropbox.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "root_folder_name"),
        text: a.repository.container ? a.repository.container : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.google_drive.Destination");
SYNO.Backup.Addon.google_drive.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "root_folder_name"),
        text: a.repository.container ? a.repository.container : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.hidrive.Destination");
SYNO.Backup.Addon.hidrive.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "username"),
        text: a.repository.account ? a.repository.account : _T("common", "loading")
    });
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "root_folder"),
        text: a.repository.share ? a.repository.share : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.hubic.Destination");
SYNO.Backup.Addon.hubic.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "container"),
        text: a.repository.container ? a.repository.container : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.ibm_softlayer.Destination");
SYNO.Backup.Addon.ibm_softlayer.Destination.getInfo = function(b) {
    var d = [];
    if (Ext.isDefined(b.repository.region)) {
        var a = SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping([
            [b.repository.region]
        ]);
        var c = a[0][1];
        d.push({
            key: SYNO.Backup.Addon.Util.getString("openstack", "region"),
            text: c
        })
    }
    d.push({
        key: SYNO.Backup.Addon.Util.getString("openstack", "container"),
        text: b.repository.bucket ? b.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(b, d)
};
Ext.ns("SYNO.Backup.Addon.legacy_aws_s3.Destination");
SYNO.Backup.Addon.legacy_aws_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.legacy_azure_blob.Destination");
SYNO.Backup.Addon.legacy_azure_blob.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "container"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.legacy_hicloud_s3.Destination");
SYNO.Backup.Addon.legacy_hicloud_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.legacy_local.Destination");
SYNO.Backup.Addon.legacy_local.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("tree", "leaf_sharefolder"),
        text: a.repository.share ? a.repository.share : _T("common", "loading")
    });
    b.push({
        key: _T("backup", "backup_dest_directory"),
        text: a.targetId ? a.targetId : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.legacy_rsync.Destination");
SYNO.Backup.Addon.legacy_rsync.Destination.getInfo = function(a) {
    var b = [];
    if (!("exportable" === a.taskState || "importable" === a.taskState)) {
        b.push({
            key: SYNO.SDS.Backup.Util.isValidIPAddr(a.repository.dest) ? _T("common", "ip_addr") : SYNO.SDS.Backup.String("app", "server_name"),
            text: a.repository.dest ? a.repository.dest : _T("common", "loading")
        });
        b.push({
            key: _T("common", "username"),
            text: a.repository.account ? a.repository.account : _T("common", "loading")
        })
    }
    b.push({
        key: _T("tree", "leaf_sharefolder"),
        text: a.repository.share ? a.repository.share : _T("common", "loading")
    });
    b.push({
        key: _T("backup", "backup_dest_directory"),
        text: a.targetId ? a.targetId : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.legacy_rsync_ds.Destination");
SYNO.Backup.Addon.legacy_rsync_ds.Destination.getInfo = SYNO.Backup.Addon.legacy_rsync.Destination.getInfo;
Ext.ns("SYNO.Backup.Addon.legacy_sfr_s3.Destination");
SYNO.Backup.Addon.legacy_sfr_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.local.Destination");
SYNO.Backup.Addon.local.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("tree", "leaf_sharefolder"),
        text: a.repository.share ? a.repository.share : _T("common", "loading")
    });
    b.push({
        key: _T("backup", "backup_dest_directory"),
        text: a.targetId ? a.targetId : _T("common", "loading")
    });
    b.push({
        id: "owner_name",
        key: SYNO.SDS.Backup.String("app", "owner"),
        text: a.ownerName ? a.ownerName : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.openstack.Destination");
SYNO.Backup.Addon.openstack.Destination.getInfo = function(b) {
    var d = [];
    if (Ext.isDefined(b.repository.auth_version) && "1.0" !== b.repository.auth_version) {
        var a = SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping([
            [b.repository.region]
        ]);
        var c = a[0][1];
        d.push({
            key: SYNO.Backup.Addon.Util.getString(b.stringSection, "region"),
            text: c
        })
    }
    d.push({
        key: SYNO.Backup.Addon.Util.getString(b.stringSection, "container"),
        text: b.repository.bucket ? b.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(b, d)
};
Ext.ns("SYNO.Backup.Addon.rackspace.Destination");
SYNO.Backup.Addon.rackspace.Destination.getInfo = function(b) {
    var d = [];
    if (Ext.isDefined(b.repository.region)) {
        var a = SYNO.SDS.Backup.Addon.Util.Image.OpenStack.region_name_mapping([
            [b.repository.region]
        ]);
        var c = a[0][1];
        d.push({
            key: SYNO.Backup.Addon.Util.getString("openstack", "region"),
            text: c
        })
    }
    d.push({
        key: SYNO.Backup.Addon.Util.getString("openstack", "container"),
        text: b.repository.bucket ? b.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(b, d)
};
Ext.ns("SYNO.Backup.Addon.remote.Destination");
SYNO.Backup.Addon.remote.Destination.getInfo = function(a) {
    var b = [];
    if (!("exportable" === a.taskState || "importable" === a.taskState)) {
        b.push({
            key: SYNO.SDS.Backup.Util.isValidIPAddr(a.repository.dest) ? _T("common", "ip_addr") : SYNO.SDS.Backup.String("app", "server_name"),
            text: a.repository.dest ? a.repository.dest : _T("common", "loading")
        });
        b.push({
            key: _T("common", "username"),
            text: a.repository.account ? a.repository.account : _T("common", "loading")
        })
    }
    if (!Ext.isEmpty(a.repository.volume)) {
        b.push({
            key: SYNO.SDS.Backup.String("app", "volume"),
            text: SYNO.SDS.Backup.String("app", "volume") + " " + a.repository.volume.substring(7)
        });
        b.push({
            key: SYNO.SDS.Backup.String("app", "id"),
            text: a.targetId ? a.targetId : _T("common", "loading")
        })
    } else {
        b.push({
            key: _T("tree", "leaf_sharefolder"),
            text: a.repository.share ? a.repository.share : _T("common", "loading")
        });
        b.push({
            key: _T("backup", "backup_dest_directory"),
            text: a.targetId ? a.targetId : _T("common", "loading")
        })
    }
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.rsync.Destination");
SYNO.Backup.Addon.rsync.Destination.getInfo = function(a) {
    var b = [];
    if (!("exportable" === a.taskState || "importable" === a.taskState)) {
        b.push({
            key: SYNO.SDS.Backup.Util.isValidIPAddr(a.repository.dest) ? _T("common", "ip_addr") : SYNO.SDS.Backup.String("app", "server_name"),
            text: a.repository.dest ? a.repository.dest : _T("common", "loading")
        });
        b.push({
            key: _T("common", "username"),
            text: a.repository.account ? a.repository.account : _T("common", "loading")
        })
    }
    b.push({
        key: _T("tree", "leaf_sharefolder"),
        text: a.repository.share ? a.repository.share : _T("common", "loading")
    });
    b.push({
        key: _T("backup", "backup_dest_directory"),
        text: a.targetId ? a.targetId : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.rsync_ds.Destination");
SYNO.Backup.Addon.rsync_ds.Destination.getInfo = SYNO.Backup.Addon.rsync.Destination.getInfo;
Ext.ns("SYNO.Backup.Addon.webdav.Destination");
SYNO.Backup.Addon.webdav.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "username"),
        text: a.repository.account ? a.repository.account : _T("common", "loading")
    });
    b.push({
        key: SYNO.Backup.Addon.Util.getString(a.stringSection, "root_folder"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.sfr_s3.Destination");
SYNO.Backup.Addon.sfr_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.hicloud_s3.Destination");
SYNO.Backup.Addon.hicloud_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.jdcloud_s3.Destination");
SYNO.Backup.Addon.jdcloud_s3.Destination.getInfo = function(a) {
    var b = [];
    b.push({
        key: _T("backup", "s3_bucket"),
        text: a.repository.bucket ? a.repository.bucket : _T("common", "loading")
    });
    return SYNO.Backup.Addon.base.Destination.getInfo(a, b)
};
Ext.ns("SYNO.Backup.Addon.synocloud.Destination");
SYNO.Backup.Addon.synocloud.Destination.RegionMapping = function(a) {
    var b = {
        eu: _T("Country", "EU"),
        us: _T("Country", "US")
    };
    if (a in b) {
        return b[a]
    }
    return ""
};
SYNO.Backup.Addon.synocloud.Destination.getInfo = function(b) {
    var c = [];
    if (Ext.isDefined(b.repository.region)) {
        var a = SYNO.Backup.Addon.synocloud.Destination.RegionMapping(b.repository.region);
        if ("" !== a) {
            c.push({
                key: SYNO.Backup.Addon.Util.getString("synocloud", "region"),
                text: a
            })
        }
    }
    return SYNO.Backup.Addon.base.Destination.getInfo(b, c)
};
Ext.ns("SYNO.Backup.Addon.Util");
SYNO.Backup.Addon.Util.getInfo = function(c) {
    var a = SYNO.Backup.Addon.Config.addon_list;
    var b = a[0];
    Ext.each(a, function(e, d, f) {
        if (c === e.id) {
            b = e
        }
        return
    });
    return b
};
SYNO.Backup.Addon.Util.getInfoByTargetAndTransfer = function(b, a) {
    var c = SYNO.Backup.Addon.Config.addon_list;
    var d = {};
    Ext.each(c, function(f, e, g) {
        if (b === f.target_type && a === f.transfer_type) {
            d = f
        }
        return
    });
    return d
};
SYNO.Backup.Addon.Util.getID = function(c, a) {
    var d = SYNO.Backup.Addon.Config.addon_list;
    var b = "";
    Ext.each(d, function(f, e, g) {
        if (c === f.target_type && a === f.transfer_type) {
            b = f.id
        }
        return
    });
    return b
};
SYNO.Backup.Addon.Util.getClass = function(c, b) {
    var a = String.format("SYNO.Backup.Addon.{0}.{1}", c, b);
    return Ext.getClassByName(a)
};
SYNO.Backup.Addon.Util.getFunc = function(f, d) {
    if (!SYNO.Backup.Addon[f]) {
        return undefined
    }
    var c = SYNO.Backup.Addon[f];
    var b = d.split(".");
    var e;
    if (b.length === 0) {
        return undefined
    }
    for (var a = 0; a < b.length; a++) {
        e = c[b[a]];
        if (!e) {
            return undefined
        }
        c = e
    }
    return c
};
SYNO.Backup.Addon.Util.getString = function(b, a) {
    if ("azure_blob" === b) {
        b = "azure"
    }
    return SYNO.SDS.Backup.String(b, a)
};
SYNO.Backup.Addon.Util.getOathWindowParams = function(f) {
    if (!Ext.isObject(f) || !Ext.isObject(f.oauth)) {
        return null
    }
    var c = f.oauth.url;
    var h = f.oauth.client_id;
    var g = f.oauth.redirect;
    var a = SYNO.Backup.Util.getPkgVersion();
    var d = window.location.origin;
    if (!d) {
        d = window.location.protocol + "//" + window.location.host
    }
    var b = String.format(c, h, g, d, a);
    var e = "width=1264, height=835";
    return {
        url: b,
        specs: e
    }
};
