/*!
 * // @require: SYNO.SDS.WebStation.Errors.GetMessage
 * // @require: SYNO.SDS.Utils.FileChooser.Chooser
 */
! function(t) {
    var e = {};

    function r(n) {
        if (e[n]) return e[n].exports;
        var i = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(i.exports, i, i.exports, r), i.l = !0, i.exports
    }
    r.m = t, r.c = e, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function(t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var i in t) r.d(n, i, function(e) {
                return t[e]
            }.bind(null, i));
        return n
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "", r(r.s = 64)
}([function(t, e, r) {
    "use strict";
    t.exports = function(t) {
        var e = [];
        return e.toString = function() {
            return this.map((function(e) {
                var r = function(t, e) {
                    var r = t[1] || "",
                        n = t[3];
                    if (!n) return r;
                    if (e && "function" == typeof btoa) {
                        var i = (a = n, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(a)))) + " */"),
                            o = n.sources.map((function(t) {
                                return "/*# sourceURL=" + n.sourceRoot + t + " */"
                            }));
                        return [r].concat(o).concat([i]).join("\n")
                    }
                    var a;
                    return [r].join("\n")
                }(e, t);
                return e[2] ? "@media " + e[2] + "{" + r + "}" : r
            })).join("")
        }, e.i = function(t, r) {
            "string" == typeof t && (t = [
                [null, t, ""]
            ]);
            for (var n = {}, i = 0; i < this.length; i++) {
                var o = this[i][0];
                null != o && (n[o] = !0)
            }
            for (i = 0; i < t.length; i++) {
                var a = t[i];
                null != a[0] && n[a[0]] || (r && !a[2] ? a[2] = r : r && (a[2] = "(" + a[2] + ") and (" + r + ")"), e.push(a))
            }
        }, e
    }
}, function(t, e, r) {
    "use strict";

    function n(t, e) {
        for (var r = [], n = {}, i = 0; i < e.length; i++) {
            var o = e[i],
                a = o[0],
                s = {
                    id: t + ":" + i,
                    css: o[1],
                    media: o[2],
                    sourceMap: o[3]
                };
            n[a] ? n[a].parts.push(s) : r.push(n[a] = {
                id: a,
                parts: [s]
            })
        }
        return r
    }
    r.r(e), r.d(e, "default", (function() {
        return f
    }));
    var i = "undefined" != typeof document;
    if ("undefined" != typeof DEBUG && DEBUG && !i) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
    var o = {},
        a = i && (document.head || document.getElementsByTagName("head")[0]),
        s = null,
        c = 0,
        p = !1,
        l = function() {},
        u = null,
        d = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

    function f(t, e, r, i) {
        p = r, u = i || {};
        var a = n(t, e);
        return h(a),
            function(e) {
                for (var r = [], i = 0; i < a.length; i++) {
                    var s = a[i];
                    (c = o[s.id]).refs--, r.push(c)
                }
                e ? h(a = n(t, e)) : a = [];
                for (i = 0; i < r.length; i++) {
                    var c;
                    if (0 === (c = r[i]).refs) {
                        for (var p = 0; p < c.parts.length; p++) c.parts[p]();
                        delete o[c.id]
                    }
                }
            }
    }

    function h(t) {
        for (var e = 0; e < t.length; e++) {
            var r = t[e],
                n = o[r.id];
            if (n) {
                n.refs++;
                for (var i = 0; i < n.parts.length; i++) n.parts[i](r.parts[i]);
                for (; i < r.parts.length; i++) n.parts.push(m(r.parts[i]));
                n.parts.length > r.parts.length && (n.parts.length = r.parts.length)
            } else {
                var a = [];
                for (i = 0; i < r.parts.length; i++) a.push(m(r.parts[i]));
                o[r.id] = {
                    id: r.id,
                    refs: 1,
                    parts: a
                }
            }
        }
    }

    function v() {
        var t = document.createElement("style");
        return t.type = "text/css", a.appendChild(t), t
    }

    function m(t) {
        var e, r, n = document.querySelector('style[data-vue-ssr-id~="' + t.id + '"]');
        if (n) {
            if (p) return l;
            n.parentNode.removeChild(n)
        }
        if (d) {
            var i = c++;
            n = s || (s = v()), e = g.bind(null, n, i, !1), r = g.bind(null, n, i, !0)
        } else n = v(), e = S.bind(null, n), r = function() {
            n.parentNode.removeChild(n)
        };
        return e(t),
            function(n) {
                if (n) {
                    if (n.css === t.css && n.media === t.media && n.sourceMap === t.sourceMap) return;
                    e(t = n)
                } else r()
            }
    }
    var _, b = (_ = [], function(t, e) {
        return _[t] = e, _.filter(Boolean).join("\n")
    });

    function g(t, e, r, n) {
        var i = r ? "" : n.css;
        if (t.styleSheet) t.styleSheet.cssText = b(e, i);
        else {
            var o = document.createTextNode(i),
                a = t.childNodes;
            a[e] && t.removeChild(a[e]), a.length ? t.insertBefore(o, a[e]) : t.appendChild(o)
        }
    }

    function S(t, e) {
        var r = e.css,
            n = e.media,
            i = e.sourceMap;
        if (n && t.setAttribute("media", n), u.ssrId && t.setAttribute("data-vue-ssr-id", e.id), i && (r += "\n/*# sourceURL=" + i.sources[0] + " */", r += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(i)))) + " */"), t.styleSheet) t.styleSheet.cssText = r;
        else {
            for (; t.firstChild;) t.removeChild(t.firstChild);
            t.appendChild(document.createTextNode(r))
        }
    }
}, function(t, e, r) {
    var n = r(47),
        i = "object" == typeof self && self && self.Object === Object && self,
        o = n || i || Function("return this")();
    t.exports = o
}, function(t, e, r) {
    var n = r(83),
        i = r(88);
    t.exports = function(t, e) {
        var r = i(t, e);
        return n(r) ? r : void 0
    }
}, function(t, e) {
    t.exports = Vue
}, function(t, e) {
    t.exports = function(t) {
        var e = typeof t;
        return null != t && ("object" == e || "function" == e)
    }
}, function(t, e) {
    t.exports = function(t) {
        return null != t && "object" == typeof t
    }
}, function(t, e, r) {
    "use strict";
    t.exports = function(t, e) {
        return "string" != typeof t ? t : (/^['"].*['"]$/.test(t) && (t = t.slice(1, -1)), /["'() \t\n]/.test(t) || e ? '"' + t.replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"' : t)
    }
}, function(t, e) {
    var r = Object.prototype;
    t.exports = function(t) {
        var e = t && t.constructor;
        return t === ("function" == typeof e && e.prototype || r)
    }
}, function(t, e, r) {
    var n = r(82),
        i = r(34),
        o = r(89),
        a = r(90),
        s = r(91),
        c = r(10),
        p = r(49),
        l = p(n),
        u = p(i),
        d = p(o),
        f = p(a),
        h = p(s),
        v = c;
    (n && "[object DataView]" != v(new n(new ArrayBuffer(1))) || i && "[object Map]" != v(new i) || o && "[object Promise]" != v(o.resolve()) || a && "[object Set]" != v(new a) || s && "[object WeakMap]" != v(new s)) && (v = function(t) {
        var e = c(t),
            r = "[object Object]" == e ? t.constructor : void 0,
            n = r ? p(r) : "";
        if (n) switch (n) {
            case l:
                return "[object DataView]";
            case u:
                return "[object Map]";
            case d:
                return "[object Promise]";
            case f:
                return "[object Set]";
            case h:
                return "[object WeakMap]"
        }
        return e
    }), t.exports = v
}, function(t, e, r) {
    var n = r(33),
        i = r(84),
        o = r(85),
        a = n ? n.toStringTag : void 0;
    t.exports = function(t) {
        return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : a && a in Object(t) ? i(t) : o(t)
    }
}, function(t, e) {
    var r = Array.isArray;
    t.exports = r
}, function(t, e, r) {
    var n = r(99),
        i = r(100),
        o = r(101),
        a = r(102),
        s = r(103);

    function c(t) {
        var e = -1,
            r = null == t ? 0 : t.length;
        for (this.clear(); ++e < r;) {
            var n = t[e];
            this.set(n[0], n[1])
        }
    }
    c.prototype.clear = n, c.prototype.delete = i, c.prototype.get = o, c.prototype.has = a, c.prototype.set = s, t.exports = c
}, function(t, e, r) {
    var n = r(53);
    t.exports = function(t, e) {
        for (var r = t.length; r--;)
            if (n(t[r][0], e)) return r;
        return -1
    }
}, function(t, e, r) {
    var n = r(3)(Object, "create");
    t.exports = n
}, function(t, e, r) {
    var n = r(118);
    t.exports = function(t, e) {
        var r = t.__data__;
        return n(e) ? r["string" == typeof e ? "string" : "hash"] : r.map
    }
}, function(t, e, r) {
    var n = r(54),
        i = r(55);
    t.exports = function(t, e, r, o) {
        var a = !r;
        r || (r = {});
        for (var s = -1, c = e.length; ++s < c;) {
            var p = e[s],
                l = o ? o(r[p], t[p], p, r, t) : void 0;
            void 0 === l && (l = t[p]), a ? i(r, p, l) : n(r, p, l)
        }
        return r
    }
}, function(t, e, r) {
    var n = r(66);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("195d9bb8", n, !1, {})
}, function(t, e, r) {
    var n = r(68);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("a50a80bc", n, !1, {})
}, function(t, e, r) {
    var n = r(70);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("7f36157c", n, !1, {})
}, function(t, e, r) {
    var n = r(72);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("ddfe0fa8", n, !1, {})
}, function(t, e, r) {
    var n = r(76);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("640fcc1e", n, !1, {})
}, function(t, e, r) {
    var n = r(78);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("44d15abc", n, !1, {})
}, function(t, e, r) {
    var n = r(80);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("37aa88b2", n, !1, {})
}, function(t, e, r) {
    var n = r(96);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("7a53dd67", n, !1, {})
}, function(t, e, r) {
    var n = r(151);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("6b377242", n, !1, {})
}, function(t, e, r) {
    var n = r(155);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("776c16f5", n, !1, {})
}, function(t, e, r) {
    var n = r(157);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("4de40899", n, !1, {})
}, function(t, e, r) {
    var n = r(161);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("2d550af3", n, !1, {})
}, function(t, e, r) {
    var n = r(165);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("51a71e3e", n, !1, {})
}, function(t, e, r) {
    var n = r(167);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("32f72295", n, !1, {})
}, function(t, e, r) {
    var n = r(169);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("82f32014", n, !1, {})
}, function(t, e, r) {
    var n = r(44),
        i = r(9),
        o = r(50),
        a = r(11),
        s = r(35),
        c = r(36),
        p = r(8),
        l = r(52),
        u = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        if (null == t) return !0;
        if (s(t) && (a(t) || "string" == typeof t || "function" == typeof t.splice || c(t) || l(t) || o(t))) return !t.length;
        var e = i(t);
        if ("[object Map]" == e || "[object Set]" == e) return !t.size;
        if (p(t)) return !n(t).length;
        for (var r in t)
            if (u.call(t, r)) return !1;
        return !0
    }
}, function(t, e, r) {
    var n = r(2).Symbol;
    t.exports = n
}, function(t, e, r) {
    var n = r(3)(r(2), "Map");
    t.exports = n
}, function(t, e, r) {
    var n = r(46),
        i = r(51);
    t.exports = function(t) {
        return null != t && i(t.length) && !n(t)
    }
}, function(t, e, r) {
    (function(t) {
        var n = r(2),
            i = r(93),
            o = e && !e.nodeType && e,
            a = o && "object" == typeof t && t && !t.nodeType && t,
            s = a && a.exports === o ? n.Buffer : void 0,
            c = (s ? s.isBuffer : void 0) || i;
        t.exports = c
    }).call(this, r(37)(t))
}, function(t, e) {
    t.exports = function(t) {
        return t.webpackPolyfill || (t.deprecate = function() {}, t.paths = [], t.children || (t.children = []), Object.defineProperty(t, "loaded", {
            enumerable: !0,
            get: function() {
                return t.l
            }
        }), Object.defineProperty(t, "id", {
            enumerable: !0,
            get: function() {
                return t.i
            }
        }), t.webpackPolyfill = 1), t
    }
}, function(t, e) {
    t.exports = function(t) {
        return function(e) {
            return t(e)
        }
    }
}, function(t, e, r) {
    (function(t) {
        var n = r(47),
            i = e && !e.nodeType && e,
            o = i && "object" == typeof t && t && !t.nodeType && t,
            a = o && o.exports === i && n.process,
            s = function() {
                try {
                    var t = o && o.require && o.require("util").types;
                    return t || a && a.binding && a.binding("util")
                } catch (t) {}
            }();
        t.exports = s
    }).call(this, r(37)(t))
}, function(t, e, r) {
    var n = r(56),
        i = r(44),
        o = r(35);
    t.exports = function(t) {
        return o(t) ? n(t) : i(t)
    }
}, function(t, e, r) {
    var n = r(133),
        i = r(58),
        o = Object.prototype.propertyIsEnumerable,
        a = Object.getOwnPropertySymbols,
        s = a ? function(t) {
            return null == t ? [] : (t = Object(t), n(a(t), (function(e) {
                return o.call(t, e)
            })))
        } : i;
    t.exports = s
}, function(t, e, r) {
    var n = r(139);
    t.exports = function(t) {
        var e = new t.constructor(t.byteLength);
        return new n(e).set(new n(t)), e
    }
}, function(t, e, r) {
    "use strict";
    (function(t) {
        var r = ("undefined" != typeof window ? window : void 0 !== t ? t : {}).__VUE_DEVTOOLS_GLOBAL_HOOK__;

        function n(t, e) {
            Object.keys(t).forEach((function(r) {
                return e(t[r], r)
            }))
        }

        function i(t) {
            return null !== t && "object" == typeof t
        }
        var o = function(t, e) {
                this.runtime = e, this._children = Object.create(null), this._rawModule = t;
                var r = t.state;
                this.state = ("function" == typeof r ? r() : r) || {}
            },
            a = {
                namespaced: {
                    configurable: !0
                }
            };
        a.namespaced.get = function() {
            return !!this._rawModule.namespaced
        }, o.prototype.addChild = function(t, e) {
            this._children[t] = e
        }, o.prototype.removeChild = function(t) {
            delete this._children[t]
        }, o.prototype.getChild = function(t) {
            return this._children[t]
        }, o.prototype.update = function(t) {
            this._rawModule.namespaced = t.namespaced, t.actions && (this._rawModule.actions = t.actions), t.mutations && (this._rawModule.mutations = t.mutations), t.getters && (this._rawModule.getters = t.getters)
        }, o.prototype.forEachChild = function(t) {
            n(this._children, t)
        }, o.prototype.forEachGetter = function(t) {
            this._rawModule.getters && n(this._rawModule.getters, t)
        }, o.prototype.forEachAction = function(t) {
            this._rawModule.actions && n(this._rawModule.actions, t)
        }, o.prototype.forEachMutation = function(t) {
            this._rawModule.mutations && n(this._rawModule.mutations, t)
        }, Object.defineProperties(o.prototype, a);
        var s = function(t) {
            this.register([], t, !1)
        };
        s.prototype.get = function(t) {
            return t.reduce((function(t, e) {
                return t.getChild(e)
            }), this.root)
        }, s.prototype.getNamespace = function(t) {
            var e = this.root;
            return t.reduce((function(t, r) {
                return t + ((e = e.getChild(r)).namespaced ? r + "/" : "")
            }), "")
        }, s.prototype.update = function(t) {
            ! function t(e, r, n) {
                0;
                if (r.update(n), n.modules)
                    for (var i in n.modules) {
                        if (!r.getChild(i)) return void 0;
                        t(e.concat(i), r.getChild(i), n.modules[i])
                    }
            }([], this.root, t)
        }, s.prototype.register = function(t, e, r) {
            var i = this;
            void 0 === r && (r = !0);
            var a = new o(e, r);
            0 === t.length ? this.root = a : this.get(t.slice(0, -1)).addChild(t[t.length - 1], a);
            e.modules && n(e.modules, (function(e, n) {
                i.register(t.concat(n), e, r)
            }))
        }, s.prototype.unregister = function(t) {
            var e = this.get(t.slice(0, -1)),
                r = t[t.length - 1];
            e.getChild(r).runtime && e.removeChild(r)
        };
        var c;
        var p = function(t) {
                var e = this;
                void 0 === t && (t = {}), !c && "undefined" != typeof window && window.Vue && _(window.Vue);
                var n = t.plugins;
                void 0 === n && (n = []);
                var i = t.strict;
                void 0 === i && (i = !1), this._committing = !1, this._actions = Object.create(null), this._actionSubscribers = [], this._mutations = Object.create(null), this._wrappedGetters = Object.create(null), this._modules = new s(t), this._modulesNamespaceMap = Object.create(null), this._subscribers = [], this._watcherVM = new c, this._makeLocalGettersCache = Object.create(null);
                var o = this,
                    a = this.dispatch,
                    p = this.commit;
                this.dispatch = function(t, e) {
                    return a.call(o, t, e)
                }, this.commit = function(t, e, r) {
                    return p.call(o, t, e, r)
                }, this.strict = i;
                var l = this._modules.root.state;
                h(this, l, [], this._modules.root), f(this, l), n.forEach((function(t) {
                    return t(e)
                })), (void 0 !== t.devtools ? t.devtools : c.config.devtools) && function(t) {
                    r && (t._devtoolHook = r, r.emit("vuex:init", t), r.on("vuex:travel-to-state", (function(e) {
                        t.replaceState(e)
                    })), t.subscribe((function(t, e) {
                        r.emit("vuex:mutation", t, e)
                    })))
                }(this)
            },
            l = {
                state: {
                    configurable: !0
                }
            };

        function u(t, e) {
            return e.indexOf(t) < 0 && e.push(t),
                function() {
                    var r = e.indexOf(t);
                    r > -1 && e.splice(r, 1)
                }
        }

        function d(t, e) {
            t._actions = Object.create(null), t._mutations = Object.create(null), t._wrappedGetters = Object.create(null), t._modulesNamespaceMap = Object.create(null);
            var r = t.state;
            h(t, r, [], t._modules.root, !0), f(t, r, e)
        }

        function f(t, e, r) {
            var i = t._vm;
            t.getters = {}, t._makeLocalGettersCache = Object.create(null);
            var o = t._wrappedGetters,
                a = {};
            n(o, (function(e, r) {
                a[r] = function(t, e) {
                    return function() {
                        return t(e)
                    }
                }(e, t), Object.defineProperty(t.getters, r, {
                    get: function() {
                        return t._vm[r]
                    },
                    enumerable: !0
                })
            }));
            var s = c.config.silent;
            c.config.silent = !0, t._vm = new c({
                data: {
                    $$state: e
                },
                computed: a
            }), c.config.silent = s, t.strict && function(t) {
                t._vm.$watch((function() {
                    return this._data.$$state
                }), (function() {
                    0
                }), {
                    deep: !0,
                    sync: !0
                })
            }(t), i && (r && t._withCommit((function() {
                i._data.$$state = null
            })), c.nextTick((function() {
                return i.$destroy()
            })))
        }

        function h(t, e, r, n, i) {
            var o = !r.length,
                a = t._modules.getNamespace(r);
            if (n.namespaced && (t._modulesNamespaceMap[a], t._modulesNamespaceMap[a] = n), !o && !i) {
                var s = v(e, r.slice(0, -1)),
                    p = r[r.length - 1];
                t._withCommit((function() {
                    c.set(s, p, n.state)
                }))
            }
            var l = n.context = function(t, e, r) {
                var n = "" === e,
                    i = {
                        dispatch: n ? t.dispatch : function(r, n, i) {
                            var o = m(r, n, i),
                                a = o.payload,
                                s = o.options,
                                c = o.type;
                            return s && s.root || (c = e + c), t.dispatch(c, a)
                        },
                        commit: n ? t.commit : function(r, n, i) {
                            var o = m(r, n, i),
                                a = o.payload,
                                s = o.options,
                                c = o.type;
                            s && s.root || (c = e + c), t.commit(c, a, s)
                        }
                    };
                return Object.defineProperties(i, {
                    getters: {
                        get: n ? function() {
                            return t.getters
                        } : function() {
                            return function(t, e) {
                                if (!t._makeLocalGettersCache[e]) {
                                    var r = {},
                                        n = e.length;
                                    Object.keys(t.getters).forEach((function(i) {
                                        if (i.slice(0, n) === e) {
                                            var o = i.slice(n);
                                            Object.defineProperty(r, o, {
                                                get: function() {
                                                    return t.getters[i]
                                                },
                                                enumerable: !0
                                            })
                                        }
                                    })), t._makeLocalGettersCache[e] = r
                                }
                                return t._makeLocalGettersCache[e]
                            }(t, e)
                        }
                    },
                    state: {
                        get: function() {
                            return v(t.state, r)
                        }
                    }
                }), i
            }(t, a, r);
            n.forEachMutation((function(e, r) {
                ! function(t, e, r, n) {
                    (t._mutations[e] || (t._mutations[e] = [])).push((function(e) {
                        r.call(t, n.state, e)
                    }))
                }(t, a + r, e, l)
            })), n.forEachAction((function(e, r) {
                var n = e.root ? r : a + r,
                    i = e.handler || e;
                ! function(t, e, r, n) {
                    (t._actions[e] || (t._actions[e] = [])).push((function(e) {
                        var i, o = r.call(t, {
                            dispatch: n.dispatch,
                            commit: n.commit,
                            getters: n.getters,
                            state: n.state,
                            rootGetters: t.getters,
                            rootState: t.state
                        }, e);
                        return (i = o) && "function" == typeof i.then || (o = Promise.resolve(o)), t._devtoolHook ? o.catch((function(e) {
                            throw t._devtoolHook.emit("vuex:error", e), e
                        })) : o
                    }))
                }(t, n, i, l)
            })), n.forEachGetter((function(e, r) {
                ! function(t, e, r, n) {
                    if (t._wrappedGetters[e]) return void 0;
                    t._wrappedGetters[e] = function(t) {
                        return r(n.state, n.getters, t.state, t.getters)
                    }
                }(t, a + r, e, l)
            })), n.forEachChild((function(n, o) {
                h(t, e, r.concat(o), n, i)
            }))
        }

        function v(t, e) {
            return e.length ? e.reduce((function(t, e) {
                return t[e]
            }), t) : t
        }

        function m(t, e, r) {
            return i(t) && t.type && (r = e, e = t, t = t.type), {
                type: t,
                payload: e,
                options: r
            }
        }

        function _(t) {
            c && t === c ||
                /**
                 * vuex v3.1.2
                 * (c) 2019 Evan You
                 * license MIT
                 */
                function(t) {
                    if (Number(t.version.split(".")[0]) >= 2) t.mixin({
                        beforeCreate: r
                    });
                    else {
                        var e = t.prototype._init;
                        t.prototype._init = function(t) {
                            void 0 === t && (t = {}), t.init = t.init ? [r].concat(t.init) : r, e.call(this, t)
                        }
                    }

                    function r() {
                        var t = this.$options;
                        t.store ? this.$store = "function" == typeof t.store ? t.store() : t.store : t.parent && t.parent.$store && (this.$store = t.parent.$store)
                    }
                }(c = t)
        }
        l.state.get = function() {
            return this._vm._data.$$state
        }, l.state.set = function(t) {
            0
        }, p.prototype.commit = function(t, e, r) {
            var n = this,
                i = m(t, e, r),
                o = i.type,
                a = i.payload,
                s = (i.options, {
                    type: o,
                    payload: a
                }),
                c = this._mutations[o];
            c && (this._withCommit((function() {
                c.forEach((function(t) {
                    t(a)
                }))
            })), this._subscribers.forEach((function(t) {
                return t(s, n.state)
            })))
        }, p.prototype.dispatch = function(t, e) {
            var r = this,
                n = m(t, e),
                i = n.type,
                o = n.payload,
                a = {
                    type: i,
                    payload: o
                },
                s = this._actions[i];
            if (s) {
                try {
                    this._actionSubscribers.filter((function(t) {
                        return t.before
                    })).forEach((function(t) {
                        return t.before(a, r.state)
                    }))
                } catch (t) {
                    0
                }
                return (s.length > 1 ? Promise.all(s.map((function(t) {
                    return t(o)
                }))) : s[0](o)).then((function(t) {
                    try {
                        r._actionSubscribers.filter((function(t) {
                            return t.after
                        })).forEach((function(t) {
                            return t.after(a, r.state)
                        }))
                    } catch (t) {
                        0
                    }
                    return t
                }))
            }
        }, p.prototype.subscribe = function(t) {
            return u(t, this._subscribers)
        }, p.prototype.subscribeAction = function(t) {
            return u("function" == typeof t ? {
                before: t
            } : t, this._actionSubscribers)
        }, p.prototype.watch = function(t, e, r) {
            var n = this;
            return this._watcherVM.$watch((function() {
                return t(n.state, n.getters)
            }), e, r)
        }, p.prototype.replaceState = function(t) {
            var e = this;
            this._withCommit((function() {
                e._vm._data.$$state = t
            }))
        }, p.prototype.registerModule = function(t, e, r) {
            void 0 === r && (r = {}), "string" == typeof t && (t = [t]), this._modules.register(t, e), h(this, this.state, t, this._modules.get(t), r.preserveState), f(this, this.state)
        }, p.prototype.unregisterModule = function(t) {
            var e = this;
            "string" == typeof t && (t = [t]), this._modules.unregister(t), this._withCommit((function() {
                var r = v(e.state, t.slice(0, -1));
                c.delete(r, t[t.length - 1])
            })), d(this)
        }, p.prototype.hotUpdate = function(t) {
            this._modules.update(t), d(this, !0)
        }, p.prototype._withCommit = function(t) {
            var e = this._committing;
            this._committing = !0, t(), this._committing = e
        }, Object.defineProperties(p.prototype, l);
        var b = x((function(t, e) {
                var r = {};
                return y(e).forEach((function(e) {
                    var n = e.key,
                        i = e.val;
                    r[n] = function() {
                        var e = this.$store.state,
                            r = this.$store.getters;
                        if (t) {
                            var n = P(this.$store, "mapState", t);
                            if (!n) return;
                            e = n.context.state, r = n.context.getters
                        }
                        return "function" == typeof i ? i.call(this, e, r) : e[i]
                    }, r[n].vuex = !0
                })), r
            })),
            g = x((function(t, e) {
                var r = {};
                return y(e).forEach((function(e) {
                    var n = e.key,
                        i = e.val;
                    r[n] = function() {
                        for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                        var n = this.$store.commit;
                        if (t) {
                            var o = P(this.$store, "mapMutations", t);
                            if (!o) return;
                            n = o.context.commit
                        }
                        return "function" == typeof i ? i.apply(this, [n].concat(e)) : n.apply(this.$store, [i].concat(e))
                    }
                })), r
            })),
            S = x((function(t, e) {
                var r = {};
                return y(e).forEach((function(e) {
                    var n = e.key,
                        i = e.val;
                    i = t + i, r[n] = function() {
                        if (!t || P(this.$store, "mapGetters", t)) return this.$store.getters[i]
                    }, r[n].vuex = !0
                })), r
            })),
            w = x((function(t, e) {
                var r = {};
                return y(e).forEach((function(e) {
                    var n = e.key,
                        i = e.val;
                    r[n] = function() {
                        for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                        var n = this.$store.dispatch;
                        if (t) {
                            var o = P(this.$store, "mapActions", t);
                            if (!o) return;
                            n = o.context.dispatch
                        }
                        return "function" == typeof i ? i.apply(this, [n].concat(e)) : n.apply(this.$store, [i].concat(e))
                    }
                })), r
            }));

        function y(t) {
            return function(t) {
                return Array.isArray(t) || i(t)
            }(t) ? Array.isArray(t) ? t.map((function(t) {
                return {
                    key: t,
                    val: t
                }
            })) : Object.keys(t).map((function(e) {
                return {
                    key: e,
                    val: t[e]
                }
            })) : []
        }

        function x(t) {
            return function(e, r) {
                return "string" != typeof e ? (r = e, e = "") : "/" !== e.charAt(e.length - 1) && (e += "/"), t(e, r)
            }
        }

        function P(t, e, r) {
            return t._modulesNamespaceMap[r]
        }
        var T = {
            Store: p,
            install: _,
            version: "3.1.2",
            mapState: b,
            mapMutations: g,
            mapGetters: S,
            mapActions: w,
            createNamespacedHelpers: function(t) {
                return {
                    mapState: b.bind(null, t),
                    mapGetters: S.bind(null, t),
                    mapMutations: g.bind(null, t),
                    mapActions: w.bind(null, t)
                }
            }
        };
        e.a = T
    }).call(this, r(48))
}, function(t, e, r) {
    var n = r(8),
        i = r(81),
        o = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        if (!n(t)) return i(t);
        var e = [];
        for (var r in Object(t)) o.call(t, r) && "constructor" != r && e.push(r);
        return e
    }
}, function(t, e) {
    t.exports = function(t, e) {
        return function(r) {
            return t(e(r))
        }
    }
}, function(t, e, r) {
    var n = r(10),
        i = r(5);
    t.exports = function(t) {
        if (!i(t)) return !1;
        var e = n(t);
        return "[object Function]" == e || "[object GeneratorFunction]" == e || "[object AsyncFunction]" == e || "[object Proxy]" == e
    }
}, function(t, e, r) {
    (function(e) {
        var r = "object" == typeof e && e && e.Object === Object && e;
        t.exports = r
    }).call(this, r(48))
}, function(t, e) {
    var r;
    r = function() {
        return this
    }();
    try {
        r = r || new Function("return this")()
    } catch (t) {
        "object" == typeof window && (r = window)
    }
    t.exports = r
}, function(t, e) {
    var r = Function.prototype.toString;
    t.exports = function(t) {
        if (null != t) {
            try {
                return r.call(t)
            } catch (t) {}
            try {
                return t + ""
            } catch (t) {}
        }
        return ""
    }
}, function(t, e, r) {
    var n = r(92),
        i = r(6),
        o = Object.prototype,
        a = o.hasOwnProperty,
        s = o.propertyIsEnumerable,
        c = n(function() {
            return arguments
        }()) ? n : function(t) {
            return i(t) && a.call(t, "callee") && !s.call(t, "callee")
        };
    t.exports = c
}, function(t, e) {
    t.exports = function(t) {
        return "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991
    }
}, function(t, e, r) {
    var n = r(94),
        i = r(38),
        o = r(39),
        a = o && o.isTypedArray,
        s = a ? i(a) : n;
    t.exports = s
}, function(t, e) {
    t.exports = function(t, e) {
        return t === e || t != t && e != e
    }
}, function(t, e, r) {
    var n = r(55),
        i = r(53),
        o = Object.prototype.hasOwnProperty;
    t.exports = function(t, e, r) {
        var a = t[e];
        o.call(t, e) && i(a, r) && (void 0 !== r || e in t) || n(t, e, r)
    }
}, function(t, e, r) {
    var n = r(123);
    t.exports = function(t, e, r) {
        "__proto__" == e && n ? n(t, e, {
            configurable: !0,
            enumerable: !0,
            value: r,
            writable: !0
        }) : t[e] = r
    }
}, function(t, e, r) {
    var n = r(125),
        i = r(50),
        o = r(11),
        a = r(36),
        s = r(126),
        c = r(52),
        p = Object.prototype.hasOwnProperty;
    t.exports = function(t, e) {
        var r = o(t),
            l = !r && i(t),
            u = !r && !l && a(t),
            d = !r && !l && !u && c(t),
            f = r || l || u || d,
            h = f ? n(t.length, String) : [],
            v = h.length;
        for (var m in t) !e && !p.call(t, m) || f && ("length" == m || u && ("offset" == m || "parent" == m) || d && ("buffer" == m || "byteLength" == m || "byteOffset" == m) || s(m, v)) || h.push(m);
        return h
    }
}, function(t, e, r) {
    var n = r(56),
        i = r(128),
        o = r(35);
    t.exports = function(t) {
        return o(t) ? n(t, !0) : i(t)
    }
}, function(t, e) {
    t.exports = function() {
        return []
    }
}, function(t, e, r) {
    var n = r(60),
        i = r(61),
        o = r(41),
        a = r(58),
        s = Object.getOwnPropertySymbols ? function(t) {
            for (var e = []; t;) n(e, o(t)), t = i(t);
            return e
        } : a;
    t.exports = s
}, function(t, e) {
    t.exports = function(t, e) {
        for (var r = -1, n = e.length, i = t.length; ++r < n;) t[i + r] = e[r];
        return t
    }
}, function(t, e, r) {
    var n = r(45)(Object.getPrototypeOf, Object);
    t.exports = n
}, function(t, e, r) {
    var n = r(60),
        i = r(11);
    t.exports = function(t, e, r) {
        var o = e(t);
        return i(t) ? o : n(o, r(t))
    }
}, function(t, e, r) {
    var n = r(97);
    t.exports = function(t) {
        return n(t, 5)
    }
}, function(t, e, r) {
    t.exports = r(174)
}, function(t, e, r) {
    "use strict";
    var n = r(17);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".description-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.description-content span{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.portal-type{box-sizing:border-box;position:relative;display:flex;margin-bottom:20px;width:100%;height:140px;background:#FFFFFF;border:2px solid rgba(50,60,70,0.1);box-shadow:0 2px 4px 0 rgba(50,60,70,0.05);border-radius:4px;align-items:center;cursor:pointer}.portal-type:hover{background:rgba(5,127,235,0.06);border:2px solid #057FEB;box-shadow:0 2px 6px 0 rgba(5,127,235,0.16);border-radius:4px}.portal-type.portal-type-selected{background:rgba(5,127,235,0.06);border:2px solid #057FEB;box-shadow:0 2px 6px 0 rgba(5,127,235,0.16);border-radius:4px}.portal-type-container{display:flex;align-items:center;margin:0 22px 0 30px;width:464px}.portal-icon{display:inline-block;height:72px;width:72px}.description-wrapper{display:inline-block;width:360px;padding-left:32px}.description-title{font-size:15px;color:#414b55;line-height:24px;margin-bottom:4px}.description-content{display:inline-block;max-height:100px;overflow:hidden;text-overflow:ellipsis}.description-content span{font-size:13px;color:#414b55;line-height:20px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(18);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".ws-servicewizard-service-card-name span{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.ws-servicewizard-service-card-name span{color:#414b55}.ws-servicewizard-service-card{float:left;height:142px;width:162px;margin-right:17px;margin-bottom:16px;box-sizing:border-box;border:2px solid rgba(50,60,70,0.1);border-radius:4px;background-color:#fff;cursor:pointer}.ws-servicewizard-service-card:nth-child(3n){margin-right:0}.ws-servicewizard-service-card:nth-child(n+3){margin-bottom:12px}.ws-servicewizard-service-card.ws-servicewizard-service-card-normal{background-color:#fff;border:2px solid rgba(50,60,70,0.1)}.ws-servicewizard-service-card.ws-servicewizard-service-card-normal:hover{border:0;background:rgba(5,127,235,0.06)}.ws-servicewizard-service-card.ws-servicewizard-service-card-selected{background:rgba(5,127,235,0.06);border:2px solid #057FEB;box-shadow:0 2px 6px 0 rgba(5,127,235,0.16)}.ws-servicewizard-service-card.ws-servicewizard-service-card-disabled{background:rgba(80,90,100,0.05);border:2px solid rgba(50,60,70,0.1);cursor:default}.ws-servicewizard-service-card-container{box-sizing:border-box;padding:29px 12px 0 12px}.ws-servicewizard-service-card-normal:hover .ws-servicewizard-service-card-container{padding:31px 14px 0 14px}.ws-servicewizard-service-card-icon{display:inline-block;width:48px;height:48px;line-height:48px;padding:0 43px 12px 43px}.ws-servicewizard-service-card-disabled .ws-servicewizard-service-card-icon{filter:grayscale(100%);opacity:0.4}.ws-servicewizard-service-card-name{display:inline-block;width:134px;height:40px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;text-align:center}.ws-servicewizard-service-card-name span{line-height:20px;font-size:14px}.ws-servicewizard-service-card-disabled .ws-servicewizard-service-card-name{opacity:0.4}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(19);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".ws-servicewizard-service-card-inline-name span{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:600}.ws-servicewizard-service-card-inline-name span{color:#414b55}.ws-servicewizard-service-card-inline{float:left;height:50px;width:250px;margin-right:20px;margin-bottom:6px;box-sizing:border-box;border-radius:4px;cursor:pointer}.ws-servicewizard-service-card-inline:nth-child(2n){margin-right:0}.ws-servicewizard-service-card-inline.ws-servicewizard-service-card-inline-normal{background:#FFFFFF;border:1px solid rgba(50,60,70,0.1)}.ws-servicewizard-service-card-inline.ws-servicewizard-service-card-inline-normal:hover{border:none;background:rgba(60,118,255,0.06)}.ws-servicewizard-service-card-inline.ws-servicewizard-service-card-inline-selected{background:rgba(60,118,255,0.06);border:2px solid #3C76FF;box-shadow:0 2px 6px 0 rgba(60,118,255,0.16)}.ws-servicewizard-service-card-inline.ws-servicewizard-service-card-inline-disabled{background:rgba(80,90,100,0.05);border:1px solid rgba(50,60,70,0.1);cursor:default}.ws-servicewizard-service-card-inline-container{box-sizing:border-box;padding:12px 12px 12px 15px}.ws-servicewizard-service-card-inline-normal:hover .ws-servicewizard-service-card-inline-container{padding:13px 13px 13px 16px}.ws-servicewizard-service-card-inline-disabled:hover .ws-servicewizard-service-card-inline-container{padding:12px 12px 12px 15px}.ws-servicewizard-service-card-inline-selected .ws-servicewizard-service-card-inline-container{padding:11px 11px 11px 14px}.ws-servicewizard-service-card-inline-icon{display:inline-block;width:24px;height:24px;line-height:24px;padding-right:12px}.ws-servicewizard-service-card-inlne-disabled .ws-servicewizard-service-card-inline-icon{filter:grayscale(100%);opacity:0.4}.ws-servicewizard-service-card-inline-name{position:absolute;display:inline-block;width:185px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.ws-servicewizard-service-card-inline-name span{line-height:24px;font-size:14px}.ws-servicewizard-service-card-inline-disabled .ws-servicewizard-service-card-inline-name{opacity:0.4}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(20);
    r.n(n).a
}, function(t, e, r) {
    e = t.exports = r(0)(!1);
    var n = r(7),
        i = n(r(73)),
        o = n(r(74));
    e.push([t.i, ".ws-empty-text-wrap{padding-top:110px;left:10px;right:10px}.ws-empty-text-wrap:before{content:'';display:inline-block;vertical-align:middle;height:100%;width:0px}.ws-empty-text-inner-wrap{display:inline-block;width:100%;vertical-align:middle}.ws-empty-text-icon{margin-left:auto;margin-right:auto;margin-bottom:20px;width:120px;height:120px;background-image:url(" + i + ");background-size:120px 120px;background-size:contain;background-repeat:no-repeat}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .ws-empty-text-icon{background-image:url(" + o + ");background-size:120px 120px}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .ws-empty-text-icon{background-image:url(" + o + ");background-size:120px 120px;outline:1px green dashed}}.ws-empty-text{margin-left:auto;margin-right:auto;width:330px;text-align:center;line-height:20px;font-size:13px;color:rgba(65,75,85,0.6)}.ws-servicewizard-cardtable-inline{display:inline-block}\n", ""])
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/2d5122631c636d23ca7824bba3b24888.png"
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/95e26b0a84018c212b5124e3fa944b7f.png"
}, function(t, e, r) {
    "use strict";
    var n = r(21);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".based-radio[data-v-af444550]{padding-bottom:6px}.port-checkbox[data-v-af444550]{width:90px}.port-input[data-v-af444550] input{width:38px}.input-width[data-v-af444550] input{width:196px}.radio-group[data-v-af444550]{padding-bottom:12px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(22);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".based-radio[data-v-6bbd554c]{padding-bottom:6px}.port-checkbox[data-v-6bbd554c]{width:90px}.port-input[data-v-6bbd554c] input{width:38px}.input-width[data-v-6bbd554c] input{width:196px}.radio-group[data-v-6bbd554c]{padding-bottom:12px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(23);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".based-radio[data-v-779d1616]{padding-bottom:6px}.port-checkbox[data-v-779d1616]{width:90px}.port-input[data-v-779d1616] input{width:38px}.input-width[data-v-779d1616] input{width:196px}.radio-group[data-v-779d1616]{padding-bottom:12px}\n", ""])
}, function(t, e, r) {
    var n = r(45)(Object.keys, Object);
    t.exports = n
}, function(t, e, r) {
    var n = r(3)(r(2), "DataView");
    t.exports = n
}, function(t, e, r) {
    var n = r(46),
        i = r(86),
        o = r(5),
        a = r(49),
        s = /^\[object .+?Constructor\]$/,
        c = Function.prototype,
        p = Object.prototype,
        l = c.toString,
        u = p.hasOwnProperty,
        d = RegExp("^" + l.call(u).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    t.exports = function(t) {
        return !(!o(t) || i(t)) && (n(t) ? d : s).test(a(t))
    }
}, function(t, e, r) {
    var n = r(33),
        i = Object.prototype,
        o = i.hasOwnProperty,
        a = i.toString,
        s = n ? n.toStringTag : void 0;
    t.exports = function(t) {
        var e = o.call(t, s),
            r = t[s];
        try {
            t[s] = void 0;
            var n = !0
        } catch (t) {}
        var i = a.call(t);
        return n && (e ? t[s] = r : delete t[s]), i
    }
}, function(t, e) {
    var r = Object.prototype.toString;
    t.exports = function(t) {
        return r.call(t)
    }
}, function(t, e, r) {
    var n, i = r(87),
        o = (n = /[^.]+$/.exec(i && i.keys && i.keys.IE_PROTO || "")) ? "Symbol(src)_1." + n : "";
    t.exports = function(t) {
        return !!o && o in t
    }
}, function(t, e, r) {
    var n = r(2)["__core-js_shared__"];
    t.exports = n
}, function(t, e) {
    t.exports = function(t, e) {
        return null == t ? void 0 : t[e]
    }
}, function(t, e, r) {
    var n = r(3)(r(2), "Promise");
    t.exports = n
}, function(t, e, r) {
    var n = r(3)(r(2), "Set");
    t.exports = n
}, function(t, e, r) {
    var n = r(3)(r(2), "WeakMap");
    t.exports = n
}, function(t, e, r) {
    var n = r(10),
        i = r(6);
    t.exports = function(t) {
        return i(t) && "[object Arguments]" == n(t)
    }
}, function(t, e) {
    t.exports = function() {
        return !1
    }
}, function(t, e, r) {
    var n = r(10),
        i = r(51),
        o = r(6),
        a = {};
    a["[object Float32Array]"] = a["[object Float64Array]"] = a["[object Int8Array]"] = a["[object Int16Array]"] = a["[object Int32Array]"] = a["[object Uint8Array]"] = a["[object Uint8ClampedArray]"] = a["[object Uint16Array]"] = a["[object Uint32Array]"] = !0, a["[object Arguments]"] = a["[object Array]"] = a["[object ArrayBuffer]"] = a["[object Boolean]"] = a["[object DataView]"] = a["[object Date]"] = a["[object Error]"] = a["[object Function]"] = a["[object Map]"] = a["[object Number]"] = a["[object Object]"] = a["[object RegExp]"] = a["[object Set]"] = a["[object String]"] = a["[object WeakMap]"] = !1, t.exports = function(t) {
        return o(t) && i(t.length) && !!a[n(t)]
    }
}, function(t, e, r) {
    "use strict";
    var n = r(24);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".service-portal-page .primary-link[data-v-0542193f]{width:20px;float:left}.service-portal-page .status-not-avaiable[data-v-0542193f]{color:rgba(65,75,85,0.6)}\n", ""])
}, function(t, e, r) {
    var n = r(98),
        i = r(122),
        o = r(54),
        a = r(124),
        s = r(127),
        c = r(130),
        p = r(131),
        l = r(132),
        u = r(134),
        d = r(135),
        f = r(136),
        h = r(9),
        v = r(137),
        m = r(138),
        _ = r(144),
        b = r(11),
        g = r(36),
        S = r(146),
        w = r(5),
        y = r(148),
        x = r(40),
        P = {};
    P["[object Arguments]"] = P["[object Array]"] = P["[object ArrayBuffer]"] = P["[object DataView]"] = P["[object Boolean]"] = P["[object Date]"] = P["[object Float32Array]"] = P["[object Float64Array]"] = P["[object Int8Array]"] = P["[object Int16Array]"] = P["[object Int32Array]"] = P["[object Map]"] = P["[object Number]"] = P["[object Object]"] = P["[object RegExp]"] = P["[object Set]"] = P["[object String]"] = P["[object Symbol]"] = P["[object Uint8Array]"] = P["[object Uint8ClampedArray]"] = P["[object Uint16Array]"] = P["[object Uint32Array]"] = !0, P["[object Error]"] = P["[object Function]"] = P["[object WeakMap]"] = !1, t.exports = function t(e, r, T, k, D, O) {
        var N, A = 1 & r,
            $ = 2 & r,
            E = 4 & r;
        if (T && (N = D ? T(e, k, D, O) : T(e)), void 0 !== N) return N;
        if (!w(e)) return e;
        var C = b(e);
        if (C) {
            if (N = v(e), !A) return p(e, N)
        } else {
            var W = h(e),
                R = "[object Function]" == W || "[object GeneratorFunction]" == W;
            if (g(e)) return c(e, A);
            if ("[object Object]" == W || "[object Arguments]" == W || R && !D) {
                if (N = $ || R ? {} : _(e), !A) return $ ? u(e, s(N, e)) : l(e, a(N, e))
            } else {
                if (!P[W]) return D ? e : {};
                N = m(e, W, A)
            }
        }
        O || (O = new n);
        var I = O.get(e);
        if (I) return I;
        O.set(e, N), y(e) ? e.forEach((function(n) {
            N.add(t(n, r, T, n, e, O))
        })) : S(e) && e.forEach((function(n, i) {
            N.set(i, t(n, r, T, i, e, O))
        }));
        var j = E ? $ ? f : d : $ ? keysIn : x,
            L = C ? void 0 : j(e);
        return i(L || e, (function(n, i) {
            L && (n = e[i = n]), o(N, i, t(n, r, T, i, e, O))
        })), N
    }
}, function(t, e, r) {
    var n = r(12),
        i = r(104),
        o = r(105),
        a = r(106),
        s = r(107),
        c = r(108);

    function p(t) {
        var e = this.__data__ = new n(t);
        this.size = e.size
    }
    p.prototype.clear = i, p.prototype.delete = o, p.prototype.get = a, p.prototype.has = s, p.prototype.set = c, t.exports = p
}, function(t, e) {
    t.exports = function() {
        this.__data__ = [], this.size = 0
    }
}, function(t, e, r) {
    var n = r(13),
        i = Array.prototype.splice;
    t.exports = function(t) {
        var e = this.__data__,
            r = n(e, t);
        return !(r < 0) && (r == e.length - 1 ? e.pop() : i.call(e, r, 1), --this.size, !0)
    }
}, function(t, e, r) {
    var n = r(13);
    t.exports = function(t) {
        var e = this.__data__,
            r = n(e, t);
        return r < 0 ? void 0 : e[r][1]
    }
}, function(t, e, r) {
    var n = r(13);
    t.exports = function(t) {
        return n(this.__data__, t) > -1
    }
}, function(t, e, r) {
    var n = r(13);
    t.exports = function(t, e) {
        var r = this.__data__,
            i = n(r, t);
        return i < 0 ? (++this.size, r.push([t, e])) : r[i][1] = e, this
    }
}, function(t, e, r) {
    var n = r(12);
    t.exports = function() {
        this.__data__ = new n, this.size = 0
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = this.__data__,
            r = e.delete(t);
        return this.size = e.size, r
    }
}, function(t, e) {
    t.exports = function(t) {
        return this.__data__.get(t)
    }
}, function(t, e) {
    t.exports = function(t) {
        return this.__data__.has(t)
    }
}, function(t, e, r) {
    var n = r(12),
        i = r(34),
        o = r(109);
    t.exports = function(t, e) {
        var r = this.__data__;
        if (r instanceof n) {
            var a = r.__data__;
            if (!i || a.length < 199) return a.push([t, e]), this.size = ++r.size, this;
            r = this.__data__ = new o(a)
        }
        return r.set(t, e), this.size = r.size, this
    }
}, function(t, e, r) {
    var n = r(110),
        i = r(117),
        o = r(119),
        a = r(120),
        s = r(121);

    function c(t) {
        var e = -1,
            r = null == t ? 0 : t.length;
        for (this.clear(); ++e < r;) {
            var n = t[e];
            this.set(n[0], n[1])
        }
    }
    c.prototype.clear = n, c.prototype.delete = i, c.prototype.get = o, c.prototype.has = a, c.prototype.set = s, t.exports = c
}, function(t, e, r) {
    var n = r(111),
        i = r(12),
        o = r(34);
    t.exports = function() {
        this.size = 0, this.__data__ = {
            hash: new n,
            map: new(o || i),
            string: new n
        }
    }
}, function(t, e, r) {
    var n = r(112),
        i = r(113),
        o = r(114),
        a = r(115),
        s = r(116);

    function c(t) {
        var e = -1,
            r = null == t ? 0 : t.length;
        for (this.clear(); ++e < r;) {
            var n = t[e];
            this.set(n[0], n[1])
        }
    }
    c.prototype.clear = n, c.prototype.delete = i, c.prototype.get = o, c.prototype.has = a, c.prototype.set = s, t.exports = c
}, function(t, e, r) {
    var n = r(14);
    t.exports = function() {
        this.__data__ = n ? n(null) : {}, this.size = 0
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = this.has(t) && delete this.__data__[t];
        return this.size -= e ? 1 : 0, e
    }
}, function(t, e, r) {
    var n = r(14),
        i = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = this.__data__;
        if (n) {
            var r = e[t];
            return "__lodash_hash_undefined__" === r ? void 0 : r
        }
        return i.call(e, t) ? e[t] : void 0
    }
}, function(t, e, r) {
    var n = r(14),
        i = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = this.__data__;
        return n ? void 0 !== e[t] : i.call(e, t)
    }
}, function(t, e, r) {
    var n = r(14);
    t.exports = function(t, e) {
        var r = this.__data__;
        return this.size += this.has(t) ? 0 : 1, r[t] = n && void 0 === e ? "__lodash_hash_undefined__" : e, this
    }
}, function(t, e, r) {
    var n = r(15);
    t.exports = function(t) {
        var e = n(this, t).delete(t);
        return this.size -= e ? 1 : 0, e
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = typeof t;
        return "string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== t : null === t
    }
}, function(t, e, r) {
    var n = r(15);
    t.exports = function(t) {
        return n(this, t).get(t)
    }
}, function(t, e, r) {
    var n = r(15);
    t.exports = function(t) {
        return n(this, t).has(t)
    }
}, function(t, e, r) {
    var n = r(15);
    t.exports = function(t, e) {
        var r = n(this, t),
            i = r.size;
        return r.set(t, e), this.size += r.size == i ? 0 : 1, this
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var r = -1, n = null == t ? 0 : t.length; ++r < n && !1 !== e(t[r], r, t););
        return t
    }
}, function(t, e, r) {
    var n = r(3),
        i = function() {
            try {
                var t = n(Object, "defineProperty");
                return t({}, "", {}), t
            } catch (t) {}
        }();
    t.exports = i
}, function(t, e, r) {
    var n = r(16),
        i = r(40);
    t.exports = function(t, e) {
        return t && n(e, i(e), t)
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var r = -1, n = Array(t); ++r < t;) n[r] = e(r);
        return n
    }
}, function(t, e) {
    var r = /^(?:0|[1-9]\d*)$/;
    t.exports = function(t, e) {
        var n = typeof t;
        return !!(e = null == e ? 9007199254740991 : e) && ("number" == n || "symbol" != n && r.test(t)) && t > -1 && t % 1 == 0 && t < e
    }
}, function(t, e, r) {
    var n = r(16),
        i = r(57);
    t.exports = function(t, e) {
        return t && n(e, i(e), t)
    }
}, function(t, e, r) {
    var n = r(5),
        i = r(8),
        o = r(129),
        a = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        if (!n(t)) return o(t);
        var e = i(t),
            r = [];
        for (var s in t)("constructor" != s || !e && a.call(t, s)) && r.push(s);
        return r
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = [];
        if (null != t)
            for (var r in Object(t)) e.push(r);
        return e
    }
}, function(t, e, r) {
    (function(t) {
        var n = r(2),
            i = e && !e.nodeType && e,
            o = i && "object" == typeof t && t && !t.nodeType && t,
            a = o && o.exports === i ? n.Buffer : void 0,
            s = a ? a.allocUnsafe : void 0;
        t.exports = function(t, e) {
            if (e) return t.slice();
            var r = t.length,
                n = s ? s(r) : new t.constructor(r);
            return t.copy(n), n
        }
    }).call(this, r(37)(t))
}, function(t, e) {
    t.exports = function(t, e) {
        var r = -1,
            n = t.length;
        for (e || (e = Array(n)); ++r < n;) e[r] = t[r];
        return e
    }
}, function(t, e, r) {
    var n = r(16),
        i = r(41);
    t.exports = function(t, e) {
        return n(t, i(t), e)
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var r = -1, n = null == t ? 0 : t.length, i = 0, o = []; ++r < n;) {
            var a = t[r];
            e(a, r, t) && (o[i++] = a)
        }
        return o
    }
}, function(t, e, r) {
    var n = r(16),
        i = r(59);
    t.exports = function(t, e) {
        return n(t, i(t), e)
    }
}, function(t, e, r) {
    var n = r(62),
        i = r(41),
        o = r(40);
    t.exports = function(t) {
        return n(t, o, i)
    }
}, function(t, e, r) {
    var n = r(62),
        i = r(59),
        o = r(57);
    t.exports = function(t) {
        return n(t, o, i)
    }
}, function(t, e) {
    var r = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = t.length,
            n = new t.constructor(e);
        return e && "string" == typeof t[0] && r.call(t, "index") && (n.index = t.index, n.input = t.input), n
    }
}, function(t, e, r) {
    var n = r(42),
        i = r(140),
        o = r(141),
        a = r(142),
        s = r(143);
    t.exports = function(t, e, r) {
        var c = t.constructor;
        switch (e) {
            case "[object ArrayBuffer]":
                return n(t);
            case "[object Boolean]":
            case "[object Date]":
                return new c(+t);
            case "[object DataView]":
                return i(t, r);
            case "[object Float32Array]":
            case "[object Float64Array]":
            case "[object Int8Array]":
            case "[object Int16Array]":
            case "[object Int32Array]":
            case "[object Uint8Array]":
            case "[object Uint8ClampedArray]":
            case "[object Uint16Array]":
            case "[object Uint32Array]":
                return s(t, r);
            case "[object Map]":
                return new c;
            case "[object Number]":
            case "[object String]":
                return new c(t);
            case "[object RegExp]":
                return o(t);
            case "[object Set]":
                return new c;
            case "[object Symbol]":
                return a(t)
        }
    }
}, function(t, e, r) {
    var n = r(2).Uint8Array;
    t.exports = n
}, function(t, e, r) {
    var n = r(42);
    t.exports = function(t, e) {
        var r = e ? n(t.buffer) : t.buffer;
        return new t.constructor(r, t.byteOffset, t.byteLength)
    }
}, function(t, e) {
    var r = /\w*$/;
    t.exports = function(t) {
        var e = new t.constructor(t.source, r.exec(t));
        return e.lastIndex = t.lastIndex, e
    }
}, function(t, e, r) {
    var n = r(33),
        i = n ? n.prototype : void 0,
        o = i ? i.valueOf : void 0;
    t.exports = function(t) {
        return o ? Object(o.call(t)) : {}
    }
}, function(t, e, r) {
    var n = r(42);
    t.exports = function(t, e) {
        var r = e ? n(t.buffer) : t.buffer;
        return new t.constructor(r, t.byteOffset, t.length)
    }
}, function(t, e, r) {
    var n = r(145),
        i = r(61),
        o = r(8);
    t.exports = function(t) {
        return "function" != typeof t.constructor || o(t) ? {} : n(i(t))
    }
}, function(t, e, r) {
    var n = r(5),
        i = Object.create,
        o = function() {
            function t() {}
            return function(e) {
                if (!n(e)) return {};
                if (i) return i(e);
                t.prototype = e;
                var r = new t;
                return t.prototype = void 0, r
            }
        }();
    t.exports = o
}, function(t, e, r) {
    var n = r(147),
        i = r(38),
        o = r(39),
        a = o && o.isMap,
        s = a ? i(a) : n;
    t.exports = s
}, function(t, e, r) {
    var n = r(9),
        i = r(6);
    t.exports = function(t) {
        return i(t) && "[object Map]" == n(t)
    }
}, function(t, e, r) {
    var n = r(149),
        i = r(38),
        o = r(39),
        a = o && o.isSet,
        s = a ? i(a) : n;
    t.exports = s
}, function(t, e, r) {
    var n = r(9),
        i = r(6);
    t.exports = function(t) {
        return i(t) && "[object Set]" == n(t)
    }
}, function(t, e, r) {
    "use strict";
    var n = r(25);
    r.n(n).a
}, function(t, e, r) {
    e = t.exports = r(0)(!1);
    var n = r(7),
        i = n(r(152)),
        o = n(r(153));
    e.push([t.i, ".webstation-file-input{position:relative;display:inline-flex;box-sizing:border-box;background:#fff;height:28px;width:100%;border:solid 1px;line-height:20px;padding:3px 24px 3px 11px;border-radius:4px;cursor:pointer}.webstation-file-input__text{flex:1;margin-right:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:grey}.webstation-file-input__text--primary{color:initial}.webstation-file-input__btn{position:absolute;top:1px;right:1px;background:none;border:none;padding:0;width:24px;height:24px;background-image:url(" + i + ");background-size:24px 72px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .webstation-file-input__btn{background-image:url(" + o + ");background-size:24px 72px}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .webstation-file-input__btn{background-image:url(" + o + ");background-size:24px 72px;outline:1px green dashed}}.webstation-file-input__input{display:none}.webstation-file-input{border-color:rgba(198,212,224,0.7)}.webstation-file-input .webstation-file-input__btn{background-position-y:0px}.webstation-file-input--hover{border-color:rgba(124,138,152,0.5)}.webstation-file-input--hover .webstation-file-input__btn{background-position-y:0px}.webstation-file-input--focus{border-color:#057FEB}.webstation-file-input--focus .webstation-file-input__btn{background-position-y:48px}.has-error .webstation-file-input{border-color:#E64040;background:#fdf0f0}.v-table .webstation-file-input{margin:1px 0;width:100%;height:26px !important}.v-table .webstation-file-input__btn{top:0}\n", ""])
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/d33f3914d66291159ba7e5c7c55d7ffb.png"
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/d282632c3b73ea2c27c2e2181cfbc0e9.png"
}, function(t, e, r) {
    "use strict";
    var n = r(26);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".error-page-profile-form .v-form-item-label{width:200px;margin-right:8px}.error-page-profile-form__v-input .v-textfield-input{width:291px}.error-page-profile-form__v-select{width:315px}.error-page-profile-form__file-input{width:315px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(27);
    r.n(n).a
}, function(t, e, r) {
    e = t.exports = r(0)(!1);
    var n = r(7),
        i = n(r(158)),
        o = n(r(159));
    e.push([t.i, ".response-actions{display:flex}.response-actions__form-item{flex:1;overflow:hidden}.response-actions__form-item--select{margin-right:3px !important}.response-actions__form-item--action{margin-left:3px !important;margin-right:4px !important}.response-actions__select{margin-right:0}.response-actions__delete-btn{cursor:pointer;margin:4px 0;margin-left:4px !important;width:20px;height:20px;border:none;background:none;background-image:url(" + i + ");background-size:20px 60px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .response-actions__delete-btn{background-image:url(" + o + ");background-size:20px 60px}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .response-actions__delete-btn{background-image:url(" + o + ");background-size:20px 60px;outline:1px green dashed}}.response-actions__delete-btn{background-position:0px 0px}.response-actions__delete-btn:hover{background-position:0px -20px}.response-actions__delete-btn:active{background-position:0px -40px}\n", ""])
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/301528fe0a6f3b5641719d86fdafa767.png"
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/3cc8a1f462a4a863c49cac2a7f084f82.png"
}, function(t, e, r) {
    "use strict";
    var n = r(28);
    r.n(n).a
}, function(t, e, r) {
    e = t.exports = r(0)(!1);
    var n = r(7),
        i = n(r(162)),
        o = n(r(163));
    e.push([t.i, ".custom-settings__data-table__empty-text{font-size:13px;color:rgba(65,75,85,0.4)}.custom-settings__data-table .v-form-item-input,.custom-settings__data-table .v-form-item-control{width:100%}.custom-settings__paragraph{color:#414b55;padding:4px 0;margin-bottom:6px;line-height:20px}.custom-settings__add-page-btn{margin-bottom:8px}.file-dragger{z-index:100;position:relative;width:100%;height:100%;top:0;left:0}.file-dragger__cover{z-index:1;position:absolute;display:flex;width:100%;height:100%;top:0;left:0;background:rgba(0,166,166,0.15);border:1px solid #00A6A6;box-sizing:border-box}.file-dragger__cover *{pointer-events:none}.file-dragger__cover__content{margin:auto}.file-dragger__cover__content__img{display:flex;margin-left:auto;margin-right:auto;margin-bottom:14px;border-radius:50%;width:72px;height:72px;background:#fff}.file-dragger__cover__content__img:before{content:'';margin:auto;width:40px;height:40px;background-image:url(" + i + ");background-size:40px 40px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .file-dragger__cover__content__img:before{background-image:url(" + o + ");background-size:40px 40px}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .file-dragger__cover__content__img:before{background-image:url(" + o + ");background-size:40px 40px;outline:1px green dashed}}.file-dragger__cover__content__text{font-size:15px;color:#fff;text-align:center;line-height:34px;height:34px;width:220px;background:#00A6A6;border-radius:17px}.file-dragger__cover--hidden{display:none}\n", ""])
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/ebd535b44d72d5b198f391f9fd04bdfb.gif"
}, function(t, e) {
    t.exports = "webman/3rdparty/WebStation/assets/a6caaa6a534dd21152dbd616a610411d.gif"
}, function(t, e, r) {
    "use strict";
    var n = r(29);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".modal-footer[data-v-40ab164b]{display:flex;justify-content:space-between;box-sizing:border-box;border-top:1px solid rgba(198,212,224,0.5);padding:9px 0 10px 0;width:100%}.modal-footer__left-text[data-v-40ab164b]{padding-left:8px}.modal-footer__left-text--error[data-v-40ab164b]{color:#E64040}.modal-footer__right-actions[data-v-40ab164b]{width:auto;display:inline-flex;flex-flow:row}.modal-footer__right-actions__btn[data-v-40ab164b]{margin-left:8px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(30);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".profile-dialog{height:540px;padding:0}.profile-dialog__wrapper{box-sizing:border-box;padding:8px 20px 12px 20px}.profile-dialog__general-settings{margin-bottom:12px}.profile-dialog__general-settings .v-fieldset-body{padding-bottom:0}.profile-dialog__custom-settings .v-fieldset-title-wrapper{padding-top:0}.profile-dialog__custom-settings .v-fieldset-body{padding-bottom:1px}\n", ""])
}, function(t, e, r) {
    "use strict";
    var n = r(31);
    r.n(n).a
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".profile-dialog[data-v-c74d9942]{padding:0}.profile-dialog__content[data-v-c74d9942]{padding:10px 20px}.profile-dialog__content p[data-v-c74d9942]{line-height:20px;padding:4px 0;margin-bottom:6px}.profile-dialog__file-input[data-v-c74d9942]{width:315px}\n", ""])
}, function(t, e, r) {
    var n = r(171);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("0896b611", n, !1, {})
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".ws-servicewizard-container{padding-top:24px}.ws-servicewizard-container.may-have-scrollbar{padding-bottom:12px}\n", ""])
}, function(t, e, r) {
    var n = r(173);
    "string" == typeof n && (n = [
        [t.i, n, ""]
    ]), n.locals && (t.exports = n.locals);
    (0, r(1).default)("2786b8a3", n, !1, {})
}, function(t, e, r) {
    (t.exports = r(0)(!1)).push([t.i, ".webstation-panel{display:flex;flex-direction:column;height:100%;box-sizing:border-box;padding-bottom:12px}.webstation-panel__data-table{height:100%;overflow:hidden}.action-buttons-bar{display:flex}.action-buttons-bar__item{margin-right:6px;margin-bottom:8px}.webstation-vue-modal .x-window-bwrap,.webstation-vue-modal .x-window-body{overflow:initial}.webstation-vue-modal .toast-text{color:#009E05}\n", ""])
}, function(t, e, r) {
    "use strict";
    r.r(e);
    var n = {};
    r.r(n), r.d(n, "descRules", (function() {
        return rr
    })), r.d(n, "generateCodeRules", (function() {
        return nr
    })), r.d(n, "errorPageStaticFileRules", (function() {
        return ir
    })), r.d(n, "importErrorProfileFileRules", (function() {
        return or
    })), r.d(n, "relativeUrlRules", (function() {
        return ar
    })), r.d(n, "absoluteUrlRules", (function() {
        return sr
    }));
    var i = r(4),
        o = r.n(i),
        a = function() {
            var t = this.$createElement,
                e = this._self._c || t;
            return e("v-wizard-window", {
                ref: "window",
                attrs: {
                    "syno-id": "ws-service-wizard-window",
                    title: this._TT("SYNO.SDS.WebStation.Application", "service_wizard", "service_wizard"),
                    width: 600,
                    height: "auto",
                    "before-close": function() {}
                }
            }, [e("ServiceWizard", {
                on: {
                    "step-scroll": this.onStepScrolled,
                    spinning: this.onSpinning,
                    "show-message-box": this.onMessageBoxShow,
                    close: this.onClose
                }
            })], 1)
        };
    a._withStripped = !0;
    var s = function() {
        var t = this,
            e = t.$createElement,
            r = t._self._c || e;
        return r("v-wizard", {
            attrs: {
                "syno-id": "ws-service-wizard",
                "active-step-key": "select-portal",
                "wizard-style": t.wizardStyle,
                "step-ct-style": t.stepCtStyle,
                "custom-buttons-group": t.buttonsGroup,
                refs: "wizard"
            },
            on: {
                "step-scroll": function(e) {
                    return t.$emit("step-scroll", e)
                }
            }
        }, [r("step-select-portal", {
            attrs: {
                "syno-id": "step-select-portal",
                "step-key": "select-portal",
                "service-id": t.sharedData.serviceId,
                "service-name": t.sharedData.serviceName,
                "service-list": t.sharedData.serviceList,
                "local-package-map": t.sharedData.localPackageMap,
                "server-package-map": t.sharedData.serverPackageMap,
                "web-service-map": t.sharedData.webServiceMap
            },
            on: {
                "update:serviceId": function(e) {
                    return t.$set(t.sharedData, "serviceId", e)
                },
                "update:service-id": function(e) {
                    return t.$set(t.sharedData, "serviceId", e)
                },
                "update:serviceName": function(e) {
                    return t.$set(t.sharedData, "serviceName", e)
                },
                "update:service-name": function(e) {
                    return t.$set(t.sharedData, "serviceName", e)
                },
                "update:serviceList": function(e) {
                    return t.$set(t.sharedData, "serviceList", e)
                },
                "update:service-list": function(e) {
                    return t.$set(t.sharedData, "serviceList", e)
                },
                "update:localPackageMap": function(e) {
                    return t.$set(t.sharedData, "localPackageMap", e)
                },
                "update:local-package-map": function(e) {
                    return t.$set(t.sharedData, "localPackageMap", e)
                },
                "update:serverPackageMap": function(e) {
                    return t.$set(t.sharedData, "serverPackageMap", e)
                },
                "update:server-package-map": function(e) {
                    return t.$set(t.sharedData, "serverPackageMap", e)
                },
                "update:webServiceMap": function(e) {
                    return t.$set(t.sharedData, "webServiceMap", e)
                },
                "update:web-service-map": function(e) {
                    return t.$set(t.sharedData, "webServiceMap", e)
                },
                spinning: function(e) {
                    return t.$emit("spinning", e)
                },
                "display-error": t.displayError,
                "show-message-box": function() {
                    for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                    return t.$emit.apply(void 0, ["show-message-box"].concat(e))
                },
                enableNextButton: t.onEnableNextButton
            }
        }), t._v(" "), r("step-select-service", {
            attrs: {
                "syno-id": "step-select-service",
                "step-key": "select-service",
                "service-id": t.sharedData.serviceId,
                "service-name": t.sharedData.serviceName,
                "service-list": t.sharedData.serviceList,
                "local-package-map": t.sharedData.localPackageMap,
                "server-package-map": t.sharedData.serverPackageMap,
                "web-service-map": t.sharedData.webServiceMap
            },
            on: {
                "update:serviceId": function(e) {
                    return t.$set(t.sharedData, "serviceId", e)
                },
                "update:service-id": function(e) {
                    return t.$set(t.sharedData, "serviceId", e)
                },
                "update:serviceName": function(e) {
                    return t.$set(t.sharedData, "serviceName", e)
                },
                "update:service-name": function(e) {
                    return t.$set(t.sharedData, "serviceName", e)
                },
                spinning: function(e) {
                    return t.$emit("spinning", e)
                },
                "show-message-box": function() {
                    for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                    return t.$emit.apply(void 0, ["show-message-box"].concat(e))
                },
                enableNextButton: t.onEnableNextButton
            }
        }), t._v(" "), r("step-virtualhost", {
            attrs: {
                "syno-id": "step-virtualhost",
                "step-key": "virtual-host",
                "shared-data": t.sharedData
            },
            on: {
                "update:sharedData": function(e) {
                    t.sharedData = e
                },
                "update:shared-data": function(e) {
                    t.sharedData = e
                },
                spinning: function(e) {
                    return t.$emit("spinning", e)
                },
                "display-error": t.displayError,
                "show-message-box": function() {
                    for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                    return t.$emit.apply(void 0, ["show-message-box"].concat(e))
                },
                enableNextButton: t.onEnableNextButton,
                close: function(e) {
                    return t.$emit("close")
                }
            }
        }), t._v(" "), r("step-server-portal", {
            attrs: {
                "syno-id": "step-server-portal",
                "step-key": "server-portal",
                "shared-data": t.sharedData
            },
            on: {
                "update:sharedData": function(e) {
                    t.sharedData = e
                },
                "update:shared-data": function(e) {
                    t.sharedData = e
                },
                spinning: function(e) {
                    return t.$emit("spinning", e)
                },
                "display-error": t.displayError,
                "show-message-box": function() {
                    for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                    return t.$emit.apply(void 0, ["show-message-box"].concat(e))
                },
                enableNextButton: t.onEnableNextButton,
                close: function(e) {
                    return t.$emit("close")
                }
            }
        }), t._v(" "), r("step-default-server-portal", {
            attrs: {
                "syno-id": "step-default-server-portal",
                "step-key": "default-server-portal",
                "shared-data": t.sharedData
            },
            on: {
                "update:sharedData": function(e) {
                    t.sharedData = e
                },
                "update:shared-data": function(e) {
                    t.sharedData = e
                },
                spinning: function(e) {
                    return t.$emit("spinning", e)
                },
                "display-error": t.displayError,
                "show-message-box": function() {
                    for (var e = [], r = arguments.length; r--;) e[r] = arguments[r];
                    return t.$emit.apply(void 0, ["show-message-box"].concat(e))
                },
                enableNextButton: t.onEnableNextButton,
                close: function(e) {
                    return t.$emit("close")
                }
            }
        })], 1)
    };
    s._withStripped = !0;
    var c = {
            methods: {
                T: function(t, e) {
                    var r = _T(t, e);
                    return "" === r ? "".concat(t, ":").concat(e) : r
                },
                TT: function(t, e, r) {
                    try {
                        return SYNO.SDS.Strings[t][e][r]
                    } catch (t) {
                        return ""
                    }
                },
                JSLIBSTR: function(t, e) {
                    try {
                        return SYNOJSLIB_Strings[t][e]
                    } catch (t) {
                        return ""
                    }
                }
            }
        },
        p = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-wizard-step", {
                ref: "step",
                attrs: {
                    "syno-id": "ws-sw-select-portal",
                    "show-footer": !1,
                    "step-key": t.stepKey,
                    headline: t.TT("SYNO.SDS.WebStation.Application", "service_wizard", "title_portal"),
                    "next-step-key": t.nextStep
                },
                on: {
                    activate: t.onActivate
                }
            }, [r("div", {
                staticClass: "ws-servicewizard-container"
            }, [r("Portal-Type", {
                attrs: {
                    id: t.virtualHostInfo.id,
                    iconPath: t.virtualHostInfo.iconPath,
                    title: t.virtualHostInfo.title,
                    description: t.virtualHostInfo.description
                },
                on: {
                    "type-select": t.onTypeSelect
                }
            }), t._v(" "), r("Portal-Type", {
                attrs: {
                    id: t.portalServerInfo.id,
                    iconPath: t.portalServerInfo.iconPath,
                    title: t.portalServerInfo.title,
                    description: t.portalServerInfo.description
                },
                on: {
                    "type-select": t.onTypeSelect
                }
            }), t._v(" "), r("Portal-Type", {
                attrs: {
                    id: t.defaultPortalServerInfo.id,
                    iconPath: t.defaultPortalServerInfo.iconPath,
                    title: t.defaultPortalServerInfo.title,
                    description: t.defaultPortalServerInfo.description
                },
                on: {
                    "type-select": t.onDefaultServerPortalTypeSelect
                }
            })], 1)])
        };
    p._withStripped = !0;
    var l = function() {
        var t = this,
            e = t.$createElement,
            r = t._self._c || e;
        return r("div", {
            class: t.typeCls,
            on: {
                click: function(e) {
                    return e.preventDefault(), t.onClick(e)
                }
            }
        }, [r("div", {
            staticClass: "portal-type-container"
        }, [r("img", {
            staticClass: "portal-icon",
            attrs: {
                src: t.iconPath,
                draggable: "false"
            }
        }), r("div", {
            staticClass: "description-wrapper"
        }, [r("div", {
            staticClass: "description-title"
        }, [r("span", {
            domProps: {
                innerHTML: t._s(t.title)
            }
        })]), t._v(" "), r("div", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: t.tooltipOptions,
                expression: "tooltipOptions"
            }],
            staticClass: "description-content"
        }, [r("span", {
            domProps: {
                innerHTML: t._s(t.description)
            }
        })])])])])
    };
    l._withStripped = !0;
    var u = {
        name: "PortalType",
        props: {
            id: {
                type: String,
                require: !0
            },
            iconPath: {
                type: String,
                require: !0
            },
            title: {
                type: String,
                require: !0
            },
            description: {
                type: String,
                require: !0
            },
            isSelected: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            typeCls: function() {
                return ["portal-type", {
                    "portal-type-selected": this.isSelected
                }]
            },
            tooltipOptions: function() {
                return {
                    content: this.description,
                    overflowOnly: !0
                }
            }
        },
        methods: {
            onClick: function() {
                this.$emit("type-select", this.id)
            }
        }
    };
    r(65);

    function d(t, e, r, n, i, o, a, s) {
        var c, p = "function" == typeof t ? t.options : t;
        if (e && (p.render = e, p.staticRenderFns = r, p._compiled = !0), n && (p.functional = !0), o && (p._scopeId = "data-v-" + o), a ? (c = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), i && i.call(this, t), t && t._registeredComponents && t._registeredComponents.add(a)
            }, p._ssrRegister = c) : i && (c = s ? function() {
                i.call(this, this.$root.$options.shadowRoot)
            } : i), c)
            if (p.functional) {
                p._injectStyles = c;
                var l = p.render;
                p.render = function(t, e) {
                    return c.call(e), l(t, e)
                }
            } else {
                var u = p.beforeCreate;
                p.beforeCreate = u ? [].concat(u, c) : [c]
            } return {
            exports: t,
            options: p
        }
    }
    var f = d(u, l, [], !1, null, null, null);

    function h(t) {
        return function(t) {
            if (Array.isArray(t)) {
                for (var e = 0, r = new Array(t.length); e < t.length; e++) r[e] = t[e];
                return r
            }
        }(t) || function(t) {
            if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        }()
    }

    function v(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                m(t, e, r[e])
            }))
        }
        return t
    }

    function m(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function _(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function b(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    _(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    _(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    f.options.__file = "src/components/PortalType.vue";
    var g, S, w, y, x = d({
        mixins: [c],
        components: {
            PortalType: f.exports
        },
        props: {
            stepKey: String,
            nextStepkey: String,
            serviceList: Array
        },
        data: function() {
            return {
                nextStep: "",
                virtualHostInfo: {
                    id: "virtual-host",
                    iconPath: "webman/3rdparty/WebStation/images/default/".concat(this.iconResolution(), "/wizard_icn_virtual_host.png"),
                    title: this.TT("SYNO.SDS.WebStation.Application", "title", "vhost"),
                    description: this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "vhost_description")
                },
                portalServerInfo: {
                    id: "select-service",
                    iconPath: "webman/3rdparty/WebStation/images/default/".concat(this.iconResolution(), "/wizard_icn_package_server_portal.png"),
                    title: this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "package_server_portal"),
                    description: this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "package_server_portal_description")
                },
                defaultPortalServerInfo: {
                    id: "default-server-portal",
                    iconPath: "webman/3rdparty/WebStation/images/default/".concat(this.iconResolution(), "/wizard_icn_alternative.png"),
                    title: this.TT("SYNO.SDS.WebStation.Application", "portal", "alternative_host_title_case"),
                    description: this.TT("SYNO.SDS.WebStation.Application", "portal", "alternative_host_description")
                },
                localPackageMap: {},
                serverPackageMap: {},
                webServiceMap: {}
            }
        },
        computed: {
            webStationService: function() {
                return this.serviceList.find((function(t) {
                    return "WebStation" === t.category && "default_server" === t.service
                }))
            }
        },
        methods: {
            onActivate: (y = b(regeneratorRuntime.mark((function t() {
                var e;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return this.$emit("enableNextButton", !1), this.$emit("spinning", !0), t.prev = 2, t.next = 5, this.getServiceList();
                        case 5:
                            e = t.sent, this.$emit("update:service-list", e), t.next = 12;
                            break;
                        case 9:
                            t.prev = 9, t.t0 = t.catch(2), this.$emit("display-error", t.t0.code);
                        case 12:
                            return t.prev = 12, this.$emit("spinning", !1), t.finish(12);
                        case 15:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [2, 9, 12, 15]
                ])
            }))), function() {
                return y.apply(this, arguments)
            }),
            onTypeSelect: function(t) {
                this.nextStep = t, this.$refs.step.nextStep()
            },
            onDefaultServerPortalTypeSelect: function(t) {
                this.webStationService && (this.$emit("update:service-id", this.webStationService.serviceId), this.$emit("update:service-name", this.webStationService.displayName), this.onTypeSelect(t))
            },
            iconResolution: function() {
                return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() ? "2x" : "1x"
            },
            getServiceList: (w = b(regeneratorRuntime.mark((function t() {
                var e, r, n, i, o;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = [], t.next = 3, Promise.all([this.fetchWebServices(), this.fetchServerAndLocalPackages()]);
                        case 3:
                            for (r in this.webServiceMap)
                                for (i in n = this.webServiceMap[r]) e.push(this.createWebServiceRecord(r, n[i]));
                            t.t0 = regeneratorRuntime.keys(this.serverPackageMap);
                        case 5:
                            if ((t.t1 = t.t0()).done) {
                                t.next = 12;
                                break
                            }
                            if (o = t.t1.value, !this.webServiceMap.hasOwnProperty(o)) {
                                t.next = 9;
                                break
                            }
                            return t.abrupt("continue", 5);
                        case 9:
                            e.push(this.createRemoteServerRecord(o, this.serverPackageMap[o])), t.next = 5;
                            break;
                        case 12:
                            return t.abrupt("return", e);
                        case 13:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return w.apply(this, arguments)
            }),
            fetchWebServices: (S = b(regeneratorRuntime.mark((function t() {
                var e;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.next = 3, synowebapi.promises.request({
                                api: "SYNO.WebStation.WebService.Service",
                                version: 1,
                                method: "list",
                                params: {
                                    all: !0
                                }
                            });
                        case 3:
                            e = t.sent, this.webServiceMap = e.services.reduce((function(t, e) {
                                return e.category in t || (t[e.category] = {}), t[e.category][e.id] = e, t
                            }), {}), this.$emit("update:web-service-map", this.webServiceMap);
                        case 6:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return S.apply(this, arguments)
            }),
            fetchServerAndLocalPackages: (g = b(regeneratorRuntime.mark((function t() {
                var e;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.next = 2, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                        case 2:
                            e = t.sent, this.localPackageMap = e.install, this.serverPackageMap = Object.values(e.official).filter((function(t) {
                                return "WEBSTATION_SERVICE" === t.provides
                            })).reduce((function(t, e) {
                                return v({}, t, m({}, e.id, e))
                            }), {}), this.$emit("update:local-package-map", this.localPackageMap), this.$emit("update:server-package-map", this.serverPackageMap);
                        case 7:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return g.apply(this, arguments)
            }),
            createWebServiceRecord: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return v({}, this.createRecord(t, e), {
                    type: "web-service",
                    serviceId: e.id,
                    managed_by_web_service: e.managed_by_web_service,
                    iconPath: this.getServiceIconPath(this.webServiceMap[t][e.id]),
                    displayName: this.getServiceDisplayName(this.webServiceMap[t][e.id])
                })
            },
            createRemoteServerRecord: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return v({}, this.createRecord(t, e), {
                    type: "remote-service",
                    iconPath: this.getRemotePackageIconPath(this.serverPackageMap[t]),
                    displayName: this.serverPackageMap[t].dname
                })
            },
            createRecord: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return {
                    packageId: t,
                    service: e.service,
                    category: e.category,
                    installed: this.isPackageInstalled(t),
                    enabled: this.isPackageEnabled(t, e.id),
                    needUpgrade: this.isPackageNeedUpgrade(t)
                }
            },
            getRemotePackageIconPath: function(t) {
                var e = {
                    api: "SYNO.Core.Package.Thumb.Server",
                    version: 1,
                    method: "get",
                    params: {
                        name: t.id,
                        ver: t.version,
                        size: 72,
                        bls: !0,
                        link: this.isRetina ? t.thumbnail_retina[0] : t.thumbnail[0]
                    }
                };
                return "".concat(SYNO.API.GetBaseURL(e))
            },
            getServiceIconPath: function(t) {
                var e = "webman/3rdparty/WebService/images/{SERVICE_UUID}/icon_{0}.png";
                return e = (e = e.replace("{SERVICE_UUID}", t.id)).replace("{0}", this.isRetina ? "256" : "48")
            },
            getServiceDisplayName: function(t) {
                var e = t.display_name,
                    r = t.display_name_i18n;
                if (null === r) return e;
                var n = r.split(":");
                return 3 === n.length ? this.TT.apply(this, h(n)) : 2 === n.length ? this.T.apply(this, h(n)) : r
            },
            isPackageInstalled: function(t) {
                return this.localPackageMap.hasOwnProperty(t)
            },
            isPackageEnabled: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                return !!(e && this.localPackageMap.hasOwnProperty(t) && this.webServiceMap.hasOwnProperty(t) && this.webServiceMap[t].hasOwnProperty(e)) && this.webServiceMap[t][e].enable
            },
            isPackageNeedUpgrade: function(t) {
                return this.serverPackageMap.hasOwnProperty(t) && this.localPackageMap.hasOwnProperty(t) && !this.webServiceMap.hasOwnProperty(t)
            }
        }
    }, p, [], !1, null, null, null);
    x.options.__file = "src/components/serviceWizard/StepSelectPortal.vue";
    var P = x.exports,
        T = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-wizard-step", {
                attrs: {
                    "syno-id": "ws-sw-select-service",
                    preEnterNextStep: t.beforeNextStep,
                    "step-key": t.stepKey,
                    headline: t.TT("SYNO.SDS.WebStation.Application", "service_wizard", "title_service"),
                    "next-step-key": "server-portal"
                },
                on: {
                    activate: t.onActivate
                }
            }, [0 === t.serviceAmount ? r("div", {
                staticClass: "ws-servicewizard-service-empty-zero",
                attrs: {
                    id: "ws-sw-select-service-empty-zero"
                }
            }, [r("div", {
                staticClass: "ws-empty-text-wrap"
            }, [r("div", {
                staticClass: "ws-empty-text-inner-wrap"
            }, [r("div", {
                staticClass: "ws-empty-text-icon"
            }), t._v(" "), r("div", {
                staticClass: "ws-empty-text"
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "service_wizard", "no_service")))])])])]) : r("div", {
                staticClass: "ws-servicewizard-container may-have-scrollbar",
                attrs: {
                    id: "ws-sw-select-service-panel"
                }
            }, [t.serviceAmount <= 6 ? r("div", {
                staticClass: "ws-servicewizard-cardtable"
            }, t._l(t.serviceManagedByWebStationList, (function(e, n) {
                return r("ServiceCard", {
                    key: n,
                    attrs: {
                        iconPath: e.iconPath,
                        serviceName: e.displayName,
                        index: n,
                        isSelected: n === t.selectedItemIndex,
                        isDisabled: !t.isServiceAvailable(e),
                        disabledMessage: t.getDisabledMessage(e)
                    },
                    on: {
                        "card-select": t.onCardSelect
                    }
                })
            })), 1) : r("div", {
                staticClass: "ws-servicewizard-cardtable-inline"
            }, t._l(t.serviceManagedByWebStationList, (function(e, n) {
                return r("ServiceCardInline", {
                    key: n,
                    attrs: {
                        iconPath: e.iconPath,
                        serviceName: e.displayName,
                        index: n,
                        isSelected: n === t.selectedItemIndex,
                        isDisabled: !t.isServiceAvailable(e),
                        disabledMessage: t.getDisabledMessage(e)
                    },
                    on: {
                        "card-select": t.onCardSelect
                    }
                })
            })), 1)])])
        };
    T._withStripped = !0;
    var k = function() {
        var t = this,
            e = t.$createElement,
            r = t._self._c || e;
        return t.isDisabled ? r("div", {
            directives: [{
                name: "tooltip",
                rawName: "v-tooltip",
                value: t.tooltipOptions,
                expression: "tooltipOptions"
            }],
            class: t.cardCls
        }, [r("div", {
            staticClass: "ws-servicewizard-service-card-container"
        }, [r("img", {
            staticClass: "ws-servicewizard-service-card-icon",
            attrs: {
                src: t.iconPath,
                draggable: "false"
            }
        }), r("div", {
            staticClass: "ws-servicewizard-service-card-name"
        }, [r("span", [t._v(t._s(t.serviceName))])])])]) : r("div", {
            class: t.cardCls,
            on: {
                click: function(e) {
                    return e.preventDefault(), t.onClick(e)
                }
            }
        }, [r("div", {
            staticClass: "ws-servicewizard-service-card-container"
        }, [r("img", {
            staticClass: "ws-servicewizard-service-card-icon",
            attrs: {
                src: t.iconPath,
                draggable: "false"
            }
        }), r("div", {
            staticClass: "ws-servicewizard-service-card-name"
        }, [r("span", [t._v(t._s(t.serviceName))])])])])
    };
    k._withStripped = !0;
    var D = {
            name: "ServiceCard",
            props: {
                iconPath: String,
                serviceName: {
                    type: String,
                    require: !0
                },
                index: {
                    type: Number,
                    require: !0
                },
                isSelected: {
                    type: Boolean,
                    require: !0
                },
                isDisabled: {
                    type: Boolean,
                    require: !0
                },
                disabledMessage: {
                    type: String,
                    require: !1
                }
            },
            computed: {
                cardCls: function() {
                    return ["ws-servicewizard-service-card", {
                        "ws-servicewizard-service-card-selected": this.isSelected && !this.isDisabled
                    }, {
                        "ws-servicewizard-service-card-disabled": this.isDisabled
                    }, {
                        "ws-servicewizard-service-card-normal": !this.isSelected && !this.isDisabled
                    }]
                },
                tooltipOptions: function() {
                    return {
                        content: this.disabledMessage
                    }
                }
            },
            methods: {
                onClick: function() {
                    this.$emit("card-select", this.index)
                }
            }
        },
        O = (r(67), d(D, k, [], !1, null, null, null));
    O.options.__file = "src/components/ServiceCard.vue";
    var N = O.exports,
        A = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return t.isDisabled ? r("div", {
                directives: [{
                    name: "tooltip",
                    rawName: "v-tooltip",
                    value: t.tooltipOptions,
                    expression: "tooltipOptions"
                }],
                class: t.cardCls
            }, [r("div", {
                staticClass: "ws-servicewizard-service-card-inline-container"
            }, [t.showIcon ? r("img", {
                staticClass: "ws-servicewizard-service-card-inline-icon",
                attrs: {
                    src: t.iconPath,
                    draggable: "false"
                }
            }) : t._e(), r("div", {
                staticClass: "ws-servicewizard-service-card-inline-name"
            }, [r("span", [t._v(t._s(t.serviceName))])])])]) : r("div", {
                class: t.cardCls,
                on: {
                    click: function(e) {
                        return e.preventDefault(), t.onClick(e)
                    }
                }
            }, [r("div", {
                staticClass: "ws-servicewizard-service-card-inline-container"
            }, [t.showIcon ? r("img", {
                staticClass: "ws-servicewizard-service-card-inline-icon",
                attrs: {
                    src: t.iconPath,
                    draggable: "false"
                }
            }) : t._e(), r("div", {
                staticClass: "ws-servicewizard-service-card-inline-name"
            }, [r("span", [t._v(t._s(t.serviceName))])])])])
        };
    A._withStripped = !0;
    var $ = {
            name: "ServiceCardInline",
            props: {
                iconPath: String,
                serviceName: {
                    type: String,
                    require: !0
                },
                index: {
                    type: Number,
                    require: !0
                },
                isSelected: {
                    type: Boolean,
                    require: !0
                },
                isDisabled: {
                    type: Boolean,
                    require: !0
                },
                disabledMessage: {
                    type: String,
                    require: !1
                }
            },
            computed: {
                cardCls: function() {
                    return ["ws-servicewizard-service-card-inline", {
                        "ws-servicewizard-service-card-inline-normal": !this.isSelected && !this.isDisabled
                    }, {
                        "ws-servicewizard-service-card-inline-selected": this.isSelected && !this.isDisabled
                    }, {
                        "ws-servicewizard-service-card-inline-disabled": this.isDisabled
                    }]
                },
                showIcon: function() {
                    return !!this.iconPath
                },
                tooltipOptions: function() {
                    return {
                        content: this.disabledMessage
                    }
                }
            },
            methods: {
                onClick: function() {
                    this.$emit("card-select", this.index)
                }
            }
        },
        E = (r(69), d($, A, [], !1, null, null, null));
    E.options.__file = "src/components/ServiceCardInline.vue";
    var C = {
            mixins: [c],
            components: {
                ServiceCard: N,
                ServiceCardInline: E.exports
            },
            props: {
                nextStepkey: String,
                stepKey: String,
                serviceList: Array,
                localPackageMap: Object,
                serverPackageMap: Object,
                webServiceMap: Object
            },
            data: function() {
                return {
                    selectedItemIndex: -1
                }
            },
            computed: {
                serviceManagedByWebStationList: function() {
                    return this.serviceList.filter((function(t) {
                        return "web-service" === t.type ? t.managed_by_web_service : "remote-service" === t.type
                    }))
                },
                serviceAmount: function() {
                    return this.serviceManagedByWebStationList.length
                },
                serviceAvailableAmount: function() {
                    return this.calcAvailableService(this.serviceManagedByWebStationList)
                },
                isRetina: function() {
                    return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
                }
            },
            methods: {
                beforeNextStep: function() {
                    if (!(this.selectedItemIndex >= 0 && this.serviceManagedByWebStationList && this.serviceManagedByWebStationList[this.selectedItemIndex])) return !1;
                    this.$emit("update:service-id", this.serviceManagedByWebStationList[this.selectedItemIndex].serviceId), this.$emit("update:service-name", this.serviceManagedByWebStationList[this.selectedItemIndex].displayName)
                },
                onActivate: function() {
                    var t = -1 !== this.selectedItemIndex;
                    this.$emit("enableNextButton", t, !1)
                },
                onCardSelect: function(t) {
                    this.selectedItemIndex = t, this.$emit("enableNextButton", !0, !1)
                },
                getDisabledMessage: function(t) {
                    return this.isPackageInstalled(t.packageId) ? this.isPackageNeedUpgrade(t.packageId) ? this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "tip_upgrade_package") : this.isPackageEnabled(t.packageId) ? "" : this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "tip_enable_package") : this.TT("SYNO.SDS.WebStation.Application", "service_wizard", "tip_install_package")
                },
                isPackageInstalled: function(t) {
                    return this.localPackageMap.hasOwnProperty(t)
                },
                isPackageEnabled: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
                    return !!(e && this.localPackageMap.hasOwnProperty(t) && this.webServiceMap.hasOwnProperty(t) && this.webServiceMap[t].hasOwnProperty(e)) && this.webServiceMap[t][e].enable
                },
                isPackageNeedUpgrade: function(t) {
                    return this.serverPackageMap.hasOwnProperty(t) && this.localPackageMap.hasOwnProperty(t) && !this.webServiceMap.hasOwnProperty(t)
                },
                isServiceAvailable: function(t) {
                    return t.installed && t.enabled && !t.needUpgrade
                },
                calcAvailableService: function(t) {
                    var e = 0,
                        r = !0,
                        n = !1,
                        i = void 0;
                    try {
                        for (var o, a = t[Symbol.iterator](); !(r = (o = a.next()).done); r = !0) service = o.value, this.isServiceAvailable(service) && (e += 1)
                    } catch (t) {
                        n = !0, i = t
                    } finally {
                        try {
                            r || null == a.return || a.return()
                        } finally {
                            if (n) throw i
                        }
                    }
                    return e
                }
            }
        },
        W = (r(71), d(C, T, [], !1, null, null, null));
    W.options.__file = "src/components/serviceWizard/StepSelectService.vue";
    var R = W.exports,
        I = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-wizard-step", {
                ref: "step",
                attrs: {
                    "syno-id": "ws-sw-virtualhost",
                    "step-key": t.stepKey,
                    finished: t.finished,
                    headline: t.TT("SYNO.SDS.WebStation.Application", "portal", "setup_vhost_title_case")
                },
                on: {
                    activate: t.onActivate
                }
            }, [r("div", {
                staticClass: "ws-servicewizard-container may-have-scrollbar"
            }, [r("v-perfect-scrollbar", [r("v-form", {
                ref: "form",
                attrs: {
                    usePerfectScroll: !0,
                    "syno-id": "virtualhost-form",
                    rules: t.rules
                }
            }, [r("v-radio-group", {
                staticClass: "radio-group",
                attrs: {
                    "syno-id": "virtualhost-based-group",
                    name: "basedGroup"
                },
                model: {
                    value: t.fields.based,
                    callback: function(e) {
                        t.$set(t.fields, "based", e)
                    },
                    expression: "fields.based"
                }
            }, [r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "name-based",
                    name: "based",
                    value: "name"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "name_based")))]), t._v(" "), r("v-form-item", {
                ref: "itemFqdn",
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                    indent: 1,
                    prop: "fqdn"
                }
            }, [r("v-input", {
                staticClass: "input-width",
                attrs: {
                    "syno-id": "fqdn",
                    name: "fqdn",
                    disabled: "name" !== t.fields.based,
                    mask: t.Validators().FQDN_MASK
                },
                model: {
                    value: t.fields.fqdn,
                    callback: function(e) {
                        t.$set(t.fields, "fqdn", e)
                    },
                    expression: "fields.fqdn"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    indent: 1,
                    prop: "name_port"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "name_port",
                    name: "name_port",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_port", e)
                    },
                    expression: "fields.name_port"
                }
            }, [t._v("80 / 443")])], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_http_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_http",
                    name: "name_http",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_http,
                    callback: function(e) {
                        t.$set(t.fields, "name_http", e)
                    },
                    expression: "fields.name_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpPort",
                attrs: {
                    prop: "name_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_http_port",
                    name: "name_http_port",
                    "number-only": !0,
                    disabled: t.nameHttpDisabled
                },
                model: {
                    value: t.fields.name_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_http_port", e)
                    },
                    expression: "fields.name_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_https",
                    name: "name_https",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_https,
                    callback: function(e) {
                        t.$set(t.fields, "name_https", e)
                    },
                    expression: "fields.name_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpsPort",
                attrs: {
                    prop: "name_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_https_port",
                    name: "name_https_port",
                    "number-only": !0,
                    disabled: t.nameHttpsDisabled
                },
                model: {
                    value: t.fields.name_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_https_port", e)
                    },
                    expression: "fields.name_https_port"
                }
            })], 1)], 1), t._v(" "), r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "port-based",
                    name: "based",
                    value: "port"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "port_based")))]), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    "syno-id": "port_based_http_port",
                    indent: 1
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_http",
                    name: "port_http",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_http,
                    callback: function(e) {
                        t.$set(t.fields, "port_http", e)
                    },
                    expression: "fields.port_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpPort",
                attrs: {
                    prop: "port_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_http_port",
                    name: "port_http_port",
                    "number-only": !0,
                    disabled: t.portHttpDisabled
                },
                model: {
                    value: t.fields.port_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_http_port", e)
                    },
                    expression: "fields.port_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "port_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_https",
                    name: "port_https",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_https,
                    callback: function(e) {
                        t.$set(t.fields, "port_https", e)
                    },
                    expression: "fields.port_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpsPort",
                attrs: {
                    prop: "port_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_https_port",
                    name: "port_https_port",
                    "number-only": !0,
                    disabled: t.portHttpsDisabled
                },
                model: {
                    value: t.fields.port_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_https_port", e)
                    },
                    expression: "fields.port_https_port"
                }
            })], 1)], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "docroot")
                }
            }, [r("v-form-item", {
                ref: "rootdoc",
                attrs: {
                    prop: "root"
                }
            }, [r("v-input", {
                staticClass: "input-width",
                attrs: {
                    "syno-id": "rootdoc",
                    name: "root"
                },
                model: {
                    value: t.fields.root,
                    callback: function(e) {
                        t.$set(t.fields, "root", e)
                    },
                    expression: "fields.root"
                }
            })], 1), t._v(" "), r("v-button", {
                attrs: {
                    "syno-id": "filechooser"
                },
                on: {
                    click: t.openFileChooser
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "choose_dir")))])], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                    prop: "hsts"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "hsts",
                    name: "hsts"
                },
                model: {
                    value: t.fields.hsts,
                    callback: function(e) {
                        t.$set(t.fields, "hsts", e)
                    },
                    expression: "fields.hsts"
                }
            }, [t._v("HSTS")])], 1), t._v(" "), r("v-form-item", {
                ref: "http_backend",
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "http_backend"),
                    prop: "backend"
                }
            }, [r("v-select", {
                attrs: {
                    "syno-id": "backend",
                    width: 220,
                    name: "backend",
                    displayField: "backend_name",
                    valueField: "backend_id",
                    options: this.backendList,
                    readonly: ""
                },
                model: {
                    value: t.fields.backend,
                    callback: function(e) {
                        t.$set(t.fields, "backend", e)
                    },
                    expression: "fields.backend"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: "PHP",
                    prop: "php"
                },
                scopedSlots: t._u([{
                    key: "after",
                    fn: function() {
                        return [r("v-whitetip", {
                            attrs: {
                                content: t.TT("SYNO.SDS.WebStation.Application", "php", "no_php_profile_available"),
                                tooltipOptions: {
                                    isHtml: !0
                                }
                            }
                        })]
                    },
                    proxy: !0
                }])
            }, [r("v-select", {
                attrs: {
                    "syno-id": "php",
                    width: 220,
                    name: "php",
                    displayField: "profile_name",
                    valueField: "uuid",
                    options: this.phpList,
                    readonly: "",
                    hasTooltip: ""
                },
                model: {
                    value: t.fields.php,
                    callback: function(e) {
                        t.$set(t.fields, "php", e)
                    },
                    expression: "fields.php"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.T("app_port_alias", "desc_acl"),
                    prop: "acl"
                },
                scopedSlots: t._u([{
                    key: "after",
                    fn: function() {
                        return [r("v-whitetip", {
                            attrs: {
                                content: t.TT("SYNO.SDS.WebStation.Application", "common", "no_acl_profile_available"),
                                tooltipOptions: {
                                    isHtml: !0
                                }
                            }
                        })]
                    },
                    proxy: !0
                }])
            }, [r("v-select", {
                attrs: {
                    "syno-id": "acl",
                    width: 220,
                    name: "acl",
                    displayField: "name",
                    valueField: "UUID",
                    options: this.aclList,
                    readonly: "",
                    hasTooltip: ""
                },
                model: {
                    value: t.fields.acl,
                    callback: function(e) {
                        t.$set(t.fields, "acl", e)
                    },
                    expression: "fields.acl"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_page_profile"),
                    prop: "error_page"
                },
                scopedSlots: t._u([{
                    key: "after",
                    fn: function() {
                        return [r("v-whitetip", {
                            attrs: {
                                content: t.TT("SYNO.SDS.WebStation.Application", "common", "tip_error_page_profile"),
                                tooltipOptions: {
                                    isHtml: !0
                                }
                            }
                        })]
                    },
                    proxy: !0
                }])
            }, [r("v-select", {
                attrs: {
                    "syno-id": "error_page",
                    width: 220,
                    name: "error_page",
                    displayField: "desc",
                    valueField: "id",
                    options: this.errorPageList,
                    readonly: "",
                    hasTooltip: ""
                },
                model: {
                    value: t.fields.error_page,
                    callback: function(e) {
                        t.$set(t.fields, "error_page", e)
                    },
                    expression: "fields.error_page"
                }
            })], 1)], 1)], 1)], 1)])
        };
    I._withStripped = !0;
    var j = {
            methods: {
                errorHandler: function(t, e) {
                    var r = SYNO.SDS.WebStation.Errors.GetMessage(t);
                    switch (t) {
                        case 1004:
                        case 1009:
                        case 1021:
                            this.handleConflictHost(e.conflict_ports);
                            break;
                        case 1007:
                            this.$refs.itemFqdn.setInvalid(r);
                            break;
                        case 1022:
                            this.$root.$appWindow.getMsgBox().confirm("ACL Error", r, this.onForceAcl, this);
                            break;
                        case 1307:
                            this.markHttpFieldInvaid(r);
                            break;
                        case 1308:
                            this.markHttpsFieldInvaid(r);
                            break;
                        case 1309:
                            this.markHttpFieldInvaid(r), this.markHttpsFieldInvaid(r);
                            break;
                        default:
                            this.$emit("display-error", r)
                    }
                },
                handleConflictHost: function(t) {
                    var e = this.fields,
                        r = "",
                        n = null,
                        i = null,
                        o = -1,
                        a = -1;
                    "name" === e.based ? (!1 === this.nameHttpDisabled && (n = this.$refs.itemNameHttpPort, o = parseInt(e.name_http_port, 10)), !1 === this.nameHttpsDisabled && (i = this.$refs.itemNameHttpsPort, a = parseInt(e.name_https_port, 10)), r = this.TT("SYNO.SDS.WebStation.Application", "error", "err_host_duplicated")) : (!1 === this.portHttpDisabled && (n = this.$refs.itemPortHttpPort, o = parseInt(e.port_http_port, 10)), !1 === this.portHttpsDisabled && (i = this.$refs.itemPortHttpsPort, a = parseInt(e.port_https_port, 10)), r = this.TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict")), !0 === e.name_port && this.$refs.itemFqdn.setInvalid(r), r = this.TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"), n && t.includes(o) && n.setInvalid(r), i && t.includes(a) && i.setInvalid(r)
                },
                markHttpFieldInvaid: function(t) {
                    "name" === this.fields.based ? this.$refs.itemNameHttpPort.setInvalid(t) : this.$refs.itemPortHttpPort.setInvalid(t)
                },
                markHttpsFieldInvaid: function(t) {
                    "name" === this.fields.based ? this.$refs.itemNameHttpsPort.setInvalid(t) : this.$refs.itemPortHttpsPort.setInvalid(t)
                },
                onForceAcl: function(t) {
                    "yes" == t && (this.forceAcl = !0, this.finished())
                }
            }
        },
        L = {
            methods: {
                Validators: function() {
                    return {
                        FQDN: function(t) {
                            if (this.IP(t)) return !1;
                            return /^(?:[^\s`=~!@#$%^&*()_+\[\]\\{}|;:'",\/<>?\.]+\.)*(?:[^\s`=~!@#$%^&*()_+\[\]\\{}|;:'",\/<>?\.]+)$/.test(t)
                        },
                        IP: function(t) {
                            return !(!this.IPv4(t) && !this.IPv6(t))
                        },
                        IPv4: function(t) {
                            return /^([1-9][0-9]{0,1}|1[0-9][0-9]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){2}[.]([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(t)
                        },
                        IPv6: function(t) {
                            return /^([1-9][0-9]{0,1}|1[0-9][0-9]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){2}[.]([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/.test(t)
                        },
                        FQDN_MASK: function(t) {
                            return t.replace(/[\s`=~!@#$%^&*()_+\[\]\\{}|;:'",\/<>?]+/, "")
                        }
                    }
                }
            }
        };

    function Y(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function z(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    Y(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    Y(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    var M, F, q, H, B = {
            mixins: [c, j, L],
            props: {
                nextStepkey: String,
                stepKey: String,
                sharedData: Object
            },
            data: function() {
                var t = this,
                    e = function(e, r, n) {
                        var i = e.field.slice(0, -5);
                        if (!0 === t.fields[i]) {
                            if (r.length <= 0) return void n(new Error(t.JSLIBSTR("extlang", "fieldblank")));
                            var o = parseInt(r, 10);
                            (o <= 0 || o > 65535) && n(new Error("1 ~ 65535"))
                        }
                        n()
                    };
                return {
                    fields: {
                        based: "name",
                        fqdn: "",
                        name_port: !0,
                        name_http: !1,
                        name_https: !1,
                        name_http_port: "",
                        name_https_port: "",
                        port_http: !1,
                        port_https: !1,
                        port_http_port: "",
                        port_https_port: "",
                        root: "",
                        hsts: !1,
                        backend: null,
                        php: null,
                        acl: null,
                        error_page: null
                    },
                    rules: {
                        fqdn: [{
                            validator: function(e, r, n) {
                                var i = t.fields;
                                "name" !== i.based && n();
                                var o = t.fields.fqdn;
                                if (o.length <= 0 && n(new Error(t.JSLIBSTR("extlang", "fieldblank"))), t.Validators().FQDN(o) || n(new Error(t.JSLIBSTR("vtype", "bad_domain_name"))), i.name_port && (t.isFQDNConflict(o, 80) || t.isFQDNConflict(o, 443)) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated"))), i.name_http) {
                                    var a = parseInt(i.name_http_port, 10);
                                    a && t.isFQDNConflict(o, a) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                if (i.name_https) {
                                    var s = parseInt(i.name_https_port, 10);
                                    s && t.isFQDNConflict(o, s) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                n()
                            }
                        }],
                        name_http_port: [{
                            validator: e
                        }],
                        name_https_port: [{
                            validator: e
                        }],
                        port_http_port: [{
                            validator: e
                        }],
                        port_https_port: [{
                            validator: e
                        }],
                        backend: {
                            required: !0,
                            message: this.JSLIBSTR("extlang", "fieldblank")
                        },
                        root: {
                            required: !0,
                            message: this.JSLIBSTR("extlang", "fieldblank")
                        }
                    },
                    backendList: [],
                    phpList: [],
                    aclList: [],
                    errorPageList: [],
                    FQDNPortPairList: [],
                    forceAcl: !1
                }
            },
            computed: {
                nameHttpDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_http
                },
                nameHttpsDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_https
                },
                portHttpDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_http
                },
                portHttpsDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_https
                }
            },
            mounted: function() {
                this.$wizardWindow = this.$root.$children[0].$refs.window
            },
            methods: {
                onActivate: function() {
                    var t = z(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                                case 2:
                                    this.packageInfo = t.sent, this.$emit("spinning", !0), this.findListFQDNPortPair(), this.apiGetACLAndBackendAndPHPAndErrorPageList(), this.$emit("enableNextButton", !0);
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                finished: (H = z(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, t.next = 3, this.$refs.form.validate();
                            case 3:
                                if (t.sent) {
                                    t.next = 7;
                                    break
                                }
                                return this.$emit("display-error", this.T("common", "forminvalid")), t.abrupt("return", !1);
                            case 7:
                                t.next = 13;
                                break;
                            case 9:
                                return t.prev = 9, t.t0 = t.catch(0), this.$emit("display-error", t.t0), t.abrupt("return", !1);
                            case 13:
                                return t.next = 15, this.apiSetVirtualHost();
                            case 15:
                                if (!t.sent) {
                                    t.next = 20;
                                    break
                                }
                                this.$emit("close"), t.next = 21;
                                break;
                            case 20:
                                return t.abrupt("return", !1);
                            case 21:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 9]
                    ])
                }))), function() {
                    return H.apply(this, arguments)
                }),
                apiGetACLAndBackendAndPHPAndErrorPageList: function() {
                    var t = this,
                        e = [{
                            api: "SYNO.Core.AppPortal.AccessControl",
                            method: "list",
                            version: 1
                        }, {
                            api: "SYNO.WebStation.Status",
                            method: "get",
                            version: 1
                        }, {
                            api: "SYNO.WebStation.PHP.Profile",
                            method: "list",
                            version: 1
                        }, {
                            api: "SYNO.WebStation.ErrorPage",
                            method: "list",
                            version: 1
                        }];
                    synowebapi.request({
                        compound: {
                            stopwhenerror: !0,
                            params: e
                        },
                        callback: function(e, r) {
                            t.$emit("spinning", !1), e ? (t.loadAclListFromAPIResponse(r.result[0].data), t.loadBackendListFromAPIResponse(r.result[1].data), t.loadPHPListFromAPIResponse(r.result[2].data), t.loadErrorPageFromAPIResponse(r.result[3].data)) : r && r.code && t.$emit("display-error", r.code)
                        }
                    })
                },
                loadAclListFromAPIResponse: function(t) {
                    this.aclList = [{
                        UUID: null,
                        name: this.TT("SYNO.SDS.WebStation.Application", "default", "not_configured")
                    }], this.aclList = this.aclList.concat(t.entries), this.fields.acl = this.aclList[0].UUID
                },
                loadBackendListFromAPIResponse: function(t) {
                    var e = this;
                    this.backendList = t.available_server_backend.map((function(t) {
                        return {
                            backend_id: t,
                            backend_name: e.packageInfo.backendData.server.find((function(e) {
                                return e.id === t
                            })).name
                        }
                    })), this.backendList.length > 0 ? this.fields.backend = this.backendList[0].backend_id : this.$refs.http_backend.setInvalid(this.TT("SYNO.SDS.WebStation.Application", "error", "err_backend_not_found"))
                },
                loadPHPListFromAPIResponse: function(t) {
                    var e = this;
                    this.phpList = [{
                        uuid: null,
                        profile_name: this.TT("SYNO.SDS.WebStation.Application", "default", "php_not_configured")
                    }], this.phpList = this.phpList.concat(t.profiles.filter((function(t) {
                        return null === t.default_profile
                    })).map((function(t) {
                        return {
                            uuid: t.uuid,
                            profile_name: "".concat(t.profile_name, " ( ").concat(e.packageInfo.backendData.php.find((function(e) {
                                return e.id === t.backend
                            })).name, " )")
                        }
                    }))), this.fields.php = this.phpList[0].uuid
                },
                loadErrorPageFromAPIResponse: function(t) {
                    this.errorPageList = t.profiles, this.errorPageList.find((function(t) {
                        return "default" == t.id
                    })).desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile"), this.fields.error_page = "default"
                },
                apiSetVirtualHost: (q = z(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$emit("spinning", !0), e = !1, t.prev = 2, t.next = 5, synowebapi.promises.request({
                                    api: "SYNO.WebStation.HTTP.VHost",
                                    version: 1,
                                    method: "add",
                                    params: {
                                        host: this.prepareSetParams()
                                    }
                                });
                            case 5:
                                t.sent, e = !0, t.next = 13;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(2), this.errorHandler(t.t0.code, t.t0.errors), e = !1;
                            case 13:
                                return t.prev = 13, this.$emit("spinning", !1), t.abrupt("return", e);
                            case 17:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [2, 9, 13, 17]
                    ])
                }))), function() {
                    return q.apply(this, arguments)
                }),
                initSetParams: function() {
                    return {
                        port: {
                            http: [],
                            https: []
                        },
                        https: {
                            hsts: !1
                        },
                        root: "",
                        backend: null,
                        php: null,
                        acl: null,
                        enable: !0,
                        version: 2,
                        apply_permission: !1
                    }
                },
                prepareSetParams: function() {
                    var t = this.initSetParams(),
                        e = this.fields;
                    return "name" === e.based ? (t.fqdn = e.fqdn, e.name_port && (t.port.http.push(80), t.port.https.push(443)), e.name_http && t.port.http.push(parseInt(e.name_http_port, 10)), e.name_https && t.port.https.push(parseInt(e.name_https_port, 10))) : (e.port_http && t.port.http.push(parseInt(e.port_http_port, 10)), e.port_https && t.port.https.push(parseInt(e.port_https_port, 10))), t.https.hsts = e.hsts, t.root = e.root, t.backend = e.backend, t.php = e.php, t.acl = e.acl, t.error_page = e.error_page, t.apply_permission = this.forceAcl, t
                },
                apiGetFQDNList: (F = z(regeneratorRuntime.mark((function t() {
                    var e, r;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = [{
                                    api: "SYNO.Core.Web.DSM",
                                    method: "get",
                                    version: 2
                                }, {
                                    api: "SYNO.Core.AppPortal",
                                    method: "list",
                                    version: 2
                                }, {
                                    api: "SYNO.Core.AppPortal.ReverseProxy",
                                    method: "list",
                                    version: 1
                                }], t.prev = 4, t.next = 7, synowebapi.promises.request({
                                    compound: {
                                        stopwhenerror: !0,
                                        params: e
                                    }
                                });
                            case 7:
                                return r = t.sent, t.abrupt("return", r);
                            case 11:
                                throw t.prev = 11, t.t0 = t.catch(4), t.t0;
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 11]
                    ])
                }))), function() {
                    return F.apply(this, arguments)
                }),
                findListFQDNPortPair: (M = z(regeneratorRuntime.mark((function t() {
                    var e, r, n, i;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return n = function(t, e) {
                                    e.entries.forEach((function(e) {
                                        e.frontend && e.frontend.fqdn && t.FQDNPortPairList.push({
                                            fqdn: e.frontend.fqdn.toLowerCase(),
                                            port: e.frontend.port
                                        })
                                    }))
                                }, r = function(t, e) {
                                    e.portal.forEach((function(e) {
                                        e.fqdn && (t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 80
                                        }), t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 443
                                        }))
                                    }))
                                }, e = function(t, e) {
                                    e.fqdn && (t.FQDNPortPairList.push({
                                        fqdn: e.fqdn.toLowerCase(),
                                        port: 80
                                    }), t.FQDNPortPairList.push({
                                        fqdn: e.fqdn.toLowerCase(),
                                        port: 443
                                    }))
                                }, this.$emit("spinning", !0), t.prev = 4, t.next = 7, this.apiGetFQDNList();
                            case 7:
                                i = t.sent, e(this, i.result[0].data), r(this, i.result[1].data), n(this, i.result[2].data), t.next = 16;
                                break;
                            case 13:
                                t.prev = 13, t.t0 = t.catch(4), this.$emit("display-error", t.t0.code);
                            case 16:
                                return t.prev = 16, this.$emit("spinning", !1), t.finish(16);
                            case 19:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 13, 16, 19]
                    ])
                }))), function() {
                    return M.apply(this, arguments)
                }),
                isFQDNConflict: function(t, e) {
                    t = t.toLowerCase();
                    for (var r = 0; r < this.FQDNPortPairList.length; r++) {
                        var n = this.FQDNPortPairList[r];
                        if (n.fqdn === t && n.port === e) return !0
                    }
                    return !1
                },
                openFileChooser: function() {
                    var t = this,
                        e = new SYNO.SDS.Utils.FileChooser.Chooser({
                            owner: this.$root.$appWindow,
                            needrw: !1,
                            usage: {
                                type: "chooseDir"
                            },
                            title: this.TT("SYNO.SDS.WebStation.Application", "vhost", "select_folder"),
                            folderToolbar: !0,
                            enumCluster: !1,
                            enumC2Share: !0,
                            listeners: {
                                choose: function(e, r, n) {
                                    var i = r.path;
                                    i && (i = i.replace(/^\/+/, "")) && (t.fields.root = i, t.$refs.rootdoc.resetInvalid(), e.close())
                                }
                            },
                            treeFilter: function(t, e) {
                                if (e) {
                                    if ("remote" === e.mountType) return !1;
                                    for (var r = ["/web_packages", "/home", "/homes"], n = e.spath, i = 0; i < r.length; i++)
                                        if (!(n.length < r[i] || n.substr(0, r[i].length) !== r[i] || n.length !== r[i].length && "/" !== n[r[i].length])) return !1
                                }
                                return !0
                            }
                        });
                    this.$wizardWindow.openModalWindow(e)
                }
            }
        },
        U = (r(75), d(B, I, [], !1, null, "af444550", null));
    U.options.__file = "src/components/serviceWizard/StepVirtualHost.vue";
    var V = U.exports,
        Q = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-wizard-step", {
                ref: "step",
                attrs: {
                    "syno-id": "ws-sw-server-portal",
                    "step-key": t.stepKey,
                    finished: t.finished,
                    headline: t.TT("SYNO.SDS.WebStation.Application", "portal", "setup_portal_title_case") + " - " + t.sharedData.serviceName
                },
                on: {
                    activate: t.onActivate
                }
            }, [r("div", {
                staticClass: "ws-servicewizard-container may-have-scrollbar"
            }, [r("v-perfect-scrollbar", [r("v-form", {
                ref: "form",
                attrs: {
                    usePerfectScroll: !0,
                    "syno-id": "server-portal-form",
                    rules: t.rules
                }
            }, [r("v-radio-group", {
                staticClass: "radio-group",
                attrs: {
                    "syno-id": "server-portal-based-group",
                    name: "basedGroup"
                },
                model: {
                    value: t.fields.based,
                    callback: function(e) {
                        t.$set(t.fields, "based", e)
                    },
                    expression: "fields.based"
                }
            }, [r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "name-based",
                    name: "based",
                    value: "name"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "name_based")))]), t._v(" "), r("v-form-item", {
                ref: "itemFqdn",
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                    indent: 1,
                    prop: "fqdn"
                }
            }, [r("v-input", {
                staticClass: "input-width",
                attrs: {
                    "syno-id": "fqdn",
                    name: "fqdn",
                    disabled: "name" !== t.fields.based,
                    mask: t.Validators().FQDN_MASK
                },
                model: {
                    value: t.fields.fqdn,
                    callback: function(e) {
                        t.$set(t.fields, "fqdn", e)
                    },
                    expression: "fields.fqdn"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    indent: 1,
                    prop: "name_port"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "name_port",
                    name: "name_port",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_port", e)
                    },
                    expression: "fields.name_port"
                }
            }, [t._v("80 / 443")])], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_http_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_http",
                    name: "name_http",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_http,
                    callback: function(e) {
                        t.$set(t.fields, "name_http", e)
                    },
                    expression: "fields.name_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpPort",
                attrs: {
                    prop: "name_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_http_port",
                    name: "name_http_port",
                    "number-only": !0,
                    disabled: t.nameHttpDisabled
                },
                model: {
                    value: t.fields.name_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_http_port", e)
                    },
                    expression: "fields.name_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_https",
                    name: "name_https",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_https,
                    callback: function(e) {
                        t.$set(t.fields, "name_https", e)
                    },
                    expression: "fields.name_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpsPort",
                attrs: {
                    prop: "name_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_https_port",
                    name: "name_https_port",
                    "number-only": !0,
                    disabled: t.nameHttpsDisabled
                },
                model: {
                    value: t.fields.name_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_https_port", e)
                    },
                    expression: "fields.name_https_port"
                }
            })], 1)], 1), t._v(" "), r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "port-based",
                    name: "based",
                    value: "port"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "port_based")))]), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    "syno-id": "port_based_http_port",
                    indent: 1
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_http",
                    name: "port_http",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_http,
                    callback: function(e) {
                        t.$set(t.fields, "port_http", e)
                    },
                    expression: "fields.port_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpPort",
                attrs: {
                    prop: "port_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_http_port",
                    name: "port_http_port",
                    "number-only": !0,
                    disabled: t.portHttpDisabled
                },
                model: {
                    value: t.fields.port_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_http_port", e)
                    },
                    expression: "fields.port_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "port_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_https",
                    name: "port_https",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_https,
                    callback: function(e) {
                        t.$set(t.fields, "port_https", e)
                    },
                    expression: "fields.port_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpsPort",
                attrs: {
                    prop: "port_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_https_port",
                    name: "port_https_port",
                    "number-only": !0,
                    disabled: t.portHttpsDisabled
                },
                model: {
                    value: t.fields.port_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_https_port", e)
                    },
                    expression: "fields.port_https_port"
                }
            })], 1)], 1)], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                    prop: "hsts"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "hsts",
                    name: "hsts"
                },
                model: {
                    value: t.fields.hsts,
                    callback: function(e) {
                        t.$set(t.fields, "hsts", e)
                    },
                    expression: "fields.hsts"
                }
            }, [t._v("HSTS")])], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.T("app_port_alias", "desc_acl"),
                    prop: "acl"
                },
                scopedSlots: t._u([{
                    key: "after",
                    fn: function() {
                        return [r("v-whitetip", {
                            attrs: {
                                content: t.TT("SYNO.SDS.WebStation.Application", "common", "no_acl_profile_available"),
                                tooltipOptions: {
                                    isHtml: !0
                                }
                            }
                        })]
                    },
                    proxy: !0
                }])
            }, [r("v-select", {
                attrs: {
                    "syno-id": "acl",
                    width: 220,
                    name: "acl",
                    displayField: "name",
                    valueField: "UUID",
                    options: this.aclList,
                    readonly: "",
                    hasTooltip: ""
                },
                model: {
                    value: t.fields.acl,
                    callback: function(e) {
                        t.$set(t.fields, "acl", e)
                    },
                    expression: "fields.acl"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_page_profile"),
                    prop: "error_page"
                },
                scopedSlots: t._u([{
                    key: "after",
                    fn: function() {
                        return [r("v-whitetip", {
                            attrs: {
                                content: t.TT("SYNO.SDS.WebStation.Application", "common", "tip_error_page_profile"),
                                tooltipOptions: {
                                    isHtml: !0
                                }
                            }
                        })]
                    },
                    proxy: !0
                }])
            }, [r("v-select", {
                attrs: {
                    "syno-id": "error_page",
                    width: 220,
                    name: "error_page",
                    displayField: "desc",
                    valueField: "id",
                    options: this.errorPageList,
                    readonly: "",
                    hasTooltip: ""
                },
                model: {
                    value: t.fields.error_page,
                    callback: function(e) {
                        t.$set(t.fields, "error_page", e)
                    },
                    expression: "fields.error_page"
                }
            })], 1)], 1)], 1)], 1)])
        };

    function G(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function J(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    G(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    G(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    Q._withStripped = !0;
    var K, X, Z = {
            name: "ServerPortal",
            mixins: [c, j, L],
            props: {
                nextStepkey: String,
                stepKey: String,
                sharedData: Object
            },
            data: function() {
                var t = this,
                    e = function(e, r, n) {
                        var i = e.field.slice(0, -5);
                        if (!0 === t.fields[i]) {
                            if (r.length <= 0) return void n(new Error(t.JSLIBSTR("extlang", "fieldblank")));
                            var o = parseInt(r, 10);
                            (o <= 0 || o > 65535) && n(new Error("1 ~ 65535"))
                        }
                        n()
                    };
                return {
                    fields: {
                        based: "name",
                        fqdn: "",
                        name_port: !0,
                        name_http: !1,
                        name_https: !1,
                        name_http_port: "",
                        name_https_port: "",
                        port_http: !1,
                        port_https: !1,
                        port_http_port: "",
                        port_https_port: "",
                        hsts: !1,
                        acl: null,
                        error_page: null
                    },
                    rules: {
                        fqdn: [{
                            validator: function(e, r, n) {
                                var i = t.fields;
                                "name" !== i.based && n();
                                var o = t.fields.fqdn;
                                if (o.length <= 0 && n(new Error(t.JSLIBSTR("extlang", "fieldblank"))), t.Validators().FQDN(o) || n(new Error(t.JSLIBSTR("vtype", "bad_domain_name"))), i.name_port && (t.isFQDNConflict(o, 80) || t.isFQDNConflict(o, 443)) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated"))), i.name_http) {
                                    var a = parseInt(i.name_http_port, 10);
                                    a && t.isFQDNConflict(o, a) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                if (i.name_https) {
                                    var s = parseInt(i.name_https_port, 10);
                                    s && t.isFQDNConflict(o, s) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                n()
                            }
                        }],
                        name_http_port: [{
                            validator: e
                        }],
                        name_https_port: [{
                            validator: e
                        }],
                        port_http_port: [{
                            validator: e
                        }],
                        port_https_port: [{
                            validator: e
                        }]
                    },
                    aclList: [],
                    errorPageList: [],
                    FQDNPortPairList: []
                }
            },
            computed: {
                nameHttpDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_http
                },
                nameHttpsDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_https
                },
                portHttpDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_http
                },
                portHttpsDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_https
                }
            },
            methods: {
                onActivate: function() {
                    this.$emit("spinning", !0), this.findListFQDNPortPair(), this.apiGetACLAndErrorPageList(), this.$emit("enableNextButton", !0)
                },
                finished: function() {
                    var t = J(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.prev = 0, t.next = 3, this.$refs.form.validate();
                                case 3:
                                    if (t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return this.$emit("display-error", this.T("common", "forminvalid")), t.abrupt("return", !1);
                                case 7:
                                    t.next = 13;
                                    break;
                                case 9:
                                    return t.prev = 9, t.t0 = t.catch(0), this.$emit("display-error", t.t0), t.abrupt("return", !1);
                                case 13:
                                    return t.next = 15, this.sendSetRequest();
                                case 15:
                                    if (!t.sent) {
                                        t.next = 20;
                                        break
                                    }
                                    this.$emit("close"), t.next = 21;
                                    break;
                                case 20:
                                    return t.abrupt("return", !1);
                                case 21:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [0, 9]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                apiGetACLAndErrorPageList: function() {
                    var t = this,
                        e = [{
                            api: "SYNO.Core.AppPortal.AccessControl",
                            version: 1,
                            method: "list"
                        }, {
                            api: "SYNO.WebStation.ErrorPage",
                            method: "list",
                            version: 1
                        }];
                    synowebapi.request({
                        compound: {
                            stopwhenerror: !0,
                            params: e
                        },
                        callback: function(e, r) {
                            t.$emit("spinning", !1), e ? (t.loadAclListFromAPIResponse(r.result[0].data), t.loadErrorPageFromAPIResponse(r.result[1].data)) : r && r.code && t.$emit("display-error", r.code)
                        }
                    })
                },
                loadAclListFromAPIResponse: function(t) {
                    this.aclList = [{
                        UUID: null,
                        name: this.TT("SYNO.SDS.WebStation.Application", "default", "not_configured")
                    }], this.aclList = this.aclList.concat(t.entries), this.fields.acl = this.aclList[0].UUID
                },
                loadErrorPageFromAPIResponse: function(t) {
                    this.errorPageList = t.profiles, this.errorPageList.find((function(t) {
                        return "default" === t.id
                    })).desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile"), this.fields.error_page = "default"
                },
                sendSetRequest: (X = J(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$emit("spinning", !0), e = !1, t.prev = 2, t.next = 5, synowebapi.promises.request({
                                    api: "SYNO.WebStation.WebService.Portal",
                                    version: 1,
                                    method: "create",
                                    params: {
                                        portal: this.prepareSetParams()
                                    }
                                });
                            case 5:
                                t.sent, e = !0, t.next = 13;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(2), this.errorHandler(t.t0.code, t.t0.errors), e = !1;
                            case 13:
                                return t.prev = 13, this.$emit("spinning", !1), t.abrupt("return", e);
                            case 17:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [2, 9, 13, 17]
                    ])
                }))), function() {
                    return X.apply(this, arguments)
                }),
                prepareSetParams: function() {
                    var t = this.fields,
                        e = {
                            http_port: [],
                            https_port: []
                        };
                    return "name" === t.based ? (e.fqdn = t.fqdn, t.name_port && (e.http_port.push(80), e.https_port.push(443)), t.name_http && e.http_port.push(parseInt(t.name_http_port, 10)), t.name_https && e.https_port.push(parseInt(t.name_https_port, 10))) : (t.port_http && e.http_port.push(parseInt(t.port_http_port, 10)), t.port_https && e.https_port.push(parseInt(t.port_https_port, 10))), e.hsts = t.hsts, e.acl = t.acl, e.error_page = t.error_page, e.enable = !0, e.type = "server", e.service = this.sharedData.serviceId, e
                },
                findListFQDNPortPair: function() {
                    var t = J(regeneratorRuntime.mark((function t() {
                        var e, r, n, i;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return n = function(t, e) {
                                        e.entries.forEach((function(e) {
                                            e.frontend && e.frontend.fqdn && t.FQDNPortPairList.push({
                                                fqdn: e.frontend.fqdn.toLowerCase(),
                                                port: e.frontend.port
                                            })
                                        }))
                                    }, r = function(t, e) {
                                        e.portal.forEach((function(e) {
                                            e.fqdn && (t.FQDNPortPairList.push({
                                                fqdn: e.fqdn.toLowerCase(),
                                                port: 80
                                            }), t.FQDNPortPairList.push({
                                                fqdn: e.fqdn.toLowerCase(),
                                                port: 443
                                            }))
                                        }))
                                    }, e = function(t, e) {
                                        e.fqdn && (t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 80
                                        }), t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 443
                                        }))
                                    }, this.$emit("spinning", !0), t.prev = 4, t.next = 7, this.sendFQDNListRequest();
                                case 7:
                                    i = t.sent, e(this, i.result[0].data), r(this, i.result[1].data), n(this, i.result[2].data), t.next = 16;
                                    break;
                                case 13:
                                    t.prev = 13, t.t0 = t.catch(4), this.$emit("display-error", t.t0.code);
                                case 16:
                                    return t.prev = 16, this.$emit("spinning", !1), t.finish(16);
                                case 19:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [4, 13, 16, 19]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                sendFQDNListRequest: (K = J(regeneratorRuntime.mark((function t() {
                    var e, r;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = [{
                                    api: "SYNO.Core.Web.DSM",
                                    method: "get",
                                    version: 2
                                }, {
                                    api: "SYNO.Core.AppPortal",
                                    method: "list",
                                    version: 2
                                }, {
                                    api: "SYNO.Core.AppPortal.ReverseProxy",
                                    method: "list",
                                    version: 1
                                }], t.prev = 4, t.next = 7, synowebapi.promises.request({
                                    compound: {
                                        stopwhenerror: !0,
                                        params: e
                                    }
                                });
                            case 7:
                                return r = t.sent, t.abrupt("return", r);
                            case 11:
                                throw t.prev = 11, t.t0 = t.catch(4), t.t0;
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 11]
                    ])
                }))), function() {
                    return K.apply(this, arguments)
                }),
                isFQDNConflict: function(t, e) {
                    t = t.toLowerCase();
                    for (var r = 0; r < this.FQDNPortPairList.length; r++) {
                        var n = this.FQDNPortPairList[r];
                        if (n.fqdn === t && n.port === e) return !0
                    }
                    return !1
                }
            }
        },
        tt = (r(77), d(Z, Q, [], !1, null, "6bbd554c", null));
    tt.options.__file = "src/components/serviceWizard/StepServerPortal.vue";
    var et = tt.exports,
        rt = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-wizard-step", {
                ref: "step",
                attrs: {
                    "syno-id": "ws-sw-default-server-portal",
                    "step-key": t.stepKey,
                    finished: t.finished,
                    headline: "" + t.TT("SYNO.SDS.WebStation.Application", "portal", "setup_alternative_protal_of_default_server")
                },
                on: {
                    activate: t.onActivate
                }
            }, [r("div", {
                staticClass: "ws-servicewizard-container may-have-scrollbar"
            }, [r("v-perfect-scrollbar", [r("v-form", {
                ref: "form",
                attrs: {
                    usePerfectScroll: !0,
                    "syno-id": "server-portal-form",
                    rules: t.rules
                }
            }, [r("v-radio-group", {
                staticClass: "radio-group",
                attrs: {
                    "syno-id": "server-portal-based-group",
                    name: "basedGroup"
                },
                model: {
                    value: t.fields.based,
                    callback: function(e) {
                        t.$set(t.fields, "based", e)
                    },
                    expression: "fields.based"
                }
            }, [r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "name-based",
                    name: "based",
                    value: "name"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "name_based")))]), t._v(" "), r("v-form-item", {
                ref: "itemFqdn",
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                    indent: 1,
                    prop: "fqdn"
                }
            }, [r("v-input", {
                staticClass: "input-width",
                attrs: {
                    "syno-id": "fqdn",
                    name: "fqdn",
                    disabled: "name" !== t.fields.based,
                    mask: t.Validators().FQDN_MASK
                },
                model: {
                    value: t.fields.fqdn,
                    callback: function(e) {
                        t.$set(t.fields, "fqdn", e)
                    },
                    expression: "fields.fqdn"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    indent: 1,
                    prop: "name_port"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "name_port",
                    name: "name_port",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_port", e)
                    },
                    expression: "fields.name_port"
                }
            }, [t._v("80 / 443")])], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_http_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_http",
                    name: "name_http",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_http,
                    callback: function(e) {
                        t.$set(t.fields, "name_http", e)
                    },
                    expression: "fields.name_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpPort",
                attrs: {
                    prop: "name_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_http_port",
                    name: "name_http_port",
                    "number-only": !0,
                    disabled: t.nameHttpDisabled
                },
                model: {
                    value: t.fields.name_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_http_port", e)
                    },
                    expression: "fields.name_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "name_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "name_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "name_https",
                    name: "name_https",
                    disabled: "name" !== t.fields.based
                },
                model: {
                    value: t.fields.name_https,
                    callback: function(e) {
                        t.$set(t.fields, "name_https", e)
                    },
                    expression: "fields.name_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemNameHttpsPort",
                attrs: {
                    prop: "name_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "name_https_port",
                    name: "name_https_port",
                    "number-only": !0,
                    disabled: t.nameHttpsDisabled
                },
                model: {
                    value: t.fields.name_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "name_https_port", e)
                    },
                    expression: "fields.name_https_port"
                }
            })], 1)], 1), t._v(" "), r("v-radio", {
                staticClass: "based-radio",
                attrs: {
                    "syno-id": "port-based",
                    name: "based",
                    value: "port"
                }
            }, [t._v(t._s(t.TT("SYNO.SDS.WebStation.Application", "vhost", "port_based")))]), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                    "syno-id": "port_based_http_port",
                    indent: 1
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_http"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_http",
                    name: "port_http",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_http,
                    callback: function(e) {
                        t.$set(t.fields, "port_http", e)
                    },
                    expression: "fields.port_http"
                }
            }, [t._v("HTTP")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpPort",
                attrs: {
                    prop: "port_http_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_http_port",
                    name: "port_http_port",
                    "number-only": !0,
                    disabled: t.portHttpDisabled
                },
                model: {
                    value: t.fields.port_http_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_http_port", e)
                    },
                    expression: "fields.port_http_port"
                }
            })], 1)], 1), t._v(" "), r("v-form-multiple-item", {
                attrs: {
                    "syno-id": "port_based_https_port"
                }
            }, [r("v-form-item", {
                attrs: {
                    prop: "port_https"
                }
            }, [r("v-checkbox", {
                staticClass: "port-checkbox",
                attrs: {
                    "syno-id": "port_https",
                    name: "port_https",
                    disabled: "port" !== t.fields.based
                },
                model: {
                    value: t.fields.port_https,
                    callback: function(e) {
                        t.$set(t.fields, "port_https", e)
                    },
                    expression: "fields.port_https"
                }
            }, [t._v("HTTPS")])], 1), t._v(" "), r("v-form-item", {
                ref: "itemPortHttpsPort",
                attrs: {
                    prop: "port_https_port"
                }
            }, [r("v-input", {
                staticClass: "port-input",
                attrs: {
                    "syno-id": "port_https_port",
                    name: "port_https_port",
                    "number-only": !0,
                    disabled: t.portHttpsDisabled
                },
                model: {
                    value: t.fields.port_https_port,
                    callback: function(e) {
                        t.$set(t.fields, "port_https_port", e)
                    },
                    expression: "fields.port_https_port"
                }
            })], 1)], 1)], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    label: t.TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                    prop: "hsts"
                }
            }, [r("v-checkbox", {
                attrs: {
                    "syno-id": "hsts",
                    name: "hsts"
                },
                model: {
                    value: t.fields.hsts,
                    callback: function(e) {
                        t.$set(t.fields, "hsts", e)
                    },
                    expression: "fields.hsts"
                }
            }, [t._v("HSTS")])], 1)], 1)], 1)], 1)])
        };

    function nt(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function it(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    nt(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    nt(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    rt._withStripped = !0;
    var ot = {
            name: "DefaultServerPortal",
            mixins: [c, j, L],
            props: {
                nextStepkey: String,
                stepKey: String,
                sharedData: Object
            },
            data: function() {
                var t = this,
                    e = function(e, r, n) {
                        var i = e.field.slice(0, -5);
                        if (!0 === t.fields[i]) {
                            if (r.length <= 0) return void n(new Error(t.JSLIBSTR("extlang", "fieldblank")));
                            var o = parseInt(r, 10);
                            (o <= 0 || o > 65535) && n(new Error("1 ~ 65535"))
                        }
                        n()
                    };
                return {
                    fields: {
                        based: "name",
                        fqdn: "",
                        name_port: !0,
                        name_http: !1,
                        name_https: !1,
                        name_http_port: "",
                        name_https_port: "",
                        port_http: !1,
                        port_https: !1,
                        port_http_port: "",
                        port_https_port: "",
                        hsts: !1,
                        acl: null,
                        error_page: null
                    },
                    rules: {
                        fqdn: [{
                            validator: function(e, r, n) {
                                var i = t.fields;
                                "name" !== i.based && n();
                                var o = t.fields.fqdn;
                                if (o.length <= 0 && n(new Error(t.JSLIBSTR("extlang", "fieldblank"))), t.Validators().FQDN(o) || n(new Error(t.JSLIBSTR("vtype", "bad_domain_name"))), i.name_port && (t.isFQDNConflict(o, 80) || t.isFQDNConflict(o, 443)) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated"))), i.name_http) {
                                    var a = parseInt(i.name_http_port, 10);
                                    a && t.isFQDNConflict(o, a) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                if (i.name_https) {
                                    var s = parseInt(i.name_https_port, 10);
                                    s && t.isFQDNConflict(o, s) && n(new Error(t.T("app_port_alias", "err_fqdn_duplicated")))
                                }
                                n()
                            }
                        }],
                        name_http_port: [{
                            validator: e
                        }],
                        name_https_port: [{
                            validator: e
                        }],
                        port_http_port: [{
                            validator: e
                        }],
                        port_https_port: [{
                            validator: e
                        }]
                    },
                    FQDNPortPairList: []
                }
            },
            computed: {
                nameHttpDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_http
                },
                nameHttpsDisabled: function() {
                    return "name" !== this.fields.based || !1 === this.fields.name_https
                },
                portHttpDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_http
                },
                portHttpsDisabled: function() {
                    return "port" !== this.fields.based || !1 === this.fields.port_https
                }
            },
            methods: {
                onActivate: function() {
                    var t = it(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.$emit("spinning", !0), t.next = 3, this.findListFQDNPortPair();
                                case 3:
                                    this.$emit("spinning", !1), this.$emit("enableNextButton", !0);
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                finished: function() {
                    var t = it(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.prev = 0, t.next = 3, this.$refs.form.validate();
                                case 3:
                                    if (t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return this.$emit("display-error", this.T("common", "forminvalid")), t.abrupt("return", !1);
                                case 7:
                                    t.next = 13;
                                    break;
                                case 9:
                                    return t.prev = 9, t.t0 = t.catch(0), this.$emit("display-error", t.t0), t.abrupt("return", !1);
                                case 13:
                                    return t.next = 15, this.sendSetRequest();
                                case 15:
                                    if (!t.sent) {
                                        t.next = 20;
                                        break
                                    }
                                    this.$emit("close"), t.next = 21;
                                    break;
                                case 20:
                                    return t.abrupt("return", !1);
                                case 21:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [0, 9]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                sendSetRequest: function() {
                    var t = it(regeneratorRuntime.mark((function t() {
                        var e;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.$emit("spinning", !0), e = !1, t.prev = 2, t.next = 5, synowebapi.promises.request({
                                        api: "SYNO.WebStation.WebService.Portal",
                                        version: 1,
                                        method: "create",
                                        params: {
                                            portal: this.prepareSetParams()
                                        }
                                    });
                                case 5:
                                    t.sent, e = !0, t.next = 13;
                                    break;
                                case 9:
                                    t.prev = 9, t.t0 = t.catch(2), this.errorHandler(t.t0.code, t.t0.errors), e = !1;
                                case 13:
                                    return t.prev = 13, this.$emit("spinning", !1), t.abrupt("return", e);
                                case 17:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [2, 9, 13, 17]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                prepareSetParams: function() {
                    var t = this.fields,
                        e = {
                            http_port: [],
                            https_port: []
                        };
                    return "name" === t.based ? (e.fqdn = t.fqdn, t.name_port && (e.http_port.push(80), e.https_port.push(443)), t.name_http && e.http_port.push(parseInt(t.name_http_port, 10)), t.name_https && e.https_port.push(parseInt(t.name_https_port, 10))) : (t.port_http && e.http_port.push(parseInt(t.port_http_port, 10)), t.port_https && e.https_port.push(parseInt(t.port_https_port, 10))), e.hsts = t.hsts, e.acl = t.acl, e.error_page = t.error_page, e.enable = !0, e.type = "server", e.service = this.sharedData.serviceId, e
                },
                findListFQDNPortPair: function() {
                    var t = it(regeneratorRuntime.mark((function t() {
                        var e, r, n, i;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return n = function(t, e) {
                                        e.entries.forEach((function(e) {
                                            e.frontend && e.frontend.fqdn && t.FQDNPortPairList.push({
                                                fqdn: e.frontend.fqdn.toLowerCase(),
                                                port: e.frontend.port
                                            })
                                        }))
                                    }, r = function(t, e) {
                                        e.portal.forEach((function(e) {
                                            e.fqdn && (t.FQDNPortPairList.push({
                                                fqdn: e.fqdn.toLowerCase(),
                                                port: 80
                                            }), t.FQDNPortPairList.push({
                                                fqdn: e.fqdn.toLowerCase(),
                                                port: 443
                                            }))
                                        }))
                                    }, e = function(t, e) {
                                        e.fqdn && (t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 80
                                        }), t.FQDNPortPairList.push({
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 443
                                        }))
                                    }, this.$emit("spinning", !0), t.prev = 4, t.next = 7, this.sendFQDNListRequest();
                                case 7:
                                    i = t.sent, e(this, i.result[0].data), r(this, i.result[1].data), n(this, i.result[2].data), t.next = 16;
                                    break;
                                case 13:
                                    t.prev = 13, t.t0 = t.catch(4), this.$emit("display-error", t.t0.code);
                                case 16:
                                    return t.prev = 16, this.$emit("spinning", !1), t.finish(16);
                                case 19:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [4, 13, 16, 19]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                sendFQDNListRequest: function() {
                    var t = it(regeneratorRuntime.mark((function t() {
                        var e, r;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = [{
                                        api: "SYNO.Core.Web.DSM",
                                        method: "get",
                                        version: 2
                                    }, {
                                        api: "SYNO.Core.AppPortal",
                                        method: "list",
                                        version: 2
                                    }, {
                                        api: "SYNO.Core.AppPortal.ReverseProxy",
                                        method: "list",
                                        version: 1
                                    }], t.prev = 4, t.next = 7, synowebapi.promises.request({
                                        compound: {
                                            stopwhenerror: !0,
                                            params: e
                                        }
                                    });
                                case 7:
                                    return r = t.sent, t.abrupt("return", r);
                                case 11:
                                    throw t.prev = 11, t.t0 = t.catch(4), t.t0;
                                case 14:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [4, 11]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                isFQDNConflict: function(t, e) {
                    t = t.toLowerCase();
                    for (var r = 0; r < this.FQDNPortPairList.length; r++) {
                        var n = this.FQDNPortPairList[r];
                        if (n.fqdn === t && n.port === e) return !0
                    }
                    return !1
                }
            }
        },
        at = (r(79), d(ot, rt, [], !1, null, "779d1616", null));
    at.options.__file = "src/components/serviceWizard/StepDefaultServerPortal.vue";
    var st = d({
        mixins: [c],
        components: {
            "step-select-portal": P,
            "step-select-service": R,
            "step-virtualhost": V,
            "step-server-portal": et,
            "step-default-server-portal": at.exports
        },
        data: function() {
            return {
                buttonsGroup: {},
                sharedData: {
                    serviceId: "",
                    serviceName: "",
                    serviceList: [],
                    localPackageMap: {},
                    serverPackageMap: {},
                    webServiceMap: {}
                },
                wizardStyle: {
                    height: "560px"
                },
                stepCtStyle: {
                    height: "512px"
                }
            }
        },
        methods: {
            onEnableNextButton: function(t) {
                var e = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                this.buttonsGroup = {
                    next: {
                        text: e ? _T("common", "create") : _T("common", "next"),
                        disabled: !t
                    }
                }
            },
            displayError: function(t) {
                this.$emit("show-message-box", this.$root.$appWindow.title, t)
            }
        }
    }, s, [], !1, null, null, null);

    function ct() {
        for (var t = arguments.length, e = new Array(t), r = 0; r < t; r++) e[r] = arguments[r];
        return e.join(":")
    }
    st.options.__file = "src/components/serviceWizard/ServiceWizard.vue";
    var pt = {
            created: function() {
                this._T = window._T || ct, this._TT = window._TT || ct
            }
        },
        lt = d({
            mixins: [pt],
            components: {
                ServiceWizard: st.exports
            },
            methods: {
                onStepScrolled: function(t) {
                    this.$refs.window.onStepScrolled(t)
                },
                onSpinning: function(t) {
                    t ? this.$refs.window.setStatusBusy() : this.$refs.window.clearStatusBusy()
                },
                onMessageBoxShow: function(t, e) {
                    this.$refs.window.getMsgBox().alert(t, e)
                },
                onClose: function() {
                    this.$refs.window.close()
                }
            }
        }, a, [], !1, null, null, null);
    lt.options.__file = "src/wizards/ServiceWizardWindow.vue";
    var ut = lt.exports,
        dt = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("div", {
                staticClass: "webstation-panel"
            }, [r("div", {
                staticClass: "action-buttons-bar"
            }, [r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "webstation-error-page-add-button",
                    type: "dropdown"
                },
                scopedSlots: t._u([{
                    key: "dropdown",
                    fn: function() {
                        return [r("v-menu", {
                            attrs: {
                                "syno-id": "webstation-error-page-add-menu"
                            }
                        }, [r("v-menu-item", {
                            attrs: {
                                "syno-id": "webstation-error-page-add-menu-item-profile",
                                title: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "create_profile_title_case")
                            },
                            on: {
                                click: t.openProfileModal
                            }
                        }), t._v(" "), r("v-menu-item", {
                            attrs: {
                                "syno-id": "webstation-error-page-add-menu-item-import",
                                title: t._T("helptoc", "user_import")
                            },
                            on: {
                                click: t.openImportProfileDialog
                            }
                        })], 1)]
                    },
                    proxy: !0
                }])
            }, [t._v("\n      " + t._s(t._T("common", "create")) + "\n      ")]), t._v(" "), r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "webstation-error-page-edit-button",
                    disabled: !t.isEditable
                },
                on: {
                    click: t.openEditProfileModal
                }
            }, [t._v("\n      " + t._s(t._T("common", "alt_edit")) + "\n    ")]), t._v(" "), r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "webstation-error-page-delete-button",
                    disabled: !t.isDeletable
                },
                on: {
                    click: function(e) {
                        return t.deleteProfiles()
                    }
                }
            }, [t._v("\n      " + t._s(t._T("common", "delete")) + "\n    ")]), t._v(" "), r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "webstation-error-page-export-button",
                    disabled: !t.isExportable
                },
                on: {
                    click: function(e) {
                        return t.exportProfile()
                    }
                }
            }, [t._v("\n      " + t._s(t._T("delegation", "export")) + "\n    ")])], 1), t._v(" "), r("v-data-table", {
                ref: "dataTable",
                staticClass: "webstation-panel__data-table",
                attrs: {
                    "syno-id": "webstation-error-page-data-table",
                    multipleSelected: "",
                    "enable-hd-menu": !1,
                    groupTable: "",
                    groupInfo: t.groupInfo,
                    columns: t.columns,
                    data: t.loadData
                },
                on: {
                    rowsclick: function(e) {
                        t.selectedProfiles = e
                    },
                    rowdbclick: t.openEditProfileModalByDbClick
                }
            })], 1)
        };
    dt._withStripped = !0;
    var ft = r(32),
        ht = r.n(ft);

    function vt() {
        return "\n    tmp-\n    ".concat(Date.now().toString(36), "-\n    ").concat(Math.random().toString(36).substr(2, 9), "\n  ").replace(/\s/g, "")
    }
    var mt = {
            STATIC: "static",
            RELATIVE_URL: "relative_url",
            REDIRECT_302: "redirect_302"
        },
        _t = function() {
            return [{
                label: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "insert_static"),
                value: mt.STATIC
            }, {
                label: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "execute_url"),
                value: mt.RELATIVE_URL
            }, {
                label: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "redirect_302"),
                value: mt.REDIRECT_302
            }]
        };

    function bt(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                gt(t, e, r[e])
            }))
        }
        return t
    }

    function gt(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function St() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = (t.pages || []).find((function(t) {
                return "default" === t.code
            })),
            r = (t.pages || []).filter((function(t) {
                return t !== e
            }));
        return {
            id: t.id,
            desc: t.desc || "",
            defaultPage: wt(e || {
                code: "default"
            }),
            otherPages: r.map((function(t) {
                return wt(t)
            }))
        }
    }

    function wt() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            id: t.id || vt(),
            code: t.code || "",
            desc: t.desc || "",
            type: t.type || mt.STATIC,
            absolute_url: t.absolute_url || "",
            relative_url: t.relative_url || "",
            file: t.file || "",
            modified_time: t.modified_time
        }
    }

    function yt() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            r = {},
            n = {};
        e.needsId && t.id && (r.id = t.id), e.needsRemovePageIds && (r.remove_pages = t.remove_pages), r.desc = "default" === t.id ? "default" : t.desc, r.pages = t.otherPages.map((function(t) {
            return o(t)
        }));
        var i = o(t.defaultPage);
        return i && r.pages.unshift(i), bt({
            profile: JSON.stringify(r)
        }, n);

        function o() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (!ht()(t)) {
                var e = {};
                return e.type = t.type, e.code = t.code, t.id && !t.id.startsWith("tmp") && (e.id = t.id), t.modified_time && (e.modified_time = t.modified_time), t.type === mt.RELATIVE_URL && (e.relative_url = t.relative_url), t.type === mt.REDIRECT_302 && (e.absolute_url = t.absolute_url), t.type === mt.STATIC && (e.file = null, t.file instanceof File && (e.desc = t.file.name, n[t.id] = t.file, e.file = t.id)), e
            }
        }
    }

    function xt() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return yt(t)
    }

    function Pt() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
            r = {
                id: t.id,
                desc: t.desc,
                defaultPage: o(t.defaultPage, e.defaultPage) ? t.defaultPage : void 0,
                otherPages: i(t.otherPages, e.otherPages),
                remove_pages: n(t.otherPages, e.otherPages)
            };
        return yt(r, {
            needsId: !0,
            needsRemovePageIds: !0
        });

        function n() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [],
                r = e.map((function(t) {
                    return t.id
                })),
                n = t.map((function(t) {
                    return t.id
                }));
            return r.filter((function(t) {
                return !n.find((function(e) {
                    return e === t
                }))
            }))
        }

        function i() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
                e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
            return t.filter((function(t) {
                var r = e.find((function(e) {
                    return e.id === t.id
                }));
                return !r || o(t, r)
            }))
        }

        function o() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            return t.code !== e.code || (t.type === mt.REDIRECT_302 && t.absolute_url !== e.absolute_url || (t.type === mt.RELATIVE_URL && t.relative_url !== e.relative_url || t.type === mt.STATIC && t.file !== e.file))
        }
    }

    function Tt(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function kt(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    Tt(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    Tt(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Dt() {
        return Ot.apply(this, arguments)
    }

    function Ot() {
        return (Ot = kt(regeneratorRuntime.mark((function t() {
            var e;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "list",
                            version: 1
                        });
                    case 2:
                        return e = t.sent, t.abrupt("return", e.profiles.map((function(t) {
                            return St(t)
                        })));
                    case 4:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function Nt() {
        return At.apply(this, arguments)
    }

    function At() {
        return (At = kt(regeneratorRuntime.mark((function t() {
            var e, r, n = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, r = xt(e), t.next = 4, synowebapi.promises.request({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "create",
                            version: 1,
                            formData: r
                        });
                    case 4:
                        return t.abrupt("return", t.sent);
                    case 5:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function $t() {
        return Et.apply(this, arguments)
    }

    function Et() {
        return (Et = kt(regeneratorRuntime.mark((function t() {
            var e, r, n, i = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = i.length > 0 && void 0 !== i[0] ? i[0] : {}, r = i.length > 1 && void 0 !== i[1] ? i[1] : {}, n = Pt(e, r), t.next = 5, synowebapi.promises.request({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "update",
                            version: 1,
                            formData: n
                        });
                    case 5:
                        return t.abrupt("return", t.sent);
                    case 6:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function Ct() {
        return Wt.apply(this, arguments)
    }

    function Wt() {
        return (Wt = kt(regeneratorRuntime.mark((function t() {
            var e, r, n = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : [], r = e.map((function(t) {
                            return t.id
                        })), t.next = 4, synowebapi.promises.request({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "remove",
                            version: 1,
                            params: {
                                ids: r
                            }
                        });
                    case 4:
                        return t.abrupt("return", t.sent);
                    case 5:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function Rt() {
        return It.apply(this, arguments)
    }

    function It() {
        return (It = kt(regeneratorRuntime.mark((function t() {
            var e, r = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = r.length > 0 && void 0 !== r[0] ? r[0] : {}, t.next = 3, jt(e.id);
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function jt() {
        return Lt.apply(this, arguments)
    }

    function Lt() {
        return (Lt = kt(regeneratorRuntime.mark((function t() {
            var e, r = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = r.length > 0 && void 0 !== r[0] ? r[0] : "", t.next = 3, synowebapi.promises.download({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "export",
                            version: 1,
                            params: {
                                id: e
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function Yt(t) {
        return zt.apply(this, arguments)
    }

    function zt() {
        return (zt = kt(regeneratorRuntime.mark((function t(e) {
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.WebStation.ErrorPage",
                            method: "import",
                            version: 1,
                            formData: {
                                file: e
                            }
                        });
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }

    function Mt(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function Ft(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    Mt(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    Mt(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    var qt, Ht, Bt, Ut = d({
        mixins: [pt],
        data: function() {
            return {
                selectedProfiles: [],
                columns: [{
                    title: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "profile_name_title_case"),
                    field: "desc"
                }],
                groupInfo: {
                    category: "preserve"
                }
            }
        },
        computed: {
            singleSelectedProfile: function() {
                return 1 === this.selectedProfiles.length && this.selectedProfiles[0] || null
            },
            singleSelectedData: function() {
                return this.singleSelectedProfile && this.singleSelectedProfile.row || null
            },
            isEditable: function() {
                return !!this.singleSelectedData
            },
            isDeletable: function() {
                return !!this.singleSelectedData && "default" !== this.singleSelectedData.id
            },
            isExportable: function() {
                return !!this.singleSelectedData
            }
        },
        methods: {
            loadData: (Bt = Ft(regeneratorRuntime.mark((function t() {
                var e;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.next = 2, Dt();
                        case 2:
                            return (e = t.sent).forEach((function(t) {
                                "default" === t.id ? (t.preserve = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_settings"), t.desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile")) : t.preserve = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "custom_settings")
                            })), t.abrupt("return", {
                                items: Object.values(e)
                            });
                        case 5:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return Bt.apply(this, arguments)
            }),
            openProfileModal: function() {
                var t = this;
                new SYNO.SDS.WebStation.Dialog.CreateProfile({
                    owner: this.$root._$extPanel.findWindow(),
                    listeners: {
                        close: function() {
                            return t.$refs.dataTable.refresh()
                        }
                    }
                }).open()
            },
            openImportProfileDialog: function() {
                var t = this;
                new SYNO.SDS.WebStation.Dialog.ImportProfile({
                    owner: this.$root._$extPanel.findWindow(),
                    listeners: {
                        close: function() {
                            return t.$refs.dataTable.refresh()
                        }
                    }
                }).open()
            },
            openEditProfileModalByDbClick: function(t) {
                t.row;
                var e = t.category,
                    r = t.index;
                this.singleSelectedProfile && e === this.singleSelectedProfile.category && r === this.singleSelectedProfile.index && this.openEditProfileModal()
            },
            openEditProfileModal: function() {
                var t = this;
                this.isEditable && new SYNO.SDS.WebStation.Dialog.EditProfile({
                    owner: this.$root._$extPanel.findWindow(),
                    data: {
                        profile: this.singleSelectedData
                    },
                    listeners: {
                        close: function() {
                            return t.$refs.dataTable.refresh()
                        }
                    }
                }).open()
            },
            deleteProfiles: (Ht = Ft(regeneratorRuntime.mark((function t() {
                var e, r, n = this;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (this.isDeletable) {
                                t.next = 2;
                                break
                            }
                            return t.abrupt("return");
                        case 2:
                            return e = function() {
                                return new Promise((function(t, e) {
                                    n.$root._$extPanel.findAppWindow().getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), t)
                                }))
                            }, t.next = 5, e();
                        case 5:
                            if ("yes" === t.sent) {
                                t.next = 8;
                                break
                            }
                            return t.abrupt("return");
                        case 8:
                            return r = this.selectedProfiles.map((function(t) {
                                return t.row
                            })), t.next = 11, Ct(r);
                        case 11:
                            this.$refs.dataTable.refresh();
                        case 12:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return Ht.apply(this, arguments)
            }),
            exportProfile: (qt = Ft(regeneratorRuntime.mark((function t() {
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            if (this.isExportable) {
                                t.next = 2;
                                break
                            }
                            return t.abrupt("return");
                        case 2:
                            return t.next = 4, Rt(this.singleSelectedData);
                        case 4:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            }))), function() {
                return qt.apply(this, arguments)
            })
        }
    }, dt, [], !1, null, null, null);
    Ut.options.__file = "src/pages/CustomErrorPage.vue";
    var Vt = Ut.exports,
        Qt = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("div", {
                staticClass: "webstation-panel service-portal-page"
            }, [r("div", {
                staticClass: "action-buttons-bar"
            }, [r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "service-portal-add-btn",
                    type: "dropdown"
                },
                scopedSlots: t._u([{
                    key: "dropdown",
                    fn: function() {
                        return [r("v-menu", {
                            attrs: {
                                "syno-id": "service-portal-add-menu",
                                width: "auto",
                                closeOnSelect: !0
                            }
                        }, [r("v-menu-item", {
                            attrs: {
                                "syno-id": "service-portal-add-menu-item-add-service"
                            },
                            on: {
                                click: t.openServiceWizard
                            }
                        }, [t._v("\n            " + t._s(t._TT("SYNO.SDS.WebStation.Application", "portal", "create_service_portal")) + "\n          ")]), t._v(" "), r("v-menu-item", {
                            attrs: {
                                "syno-id": "service-portal-add-menu-item-add-alias"
                            },
                            on: {
                                click: t.openCreateAliasModal
                            }
                        }, [t._v("\n            " + t._s(t._TT("SYNO.SDS.WebStation.Application", "portal", "create_alias_portal")) + "\n          ")])], 1)]
                    },
                    proxy: !0
                }])
            }, [t._v("\n      " + t._s(t._T("common", "create")) + "\n      ")]), t._v(" "), r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "service-portal-edit-btn",
                    disabled: !t.isEditable
                },
                on: {
                    click: t.openEditModal
                }
            }, [t._v("\n      " + t._s(t._T("common", "alt_edit")) + "\n    ")]), t._v(" "), r("v-button", {
                staticClass: "action-buttons-bar__item",
                attrs: {
                    "syno-id": "service-portal-action-btn",
                    disabled: !t.isActionEnabled,
                    type: "dropdown"
                },
                scopedSlots: t._u([{
                    key: "dropdown",
                    fn: function() {
                        return [r("v-menu", {
                            attrs: {
                                "syno-id": "service-portal-action-menu",
                                width: "auto"
                            }
                        }, [r("v-menu-item", {
                            attrs: {
                                "syno-id": "service-portal-action-menu-item-enable",
                                disabled: !t.isAvailable
                            },
                            on: {
                                click: t.activateService
                            }
                        }, [t._v("\n            " + t._s(t._TT("SYNO.SDS.WebStation.Application", "common", "enable")) + "\n          ")]), t._v(" "), r("v-menu-item", {
                            attrs: {
                                "syno-id": "service-portal-action-menu-item-disable",
                                disabled: !t.isAvailable
                            },
                            on: {
                                click: t.deactivateService
                            }
                        }, [t._v("\n            " + t._s(t._TT("SYNO.SDS.WebStation.Application", "common", "disable")) + "\n          ")]), t._v(" "), r("v-menu-item", {
                            attrs: {
                                "syno-id": "service-portal-action-menu-item-delete",
                                disabled: !t.isDeleteable
                            },
                            on: {
                                click: t.deleteServices
                            }
                        }, [t._v("\n            " + t._s(t._T("common", "delete")) + "\n          ")])], 1)]
                    },
                    proxy: !0
                }])
            }, [t._v("\n      " + t._s(t._T("common", "action")) + "\n      ")])], 1), t._v(" "), r("v-data-table", {
                ref: "dataTable",
                staticClass: "webstation-panel__data-table",
                attrs: {
                    groupTable: "",
                    multipleSelected: "",
                    "syno-id": "service-portal-data-table",
                    "enable-hd-menu": !1,
                    groupInfo: t.groupInfo,
                    columns: t.columns,
                    "current-data": t.data
                },
                on: {
                    rowsclick: t.updateSelectedRows,
                    rowdbclick: t.openEditModalByDbClick,
                    dataloaded: t.clearSelectedRows,
                    refresh: t.loadData
                },
                scopedSlots: t._u([{
                    key: "status",
                    fn: function(e) {
                        var n = e.data;
                        return [r("span", {
                            class: n.class
                        }, [t._v(t._s(n.message))])]
                    }
                }, {
                    key: "service",
                    fn: function(e) {
                        var n = e.data;
                        return ["string" == typeof n ? r("span", [t._v(t._s(n))]) : r("span", {
                            class: n.class
                        }, [t._v(t._s(n.message))])]
                    }
                }, {
                    key: "primaryLink",
                    fn: function(t) {
                        var e = t.data;
                        return [r("a", {
                            staticClass: "syno-webstation-management primary-link",
                            attrs: {
                                target: "_blank",
                                href: e
                            }
                        })]
                    }
                }])
            })], 1)
        };

    function Gt(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }
    Qt._withStripped = !0;
    var Jt = "ENABLE",
        Kt = "SERVICE_DISABLE",
        Xt = "DISABLE",
        Zt = "ERROR",
        te = function() {
            var t;
            return Gt(t = {}, Jt, {
                class: "green-status",
                message: _T("helpbrowser", "font_normal")
            }), Gt(t, Xt, {
                class: "syno-webstation-grey-status",
                message: _T("common", "disabled")
            }), Gt(t, Kt, {
                class: "red-status",
                message: _TT("SYNO.SDS.WebStation.Application", "common", "service_disable")
            }), Gt(t, Zt, {
                class: "red-status",
                message: _T("common", "status_abnormal")
            }), t
        },
        ee = "DEFAULT_SERVER",
        re = "VHOST",
        ne = "DEFAULT_SERVER_PORTAL",
        ie = "PORTAL",
        oe = "ALIAS";

    function ae(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                se(t, e, r[e])
            }))
        }
        return t
    }

    function se(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function ce() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        return t.map((function(t) {
            return ae({
                preserve: !1
            }, t)
        })).map((function(t) {
            return ae({
                _type: re
            }, t)
        })).map((function(t) {
            return {
                preserve: e(t),
                status: r(t),
                service: {
                    class: "",
                    message: _TT("SYNO.SDS.WebStation.Application", "title", "vhost")
                },
                fqdn: t.fqdn || "*",
                port: n(t),
                alias: "-",
                primaryLink: i(t),
                detail: o(t),
                _originalData: t
            }
        }));

        function e() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return t.preserve ? _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_preserve_portal") : _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_non_preserve_portal")
        }

        function r() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                e = te(),
                r = Xt;
            return t.enable && (r = Jt), 999 !== t.error && (r = Zt), e[r]
        }

        function n() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return [t.port.http, t.port.https].flat().join(" / ")
        }

        function i() {
            var t, e, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            r.port.http.length > 0 && (t = "http", e = r.port.http.some((function(t) {
                return 80 === t
            })) ? 80 : r.port.http[0]), r.port.https.length > 0 && (t = "https", e = r.port.https.some((function(t) {
                return 443 === t
            })) ? 443 : r.port.https[0]);
            var n = r.fqdn || window.location.hostname;
            return "".concat(t, "://").concat(n, ":").concat(e)
        }

        function o() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            if (!t.root) return "";
            var e = _TT("SYNO.SDS.WebStation.Application", "vhost", "docroot");
            return "".concat(e, ": ").concat(t.root)
        }
    }

    function pe(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                le(t, e, r[e])
            }))
        }
        return t
    }

    function le(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function ue() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        return t.filter((function(t) {
            return "server" === t.type
        })).map((function(t) {
            var r = e.find((function(e) {
                return e.id === t.service
            })) || {};
            return pe({
                _type: "WebStation" === r.category && "default_server" === r.service ? ne : ie
            }, t)
        })).map((function(t) {
            var r = e.find((function(e) {
                return e.id === t.service
            }));
            return {
                preserve: fe(t),
                status: he(t, r),
                service: ve(t, r),
                fqdn: t.fqdn || "*",
                port: me(t),
                alias: "-",
                primaryLink: _e(t),
                detail: "",
                _originalData: t
            }
        }))
    }

    function de() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        return t.filter((function(t) {
            return "alias" === t.type
        })).map((function(t) {
            return pe({
                _type: oe
            }, t)
        })).map((function(t) {
            var r = e.find((function(e) {
                return e.id === t.service
            }));
            return {
                preserve: fe(t),
                status: he(t, r),
                service: ve(t, r),
                fqdn: t.fqdn || "*",
                port: "-",
                alias: t.alias,
                primaryLink: "https://".concat(window.location.hostname, "/").concat(t.alias),
                detail: "",
                _originalData: t
            }
        }))
    }

    function fe() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return t.preserve ? _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_preserve_portal") : _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_non_preserve_portal")
    }

    function he() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null,
            r = te();
        if (!t.enable) return r[Xt];
        var n = Xt;
        return e && (n = Jt), e && !e.enable && (n = Kt), e || (n = Zt), r[n]
    }

    function ve() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
        if (!t.service) return "";
        if (!e) return {
            class: "status-not-avaiable",
            message: _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available")
        };
        if ("WebStation" === e.category && "default_server" === e.service) return _TT("SYNO.SDS.WebStation.Application", "portal", "alternative_host");
        var r = e.display_name_i18n,
            n = e.display_name;
        return SYNO.SDS.WebStation.Util.geti18nString(r, n)
    }

    function me() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return [t.http_port, t.https_port].flat().join(" / ")
    }

    function _e() {
        var t, e, r = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        r.http_port.length > 0 && (t = "http", e = r.http_port.some((function(t) {
            return 80 === t
        })) ? 80 : r.http_port[0]), r.https_port.length > 0 && (t = "https", e = r.https_port.some((function(t) {
            return 443 === t
        })) ? 443 : r.https_port[0]);
        var n = r.fqdn || window.location.hostname;
        return "".concat(t, "://").concat(n, ":").concat(e)
    }

    function be(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function ge(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                Se(t, e, r[e])
            }))
        }
        return t
    }

    function Se(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function we() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return ge({
            id: void 0,
            name: "",
            pages: [ye({
                code: "default"
            })]
        }, t)
    }

    function ye() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return ge({
            code: "",
            description: "",
            type: mt.STATIC,
            absolute_url: void 0,
            relative_url: void 0,
            file: void 0,
            modified_time: void 0
        }, t)
    }
    var xe = {
            ADD_PROFILE: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                t.profiles.push(we(e))
            },
            UPDATE_NEW_PROFILE: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                t.newProfile = we(ge({}, t.newProfile, e))
            },
            ADD_NEW_PROFILE_EMPTY_PAGE: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                return t.newProfile.pages.push(ye(e))
            }
        },
        Pe = {
            state: {
                newProfile: we(),
                profiles: []
            },
            getters: {
                newProfile: function(t) {
                    return t.newProfile
                },
                profiles: function(t) {
                    return t.profiles
                },
                getCustomProfilesById: function(t) {
                    return function(e) {
                        return e.profiles.find((function(e) {
                            return e.id === t
                        }))
                    }
                }
            },
            mutations: xe,
            actions: {
                addCustomProfile: function(t) {
                    (0, t.commit)("ADD_PROFILE", t.state.newProfile)
                },
                fetchProfiles: function() {
                    var t, e = (t = regeneratorRuntime.mark((function t(e) {
                        var r, n, i;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return r = e.commit, t.next = 3, synowebapi.promises.request({
                                        api: "SYNO.WebStation.ErrorPage",
                                        method: "list",
                                        version: 1
                                    });
                                case 3:
                                    return n = t.sent, (i = n.profiles.map((function(t) {
                                        return we({
                                            id: t.id,
                                            name: t.desc,
                                            pages: t.pages.map((function(t) {
                                                return ye(t)
                                            }))
                                        })
                                    }))).forEach((function(t) {
                                        return r("ADD_PROFILE", t)
                                    })), t.abrupt("return", i);
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })), function() {
                        var e = this,
                            r = arguments;
                        return new Promise((function(n, i) {
                            var o = t.apply(e, r);

                            function a(t) {
                                be(o, n, i, a, s, "next", t)
                            }

                            function s(t) {
                                be(o, n, i, a, s, "throw", t)
                            }
                            a(void 0)
                        }))
                    });
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                updateNewProfile: function(t) {
                    var e = t.commit,
                        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    e("UPDATE_NEW_PROFILE", r)
                },
                addNewProfileEmptyPage: function(t) {
                    var e = t.commit,
                        r = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
                    e("ADD_NEW_PROFILE_EMPTY_PAGE", r)
                }
            }
        };

    function Te() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            preserve: _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_preserve_portal"),
            status: e(),
            service: _TT("SYNO.SDS.WebStation.Application", "portal", "default_server"),
            fqdn: "*",
            port: "80 / 443",
            alias: "-",
            primaryLink: "https://".concat(window.location.hostname, "/"),
            detail: "",
            _originalData: {
                _type: ee,
                preserve: !0
            }
        };

        function e() {
            var e = te(),
                r = null === t.php || t.php_profiles.profiles.some((function(e) {
                    return e.uuid === t.php
                })),
                n = -1 !== t.available_server_backend.indexOf(t.backend),
                i = Zt;
            return r && n && (i = Jt), e[i]
        }
    }

    function ke(t) {
        return function(t) {
            if (Array.isArray(t)) {
                for (var e = 0, r = new Array(t.length); e < t.length; e++) r[e] = t[e];
                return r
            }
        }(t) || function(t) {
            if (Symbol.iterator in Object(t) || "[object Arguments]" === Object.prototype.toString.call(t)) return Array.from(t)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        }()
    }

    function De(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function Oe(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    De(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    De(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Ne(t) {
        for (var e = 1; e < arguments.length; e++) {
            var r = null != arguments[e] ? Object(arguments[e]) : {},
                n = Object.keys(r);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter((function(t) {
                return Object.getOwnPropertyDescriptor(r, t).enumerable
            })))), n.forEach((function(e) {
                Ae(t, e, r[e])
            }))
        }
        return t
    }

    function Ae(t, e, r) {
        return e in t ? Object.defineProperty(t, e, {
            value: r,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = r, t
    }

    function $e() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            api: "SYNO.WebStation.HTTP.VHost",
            method: "update",
            version: 1,
            params: {
                host: Ne({}, t, {
                    version: 2
                })
            }
        }
    }

    function Ee() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return {
            api: "SYNO.WebStation.WebService.Portal",
            method: "update",
            version: 1,
            params: {
                portal: t
            }
        }
    }

    function Ce() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        if (0 !== t.length) return {
            api: "SYNO.WebStation.HTTP.VHost",
            method: "delete",
            version: 1,
            params: {
                uuids: t
            }
        }
    }

    function We() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
        if (0 !== t.length) return {
            api: "SYNO.WebStation.WebService.Portal",
            method: "remove",
            version: 1,
            params: {
                ids: t
            }
        }
    }

    function Re() {
        return Ie.apply(this, arguments)
    }

    function Ie() {
        return (Ie = Oe(regeneratorRuntime.mark((function t() {
            var e, r, n, i, o, a, s = arguments;
            return regeneratorRuntime.wrap((function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = s.length > 0 && void 0 !== s[0] ? s[0] : [], t.next = 3, synowebapi.promises.request({
                            compound: {
                                stopwhenerror: !0,
                                params: e
                            }
                        });
                    case 3:
                        if (r = t.sent, n = r.has_fail, i = r.result, !n) {
                            t.next = 11;
                            break
                        }
                        throw o = i.filter((function(t) {
                            return !t.sucess
                        })), a = o.map((function(t) {
                            return "".concat(t.api, ":").concat(t.error.code)
                        })).join(", "), SYNO.Debug.error("Synowebapi request has fail: ".concat(a)), o;
                    case 11:
                        return t.abrupt("return", i);
                    case 13:
                    case "end":
                        return t.stop()
                }
            }), t, this)
        })))).apply(this, arguments)
    }
    var je, Le, Ye, ze, Me = {
            mixins: [pt],
            computed: {
                allSelectedData: function() {
                    return this.selectedRows.map((function(t) {
                        return t.row._originalData
                    }))
                },
                allSelectedDataInfo: function() {
                    return this.selectedRows.map((function(t) {
                        return "".concat(t.category, ":").concat(t.index)
                    }))
                },
                singleSelectedRowData: function() {
                    return 1 === this.selectedRows.length && this.selectedRows[0] || null
                },
                singleSelectedData: function() {
                    return this.singleSelectedRowData && this.singleSelectedRowData.row._originalData || null
                },
                isEditable: function() {
                    return !!this.singleSelectedData
                },
                isActionEnabled: function() {
                    return this.allSelectedData.length > 0 && void 0 === this.allSelectedData.find((function(t) {
                        return t.preserve && "DEFAULT_SERVER" === t._type
                    }))
                },
                isDeleteable: function() {
                    return this.allSelectedData.every((function(t) {
                        return !t.preserve
                    }))
                },
                isAvailable: function() {
                    return this.allSelectedData.every((function(t) {
                        return "DEFAULT_SERVER_PORTAL" !== t._type
                    }))
                }
            },
            data: function() {
                return {
                    data: [],
                    isLoading: !1,
                    isServiceWizardOpened: !1,
                    selectedRows: [],
                    columns: [{
                        title: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                        field: "status",
                        tooltip: function(t) {
                            return t.status.message
                        }
                    }, {
                        title: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                        field: "service",
                        tooltip: function(t) {
                            return "string" == typeof t.service ? t.service : t.service.message
                        }
                    }, {
                        title: _T("service", "service_host_name"),
                        field: "fqdn",
                        tooltip: !0
                    }, {
                        title: _T("service", "service_vhost_port"),
                        field: "port",
                        tooltip: !0
                    }, {
                        title: _T("app_port_alias", "desc_alias"),
                        field: "alias",
                        tooltip: !0
                    }, {
                        title: _TT("SYNO.SDS.WebStation.Application", "common", "primary_link"),
                        field: "primaryLink"
                    }, {
                        title: _TT("SYNO.SDS.WebStation.Application", "common", "details"),
                        field: "detail",
                        tooltip: !0
                    }],
                    groupInfo: {
                        category: "preserve"
                    }
                }
            },
            mounted: function() {
                this.$appWindow = this.$root._$extPanel.findAppWindow()
            },
            methods: {
                loadData: function() {
                    var t = Oe(regeneratorRuntime.mark((function t() {
                        var e, r, n, i, o, a, s, c, p;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = {
                                        api: "SYNO.WebStation.Status",
                                        method: "get",
                                        version: 1
                                    }, r = {
                                        api: "SYNO.WebStation.WebService.Service",
                                        method: "list",
                                        version: 1,
                                        params: {
                                            all: !0
                                        }
                                    }, n = {
                                        api: "SYNO.WebStation.WebService.Portal",
                                        method: "list",
                                        version: 1
                                    }, i = {
                                        api: "SYNO.WebStation.HTTP.VHost",
                                        method: "list",
                                        version: 1
                                    }, t.next = 6, Re([e, r, n, i]);
                                case 6:
                                    return o = t.sent, a = o.find((function(t) {
                                        return "SYNO.WebStation.Status" === t.api
                                    })).data, s = o.find((function(t) {
                                        return "SYNO.WebStation.WebService.Service" === t.api
                                    })).data.services, c = o.find((function(t) {
                                        return "SYNO.WebStation.WebService.Portal" === t.api
                                    })).data.portals, p = o.find((function(t) {
                                        return "SYNO.WebStation.HTTP.VHost" === t.api
                                    })).data.hosts, this.data = [Te(a)].concat(ke(ue(c, s)), ke(de(c, s)), ke(ce(p))), t.abrupt("return");
                                case 13:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                openEditModalByDbClick: function(t) {
                    t.row;
                    var e = t.category,
                        r = t.index;
                    this.singleSelectedRowData && e === this.singleSelectedRowData.category && r === this.singleSelectedRowData.index && this.openEditModal()
                },
                openEditModal: function() {
                    if (this.singleSelectedRowData) {
                        this.$refs.dataTable.$refs.groupNode.multiRowSelectionChange(this.allSelectedDataInfo);
                        var t = this.singleSelectedData._type;
                        t === ee && this.openDefaultServerEditModal(), t === re && this.openVhostEditModal(this.singleSelectedData), t === ie && this.openPortalEditModal(this.singleSelectedData), t === ne && this.openDefaultPortalEditModal(this.singleSelectedData), t === oe && this.openAliasEditModal(this.singleSelectedData)
                    }
                },
                openDefaultServerEditModal: function() {
                    var t = this;
                    new SYNO.SDS.WebStation.Dialog.DefaultServer({
                        owner: this.$root._$extPanel.owner.appWin,
                        module: this.$root._$extPanel.owner,
                        title: _TT("SYNO.SDS.WebStation.Application", "portal", "edit_default_server_title_case"),
                        listeners: {
                            close: function() {
                                return t.$refs.dataTable.refresh()
                            },
                            scope: this.$root._$extPanel.owner
                        }
                    }).show()
                },
                openVhostEditModal: function() {
                    var t = this,
                        e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        r = new SYNO.SDS.WebStation.Web.VHostEditor({
                            owner: this.$root._$extPanel.owner.appWin,
                            module: this.$root._$extPanel.owner,
                            title: _TT("SYNO.SDS.WebStation.Application", "vhost", "edit_vhost"),
                            webapi: {
                                api: "SYNO.WebStation.HTTP.VHost",
                                method: "update",
                                version: 1
                            },
                            listeners: {
                                close: function() {
                                    return t.$refs.dataTable.refresh()
                                },
                                scope: this.$root._$extPanel.owner
                            }
                        });
                    r.setData(e), r.show()
                },
                openPortalEditModal: function() {
                    var t = this,
                        e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        r = new SYNO.SDS.WebStation.Web.ServerPortalEditor({
                            owner: this.$root._$extPanel.owner.appWin,
                            module: this.$root._$extPanel.owner,
                            title: _TT("SYNO.SDS.WebStation.Application", "portal", "edit_portal"),
                            webapi: {
                                api: "SYNO.WebStation.WebService.Portal",
                                method: "update",
                                version: 1
                            },
                            listeners: {
                                close: function() {
                                    return t.$refs.dataTable.refresh()
                                },
                                scope: this.$root._$extPanel.owner
                            },
                            preserve: e.preserve
                        });
                    r.setData(e), r.open()
                },
                openDefaultPortalEditModal: function() {
                    var t = this,
                        e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        r = new SYNO.SDS.WebStation.Web.DefaultServerPortalEditor({
                            owner: this.$root._$extPanel.owner.appWin,
                            module: this.$root._$extPanel.owner,
                            title: _TT("SYNO.SDS.WebStation.Application", "portal", "edit_alternative_portal_title_case"),
                            webapi: {
                                api: "SYNO.WebStation.WebService.Portal",
                                method: "update",
                                version: 1
                            },
                            listeners: {
                                close: function() {
                                    return t.$refs.dataTable.refresh()
                                },
                                scope: this.$root._$extPanel.owner
                            },
                            preserve: e.preserve
                        });
                    r.setData(e), r.open()
                },
                openAliasEditModal: function() {
                    var t = this,
                        e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        r = new SYNO.SDS.WebStation.Web.AliasPortalEditor({
                            owner: this.$root._$extPanel.owner.appWin,
                            module: this.$root._$extPanel.owner,
                            isEditPanel: !0,
                            title: _TT("SYNO.SDS.WebStation.Application", "alias", "edit_alias_portal"),
                            webapi: {
                                api: "SYNO.WebStation.WebService.Portal",
                                method: "update",
                                version: 1
                            },
                            listeners: {
                                close: function() {
                                    return t.$refs.dataTable.refresh()
                                },
                                scope: this.$root._$extPanel.owner
                            },
                            preserve: e.preserve
                        });
                    r.setData(e), r.open()
                },
                openServiceWizard: function() {
                    var t = this;
                    if (!this.isServiceWizardOpened) {
                        this.isServiceWizardOpened = !0;
                        var e = this.$appWindow.openVueWindow(SYNO.SDS.WebStation.Wizard.ServiceWizard),
                            r = e.window;
                        e.component.$appWindow = this.$appWindow, r.$on("close", (function() {
                            t.isServiceWizardOpened = !1, t.$refs.dataTable.refresh()
                        }))
                    }
                },
                openCreateAliasModal: function() {
                    var t = this;
                    new SYNO.SDS.WebStation.Web.AliasPortalEditor({
                        owner: this.$root._$extPanel.owner.appWin,
                        module: this.$root._$extPanel.owner,
                        isEditPanel: !1,
                        title: _TT("SYNO.SDS.WebStation.Application", "alias", "create_alias_portal"),
                        webapi: {
                            api: "SYNO.WebStation.WebService.Portal",
                            method: "create",
                            version: 1
                        },
                        listeners: {
                            close: function() {
                                return t.$refs.dataTable.refresh()
                            },
                            scope: this.$root._$extPanel.owner
                        }
                    }).open()
                },
                activateService: (ze = Oe(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.changeSelectedServiceEanbleStatus(!0);
                            case 2:
                                return t.abrupt("return", t.sent);
                            case 3:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return ze.apply(this, arguments)
                }),
                deactivateService: (Ye = Oe(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.changeSelectedServiceEanbleStatus(!1);
                            case 2:
                                return t.abrupt("return", t.sent);
                            case 3:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Ye.apply(this, arguments)
                }),
                changeSelectedServiceEanbleStatus: (Le = Oe(regeneratorRuntime.mark((function t() {
                    var e, r, n, i, o = arguments;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = !(o.length > 0 && void 0 !== o[0]) || o[0], (r = this.$refs.dataTable).$refs.groupNode.multiRowSelectionChange(this.allSelectedDataInfo), r.currentLoading = !0, n = this.allSelectedData.filter((function(t) {
                                    return t._type === re
                                })).filter((function(t) {
                                    return t.enable !== e
                                })).map((function(t) {
                                    return Ne({}, t, {
                                        enable: e
                                    })
                                })).map((function(t) {
                                    return $e(t)
                                })), i = this.allSelectedData.filter((function(t) {
                                    return t._type === ie || t._type === oe || t._type === ne
                                })).filter((function(t) {
                                    return t.enable !== e
                                })).map((function(t) {
                                    return Ne({}, t, {
                                        enable: e
                                    })
                                })).map((function(t) {
                                    return Ee(t)
                                })), t.prev = 6, t.next = 9, Re(ke(n).concat(ke(i)));
                            case 9:
                                t.next = 13;
                                break;
                            case 11:
                                t.prev = 11, t.t0 = t.catch(6);
                            case 13:
                                r.refresh(), r.currentLoading = !1;
                            case 15:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [6, 11]
                    ])
                }))), function() {
                    return Le.apply(this, arguments)
                }),
                deleteServices: (je = Oe(regeneratorRuntime.mark((function t() {
                    var e, r, n, i, o, a = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = function() {
                                    return new Promise((function(t, e) {
                                        a.$root._$extPanel.findAppWindow().getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), t)
                                    }))
                                }, t.next = 3, e();
                            case 3:
                                if ("yes" === t.sent) {
                                    t.next = 6;
                                    break
                                }
                                return t.abrupt("return");
                            case 6:
                                return this.$refs.dataTable.currentLoading = !0, r = this.allSelectedData.filter((function(t) {
                                    return t._type === re
                                })).map((function(t) {
                                    return t.UUID
                                })), n = this.allSelectedData.filter((function(t) {
                                    return t._type === ie || t._type === oe || t._type === ne
                                })).map((function(t) {
                                    return t.id
                                })), i = Ce(r), o = We(n), t.prev = 11, t.next = 14, Re([i, o].filter((function(t) {
                                    return !!t
                                })));
                            case 14:
                                t.next = 18;
                                break;
                            case 16:
                                t.prev = 16, t.t0 = t.catch(11);
                            case 18:
                                this.$refs.dataTable.refresh(), this.$refs.dataTable.currentLoading = !1;
                            case 20:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [11, 16]
                    ])
                }))), function() {
                    return je.apply(this, arguments)
                }),
                updateSelectedRows: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
                    this.selectedRows = t
                },
                clearSelectedRows: function() {
                    this.selectedRows = []
                }
            }
        },
        Fe = (r(95), d(Me, Qt, [], !1, null, "0542193f", null));
    Fe.options.__file = "src/pages/ServicePortalPage/index.vue";
    var qe = Fe.exports,
        He = function() {
            var t = this,
                e = t.$createElement;
            return (t._self._c || e)("Profile", {
                attrs: {
                    profile: t.profile,
                    "cancel-text": t._TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"),
                    confirmText: t._T("common", "create")
                },
                on: {
                    save: t.createProfile,
                    cancel: function(e) {
                        return t.close()
                    }
                }
            })
        };
    He._withStripped = !0;
    var Be = r(43),
        Ue = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-panel", {
                staticClass: "profile-dialog",
                attrs: {
                    "syno-id": "webstation-profile-panel",
                    loading: t.isLoading,
                    "loading-type": t.loadingType,
                    "status-bar-state": t.statusBarState,
                    "show-status-bar": t.showStatusBar,
                    errorText: t._T("common", "forminvalid"),
                    confirmText: this.confirmText,
                    confirm: function() {
                        return t.save()
                    },
                    cancel: function() {
                        return t.cancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        t.showStatusBar = e
                    },
                    "update:show-status-bar": function(e) {
                        t.showStatusBar = e
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [r("v-form", {
                            ref: "form",
                            staticClass: "profile-dialog__wrapper",
                            attrs: {
                                "syno-id": "webstation-profile-form"
                            }
                        }, [r("ProfileForm", {
                            ref: "profileForm",
                            staticClass: "profile-dialog__general-settings",
                            attrs: {
                                profile: t.currentProfile
                            }
                        }), t._v(" "), r("CustomSettings", {
                            ref: "customSettings",
                            staticClass: "profile-dialog__custom-settings",
                            attrs: {
                                profile: t.currentProfile
                            },
                            on: {
                                "profile:add-page": t.addPage,
                                "profile:delete-page": t.deletePage
                            }
                        })], 1)]
                    },
                    proxy: !0
                }])
            })
        };
    Ue._withStripped = !0;
    var Ve = r(63),
        Qe = r.n(Ve),
        Ge = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-fieldset", {
                staticClass: "profile-form-fieldset",
                attrs: {
                    "syno-id": "webstation-profile-fieldset",
                    title: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_page_title_case"),
                    collapsible: !1
                }
            }, ["default" === t.profile.id ? r("v-form-item", {
                attrs: {
                    "syno-id": "webstation-profile-desc-form-item",
                    prop: "profile-desc",
                    label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "profile_name") + t._T("common", "colon")
                }
            }, [r("p", {
                staticClass: "custom-settings__paragraph"
            }, [t._v("\n    " + t._s(t.profile.desc) + "\n    ")])]) : r("v-form-item", {
                attrs: {
                    "syno-id": "webstation-profile-desc-form-item",
                    prop: "profile-desc",
                    label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "profile_name") + t._T("common", "colon"),
                    rules: t.RULES.descRules
                }
            }, [r("v-input", {
                staticClass: "error-page-profile-form__v-input",
                attrs: {
                    "syno-id": "webstation-profile-desc-input",
                    name: "profile-desc"
                },
                model: {
                    value: t.profile.desc,
                    callback: function(e) {
                        t.$set(t.profile, "desc", e)
                    },
                    expression: "profile.desc"
                }
            })], 1), t._v(" "), r("v-form-item", {
                attrs: {
                    "syno-id": "webstation-profile-page-default-type-form-item",
                    label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "response_action") + t._T("common", "colon")
                }
            }, [r("v-select", {
                staticClass: "error-page-profile-form__v-select",
                attrs: {
                    readonly: "",
                    "syno-id": "webstation-profile-page-default-type-select",
                    width: "",
                    hasTooltip: "",
                    options: t.RESPONSE_ACTION_SELECTS
                },
                model: {
                    value: t.profile.defaultPage.type,
                    callback: function(e) {
                        t.$set(t.profile.defaultPage, "type", e)
                    },
                    expression: "profile.defaultPage.type"
                }
            })], 1), t._v(" "), t.profile.defaultPage.type === t.RESPONSE_ACTIONS.STATIC ? r("v-form-item", {
                key: "webstation-profile-page-default-file-form-item",
                attrs: {
                    "syno-id": "webstation-profile-page-default-file-form-item",
                    label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "file_path") + t._T("common", "colon"),
                    prop: "profile-page-default-file",
                    rules: t.RULES.errorPageStaticFileRules
                }
            }, [r("FileInput", {
                directives: [{
                    name: "form-component",
                    rawName: "v-form-component"
                }],
                staticClass: "error-page-profile-form__file-input",
                attrs: {
                    name: "profile-page-default-file",
                    placeholder: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "select_file"),
                    accept: ".html,image/*",
                    value: "string" == typeof t.profile.defaultPage.file ? t.profile.defaultPage.desc : t.profile.defaultPage.file
                },
                on: {
                    input: function(e) {
                        t.profile.defaultPage.file = e
                    }
                }
            })], 1) : t._e(), t._v(" "), t.profile.defaultPage.type === t.RESPONSE_ACTIONS.RELATIVE_URL ? r("v-form-item", {
                key: "webstation-profile-page-default-relative-url-form-item",
                attrs: {
                    "syno-id": "webstation-profile-page-default-relative-url-form-item",
                    label: t._TT("SYNO.SDS.WebStation.Application", "common", "url") + t._T("common", "colon"),
                    prop: "profile-page-default-relative-url",
                    rules: t.RULES.relativeUrlRules
                }
            }, [r("v-input", {
                staticClass: "error-page-profile-form__v-input",
                attrs: {
                    "syno-id": "webstation-profile-page-default-relative-url-input",
                    name: "profile-page-default-relative-url",
                    placeholder: "" + t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "example") + t._T("common", "colon") + " /ErrorPages/404.aspx"
                },
                model: {
                    value: t.profile.defaultPage.relative_url,
                    callback: function(e) {
                        t.$set(t.profile.defaultPage, "relative_url", e)
                    },
                    expression: "profile.defaultPage.relative_url"
                }
            })], 1) : t._e(), t._v(" "), t.profile.defaultPage.type === t.RESPONSE_ACTIONS.REDIRECT_302 ? r("v-form-item", {
                key: "webstation-profile-page-default-absolute-url-form-item",
                attrs: {
                    "syno-id": "webstation-profile-page-default-absolute-url-form-item",
                    label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "absolute_url") + t._T("common", "colon"),
                    prop: "profile-page-default-absolute-url",
                    rules: t.RULES.absoluteUrlRules
                }
            }, [r("v-input", {
                staticClass: "error-page-profile-form__v-input",
                attrs: {
                    "syno-id": "webstation-profile-page-default-absolute-url-input",
                    name: "profile-page-default-absolute-url",
                    placeholder: "" + t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "example") + t._T("common", "colon") + " http://www.test.com/404.aspx"
                },
                model: {
                    value: t.profile.defaultPage.absolute_url,
                    callback: function(e) {
                        t.$set(t.profile.defaultPage, "absolute_url", e)
                    },
                    expression: "profile.defaultPage.absolute_url"
                }
            })], 1) : t._e()], 1)
        };
    Ge._withStripped = !0;
    var Je = function() {
        var t = this,
            e = t.$createElement,
            r = t._self._c || e;
        return r("label", {
            class: {
                "webstation-file-input": !0, "webstation-file-input--hover": t.isHovering, "webstation-file-input--focus": t.isFocusing
            },
            attrs: {
                tabindex: "0",
                for: t.labelFor
            },
            on: {
                mouseover: function(e) {
                    t.isHovering = !0
                },
                mouseleave: function(e) {
                    t.isHovering = !1
                },
                click: function(e) {
                    t.isFocusing = !0
                },
                blur: function(e) {
                    t.isFocusing = !1
                }
            }
        }, [r("span", {
            class: ["webstation-file-input__text", {
                "webstation-file-input__text--primary": t.filename
            }]
        }, [t._v("\n    " + t._s(t.filename || t.placeholder) + "\n  ")]), t._v(" "), r("span", {
            staticClass: "webstation-file-input__btn"
        }), t._v(" "), r("input", {
            staticClass: "webstation-file-input__input",
            attrs: {
                id: t.labelFor,
                type: "file",
                accept: t.accept,
                name: t.name
            },
            on: {
                change: function(e) {
                    return t.onInputChange(e)
                }
            }
        })])
    };
    Je._withStripped = !0;
    var Ke = {
            props: {
                value: [File, String],
                name: String,
                placeholder: String,
                accept: String
            },
            data: function() {
                return {
                    isHovering: !1,
                    isFocusing: !1
                }
            },
            computed: {
                labelFor: function() {
                    return "".concat(Date.now().toString(36), "-").concat(Math.random().toString(36).substr(2, 9))
                },
                filename: function() {
                    return "string" == typeof this.value ? this.value : this.value && this.value.name || null
                }
            },
            methods: {
                onInputChange: function(t) {
                    var e = t.target.files[0];
                    e && this.$emit("input", e)
                }
            }
        },
        Xe = (r(150), d(Ke, Je, [], !1, null, null, null));
    Xe.options.__file = "src/components/FileInput.vue";
    var Ze = Xe.exports;

    function tr() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
            e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : [];
        if (void 0 === t || "" === t) return new Error(_JSLIBSTR("extlang", "fieldblank"));
        if ("default" !== t) {
            var r = parseInt(t, 10);
            if (Number.isNaN(r)) return new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_code_valid"));
            if (r < 400 || 600 <= r) return new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_code_valid"));
            var n = e.some((function(r, n) {
                return e.indexOf(r) !== n && t === r
            }));
            return n ? new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_code_duplicated")) : void 0
        }
    }

    function er(t) {
        if (!t) return new Error(_JSLIBSTR("extlang", "fieldblank"))
    }
    var rr = [{
            type: "string",
            required: !0,
            validator: function(t, e, r) {
                return r(function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    if ("" === t) return new Error(_JSLIBSTR("extlang", "fieldblank"))
                }(e))
            }
        }],
        nr = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            return [{
                type: "string",
                required: !0,
                validator: function(e, r, n) {
                    return n(tr(r, t))
                }
            }]
        },
        ir = [{
            required: !0,
            validator: function(t, e, r) {
                return r((i = er(n = e)) ? i : n instanceof File ? ["image/", "html", "text"].some((function(t) {
                    return n.type.includes(t)
                })) ? void 0 : new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_file_page")) : void 0);
                var n, i
            }
        }],
        or = [{
            required: !0,
            validator: function(t, e, r) {
                return r((i = er(n = e)) ? i : n instanceof File ? "dat" === n.name.split(".").lastItem ? void 0 : new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_file_imported")) : void 0);
                var n, i
            }
        }],
        ar = [{
            type: "string",
            required: !0,
            validator: function(t, e, r) {
                return r(function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return "" === t ? new Error(_JSLIBSTR("extlang", "fieldblank")) : t.startsWith("/") ? void 0 : new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_relative_url"))
                }(e))
            }
        }],
        sr = [{
            type: "string",
            required: !0,
            validator: function(t, e, r) {
                return r(function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    if ("" === t) return new Error(_JSLIBSTR("extlang", "fieldblank"));
                    var e = ["https://", "http://"].some((function(e) {
                        return t.startsWith(e)
                    }));
                    return e ? void 0 : new Error(_TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_absolute_url"))
                }(e))
            }
        }],
        cr = {
            components: {
                FileInput: Ze
            },
            mixins: [pt],
            props: {
                profile: {
                    type: Object,
                    required: !0
                }
            },
            data: function() {
                return {
                    RESPONSE_ACTIONS: mt,
                    RESPONSE_ACTION_SELECTS: _t(),
                    RULES: n
                }
            }
        },
        pr = (r(154), d(cr, Ge, [], !1, null, null, null));
    pr.options.__file = "src/components/Profile/ProfileForm.vue";
    var lr = pr.exports,
        ur = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("div", [r("v-fieldset", {
                staticClass: "custom-settings",
                attrs: {
                    "syno-id": "webstation-profile-custom-settings-fieldset",
                    title: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "custom_settings_title_case"),
                    collapsible: !1
                }
            }, [r("div", {
                ref: "paragraph"
            }, [r("p", {
                staticClass: "custom-settings__paragraph",
                domProps: {
                    innerHTML: t._s(t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "custom_settings_description"))
                }
            }), t._v(" "), r("v-button", {
                staticClass: "custom-settings__add-page-btn",
                attrs: {
                    "syno-id": "webstation-profile-custom-page-add-button"
                },
                on: {
                    click: function(e) {
                        return t.$emit("profile:add-page", {}, t.onAddPageDone)
                    }
                }
            }, [t._v("\n      " + t._s(t._T("common", "add")) + "\n    ")])], 1), t._v(" "), r("div", {
                ref: "fileDragger",
                class: {
                    "file-dragger": !0, "file-dragger--dragging": t.isDragging
                },
                attrs: {
                    id: "file-dragger"
                },
                on: {
                    dragenter: function(e) {
                        e.stopPropagation(), e.preventDefault(), t.isDragging = !0
                    }
                }
            }, [r("div", {
                class: {
                    "file-dragger__cover": !0, "file-dragger__cover--hidden": !t.isDragging
                },
                on: {
                    dragover: function(t) {
                        t.stopPropagation(), t.preventDefault()
                    },
                    dragleave: function(e) {
                        e.stopPropagation(), e.preventDefault(), t.isDragging = !1
                    },
                    drop: function(e) {
                        return e.stopPropagation(), e.preventDefault(), t.onDrop(e)
                    }
                }
            }, [r("div", {
                staticClass: "file-dragger__cover__content"
            }, [r("div", {
                staticClass: "file-dragger__cover__content__img"
            }), t._v(" "), r("div", {
                staticClass: "file-dragger__cover__content__text"
            }, [t._v("\n            " + t._s(t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "drag_file_here")) + "\n          ")])])]), t._v(" "), r("v-data-table", {
                ref: "dataTable",
                staticClass: "custom-settings__data-table",
                style: {
                    height: t.offsetHeight + "px"
                },
                attrs: {
                    "hide-refresh-btn": "",
                    "syno-id": "webstation-profile-custom-page-data-table",
                    columns: t.columns,
                    "current-data": t.profile.otherPages
                },
                scopedSlots: t._u([{
                    key: "code",
                    fn: function(e) {
                        e.data;
                        var n = e.row;
                        return [r("v-form-item", {
                            attrs: {
                                "syno-id": "webstation-profile-page-" + n.id + "-code-form-item",
                                prop: "code",
                                rules: t.codeRules
                            }
                        }, [r("v-input", {
                            attrs: {
                                "syno-id": "webstation-profile-page-" + n.id + "-code-input",
                                name: "code",
                                maxlength: 3
                            },
                            on: {
                                keydown: function(e) {
                                    if (!e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter")) return null;
                                    e.preventDefault()
                                }
                            },
                            model: {
                                value: n.code,
                                callback: function(e) {
                                    t.$set(n, "code", e)
                                },
                                expression: "page.code"
                            }
                        })], 1)]
                    }
                }, {
                    key: "type",
                    fn: function(e) {
                        var n = e.row;
                        return [r("ResponseActionTd", t._g({
                            attrs: {
                                page: n
                            }
                        }, t.$listeners))]
                    }
                }, {
                    key: "empty-area",
                    fn: function() {
                        return [r("div", {
                            staticClass: "custom-settings__data-table__empty-text"
                        }, [t._v("\n              " + t._s(t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "no_customize_error_page")) + "\n            ")])]
                    },
                    proxy: !0
                }])
            })], 1)])], 1)
        };
    ur._withStripped = !0;
    var dr = function() {
        var t = this,
            e = t.$createElement,
            r = t._self._c || e;
        return r("div", {
            staticClass: "response-actions",
            on: {
                keydown: function(e) {
                    if (!e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter")) return null;
                    e.preventDefault()
                }
            }
        }, [r("v-form-item", {
            staticClass: "response-actions__form-item response-actions__form-item--select",
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-type-select-form-item"
            }
        }, [r("v-select", {
            staticClass: "response-actions__select",
            attrs: {
                readonly: "",
                "syno-id": "webstation-profile-page-" + t.page.id + "-type-select",
                width: "",
                hasTooltip: "",
                options: t.RESPONSE_ACTION_SELECTS
            },
            model: {
                value: t.page.type,
                callback: function(e) {
                    t.$set(t.page, "type", e)
                },
                expression: "page.type"
            }
        })], 1), t._v(" "), t.page.type === t.RESPONSE_ACTIONS.STATIC ? r("v-form-item", {
            key: "webstation-profile-page-" + t.page.id + "-file-form-item",
            staticClass: "response-actions__form-item response-actions__form-item--action",
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-file-form-item",
                prop: "file",
                rules: t.RULES.errorPageStaticFileRules
            }
        }, [r("FileInput", {
            directives: [{
                name: "form-component",
                rawName: "v-form-component"
            }],
            attrs: {
                name: "file",
                placeholder: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "select_file"),
                accept: ".html,image/*",
                value: "string" == typeof t.page.file ? t.page.desc : t.page.file
            },
            on: {
                input: function(e) {
                    t.page.file = e
                }
            }
        })], 1) : t._e(), t._v(" "), t.page.type === t.RESPONSE_ACTIONS.RELATIVE_URL ? r("v-form-item", {
            key: "webstation-profile-page-" + t.page.id + "-relative-url-form-item",
            staticClass: "response-actions__form-item response-actions__form-item--action",
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-relative-url-form-item",
                prop: "relative-url",
                rules: t.RULES.relativeUrlRules
            }
        }, [r("v-input", {
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-relative-url-input",
                name: "relative-url",
                placeholder: "" + t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "example") + t._T("common", "colon") + " /ErrorPages/404.aspx"
            },
            model: {
                value: t.page.relative_url,
                callback: function(e) {
                    t.$set(t.page, "relative_url", e)
                },
                expression: "page.relative_url"
            }
        })], 1) : t._e(), t._v(" "), t.page.type === t.RESPONSE_ACTIONS.REDIRECT_302 ? r("v-form-item", {
            key: "webstation-profile-page-" + t.page.id + "-absolute-url-form-item",
            staticClass: "response-actions__form-item response-actions__form-item--action",
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-absolute-url-form-item",
                prop: "absolute-url",
                rules: t.RULES.absoluteUrlRules
            }
        }, [r("v-input", {
            attrs: {
                "syno-id": "webstation-profile-page-" + t.page.id + "-absolute-url-input",
                name: "absolute-url",
                placeholder: "" + t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "example") + t._T("common", "colon") + " http://www.test.com/404.aspx"
            },
            model: {
                value: t.page.absolute_url,
                callback: function(e) {
                    t.$set(t.page, "absolute_url", e)
                },
                expression: "page.absolute_url"
            }
        })], 1) : t._e(), t._v(" "), r("button", {
            staticClass: "response-actions__delete-btn",
            on: {
                click: function(e) {
                    return t.$emit("profile:delete-page", t.page)
                }
            }
        })], 1)
    };
    dr._withStripped = !0;
    var fr = {
            components: {
                FileInput: Ze
            },
            mixins: [pt],
            props: {
                page: {
                    type: Object,
                    required: !0
                }
            },
            data: function() {
                return {
                    RESPONSE_ACTIONS: mt,
                    RESPONSE_ACTION_SELECTS: _t(),
                    RULES: n
                }
            }
        },
        hr = (r(156), d(fr, dr, [], !1, null, null, null));

    function vr(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function mr(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    vr(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    vr(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    hr.options.__file = "src/components/Profile/ResponseActionTd.vue";
    var _r, br, gr = {
            components: {
                ResponseActionTd: hr.exports
            },
            mixins: [pt],
            props: {
                profile: {
                    type: Object,
                    required: !0
                }
            },
            data: function() {
                return {
                    isDragging: !1,
                    offsetHeight: 205
                }
            },
            created: function() {
                var t = this;
                this.$nextTick((function() {
                    t.offsetHeight = 152 - t.$parent.$children[0].$el.offsetHeight + 275 - t.$refs.paragraph.offsetHeight
                }))
            },
            computed: {
                columns: function() {
                    return [{
                        title: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "status_code"),
                        field: "code",
                        width: 152
                    }, {
                        title: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "response_action_title_case"),
                        field: "type",
                        className: "data-table__response_actions_column"
                    }]
                },
                customPageCodes: function() {
                    return this.profile.otherPages.map((function(t) {
                        return t.code
                    }))
                },
                codeRules: function() {
                    return nr(this.customPageCodes)
                }
            },
            methods: {
                onAddPageDone: (br = mr(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.$refs.dataTable, t.next = 3, this.$nextTick();
                            case 3:
                                e.buildCols({
                                    applyHeadersWidth: !0,
                                    forceFit: !0
                                }), this.scrollAfterAdd(1);
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return br.apply(this, arguments)
                }),
                onDrop: (_r = mr(regeneratorRuntime.mark((function t(e) {
                    var r, n, i, o, a = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.isDragging = !1, e.dataTransfer.files.forEach((function(t) {
                                    a.$emit("profile:add-page", {
                                        type: mt.STATIC,
                                        file: t
                                    }, (function() {
                                        return a.onAddPageDone()
                                    }))
                                })), t.next = 4, this.$nextTick();
                            case 4:
                                r = e.dataTransfer.files.length, n = this.$root._$extPanel.findWindow(), i = 1 === r ? _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "item_added") : _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "items_added"), o = i.replace("{0}", r), n.getToastBox('<span class="toast-text">'.concat(o, "</span>")), this.scrollAfterAdd(r);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return _r.apply(this, arguments)
                }),
                scrollAfterAdd: function(t) {
                    var e = this.$refs.dataTable,
                        r = Math.floor(e.$cells.length / 2) - t;
                    this.scrollToRow(r)
                },
                scrollToRow: function(t) {
                    var e = this.$refs.dataTable;
                    e.ensureRowVisible(t), e.clickRow(t)
                }
            }
        },
        Sr = (r(160), d(gr, ur, [], !1, null, null, null));
    Sr.options.__file = "src/components/Profile/CustomSettings.vue";
    var wr = Sr.exports,
        yr = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("div", {
                staticClass: "modal-footer"
            }, [r("div", {
                class: [{
                    "modal-footer__left-text": !0
                }, {
                    "modal-footer__left-text--error": t.error
                }]
            }, [t._v("\n    " + t._s(t.text) + "\n  ")]), t._v(" "), r("div", {
                staticClass: "modal-footer__right-actions"
            }, [r("v-button", {
                staticClass: "modal-footer__right-actions__btn",
                attrs: {
                    type: "footbar"
                },
                on: {
                    click: function(e) {
                        return t.$emit("cancel", e)
                    }
                }
            }, [t._v("\n      " + t._s(t._T("common", "cancel")) + "\n    ")]), t._v(" "), r("v-button", {
                staticClass: "modal-footer__right-actions__btn",
                attrs: {
                    type: "footbar",
                    suffix: "blue"
                },
                on: {
                    click: function(e) {
                        return t.$emit("save", e)
                    }
                }
            }, [t._v("\n      " + t._s(t._T("common", "save")) + "\n    ")])], 1)])
        };
    yr._withStripped = !0;
    var xr = {
            mixins: [pt],
            props: {
                error: {
                    type: Boolean,
                    default: !1
                },
                text: {
                    type: String,
                    default: ""
                }
            }
        },
        Pr = (r(164), d(xr, yr, [], !1, null, "40ab164b", null));

    function Tr(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function kr(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    Tr(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    Tr(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    Pr.options.__file = "src/components/Footer.vue";
    var Dr, Or, Nr, Ar, $r, Er, Cr, Wr, Rr = {
            components: {
                ProfileForm: lr,
                CustomSettings: wr,
                Footer: Pr.exports
            },
            mixins: [pt],
            props: {
                cancelText: {
                    type: String,
                    required: !0
                },
                confirmText: {
                    type: String,
                    required: !0
                },
                profile: {
                    type: Object,
                    required: !0
                }
            },
            data: function() {
                return {
                    currentProfile: Qe()(this.profile),
                    showStatusBar: !1,
                    isLoading: !1,
                    loadingType: "spin",
                    statusBarState: "loading"
                }
            },
            methods: {
                save: (Wr = kr(regeneratorRuntime.mark((function t() {
                    var e = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.validate();
                            case 2:
                                if (t.sent) {
                                    t.next = 4;
                                    break
                                }
                                return t.abrupt("return", this.onError());
                            case 4:
                                this.onLoading(), this.$emit("save", this.currentProfile, (function() {
                                    return e.onError()
                                }));
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Wr.apply(this, arguments)
                }),
                cancel: (Cr = kr(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.isDirty();
                            case 2:
                                if (t.sent) {
                                    t.next = 4;
                                    break
                                }
                                return t.abrupt("return", this.$emit("cancel"));
                            case 4:
                                return t.next = 6, this.confirmClose();
                            case 6:
                                if ("yes" !== (e = t.sent)) {
                                    t.next = 9;
                                    break
                                }
                                return t.abrupt("return", this.save());
                            case 9:
                                if ("no" !== e) {
                                    t.next = 11;
                                    break
                                }
                                return t.abrupt("return");
                            case 11:
                                if ("leftCustom" !== e) {
                                    t.next = 13;
                                    break
                                }
                                return t.abrupt("return", this.$emit("cancel"));
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Cr.apply(this, arguments)
                }),
                onLoading: function() {
                    this.isLoading = !0, this.loadingType = "spin", this.statusBarState = "loading"
                },
                onError: (Er = kr(regeneratorRuntime.mark((function t() {
                    var e, r, n;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.showStatusBar = !0, this.isLoading = !1, this.loadingType = "statusbar", this.statusBarState = "error", e = this.$refs.form.fields.filter((function(t) {
                                    return ["code", "file", "relative-url", "absolute-url"].includes(t.prop)
                                })).map((function(t) {
                                    return t.index = "code" !== t.prop ? t.$parent._uid : t._uid, t
                                })).sort((function(t, e) {
                                    return t.index - e.index
                                })), t.next = 7, Promise.all(e.map((function(t) {
                                    return t.validate()
                                })));
                            case 7:
                                return r = t.sent, t.next = 10, this.$nextTick();
                            case 10:
                                -1 !== (n = r.findIndex((function(t) {
                                    return "" !== t
                                }))) && this.$refs.customSettings.scrollToRow(Math.floor(n / 2));
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Er.apply(this, arguments)
                }),
                addPage: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = arguments.length > 1 ? arguments[1] : void 0,
                        r = this.currentProfile.otherPages.find((function(t) {
                            return void 0 === t.file
                        }));
                    if (!ht()(t) && r) r.file = t.file;
                    else {
                        var n = wt(t);
                        this.currentProfile.otherPages.push(n)
                    }
                    e()
                },
                deletePage: ($r = kr(regeneratorRuntime.mark((function t(e) {
                    var r, n;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (r = this.currentProfile.otherPages.find((function(t) {
                                        return t.id === e.id
                                    }))) {
                                    t.next = 3;
                                    break
                                }
                                return t.abrupt("return");
                            case 3:
                                return t.next = 5, this.confirmDelete(r);
                            case 5:
                                if (t.sent) {
                                    t.next = 7;
                                    break
                                }
                                return t.abrupt("return");
                            case 7:
                                n = this.currentProfile.otherPages.indexOf(r), this.currentProfile.otherPages.splice(n, 1);
                            case 9:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return $r.apply(this, arguments)
                }),
                confirmDelete: (Ar = kr(regeneratorRuntime.mark((function t() {
                    var e, r, n, i = this,
                        o = arguments;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (e = o.length > 0 && void 0 !== o[0] ? o[0] : {}) {
                                    t.next = 3;
                                    break
                                }
                                return t.abrupt("return", !0);
                            case 3:
                                if (e.code || e.file || e.absolute_url || e.relative_url) {
                                    t.next = 5;
                                    break
                                }
                                return t.abrupt("return", !0);
                            case 5:
                                return r = function() {
                                    return new Promise((function(t, e) {
                                        i.$root._$extPanel.findAppWindow().getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "confirm_delete_page"), t)
                                    }))
                                }, t.next = 8, r();
                            case 8:
                                return n = t.sent, t.abrupt("return", "yes" === n);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Ar.apply(this, arguments)
                }),
                confirmClose: (Nr = kr(regeneratorRuntime.mark((function t() {
                    var e, r = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = function() {
                                    return new Promise((function(t, e) {
                                        var n = r.$root._$extPanel.findAppWindow();
                                        n.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), r.cancelText, t, n, {
                                            yes: _T("common", "save"),
                                            no: _T("common", "cancel"),
                                            leftCustom: _T("common", "dont_save")
                                        })
                                    }))
                                }, t.next = 3, e();
                            case 3:
                                return t.abrupt("return", t.sent);
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Nr.apply(this, arguments)
                }),
                validate: (Or = kr(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.$refs.form, t.next = 3, e.validate();
                            case 3:
                                return t.abrupt("return", t.sent);
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Or.apply(this, arguments)
                }),
                isDirty: (Dr = kr(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.$refs.form, t.next = 3, e.isDirty();
                            case 3:
                                return t.abrupt("return", t.sent);
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Dr.apply(this, arguments)
                })
            }
        },
        Ir = (r(166), d(Rr, Ue, [], !1, null, null, null));
    Ir.options.__file = "src/components/Profile/index.vue";
    var jr = Ir.exports;

    function Lr(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }
    var Yr, zr, Mr = d({
        components: {
            Profile: jr
        },
        mixins: [pt],
        data: function() {
            return {
                profile: St()
            }
        },
        methods: {
            createProfile: (Yr = regeneratorRuntime.mark((function t() {
                var e, r, n = arguments;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, r = n.length > 1 ? n[1] : void 0, t.prev = 2, t.next = 5, Nt(e);
                        case 5:
                            this.close(), t.next = 12;
                            break;
                        case 8:
                            t.prev = 8, t.t0 = t.catch(2), SYNO.Debug.error("CreateProfileDialog:createProfile", t.t0, e), r();
                        case 12:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [2, 8]
                ])
            })), zr = function() {
                var t = this,
                    e = arguments;
                return new Promise((function(r, n) {
                    var i = Yr.apply(t, e);

                    function o(t) {
                        Lr(i, r, n, o, a, "next", t)
                    }

                    function a(t) {
                        Lr(i, r, n, o, a, "throw", t)
                    }
                    o(void 0)
                }))
            }, function() {
                return zr.apply(this, arguments)
            }),
            close: function() {
                this.$root._$extPanel.findWindow().close()
            }
        }
    }, He, [], !1, null, null, null);
    Mr.options.__file = "src/dialogs/CreateProfileDialog.vue";
    var Fr = Mr.exports,
        qr = function() {
            var t = this,
                e = t.$createElement;
            return (t._self._c || e)("Profile", {
                attrs: {
                    profile: t.profile,
                    "cancel-text": t._TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page"),
                    confirmText: t._T("common", "save")
                },
                on: {
                    save: t.updateProfile,
                    cancel: function(e) {
                        return t.close()
                    }
                }
            })
        };

    function Hr(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }
    qr._withStripped = !0;
    var Br, Ur = d({
        components: {
            Profile: jr
        },
        mixins: [pt],
        data: function() {
            return {
                profile: this.$root._$extPanel.findWindow().data.profile
            }
        },
        methods: {
            updateProfile: (Br = function(t) {
                return function() {
                    var e = this,
                        r = arguments;
                    return new Promise((function(n, i) {
                        var o = t.apply(e, r);

                        function a(t) {
                            Hr(o, n, i, a, s, "next", t)
                        }

                        function s(t) {
                            Hr(o, n, i, a, s, "throw", t)
                        }
                        a(void 0)
                    }))
                }
            }(regeneratorRuntime.mark((function t() {
                var e, r, n = arguments;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, r = n.length > 1 ? n[1] : void 0, t.prev = 2, t.next = 5, $t(e, this.profile);
                        case 5:
                            this.close(), t.next = 12;
                            break;
                        case 8:
                            t.prev = 8, t.t0 = t.catch(2), SYNO.Debug.error("EditProfileDialog:updateProfile", t.t0, e), r();
                        case 12:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [2, 8]
                ])
            }))), function() {
                return Br.apply(this, arguments)
            }),
            close: function() {
                this.$root._$extPanel.findWindow().close()
            }
        }
    }, qr, [], !1, null, null, null);
    Ur.options.__file = "src/dialogs/EditProfileDialog.vue";
    var Vr = Ur.exports,
        Qr = function() {
            var t = this,
                e = t.$createElement,
                r = t._self._c || e;
            return r("v-panel", {
                attrs: {
                    "syno-id": "webstation-import-profile-panel",
                    loading: t.isLoading,
                    "loading-type": t.loadingType,
                    "status-bar-state": t.statusBarState,
                    "show-status-bar": t.showStatusBar,
                    errorText: t._T("common", "forminvalid"),
                    confirmText: t._T("helptoc", "user_import"),
                    confirm: function() {
                        return t.save()
                    },
                    cancel: function() {
                        return t.cancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        t.showStatusBar = e
                    },
                    "update:show-status-bar": function(e) {
                        t.showStatusBar = e
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [r("div", {
                            staticClass: "profile-dialog__content"
                        }, [r("p", [t._v(t._s(t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "select_file_to_import_description")))]), t._v(" "), r("v-form", {
                            ref: "form",
                            attrs: {
                                "syno-id": "webstation-import-profile-form"
                            }
                        }, [r("v-form-item", {
                            attrs: {
                                "syno-id": "webstation-import-profile-form-item",
                                label: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "import_file") + t._T("common", "colon"),
                                prop: "webstation-import-file",
                                rules: t.RULES.importErrorProfileFileRules,
                                validateStatus: t.validateStatus
                            }
                        }, [r("FileInput", {
                            directives: [{
                                name: "form-component",
                                rawName: "v-form-component"
                            }],
                            staticClass: "profile-dialog__file-input",
                            attrs: {
                                name: "webstation-import-file",
                                accept: ".dat",
                                placeholder: t._TT("SYNO.SDS.WebStation.Application", "custom_error_page", "select_file")
                            },
                            model: {
                                value: t.file,
                                callback: function(e) {
                                    t.file = e
                                },
                                expression: "file"
                            }
                        })], 1)], 1)], 1)]
                    },
                    proxy: !0
                }])
            })
        };

    function Gr(t, e, r, n, i, o, a) {
        try {
            var s = t[o](a),
                c = s.value
        } catch (t) {
            return void r(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(n, i)
    }

    function Jr(t) {
        return function() {
            var e = this,
                r = arguments;
            return new Promise((function(n, i) {
                var o = t.apply(e, r);

                function a(t) {
                    Gr(o, n, i, a, s, "next", t)
                }

                function s(t) {
                    Gr(o, n, i, a, s, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    Qr._withStripped = !0;
    var Kr = {
            components: {
                FileInput: Ze
            },
            mixins: [pt],
            data: function() {
                return {
                    showStatusBar: !1,
                    file: "",
                    isLoading: !1,
                    loadingType: "spin",
                    statusBarState: "loading",
                    RULES: n,
                    validateStatus: ""
                }
            },
            methods: {
                save: function() {
                    var t = Jr(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, this.validate();
                                case 2:
                                    if (t.sent) {
                                        t.next = 4;
                                        break
                                    }
                                    return t.abrupt("return", this.onError());
                                case 4:
                                    return this.onLoading(), t.prev = 5, t.next = 8, Yt(this.file);
                                case 8:
                                    this.$root._$extPanel.findWindow().close(), t.next = 14;
                                    break;
                                case 11:
                                    return t.prev = 11, t.t0 = t.catch(5), t.abrupt("return", this.onError());
                                case 14:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [5, 11]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                onLoading: function() {
                    this.isLoading = !0, this.loadingType = "spin", this.statusBarState = "loading", this.validateStatus = ""
                },
                onError: function() {
                    this.showStatusBar = !0, this.isLoading = !1, this.loadingType = "statusbar", this.statusBarState = "error", this.validateStatus = "error"
                },
                validate: function() {
                    var t = Jr(regeneratorRuntime.mark((function t() {
                        var e;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = this.$refs.form, t.next = 3, e.validate();
                                case 3:
                                    return t.abrupt("return", t.sent);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                cancel: function() {
                    var t = Jr(regeneratorRuntime.mark((function t() {
                        var e;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, this.isDirty();
                                case 2:
                                    if (t.sent) {
                                        t.next = 4;
                                        break
                                    }
                                    return t.abrupt("return", this.$root._$extPanel.findWindow().close());
                                case 4:
                                    return t.next = 6, this.confirmClose();
                                case 6:
                                    if ("yes" !== (e = t.sent)) {
                                        t.next = 9;
                                        break
                                    }
                                    return t.abrupt("return", this.save());
                                case 9:
                                    if ("no" !== e) {
                                        t.next = 11;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 11:
                                    if ("leftCustom" !== e) {
                                        t.next = 13;
                                        break
                                    }
                                    return t.abrupt("return", this.$root._$extPanel.findWindow().close());
                                case 13:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                confirmClose: function() {
                    var t = Jr(regeneratorRuntime.mark((function t() {
                        var e, r = this;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = function() {
                                        return new Promise((function(t, e) {
                                            var n = r.$root._$extPanel.findAppWindow();
                                            n.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"), t, n, {
                                                yes: _T("common", "save"),
                                                no: _T("common", "cancel"),
                                                leftCustom: _T("common", "dont_save")
                                            })
                                        }))
                                    }, t.next = 3, e();
                                case 3:
                                    return t.abrupt("return", t.sent);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                isDirty: function() {
                    var t = Jr(regeneratorRuntime.mark((function t() {
                        var e;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = this.$refs.form, t.next = 3, e.isDirty();
                                case 3:
                                    return t.abrupt("return", t.sent);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        Xr = (r(168), d(Kr, Qr, [], !1, null, "c74d9942", null));
    Xr.options.__file = "src/dialogs/ImportProfileDialog.vue";
    var Zr = Xr.exports,
        tn = new Be.a.Store({
            devtools: !!location && location.search.includes("jsDebug"),
            modules: {
                profile: Pe
            }
        });
    r(170), r(172);
    Ext.namespace("SYNO.SDS.WebStation.Vue"), SYNO.SDS.WebStation.Vue.CustomErrorPage = o.a.extend({
        template: "<CustomErrorPage />",
        components: {
            CustomErrorPage: Vt
        },
        store: tn
    }), SYNO.SDS.WebStation.Vue.ServicePortalPage = o.a.extend({
        template: "<ServicePortalPage />",
        components: {
            ServicePortalPage: qe
        },
        store: tn
    }), SYNO.SDS.WebStation.Vue.CreateProfileDialog = o.a.extend({
        template: "<CreateProfileDialog />",
        components: {
            CreateProfileDialog: Fr
        },
        store: tn
    }), SYNO.SDS.WebStation.Vue.EditProfileDialog = o.a.extend({
        template: "<EditProfileDialog />",
        components: {
            EditProfileDialog: Vr
        },
        store: tn
    }), SYNO.SDS.WebStation.Vue.ImportProfileDialog = o.a.extend({
        template: "<ImportProfileDialog />",
        components: {
            ImportProfileDialog: Zr
        },
        store: tn
    }), Ext.namespace("SYNO.SDS.WebStation.Wizard"), SYNO.SDS.WebStation.Wizard.ServiceWizard = o.a.extend({
        template: "<ServiceWizard />",
        components: {
            ServiceWizard: ut
        },
        store: tn
    })
}]);
// @require: SYNO.SDS.WebStation.Vue.CreateProfileDialog
/**
 * @class SYNO.SDS.WebStation.Dialog.CreateProfile
 * @extends SYNO.SDS.ModalWindow
 * WebStation create profile class
 *
 */
Ext.define('SYNO.SDS.WebStation.Dialog.CreateProfile', {
    extend: 'SYNO.SDS.ModalWindow',
    constructor: function(_config) {
        this.vuePanel = this._generateVuePanel();

        var config = {
            title: _TT('SYNO.SDS.WebStation.Application', 'custom_error_page', 'create_profile'),
            layout: 'fit',
            cls: 'webstation-vue-modal',
            width: 795,
            autoHeight: true,
            resizable: false,
            collapsible: false,
            maximizable: false,
            items: [this.vuePanel],
            closeAction: "onCancel"
        };

        this.callParent([Ext.apply(config, _config)]);
    },
    _generateVuePanel: function() {
        return new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.WebStation.Vue.CreateProfileDialog,
            mountId: 'vue-custom-profile-dialog',
            owner: this,
            autoHeight: true,
        });
    },
    onCancel: function() {
        this.vuePanel.components[0].$children[0].$children[0].cancel();
    }
});
// @require: SYNO.SDS.WebStation.Vue.EditProfileDialog
Ext.define('SYNO.SDS.WebStation.Dialog.EditProfile', {
    extend: 'SYNO.SDS.ModalWindow',
    constructor: function(_config) {
        this.vuePanel = this._generateVuePanel();

        var config = {
            title: _TT('SYNO.SDS.WebStation.Application', 'custom_error_page', 'edit_profile'),
            layout: 'fit',
            cls: 'webstation-vue-modal',
            width: 795,
            autoHeight: true,
            resizable: false,
            collapsible: false,
            maximizable: false,
            items: [this.vuePanel],
            closeAction: "onCancel"
        };

        this.callParent([Ext.apply(config, _config)]);
    },
    _generateVuePanel: function() {
        return new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.WebStation.Vue.EditProfileDialog,
            owner: this,
            autoHeight: true,
        });
    },
    onCancel: function() {
        this.vuePanel.components[0].$children[0].$children[0].cancel();
    }
});
// @require: SYNO.SDS.WebStation.Vue.ImportProfileDialog
Ext.define('SYNO.SDS.WebStation.Dialog.ImportProfile', {
    extend: 'SYNO.SDS.ModalWindow',
    constructor: function(_config) {
        this.vuePanel = this._generateVuePanel();

        var config = {
            title: _TT('SYNO.SDS.WebStation.Application', 'custom_error_page', 'select_file_to_import'),
            layout: 'fit',
            cls: 'webstation-vue-modal',
            width: 550,
            autoHeight: true,
            resizable: false,
            collapsible: false,
            maximizable: false,
            items: [this.vuePanel],
            closeAction: "onCancel"
        };

        this.callParent([Ext.apply(config, _config)]);
    },
    _generateVuePanel: function() {
        return new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.WebStation.Vue.ImportProfileDialog,
            owner: this,
            autoHeight: true,
        });
    },
    onCancel: function() {
        this.vuePanel.components[0].$children[0].cancel();
    }
});
