/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/*


 SoundManager 2: JavaScript Sound for the Web
 ----------------------------------------------
 http://schillmania.com/projects/soundmanager2/

 Copyright (c) 2007, Scott Schiller. All rights reserved.
 Code provided under the BSD License:
 http://schillmania.com/projects/soundmanager2/license.txt

 V2.97a.20170601
*/
Ext.namespace("com.schillmania");
com.schillmania.SoundManager = true;
(function(o, j) {
    function Z(qa, W) {
        function ra(c) {
            return b.preferFlash && O && !b.ignoreFlash && b.flash[c] !== j && b.flash[c]
        }

        function z(c) {
            return function(a) {
                var d = this._s;
                if (!d || !d._a) {
                    d && d.id ? b._wD(d.id + ": Ignoring " + a.type) : b._wD(Eb + "Ignoring " + a.type);
                    a = null
                } else a = c.call(this, a);
                return a
            }
        }
        this.setupOptions = {
            url: qa || null,
            flashVersion: 8,
            debugMode: true,
            debugFlash: false,
            useConsole: true,
            consoleOnly: true,
            waitForWindowLoad: false,
            bgColor: "#ffffff",
            useHighPerformance: false,
            flashPollingInterval: null,
            html5PollingInterval: null,
            flashLoadTimeout: 1E3,
            wmode: null,
            allowScriptAccess: "always",
            useFlashBlock: false,
            useHTML5Audio: true,
            forceUseGlobalHTML5Audio: false,
            ignoreMobileRestrictions: false,
            html5Test: /^(probably|maybe)$/i,
            preferFlash: false,
            noSWFCache: false,
            idPrefix: "sound"
        };
        this.defaultOptions = {
            autoLoad: false,
            autoPlay: false,
            from: null,
            loops: 1,
            onid3: null,
            onerror: null,
            onload: null,
            whileloading: null,
            onplay: null,
            onpause: null,
            onresume: null,
            whileplaying: null,
            onposition: null,
            onstop: null,
            onfinish: null,
            multiShot: true,
            multiShotEvents: false,
            position: null,
            pan: 0,
            playbackRate: 1,
            stream: true,
            to: null,
            type: null,
            usePolicyFile: false,
            volume: 100
        };
        this.flash9Options = {
            onfailure: null,
            isMovieStar: null,
            usePeakData: false,
            useWaveformData: false,
            useEQData: false,
            onbufferchange: null,
            ondataerror: null
        };
        this.movieStarOptions = {
            bufferTime: 3,
            serverURL: null,
            onconnect: null,
            duration: null
        };
        this.audioFormats = {
            mp3: {
                type: ['audio/mpeg; codecs="mp3"', "audio/mpeg", "audio/mp3", "audio/MPA", "audio/mpa-robust"],
                required: true
            },
            mp4: {
                related: ["m4a", "m4b"],
                type: ['audio/mp4; codecs="mp4a.40.2"',
                    "audio/x-m4a", "audio/MP4A-LATM", "audio/mpeg4-generic"
                ],
                required: false
            },
            ogg: {
                type: ["audio/ogg; codecs=vorbis"],
                required: false
            },
            opus: {
                type: ["audio/ogg; codecs=opus", "audio/opus"],
                required: false
            },
            wav: {
                type: ['audio/wav; codecs="1"', "audio/wav", "audio/wave", "audio/x-wav"],
                required: false
            },
            flac: {
                type: ["audio/flac"],
                required: false
            }
        };
        this.movieID = "sm2-container";
        this.id = W || "sm2movie";
        this.debugID = "soundmanager-debug";
        this.debugURLParam = /([#?&])debug=1/i;
        this.versionNumber = "V2.97a.20170601";
        this.altURL = this.movieURL =
            this.version = null;
        this.enabled = this.swfLoaded = false;
        this.oMC = null;
        this.sounds = {};
        this.soundIDs = [];
        this.didFlashBlock = this.muted = false;
        this.filePattern = null;
        this.filePatterns = {
            flash8: /\.mp3(\?.*)?$/i,
            flash9: /\.mp3(\?.*)?$/i
        };
        this.features = {
            buffering: false,
            peakData: false,
            waveformData: false,
            eqData: false,
            movieStar: false
        };
        this.sandbox = {
            type: null,
            types: {
                remote: "remote (domain-based) rules",
                localWithFile: "local with file access (no internet access)",
                localWithNetwork: "local with network (internet access only, no local access)",
                localTrusted: "local, trusted (local+internet access)"
            },
            description: null,
            noRemote: null,
            noLocal: null
        };
        this.html5 = {
            usingFlash: null
        };
        this.flash = {};
        this.ignoreFlash = this.html5Only = false;
        var ib, b = this,
            jb = null,
            p = null,
            Eb = "HTML5::",
            M, C = navigator.userAgent,
            sa = o.location.href.toString(),
            r = document,
            Ga, kb, Ha, s, P = [],
            Ia = true,
            K, ea = false,
            fa = false,
            x = false,
            F = false,
            ta = false,
            u, Fb = 0,
            ga, E, Ja, $, Ka, X, aa, ba, lb, La, Ma, Na, L, ua, Y, Oa, ha, va, wa, ca, mb, Pa, nb = ["log", "info", "warn", "error"],
            Qa, Ra, ob, ia = null,
            Sa = null,
            v, Ta, da, A, pb, xa, ya,
            S, w, ja = false,
            Ua = false,
            qb, rb, sb, za = 0,
            ka = null,
            Aa, T = [],
            la, G = null,
            tb, Ba, ma, ub, U, Ca, Va, vb, B, wb = Array.prototype.slice,
            H = false,
            Wa, O, Xa, xb, Q, yb, Ya, na, zb = 0,
            Za, $a = C.match(/(ipad|iphone|ipod)/i),
            ab = C.match(/android/i),
            V = C.match(/msie|trident/i),
            Gb = C.match(/webkit/i),
            Da = C.match(/safari/i) && !C.match(/chrome/i),
            bb = C.match(/opera/i),
            Ea = C.match(/(mobile|pre\/|xoom)/i) || $a || ab,
            cb = !sa.match(/usehtml5audio/i) && !sa.match(/sm2-ignorebadua/i) && Da && !C.match(/silk/i) && C.match(/OS\sX\s10_6_([3-7])/i),
            db = o.console !== j && console.log !==
            j,
            eb = r.hasFocus !== j ? r.hasFocus() : null,
            Fa = Da && (r.hasFocus === j || !r.hasFocus()),
            Ab = !Fa,
            Bb = /(mp3|mp4|mpa|m4a|m4b)/i,
            oa = r.location ? r.location.protocol.match(/http/i) : null,
            Hb = !oa ? "//" : "",
            Cb = /^\s*audio\/(?:x-)?(?:mpeg4|flv|mov|mp4|m4v|m4a|m4b|mp4v|3gp|3g2)\s*(?:$|;)/i,
            Db = ["mpeg4", "flv", "mov", "mp4", "m4v", "f4v", "m4a", "m4b", "mp4v", "3gp", "3g2"],
            Ib = new RegExp("\\.(" + Db.join("|") + ")(\\?.*)?$", "i");
        this.mimePattern = /^\s*audio\/(?:x-)?(?:mp(?:eg|3))\s*(?:$|;)/i;
        this.useAltURL = !oa;
        A = {
            swfBox: "sm2-object-box",
            swfDefault: "movieContainer",
            swfError: "swf_error",
            swfTimedout: "swf_timedout",
            swfLoaded: "swf_loaded",
            swfUnblocked: "swf_unblocked",
            sm2Debug: "sm2_debug",
            highPerf: "high_performance",
            flashDebug: "flash_debug"
        };
        ub = [null, "MEDIA_ERR_ABORTED", "MEDIA_ERR_NETWORK", "MEDIA_ERR_DECODE", "MEDIA_ERR_SRC_NOT_SUPPORTED"];
        this.hasHTML5 = function() {
            try {
                return Audio !== j && (bb && opera !== j && opera.version() < 10 ? new Audio(null) : new Audio).canPlayType !== j
            } catch (c) {
                return false
            }
        }();
        this.setup = function(c) {
            var a = !b.url;
            if (c !== j && x && G && b.ok() && (c.flashVersion !==
                    j || c.url !== j || c.html5Test !== j)) S(v("setupLate"));
            Ja(c);
            if (!H)
                if (Ea) {
                    if (!b.setupOptions.ignoreMobileRestrictions || b.setupOptions.forceUseGlobalHTML5Audio) {
                        T.push(L.globalHTML5);
                        H = true
                    }
                } else if (b.setupOptions.forceUseGlobalHTML5Audio) {
                T.push(L.globalHTML5);
                H = true
            }
            if (!Za && Ea)
                if (b.setupOptions.ignoreMobileRestrictions) T.push(L.ignoreMobile);
                else {
                    if (!b.setupOptions.useHTML5Audio || b.setupOptions.preferFlash) b._wD(L.mobileUA);
                    b.setupOptions.useHTML5Audio = true;
                    b.setupOptions.preferFlash = false;
                    if ($a) b.ignoreFlash =
                        true;
                    else if (ab && !C.match(/android\s2\.3/i) || !ab) {
                        b._wD(L.globalHTML5);
                        H = true
                    }
                } if (c) {
                a && ha && c.url !== j && b.beginDelayedInit();
                !ha && c.url !== j && r.readyState === "complete" && setTimeout(Y, 1)
            }
            Za = true;
            return b
        };
        this.supported = this.ok = function() {
            return G ? x && !F : b.useHTML5Audio && b.hasHTML5
        };
        this.getMovie = function(c) {
            return M(c) || r[c] || o[c]
        };
        this.createSound = function(c, a) {
            function d() {
                h = xa(h);
                b.sounds[h.id] = new ib(h);
                b.soundIDs.push(h.id);
                return b.sounds[h.id]
            }
            var g, h;
            g = null;
            g = "soundManager.createSound(): " + v(!x ?
                "notReady" : "notOK");
            if (!x || !b.ok()) {
                S(g);
                return false
            }
            if (a !== j) c = {
                id: c,
                url: a
            };
            h = E(c);
            h.url = Aa(h.url);
            if (h.id === j) h.id = b.setupOptions.idPrefix + zb++;
            h.id.toString().charAt(0).match(/^[0-9]$/) && b._wD("soundManager.createSound(): " + v("badID", h.id), 2);
            b._wD("soundManager.createSound(): " + h.id + (h.url ? " (" + h.url + ")" : ""), 1);
            if (w(h.id, true)) {
                b._wD("soundManager.createSound(): " + h.id + " exists", 1);
                return b.sounds[h.id]
            }
            if (Ba(h)) {
                g = d();
                b.html5Only || b._wD(h.id + ": Using HTML5");
                g._setup_html5(h)
            } else {
                if (b.html5Only) {
                    b._wD(h.id +
                        ": No HTML5 support for this sound, and no Flash. Exiting.");
                    return d()
                }
                if (b.html5.usingFlash && h.url && h.url.match(/data:/i)) {
                    b._wD(h.id + ": data: URIs not supported via Flash. Exiting.");
                    return d()
                }
                if (s > 8) {
                    if (h.isMovieStar === null) h.isMovieStar = !!(h.serverURL || (h.type ? h.type.match(Cb) : false) || h.url && h.url.match(Ib));
                    if (h.isMovieStar) {
                        b._wD("soundManager.createSound(): using MovieStar handling");
                        h.loops > 1 && u("noNSLoop")
                    }
                }
                h = ya(h, "soundManager.createSound(): ");
                g = d();
                if (s === 8) p._createSound(h.id, h.loops ||
                    1, h.usePolicyFile);
                else {
                    p._createSound(h.id, h.url, h.usePeakData, h.useWaveformData, h.useEQData, h.isMovieStar, h.isMovieStar ? h.bufferTime : false, h.loops || 1, h.serverURL, h.duration || null, h.autoPlay, true, h.autoLoad, h.usePolicyFile);
                    if (!h.serverURL) {
                        g.connected = true;
                        h.onconnect && h.onconnect.apply(g)
                    }
                }
                if (!h.serverURL && (h.autoLoad || h.autoPlay)) g.load(h)
            }!h.serverURL && h.autoPlay && g.play();
            return g
        };
        this.destroySound = function(c, a) {
            if (!w(c)) return false;
            var d = b.sounds[c],
                g;
            d.stop();
            d._iO = {};
            d.unload();
            for (g = 0; g <
                b.soundIDs.length; g++)
                if (b.soundIDs[g] === c) {
                    b.soundIDs.splice(g, 1);
                    break
                } a || d.destruct(true);
            delete b.sounds[c];
            return true
        };
        this.load = function(c, a) {
            if (!w(c)) return false;
            return b.sounds[c].load(a)
        };
        this.unload = function(c) {
            if (!w(c)) return false;
            return b.sounds[c].unload()
        };
        this.onposition = this.onPosition = function(c, a, d, g) {
            if (!w(c)) return false;
            return b.sounds[c].onposition(a, d, g)
        };
        this.clearOnPosition = function(c, a, d) {
            if (!w(c)) return false;
            return b.sounds[c].clearOnPosition(a, d)
        };
        this.start = this.play =
            function(c, a) {
                var d = null,
                    g = a && !(a instanceof Object);
                if (!x || !b.ok()) {
                    S("soundManager.play(): " + v(!x ? "notReady" : "notOK"));
                    return false
                }
                if (w(c, g)) {
                    if (g) a = {
                        url: a
                    }
                } else {
                    if (!g) return false;
                    if (g) a = {
                        url: a
                    };
                    if (a && a.url) {
                        b._wD('soundManager.play(): Attempting to create "' + c + '"', 1);
                        a.id = c;
                        d = b.createSound(a).play()
                    }
                }
                if (d === null) d = b.sounds[c].play(a);
                return d
            };
        this.setPlaybackRate = function(c, a, d) {
            if (!w(c)) return false;
            return b.sounds[c].setPlaybackRate(a, d)
        };
        this.setPosition = function(c, a) {
            if (!w(c)) return false;
            return b.sounds[c].setPosition(a)
        };
        this.stop = function(c) {
            if (!w(c)) return false;
            b._wD("soundManager.stop(" + c + ")", 1);
            return b.sounds[c].stop()
        };
        this.stopAll = function() {
            var c;
            b._wD("soundManager.stopAll()", 1);
            for (c in b.sounds) b.sounds.hasOwnProperty(c) && b.sounds[c].stop()
        };
        this.pause = function(c) {
            if (!w(c)) return false;
            return b.sounds[c].pause()
        };
        this.pauseAll = function() {
            var c;
            for (c = b.soundIDs.length - 1; c >= 0; c--) b.sounds[b.soundIDs[c]].pause()
        };
        this.resume = function(c) {
            if (!w(c)) return false;
            return b.sounds[c].resume()
        };
        this.resumeAll = function() {
            var c;
            for (c = b.soundIDs.length - 1; c >= 0; c--) b.sounds[b.soundIDs[c]].resume()
        };
        this.togglePause = function(c) {
            if (!w(c)) return false;
            return b.sounds[c].togglePause()
        };
        this.setPan = function(c, a) {
            if (!w(c)) return false;
            return b.sounds[c].setPan(a)
        };
        this.setVolume = function(c, a) {
            var d;
            if (c !== j && !isNaN(c) && a === j) {
                a = 0;
                for (d = b.soundIDs.length; a < d; a++) b.sounds[b.soundIDs[a]].setVolume(c);
                return false
            }
            if (!w(c)) return false;
            return b.sounds[c].setVolume(a)
        };
        this.mute = function(c) {
            var a = 0;
            if (c instanceof String) c = null;
            if (c) {
                if (!w(c)) return false;
                b._wD('soundManager.mute(): Muting "' + c + '"');
                return b.sounds[c].mute()
            } else {
                b._wD("soundManager.mute(): Muting all sounds");
                for (a = b.soundIDs.length - 1; a >= 0; a--) b.sounds[b.soundIDs[a]].mute();
                b.muted = true
            }
            return true
        };
        this.muteAll = function() {
            b.mute()
        };
        this.unmute = function(c) {
            if (c instanceof String) c = null;
            if (c) {
                if (!w(c)) return false;
                b._wD('soundManager.unmute(): Unmuting "' + c + '"');
                return b.sounds[c].unmute()
            } else {
                b._wD("soundManager.unmute(): Unmuting all sounds");
                for (c = b.soundIDs.length - 1; c >= 0; c--) b.sounds[b.soundIDs[c]].unmute();
                b.muted = false
            }
            return true
        };
        this.unmuteAll = function() {
            b.unmute()
        };
        this.toggleMute = function(c) {
            if (!w(c)) return false;
            return b.sounds[c].toggleMute()
        };
        this.getMemoryUse = function() {
            var c = 0;
            if (p && s !== 8) c = parseInt(p._getMemoryUse(), 10);
            return c
        };
        this.disable = function(c) {
            var a;
            if (c === j) c = false;
            if (F) return false;
            F = true;
            u("shutdown", 1);
            for (a = b.soundIDs.length - 1; a >= 0; a--) Qa(b.sounds[b.soundIDs[a]]);
            Qa(b);
            ga(c);
            B.remove(o, "load", aa);
            return true
        };
        this.canPlayMIME = function(c) {
            var a;
            if (b.hasHTML5) a = ma({
                type: c
            });
            if (!a && G) a = c && b.ok() ? !!((s > 8 ? c.match(Cb) : null) || c.match(b.mimePattern)) : null;
            return a
        };
        this.canPlayURL = function(c) {
            var a;
            if (b.hasHTML5) a = ma({
                url: c
            });
            if (!a && G) a = c && b.ok() ? !!c.match(b.filePattern) : null;
            return a
        };
        this.canPlayLink = function(c) {
            if (c.type !== j && c.type && b.canPlayMIME(c.type)) return true;
            return b.canPlayURL(c.href)
        };
        this.getSoundById = function(c, a) {
            if (!c) return null;
            var d = b.sounds[c];
            !d && !a && b._wD('soundManager.getSoundById(): Sound "' +
                c + '" not found.', 2);
            return d
        };
        this.onready = function(c, a) {
            var d = false;
            if (typeof c === "function") {
                x && b._wD(v("queue", "onready"));
                a || (a = o);
                Ka("onready", c, a);
                X();
                d = true
            } else throw v("needFunction", "onready");
            return d
        };
        this.ontimeout = function(c, a) {
            var d = false;
            if (typeof c === "function") {
                x && b._wD(v("queue", "ontimeout"));
                a || (a = o);
                Ka("ontimeout", c, a);
                X({
                    type: "ontimeout"
                });
                d = true
            } else throw v("needFunction", "ontimeout");
            return d
        };
        this._writeDebug = function(c, a) {
            var d, g;
            if (!b.setupOptions.debugMode) return false;
            if (db && b.useConsole) {
                if (a && typeof a === "object") console.log(c, a);
                else nb[a] !== j ? console[nb[a]](c) : console.log(c);
                if (b.consoleOnly) return true
            }
            d = M("soundmanager-debug");
            if (!d) return false;
            g = r.createElement("div");
            if (++Fb % 2 === 0) g.className = "sm2-alt";
            a = a === j ? 0 : parseInt(a, 10);
            g.appendChild(r.createTextNode(c));
            if (a) {
                if (a >= 2) g.style.fontWeight = "bold";
                if (a === 3) g.style.color = "#ff3333"
            }
            d.insertBefore(g, d.firstChild);
            return true
        };
        if (sa.indexOf("sm2-debug=alert") !== -1) this._writeDebug = function(c) {
            o.alert(c)
        };
        this._wD = this._writeDebug;
        this._debug = function() {
            var c, a;
            u("currentObj", 1);
            c = 0;
            for (a = b.soundIDs.length; c < a; c++) b.sounds[b.soundIDs[c]]._debug()
        };
        this.reboot = function(c, a) {
            if (b.soundIDs.length) b._wD("Destroying " + b.soundIDs.length + " SMSound object" + (b.soundIDs.length !== 1 ? "s" : "") + "...");
            var d, g;
            for (d = b.soundIDs.length - 1; d >= 0; d--) b.sounds[b.soundIDs[d]].destruct();
            if (p) try {
                if (V) Sa = p.innerHTML;
                ia = p.parentNode.removeChild(p)
            } catch (h) {
                u("badRemove", 2)
            }
            Sa = ia = G = p = null;
            b.enabled = ha = x = ja = Ua = ea = fa = F = H = b.swfLoaded =
                false;
            b.soundIDs = [];
            b.sounds = {};
            zb = 0;
            Za = false;
            if (c) P = [];
            else
                for (d in P)
                    if (P.hasOwnProperty(d)) {
                        c = 0;
                        for (g = P[d].length; c < g; c++) P[d][c].fired = false
                    } a || b._wD("soundManager: Rebooting...");
            b.html5 = {
                usingFlash: null
            };
            b.flash = {};
            b.html5Only = false;
            b.ignoreFlash = false;
            o.setTimeout(function() {
                a || b.beginDelayedInit()
            }, 20);
            return b
        };
        this.reset = function() {
            u("reset");
            return b.reboot(true, true)
        };
        this.getMoviePercent = function() {
            return p && "PercentLoaded" in p ? p.PercentLoaded() : null
        };
        this.beginDelayedInit = function() {
            ta =
                true;
            Y();
            setTimeout(function() {
                if (Ua) return false;
                wa();
                ua();
                return Ua = true
            }, 20);
            ba()
        };
        this.destruct = function() {
            b._wD("soundManager.destruct()");
            b.disable(true)
        };
        ib = function(c) {
            var a = this,
                d, g, h, t, k, n, q = false,
                y = [],
                I = 0,
                pa, D, J = null,
                N, fb;
            N = {
                duration: null,
                time: null
            };
            this.sID = this.id = c.id;
            this.url = c.url;
            this._iO = this.instanceOptions = this.options = E(c);
            this.pan = this.options.pan;
            this.volume = this.options.volume;
            this.isHTML5 = false;
            this._a = null;
            fb = !this.url;
            this.id3 = {};
            this._debug = function() {
                b._wD(a.id + ": Merged options:",
                    a.options)
            };
            this.load = function(e) {
                var f = null,
                    i;
                if (e !== j) a._iO = E(e, a.options);
                else {
                    e = a.options;
                    a._iO = e;
                    if (J && J !== a.url) {
                        u("manURL");
                        a._iO.url = a.url;
                        a.url = null
                    }
                }
                if (!a._iO.url) a._iO.url = a.url;
                a._iO.url = Aa(a._iO.url);
                i = a.instanceOptions = a._iO;
                b._wD(a.id + ": load (" + i.url + ")");
                if (!i.url && !a.url) {
                    b._wD(a.id + ": load(): url is unassigned. Exiting.", 2);
                    return a
                }!a.isHTML5 && s === 8 && !a.url && !i.autoPlay && b._wD(a.id + ": Flash 8 load() limitation: Wait for onload() before calling play().", 1);
                if (i.url === a.url && a.readyState !==
                    0 && a.readyState !== 2) {
                    u("onURL", 1);
                    a.readyState === 3 && i.onload && na(a, function() {
                        i.onload.apply(a, [!!a.duration])
                    });
                    return a
                }
                a.loaded = false;
                a.readyState = 1;
                a.playState = 0;
                a.id3 = {};
                if (Ba(i)) {
                    f = a._setup_html5(i);
                    if (f._called_load) b._wD(a.id + ": Ignoring request to load again");
                    else {
                        a._html5_canplay = false;
                        if (a.url !== i.url) {
                            b._wD(u("manURL") + ": " + i.url);
                            a._a.src = i.url;
                            a.setPosition(0)
                        }
                        a._a.autobuffer = "auto";
                        a._a.preload = "auto";
                        a._a._called_load = true
                    }
                } else {
                    if (b.html5Only) {
                        b._wD(a.id + ": No flash support. Exiting.");
                        return a
                    }
                    if (a._iO.url && a._iO.url.match(/data:/i)) {
                        b._wD(a.id + ": data: URIs not supported via Flash. Exiting.");
                        return a
                    }
                    try {
                        a.isHTML5 = false;
                        a._iO = ya(xa(i));
                        if (a._iO.autoPlay && (a._iO.position || a._iO.from)) {
                            b._wD(a.id + ": Disabling autoPlay because of non-zero offset case");
                            a._iO.autoPlay = false
                        }
                        i = a._iO;
                        s === 8 ? p._load(a.id, i.url, i.stream, i.autoPlay, i.usePolicyFile) : p._load(a.id, i.url, !!i.stream, !!i.autoPlay, i.loops || 1, !!i.autoLoad, i.usePolicyFile)
                    } catch (l) {
                        u("smError", 2);
                        K("onload", false);
                        ca({
                            type: "SMSOUND_LOAD_JS_EXCEPTION",
                            fatal: true
                        })
                    }
                }
                a.url = i.url;
                return a
            };
            this.unload = function() {
                if (a.readyState !== 0) {
                    b._wD(a.id + ": unload()");
                    if (a.isHTML5) {
                        t();
                        if (a._a) {
                            a._a.pause();
                            J = Ca(a._a)
                        }
                    } else s === 8 ? p._unload(a.id, "about:blank") : p._unload(a.id);
                    d()
                }
                return a
            };
            this.destruct = function(e) {
                b._wD(a.id + ": Destruct");
                if (a.isHTML5) {
                    t();
                    if (a._a) {
                        a._a.pause();
                        Ca(a._a);
                        H || h();
                        a._a._s = null;
                        a._a = null
                    }
                } else {
                    a._iO.onfailure = null;
                    p._destroySound(a.id)
                }
                e || b.destroySound(a.id, true)
            };
            this.start = this.play = function(e, f) {
                var i, l, m, R, gb;
                l = true;
                i = a.id +
                    ": play(): ";
                f = f === j ? true : f;
                e || (e = {});
                if (a.url) a._iO.url = a.url;
                a._iO = E(a._iO, a.options);
                a._iO = E(e, a._iO);
                a._iO.url = Aa(a._iO.url);
                a.instanceOptions = a._iO;
                if (!a.isHTML5 && a._iO.serverURL && !a.connected) {
                    if (!a.getAutoPlay()) {
                        b._wD(i + " Netstream not connected yet - setting autoPlay");
                        a.setAutoPlay(true)
                    }
                    return a
                }
                if (Ba(a._iO)) {
                    a._setup_html5(a._iO);
                    k()
                }
                if (a.playState === 1 && !a.paused) {
                    l = a._iO.multiShot;
                    if (!l) {
                        b._wD(i + "Already playing (one-shot)", 1);
                        a.isHTML5 && a.setPosition(a._iO.position);
                        return a
                    }
                    b._wD(i +
                        "Already playing (multi-shot)", 1)
                }
                if (e.url && e.url !== a.url)
                    if (!a.readyState && !a.isHTML5 && s === 8 && fb) fb = false;
                    else a.load(a._iO);
                if (a.loaded) b._wD(i.substr(0, i.lastIndexOf(":")));
                else if (a.readyState === 0) {
                    b._wD(i + "Attempting to load");
                    if (!a.isHTML5 && !b.html5Only) {
                        a._iO.autoPlay = true;
                        a.load(a._iO)
                    } else if (a.isHTML5) a.load(a._iO);
                    else {
                        b._wD(i + "Unsupported type. Exiting.");
                        return a
                    }
                    a.instanceOptions = a._iO
                } else if (a.readyState === 2) {
                    b._wD(i + "Could not load - exiting", 2);
                    return a
                } else b._wD(i + "Loading - attempting to play...");
                if (!a.isHTML5 && s === 9 && a.position > 0 && a.position === a.duration) {
                    b._wD(i + "Sound at end, resetting to position: 0");
                    e.position = 0
                }
                if (a.paused && a.position >= 0 && (!a._iO.serverURL || a.position > 0)) {
                    b._wD(i + "Resuming from paused state", 1);
                    a.resume()
                } else {
                    a._iO = E(e, a._iO);
                    if ((!a.isHTML5 && a._iO.position !== null && a._iO.position > 0 || a._iO.from !== null && a._iO.from > 0 || a._iO.to !== null) && a.instanceCount === 0 && a.playState === 0 && !a._iO.serverURL) {
                        l = function() {
                            a._iO = E(e, a._iO);
                            a.play(a._iO)
                        };
                        if (a.isHTML5 && !a._html5_canplay) {
                            b._wD(i +
                                "Beginning load for non-zero offset case");
                            a.load({
                                _oncanplay: l
                            })
                        } else if (!a.isHTML5 && !a.loaded && (!a.readyState || a.readyState !== 2)) {
                            b._wD(i + "Preloading for non-zero offset case");
                            a.load({
                                onload: l
                            })
                        }
                        a._iO = D()
                    }
                    if (!a.instanceCount || a._iO.multiShotEvents || a.isHTML5 && a._iO.multiShot && !H || !a.isHTML5 && s > 8 && !a.getAutoPlay()) a.instanceCount++;
                    a._iO.onposition && a.playState === 0 && n(a);
                    a.playState = 1;
                    a.paused = false;
                    a.position = a._iO.position !== j && !isNaN(a._iO.position) ? a._iO.position : 0;
                    if (!a.isHTML5) a._iO = ya(xa(a._iO));
                    if (a._iO.onplay && f) {
                        a._iO.onplay.apply(a);
                        q = true
                    }
                    a.setVolume(a._iO.volume, true);
                    a.setPan(a._iO.pan, true);
                    a._iO.playbackRate !== 1 && a.setPlaybackRate(a._iO.playbackRate);
                    if (a.isHTML5)
                        if (a.instanceCount < 2) {
                            k();
                            f = a._setup_html5();
                            a.setPosition(a._iO.position);
                            return f.play()
                        } else {
                            b._wD(a.id + ": Cloning Audio() for instance #" + a.instanceCount + "...");
                            m = new Audio(a._iO.url);
                            R = function() {
                                B.remove(m, "ended", R);
                                a._onfinish(a);
                                Ca(m);
                                m = null
                            };
                            gb = function() {
                                B.remove(m, "canplay", gb);
                                try {
                                    m.currentTime = a._iO.position /
                                        1E3
                                } catch (Jb) {
                                    S(a.id + ": multiShot play() failed to apply position of " + a._iO.position / 1E3)
                                }
                                m.play()
                            };
                            B.add(m, "ended", R);
                            if (a._iO.volume !== j) m.volume = Math.max(0, Math.min(1, a._iO.volume / 100));
                            if (a.muted) m.muted = true;
                            a._iO.position ? B.add(m, "canplay", gb) : m.play()
                        }
                    else {
                        l = p._start(a.id, a._iO.loops || 1, s === 9 ? a.position : a.position / 1E3, a._iO.multiShot || false);
                        if (s === 9 && !l) {
                            b._wD(i + "No sound hardware, or 32-sound ceiling hit", 2);
                            a._iO.onplayerror && a._iO.onplayerror.apply(a)
                        }
                    }
                }
                return a
            };
            this.stop = function(e) {
                var f =
                    a._iO;
                if (a.playState === 1) {
                    b._wD(a.id + ": stop()");
                    a._onbufferchange(0);
                    a._resetOnPosition(0);
                    a.paused = false;
                    if (!a.isHTML5) a.playState = 0;
                    pa();
                    f.to && a.clearOnPosition(f.to);
                    if (a.isHTML5) {
                        if (a._a) {
                            e = a.position;
                            a.setPosition(0);
                            a.position = e;
                            a._a.pause();
                            a.playState = 0;
                            a._onTimer();
                            t()
                        }
                    } else {
                        p._stop(a.id, e);
                        f.serverURL && a.unload()
                    }
                    a.instanceCount = 0;
                    a._iO = {};
                    f.onstop && f.onstop.apply(a)
                }
                return a
            };
            this.setAutoPlay = function(e) {
                b._wD(a.id + ": Autoplay turned " + (e ? "on" : "off"));
                a._iO.autoPlay = e;
                if (!a.isHTML5) {
                    p._setAutoPlay(a.id,
                        e);
                    if (e)
                        if (!a.instanceCount && a.readyState === 1) {
                            a.instanceCount++;
                            b._wD(a.id + ": Incremented instance count to " + a.instanceCount)
                        }
                }
            };
            this.getAutoPlay = function() {
                return a._iO.autoPlay
            };
            this.setPlaybackRate = function(e) {
                var f = Math.max(0.5, Math.min(4, e));
                f !== e && b._wD(a.id + ": setPlaybackRate(" + e + "): limiting rate to " + f, 2);
                if (a.isHTML5) try {
                    a._iO.playbackRate = f;
                    a._a.playbackRate = f
                } catch (i) {
                    b._wD(a.id + ": setPlaybackRate(" + f + ") failed: " + i.message, 2)
                }
                return a
            };
            this.setPosition = function(e) {
                if (e === j) e = 0;
                var f =
                    a.isHTML5 ? Math.max(e, 0) : Math.min(a.duration || a._iO.duration, Math.max(e, 0));
                a.position = f;
                e = a.position / 1E3;
                a._resetOnPosition(a.position);
                a._iO.position = f;
                if (a.isHTML5) {
                    if (a._a) {
                        if (a._html5_canplay) {
                            if (a._a.currentTime.toFixed(3) !== e.toFixed(3)) {
                                b._wD(a.id + ": setPosition(" + e + ")");
                                try {
                                    a._a.currentTime = e;
                                    if (a.playState === 0 || a.paused) a._a.pause()
                                } catch (i) {
                                    b._wD(a.id + ": setPosition(" + e + ") failed: " + i.message, 2)
                                }
                            }
                        } else if (e) {
                            b._wD(a.id + ": setPosition(" + e + "): Cannot seek yet, sound not ready", 2);
                            return a
                        }
                        a.paused &&
                            a._onTimer(true)
                    }
                } else {
                    e = s === 9 ? a.position : e;
                    if (a.readyState && a.readyState !== 2) p._setPosition(a.id, e, a.paused || !a.playState, a._iO.multiShot)
                }
                return a
            };
            this.pause = function(e) {
                if (a.paused || a.playState === 0 && a.readyState !== 1) return a;
                b._wD(a.id + ": pause()");
                a.paused = true;
                if (a.isHTML5) {
                    a._setup_html5().pause();
                    t()
                } else if (e || e === j) p._pause(a.id, a._iO.multiShot);
                a._iO.onpause && a._iO.onpause.apply(a);
                return a
            };
            this.resume = function() {
                var e = a._iO;
                if (!a.paused) return a;
                b._wD(a.id + ": resume()");
                a.paused = false;
                a.playState = 1;
                if (a.isHTML5) {
                    a._setup_html5().play();
                    k()
                } else {
                    e.isMovieStar && !e.serverURL && a.setPosition(a.position);
                    p._pause(a.id, e.multiShot)
                }
                if (!q && e.onplay) {
                    e.onplay.apply(a);
                    q = true
                } else e.onresume && e.onresume.apply(a);
                return a
            };
            this.togglePause = function() {
                b._wD(a.id + ": togglePause()");
                if (a.playState === 0) {
                    a.play({
                        position: s === 9 && !a.isHTML5 ? a.position : a.position / 1E3
                    });
                    return a
                }
                a.paused ? a.resume() : a.pause();
                return a
            };
            this.setPan = function(e, f) {
                if (e === j) e = 0;
                if (f === j) f = false;
                a.isHTML5 || p._setPan(a.id,
                    e);
                a._iO.pan = e;
                if (!f) {
                    a.pan = e;
                    a.options.pan = e
                }
                return a
            };
            this.setVolume = function(e, f) {
                if (e === j) e = 100;
                if (f === j) f = false;
                if (a.isHTML5) {
                    if (a._a) {
                        if (b.muted && !a.muted) {
                            a.muted = true;
                            a._a.muted = true
                        }
                        a._a.volume = Math.max(0, Math.min(1, e / 100))
                    }
                } else p._setVolume(a.id, b.muted && !a.muted || a.muted ? 0 : e);
                a._iO.volume = e;
                if (!f) {
                    a.volume = e;
                    a.options.volume = e
                }
                return a
            };
            this.mute = function() {
                a.muted = true;
                if (a.isHTML5) {
                    if (a._a) a._a.muted = true
                } else p._setVolume(a.id, 0);
                return a
            };
            this.unmute = function() {
                a.muted = false;
                var e =
                    a._iO.volume !== j;
                if (a.isHTML5) {
                    if (a._a) a._a.muted = false
                } else p._setVolume(a.id, e ? a._iO.volume : a.options.volume);
                return a
            };
            this.toggleMute = function() {
                return a.muted ? a.unmute() : a.mute()
            };
            this.onposition = this.onPosition = function(e, f, i) {
                y.push({
                    position: parseInt(e, 10),
                    method: f,
                    scope: i !== j ? i : a,
                    fired: false
                });
                return a
            };
            this.clearOnPosition = function(e, f) {
                var i;
                e = parseInt(e, 10);
                if (!isNaN(e))
                    for (i = 0; i < y.length; i++)
                        if (e === y[i].position)
                            if (!f || f === y[i].method) {
                                y[i].fired && I--;
                                y.splice(i, 1)
                            }
            };
            this._processOnPosition =
                function() {
                    var e, f;
                    e = y.length;
                    if (!e || !a.playState || I >= e) return false;
                    for (e = e - 1; e >= 0; e--) {
                        f = y[e];
                        if (!f.fired && a.position >= f.position) {
                            f.fired = true;
                            I++;
                            f.method.apply(f.scope, [f.position])
                        }
                    }
                    return true
                };
            this._resetOnPosition = function(e) {
                var f, i;
                f = y.length;
                if (!f) return false;
                for (f = f - 1; f >= 0; f--) {
                    i = y[f];
                    if (i.fired && e <= i.position) {
                        i.fired = false;
                        I--
                    }
                }
                return true
            };
            D = function() {
                var e = a._iO,
                    f = e.from,
                    i = e.to,
                    l, m;
                m = function() {
                    b._wD(a.id + ': "To" time of ' + i + " reached.");
                    a.clearOnPosition(i, m);
                    a.stop()
                };
                l = function() {
                    b._wD(a.id +
                        ': Playing "from" ' + f);
                    i !== null && !isNaN(i) && a.onPosition(i, m)
                };
                if (f !== null && !isNaN(f)) {
                    e.position = f;
                    e.multiShot = false;
                    l()
                }
                return e
            };
            n = function() {
                var e, f = a._iO.onposition;
                if (f)
                    for (e in f) f.hasOwnProperty(e) && a.onPosition(parseInt(e, 10), f[e])
            };
            pa = function() {
                var e, f = a._iO.onposition;
                if (f)
                    for (e in f) f.hasOwnProperty(e) && a.clearOnPosition(parseInt(e, 10))
            };
            k = function() {
                a.isHTML5 && qb(a)
            };
            t = function() {
                a.isHTML5 && rb(a)
            };
            d = function(e) {
                if (!e) {
                    y = [];
                    I = 0
                }
                q = false;
                a._hasTimer = null;
                a._a = null;
                a._html5_canplay = false;
                a.bytesLoaded = null;
                a.bytesTotal = null;
                a.duration = a._iO && a._iO.duration ? a._iO.duration : null;
                a.durationEstimate = null;
                a.buffered = [];
                a.eqData = [];
                a.eqData.left = [];
                a.eqData.right = [];
                a.failures = 0;
                a.isBuffering = false;
                a.instanceOptions = {};
                a.instanceCount = 0;
                a.loaded = false;
                a.metadata = {};
                a.readyState = 0;
                a.muted = false;
                a.paused = false;
                a.peakData = {
                    left: 0,
                    right: 0
                };
                a.waveformData = {
                    left: [],
                    right: []
                };
                a.playState = 0;
                a.position = null;
                a.id3 = {}
            };
            d();
            this._onTimer = function(e) {
                var f, i = false,
                    l = {};
                if (a._hasTimer || e)
                    if (a._a && (e ||
                            (a.playState > 0 || a.readyState === 1) && !a.paused)) {
                        f = a._get_html5_duration();
                        if (f !== N.duration) {
                            N.duration = f;
                            a.duration = f;
                            i = true
                        }
                        a.durationEstimate = a.duration;
                        f = a._a.currentTime * 1E3 || 0;
                        if (f !== N.time) {
                            N.time = f;
                            i = true
                        }
                        if (i || e) a._whileplaying(f, l, l, l, l)
                    } return i
            };
            this._get_html5_duration = function() {
                var e = a._iO;
                return (e = a._a && a._a.duration ? a._a.duration * 1E3 : e && e.duration ? e.duration : null) && !isNaN(e) && e !== Infinity ? e : null
            };
            this._apply_loop = function(e, f) {
                !e.loop && f > 1 && b._wD("Note: Native HTML5 looping is infinite.",
                    1);
                e.loop = f > 1 ? "loop" : ""
            };
            this._setup_html5 = function(e) {
                e = E(a._iO, e);
                var f = H ? jb : a._a,
                    i = decodeURI(e.url),
                    l;
                if (H) {
                    if (i === decodeURI(Wa)) l = true
                } else if (i === decodeURI(J)) l = true;
                if (f) {
                    if (f._s)
                        if (H) f._s && f._s.playState && !l && f._s.stop();
                        else if (!H && i === decodeURI(J)) {
                        a._apply_loop(f, e.loops);
                        return f
                    }
                    if (!l) {
                        J && d(false);
                        f.src = e.url;
                        Wa = J = a.url = e.url;
                        f._called_load = false
                    }
                } else {
                    if (e.autoLoad || e.autoPlay) {
                        a._a = new Audio(e.url);
                        a._a.load()
                    } else a._a = bb && opera.version() < 10 ? new Audio(null) : new Audio;
                    f = a._a;
                    f._called_load =
                        false;
                    if (H) jb = f
                }
                a.isHTML5 = true;
                a._a = f;
                f._s = a;
                g();
                a._apply_loop(f, e.loops);
                if (e.autoLoad || e.autoPlay) a.load();
                else {
                    f.autobuffer = false;
                    f.preload = "auto"
                }
                return f
            };
            g = function() {
                function e(i, l, m) {
                    return a._a ? a._a.addEventListener(i, l, m || false) : null
                }
                if (a._a._added_events) return false;
                var f;
                a._a._added_events = true;
                for (f in Q) Q.hasOwnProperty(f) && e(f, Q[f]);
                return true
            };
            h = function() {
                function e(i, l, m) {
                    return a._a ? a._a.removeEventListener(i, l, m || false) : null
                }
                var f;
                b._wD(a.id + ": Removing event listeners");
                a._a._added_events =
                    false;
                for (f in Q) Q.hasOwnProperty(f) && e(f, Q[f])
            };
            this._onload = function(e) {
                var f = !!e || !a.isHTML5 && s === 8 && a.duration;
                e = a.id + ": ";
                b._wD(e + (f ? "onload()" : "Failed to load / invalid sound?" + (!a.duration ? " Zero-length duration reported." : " -") + " (" + a.url + ")"), f ? 1 : 2);
                if (!f && !a.isHTML5) {
                    b.sandbox.noRemote === true && b._wD(e + v("noNet"), 1);
                    b.sandbox.noLocal === true && b._wD(e + v("noLocal"), 1)
                }
                a.loaded = f;
                a.readyState = f ? 3 : 2;
                a._onbufferchange(0);
                !f && !a.isHTML5 && a._onerror();
                a._iO.onload && na(a, function() {
                    a._iO.onload.apply(a,
                        [f])
                });
                return true
            };
            this._onerror = function(e, f) {
                a._iO.onerror && na(a, function() {
                    a._iO.onerror.apply(a, [e, f])
                })
            };
            this._onbufferchange = function(e) {
                if (a.playState === 0) return false;
                if (e && a.isBuffering || !e && !a.isBuffering) return false;
                a.isBuffering = e === 1;
                if (a._iO.onbufferchange) {
                    b._wD(a.id + ": Buffer state change: " + e);
                    a._iO.onbufferchange.apply(a, [e])
                }
                return true
            };
            this._onsuspend = function() {
                if (a._iO.onsuspend) {
                    b._wD(a.id + ": Playback suspended");
                    a._iO.onsuspend.apply(a)
                }
                return true
            };
            this._onfailure = function(e,
                f, i) {
                a.failures++;
                b._wD(a.id + ": Failure (" + a.failures + "): " + e);
                a._iO.onfailure && a.failures === 1 ? a._iO.onfailure(e, f, i) : b._wD(a.id + ": Ignoring failure")
            };
            this._onwarning = function(e, f, i) {
                a._iO.onwarning && a._iO.onwarning(e, f, i)
            };
            this._onfinish = function() {
                var e = a._iO.onfinish;
                a._onbufferchange(0);
                a._resetOnPosition(0);
                if (a.instanceCount) {
                    a.instanceCount--;
                    if (!a.instanceCount) {
                        pa();
                        a.playState = 0;
                        a.paused = false;
                        a.instanceCount = 0;
                        a.instanceOptions = {};
                        a._iO = {};
                        t();
                        if (a.isHTML5) a.position = 0
                    }
                    if (!a.instanceCount ||
                        a._iO.multiShotEvents)
                        if (e) {
                            b._wD(a.id + ": onfinish()");
                            na(a, function() {
                                e.apply(a)
                            })
                        }
                }
            };
            this._whileloading = function(e, f, i, l) {
                var m = a._iO;
                a.bytesLoaded = e;
                a.bytesTotal = f;
                a.duration = Math.floor(i);
                a.bufferLength = l;
                a.durationEstimate = !a.isHTML5 && !m.isMovieStar ? m.duration ? a.duration > m.duration ? a.duration : m.duration : parseInt(a.bytesTotal / a.bytesLoaded * a.duration, 10) : a.duration;
                if (!a.isHTML5) a.buffered = [{
                    start: 0,
                    end: a.duration
                }];
                if ((a.readyState !== 3 || a.isHTML5) && m.whileloading) m.whileloading.apply(a)
            };
            this._whileplaying =
                function(e, f, i, l, m) {
                    var R = a._iO;
                    if (isNaN(e) || e === null) return false;
                    a.position = Math.max(0, e);
                    a._processOnPosition();
                    if (!a.isHTML5 && s > 8) {
                        if (R.usePeakData && f !== j && f) a.peakData = {
                            left: f.leftPeak,
                            right: f.rightPeak
                        };
                        if (R.useWaveformData && i !== j && i) a.waveformData = {
                            left: i.split(","),
                            right: l.split(",")
                        };
                        if (R.useEQData)
                            if (m !== j && m && m.leftEQ) {
                                e = m.leftEQ.split(",");
                                a.eqData = e;
                                a.eqData.left = e;
                                if (m.rightEQ !== j && m.rightEQ) a.eqData.right = m.rightEQ.split(",")
                            }
                    }
                    if (a.playState === 1) {
                        !a.isHTML5 && s === 8 && !a.position && a.isBuffering &&
                            a._onbufferchange(0);
                        R.whileplaying && R.whileplaying.apply(a)
                    }
                    return true
                };
            this._oncaptiondata = function(e) {
                b._wD(a.id + ": Caption data received.");
                a.captiondata = e;
                a._iO.oncaptiondata && a._iO.oncaptiondata.apply(a, [e])
            };
            this._onmetadata = function(e, f) {
                b._wD(a.id + ": Metadata received.");
                var i = {},
                    l, m;
                l = 0;
                for (m = e.length; l < m; l++) i[e[l]] = f[l];
                a.metadata = i;
                a._iO.onmetadata && a._iO.onmetadata.call(a, a.metadata)
            };
            this._onid3 = function(e, f) {
                b._wD(a.id + ": ID3 data received.");
                var i = [],
                    l, m;
                l = 0;
                for (m = e.length; l < m; l++) i[e[l]] =
                    f[l];
                a.id3 = E(a.id3, i);
                a._iO.onid3 && a._iO.onid3.apply(a)
            };
            this._onconnect = function(e) {
                e = e === 1;
                b._wD(a.id + ": " + (e ? "Connected." : "Failed to connect? - " + a.url), e ? 1 : 2);
                if (a.connected = e) {
                    a.failures = 0;
                    if (w(a.id))
                        if (a.getAutoPlay()) a.play(j, a.getAutoPlay());
                        else a._iO.autoLoad && a.load();
                    a._iO.onconnect && a._iO.onconnect.apply(a, [e])
                }
            };
            this._ondataerror = function(e) {
                if (a.playState > 0) {
                    b._wD(a.id + ": Data error: " + e);
                    a._iO.ondataerror && a._iO.ondataerror.apply(a)
                }
            };
            this._debug()
        };
        va = function() {
            return r.body || r.getElementsByTagName("div")[0]
        };
        M = function(c) {
            return r.getElementById(c)
        };
        E = function(c, a) {
            c = c || {};
            var d;
            a = a === j ? b.defaultOptions : a;
            for (d in a)
                if (a.hasOwnProperty(d) && c[d] === j) c[d] = typeof a[d] !== "object" || a[d] === null ? a[d] : E(c[d], a[d]);
            return c
        };
        na = function(c, a) {
            !c.isHTML5 && s === 8 ? o.setTimeout(a, 0) : a()
        };
        $ = {
            onready: 1,
            ontimeout: 1,
            defaultOptions: 1,
            flash9Options: 1,
            movieStarOptions: 1
        };
        Ja = function(c, a) {
            var d, g = true,
                h = a !== j,
                t = b.setupOptions;
            if (c === j) {
                g = [];
                for (d in t) t.hasOwnProperty(d) && g.push(d);
                for (d in $)
                    if ($.hasOwnProperty(d))
                        if (typeof b[d] ===
                            "object") g.push(d + ": {...}");
                        else b[d] instanceof Function ? g.push(d + ": function() {...}") : g.push(d);
                b._wD(v("setup", g.join(", ")));
                return false
            }
            for (d in c)
                if (c.hasOwnProperty(d))
                    if (typeof c[d] !== "object" || c[d] === null || c[d] instanceof Array || c[d] instanceof RegExp)
                        if (h && $[a] !== j) b[a][d] = c[d];
                        else if (t[d] !== j) {
                b.setupOptions[d] = c[d];
                b[d] = c[d]
            } else if ($[d] === j) {
                S(v(b[d] === j ? "setupUndef" : "setupError", d), 2);
                g = false
            } else if (b[d] instanceof Function) b[d].apply(b, c[d] instanceof Array ? c[d] : [c[d]]);
            else b[d] = c[d];
            else if ($[d] === j) {
                S(v(b[d] === j ? "setupUndef" : "setupError", d), 2);
                g = false
            } else return Ja(c[d], d);
            return g
        };
        B = function() {
            function c(k) {
                k = wb.call(k);
                var n = k.length;
                if (h) {
                    k[1] = "on" + k[1];
                    n > 3 && k.pop()
                } else n === 3 && k.push(false);
                return k
            }

            function a(k, n) {
                var q = k.shift();
                n = [t[n]];
                h ? q[n](k[0], k[1]) : q[n].apply(q, k)
            }

            function d() {
                a(c(arguments), "add")
            }

            function g() {
                a(c(arguments), "remove")
            }
            var h = o.attachEvent,
                t = {
                    add: h ? "attachEvent" : "addEventListener",
                    remove: h ? "detachEvent" : "removeEventListener"
                };
            return {
                add: d,
                remove: g
            }
        }();
        Q = {
            abort: z(function() {
                b._wD(this._s.id + ": abort")
            }),
            canplay: z(function() {
                var c = this._s,
                    a;
                if (!c._html5_canplay) {
                    c._html5_canplay = true;
                    b._wD(c.id + ": canplay");
                    c._onbufferchange(0);
                    a = c._iO.position !== j && !isNaN(c._iO.position) ? c._iO.position / 1E3 : null;
                    if (this.currentTime !== a) {
                        b._wD(c.id + ": canplay: Setting position to " + a);
                        try {
                            this.currentTime = a
                        } catch (d) {
                            b._wD(c.id + ": canplay: Setting position of " + a + " failed: " + d.message, 2)
                        }
                    }
                    c._iO._oncanplay && c._iO._oncanplay()
                }
            }),
            canplaythrough: z(function() {
                var c = this._s;
                if (!c.loaded) {
                    c._onbufferchange(0);
                    c._whileloading(c.bytesLoaded, c.bytesTotal, c._get_html5_duration());
                    c._onload(true)
                }
            }),
            durationchange: z(function() {
                var c = this._s,
                    a;
                a = c._get_html5_duration();
                if (!isNaN(a) && a !== c.duration) {
                    b._wD(this._s.id + ": durationchange (" + a + ")" + (c.duration ? ", previously " + c.duration : ""));
                    c.durationEstimate = c.duration = a
                }
            }),
            ended: z(function() {
                var c = this._s;
                b._wD(c.id + ": ended");
                c._onfinish()
            }),
            error: z(function() {
                var c = ub[this.error.code] || null;
                b._wD(this._s.id + ": HTML5 error, code " +
                    this.error.code + (c ? " (" + c + ")" : ""));
                this._s._onload(false);
                this._s._onerror(this.error.code, c)
            }),
            loadeddata: z(function() {
                var c = this._s;
                b._wD(c.id + ": loadeddata");
                if (!c._loaded && !Da) c.duration = c._get_html5_duration()
            }),
            loadedmetadata: z(function() {
                b._wD(this._s.id + ": loadedmetadata")
            }),
            loadstart: z(function() {
                b._wD(this._s.id + ": loadstart");
                this._s._onbufferchange(1)
            }),
            play: z(function() {
                this._s._onbufferchange(0)
            }),
            playing: z(function() {
                b._wD(this._s.id + ": playing " + String.fromCharCode(9835));
                this._s._onbufferchange(0)
            }),
            progress: z(function(c) {
                var a = this._s,
                    d, g, h;
                d = 0;
                var t = c.type === "progress",
                    k = c.target.buffered,
                    n = c.loaded || 0,
                    q = c.total || 1;
                a.buffered = [];
                if (k && k.length) {
                    d = 0;
                    for (g = k.length; d < g; d++) a.buffered.push({
                        start: k.start(d) * 1E3,
                        end: k.end(d) * 1E3
                    });
                    d = (k.end(0) - k.start(0)) * 1E3;
                    n = Math.min(1, d / (c.target.duration * 1E3));
                    if (t && k.length > 1) {
                        h = [];
                        g = k.length;
                        for (d = 0; d < g; d++) h.push(c.target.buffered.start(d) * 1E3 + "-" + c.target.buffered.end(d) * 1E3);
                        b._wD(this._s.id + ": progress, timeRanges: " + h.join(", "))
                    }
                    t && !isNaN(n) && b._wD(this._s.id +
                        ": progress, " + Math.floor(n * 100) + "% loaded")
                }
                if (!isNaN(n)) {
                    a._whileloading(n, q, a._get_html5_duration());
                    n && q && n === q && Q.canplaythrough.call(this, c)
                }
            }),
            ratechange: z(function() {
                b._wD(this._s.id + ": ratechange")
            }),
            suspend: z(function(c) {
                var a = this._s;
                b._wD(this._s.id + ": suspend");
                Q.progress.call(this, c);
                a._onsuspend()
            }),
            stalled: z(function() {
                b._wD(this._s.id + ": stalled")
            }),
            timeupdate: z(function() {
                this._s._onTimer()
            }),
            waiting: z(function() {
                var c = this._s;
                b._wD(this._s.id + ": waiting");
                c._onbufferchange(1)
            })
        };
        Ba = function(c) {
            return !c || !c.type && !c.url && !c.serverURL ? false : c.serverURL || c.type && ra(c.type) ? false : c.type ? ma({
                type: c.type
            }) : ma({
                url: c.url
            }) || b.html5Only || c.url.match(/data:/i)
        };
        Ca = function(c) {
            var a;
            if (c) {
                a = Da ? "about:blank" : b.html5.canPlayType("audio/wav") ? "data:audio/wave;base64,/UklGRiYAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQIAAAD//w==" : "about:blank";
                c.src = a;
                if (c._called_unload !== j) c._called_load = false
            }
            if (H) Wa = null;
            return a
        };
        ma = function(c) {
            if (!b.useHTML5Audio || !b.hasHTML5) return false;
            var a =
                c.url || null;
            c = c.type || null;
            var d = b.audioFormats,
                g;
            if (c && b.html5[c] !== j) return b.html5[c] && !ra(c);
            if (!U) {
                U = [];
                for (g in d)
                    if (d.hasOwnProperty(g)) {
                        U.push(g);
                        if (d[g].related) U = U.concat(d[g].related)
                    } U = new RegExp("\\.(" + U.join("|") + ")(\\?.*)?$", "i")
            }
            g = a ? a.toLowerCase().match(U) : null;
            if (!g || !g.length) {
                if (c) {
                    a = c.indexOf(";");
                    g = (a !== -1 ? c.substr(0, a) : c).substr(6)
                }
            } else g = g[1];
            if (g && b.html5[g] !== j) a = b.html5[g] && !ra(g);
            else {
                c = "audio/" + g;
                a = b.html5.canPlayType({
                    type: c
                });
                a = (b.html5[g] = a) && b.html5[c] && !ra(c)
            }
            return a
        };
        vb = function() {
            function c(n) {
                var q;
                var y = q = false;
                if (!a || typeof a.canPlayType !== "function") return q;
                if (n instanceof Array) {
                    k = 0;
                    for (q = n.length; k < q; k++)
                        if (b.html5[n[k]] || a.canPlayType(n[k]).match(b.html5Test)) {
                            y = true;
                            b.html5[n[k]] = true;
                            b.flash[n[k]] = !!n[k].match(Bb)
                        } q = y
                } else {
                    n = a && typeof a.canPlayType === "function" ? a.canPlayType(n) : false;
                    q = !!(n && n.match(b.html5Test))
                }
                return q
            }
            if (!b.useHTML5Audio || !b.hasHTML5) {
                G = b.html5.usingFlash = true;
                return false
            }
            var a = Audio !== j ? bb && opera.version() < 10 ? new Audio(null) :
                new Audio : null,
                d, g, h = {},
                t, k;
            t = b.audioFormats;
            for (d in t)
                if (t.hasOwnProperty(d)) {
                    g = "audio/" + d;
                    h[d] = c(t[d].type);
                    h[g] = h[d];
                    if (d.match(Bb)) {
                        b.flash[d] = true;
                        b.flash[g] = true
                    } else {
                        b.flash[d] = false;
                        b.flash[g] = false
                    }
                    if (t[d] && t[d].related)
                        for (k = t[d].related.length - 1; k >= 0; k--) {
                            h["audio/" + t[d].related[k]] = h[d];
                            b.html5[t[d].related[k]] = h[d];
                            b.flash[t[d].related[k]] = h[d]
                        }
                } h.canPlayType = a ? c : null;
            b.html5 = E(b.html5, h);
            b.html5.usingFlash = tb();
            G = b.html5.usingFlash;
            return true
        };
        L = {
            notReady: "Unavailable - wait until onready() has fired.",
            notOK: "Audio support is not available.",
            domError: "soundManagerexception caught while appending SWF to DOM.",
            spcWmode: "Removing wmode, preventing known SWF loading issue(s)",
            swf404: "soundManager: Verify that %s is a valid path.",
            tryDebug: "Try soundManager.debugFlash = true for more security details (output goes to SWF.)",
            checkSWF: "See SWF output for more debug info.",
            localFail: "soundManager: Non-HTTP page (" + r.location.protocol + " URL?) Review Flash player security settings for this special case:\nhttp://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager04.html\nMay need to add/allow path, eg. c:/sm2/ or /users/me/sm2/",
            waitFocus: "soundManager: Special case: Waiting for SWF to load with window focus...",
            waitForever: "soundManager: Waiting indefinitely for Flash (will recover if unblocked)...",
            waitSWF: "soundManager: Waiting for 100% SWF load...",
            needFunction: "soundManager: Function object expected for %s",
            badID: 'Sound ID "%s" should be a string, starting with a non-numeric character',
            currentObj: "soundManager: _debug(): Current sound objects",
            waitOnload: "soundManager: Waiting for window.onload()",
            docLoaded: "soundManager: Document already loaded",
            onload: "soundManager: initComplete(): calling soundManager.onload()",
            onloadOK: "soundManager.onload() complete",
            didInit: "soundManager: init(): Already called?",
            secNote: "Flash security note: Network/internet URLs will not load due to security restrictions. Access can be configured via Flash Player Global Security Settings Page: http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager04.html",
            badRemove: "soundManager: Failed to remove Flash node.",
            shutdown: "soundManager.disable(): Shutting down",
            queue: "soundManager: Queueing %s handler",
            smError: "SMSound.load(): Exception: JS-Flash communication failed, or JS error.",
            fbTimeout: "No flash response, applying ." + A.swfTimedout + " CSS...",
            fbLoaded: "Flash loaded",
            fbHandler: "soundManager: flashBlockHandler()",
            manURL: "SMSound.load(): Using manually-assigned URL",
            onURL: "soundManager.load(): current URL already assigned.",
            badFV: 'soundManager.flashVersion must be 8 or 9. "%s" is invalid. Reverting to %s.',
            as2loop: "Note: Setting stream:false so looping can work (flash 8 limitation)",
            noNSLoop: "Note: Looping not implemented for MovieStar formats",
            needfl9: "Note: Switching to flash 9, required for MP4 formats.",
            mfTimeout: "Setting flashLoadTimeout = 0 (infinite) for off-screen, mobile flash case",
            needFlash: "soundManager: Fatal error: Flash is needed to play some required formats, but is not available.",
            gotFocus: "soundManager: Got window focus.",
            policy: "Enabling usePolicyFile for data access",
            setup: "soundManager.setup(): allowed parameters: %s",
            setupError: 'soundManager.setup(): "%s" cannot be assigned with this method.',
            setupUndef: 'soundManager.setup(): Could not find option "%s"',
            setupLate: "soundManager.setup(): url, flashVersion and html5Test property changes will not take effect until reboot().",
            noURL: "soundManager: Flash URL required. Call soundManager.setup({url:...}) to get started.",
            sm2Loaded: "SoundManager 2: Ready. " + String.fromCharCode(10003),
            reset: "soundManager.reset(): Removing event callbacks",
            mobileUA: "Mobile UA detected, preferring HTML5 by default.",
            globalHTML5: "Using singleton HTML5 Audio() pattern for this device.",
            ignoreMobile: "Ignoring mobile restrictions for this device."
        };
        v = function() {
            var c, a, d, g;
            c = wb.call(arguments);
            a = c.shift();
            if ((g = L && L[a] ? L[a] : "") && c && c.length) {
                a = 0;
                for (d = c.length; a < d; a++) g = g.replace("%s", c[a])
            }
            return g
        };
        xa = function(c) {
            if (s === 8 && c.loops > 1 && c.stream) {
                u("as2loop");
                c.stream = false
            }
            return c
        };
        ya = function(c, a) {
            if (c && !c.usePolicyFile && (c.onid3 || c.usePeakData || c.useWaveformData || c.useEQData)) {
                b._wD((a || "") + v("policy"));
                c.usePolicyFile = true
            }
            return c
        };
        S = function(c) {
            db && console.warn !== j ? console.warn(c) :
                b._wD(c)
        };
        Ga = function() {
            return false
        };
        Qa = function(c) {
            var a;
            for (a in c)
                if (c.hasOwnProperty(a) && typeof c[a] === "function") c[a] = Ga
        };
        Ra = function(c) {
            if (c === j) c = false;
            if (F || c) b.disable(c)
        };
        ob = function(c) {
            var a = null;
            if (c)
                if (c.match(/\.swf(\?.*)?$/i)) {
                    if (a = c.substr(c.toLowerCase().lastIndexOf(".swf?") + 4)) return c
                } else if (c.lastIndexOf("/") !== c.length - 1) c += "/";
            c = (c && c.lastIndexOf("/") !== -1 ? c.substr(0, c.lastIndexOf("/") + 1) : "./") + b.movieURL;
            if (b.noSWFCache) c += "?ts=" + (new Date).getTime();
            return c
        };
        Ma = function() {
            s =
                parseInt(b.flashVersion, 10);
            if (s !== 8 && s !== 9) {
                b._wD(v("badFV", s, 8));
                b.flashVersion = s = 8
            }
            var c = b.debugMode || b.debugFlash ? "_debug.swf" : ".swf";
            if (b.useHTML5Audio && !b.html5Only && b.audioFormats.mp4.required && s < 9) {
                b._wD(v("needfl9"));
                b.flashVersion = s = 9
            }
            b.version = b.versionNumber + (b.html5Only ? " (HTML5-only mode)" : s === 9 ? " (AS3/Flash 9)" : " (AS2/Flash 8)");
            if (s > 8) {
                b.defaultOptions = E(b.defaultOptions, b.flash9Options);
                b.features.buffering = true;
                b.defaultOptions = E(b.defaultOptions, b.movieStarOptions);
                b.filePatterns.flash9 =
                    new RegExp("\\.(mp3|" + Db.join("|") + ")(\\?.*)?$", "i");
                b.features.movieStar = true
            } else b.features.movieStar = false;
            b.filePattern = b.filePatterns[s !== 8 ? "flash9" : "flash8"];
            b.movieURL = (s === 8 ? "soundmanager2.swf" : "soundmanager2_flash9.swf").replace(".swf", c);
            b.features.peakData = b.features.waveformData = b.features.eqData = s > 8
        };
        mb = function(c, a) {
            p && p._setPolling(c, a)
        };
        Pa = function() {
            if (b.debugURLParam.test(sa)) b.setupOptions.debugMode = b.debugMode = true;
            if (!M(b.debugID)) {
                var c, a, d, g;
                if (b.debugMode && !M(b.debugID) &&
                    (!db || !b.useConsole || !b.consoleOnly)) {
                    c = r.createElement("div");
                    c.id = b.debugID + "-toggle";
                    a = {
                        position: "fixed",
                        bottom: "0px",
                        right: "0px",
                        width: "1.2em",
                        height: "1.2em",
                        lineHeight: "1.2em",
                        margin: "2px",
                        textAlign: "center",
                        border: "1px solid #999",
                        cursor: "pointer",
                        background: "#fff",
                        color: "#333",
                        zIndex: 10001
                    };
                    c.appendChild(r.createTextNode("-"));
                    c.onclick = pb;
                    c.title = "Toggle SM2 debug console";
                    if (C.match(/msie 6/i)) {
                        c.style.position = "absolute";
                        c.style.cursor = "hand"
                    }
                    for (g in a)
                        if (a.hasOwnProperty(g)) c.style[g] =
                            a[g];
                    a = r.createElement("div");
                    a.id = b.debugID;
                    a.style.display = b.debugMode ? "block" : "none";
                    if (b.debugMode && !M(c.id)) {
                        try {
                            d = va();
                            d.appendChild(c)
                        } catch (h) {
                            throw new Error(v("domError") + " \n" + h.toString());
                        }
                        d.appendChild(a)
                    }
                }
            }
        };
        w = this.getSoundById;
        u = function(c, a) {
            return !c ? "" : b._wD(v(c), a)
        };
        pb = function() {
            var c = M(b.debugID),
                a = M(b.debugID + "-toggle");
            if (c) {
                if (Ia) {
                    a.innerHTML = "+";
                    c.style.display = "none"
                } else {
                    a.innerHTML = "-";
                    c.style.display = "block"
                }
                Ia = !Ia
            }
        };
        K = function(c, a, d) {
            if (o.sm2Debugger !== j) try {
                sm2Debugger.handleEvent(c,
                    a, d)
            } catch (g) {
                return false
            }
            return true
        };
        da = function() {
            var c = [];
            b.debugMode && c.push(A.sm2Debug);
            b.debugFlash && c.push(A.flashDebug);
            b.useHighPerformance && c.push(A.highPerf);
            return c.join(" ")
        };
        Ta = function() {
            var c = v("fbHandler"),
                a = b.getMoviePercent(),
                d = {
                    type: "FLASHBLOCK"
                };
            if (!b.html5Only)
                if (b.ok()) {
                    b.didFlashBlock && b._wD(c + ": Unblocked");
                    if (b.oMC) b.oMC.className = [da(), A.swfDefault, A.swfLoaded + (b.didFlashBlock ? " " + A.swfUnblocked : "")].join(" ")
                } else {
                    if (G) {
                        b.oMC.className = da() + " " + A.swfDefault + " " + (a ===
                            null ? A.swfTimedout : A.swfError);
                        b._wD(c + ": " + v("fbTimeout") + (a ? " (" + v("fbLoaded") + ")" : ""))
                    }
                    b.didFlashBlock = true;
                    X({
                        type: "ontimeout",
                        ignoreInit: true,
                        error: d
                    });
                    ca(d)
                }
        };
        Ka = function(c, a, d) {
            if (P[c] === j) P[c] = [];
            P[c].push({
                method: a,
                scope: d || null,
                fired: false
            })
        };
        X = function(c) {
            c || (c = {
                type: b.ok() ? "onready" : "ontimeout"
            });
            if (!x && c && !c.ignoreInit) return false;
            if (c.type === "ontimeout" && (b.ok() || F && !c.ignoreInit)) return false;
            var a = {
                    success: c && c.ignoreInit ? b.ok() : !F
                },
                d = c && c.type ? P[c.type] || [] : [],
                g = [],
                h;
            a = [a];
            var t =
                G && !b.ok();
            if (c.error) a[0].error = c.error;
            c = 0;
            for (h = d.length; c < h; c++) d[c].fired !== true && g.push(d[c]);
            if (g.length) {
                c = 0;
                for (h = g.length; c < h; c++) {
                    g[c].scope ? g[c].method.apply(g[c].scope, a) : g[c].method.apply(this, a);
                    if (!t) g[c].fired = true
                }
            }
            return true
        };
        aa = function() {
            o.setTimeout(function() {
                b.useFlashBlock && Ta();
                X();
                if (typeof b.onload === "function") {
                    u("onload", 1);
                    b.onload.apply(o);
                    u("onloadOK", 1)
                }
                b.waitForWindowLoad && B.add(o, "load", aa)
            }, 1)
        };
        Xa = function() {
            if (O !== j) return O;
            var c = false,
                a = navigator,
                d, g = o.ActiveXObject,
                h;
            try {
                h = a.plugins
            } catch (t) {
                h = undefined
            }
            if (h && h.length) {
                if ((a = a.mimeTypes) && a["application/x-shockwave-flash"] && a["application/x-shockwave-flash"].enabledPlugin && a["application/x-shockwave-flash"].enabledPlugin.description) c = true
            } else if (g !== j && !C.match(/MSAppHost/i)) {
                try {
                    d = new g("ShockwaveFlash.ShockwaveFlash")
                } catch (k) {
                    d = null
                }
                c = !!d
            }
            return O = c
        };
        tb = function() {
            var c, a, d = b.audioFormats;
            if ($a && C.match(/os (1|2|3_0|3_1)\s/i)) {
                b.hasHTML5 = false;
                b.html5Only = true;
                if (b.oMC) b.oMC.style.display = "none"
            } else if (b.useHTML5Audio) {
                if (!b.html5 ||
                    !b.html5.canPlayType) {
                    b._wD("SoundManager: No HTML5 Audio() support detected.");
                    b.hasHTML5 = false
                }
                if (cb) b._wD("soundManager: Note: Buggy HTML5 Audio in Safari on this OS X release, see https://bugs.webkit.org/show_bug.cgi?id=32159 - " + (!O ? " would use flash fallback for MP3/MP4, but none detected." : "will use flash fallback for MP3/MP4, if available"), 1)
            }
            if (b.useHTML5Audio && b.hasHTML5) {
                la = true;
                for (a in d)
                    if (d.hasOwnProperty(a))
                        if (d[a].required)
                            if (b.html5.canPlayType(d[a].type)) {
                                if (b.preferFlash && (b.flash[a] ||
                                        b.flash[d[a].type])) c = true
                            } else {
                                la = false;
                                c = true
                            }
            }
            if (b.ignoreFlash) {
                c = false;
                la = true
            }
            b.html5Only = b.hasHTML5 && b.useHTML5Audio && !c;
            return !b.html5Only
        };
        Aa = function(c) {
            var a, d, g = 0;
            if (c instanceof Array) {
                a = 0;
                for (d = c.length; a < d; a++)
                    if (c[a] instanceof Object) {
                        if (b.canPlayMIME(c[a].type)) {
                            g = a;
                            break
                        }
                    } else if (b.canPlayURL(c[a])) {
                    g = a;
                    break
                }
                if (c[g].url) c[g] = c[g].url;
                c = c[g]
            } else c = c;
            return c
        };
        qb = function(c) {
            if (!c._hasTimer) {
                c._hasTimer = true;
                if (!Ea && b.html5PollingInterval) {
                    if (ka === null && za === 0) ka = setInterval(sb, b.html5PollingInterval);
                    za++
                }
            }
        };
        rb = function(c) {
            if (c._hasTimer) {
                c._hasTimer = false;
                !Ea && b.html5PollingInterval && za--
            }
        };
        sb = function() {
            var c;
            if (ka !== null && !za) {
                clearInterval(ka);
                ka = null
            } else
                for (c = b.soundIDs.length - 1; c >= 0; c--) b.sounds[b.soundIDs[c]].isHTML5 && b.sounds[b.soundIDs[c]]._hasTimer && b.sounds[b.soundIDs[c]]._onTimer()
        };
        ca = function(c) {
            c = c !== j ? c : {};
            if (typeof b.onerror === "function") b.onerror.apply(o, [{
                type: c.type !== j ? c.type : null
            }]);
            c.fatal !== j && c.fatal && b.disable()
        };
        xb = function() {
            if (cb && Xa()) {
                var c = b.audioFormats,
                    a, d;
                for (d in c)
                    if (c.hasOwnProperty(d))
                        if (d === "mp3" || d === "mp4") {
                            b._wD("soundManager: Using flash fallback for " + d + " format");
                            b.html5[d] = false;
                            if (c[d] && c[d].related)
                                for (a = c[d].related.length - 1; a >= 0; a--) b.html5[c[d].related[a]] = false
                        }
            }
        };
        this._setSandboxType = function(c) {
            var a = b.sandbox;
            a.type = c;
            a.description = a.types[a.types[c] !== j ? c : "unknown"];
            if (a.type === "localWithFile") {
                a.noRemote = true;
                a.noLocal = false;
                u("secNote", 2)
            } else if (a.type === "localWithNetwork") {
                a.noRemote = false;
                a.noLocal = true
            } else if (a.type === "localTrusted") {
                a.noRemote =
                    false;
                a.noLocal = false
            }
        };
        this._externalInterfaceOK = function(c) {
            if (!b.swfLoaded) {
                var a;
                K("swf", true);
                K("flashtojs", true);
                b.swfLoaded = true;
                Fa = false;
                cb && xb();
                if (!c || c.replace(/\+dev/i, "") !== b.versionNumber.replace(/\+dev/i, "")) {
                    a = 'soundManager: Fatal: JavaScript file build "' + b.versionNumber + '" does not match Flash SWF build "' + c + '" at ' + b.url + ". Ensure both are up-to-date.";
                    setTimeout(function() {
                        throw new Error(a);
                    }, 0)
                } else setTimeout(Ha, V ? 100 : 1)
            }
        };
        wa = function(c, a) {
            function d() {
                var D = [],
                    J, N = [];
                J = "SoundManager " +
                    b.version + (!b.html5Only && b.useHTML5Audio ? b.hasHTML5 ? " + HTML5 audio" : ", no HTML5 audio support" : "");
                if (b.html5Only) b.html5PollingInterval && D.push("html5PollingInterval (" + b.html5PollingInterval + "ms)");
                else {
                    b.preferFlash && D.push("preferFlash");
                    b.useHighPerformance && D.push("useHighPerformance");
                    b.flashPollingInterval && D.push("flashPollingInterval (" + b.flashPollingInterval + "ms)");
                    b.html5PollingInterval && D.push("html5PollingInterval (" + b.html5PollingInterval + "ms)");
                    b.wmode && D.push("wmode (" + b.wmode + ")");
                    b.debugFlash && D.push("debugFlash");
                    b.useFlashBlock && D.push("flashBlock")
                }
                if (D.length) N = N.concat([D.join(" + ")]);
                b._wD(J + (N.length ? " + " + N.join(", ") : ""), 1);
                yb()
            }

            function g(D, J) {
                return '<param name="' + D + '" value="' + J + '" />'
            }
            if (ea && fa) return false;
            if (b.html5Only) {
                Ma();
                d();
                b.oMC = M(b.movieID);
                Ha();
                fa = ea = true;
                return false
            }
            var h = a || b.url,
                t = b.altURL || h;
            a = va();
            var k = da(),
                n = null;
            n = r.getElementsByTagName("html")[0];
            var q, y, I;
            n = n && n.dir && n.dir.match(/rtl/i);
            c = c === j ? b.id : c;
            Ma();
            qa = b.url + "?v=5018";
            b.url = ob(oa ?
                h : t);
            a = b.url;
            b.wmode = !b.wmode && b.useHighPerformance ? "transparent" : b.wmode;
            if (b.wmode !== null && (C.match(/msie 8/i) || !V && !b.useHighPerformance) && navigator.platform.match(/win32|win64/i)) {
                T.push(L.spcWmode);
                b.wmode = null
            }
            k = {
                name: c,
                id: c,
                src: a,
                quality: "high",
                allowScriptAccess: b.allowScriptAccess,
                bgcolor: b.bgColor,
                pluginspage: Hb + "www.macromedia.com/go/getflashplayer",
                title: "JS/Flash audio component (SoundManager 2)",
                type: "application/x-shockwave-flash",
                wmode: b.wmode,
                hasPriority: "true"
            };
            if (b.debugFlash) k.FlashVars =
                "debug=1";
            b.wmode || delete k.wmode;
            if (V) {
                h = r.createElement("div");
                y = ['<object id="' + c + '" data="' + a + '" type="' + k.type + '" title="' + k.title + '" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0">', g("movie", a), g("AllowScriptAccess", b.allowScriptAccess), g("quality", k.quality), b.wmode ? g("wmode", b.wmode) : "", g("bgcolor", b.bgColor), g("hasPriority", "true"), b.debugFlash ? g("FlashVars", k.FlashVars) : "", "</object>"].join("")
            } else {
                h =
                    r.createElement("embed");
                for (q in k) k.hasOwnProperty(q) && h.setAttribute(q, k[q])
            }
            Pa();
            k = da();
            if (a = va()) {
                b.oMC = M(b.movieID) || r.createElement("div");
                if (b.oMC.id) {
                    I = b.oMC.className;
                    b.oMC.className = (I ? I + " " : A.swfDefault) + (k ? " " + k : "");
                    b.oMC.appendChild(h);
                    if (V) {
                        c = b.oMC.appendChild(r.createElement("div"));
                        c.className = A.swfBox;
                        c.innerHTML = y
                    }
                    fa = true
                } else {
                    b.oMC.id = b.movieID;
                    b.oMC.className = A.swfDefault + " " + k;
                    c = q = null;
                    if (!b.useFlashBlock)
                        if (b.useHighPerformance) q = {
                            position: "fixed",
                            width: "8px",
                            height: "8px",
                            bottom: "0px",
                            left: "0px",
                            overflow: "hidden"
                        };
                        else {
                            q = {
                                position: "absolute",
                                width: "6px",
                                height: "6px",
                                top: "-9999px",
                                left: "-9999px"
                            };
                            if (n) q.left = Math.abs(parseInt(q.left, 10)) + "px"
                        } if (Gb) b.oMC.style.zIndex = 1E4;
                    if (!b.debugFlash)
                        for (I in q)
                            if (q.hasOwnProperty(I)) b.oMC.style[I] = q[I];
                    try {
                        V || b.oMC.appendChild(h);
                        a.appendChild(b.oMC);
                        if (V) {
                            c = b.oMC.appendChild(r.createElement("div"));
                            c.className = A.swfBox;
                            c.innerHTML = y
                        }
                        fa = true
                    } catch (pa) {
                        throw new Error(v("domError") + " \n" + pa.toString());
                    }
                }
            }
            ea = true;
            d();
            return true
        };
        ua = function() {
            if (b.html5Only) {
                wa();
                return false
            }
            if (p) return false;
            if (!b.url) {
                u("noURL");
                return false
            }
            p = b.getMovie(b.id);
            if (!p) {
                if (ia) {
                    if (V) b.oMC.innerHTML = Sa;
                    else b.oMC.appendChild(ia);
                    ia = null;
                    ea = true
                } else wa(b.id, b.url);
                p = b.getMovie(b.id)
            }
            typeof b.oninitmovie === "function" && setTimeout(b.oninitmovie, 1);
            Ya();
            return true
        };
        ba = function() {
            setTimeout(lb, 1E3)
        };
        La = function() {
            o.setTimeout(function() {
                S("soundManager: useFlashBlock is false, 100% HTML5 mode is possible. Rebooting with preferFlash: false...");
                b.setup({
                    preferFlash: false
                }).reboot();
                b.didFlashBlock = true;
                b.beginDelayedInit()
            }, 1)
        };
        lb = function() {
            var c, a = false;
            if (b.url)
                if (!ja) {
                    ja = true;
                    B.remove(o, "load", ba);
                    if (O && Fa && !eb) u("waitFocus");
                    else {
                        if (!x) {
                            c = b.getMoviePercent();
                            if (c > 0 && c < 100) a = true
                        }
                        setTimeout(function() {
                            c = b.getMoviePercent();
                            if (a) {
                                ja = false;
                                b._wD(v("waitSWF"));
                                o.setTimeout(ba, 1)
                            } else {
                                if (!x) {
                                    b._wD("soundManager: No Flash response within expected time. Likely causes: " + (c === 0 ? "SWF load failed, " : "") + "Flash blocked or JS-Flash security error." + (b.debugFlash ? " " + v("checkSWF") :
                                        ""), 2);
                                    if (!oa && c) {
                                        u("localFail", 2);
                                        b.debugFlash || u("tryDebug", 2)
                                    }
                                    c === 0 && b._wD(v("swf404", b.url), 1);
                                    K("flashtojs", false, ": Timed out" + (oa ? " (Check flash security or flash blockers)" : " (No plugin/missing SWF?)"))
                                }
                                if (!x && Ab)
                                    if (c === null)
                                        if (b.useFlashBlock || b.flashLoadTimeout === 0) {
                                            b.useFlashBlock && Ta();
                                            u("waitForever")
                                        } else if (!b.useFlashBlock && la) La();
                                else {
                                    u("waitForever");
                                    X({
                                        type: "ontimeout",
                                        ignoreInit: true,
                                        error: {
                                            type: "INIT_FLASHBLOCK"
                                        }
                                    })
                                } else if (b.flashLoadTimeout === 0) u("waitForever");
                                else !b.useFlashBlock &&
                                    la ? La() : Ra(true)
                            }
                        }, b.flashLoadTimeout)
                    }
                }
        };
        Na = function() {
            function c() {
                B.remove(o, "focus", Na)
            }
            if (eb || !Fa) {
                c();
                return true
            }
            eb = Ab = true;
            u("gotFocus");
            ja = false;
            ba();
            c();
            return true
        };
        Ya = function() {
            if (T.length) {
                b._wD("SoundManager 2: " + T.join(" "), 1);
                T = []
            }
        };
        yb = function() {
            Ya();
            var c, a = [];
            if (b.useHTML5Audio && b.hasHTML5) {
                for (c in b.audioFormats)
                    if (b.audioFormats.hasOwnProperty(c)) a.push(c + " = " + b.html5[c] + (!b.html5[c] && G && b.flash[c] ? " (using flash)" : b.preferFlash && b.flash[c] && G ? " (preferring flash)" : !b.html5[c] ?
                        " (" + (b.audioFormats[c].required ? "required, " : "") + "and no flash support)" : ""));
                b._wD("SoundManager 2 HTML5 support: " + a.join(", "), 1)
            }
        };
        ga = function(c) {
            if (x) return false;
            if (b.html5Only) {
                u("sm2Loaded", 1);
                x = true;
                aa();
                K("onload", true);
                return true
            }
            var a = true,
                d;
            b.useFlashBlock && b.flashLoadTimeout && !b.getMoviePercent() || (x = true);
            d = {
                type: !O && G ? "NO_FLASH" : "INIT_TIMEOUT"
            };
            b._wD("SoundManager 2 " + (F ? "failed to load" : "loaded") + " (" + (F ? "Flash security/load error" : "OK") + ") " + String.fromCharCode(F ? 10006 : 10003),
                F ? 2 : 1);
            if (F || c) {
                if (b.useFlashBlock && b.oMC) b.oMC.className = da() + " " + (b.getMoviePercent() === null ? A.swfTimedout : A.swfError);
                X({
                    type: "ontimeout",
                    error: d,
                    ignoreInit: true
                });
                K("onload", false);
                ca(d);
                a = false
            } else K("onload", true);
            if (!F)
                if (b.waitForWindowLoad && !ta) {
                    u("waitOnload");
                    B.add(o, "load", aa)
                } else {
                    b.waitForWindowLoad && ta && u("docLoaded");
                    aa()
                } return a
        };
        kb = function() {
            var c, a = b.setupOptions;
            for (c in a)
                if (a.hasOwnProperty(c))
                    if (b[c] === j) b[c] = a[c];
                    else if (b[c] !== a[c]) b.setupOptions[c] = b[c]
        };
        Ha = function() {
            function c() {
                B.remove(o,
                    "load", b.beginDelayedInit)
            }
            if (x) {
                u("didInit");
                return false
            }
            if (b.html5Only) {
                if (!x) {
                    c();
                    b.enabled = true;
                    ga()
                }
                return true
            }
            ua();
            try {
                p._externalInterfaceTest(false);
                mb(true, b.flashPollingInterval || (b.useHighPerformance ? 10 : 50));
                b.debugMode || p._disableDebug();
                b.enabled = true;
                K("jstoflash", true);
                b.html5Only || B.add(o, "unload", Ga)
            } catch (a) {
                b._wD("js/flash exception: " + a.toString());
                K("jstoflash", false);
                ca({
                    type: "JS_TO_FLASH_EXCEPTION",
                    fatal: true
                });
                Ra(true);
                ga();
                return false
            }
            ga();
            c();
            return true
        };
        Y = function() {
            if (ha) return false;
            ha = true;
            kb();
            Pa();
            if (!O && b.hasHTML5) {
                b._wD("SoundManager 2: No Flash detected" + (!b.useHTML5Audio ? ", enabling HTML5." : ". Trying HTML5-only mode."), 1);
                b.setup({
                    useHTML5Audio: true,
                    preferFlash: false
                })
            }
            vb();
            if (!O && G) {
                T.push(L.needFlash);
                b.setup({
                    flashLoadTimeout: 1
                })
            }
            r.removeEventListener && r.removeEventListener("DOMContentLoaded", Y, false);
            ua();
            return true
        };
        Va = function() {
            if (r.readyState === "complete") {
                Y();
                r.detachEvent("onreadystatechange", Va)
            }
            return true
        };
        Oa = function() {
            ta = true;
            Y();
            B.remove(o, "load", Oa)
        };
        Xa();
        B.add(o, "focus", Na);
        B.add(o, "load", ba);
        B.add(o, "load", Oa);
        if (r.addEventListener) r.addEventListener("DOMContentLoaded", Y, false);
        else if (r.attachEvent) r.attachEvent("onreadystatechange", Va);
        else {
            K("onload", false);
            ca({
                type: "NO_DOM2_EVENTS",
                fatal: true
            })
        }
    }
    if (!o || !o.document) throw new Error("SoundManager requires a browser with window and document objects.");
    var hb = null;
    o.SM2_DEFER = true;
    if (o.SM2_DEFER === j || !SM2_DEFER) hb = new Z;
    if (typeof module === "object" && module && typeof module.exports === "object") {
        module.exports.SoundManager =
            Z;
        module.exports.soundManager = hb
    } else typeof define === "function" && define.amd && define(function() {
        function qa(W) {
            if (!o.soundManager && W instanceof Function) {
                W = W(Z);
                if (W instanceof Z) o.soundManager = W
            }
            return o.soundManager
        }
        return {
            constructor: Z,
            getInstance: qa
        }
    });
    o.SoundManager = Z;
    o.soundManager = hb
})(window);