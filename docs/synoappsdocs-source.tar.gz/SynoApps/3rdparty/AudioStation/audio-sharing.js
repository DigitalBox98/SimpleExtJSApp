/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.AudioStation.Main
 * @extends SYNO.SDS.AudioStation.Base_Main
 * AudioStation main class
 *
 */
Ext.define("SYNO.SDS.AudioStation.Main", {
    extend: "SYNO.SDS.AudioStation.Base_Main",
    constructor: function(a) {
        var b;
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.Main", this);
        this.baseURL = a.baseURL;
        this.playingStore = this.createPlayingStore();
        b = this.fillConfig(a);
        this.callParent([b]);
        this.audioWebPlayer = SYNO.SDS.AudioStation.WebPlayer(this);
        this.audioWebPlayer.setStreamStore(this.playingStore);
        this.audioPlayer = SYNO.SDS.AudioStation.Player(this, this.audioWebPlayer)
    },
    fillConfig: function(a) {
        var b = (this._getWindow().isMobile) ? this.getMobileCfg() : this.getMainCfg();
        Ext.apply(b, a);
        return b
    },
    getMobileCfg: function() {
        var g = new SYNO.SDS.AudioStation.PlayingQueueGrid({
            itemId: "mobile_song",
            isForLargeView: true,
            customGridHeight: 52
        });
        var a = new SYNO.SDS.AudioStation.PlayerPanel({
            itemId: "player",
            region: "south",
            audioAppMain: this,
            cls: "syno-as-player-panel"
        });
        var f = new SYNO.SDS.AudioStation.CoverPanel({
            itemId: "cover",
            audioAppMain: this,
            isMobileStyle: true
        });
        var c = new SYNO.ux.Panel({
            xtype: "syno_panel",
            itemId: "center_card",
            border: false,
            region: "center",
            layout: "card",
            activeItem: 0,
            items: [f]
        });
        var e = new SYNO.SDS.AudioStation.LyricsPanel({
            itemId: "lyrics",
            cls: "syno-as-mini-lyrics-panel",
            padding: "10px",
            openContainer: c
        });
        c.add(e);
        c.doLayout();
        var d = new SYNO.ux.Panel({
            xtype: "syno_panel",
            itemId: "mobile_info",
            border: false,
            layout: "border",
            items: [c, a],
            listeners: {
                scope: this,
                activate: this.onInfoActive
            }
        });
        var b = {
            itemId: "main",
            border: false,
            cls: "syno-as-mobile-panel",
            layout: "card",
            activeItem: 0,
            items: [d, g]
        };
        this.gIsOnLargePlayingQueue = false;
        this.gIsMobileStyle = true;
        this.playerPanel = a;
        this.coverPanel = f;
        this.lyricsPanel = e;
        return b
    },
    getMainCfg: function() {
        var a = new SYNO.SDS.AudioStation.PlayingQueueView({
            itemId: "center",
            region: "center",
            isForLargeView: true,
            customGridHeight: 56
        });
        var b = new SYNO.SDS.AudioStation.PlayerPanel({
            itemId: "player",
            region: "south",
            audioAppMain: this,
            cls: "syno-as-player-panel"
        });
        var c = {
            itemId: "main",
            border: false,
            layout: "border",
            items: [a, b]
        };
        this.gIsOnLargePlayingQueue = true;
        this.largePlayingQueuePanel = a;
        this.gIsMobileStyle = false;
        this.playerPanel = b;
        return c
    },
    isPublicSharing: function() {
        return true
    },
    toggleListPanel: function(a) {
        if (this.gIsMobileStyle) {
            this.getLayout().setActiveItem(a ? "mobile_song" : "mobile_info")
        }
    },
    onAfterLoadPlayingStore: function(b, a, c) {
        SYNO.SDS.AudioStation.Window.clearStatusBusy();
        this.checkDelayPlay(b)
    },
    checkDelayPlay: function(b) {
        var d = 0,
            c, a;
        if (!Ext.isEmpty(location.hash)) {
            c = SYNO.SDS.AudioStation.Utils.Base64.decode(location.hash.substr(2));
            a = this.findPlayIndex(b, c);
            if (-1 !== a) {
                d = a
            }
        }
        this.delayPlayFn = function() {
            if (!SYNO.SDS.AudioStation.Utils.isSupportHtml5AutoPlay()) {
                this.audioPlayer.doJump(d);
                this.audioPlayer.doPlay()
            } else {
                this.audioPlayer.doJump(d)
            }
        };
        if (this.audioWebPlayer.isReady()) {
            this.delayPlayFn();
            this.delayPlayFn = null
        }
    },
    findPlayIndex: function(b, d) {
        var c = SYNO.SDS.AudioStation.Utils.parseVirtualPath(d),
            a;
        if (false === c) {
            return b.find("path", d)
        }
        b.findBy(function(e, f) {
            if (c.path == e.get("path") && c.track == e.get("track")) {
                a = e;
                return true
            }
        }, this);
        return a ? b.indexOf(a) : -1
    },
    onInfoActive: function() {
        if (this.gIsMobileStyle) {
            this.coverPanel.resetInfo()
        }
    },
    createPlayingStore: function() {
        var b = SYNO.SDS.AudioStation.Utils.getWebAPIParams({
            api: "SYNO.AudioStation.Playlist",
            method: "getinfo",
            sharing_id: SYNO.SDS.AudioStation.SessionData.SharingId,
            additional: "songs_song_tag,songs_song_audio",
            offset: 0,
            limit: SYNO.SDS.AudioStation.Define.MAX_SONG_LIMIT
        });
        if (!Ext.isEmpty(SYNO.SDS.AudioStation.SessionData.enc_song)) {
            b.enc_song = SYNO.SDS.AudioStation.SessionData.enc_song
        }
        var a = new Ext.data.Store({
            remoteSort: true,
            paramNames: {
                start: "songs_offset",
                limit: "songs_limit"
            },
            url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("playlist.cgi"),
            method: "POST",
            baseParams: b,
            reader: new Ext.data.JsonReader({
                root: "data.playlists[0].additional.songs",
                totalProperty: "data.playlists[0].additional.songs_total",
                fields: ["title", "path", "type", "id", {
                    name: "album",
                    mapping: "additional.song_tag.album"
                }, {
                    name: "artist",
                    mapping: "additional.song_tag.artist"
                }, {
                    name: "album_artist",
                    mapping: "additional.song_tag.album_artist"
                }, {
                    name: "composer",
                    mapping: "additional.song_tag.composer"
                }, {
                    name: "genre",
                    mapping: "additional.song_tag.genre"
                }, {
                    name: "comment",
                    mapping: "additional.song_tag.comment"
                }, {
                    name: "disc",
                    mapping: "additional.song_tag.disc"
                }, {
                    name: "track",
                    mapping: "additional.song_tag.track"
                }, {
                    name: "year",
                    mapping: "additional.song_tag.year"
                }, {
                    name: "bitrate",
                    mapping: "additional.song_audio.bitrate"
                }, {
                    name: "channel",
                    mapping: "additional.song_audio.channel"
                }, {
                    name: "duration",
                    mapping: "additional.song_audio.duration"
                }, {
                    name: "filesize",
                    mapping: "additional.song_audio.filesize"
                }, {
                    name: "frequency",
                    mapping: "additional.song_audio.frequency"
                }, {
                    name: "support",
                    convert: function(c, d) {
                        return d.path ? SYNO.SDS.AudioStation.Utils.updateSupportField(d.path) : true
                    }
                }]
            }),
            listeners: {
                scope: this,
                beforeload: function() {
                    SYNO.SDS.AudioStation.Window.setStatusBusy()
                },
                load: this.onAfterLoadPlayingStore,
                exception: function() {
                    SYNO.SDS.AudioStation.Window.clearStatusBusy()
                }
            }
        });
        return a
    },
    getPlayingPanel: function() {
        if (this.gIsOnLargePlayingQueue && this.largePlayingQueuePanel) {
            return this.largePlayingQueuePanel.songPanel
        }
        return this.getComponent("song")
    }
});
Ext.namespace("SYNO.SDS.AudioStation");
var _S, _TT;
_S = function(a) {
    return SYNO.SDS.AudioStation.SessionData[a]
};
_TT = function(d, c, a) {
    try {
        return SYNO.SDS.Strings[d][c][a]
    } catch (b) {
        return ""
    }
};
Ext.define("SYNO.SDS.AudioStation.SharingWindow", {
    extend: "SYNO.SDS.Window",
    isMobile: false,
    constructor: function(a) {
        SYNO.SDS.AudioStation.Window = this;
        this.baseURL = SYNO.SDS.AudioStation.SessionData.BaseUrl;
        this.panelList = {};
        var b = this.fillConfig(a);
        this.callParent([b]);
        SYNO.SDS.AudioStation.Utils.init()
    },
    fillConfig: function(a) {
        var d, b = [],
            e, c = SYNO.SDS.AudioStation.SessionData.PlaylistInfo;
        this.isMobile = SYNO.SDS.AudioStation.Utils.isMobileStyle();
        if (0 < c.additional.songs_total) {
            this.mainPanel = new SYNO.SDS.AudioStation.Main({
                baseURL: this.baseURL
            });
            b.push(this.mainPanel)
        } else {
            e = {
                html: this.getEmptyPageCfg()
            };
            b.push(e)
        }
        d = {
            cls: "syno-as-win syno-as-sharing-win " + ((this.isMobile) ? "syno-as-mobile-win" : ""),
            layout: "fit",
            renderTo: Ext.getBody(),
            border: false,
            header: false,
            closable: false,
            maximizable: false,
            title: _AST("common", "class_audio_station"),
            items: b
        };
        if (this.isMobile) {
            d.toolTemplate = new Ext.Template('<div class="x-tool x-tool-{id}"></div>');
            d.tools = [{
                id: "syno_as_lyrics",
                scope: this
            }, {
                id: "syno_as_toggle",
                scope: this
            }];
            d.listeners = {
                scope: this,
                afterrender: this.onMobileWinAfterRender
            }
        }
        Ext.apply(d, a);
        return d
    },
    onMobileWinAfterRender: function(a) {
        this.btnToggleList = new SYNO.ux.Button({
            enableToggle: true,
            toggleHandler: this.onBtnToggleListClick,
            scope: this,
            renderTo: this.getTool("syno_as_toggle")
        })
    },
    onBtnToggleListClick: function(a, b) {
        this.mainPanel.toggleListPanel(b);
        this.getTool("syno_as_lyrics").setVisible(!b)
    },
    getEmptyPageCfg: function() {
        var a = ['<div class="syno-as-sharing-empty-wrap">', '<div class="syno-as-sharing-empty">', '<div class="empty-img"></div>', '<div class="empty-text">', _AST("sharing", "empty_msg"), "</div>", "</div>", "</div>"].join("");
        a = String.format(a);
        return a
    },
    addPanelScope: function(b, a) {
        this.panelList[b] = a
    },
    getPanelScope: function(a) {
        if (a in this.panelList) {
            return this.panelList[a]
        }
        return null
    },
    getBrowseLibraryType: function() {
        return "all"
    }
});
SYNO.SDS.AudioStation.init = function(a) {
    var b = SYNO.SDS.AudioStation.Utils.getWebAPIParams({
        api: "SYNO.AudioStation.Playlist",
        method: "getinfo",
        sharing_id: SYNO.SDS.AudioStation.SessionData.SharingId,
        additional: "songs",
        songs_limit: 1
    });
    if (!Ext.isEmpty(SYNO.SDS.AudioStation.SessionData.enc_song)) {
        b.enc_song = SYNO.SDS.AudioStation.SessionData.enc_song
    }
    Ext.Ajax.request({
        url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("playlist.cgi"),
        params: b,
        callback: function(e, g, d) {
            var f, c;
            if (g && d.responseText) {
                f = Ext.util.JSON.decode(d.responseText);
                if (SYNO.SDS.AudioStation.Utils.testProperty(f, "data.playlists") && 0 < f.data.playlists.length) {
                    SYNO.SDS.AudioStation.SessionData.PlaylistInfo = f.data.playlists[0];
                    c = new SYNO.SDS.AudioStation.SharingWindow();
                    c.toggleMaximize();
                    c.show();
                    return
                }
            }
            window.alert(_AST("common", "error_system"))
        },
        scope: this
    })
};
Ext.onReady(function() {
    var a = function(d) {
        if (d.getTarget(".selectabletext")) {
            return true
        }
        if (d.getTarget("textarea")) {
            return true
        }
        var c = d.getTarget("input"),
            b = (c && c.type) ? c.type.toLowerCase() : "";
        if ("text" !== b && "textarea" !== b && "password" !== b) {
            return false
        }
        if (c.readOnly) {
            return false
        }
        return true
    };
    Ext.QuickTips.init();
    if (!Ext.isIE9m || Ext.isIE9) {
        Ext.QuickTips.getQuickTip().getEl().disableShadow()
    }
    Ext.getBody().on("contextmenu", function(b) {
        if (!a(b) && !b.getTarget(".allowDefCtxMenu")) {
            b.stopEvent()
        }
    });
    SYNO.SDS.GestureMgr = new SYNO.SDS._GestureMgr();
    if (SYNO.SDS.AudioStation.SessionData.SynohdpackStatus && SYNO.SDS.UIFeatures.test("isRetina")) {
        Ext.getBody().addClass("synohdpack")
    }
    SYNO.SDS.AudioStation.Utils.init(SYNO.SDS.AudioStation.init, window)
});
