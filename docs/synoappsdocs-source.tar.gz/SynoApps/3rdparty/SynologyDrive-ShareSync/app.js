/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SynologyDriveShareSync.View.Connection.Overview
 * @extends SYNO.ux.Panel
 * SynologyDrive share sync view connection class
 *
 */
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Connection.Overview", {
    extend: "SYNO.ux.Panel",
    xtype: "sdss_connection_overview",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            title: _SDSS("title", "ds_overview"),
            xtype: "container",
            layout: "vbox",
            items: [{
                xtype: "panel",
                width: 620,
                height: 140,
                border: false,
                cls: "syno-sdss-overview-card",
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [{
                    xtype: "container",
                    cls: "syno-sdss-overview-status",
                    layout: "hbox",
                    layoutConfig: {
                        align: "middle"
                    },
                    items: [{
                        xtype: "container",
                        layout: "vbox",
                        layoutConfig: {
                            align: "center"
                        },
                        width: 92,
                        height: 48,
                        items: {
                            xtype: "panel",
                            itemId: "status_icon",
                            border: false,
                            bodyCssClass: "syno-sdss-icon"
                        }
                    }, {
                        xtype: "syno_formpanel",
                        itemId: "status_form",
                        layout: "vbox",
                        baseCls: "syno-sdss-status-panel",
                        border: true,
                        hideLabel: true,
                        autoHeight: true,
                        autoFlexcroll: false,
                        useGradient: false,
                        items: [{
                            itemId: "sync_status",
                            xtype: "syno_displayfield",
                            width: 508,
                            cls: "syno-sdss-status-short",
                            value: "--"
                        }, {
                            xtype: "spacer",
                            height: 4
                        }, {
                            itemId: "sync_desc",
                            xtype: "syno_displayfield",
                            width: 508,
                            cls: "syno-sdss-status-long",
                            value: "--"
                        }]
                    }]
                }, {
                    xtype: "spacer",
                    height: 12
                }, {
                    xtype: "container",
                    layout: "hbox",
                    items: [{
                        xtype: "spacer",
                        width: 92
                    }, {
                        xtype: "syno_button",
                        itemId: "pauseResumeButton",
                        height: 28,
                        text: _SDSS("btn", "pause_connection")
                    }]
                }]
            }, {
                xtype: "syno_formpanel",
                itemId: "status_info",
                width: 620,
                height: 250,
                margins: "16px 0px 0px 0px",
                border: false,
                cls: "syno-sdss-overview-card",
                layout: "vbox",
                items: [{
                    xtype: "container",
                    cls: "syno-sdss-status-info-title",
                    html: _SDSS("title", "title_status_info")
                }, {
                    xtype: "syno_fieldset",
                    labelWidth: 200,
                    cls: "syno-sdss-status-info",
                    items: [{
                        itemId: "address",
                        xtype: "syno_displayfield",
                        labelSeparator: ":",
                        fieldLabel: _SDSS("title", "ip"),
                        value: "--"
                    }, {
                        itemId: "conn_method",
                        xtype: "syno_displayfield",
                        labelSeparator: ":",
                        fieldLabel: _SDSS("title", "conn_mode"),
                        value: "--"
                    }, {
                        itemId: "user",
                        xtype: "syno_displayfield",
                        labelSeparator: ":",
                        fieldLabel: _SDSS("title", "title_usr"),
                        value: "--"
                    }, {
                        itemId: "ssl_enable",
                        xtype: "syno_displayfield",
                        labelSeparator: ":",
                        fieldLabel: _SDSS("title", "title_ssl_enable"),
                        value: "--"
                    }]
                }, {
                    xtype: "container",
                    margins: "0px 0px 0px 20px",
                    items: [{
                        xtype: "syno_button",
                        itemId: "editButton",
                        text: _SDSS("btn", "edit_connection")
                    }, {
                        xtype: "syno_button",
                        itemId: "unlinkButton",
                        text: _SDSS("btn", "unlink_connection")
                    }]
                }]
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.DsccGridView", {
    extend: "SYNO.ux.FleXcroll.grid.GridView",
    initData: function(a, b) {
        this.callParent(arguments);
        if (a && this.scrollToTopOnLoad === false) {
            a.un("load", this.onLoad, this)
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ShareChooser", {
    extend: "SYNO.SDS.ShareChooser",
    getStore: function() {
        return this.store
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Connection.Share", {
    extend: "SYNO.ux.FormPanel",
    xtype: "sdss_connection_share",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(c) {
        this.modeWizard = c.modeWizard;
        this.enableColumn = new SYNO.ux.EnableColumn({
            name: "sync_enable",
            header: _SDSS("manage", "share_enable"),
            dataIndex: "enable",
            menuDisabled: true,
            sortable: false,
            width: 100,
            align: "center",
            disableSelectAll: true,
            listeners: {
                scope: this,
                click: function(d, f, h, g) {
                    this.fireEvent("clickEnableColumn", d, f, h, g)
                }
            },
            scope: this
        });
        var b = [{
            xtype: "syno_button",
            text: _T("common", "reset"),
            itemId: "resetButton",
            btnStyle: "grey",
            scope: this
        }, {
            xtype: "syno_button",
            text: _T("common", "save"),
            itemId: "saveButton",
            btnStyle: "blue",
            disabled: _S("demo_mode"),
            tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            scope: this
        }];
        var a = {
            title: _SDSS("manage", "share_tab_name"),
            layout: "fit",
            height: 307,
            padding: this.modeWizard ? undefined : "0px 0px 0px 0px",
            items: [{
                xtype: "syno_gridpanel",
                itemId: "synced_folder_grid",
                store: c.store,
                padding: "0px 0px 0px 0px",
                colModel: this.createColumnModel(c),
                view: new SYNO.SDS.SynologyDriveShareSync.Component.DsccGridView({
                    scrollToTopOnLoad: false
                }),
                plugins: [this.enableColumn],
                mode: "remote"
            }]
        };
        if (!this.modeWizard) {
            Ext.apply(a, {
                buttons: b,
                useStatusBar: true
            })
        }
        return Ext.apply(a, c)
    },
    createColumnModel: function(d) {
        var g = [];
        var f = {
            iconCls: "syno-sdss-columnicon-delete",
            tooltip: _SDSS("btn", "share_db_delete"),
            handler: function(j, m, i, k, l) {
                this.fireEvent("clickDeleteButton", j, m, i, k, l)
            },
            scope: this
        };
        var c = {
            iconCls: "syno-sdss-columnicon-folder",
            tooltip: _SDSS("manage", "share_change_folder"),
            handler: function(j, m, i, k, l) {
                this.fireEvent("clickFolderButton", j, m, i, k, l)
            },
            scope: this
        };
        var h = {
            iconCls: "syno-sdss-columnicon-settings",
            tooltip: _SDSS("msg", "perm_sync_settings"),
            handler: function(j, m, i, k, l) {
                this.fireEvent("clickAdvanceSettingButton", j, m, i, k, l)
            },
            scope: this
        };
        if (this.modeWizard) {
            g = [c, h]
        } else {
            g = [f, c, h]
        }
        var b = [this.enableColumn, {
            header: _SDSS("manage", "share_name"),
            dataIndex: "remote_share",
            renderer: function(m, l, i, k, n, j) {
                l.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(m) + '"';
                return m
            }
        }, {
            header: _SDSS("manage", "share_local_syncfolder"),
            dataIndex: "local_share",
            renderer: function(m, l, i, k, n, j) {
                if (m === "--") {
                    l.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(_SDSS("msg", "choose_local_sync_folder_info")) + '"'
                } else {
                    l.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(m) + '"'
                }
                return m
            }
        }, {
            header: _SDSS("msg", "sync_direction"),
            dataIndex: "sync_direction",
            renderer: function(n, m, j, l, o, k) {
                var p = "--";
                var i = j.get("sync_direction");
                if (i === 0) {
                    p = _SDSS("title", "two_way_sync")
                } else {
                    if (i === 1) {
                        p = _SDSS("msg", "sync_direction_upload")
                    } else {
                        if (i === 2) {
                            p = _SDSS("msg", "sync_direction_download")
                        }
                    }
                }
                if (null !== m) {
                    m.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(p) + '"'
                }
                return p
            }
        }, {
            header: _SDSS("manage", "share_status"),
            dataIndex: "status",
            renderer: function(m, l, i, k, n, j) {
                var o = "-";
                if (i.get("org_enable") || i.get("db_error")) {
                    o = SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToString(m);
                    if (null !== l) {
                        l.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(o) + '"'
                    }
                    o = SYNO.SDS.SynologyDriveShareSync.Util.DecorateStatusString(m, o)
                }
                return o
            }
        }, {
            scope: this,
            header: _SDSS("msg", "summary"),
            id: "actionColumn",
            xtype: "actioncolumn",
            items: g,
            renderer: function(m, j, i, n, l, k) {
                j.css = "syno-sdss-columnicon ";
                if (i.get("org_enable") || !i.get("used")) {
                    j.css += "x-btn-disabled-delete "
                }
                if (i.get("org_enable") && i.get("org_local_share")) {
                    j.css += "x-btn-disabled-folder "
                }
                return ""
            }
        }];
        if (this.modeWizard) {
            for (var e = 0; e < b.length; ++e) {
                if (b[e].dataIndex && b[e].dataIndex === "status") {
                    b.splice(e, 1);
                    break
                }
            }
        }
        var a = new Ext.grid.ColumnModel({
            defaults: {
                sortable: false,
                menuDisabled: true
            },
            columns: b
        });
        return a
    },
    createShareChooser: function(b) {
        var a = {
            owner: b.owner,
            title: _T("common", "choose"),
            setApiParams: function() {
                return {
                    shareType: ["local", "enc", "dec"],
                    additional: ["migrate", "encryption", "is_force_readonly", "force_readonly_subscriber"],
                    check_mounted: true,
                    check_mounted_exceptions: ["#snapshot"]
                }
            },
            setStoreField: function() {
                return ["name", "desc", "is_force_readonly", "force_readonly_subscriber", "migrate"]
            },
            setGridPanelConfig: function() {
                return {
                    enableColumnHide: false
                }
            },
            singleSelect: true
        };
        if (SYNO.SDS.SynologyDriveShareSync.Util.IsSupportColdStorageModel()) {
            Ext.apply(a, {
                cls: "syno-sdss-share-chooser",
                bbar: {
                    xtype: "container",
                    cls: "syno-sdss-share-chooser-note",
                    items: {
                        xtype: "syno_displayfield",
                        html: "<span>" + _T("common", "note") + ":</span> " + _SDSS("common", "shared_not_supported")
                    }
                }
            })
        }
        var c = new SYNO.SDS.SynologyDriveShareSync.Component.ShareChooser(a);
        c.getStore().on("load", function(e, d, f) {
            e.filterBy(function(h, m) {
                var g = b.remoteShareName === "homes";
                var l = h.get("name") === "homes";
                var j = !b.remoteShareRW;
                var i = h.get("is_force_readonly");
                var k = h.get("migrate");
                if ((g && l) && (j || i)) {
                    return false
                } else {
                    if (g && i) {
                        return false
                    } else {
                        if (l && (j || !b.isUserAdmin || k)) {
                            return false
                        }
                    }
                }
                if (i) {
                    if (h.get("force_readonly_subscriber") !== "surveillance" || b.serverBuildNumber < 4100) {
                        return false
                    } else {
                        if (j) {
                            return false
                        }
                    }
                }
                return true
            }, this)
        });
        return c
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.ConnectionList", {
    extend: "SYNO.ux.ModuleList",
    xtype: "sdss_connection_list",
    listItems: [],
    customStore: undefined,
    constructor: function(a) {
        this.callParent([this.fillConfig(a)]);
        this.init()
    },
    fillConfig: function(b) {
        this.customStore = b.store;
        var a = {
            baseAttrs: {
                uiProvider: SYNO.SDS.SynologyDriveShareSync.View.ConnectionListTreeNodeUI
            },
            itemId: "connectionList",
            cls: "syno-sdss-connlist",
            listItems: this.listItems
        };
        return Ext.apply(a, b)
    },
    init: function() {},
    refresh: function() {
        var c = this.customStore.data.items;
        var b = c.map(function(d) {
            return d.id
        });
        var a = [];
        this.getRootNode().eachChild(function(d) {
            if (b.indexOf(d.attributes.connId) === -1) {
                a.push(d)
            }
        }, this);
        Ext.each(a, function(d) {
            this.removeModule(d.id)
        }, this);
        Ext.each(c, function(d) {
            var e = this.getRootNode().findChildBy(function(g) {
                return g.attributes.connId >= d.id
            });
            var f = {
                connId: d.id,
                text: d.data.server_name,
                iconCls: "syno-sdss-connicon",
                status: d.data.status,
                statusIconCls: "syno-sdss-sicon syno-sdss-sicon-" + d.data.status
            };
            if (!e) {
                this.appendModule(f)
            } else {
                if (e.attributes.connId === d.id) {
                    this.replaceModule(f, e.id)
                } else {
                    this.insertModule(f, e.id)
                }
            }
        }, this);
        this.doLayout()
    },
    replaceModule: function(c, b) {
        var a, d;
        a = this.getRootNode();
        d = this.getNodeById(b);
        if (a && d) {
            a.replaceChild(c, d)
        }
    },
    getStore: function() {
        return this.customStore
    },
    select: function(a) {
        if (Ext.isNumber(a)) {
            this.selectModule(this.getRootNode().item(a).id)
        }
        if (Ext.isObject(a) && a.isAncestor && a.isAncestor(this.getRootNode())) {
            this.selectModule(a.id)
        }
    },
    getObservable: function() {
        return this.getSelectionModel()
    },
    getSelectedNode: function() {
        return this.getSelectionModel().getSelectedNode()
    },
    suspendEvents: function() {
        this.getSelectionModel().suspendEvents()
    },
    resumeEvents: function() {
        this.getSelectionModel().resumeEvents()
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.ConnectionListTreeNodeUI", {
    extend: "SYNO.ux.ModuleList.TreeNodeUI",
    base_renderElements: function(d, k, i, l) {
        this.indentMarkup = d.parentNode ? d.parentNode.ui.getChildIndent() : "";
        var e = Ext.isBoolean(k.checked),
            b, j = d.attributes.htmlEncode !== false && d.htmlEncode !== false && d.ownerTree.htmlEncode !== false,
            f = k.isCategory ? "x-tree-node x-tree-node-category" : "x-tree-node";
        var m = k.cls + (k.collapsible === false ? " x-tree-node-not-collapsible" : "");
        var c = Ext.isFunction(k.getTpl) ? k.getTpl(this, d, k, i, l) : ['<li class="' + f + '" tree-root-id="', k.originText, '"><div ext:tree-node-id="', d.id, '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', m, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', '<img alt="" src="', k.icon || this.emptyIcon, '" class="x-tree-node-icon', (k.icon ? " x-tree-node-inline-icon" : ""), (k.iconCls ? " " + k.iconCls : ""), '" unselectable="on" />', e ? ('<input class="x-tree-node-cb" type="checkbox" ' + (k.checked ? 'checked="checked" />' : "/>")) : "", '<a hidefocus="on" class="x-tree-node-anchor"', k.href ? ' href="' + k.href + '"' : "", ' tabIndex="-1" ', k.hrefTarget ? ' target="' + k.hrefTarget + '"' : "", '><span class="x-tree-node-text" unselectable="on">', (j) ? Ext.util.Format.htmlEncode(d.text) : d.text, "</span></a>", '<img alt="" src="', k.statusIcon || this.emptyIcon, '" class="', (k.statusIconCls ? k.statusIconCls : ""), '" unselectable="on" />', "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        if (l !== true && d.nextSibling && (b = d.nextSibling.ui.getEl())) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", b, c)
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", i, c)
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1];
        var h = this.elNode.childNodes;
        this.indentNode = h[0];
        this.ecNode = h[1];
        this.iconNode = h[2];
        var g = 3;
        if (e) {
            this.checkbox = h[3];
            this.checkbox.defaultChecked = this.checkbox.checked;
            g++
        }
        this.anchor = h[g];
        this.textNode = h[g].firstChild
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Viewport", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "appWindow",
            resizable: false,
            maximizable: false,
            width: 900,
            height: 530,
            layout: "border",
            cls: "syno-sdss",
            border: false,
            items: [{
                xtype: "panel",
                itemId: "siderBar",
                region: "west",
                border: false,
                cls: "syno-sdss-sidebar",
                width: 240,
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                items: [{
                    xtype: "panel",
                    itemId: "actionButtons",
                    layout: {
                        type: "hbox",
                        pack: "center"
                    },
                    padding: "16px 0 8px 0",
                    border: false,
                    items: [{
                        xtype: "syno_button",
                        itemId: "createButton",
                        btnStyle: "blue",
                        iconCls: "syno-sdss-create-icon",
                        disabled: _S("demo_mode"),
                        tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : _SDSS("btn", "link_new_nas"),
                        width: 68,
                        height: 28
                    }, {
                        xtype: "container",
                        width: 6
                    }, {
                        xtype: "syno_button",
                        itemId: "logButton",
                        btnStyle: "grey",
                        iconCls: "syno-sdss-synclog-icon",
                        tooltip: _SDSS("history", "page_title"),
                        width: 68,
                        height: 28
                    }, {
                        xtype: "container",
                        width: 6
                    }, {
                        xtype: "syno_button",
                        itemId: "settingButton",
                        btnStyle: "grey",
                        iconCls: "syno-sdss-settings-icon",
                        tooltip: _SDSS("msg", "summary"),
                        width: 68,
                        height: 28
                    }]
                }, {
                    xtype: "sdss_connection_list",
                    flex: 1,
                    itemId: "connectionList",
                    store: b.application.getStore("Connection")
                }]
            }, {
                xtype: "container",
                itemId: "tabpanel_wrapper",
                region: "center",
                cls: "syno-sdss-tabpanel-overview",
                layout: "border",
                items: [{
                    xtype: "syno_tabpanel",
                    itemId: "tabPanel",
                    deferredRender: false,
                    layoutOnTabChange: true,
                    border: false,
                    plain: true,
                    activeTab: 0,
                    region: "center",
                    margins: "16px 20px 0px 20px",
                    items: [{
                        xtype: "sdss_connection_overview",
                        itemId: "connectionOverview"
                    }, {
                        xtype: "sdss_connection_share",
                        itemId: "target_share",
                        store: b.application.getStore("Share")
                    }]
                }]
            }]
        };
        return Ext.apply(a, b)
    },
    close: function() {
        if (this.closed) {
            return
        }
        this.closed = true;
        this.callParent(arguments)
    },
    onClickHelp: function() {
        var a = "SYNO.SDS.Drive.Application:drive_sharesync.html";
        if (_S("standalone")) {
            SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            })
        } else {
            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            }, false)
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Main", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.control({
            appWindow: {
                destroy: this.onDestroyAppWindow
            },
            "siderBar actionButtons createButton": {
                click: this.onClickCreateButton
            },
            "siderBar actionButtons settingButton": {
                click: this.onClickSettingButton
            },
            "siderBar actionButtons logButton": {
                click: this.onClickLogButton
            }
        });
        this.owner = this.componentQuery("appWindow");
        var b = this.componentQuery("siderBar connectionList");
        var a = this.getObservableConnectionList();
        this.addEvents("updateConnInfo");
        this.addEvents("updateSessList");
        this.mon(a, "beforeselect", function(d, f, e) {
            var g = Ext.emptyFn,
                i = Ext.emptyFn;
            if (_S("majorversion") < 7) {
                g = function(k, l) {
                    return k.getRecord(l).get("id")
                };
                i = function(k, l) {
                    return k.getStore().indexOfId(l)
                }
            } else {
                g = function(k, l) {
                    return l.attributes.connId
                };
                i = function(k, l) {
                    return k.tree.getStore().indexOfId(l)
                }
            }
            var h = (this.connId) ? this.connId : 0;
            var j = g(d, f, e);
            if (h !== j) {
                if (this.owner.fireEvent("beforeLeavingConnection", b.select.bind(b, f))) {
                    return true
                } else {
                    var c = i(d, this.connId);
                    b.select(c);
                    return false
                }
            }
            return true
        }, this);
        this.mon(a, "selectionchange", function(c, d) {
            var f;
            if (_S("majorversion") < 7) {
                if (d.length) {
                    f = c.getRecord(d[0]).get("id")
                }
            } else {
                if (d) {
                    f = d.attributes.connId
                }
            }
            if (f) {
                var e = this.connId;
                this.connId = f;
                if (e !== this.connId) {
                    this.prevConnId = e;
                    this.updatePollingApi();
                    this.restartPollingTask()
                }
            }
        }, this);
        this.setupPollingTask();
        this.startup()
    },
    onDestroyAppWindow: function(a) {
        if (this.pollingTask) {
            this.stopPollingTask()
        }
    },
    onClickCreateButton: function(b, c, a) {
        var d = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.Wizard, {
            owner: this.owner,
            editMode: false,
            firstConnection: (a) ? true : false
        });
        this.mon(d, "launchService", this.launchService, this, {
            single: true
        });
        d.getViewport().open()
    },
    onClickSettingButton: function(a, c) {
        var b = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.Setting, {
            owner: this.owner
        });
        b.getViewport().open()
    },
    onClickLogButton: function(b, c) {
        var a = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.SyncLog, {
            owner: this.owner
        });
        a.getViewport().open()
    },
    startup: function() {
        this.owner.setStatusBusy();
        this.getWebAPI().listConnection({
            limit: 0
        }, function(d, a, c, b) {
            if (!d) {
                var e = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(a);
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert(this.owner.title, e, function() {
                    this.owner.close()
                }, this)
            } else {
                if (a.total === 0) {
                    this.owner.clearStatusBusy();
                    this.goToDefault()
                } else {
                    this.launchService()
                }
            }
        }, this)
    },
    goToDefault: function() {
        this.componentQuery("createButton").setDisabled(true);
        this.componentQuery("settingButton").setDisabled(true);
        this.componentQuery("logButton").setDisabled(true);
        if (_S("majorversion") < 7) {
            this.componentQuery("manageButtonGroup").setDisabled(true)
        }
        this.componentQuery("connectionList").getStore().removeAll();
        this.app().getController("Connection").resetUI();
        var a = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.Introduction, {
            owner: this.owner
        });
        a.getViewport().open()
    },
    launchService: function() {
        var a = this.getObservableConnectionList();
        this.mon(a, "selectionchange", function() {
            if (!_S("demo_mode")) {
                this.componentQuery("createButton").setDisabled(false);
                if (_S("majorversion") < 7) {
                    this.componentQuery("manageButtonGroup").setDisabled(false)
                }
                this.componentQuery("logButton").setDisabled(false)
            }
            this.componentQuery("settingButton").setDisabled(false);
            this.owner.clearStatusBusy()
        }, this, {
            single: true
        });
        this.startPollingTask()
    },
    getObservableConnectionList: function() {
        return this.componentQuery("siderBar connectionList").getObservable()
    },
    setupPollingTask: function() {
        var b = this.componentQuery("connectionList");
        var a = b.getStore();
        this.mon(a, "datachanged", function(c) {
            var f;
            if (_S("majorversion") < 7) {
                var e = b.getSelectedRecords();
                f = (e[0]) ? e[0].get("id") : 0
            } else {
                var d = b.getSelectedNode();
                f = d ? d.attributes.connId : undefined
            }
            c.selectedConnId = f;
            b.suspendEvents();
            b.refresh()
        }, this);
        this.mon(a, "load", function(e, d, f) {
            var c = e.indexOfId(e.selectedConnId);
            if (c === -1) {
                c = 0
            }
            b.resumeEvents();
            b.select(c)
        }, this);
        this.pollingTask = this.addWebAPITask({
            interval: 5000,
            compound: {
                mode: "sequential",
                params: []
            },
            single: false,
            callback: function(f, c, e, d) {
                if (!f) {
                    return
                }
                c.result.forEach(function(h, g) {
                    var i;
                    if (h.api === "SYNO.SynologyDriveShareSync.Connection" && h.method === "list") {
                        this.handleConnectionUpdate(h.success, h.success ? h.data : h.error, h.params, h.opts);
                        return
                    } else {
                        if (h.api === "SYNO.SynologyDriveShareSync.Connection" && h.method === "get") {
                            if (e.compound[g].conn_id !== this.connId) {
                                return
                            }
                            i = "updateConnInfo"
                        } else {
                            if (h.api === "SYNO.SynologyDriveShareSync.Session" && h.method === "list") {
                                if (e.compound[g].conn_id !== this.connId) {
                                    return
                                }
                                i = "updateSessList"
                            } else {
                                return
                            }
                        }
                    }
                    this.fireEvent(i, h.success, h.success ? h.data : h.error, h.params, h.opts)
                }, this);
                if (this.prevConnId !== this.connId) {
                    this.prevConnId = this.connId
                }
            },
            scope: this
        })
    },
    handleConnectionUpdate: function(d, a, c, b) {
        var e = this.componentQuery("connectionList");
        if (d) {
            e.getStore().loadData(a)
        } else {
            console.log("list_conn fail")
        }
    },
    startPollingTask: function() {
        this.updatePollingApi();
        this.pollingTask.start()
    },
    stopPollingTask: function() {
        this.pollingTask.stop()
    },
    restartPollingTask: function() {
        this.pollingTask.restart(true)
    },
    monPolling: function(d, a, c, b) {
        d.mon(this, a, c, b);
        this.updatePollingApi()
    },
    munPolling: function(d, a, c, b) {
        d.mun(this, a, c, b);
        this.updatePollingApi()
    },
    updatePollingApi: function() {
        if (!this.pollingTask) {
            return
        }
        var a = [{
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "list"
        }];
        if (this.connId && this.hasListener("updateConnInfo")) {
            a = a.concat({
                api: "SYNO.SynologyDriveShareSync.Connection",
                version: 1,
                method: "get",
                params: {
                    conn_id: this.connId
                }
            })
        }
        if (this.connId && this.hasListener("updateSessList")) {
            a.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "list",
                params: {
                    conn_id: this.connId
                }
            })
        }
        this.pollingTask.reqConfig.compound.params = a
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Connection", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.control({
            tabPanel: {
                tabchange: this.onTabChange
            },
            "tabPanel connectionOverview pauseResumeButton": {
                click: this.onClickPauseResumeButton
            },
            "tabPanel connectionOverview unlinkButton": {
                click: this.onClickUnlinkButton
            },
            "tabPanel connectionOverview editButton": {
                click: this.onClickEditButton
            },
            "tabPanel connectionOverview": {
                activate: this.onOverviewActivate,
                deactivate: this.onOverviewDeactivate
            }
        });
        this.mon(this.componentQuery("siderBar connectionList").getObservable(), "selectionchange", this.onChangeSelectedConnection, this);
        this.owner = this.componentQuery("appWindow");
        this.activated = true;
        this.app().getController("Main").monPolling(this, "updateConnInfo", this.handleInfoUpdate, this)
    },
    onChangeSelectedConnection: function(a, b) {
        var d = {};
        var c;
        if (_S("majorversion") < 7) {
            if (b.length) {
                d = a.getRecord(b[0]).data;
                c = d.id
            }
        } else {
            if (b) {
                Ext.apply(d, b.attributes);
                d.id = d.connId;
                c = d.id
            }
        }
        if (c) {
            if (this.connectionData && this.connectionData.id !== d.id) {
                if (this.activated && !this.isStatusBusy) {
                    this.owner.setStatusBusy();
                    this.isStatusBusy = true
                }
            }
            this.connectionData = d
        }
    },
    updateConnectionStatus: function(b, d) {
        var f = SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToDescription(b, d),
            c = this.componentQuery("status_form").getForm(),
            a = c.findField("sync_status"),
            e = this.componentQuery("pauseResumeButton");
        this.setStatusIcon(SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToIconType(b));
        a.setValue(f.status);
        a.removeClass(["syno-ux-displayfield", "green-status", "blue-status", "red-status", "gray-status"]);
        a.addClass(f.cls);
        c.findField("sync_desc").setValue(f.description);
        c.findField("sync_desc").getEl().set({
            "ext:qtip": f.description
        });
        if (b === "unlink") {
            e.disable();
            e.setText(_SDSS("btn", "pause_connection"))
        } else {
            if (b !== "pause") {
                e.enable();
                e.setText(_SDSS("btn", "pause_connection"))
            } else {
                e.enable();
                e.setText(_SDSS("btn", "resume_connection"))
            }
        }
    },
    setStatusIcon: function(a) {
        var b = this.componentQuery("status_icon");
        b.body.replaceClass("syno-sdss-icon-" + b.body.oldStatus, "syno-sdss-icon-" + a);
        b.body.oldStatus = a
    },
    updateConnectionInformation: function(b) {
        var c = this.componentQuery("status_info").getForm(),
            a;
        switch (b.conn_method) {
            case "DirectConnect":
                a = _SDSS("msg", "conn_mode_direct");
                break;
            case "QuickConnect":
                a = _SDSS("msg", "conn_mode_ez");
                break;
            case "WAN":
                a = _SDSS("msg", "conn_mode_wan");
                break;
            case "LAN":
                a = _SDSS("msg", "conn_mode_lan");
                break;
            default:
            case "Upgrade":
                a = _SDSS("msg", "conn_mode_reading");
                break
        }
        c.setValues({
            conn_method: a,
            address: b.server_name,
            user: b.user,
            ssl_enable: (b.ssl_enable) ? _SDSS("msg", "enabled") : _SDSS("msg", "disabled")
        })
    },
    onTabChange: function(b, c) {
        var a = this.componentQuery("tabpanel_wrapper");
        if (!a) {
            return
        }
        if (b.getActiveTab().getItemId() === "connectionOverview") {
            a.addClass("syno-sdss-tabpanel-overview")
        } else {
            a.removeClass("syno-sdss-tabpanel-overview")
        }
    },
    onClickPauseResumeButton: function(a, b) {
        var c = this.connectionData.id;
        if (this.componentQuery("pauseResumeButton").text === _SDSS("btn", "pause_connection")) {
            this.pauseConnection(c)
        } else {
            this.resumeConnection(c)
        }
    },
    pauseConnection: function(a) {
        this.owner.setStatusBusy();
        this.app().getController("Main").stopPollingTask();
        this.getWebAPI().pause(a, function(e, b, d, c) {
            this.owner.clearStatusBusy();
            if (!e) {
                this.showErrorMessageBox(b)
            }
            this.app().getController("Main").startPollingTask();
            SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.SynologyDriveShareSync.TrayApp")[0].updateTrayStatus()
        }, this)
    },
    resumeConnection: function(a) {
        this.owner.setStatusBusy();
        this.app().getController("Main").stopPollingTask();
        this.getWebAPI().resume(a, function(e, b, d, c) {
            this.owner.clearStatusBusy();
            if (!e) {
                this.showErrorMessageBox(b)
            }
            this.app().getController("Main").startPollingTask();
            SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.SynologyDriveShareSync.TrayApp")[0].updateTrayStatus()
        }, this)
    },
    onClickUnlinkButton: function(a, b) {
        this.owner.getMsgBox().confirm(this.owner.title, _SDSS("msg", "confirm_unlink"), function(d, f, c) {
            if (d === "yes") {
                var e = this.connectionData.id;
                this.unlinkConnection(e)
            }
        }, this)
    },
    unlinkConnection: function(a) {
        this.owner.setStatusBusy();
        this.app().getController("Main").stopPollingTask();
        this.getWebAPI().deleteConnection(a, function(e, b, d, c) {
            this.owner.clearStatusBusy();
            if (!e) {
                this.showErrorMessageBox(b)
            }
            this.app().getController("Main").startup();
            SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.SynologyDriveShareSync.TrayApp")[0].updateTrayStatus()
        }, this)
    },
    onClickEditButton: function(a, b) {
        var c = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.Wizard, {
            owner: this.owner,
            editMode: true,
            connId: this.connectionData.id
        });
        this.wizardCreate = c.getViewport();
        this.wizardCreate.open()
    },
    resetUI: function() {
        var a = this.componentQuery("status_form").getForm(),
            b = this.componentQuery("status_info").getForm();
        a.setValues({
            sync_status: "--",
            sync_desc: "--"
        });
        b.setValues({
            ssl_enable: "--",
            user: "--",
            conn_method: "--",
            address: "--"
        });
        this.setStatusIcon("")
    },
    showErrorMessageBox: function(b) {
        var a = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(b);
        this.owner.getMsgBox().alert(this.owner.title, a)
    },
    handleInfoUpdate: function(d, a, c, b) {
        if (d) {
            this.updateConnectionStatus(a.status, a.unfinished_files);
            this.updateConnectionInformation(a)
        }
        if (this.isStatusBusy) {
            this.owner.clearStatusBusy();
            this.isStatusBusy = false
        }
    },
    onOverviewActivate: function() {
        var a = this.app().getController("Main");
        this.activated = true;
        if (!this.isStatusBusy) {
            this.owner.setStatusBusy();
            this.isStatusBusy = true
        }
        a.monPolling(this, "updateConnInfo", this.handleInfoUpdate, this);
        a.restartPollingTask()
    },
    onOverviewDeactivate: function() {
        var a = this.app().getController("Main");
        this.activated = false;
        a.munPolling(this, "updateConnInfo", this.handleInfoUpdate, this)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Share", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.control({
            target_share: {
                activate: this.onActivateShare,
                deactivate: this.onDeactivateShare
            }
        });
        this.model = this.app().getModel("Share");
        this.store = this.app().getStore("Share");
        this.filterMap = {};
        if (this.modeWizard) {
            this.owner = this.componentQuery("wizardWindow");
            this.shareWindow = this.owner.getStep("target_share")
        } else {
            this.owner = this.componentQuery("appWindow");
            this.shareWindow = this.componentQuery("target_share");
            this.mon(this.owner, "beforeLeavingConnection", this.handleLeavingConnection, this);
            this.mon(this.owner, "beforeclose", this.onBeforeCloseMainWindow, this);
            this.mon(this.componentQuery("siderBar connectionList").getObservable(), "selectionchange", this.onChangeSelectedConnection, this);
            this.mon(this.shareWindow.getFooterToolbar().getComponent("saveButton"), "click", this.onClickSaveButton, this);
            this.mon(this.shareWindow.getFooterToolbar().getComponent("resetButton"), "click", this.onClickResetButton, this)
        }
        this.mon(this.shareWindow, "clickEnableColumn", this.onClickEnableColumn, this);
        this.mon(this.shareWindow, "clickDeleteButton", this.onClickDeleteButton, this);
        this.mon(this.shareWindow, "clickFolderButton", this.onClickFolderButton, this);
        this.mon(this.shareWindow, "clickAdvanceSettingButton", this.onClickAdvanceSettingButton, this)
    },
    onActivateShare: function(a) {
        this.activated = true;
        this.load(true)
    },
    load: function(a) {
        var b = (this.connId) ? this.connId : 0;
        if (!this.modeWizard) {
            if (a && !this.isStatusBusy) {
                this.owner.setStatusBusy();
                this.isStatusBusy = true
            }
            this.getWebAPI().refreshSession({
                conn_id: this.connId,
                fast_monitor: true
            });
            this.stopPolling()
        } else {
            if (a) {
                this.owner.setStatusBusy()
            }
        }
        this.listLocalShare(function(h, g, f, e) {
            var d = (this.connId) ? this.connId : 0;
            if (b !== d) {
                return
            }
            if (!h && a) {
                if (this.modeWizard) {
                    this.owner.clearStatusBusy()
                }
                this.showErrorMessageBox(g);
                return
            }
            this.model.valid_share = g.shares || [];
            if (this.modeWizard) {
                var c = this.app().conn_entry;
                this.store.load({
                    params: c,
                    callback: function() {
                        if (a) {
                            this.owner.clearStatusBusy()
                        }
                    },
                    scope: this
                })
            } else {
                this.startPolling()
            }
        })
    },
    listLocalShare: function(b, a) {
        this.sendWebAPI({
            webapi: {
                api: "SYNO.Core.Share",
                method: "list",
                version: "1",
                params: {
                    shareType: ["local", "enc", "dec"],
                    additional: ["migrate", "encryption"],
                    check_mounted: true,
                    check_mounted_exceptions: ["#snapshot"]
                }
            },
            callback: b,
            scope: a || this
        })
    },
    onDeactivateShare: function(a) {
        this.activated = false;
        if (!this.modeWizard) {
            this.stopPolling()
        }
    },
    handleLeavingConnection: function(c) {
        var b = this.store.getModifiedRecords().length > 0;
        if (!b) {
            return true
        }
        if (_S("majorversion") < 7) {
            this.owner.getMsgBox().confirm(_SDSS("app", "app_name"), _T("common", "confirm_lostchange"), function(e) {
                if ("yes" === e) {
                    this.store.rejectChanges();
                    if (Ext.isFunction(c)) {
                        c()
                    }
                }
            }, this)
        } else {
            this.owner.confirmLostChangePromise({
                save: function() {
                    return new Promise(function(f, e) {
                        this.handleLeavingConnectionConfirmLostChangeResolve = f;
                        this.onClickSaveButton()
                    }.bind(this))
                },
                dontSave: function() {
                    this.store.rejectChanges()
                },
                cancel: Ext.emptyFn
            }, this, function d() {}, function a() {
                if (Ext.isFunction(c)) {
                    c()
                }
            })
        }
        return false
    },
    onBeforeCloseMainWindow: function(b) {
        var c = this.store.getModifiedRecords().length > 0;
        if (!c) {
            return true
        } else {
            if (_S("majorversion") < 7) {
                this.owner.getMsgBox().confirm(_SDSS("app", "app_name"), _T("common", "confirm_lostchange"), function(e) {
                    if ("yes" === e) {
                        b.destroy()
                    }
                }, this)
            } else {
                this.owner.confirmLostChangePromise({
                    save: function() {
                        return new Promise(function(f, e) {
                            this.onBeforeCloseConfirmLostChangeResolve = f;
                            this.onClickSaveButton()
                        }.bind(this))
                    },
                    dontSave: Ext.emptyFn,
                    cancel: Ext.emptyFn
                }, this, function d() {}, function a() {
                    b.destroy()
                })
            }
            return false
        }
    },
    onClickEnableColumn: function(a, b, f, d) {
        var c = b.getStore().getAt(f);
        if (c.get("enable") === true && (c.get("local_share") === "homes" && c.get("remote_share") === "homes")) {
            this.owner.getMsgBox().alert(this.owner.title, _SDSS("warning", "warn_enable_homes"))
        }
    },
    onClickDeleteButton: function(b, e, a, d) {
        var c = b.getStore().getAt(e);
        if (!c.isSupportDelete()) {
            return
        }
        this.owner.setStatusBusy();
        this.app().getController("Main").stopPollingTask();
        this.owner.getMsgBox().confirm(this.owner.title, _SDSS("msg", "confirm_remove_db", _SDSSAPPNAME), function(g, h, f) {
            if (g === "yes") {
                this.getWebAPI().removeShare(c.get("sess_id"), function(l, i, k, j) {
                    this.owner.clearStatusBusy();
                    if (!l) {
                        this.showErrorMessageBox(i);
                        return
                    }
                    this.app().getController("Main").startPollingTask();
                    this.load(true)
                }, this)
            } else {
                this.owner.clearStatusBusy()
            }
        }, this)
    },
    onClickFolderButton: function(c, h, d, f) {
        var e = c.getStore().getAt(h);
        if (!e.isSupportFolderSetting()) {
            return
        }
        var a;
        var b = true;
        if (this.connId) {
            this.owner.setStatusBusy();
            this.getWebAPI().getConnection(this.connId, function(l, i, k, j) {
                this.owner.clearStatusBusy();
                if (!l) {
                    this.showErrorMessageBox(i.errors);
                    return
                }
                a = i.ver_build_no;
                b = i.user_is_admin
            }, this)
        } else {
            a = this.app().conn_entry.ver_build_no;
            b = this.app().conn_entry.user_is_admin
        }
        var g = this.shareWindow.createShareChooser({
            owner: this.owner,
            serverBuildNumber: a,
            isUserAdmin: b,
            remoteShareRW: e.get("rw"),
            remoteShareName: e.get("remote_share")
        });
        g.share = e;
        g.mon(g, "hide", this.onHideShareChooser, this);
        g.open();
        if (!this.modeWizard) {
            this.app().getController("Main").stopPollingTask()
        }
    },
    onHideShareChooser: function(d) {
        if (d.getRecords().length === 0) {
            return
        }
        var a = d.getRecords()[0];
        var e = a.get("migrate");
        d.share.set("local_share", a.get("name"));
        if (e) {
            d.share.set("perm_sync", 2)
        }
        var c = d.share.get("rw");
        var b = d.share.get("remote_share") === "homes";
        var f = d.share.get("local_share") === "homes";
        if (b) {
            if (f) {
                d.share.set("sync_direction", 0);
                d.share.set("perm_sync", 0)
            } else {
                d.share.set("sync_direction", 2);
                d.share.set("perm_sync", e ? 2 : 0)
            }
        } else {
            if (f) {
                d.share.set("sync_direction", 1);
                d.share.set("perm_sync", e ? 2 : 0)
            } else {
                if (c) {
                    if (a.get("is_force_readonly")) {
                        d.share.set("sync_direction", 1);
                        d.share.set("local_rw", false)
                    } else {
                        d.share.set("sync_direction", 0);
                        d.share.set("local_rw", true)
                    }
                } else {
                    d.share.set("sync_direction", 2);
                    d.share.set("local_rw", true)
                }
            }
        }
        if (!this.modeWizard) {
            this.app().getController("Main").startPollingTask()
        }
        d.destroy()
    },
    onClickAdvanceSettingButton: function(c, f, a, d) {
        var e = {
            owner: this.owner,
            share: c.getStore().getAt(f),
            connId: this.connId,
            filterMap: this.filterMap,
            wizardMode: this.modeWizard,
            valid_share: this.model.valid_share
        };
        if (this.modeWizard) {
            e.connEntry = this.app().conn_entry
        }
        var b = this.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.AdvanceSetting, e);
        b.getViewport().open()
    },
    onChangeSelectedConnection: function(a, b) {
        var c;
        if (_S("majorversion") < 7) {
            if (b.length) {
                c = a.getRecord(b[0]).get("id")
            }
        } else {
            if (b) {
                c = b.attributes.connId
            }
        }
        if (!c) {
            return
        }
        var d = (this.connId) ? this.connId : 0;
        this.connId = c;
        if (this.activated) {
            if (this.connId !== d) {
                this.load(true)
            }
        }
    },
    onClickSaveButton: function(a, b) {
        if (this.connId) {
            this.owner.setStatusBusy();
            this.getWebAPI().getConnection(this.connId, function(f, c, e, d) {
                this.owner.clearStatusBusy();
                if (!f) {
                    this.showErrorMessageBox(c);
                    return
                }
                this.applySetting(this.store.getModifiedShareList(c.ver_build_no, c.user_is_admin, this.model.valid_share))
            }, this)
        } else {
            this.applySetting(this.store.getModifiedShareList(this.app().conn_entry.ver_build_no, this.app().conn_entry.user_is_admin, this.model.valid_share))
        }
    },
    applySetting: function(b) {
        if (b.length === 0) {
            this.showNoSettingChanged(this.shareWindow);
            return
        }
        for (var a = 0; a < b.length; ++a) {
            if (b[a].local_share === "--") {
                this.owner.getMsgBox().alert(this.owner.title, _SDSS("msg", "choose_local_sync_folder_info"));
                return
            }
        }
        this.owner.setStatusBusy();
        this.getWebAPI().testShare(b, {
            conn_id: this.connId
        }, function(f, c, e, d) {
            if (!f) {
                this.owner.clearStatusBusy();
                this.showErrorMessageBox(c);
                return
            }
            this.updateShare(b)
        }, this)
    },
    updateShare: function(c) {
        this.stopPolling();
        for (var b = 0; b < c.length; b++) {
            var a = c[b].view_id;
            if (this.filterMap.hasOwnProperty(a)) {
                Ext.apply(c[b], this.filterMap[a])
            }
        }
        var d = new SYNO.SDS.SynologyDriveShareSync.Util.SessionSetTask({
            owner: this.owner,
            app: this.app(),
            scope: this,
            error: function(e) {
                var f = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(e.error || e);
                if (e.error.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.ENABLE_SESSION_PARTIAL && e.error.errors.enable_error_list) {
                    Ext.each(e.error.errors.enable_error_list, function(g) {
                        if (SYNO.SDS.SynologyDriveShareSync.Util.IsEnableSessionPartialError(g.error)) {
                            f += "<li>" + String.format(SYNO.SDS.SynologyDriveShareSync.Util.GetErrorStringWithErrorCode(g.error), g.local_share) + "</li>"
                        }
                    })
                }
                this.owner.getMsgBox().alert(this.owner.title, f, function() {
                    if (this.modeWizard) {
                        this.owner.wizardDone = true;
                        this.owner.close()
                    } else {
                        this.app().getController("Main").restartPollingTask();
                        this.startPolling()
                    }
                }, this)
            },
            success: function(e) {
                if (this.modeWizard) {
                    this.owner.wizardDone = true;
                    this.owner.close()
                } else {
                    this.store.commitChanges();
                    this.app().getController("Main").restartPollingTask();
                    this.startPolling()
                }
                if (this.onBeforeCloseConfirmLostChangeResolve) {
                    this.onBeforeCloseConfirmLostChangeResolve()
                }
                if (this.handleLeavingConnectionConfirmLostChangeResolve) {
                    this.handleLeavingConnectionConfirmLostChangeResolve()
                }
            }
        });
        this.owner.clearStatusBusy();
        d.startTask({
            sess_list: c
        })
    },
    onClickResetButton: function(a, b) {
        this.store.rejectChanges()
    },
    showNoSettingChanged: function(b) {
        var a = b.getFooterToolbar();
        a.setStatus({
            text: _T("error", "nochange_subject"),
            clear: true,
            iconCls: "syno-ux-statusbar-error"
        })
    },
    showErrorMessageBox: function(b) {
        var a = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(b);
        this.owner.getMsgBox().alert(this.owner.title, a)
    },
    handleSessListUpdate: function(d, a, c, b) {
        if (this.prevConnId !== this.connId) {
            this.store.removeAll();
            this.filterMap = {};
            this.prevConnId = this.connId
        }
        if (this.isStatusBusy) {
            this.owner.clearStatusBusy();
            this.isStatusBusy = false
        }
        if (d) {
            this.store.loadData({
                session: a.session
            }, {
                update: true,
                preserveDirtyRecord: true,
                preserveDirtyFields: ["enable", "local_share", "perm_sync", "sync_direction", "attribute_check_strength", "local_rw"],
                scope: this
            })
        }
    },
    startPolling: function(a) {
        if (this.isPolling) {
            return
        }
        var b = this.app().getController("Main");
        b.monPolling(this, "updateSessList", this.handleSessListUpdate, this);
        b.restartPollingTask();
        this.isPolling = true
    },
    stopPolling: function() {
        if (!this.isPolling) {
            return
        }
        var a = this.app().getController("Main");
        a.munPolling(this, "updateSessList", this.handleSessListUpdate, this);
        this.isPolling = false
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Introduction", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "introductionWindow",
            width: 680,
            height: 467,
            header: false,
            elements: "body",
            useStatusBar: false,
            resizable: false,
            closable: false,
            draggable: false,
            layout: "vbox",
            layoutConfig: {
                align: "center"
            },
            cls: "syno-sdss-introduction",
            items: [{
                xtype: "spacer",
                height: 20
            }, {
                xtype: "container",
                cls: "syno-sdss-introduction-bg"
            }, {
                xtype: "spacer",
                height: 20
            }, {
                xtype: "container",
                html: _SDSS("title", "title_introduction"),
                cls: ["normal-font", "syno-sdss-introduction-title"]
            }, {
                xtype: "spacer",
                height: 12
            }, {
                xtype: "container",
                cls: ["normal-font", "syno-sdss-introduction-description"],
                html: _SDSS("msg", "desc_introduction")
            }, {
                xtype: "container",
                flex: 1
            }, {
                xtype: "syno_button",
                itemId: "startButton",
                text: _SDSS("btn", "btn_start_now"),
                btnStyle: "blue",
                cls: "syno-sdss-introduction-button",
                autoWidth: false
            }, {
                xtype: "spacer",
                height: 36
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Introduction", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Widget",
    viewport: "SYNO.SDS.SynologyDriveShareSync.View.Introduction",
    init: function() {
        this.control({
            introductionWindow: {
                close: this.onCloseIntroductionWindow
            },
            startButton: {
                click: this.onClickStartButton
            }
        });
        this.introductionWindow = this.componentQuery("introductionWindow");
        this.closed = false
    },
    onCloseIntroductionWindow: function() {
        if (this.closed) {
            return
        }
        this.closed = true;
        this.owner.close()
    },
    onClickStartButton: function(a, b) {
        var d = this.getMainApplication().getController("Main");
        var c = d.createWidget(SYNO.SDS.SynologyDriveShareSync.Controller.Wizard, {
            owner: this.owner,
            editMode: false,
            firstConnection: true
        });
        d.mon(c, "launchService", d.launchService, d, {
            single: true
        });
        c.getViewport().open();
        this.introductionWindow.destroy();
        this.destroy()
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Wizard.Account", {
    extend: "SYNO.ux.FormPanel",
    xtype: "sdss_wizard_account",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            header: false,
            hideLabels: true,
            items: [{
                xtype: "syno_textfield",
                allowBlank: false,
                indent: 1,
                width: 410,
                name: "address",
                emptyText: _SDSS("title", "title_ip_detail")
            }, {
                xtype: "syno_textfield",
                allowBlank: false,
                width: 410,
                name: "user",
                emptyText: _SDSS("title", "title_usr")
            }, {
                xtype: "syno_textfield",
                allowBlank: true,
                width: 410,
                name: "password",
                textType: "password",
                emptyText: _SDSS("title", "title_pwd")
            }, {
                xtype: "syno_checkbox",
                name: "ssl_enable",
                checked: true,
                boxLabel: _SDSS("manage", "option_enable_ssl")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Wizard.Viewport", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)]);
        this.addEvents("clickHelp")
    },
    fillConfig: function(b) {
        var a = {
            itemId: "wizardWindow",
            title: _SDSSAPPNAME,
            width: 620,
            height: 462,
            cls: "syno-sdss-create-wizard",
            tools: [{
                id: "help",
                scope: this,
                handler: function(f, e, d, c) {
                    this.fireEvent("clickHelp", f, e, d, c)
                }
            }],
            steps: [{
                xtype: "sdss_wizard_account",
                itemId: "conn_info",
                headline: _SDSS("msg", "link_info"),
                nextId: (!b.editMode) ? "target_share" : null,
                padding: "40px 0px 0px 65px"
            }, {
                xtype: "sdss_connection_share",
                header: false,
                itemId: "target_share",
                headline: _SDSS("msg", "seldir"),
                modeWizard: true,
                store: b.application.getStore("Share")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Wizard", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Widget",
    viewport: "SYNO.SDS.SynologyDriveShareSync.View.Wizard.Viewport",
    controllers: ["SYNO.SDS.SynologyDriveShareSync.Controller.Share"],
    models: ["SYNO.SDS.SynologyDriveShareSync.Model.Connection", "SYNO.SDS.SynologyDriveShareSync.Model.Share"],
    stores: ["SYNO.SDS.SynologyDriveShareSync.Store.Share"],
    constructor: function(a) {
        this.callParent([Ext.apply({
            modeWizard: true
        }, a)])
    },
    init: function() {
        this.control({
            wizardWindow: {
                show: this.onShowWizardWindow,
                close: this.onCloseWizardWindow,
                clickHelp: this.onClickHelp
            },
            conn_info: {
                afterlayout: this.onAfterLayoutAccountInfo
            }
        });
        this.wizardWindow = this.componentQuery("wizardWindow");
        this.model = this.getModel("Share");
        this.connectionModel = this.getModel("Connection");
        this.addEvents("launchService");
        this.wizardWindow.getStep("conn_info").getNext = Ext.createDelegate(this.getNextStepOfAccount, this);
        this.wizardWindow.getStep("target_share").getBack = Ext.createDelegate(this.getBackStepOfShare, this);
        this.wizardWindow.getStep("target_share").getNext = Ext.createDelegate(this.getNextStepOfShare, this);
        this.mon(this.componentQuery("synced_folder_grid", this.wizardWindow.getStep("target_share")).getStore(), "load", this.onLoadShareStore, this);
        this.stateMachine = new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.StateMachine()
    },
    onShowWizardWindow: function(a) {
        if (!this.firstConnection) {
            this.getMainApplication().getController("Main").stopPollingTask()
        }
        this.closed = false
    },
    onCloseWizardWindow: function() {
        if (this.closed) {
            return
        }
        this.closed = true;
        if (this.is_connection_created && !this.wizardWindow.wizardDone) {
            this.cancelConnection()
        }
        if (this.firstConnection) {
            if (this.wizardWindow.wizardDone) {
                this.fireEvent("launchService")
            } else {
                this.owner.close()
            }
        } else {
            this.getMainApplication().getController("Main").startPollingTask()
        }
    },
    onClickHelp: function() {
        var a = "SYNO.SDS.Drive.Application:drive_sharesync.html";
        if (_S("standalone")) {
            SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            })
        } else {
            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            }, false)
        }
    },
    onAfterLayoutAccountInfo: function(a, b) {
        if (this.editMode && this.connId) {
            this.wizardWindow.setStatusBusy();
            this.getWebAPI().getConnection(this.connId, function(g, c, f, e) {
                var d = this.wizardWindow.getStep("conn_info").getForm();
                if (!g) {
                    this.showErrorMessageBox(c);
                    return
                }
                this.wizardWindow.clearStatusBusy();
                d.findField("address").setValue(c.server_name);
                d.findField("user").setValue(c.user);
                d.findField("ssl_enable").setValue(c.ssl_enable);
                d.findField("user").setDisabled(true)
            }, this)
        }
    },
    getNextStepOfAccount: function() {
        if (this.stateMachine.currentStateName() != "conn_info") {
            return false
        }
        var c = this.wizardWindow.getStep("conn_info").getForm();
        if (!c.isValid()) {
            this.wizardWindow.getMsgBox().alert(this.wizardWindow.title, _SDSS("warning", "invalid_param"));
            return false
        }
        var b = c.findField("address").getValue(),
            a = c.findField("ssl_enable").getValue();
        this.testConnection(b, a, this.editMode);
        return false
    },
    testConnection: function(a, c, b) {
        this.wizardWindow.setStatusBusy({
            text: _SDSS("msg", "testing_connect")
        });
        this.getWebAPI().testConnection(a, c, b, function(h, d, g, f) {
            this.wizardWindow.clearStatusBusy();
            if (!h) {
                this.showErrorMessageBox(d);
                return
            }
            var e = this.wizardWindow.getStep("conn_info").getForm();
            this.conn_entry = Ext.apply({}, d);
            this.conn_entry.user_name = e.findField("user").getValue();
            this.conn_entry.user_passwd = e.findField("password").getValue();
            this.conn_entry.ssl_enable = e.findField("ssl_enable").getValue();
            this.conn_entry.do_verify_ssl = true;
            this.conn_entry.c_mode = d.conn_mode;
            this.conn_entry.domain_name = d.domain_name;
            if (this.editMode) {
                var i = this.connId;
                this.editLink(i)
            } else {
                this.createLink()
            }
            this.gotoNextState()
        }, this)
    },
    editLink: function(a) {
        this.wizardWindow.setStatusBusy();
        this.getWebAPI().createLink(this.conn_entry, function(e, b, d, c) {
            if (!e) {
                this.wizardWindow.clearStatusBusy();
                if (b.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.OTP_REQUIRED) {
                    this.wizardWindow.getMsgBox().prompt(this.wizardWindow.title, _SDSS("msg", "connection_enter_otp"), function(g, f) {
                        if (g === "ok") {
                            this.conn_entry.otp = f;
                            this.editLink(a)
                        } else {
                            this.showErrorMessageBox(b);
                            this.gotoBackState()
                        }
                    }, this)
                } else {
                    if (b.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.SSL_VERIFY_FAIL) {
                        this.wizardWindow.getMsgBox().confirm(_SDSS("warning", "title_ssl_warning"), _SDSS("msg", "ssl_error"), function(f) {
                            if ("yes" === f) {
                                this.conn_entry.do_verify_ssl = false;
                                this.editLink(a)
                            } else {
                                this.gotoBackState()
                            }
                        }, this)
                    } else {
                        this.showErrorMessageBox(b);
                        this.gotoBackState()
                    }
                }
                return
            }
            delete this.conn_entry.user_passwd;
            this.conn_entry.sess_token = b.sess_token;
            this.conn_entry.ssl_signature = b.ssl_signature;
            this.conn_entry.user_is_admin = b.is_admin_group;
            this.conn_entry.computer_name = b.computer_name;
            this.updateLink(a, this.conn_entry, false)
        }, this)
    },
    updateLink: function(c, a, b) {
        this.getWebAPI().editLink(c, this.conn_entry, b, function(g, d, f, e) {
            this.wizardWindow.clearStatusBusy();
            if (!g) {
                if (!b && d.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.SSL_CHANGE) {
                    this.wizardWindow.getMsgBox().confirm(_SDSS("warning", "title_ssl_warning"), _SDSS("warning", "msg_ssl_change"), function(h) {
                        if ("yes" === h) {
                            this.wizardWindow.setStatusBusy();
                            this.updateLink(c, a, true)
                        } else {
                            this.gotoBackState()
                        }
                    }, this)
                } else {
                    this.showErrorMessageBox(d);
                    this.gotoBackState()
                }
                return
            }
            this.gotoNextState()
        }, this)
    },
    createLink: function() {
        this.wizardWindow.setStatusBusy({
            text: _SDSS("msg", "checkpass")
        });
        this.getWebAPI().createLink(this.conn_entry, function(d, a, c, b) {
            this.wizardWindow.clearStatusBusy();
            if (!d) {
                if (a.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.OTP_REQUIRED) {
                    this.wizardWindow.getMsgBox().prompt(this.wizardWindow.title, _SDSS("msg", "connection_enter_otp"), function(f, e) {
                        if (f === "ok") {
                            this.conn_entry.otp = e;
                            this.createLink()
                        } else {
                            this.showErrorMessageBox(a);
                            this.gotoBackState()
                        }
                    }, this)
                } else {
                    if (a.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.SSL_VERIFY_FAIL) {
                        this.wizardWindow.getMsgBox().confirm(_SDSS("warning", "title_ssl_warning"), _SDSS("msg", "ssl_error"), function(e) {
                            if ("yes" === e) {
                                this.conn_entry.do_verify_ssl = false;
                                this.createLink()
                            } else {
                                this.gotoBackState()
                            }
                        }, this)
                    } else {
                        this.showErrorMessageBox(a);
                        this.gotoBackState()
                    }
                }
                return
            }
            delete this.conn_entry.user_passwd;
            this.conn_entry.sess_token = a.sess_token;
            this.conn_entry.ssl_signature = a.ssl_signature;
            this.conn_entry.user_is_admin = a.is_admin_group;
            this.conn_entry.computer_name = a.computer_name;
            this.is_connection_created = true;
            this.gotoNextState()
        }, this)
    },
    getNextStepOfShare: function() {
        if (this.stateMachine.currentStateName() != "target_share") {
            return false
        }
        var b = this.getStore("Share").getModifiedShareList(this.conn_entry.ver_build_no, this.conn_entry.user_is_admin, this.app().getModel("Share").valid_share);
        if (b.length === 0) {
            this.owner.getMsgBox().alert(this.owner.title, _SDSS("msg", "no_selected_share_folder"));
            return false
        }
        for (var a = 0; a < b.length; ++a) {
            if (b[a].local_share === "--") {
                this.owner.getMsgBox().alert(this.owner.title, _SDSS("msg", "choose_local_sync_folder_info"));
                return false
            }
        }
        this.createConnection(b);
        return false
    },
    createConnection: function(a) {
        this.wizardWindow.setStatusBusy();
        a.forEach(function(b) {
            b.conn_id = 0
        });
        this.getWebAPI().testShare(a, this.conn_entry, function(e, b, d, c) {
            if (!e) {
                this.wizardWindow.clearStatusBusy();
                this.showErrorMessageBox(b);
                return
            }
            this.updateConnection(a)
        }, this)
    },
    updateConnection: function(a) {
        this.getWebAPI().createConnection(this.conn_entry, function(e, b, d, c) {
            if (!e) {
                this.wizardWindow.clearStatusBusy();
                this.showErrorMessageBox(b);
                return
            }
            a.forEach(function(f) {
                f.conn_id = b.connection_id
            });
            this.getController("Share").updateShare(a)
        }, this)
    },
    getBackStepOfShare: function() {
        if (this.stateMachine.currentStateName() != "target_share") {
            return false
        }
        this.cancelConnection();
        return false
    },
    cancelConnection: function() {
        this.wizardWindow.setStatusBusy();
        this.getWebAPI().cancelConnection(this.conn_entry, function(d, a, c, b) {
            this.is_connection_created = false;
            this.wizardWindow.clearStatusBusy();
            if (!this.closed) {
                this.gotoBackState()
            }
            return
        }, this)
    },
    onLoadShareStore: function(b, a, c) {
        if (!a.length) {
            this.wizardWindow.getMsgBox().alert(this.wizardWindow.title, _SDSS("msg", "no_valid_folder"), function(d) {
                this.gotoBackState()
            }, this)
        }
    },
    showErrorMessageBox: function(b) {
        var a;
        if (b.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.AUTH) {
            a = _SDSS("msg", "test_username_fail")
        } else {
            a = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(b)
        }
        this.wizardWindow.getMsgBox().alert(this.wizardWindow.title, a)
    },
    gotoNextPage: function() {
        var a = this.wizardWindow.getActiveStep().nextId;
        this.wizardWindow.goNext((a) ? a : null)
    },
    gotoNextState: function() {
        this.stateMachine.nextState();
        if (!this.stateMachine.isNeedChangePage()) {
            this.gotoNextPage()
        }
    },
    gotoBackState: function() {
        this.stateMachine.backState();
        if (!this.stateMachine.isNeedChangePage()) {
            this.wizardWindow.goBack()
        }
    }
});
Ext.ns("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState");
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.StateMachine", {
    constructor: function() {
        this.currentState = new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.ConnInfoState(this)
    },
    changeState: function(a) {
        this.currentState = a
    },
    currentStateName: function() {
        return this.currentState ? this.currentState.stateName() : ""
    },
    isNeedChangePage: function() {
        return this.currentState ? this.currentState.isNeedChangePage() : false
    },
    nextState: function() {
        if (this.currentState) {
            this.currentState.nextState()
        }
    },
    backState: function() {
        if (this.currentState) {
            this.currentState.backState()
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.State", {
    constructor: function(a) {
        this.page = a
    },
    stateName: function() {
        return ""
    },
    isNeedChangePage: function() {
        return false
    },
    nextState: function() {
        this.page.changeState(null)
    },
    backState: function() {
        this.page.changeState(null)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.ConnInfoState", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.State",
    constructor: function(a) {
        this.callParent(arguments)
    },
    stateName: function() {
        return "conn_info"
    },
    nextState: function() {
        this.page.changeState(new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.TestConnectionState(this.page))
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.TestConnectionState", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.State",
    constructor: function(a) {
        this.callParent(arguments)
    },
    stateName: function() {
        return "test_conn"
    },
    isNeedChangePage: function() {
        return true
    },
    nextState: function() {
        this.page.changeState(new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.TargetShareState(this.page))
    },
    backState: function() {
        this.page.changeState(new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.ConnInfoState(this.page))
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.TargetShareState", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.State",
    constructor: function(a) {
        this.callParent(arguments)
    },
    stateName: function() {
        return "target_share"
    },
    backState: function() {
        this.page.changeState(new SYNO.SDS.SynologyDriveShareSync.Controller.WizardState.ConnInfoState(this.page))
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Setting", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            title: _SDSS("msg", "summary"),
            itemId: "settingWindow",
            width: 600,
            height: 450,
            resizable: false,
            layout: "fit",
            cls: "syno-sdss-setting",
            items: [{
                xtype: "syno_formpanel",
                itemId: "configForm",
                border: false,
                bodyStyle: "padding: 0",
                labelWidth: "auto",
                items: [{
                    id: this.cbIdRepoProvider,
                    itemId: "repoCombobox",
                    xtype: "syno_combobox",
                    name: "repo_provider",
                    fieldLabel: _SDSS("title", "db_location_setting"),
                    labelStyle: "margin-right: 5px; width: auto !important; max-width: 244px;",
                    width: 290,
                    valueField: "volume_path",
                    displayField: "display_name",
                    allowBlank: false,
                    scope: this,
                    store: new Ext.data.JsonStore({
                        fields: ["display_name", "volume_path"],
                        root: "volumes"
                    }),
                    triggerAction: "all",
                    forceSelection: true,
                    mode: "local",
                    hideLabel: false,
                    selectOnFocus: true,
                    editable: false,
                    hidden: false
                }, {
                    xtype: "syno_displayfield",
                    value: _SDSS("manage", "synchronization_mode_desc"),
                    style: "margin-top: 12px"
                }, {
                    itemId: "mergeModeRadio",
                    xtype: "syno_radio",
                    name: "synchronization_mode",
                    boxLabel: _SDSS("manage", "synchronization_mode_merge_mode"),
                    indent: 1
                }, {
                    itemId: "syncModeRadio",
                    xtype: "syno_radio",
                    name: "synchronization_mode",
                    boxLabel: _SDSS("manage", "synchronization_mode_sync_mode"),
                    indent: 1
                }, {
                    xtype: "syno_displayfield",
                    value: _SDSS("manage", "conflict_policy_desc"),
                    style: "margin-top: 12px"
                }, {
                    itemId: "conflictPolicyCompareMtimeRadio",
                    xtype: "syno_radio",
                    name: "conflict_policy",
                    boxLabel: _SDSS("manage", "conflict_policy_compare_mtime"),
                    indent: 1
                }, {
                    itemId: "conflictPolicyOverwriteClientRadio",
                    xtype: "syno_radio",
                    name: "conflict_policy",
                    boxLabel: _SDSS("manage", "conflict_policy_overwrite_client"),
                    indent: 1
                }, {
                    itemId: "renameConflictCheckbox",
                    xtype: "syno_checkbox",
                    name: "rename_conflict",
                    boxLabel: _SDSS("manage", "conflict_policy_rename_conflict"),
                    indent: 1
                }]
            }],
            buttons: [{
                text: _T("common", "cancel"),
                handler: this.close,
                scope: this
            }, {
                text: _T("common", "apply"),
                itemId: "applyButton",
                cls: "syno-ux-button-blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Setting", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Widget",
    viewport: "SYNO.SDS.SynologyDriveShareSync.View.Setting",
    init: function() {
        this.control({
            settingWindow: {
                beforeshow: this.onBeforeShowWindow,
                beforeclose: this.onBeforeCloseWindow
            },
            applyButton: {
                click: this.onClickApplyButton
            }
        });
        this.settingWindow = this.componentQuery("settingWindow");
        this.repoCombobox = this.componentQuery("configForm repoCombobox");
        this.conflictPolicyCompareMtimeRadio = this.componentQuery("configForm conflictPolicyCompareMtimeRadio");
        this.conflictPolicyOverwriteClientRadio = this.componentQuery("configForm conflictPolicyOverwriteClientRadio");
        this.renameConflictCheckbox = this.componentQuery("configForm renameConflictCheckbox");
        this.mergeModeRadio = this.componentQuery("configForm mergeModeRadio");
        this.syncModeRadio = this.componentQuery("configForm syncModeRadio")
    },
    onBeforeShowWindow: function(a) {
        this.getVolumes()
    },
    getVolumes: function() {
        this.settingWindow.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.Storage.Volume",
            version: 1,
            method: "list",
            params: {
                offset: 0,
                limit: 10,
                location: "internal"
            },
            callback: function(d, c, b, a) {
                if (!d || !c || !(c.volumes instanceof Array)) {
                    this.settingWindow.clearStatusBusy();
                    this.showErrorMessageBox(c);
                    return
                }
                if (d) {
                    this.repoCombobox.getStore().loadData(c);
                    this.getSettings()
                }
            },
            scope: this
        })
    },
    getSettings: function() {
        this.getWebAPI().getConfig(function(d, a, c, b) {
            this.settingWindow.clearStatusBusy();
            if (!d) {
                this.showErrorMessageBox(a);
                return
            }
            this.repoCombobox.setValue(a.repo_loc);
            if (a.conflict_policy == "compare_mtime") {
                this.conflictPolicyCompareMtimeRadio.setValue(true)
            } else {
                this.conflictPolicyOverwriteClientRadio.setValue(true)
            }
            this.renameConflictCheckbox.setValue(a.rename_conflict);
            if (a.synchronization_mode == "sync_mode") {
                this.syncModeRadio.setValue(true)
            } else {
                this.mergeModeRadio.setValue(true)
            }
            this.oldVolume = a.repo_loc;
            this.oldPolicy = a.conflict_policy;
            this.oldRenameConflict = a.rename_conflict;
            this.oldSynchronizationMode = a.synchronization_mode;
            if ("yes" === _D("usbstation")) {
                this.repoCombobox.setDisabled(true)
            }
        }, this)
    },
    onClickApplyButton: function(c, e) {
        var d = this.repoCombobox.getValue();
        var b = this.renameConflictCheckbox.getValue();
        var a;
        var f;
        if (this.conflictPolicyCompareMtimeRadio.getValue()) {
            a = "compare_mtime"
        } else {
            a = "overwrite_client"
        }
        if (this.syncModeRadio.getValue()) {
            f = "sync_mode"
        } else {
            f = "merge_mode"
        }
        this.settingWindow.setStatusBusy();
        this.getWebAPI().setConfig(d, a, b, f, function(j, g, i, h) {
            this.settingWindow.clearStatusBusy();
            if (j) {
                this.settingWindow.destroy();
                this.destroy()
            } else {
                if (g.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.REPO_MOVE) {
                    this.settingWindow.getMsgBox().alert("msg", _SDSS("warning", "err_repomove"), function() {
                        this.owner.close()
                    }, this)
                } else {
                    this.showErrorMessageBox(g)
                }
            }
        }, this)
    },
    onBeforeCloseWindow: function(b, e) {
        var d = this.repoCombobox.getValue();
        var c = this.renameConflictCheckbox.getValue();
        var a;
        var f;
        if (this.conflictPolicyCompareMtimeRadio.getValue()) {
            a = "compare_mtime"
        } else {
            a = "overwrite_client"
        }
        if (this.syncModeRadio.getValue()) {
            f = "sync_mode"
        } else {
            f = "merge_mode"
        }
        if (d !== this.oldVolume || a !== this.oldPolicy || c !== this.oldRenameConflict || f != this.oldSynchronizationMode) {
            if (_S("majorversion") < 7) {
                this.settingWindow.getMsgBox().confirm(_SDSS("app", "app_name"), _T("common", "confirm_lostchange"), function(g) {
                    if ("yes" === g) {
                        this.settingWindow.destroy();
                        this.destroy()
                    }
                }, this)
            } else {
                this.settingWindow.confirmLostChangePromise({
                    save: this.onClickApplyButton,
                    dontSave: function() {
                        this.settingWindow.destroy();
                        this.destroy()
                    },
                    cancel: Ext.emptyFn
                }, this)
            }
            return false
        } else {
            this.destroy();
            return true
        }
    },
    showErrorMessageBox: function(b) {
        var a = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(b);
        this.settingWindow.getMsgBox().alert(this.settingWindow.title, a)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.SearchField", {
    extend: "SYNO.ux.SearchField",
    xtype: "sdss_searchfield",
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() == Ext.EventObject.ENTER) {
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof Ext.form.DateField) {
                    if (d instanceof SYNO.ux.DateTimeField) {
                        if (d.isWithinEl(c)) {
                            a = true;
                            return false
                        }
                    } else {
                        if (d.menu && c.within(d.menu.getEl())) {
                            a = true;
                            return false
                        }
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tl-bl?", [0, 0]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.SearchPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.searchPanel = null;
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        };
        this.dataRange = [
            [this.dateType.custom, _T("log", "date_custom")],
            [this.dateType.today, _T("log", "date_today")],
            [this.dateType.yesterday, _T("log", "date_yesterday")],
            [this.dateType.lastweek, _T("log", "date_lastweek")],
            [this.dateType.lastmonth, _T("log", "date_lastmonth")]
        ];
        this.actionfilterType = {
            all: 1,
            download: 2,
            upload: 4,
            remove: 8,
            rename: 16,
            unsynced: 32
        };
        this.actionfilterRange = [
            [this.actionfilterType.all, _SDSS("history", "all_event")],
            [this.actionfilterType.download, _SDSS("history", "download")],
            [this.actionfilterType.upload, _SDSS("history", "upload")],
            [this.actionfilterType.remove, _SDSS("history", "delete")],
            [this.actionfilterType.rename, _SDSS("history", "rename")],
            [this.actionfilterType.unsynced, _SDSS("history", "type_unsynced")]
        ];
        this.defaultAnimation = ["#000", 1, {
            duration: 0.35
        }];
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(e) {
        var d, g, h, f, c;
        var b = [];
        d = this.createKeyword();
        g = this.createFriendlyDate();
        h = this.createCustDate();
        c = this.createFilterActionType();
        f = this.createFootBar();
        b.push(d);
        b.push(g);
        b.push(h);
        b.push(c);
        b.push(f);
        var a = {
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            border: true,
            cls: "syno-sdss-search-panel",
            autoFlexcroll: false,
            hidden: true,
            shadow: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            itemId: "searchPanel",
            items: b
        };
        return Ext.apply(a, e)
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "keyword",
            flex: 2,
            vaule: ""
        }]
    },
    createFriendlyDate: function() {
        this.friendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "dateRange",
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforeselect: this.friendlyDateSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.friendlyDate]
    },
    createCustDate: function() {
        this.dateFrom = {
            xtype: _S("majorversion") < 7 ? "syno_datefield" : "syno_datetimefield",
            name: "searchdatefrom",
            editable: false,
            format: SYNO.SDS.DateTimeUtils ? SYNO.SDS.DateTimeUtils.GetDateFormat() : "Y-m-d",
            emptyText: _T("log", "date_from"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdateto").setMinValue(a)
                }
            }
        };
        this.dateTo = {
            xtype: _S("majorversion") < 7 ? "syno_datefield" : "syno_datetimefield",
            name: "searchdateto",
            editable: false,
            format: SYNO.SDS.DateTimeUtils ? SYNO.SDS.DateTimeUtils.GetDateFormat() : "Y-m-d",
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdatefrom").setMaxValue(a)
                }
            }
        };
        return [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.dateFrom, this.dateTo]
        }]
    },
    createFilterActionType: function() {
        this.filteraction = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "filteractionRange",
            store: this.getActionFilterStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            value: this.actionfilterType.all
        });
        return [{
            xtype: "syno_displayfield",
            value: _SDSS("history", "type") + _T("common", "colon"),
            flex: 1
        }, this.filteraction]
    },
    createFootBar: function() {
        if (_S("majorversion") < 7) {
            return [{
                xtype: "toolbar",
                border: false,
                itemId: "btns",
                toolbarCls: "search-panel-fbar-btnPanel",
                items: [{
                    xtype: "tbfill"
                }, {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    style: "margin-right: 10px",
                    text: _T("log", "search"),
                    itemId: "btn_search",
                    handler: this.onSearch,
                    scope: this
                }, {
                    xtype: "syno_button",
                    minWidth: 80,
                    text: _T("common", "reset"),
                    handler: this.onReset,
                    scope: this
                }]
            }]
        } else {
            return [{
                xtype: "toolbar",
                border: false,
                itemId: "btns",
                toolbarCls: "search-panel-fbar-btnPanel",
                items: [{
                    xtype: "tbfill"
                }, {
                    xtype: "syno_button",
                    width: 80,
                    text: _T("common", "reset"),
                    handler: this.onReset,
                    scope: this
                }, {
                    xtype: "syno_button",
                    width: 120,
                    btnStyle: "blue",
                    text: _T("log", "search"),
                    itemId: "btn_search",
                    handler: this.onSearch,
                    scope: this
                }]
            }]
        }
    },
    setKeyWord: function(a) {
        var b = this.getForm().findField("keyword");
        if (b && Ext.isString(a)) {
            b.setValue(a)
        }
        b.focus("", 1)
    },
    onSearch: function() {
        var c, b, f, a, e;
        var d;
        c = this.getForm();
        b = c.findField("keyword").getValue();
        f = c.findField("searchdatefrom").getValue();
        a = c.findField("searchdateto").getValue();
        e = c.findField("filteractionRange").getValue();
        d = {
            keyword: b,
            date_from: f ? new Date(f.getFullYear(), f.getMonth(), f.getDate(), 0, 0, 0).getTime() / 1000 : 0,
            date_to: a ? new Date(a.getFullYear(), a.getMonth(), a.getDate(), 23, 59, 59).getTime() / 1000 : 0,
            filter_action: e
        };
        this.fireEvent("search", this, d)
    },
    onReset: function() {
        this.getForm().items.each(function(a) {
            if (a.isDirty()) {
                this.frameAnimation(a.el, this.defaultAnimation)
            }
        }, this);
        this.getForm().reset();
        this.getForm().findField("searchdatefrom").setMaxValue(null);
        this.getForm().findField("searchdateto").setMinValue(null)
    },
    frameAnimation: function(a, b) {
        if (a && a.isVisible()) {
            Ext.Element.prototype.frame.apply(a, b)
        }
    },
    setDate: function(c, b, a) {
        if (a === true) {
            this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation);
            this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)
        }
        this.form.findField("searchdatefrom").setMaxValue(b);
        this.form.findField("searchdateto").setMinValue(c);
        this.form.findField("searchdatefrom").setValue(c);
        this.form.findField("searchdateto").setValue(b)
    },
    getFromToDate: function(c) {
        var e, d;
        var b = new Date();
        if (c === this.dateType.today) {
            e = d = b
        } else {
            if (c === this.dateType.yesterday) {
                e = d = b.add(Date.DAY, -1)
            } else {
                if (c === this.dateType.lastweek) {
                    var a = b.getDay();
                    e = b.add(Date.DAY, -7 - a);
                    d = e.add(Date.DAY, 6)
                } else {
                    if (c === this.dateType.lastmonth) {
                        e = b.add(Date.MONTH, -1).getFirstDateOfMonth();
                        d = b.add(Date.MONTH, -1).getLastDateOfMonth()
                    }
                }
            }
        }
        return {
            from: e,
            to: d
        }
    },
    friendlyDateSelect: function(c, e, a) {
        var b = e.get("id");
        var d = this.getFromToDate(b);
        this.setDate(d.from, d.to, true)
    },
    getFriendlyDateStore: function() {
        var a = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    },
    getActionFilterStore: function() {
        var a = this.actionfilterRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.SyncLog", {
    extend: "SYNO.SDS.ModalWindow",
    border: false,
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        this.pageSize = 200;
        this.searchPanel = new SYNO.SDS.SynologyDriveShareSync.Component.SearchPanel({
            renderTo: Ext.getBody(),
            owner: this
        });
        var d = new Ext.Toolbar({
            itemId: "syncToolBar",
            items: [{
                xtype: "syno_combobox",
                itemId: "taskCombo",
                displayField: "display_text",
                valueField: "sess_id",
                disbled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                store: new Ext.data.JsonStore({
                    fields: ["display_text", "sess_id", "folder_path"]
                })
            }, "->", {
                region: "east",
                xtype: "sdss_searchfield",
                searchPanel: this.searchPanel,
                itemId: "searchField"
            }]
        });
        var e = new SYNO.ux.PagingToolbar({
            store: b.application.getStore("SyncLog"),
            pageSize: this.pageSize,
            displayInfo: true
        });
        var c = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                handler: this.close,
                scope: this
            }]
        };
        var a = {
            title: _SDSS("history", "page_title"),
            itemId: "logWindow",
            width: 700,
            height: 500,
            resizable: false,
            layout: "fit",
            padding: "16px 20px 0px 20px",
            useStatusBar: false,
            fbar: c,
            items: [{
                xtype: "syno_gridpanel",
                itemId: "logGrid",
                border: false,
                loadMask: true,
                tbar: d,
                colModel: this.createColumnModel(b),
                mode: "remote",
                store: b.application.getStore("SyncLog"),
                bbar: e
            }]
        };
        return Ext.apply(a, b)
    },
    createColumnModel: function(c) {
        var b = [{
            header: _SDSS("history", "file_name"),
            dataIndex: "path",
            renderer: this.renderName
        }, {
            header: _SDSS("history", "action"),
            dataIndex: "action",
            renderer: this.renderAction
        }, {
            header: _SDSS("history", "file_type"),
            dateIndex: "is_dir",
            renderer: this.renderFileType
        }, {
            header: _SDSS("history", "time"),
            dateIndex: "time",
            renderer: this.renderTime
        }];
        var a = new Ext.grid.ColumnModel({
            defaults: {
                sortable: false,
                menuDisabled: true
            },
            columns: b
        });
        return a
    },
    renderName: function(g, f, a) {
        var h = g.lastIndexOf("/");
        var c = g.substr(h + 1);
        var e = a.get("action");
        var b = a.get("rename_opt");
        var d = "";
        if (e === "remote_rename" || e === "local_rename") {
            d = b.substr(1) + " \u2192 "
        }
        d += g.substr(1);
        if (f) {
            f.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(d)) + '"'
        }
        if (c.length > 0) {
            return Ext.util.Format.htmlEncode(c)
        } else {
            return g.substr(1, g.length - 2)
        }
    },
    renderTime: function(b, c) {
        var a, d;
        if (b != parseInt(b, 10)) {
            return b
        }
        a = new Date(1000 * b);
        d = a.format("Y-m-d H:i:s");
        if (c) {
            c.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(d) + '"'
        }
        return d
    },
    renderAction: function(e, d, a) {
        var c = a.get("unsynced_reason");
        var b = "";
        if (c === -4096) {
            b = _SDSS("history", "unsynced_system_filter")
        } else {
            if (c === -8192) {
                b = _SDSS("history", "unsynced_common_filter")
            } else {
                if (c === -12288) {
                    b = _SDSS("history", "unsynced_no_perm")
                }
            }
        }
        if (b !== "") {
            d.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(b)) + '"'
        }
        if (e === "download") {
            return _SDSS("history", "download")
        } else {
            if (e === "upload") {
                return _SDSS("history", "upload")
            } else {
                if (e === "local_rename") {
                    return _SDSS("history", "local_rename")
                } else {
                    if (e === "remote_rename") {
                        return _SDSS("history", "remote_rename")
                    } else {
                        if (e === "delete") {
                            return _SDSS("history", "delete")
                        }
                    }
                }
            }
        }
    },
    renderFileType: function(a) {
        return (a) ? _SDSS("history", "folder") : _SDSS("history", "file")
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.SyncLog", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Widget",
    viewport: "SYNO.SDS.SynologyDriveShareSync.View.SyncLog",
    models: ["SYNO.SDS.SynologyDriveShareSync.Model.SyncLog"],
    stores: ["SYNO.SDS.SynologyDriveShareSync.Store.SyncLog"],
    init: function() {
        this.control({
            logWindow: {
                beforeshow: this.onBeforeShowWindow
            },
            logGrid: {
                celldblclick: this.onCellDoubleClick
            }
        });
        this.logWindow = this.componentQuery("logWindow");
        this.searchPanel = this.componentQuery("logGrid").getTopToolbar().getComponent("searchField").searchPanel;
        this.taskCombo = this.componentQuery("logGrid").getTopToolbar().getComponent("taskCombo");
        this.mon(this.searchPanel, "search", this.onSearch, this, {
            buffer: this.searchBuffer
        });
        this.mon(this.taskCombo, "select", this.onSelect, this)
    },
    onBeforeShowWindow: function() {
        this.getWebAPI().listSyncFolder(function(e, a, d, c) {
            if (!e) {
                this.showErrorMessageBox(a);
                return
            }
            var b = [{
                display_text: _SDSS("history", "all_event"),
                folder_path: "/",
                sess_id: 0
            }].concat(a.syncfolder_list);
            this.taskCombo.getStore().loadData(b);
            this.taskCombo.setValue(0);
            this.onSearch()
        }, this)
    },
    onSelect: function(c) {
        var a = this.componentQuery("logGrid").getStore();
        var b = this.taskCombo.getValue();
        Ext.apply(a.baseParams, {
            sess_id: b
        });
        a.load()
    },
    onSearch: function(c, d) {
        var a = this.componentQuery("logGrid").getStore();
        var b = this.taskCombo.getValue();
        Ext.apply(a.baseParams, d);
        Ext.apply(a.baseParams, {
            sess_id: b
        });
        a.load()
    },
    onCellDoubleClick: function(i, g, d, c) {
        if (d > 0) {
            return
        }
        var h = this.componentQuery("logGrid").getStore();
        var b = h.getAt(g);
        if (!b) {
            return
        }
        var j = b.get("path");
        var f = b.get("is_dir");
        var a = b.get("action") === "delete";
        if (a) {
            return
        }
        SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", f ? {
            opendir: j
        } : {
            openfile: j
        })
    },
    showErrorMessageBox: function(b) {
        var a;
        if (b.code === SYNO.SDS.SynologyDriveShareSync.ErrorCode.AUTH) {
            a = _SDSS("msg", "test_username_fail")
        } else {
            a = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(b)
        }
        this.owner.getMsgBox().alert(this.owner.title, a)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.PermissionSetting", {
    extend: "SYNO.ux.FormPanel",
    xtype: "sdss_permission_setting",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "permission_setting",
            xtype: "syno_formpanel",
            title: _SDSS("title", "permission_setting"),
            border: false,
            cls: "syno-sdss-permission-setting",
            items: [{
                xtype: "syno_fieldset",
                collapsible: false,
                itemId: "permission_setting_field",
                items: [{
                    xtype: "syno_displayfield",
                    value: _SDSS("msg", "permission_sync")
                }, {
                    xtype: "syno_radio",
                    itemId: "perm_sync_all",
                    boxLabel: _SDSS("title", "perm_sync_all"),
                    name: "permission_sync_radio",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    itemId: "perm_sync_domain",
                    boxLabel: _SDSS("title", "perm_sync_domain"),
                    name: "permission_sync_radio",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    itemId: "perm_sync_data_only",
                    boxLabel: _SDSS("title", "perm_sync_data_only"),
                    name: "permission_sync_radio",
                    indent: 1
                }]
            }, {
                xtype: "syno_fieldset",
                collapsible: false,
                itemId: "sync_direction_setting_field",
                items: [{
                    xtype: "container",
                    layout: "hbox",
                    items: [{
                        xtype: "syno_displayfield",
                        value: _SDSS("msg", "sync_direction")
                    }, {
                        xtype: "syno_displayfield",
                        cls: "syno-sdss-tip-field",
                        listeners: {
                            scope: this,
                            afterrender: function(c) {
                                SYNO.SDS.Utils.AddTip(c.el.dom, _SDSS("msg", "sync_direction_usage"))
                            }
                        }
                    }]
                }, {
                    xtype: "syno_radio",
                    itemId: "two_way_sync",
                    boxLabel: _SDSS("title", "two_way_sync"),
                    name: "sync_direction_radio",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    itemId: "one_way_sync_upload",
                    boxLabel: _SDSS("title", "one_way_sync_upload"),
                    name: "sync_direction_radio",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    itemId: "one_way_sync_download",
                    boxLabel: _SDSS("title", "one_way_sync_download"),
                    name: "sync_direction_radio",
                    indent: 1
                }]
            }, {
                xtype: "spacer",
                height: 6
            }, {
                xtype: "syno_checkbox",
                itemId: "entireAttributeCheckCheckBox",
                checked: true,
                boxLabel: _SDSS("msg", "option_enable_entire_attribute_check")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.BaseTree", {
    extend: "SYNO.ux.TreePanel",
    updateScrollBarEventNames: ["afterlayout", "expandnode", "collapsenode", "resize", "append", "remove"],
    constructor: function(a) {
        var b = Ext.apply({
            useArrows: true,
            autoScroll: true,
            containerScroll: true,
            bodyStyle: "overflow-x: hidden;overflow-y:auto; padding-right: 12px;",
            enableDD: false
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFile", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.BaseTree",
    constructor: function(a) {
        var b = Ext.apply({
            useArrows: true,
            autoScroll: true,
            containerScroll: true,
            bodyStyle: "overflow-x: hidden; overflow-y: auto; padding-top: 0px; padding-right: 12px; padding-left: 0px",
            enableDD: false
        }, a);
        return this.callParent([b])
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        this.mon(this, "checkchange", this.onCheckChange, this);
        return a
    },
    get_state_by_children: function(d) {
        var c = 0,
            b = 0,
            a = 0;
        d.eachChild(function(f) {
            var e = f.getUI() || {};
            if (e.checkbox && Ext.isFunction(e.getCheckValue) && (!Ext.isFunction(e.isDisabled) || !e.isDisabled())) {
                if (true === e.getCheckValue()) {
                    b += 1
                } else {
                    if (false === e.getCheckValue()) {
                        a += 1
                    }
                }
                c += 1
            }
        });
        if (d.attributes.node_type == "other") {
            if (c == b) {
                return true
            } else {
                return "gray"
            }
        } else {
            if (0 === c) {
                return d.getUI().getCheckValue()
            } else {
                if (b === c) {
                    return true
                } else {
                    if (a === c) {
                        return false
                    } else {
                        return "gray"
                    }
                }
            }
        }
    },
    propagate_down: function(a, b) {
        if (true === b) {
            a.eachChild(function(d) {
                var c = d.getUI();
                if (c && Ext.isFunction(c.setCheckValue) && (!Ext.isFunction(c.isDisabled) || !c.isDisabled())) {
                    c.setCheckValue(true)
                }
            }, this)
        } else {
            if (false === b) {
                a.eachChild(function(d) {
                    var c = d.getUI();
                    if (c && Ext.isFunction(c.setCheckValue)) {
                        c.setCheckValue(false)
                    }
                }, this)
            }
        }
    },
    set_pnode_checked: function(b) {
        var a = b.getUI();
        if (!a || !Ext.isFunction(a.getCheckValue)) {
            return
        }
        b.attributes.checked = this.get_state_by_children(b);
        a.syncCheckCssClass()
    },
    propagate_up: function(b, a) {
        while (b) {
            this.set_pnode_checked(b);
            b = b.parentNode
        }
    },
    onCheckChange: function(a, b) {
        this.propagate_down(a, b);
        this.propagate_up(a.parentNode)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.SelectiveFile", {
    extend: "SYNO.ux.FormPanel",
    xtype: "sdss_selective_file",
    constructor: function(a) {
        this.selectiveFilePanel = null;
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "selective_file_tab",
            title: _SDSS("title", "file_selective_sync"),
            border: false,
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            fieldWidth: undefined,
            cls: "syno-sdss-selective-file",
            items: [{
                xtype: "syno_fieldset",
                title: _SDSS("title", "file_size"),
                collapsible: false,
                items: [{
                    xtype: "syno_compositefield",
                    items: [{
                        xtype: "syno_numberfield",
                        fieldLabel: _SDSS("label", "file_max_size_label"),
                        itemId: "input_max_file_size",
                        regex: /^\d+$/,
                        maxlength: 8,
                        listeners: {
                            render: function(c) {
                                c.getEl().set({
                                    "ext:qtip": _SDSS("black_list", "size_tool_tip")
                                })
                            }
                        }
                    }, {
                        xtype: "syno_displayfield",
                        value: "MB"
                    }]
                }]
            }, {
                xtype: "syno_fieldset",
                title: _SDSS("title", "file_name"),
                collapsible: false,
                flex: 1,
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [{
                    xtype: "syno_displayfield",
                    height: 28,
                    value: _SDSS("black_list", "name_label")
                }, this.getSelectiveFilePanel(b), {
                    layout: "hbox",
                    height: 34,
                    border: false,
                    cls: "syno-sdss-add-blacklist",
                    items: [{
                        xtype: "syno_textfield",
                        itemId: "custom_file_ext",
                        flex: 1,
                        validator: this.isValidRule.createDelegate(this),
                        emptyText: _SDSS("black_list", "name_tool_tip"),
                        enableKeyEvents: true,
                        listeners: {
                            scope: this,
                            render: function(c) {
                                c.getEl().set({
                                    "ext:qtip": c.emptyText
                                })
                            },
                            keyup: function(d, c) {
                                if (d.getValue() !== "") {
                                    d.getEl().set({
                                        "ext:qtip": Ext.util.Format.htmlEncode(d.getValue())
                                    })
                                } else {
                                    d.getEl().set({
                                        "ext:qtip": d.emptyText
                                    })
                                }
                            }
                        },
                        allowBlank: true
                    }, {
                        xtype: "spacer",
                        width: 6
                    }, {
                        itemId: "add_custom_file_rule",
                        xtype: "syno_button",
                        text: _T("common", "add")
                    }]
                }]
            }]
        };
        return Ext.apply(a, b)
    },
    getSelectiveFilePanel: function(a) {
        if (!this.selectiveFilePanel) {
            this.selectiveFilePanel = new SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFile({
                owner: a.owner,
                itemId: "selective_file_treepanel",
                border: false,
                rootVisible: false,
                flex: 1,
                bodyStyle: "overflow-x: hidden; overflow-y: auto; padding-top: 0px; padding-right: 2px; padding-left: 0px",
                cls: "syno-sdss-treepanel",
                root: {}
            })
        }
        return this.selectiveFilePanel
    },
    isValidRule: function(a) {
        if (a === "" || this.isExtRule(a) || this.isNameRule(a)) {
            return true
        } else {
            return false
        }
    },
    isExtRule: function(b) {
        var a = /^\*\.[^\*\?\\\/]+$/;
        return a.test(b)
    },
    isNameRule: function(b) {
        var a = /^[^\\\/]+$/;
        return a.test(b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI", {
    extend: "Ext.tree.TreeNodeUI",
    renderElements: function(f, m, l, o) {
        this.indentMarkup = f.parentNode ? f.parentNode.ui.getChildIndent() : "";
        var h = Ext.isBoolean(m.checked) || m.checked === "gray",
            k = Ext.isBoolean(m.hide_checkbox) && m.hide_checkbox === true,
            p = Ext.isString(m.rimgCls),
            g = Ext.util.Format.htmlEncode,
            e = m.input,
            c, b = this.getHref(m.href),
            d = ['<li class="x-tree-node syno-extended-tree-node"><div ext:tree-node-id="', g(f.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', m.cls, '" unselectable="on">', p ? ('<img alt="" src="' + this.emptyIcon + '" class= "' + m.rimgCls + '" style="float: right" draggable="false" />') : "", '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', h ? ('<img alt="" src="' + this.emptyIcon + '"' + (k ? ' style="display: none;"' : "") + ' class="syno-tree-node-cb syno-ux-checkbox-icon" />') : "", '<img alt="" src="', m.icon || this.emptyIcon, '" class="x-tree-node-icon', (m.icon ? " x-tree-node-inline-icon" : ""), (m.iconCls ? " " + m.iconCls : ""), '" unselectable="on" ', ((m.icon || m.iconCls) ? "" : 'style="display: none;"') + "/>", (m.icon || m.iconCls) ? "<span>&nbsp</span>" : "", '<a hidefocus="on" class="x-tree-node-anchor" href="', b, '" tabIndex="1" ', m.hrefTarget ? ' target="' + m.hrefTarget + '"' : "", '><span unselectable="on">', Ext.util.Format.htmlEncode(f.text), "</span></a>", "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        if (o !== true && f.nextSibling && (c = f.nextSibling.ui.getEl())) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", c, d)
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", l, d)
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1];
        var j = this.elNode.childNodes;
        var i = 0;
        if (p) {
            this.rimgNode = j[i++]
        }
        this.indentNode = j[i++];
        this.ecNode = j[i++];
        if (h) {
            this.checkbox = j[i++];
            this.syncCheckCssClass()
        }
        this.iconNode = j[i++];
        this.anchor = j[i++];
        this.textNode = this.anchor.firstChild;
        if (e) {
            this.createInputField(e, m, this.elNode);
            i++
        }
        f.on("disabledchange", this.onDisabled, this)
    },
    onIdChange: function(b) {
        var a = Ext.util.Format.htmlEncode;
        if (this.rendered) {
            this.elNode.setAttribute("ext:tree-node-id", a(b))
        }
    },
    createInputField: function(b, a, c) {
        var d = b;
        if (Ext.isObject(b)) {
            this.inputConfig = Ext.apply({}, b);
            d = b.xtype || "textfield";
            delete b.xtype
        } else {
            this.inputConfig = {}
        }
        if (Ext.isDefined(a.value)) {
            this.inputConfig.value = a.value
        }
        this.inputConfig.renderTo = c;
        switch (d) {
            case "textfield":
                this.input = new SYNO.ux.TextField(this.inputConfig);
                break;
            case "numberfield":
                this.input = new SYNO.ux.NumberField(this.inputConfig);
                break
        }
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        if (this.rimgNode) {
            Ext.EventManager.on(this.rimgNode, "click", this.onRImgClick, this);
            Ext.EventManager.on(this.rimgNode, "mousedown", this.onRImgMouseDown, this);
            Ext.EventManager.on(this.rimgNode, "mouseenter", this.onRimgMouseEnter, this);
            Ext.EventManager.on(this.rimgNode, "mouseleave", this.onRimgMouseLeave, this)
        }
        return a
    },
    onRImgClick: function() {
        this.node.fireEvent("rimgclick")
    },
    onRimgMouseEnter: function() {
        this.node.fireEvent("rimgmouseenter")
    },
    onRimgMouseLeave: function() {
        this.node.fireEvent("rimgmouseleave")
    },
    onRImgMouseDown: function() {
        this.node.fireEvent("rimgmousedown");
        Ext.getDoc().on("mouseup", this.onRImgMouseUp, this)
    },
    onRImgMouseUp: function() {
        this.node.fireEvent("rimgmouseup");
        Ext.getDoc().un("mouseup", this.onRImgMouseUp, this)
    },
    isDisabled: function() {
        var a = this.node;
        return (true === a.disabled)
    },
    onClick: function(a) {
        if (a.getTarget(".x-form-field")) {
            return
        }
        if (a.getTarget(".syno-tree-node-cb")) {
            this.toggleCheck()
        }
        return this.callParent(arguments)
    },
    onDblClick: function(a) {
        a.preventDefault();
        if (this.disabled) {
            return
        }
        if (this.fireEvent("beforedblclick", this.node, a) !== false) {
            if (!this.animating && this.node.isExpandable()) {
                this.node.toggle()
            }
            this.fireEvent("dblclick", this.node, a)
        }
    },
    onDisabled: function(b, a) {
        if (this.input) {
            if (a) {
                this.input.disable()
            } else {
                this.input.enable()
            }
        }
        if (this.checkbox) {
            if (a) {
                Ext.fly(this.checkbox).addClass("syno-ux-cb-disabled")
            } else {
                Ext.fly(this.checkbox).removeClass("syno-ux-cb-disabled")
            }
        }
    },
    onCheckChange: function() {
        this.syncCheckCssClass();
        if (this.node.ui.rendered) {
            this.fireEvent("checkchange", this.node, this.getCheckValue())
        }
    },
    isValid: function() {
        if (this.node.disabled) {
            return true
        }
        if (this.input && !this.input.isValid()) {
            return false
        }
        return true
    },
    getInputValue: function() {
        if (!this.input || this.disabled) {
            return undefined
        }
        return this.input.getValue()
    },
    setInputValue: function(a) {
        if (!this.input) {
            return
        }
        this.input.setValue(a)
    },
    isChecked: function() {
        return this.getCheckValue()
    },
    getCheckValue: function() {
        return this.node.attributes.checked
    },
    toggleCheck: function() {
        var a = this.checkbox;
        if (true === this.node.disabled) {
            return
        }
        if (a) {
            this.setCheckValue(!this.getCheckValue())
        }
    },
    setCheckValue: function(a) {
        if (this.node.disabled) {
            return
        }
        if (a === this.getCheckValue()) {
            return
        }
        if (a === "false" || a === "off" || a === "0") {
            a = false
        } else {
            if (a === "gray") {
                a = "gray"
            } else {
                a = (a ? true : false)
            }
        }
        this.node.attributes.checked = a;
        this.onCheckChange()
    },
    syncCheckCssClass: function() {
        var b = this.getCheckValue();
        var a = this.checkbox;
        if (!a) {
            return
        }
        Ext.each(["checked", "grayed", "disabled"], function(c) {
            Ext.fly(this.checkbox).removeClass("syno-ux-cb-" + c)
        }, this);
        if (b === true) {
            Ext.fly(this.checkbox).addClass("syno-ux-cb-checked")
        } else {
            if (b === "gray") {
                Ext.fly(this.checkbox).addClass("syno-ux-cb-grayed")
            }
        }
        if (this.node.disabled) {
            Ext.fly(this.checkbox).addClass("syno-ux-cb-disabled")
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.FolderLoader.Base", {
    extend: "Ext.tree.TreeLoader",
    createNode: function(a) {
        var b;
        a = Ext.apply({
            uiProvider: "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI",
            iconCls: "x-tree-node-icon",
            draggable: false
        }, a);
        if (Ext.isFunction(this.createNodeFn)) {
            b = this.createNodeFn.call(this.createNodeScope || this, a);
            if (b === false) {
                return
            }
        }
        return this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolderUI", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI",
    toggleCheck: function() {
        var a = this.checkbox;
        if (true === this.node.disabled) {
            return
        }
        if (a) {
            if (null === this.node.parentNode) {
                if (this.node.childNodes.length === 0) {
                    return
                }
                this.setCheckValue(("gray" === this.getCheckValue()) ? true : "gray")
            } else {
                this.setCheckValue(!this.getCheckValue())
            }
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolder", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.BaseTree",
    constructor: function(a) {
        var b = Ext.apply({}, a);
        return this.callParent([b])
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        this.mon(this, "checkchange", this.onCheckChange, this);
        this.mon(this, "beforeexpandnode", this.beforeExpandNode, this);
        this.mon(this, "beforeappend", this.beforeAppend, this);
        return a
    },
    get_state_by_children: function(d) {
        var c = 0,
            b = 0,
            a = 0;
        d.eachChild(function(f) {
            var e = f.getUI() || {};
            if (e.checkbox && Ext.isFunction(e.getCheckValue) && (!Ext.isFunction(e.isDisabled) || !e.isDisabled())) {
                if (true === e.getCheckValue()) {
                    b += 1
                } else {
                    if (false === e.getCheckValue()) {
                        a += 1
                    }
                }
                c += 1
            }
        });
        if (0 === c) {
            return d.getUI().getCheckValue()
        } else {
            if (b === c) {
                return true
            } else {
                if (a === c) {
                    return "gray"
                } else {
                    return "gray"
                }
            }
        }
    },
    propagate_down: function(b, c) {
        var a = function(d, f) {
            d.eachChild(function(g) {
                a(g, f)
            });
            var e = d.getUI();
            if (e && Ext.isFunction(e.setCheckValue)) {
                e.setCheckValue(f)
            }
        };
        if (null === b.parentNode) {
            if ("gray" === c) {
                c = false
            }
            b.eachChild(function(d) {
                a(d, c)
            })
        } else {
            a(b, c)
        }
    },
    set_pnode_checked: function(c, b) {
        var a = c.getUI();
        if (!a || !Ext.isFunction(a.getCheckValue)) {
            return
        }
        c.attributes.checked = this.get_state_by_children(c);
        a.syncCheckCssClass()
    },
    propagate_up: function(b, a) {
        while (b) {
            this.set_pnode_checked(b, a);
            b = b.parentNode
        }
    },
    onCheckChange: function(a, b) {
        this.propagate_down(a, b);
        this.propagate_up(a.parentNode, b)
    },
    beforeExpandNode: function(b, a, c) {
        b.eachChild(function(d) {
            if (d.attributes.checked_TBD === true) {
                d.attributes.checked = (b.attributes.checked === false) ? false : true;
                d.attributes.checked_TBD = false;
                d.getUI().syncCheckCssClass()
            }
        }, this);
        b.sort(function(e, g) {
            var d = e.attributes.text;
            var f = g.attributes.text;
            return (d < f) ? -1 : (d > f)
        })
    },
    beforeAppend: function(a, d, e) {
        var c = e.attributes.path;
        var b;
        Ext.each(d.childNodes, function(f) {
            if (f.attributes.path == c) {
                b = f
            }
        });
        if (!b) {
            return true
        }
        b.attributes.filtered = b.attributes.filtered || e.attributes.filtered;
        b.attributes.map_entries.push.apply(b.attributes.map_entries, e.attributes.map_entries);
        return false
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.FolderLoader.Regular", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.FolderLoader.Base",
    clearOnLoad: false,
    paramsAsHash: true,
    constructor: function() {
        var b = this.callParent(arguments);
        var a = this.baseParams;
        this.baseParams = {
            api: this.api,
            version: this.version,
            method: this.method,
            apiSender: this.apiSender,
            params: a
        };
        this.on("beforeload", function(d, c) {
            this.removeNotFilteredChildren(c);
            this.baseParams.params.map_entries = c.attributes.map_entries;
            this.baseParams.params.path = c.attributes.path
        }, this);
        return b
    },
    createNode: function(a) {
        a.checked = true;
        a.checked_TBD = true;
        a.uiProvider = "SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolderUI";
        return this.callParent(arguments)
    },
    removeNotFilteredChildren: function(b) {
        for (var a = b.childNodes.length - 1; a >= 0; a--) {
            if (b.childNodes[a].attributes.filtered === false) {
                b.removeChild(b.childNodes[a], true)
            }
        }
    },
    directFn: function(a, b) {
        a.apiSender.sendWebAPI({
            api: a.api,
            version: a.version,
            method: a.method,
            params: a.params,
            callback: function(g, c, f, e) {
                var d = {};
                if (g) {
                    d.status = true
                } else {
                    d.status = false
                }
                b(c.children, d)
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.SelectiveFolder", {
    extend: "SYNO.ux.Panel",
    xtype: "sdss_selective_folder",
    constructor: function(a) {
        this.selectiveFolderChooser = null;
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "selective_folder_tab",
            title: _SDSS("title", "folder_selective_sync"),
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            cls: "syno-sdss-selective-folder",
            items: [{
                xtype: "syno_displayfield",
                value: _SDSS("msg", "folder_selective_sync")
            }, this.getSelectiveFolderChooser(b)]
        };
        return Ext.apply(a, b)
    },
    getSelectiveFolderChooser: function(a) {
        if (!this.selectiveFolderChooser) {
            this.selectiveFolderChooser = new SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolder({
                owner: a.owner,
                itemId: "selective_folder_chooser",
                border: false,
                rootVisible: true,
                bodyStyle: "padding-right: 2px",
                cls: "syno-sdss-treepanel",
                flex: 1,
                root: {}
            })
        }
        return this.selectiveFolderChooser
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.AdvanceSetting", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "advanceSettingWindow",
            title: _SDSS("msg", "perm_sync_settings"),
            width: 664,
            height: 510,
            resizable: false,
            layout: "fit",
            padding: "16px 20px 0px 20px",
            cls: "syno-sdss",
            items: [{
                xtype: "syno_tabpanel",
                itemId: "tabPanel",
                deferredRender: false,
                layoutOnTabChange: true,
                border: false,
                plain: true,
                activeTab: 0,
                items: [{
                    xtype: "sdss_selective_folder",
                    rootVisible: true,
                    root: {}
                }, {
                    xtype: "sdss_selective_file",
                    rootVisible: false,
                    root: {}
                }, {
                    xtype: "sdss_permission_setting"
                }]
            }],
            fbar: {
                xtype: "statusbar",
                defaultText: "&nbsp",
                statusAlign: "left",
                buttonAlign: "left",
                items: [{
                    text: _T("common", "cancel"),
                    xtype: "syno_button",
                    btnStyle: "grey",
                    handler: this.close,
                    scope: this
                }, {
                    text: _T("common", "apply"),
                    xtype: "syno_button",
                    btnStyle: "blue",
                    itemId: "applyButton",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : ""
                }]
            }
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.AdvanceSetting", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Widget",
    viewport: "SYNO.SDS.SynologyDriveShareSync.View.AdvanceSetting",
    models: ["SYNO.SDS.SynologyDriveShareSync.Model.Share"],
    controllers: ["SYNO.SDS.SynologyDriveShareSync.Controller.PermissionSetting", "SYNO.SDS.SynologyDriveShareSync.Controller.SelectiveFile", "SYNO.SDS.SynologyDriveShareSync.Controller.SelectiveFolder"],
    wizardMode: false,
    init: function() {
        this.control({
            advanceSettingWindow: {
                beforeshow: this.onBeforeShowWindow,
                beforeclose: this.onBeforeCloseWindow,
                close: this.onCloseWindow
            },
            applyButton: {
                click: this.onClickApplyButton
            }
        });
        this.advanceSettingWindow = this.componentQuery("advanceSettingWindow")
    },
    onBeforeShowWindow: function(c) {
        var d = this.componentQuery("advanceSettingWindow tabPanel");
        var b = [];
        this.app().getController("PermissionSetting").setPermissionMode(this.share.get("perm_sync"));
        this.app().getController("PermissionSetting").setSyncMode(this.share.get("sync_direction"));
        this.app().getController("PermissionSetting").setAttributeCheckStrength(this.share.get("attribute_check_strength"));
        this.maskSyncDirectionAndPermissionSetting();
        d.setActiveTab("selective_folder_tab");
        if (!this.wizardMode) {
            this.app().getController("SelectiveFolder").setConn({
                conn_id: this.share.get("conn_id"),
                view_id: this.share.get("view_id"),
                local_share: this.share.get("local_share")
            });
            this.getMainApplication().getController("Main").stopPollingTask();
            b.push({
                api: "SYNO.SynologyDriveShareSync.Connection",
                version: 1,
                method: "get",
                params: {
                    conn_id: this.connId
                }
            })
        } else {
            this.app().getController("SelectiveFolder").setConn({
                use_ssl: this.connEntry.ssl_enable,
                server_port: this.connEntry.server_port,
                view_id: this.share.get("view_id"),
                local_share: this.share.get("local_share"),
                sess_token: this.connEntry.sess_token,
                server_ip: this.connEntry.server_ip,
                server_name: this.connEntry.server_name,
                ver_build_no: this.connEntry.ver_build_no,
                use_proxy: this.connEntry.use_proxy,
                proxy_ip: this.connEntry.proxy_ip,
                proxy_port: this.connEntry.proxy_port,
                proxy_username: this.connEntry.proxy_username,
                proxy_password: this.connEntry.proxy_password,
                use_tunnel: this.connEntry.use_tunnel,
                tunnel_ip: this.connEntry.tunnel_ip,
                tunnel_port: this.connEntry.tunnel_port
            });
            this.setPermSettingField(this.connEntry.ver_build_no, this.connEntry.user_is_admin);
            if (!this.isSupportedOneWayUpload(this.connEntry.ver_build_no)) {
                this.componentQuery("sync_direction_setting_field one_way_sync_upload").setDisabled(true)
            }
        }
        if ((this.wizardMode || !this.share.get("used")) && this.filterMap[this.share.get("view_id")]) {
            var a = this.filterMap[this.share.get("view_id")];
            this.app().getController("SelectiveFile").loadPanel(a);
            this.app().getController("SelectiveFolder").loadPanel({
                filtered_paths: a.filtered_paths,
                local_share: this.share.get("local_share")
            })
        } else {
            b.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "get",
                params: {
                    sess_id: this.share.get("sess_id")
                }
            })
        }
        if (b.length === 0) {
            return
        }
        this.advanceSettingWindow.setStatusBusy(undefined, undefined, 1);
        this.getMainApplication().sendWebAPI({
            compound: {
                params: b
            },
            callback: function(h, e, g, f) {
                this.advanceSettingWindow.clearStatusBusy();
                if (!h || e.has_fail) {
                    var i = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(e);
                    this.advanceSettingWindow.getMsgBox().alert(_SDSSAPPNAME, i, function() {
                        this.advanceSettingWindow.destroy();
                        this.destroy()
                    }, this)
                }
                e.result.forEach(function(j) {
                    if (j.api === "SYNO.SynologyDriveShareSync.Session" && j.method === "get") {
                        this.app().getController("SelectiveFile").loadPanel(j.data);
                        this.app().getController("SelectiveFolder").loadPanel({
                            filtered_paths: j.data.filtered_paths,
                            local_share: this.share.get("local_share")
                        })
                    } else {
                        if (j.api === "SYNO.SynologyDriveShareSync.Connection" && j.method === "get") {
                            this.setPermSettingField(j.data.ver_build_no, j.data.user_is_admin);
                            if (!this.isSupportedOneWayUpload(j.data.ver_build_no)) {
                                this.componentQuery("sync_direction_setting_field one_way_sync_upload").setDisabled(true)
                            }
                        }
                    }
                }, this)
            },
            scope: this
        })
    },
    onCloseWindow: function(a) {
        if (!this.wizardMode) {
            this.getMainApplication().getController("Main").startPollingTask()
        }
    },
    onClickApplyButton: function(f, a) {
        var i = {};
        var c;
        if (!this.getController("SelectiveFile").isValid()) {
            var e = this.componentQuery("advanceSettingWindow");
            var h = e.getFooterToolbar();
            e.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            }, h);
            this.componentQuery("advanceSettingWindow tabPanel").setActiveTab("selective_file_tab");
            return
        }
        var b = this.getController("PermissionSetting").isDirty();
        var g = this.getController("SelectiveFolder").isDirty();
        var j = this.getController("SelectiveFile").isDirty();
        if (b) {
            i.syncPerm = this.getController("PermissionSetting").getPermissionMode();
            i.syncDirection = this.getController("PermissionSetting").getSyncMode();
            i.attributeCheckStrength = this.getController("PermissionSetting").getAttributeCheckStrength()
        }
        if (g || j) {
            c = {};
            var d = this.app().getController("SelectiveFile").getSettings();
            c.filtered_max_upload_size = d.filtered_max_upload_size;
            c.filtered_extensions = d.filtered_extensions;
            c.filtered_names = d.filtered_names;
            c.user_defined_extensions = d.user_defined_extensions;
            c.user_defined_names = d.user_defined_names;
            c.filtered_paths = this.app().getController("SelectiveFolder").getFilteredRules()
        }
        if (this.getController("PermissionSetting").getPermissionMode() === 0) {
            this.advanceSettingWindow.getMsgBox().alert(this.advanceSettingWindow.title, _SDSS("warning", "warn_perm_sync_policy"), function() {
                this.applySetting(i, c)
            }, this);
            return
        }
        this.applySetting(i, c)
    },
    applySetting: function(b, a) {
        var c = this.share.get("sess_id");
        if (b.syncPerm !== undefined) {
            this.share.set("perm_sync", b.syncPerm)
        }
        if (b.syncDirection !== undefined) {
            this.share.set("sync_direction", b.syncDirection)
        }
        if (b.attributeCheckStrength !== undefined) {
            this.share.set("attribute_check_strength", b.attributeCheckStrength)
        }
        if (a !== undefined) {
            this.filterMap[this.share.get("view_id")] = a
        }
        if (this.share.get("sess_id") === 0) {
            this.advanceSettingWindow.destroy();
            this.destroy();
            return
        }
        this.advanceSettingWindow.setStatusBusy();
        this.getWebAPI().updateShare([Ext.apply({
            sess_id: c,
            perm_sync: b.syncPerm,
            sync_direction: b.syncDirection,
            attribute_check_strength: b.attributeCheckStrength
        }, a)], {}, function(g, d, f, e) {
            this.advanceSettingWindow.clearStatusBusy();
            if (!g || (d && d.has_fail)) {
                var h = SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString(d);
                this.advanceSettingWindow.getMsgBox().alert(this.advanceSettingWindow.title, h);
                return
            }
            this.advanceSettingWindow.destroy();
            this.destroy()
        }, this)
    },
    onBeforeCloseWindow: function(b, d) {
        var c = this.getController("PermissionSetting").isDirty();
        var e = this.getController("SelectiveFolder").isDirty();
        var a = this.getController("SelectiveFile").isDirty();
        if (c || e || a) {
            if (_S("majorversion") < 7) {
                this.advanceSettingWindow.getMsgBox().confirm(_SDSS("app", "app_name"), _T("common", "confirm_lostchange"), function(f) {
                    if ("yes" === f) {
                        this.advanceSettingWindow.destroy();
                        this.destroy()
                    }
                }, this)
            } else {
                this.advanceSettingWindow.confirmLostChangePromise({
                    save: this.onClickApplyButton,
                    dontSave: function() {
                        this.advanceSettingWindow.destroy();
                        this.destroy()
                    },
                    cancel: Ext.emptyFn
                }, this)
            }
            return false
        } else {
            this.destroy();
            return true
        }
    },
    setPermSettingField: function(b, a) {
        if (SYNO.SDS.SynologyDriveShareSync.Util.SupportPermissionSetting(this.share, b, a, this.valid_share)) {
            this.componentQuery("permission_setting permission_setting_field").setDisabled(false)
        } else {
            this.componentQuery("permission_setting permission_setting_field").setDisabled(true)
        }
    },
    isSupportedOneWayUpload: function(a) {
        return (a >= 4100)
    },
    maskSyncDirectionAndPermissionSetting: function() {
        var c = this.share.get("remote_share");
        var a = this.share.get("rw");
        var b = this.share.get("local_share");
        var d = this.share.get("local_rw");
        if (a === false) {
            this.componentQuery("sync_direction_setting_field two_way_sync").setDisabled(true);
            this.componentQuery("sync_direction_setting_field one_way_sync_upload").setDisabled(true)
        }
        if (b !== "--" && d === false) {
            this.componentQuery("sync_direction_setting_field two_way_sync").setDisabled(true);
            this.componentQuery("sync_direction_setting_field one_way_sync_download").setDisabled(true)
        }
        if (c === "homes" && b === "homes") {
            this.componentQuery("sync_direction_setting_field one_way_sync_upload").setDisabled(true);
            this.componentQuery("sync_direction_setting_field one_way_sync_download").setDisabled(true);
            this.componentQuery("permission_setting_field perm_sync_domain").setDisabled(true);
            this.componentQuery("permission_setting_field perm_sync_data_only").setDisabled(true)
        } else {
            if (c === "homes") {
                this.componentQuery("sync_direction_setting_field one_way_sync_upload").setDisabled(true);
                this.componentQuery("sync_direction_setting_field two_way_sync").setDisabled(true)
            } else {
                if (b === "homes") {
                    this.componentQuery("sync_direction_setting_field two_way_sync").setDisabled(true);
                    this.componentQuery("sync_direction_setting_field one_way_sync_download").setDisabled(true)
                }
            }
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.PermissionSetting", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.owner = this.componentQuery("advanceSettingWindow");
        this.permissionMode = undefined;
        this.syncMode = undefined;
        this.attributeCheckStrength = undefined;
        this.permission_mode_itemids = ["perm_sync_all", "perm_sync_domain", "perm_sync_data_only"];
        this.sync_direction_itemids = ["two_way_sync", "one_way_sync_upload", "one_way_sync_download"]
    },
    isDirty: function() {
        return ((this.getPermissionMode() !== this.permissionMode) || (this.getSyncMode() !== this.syncMode) || (this.getAttributeCheckStrength() !== this.attributeCheckStrength))
    },
    setPermissionMode: function(a) {
        this.componentQuery("permission_setting_field " + this.permission_mode_itemids[a]).setValue(true);
        this.permissionMode = a
    },
    getPermissionMode: function() {
        return Ext.each(this.permission_mode_itemids, function(a) {
            if (this.componentQuery("permission_setting_field " + a).getValue()) {
                return false
            }
        }, this)
    },
    setSyncMode: function(a) {
        this.componentQuery("sync_direction_setting_field " + this.sync_direction_itemids[a]).setValue(true);
        this.syncMode = a
    },
    getSyncMode: function() {
        return Ext.each(this.sync_direction_itemids, function(a) {
            if (this.componentQuery("sync_direction_setting_field " + a).getValue()) {
                return false
            }
        }, this)
    },
    setAttributeCheckStrength: function(b) {
        var a = (b === 0 ? true : false);
        this.componentQuery("entireAttributeCheckCheckBox").setValue(a);
        this.attributeCheckStrength = b
    },
    getAttributeCheckStrength: function() {
        return (this.componentQuery("entireAttributeCheckCheckBox").getValue() === true ? 0 : 1)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.SelectiveFile", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.control({
            add_custom_file_rule: {
                click: this.addCustomFileRule
            }
        });
        this.owner = this.componentQuery("advanceSettingWindow");
        this.cgi_filtered_extensions = undefined;
        this.cgi_filtered_names = undefined;
        this.cgi_user_defined_extensions = undefined;
        this.cgi_user_defined_names = undefined;
        this.cgi_filtered_max_upload_size = undefined
    },
    loadPanel: function(a) {
        this.cgi_filtered_extensions = a.filtered_extensions;
        this.cgi_filtered_names = a.filtered_names;
        this.cgi_filtered_max_upload_size = a.filtered_max_upload_size;
        this.cgi_user_defined_extensions = a.user_defined_extensions;
        this.cgi_user_defined_names = a.user_defined_names;
        Ext.each(this.cgi_filtered_extensions, function(e, d, c) {
            c[d] = e.toLowerCase()
        });
        Ext.each(this.cgi_user_defined_extensions, function(e, d, c) {
            c[d] = e.toLowerCase()
        });
        var b = this.getBuiltInExtensions();
        Ext.each(b, function(c) {
            Ext.each(c.extensions, function(e) {
                var d = this.cgi_user_defined_extensions.indexOf(e);
                if (d >= 0) {
                    this.cgi_user_defined_extensions.splice(d, 1)
                }
            }, this)
        }, this);
        this.reloadPanel()
    },
    reloadPanel: function() {
        var a = this.componentQuery("selective_file_treepanel").getRootNode();
        a.removeAll();
        this.componentQuery("selective_file_tab custom_file_ext").setValue("");
        var b = this.getBuiltInExtensions();
        Ext.each(b, function(c) {
            a.appendChild(this.createBuiltInCategory(c, this.cgi_filtered_extensions))
        }, this);
        a.appendChild(this.createUserDefinedCategory(this.cgi_user_defined_extensions, this.cgi_filtered_extensions, this.cgi_user_defined_names, this.cgi_filtered_names));
        a.expand();
        (function() {
            for (var c = 0; c < a.childNodes.length; c++) {
                a.childNodes[c].expand(undefined, false);
                if (a.childNodes[c].attributes.is_customize_session === false) {
                    a.childNodes[c].collapse(undefined, false)
                }
                a.childNodes[c].ui.syncCheckCssClass()
            }
        })();
        a.childNodes[0].ensureVisible();
        (function() {
            var d = this.componentQuery("selective_file_tab input_max_file_size");
            var c = Math.round(this.cgi_filtered_max_upload_size / 1024 / 1024);
            d.setMinValue(0);
            d.setMaxValue(10000 * 1024);
            d.setValue(c)
        }).createDelegate(this)()
    },
    setStatusError: function(b, a) {
        b = b || {};
        Ext.applyIf(b, {
            text: _T("common", "error_system"),
            iconCls: this.owner.isV5Style() ? "syno-ux-statusbar-error" : "x-status-error"
        });
        a.setStatus(b)
    },
    getSettings: function() {
        var g = this.componentQuery("selective_file_tab input_max_file_size");
        var h = this.componentQuery("selective_file_treepanel").getRootNode();
        var e = [];
        var a = [];
        var c = [];
        var d = [];
        var f = (0 <= g.getValue()) ? g.getValue() * 1024 * 1024 : 0;
        var b = function(j) {
            if (this.isExtensionNode(j.attributes)) {
                if (c.indexOf(j.attributes.extension_name) < 0) {
                    c.push(j.attributes.extension_name)
                }
            } else {
                if (this.isNameNode(j.attributes)) {
                    if (d.indexOf(j.attributes.file_name) < 0) {
                        d.push(j.attributes.file_name)
                    }
                }
            }
        }.createDelegate(this);
        var i = function(j) {
            if (this.isExtensionNode(j.attributes)) {
                if (e.indexOf(j.attributes.extension_name) < 0) {
                    e.push(j.attributes.extension_name)
                }
            } else {
                if (this.isNameNode(j.attributes)) {
                    if (a.indexOf(j.attributes.file_name) < 0) {
                        a.push(j.attributes.file_name)
                    }
                }
            }
        }.createDelegate(this);
        Ext.each(h.childNodes, function(j) {
            Ext.each(j.childNodes, function(k) {
                if (false === k.attributes.checked) {
                    i(k)
                }
                if (true === j.attributes.is_customize_session) {
                    b(k)
                }
            }, this)
        }, this);
        return {
            filtered_max_upload_size: f,
            filtered_extensions: e,
            filtered_names: a,
            user_defined_extensions: c,
            user_defined_names: d
        }
    },
    isDirty: function() {
        if (this.cgi_filtered_extensions === undefined || this.cgi_filtered_max_upload_size === undefined || this.cgi_filtered_names === undefined || this.cgi_user_defined_extensions === undefined || this.cgi_user_defined_names === undefined) {
            return false
        }
        var f = this.getSettings();
        var e = f.filtered_max_upload_size;
        var a = f.filtered_extensions;
        var c = f.filtered_names;
        var b = f.user_defined_extensions;
        var g = f.user_defined_names;
        var d = 0;
        if (e != this.cgi_filtered_max_upload_size) {
            return true
        }
        if (a.length != this.cgi_filtered_extensions.length) {
            return true
        }
        if (b.length != this.cgi_user_defined_extensions.length) {
            return true
        }
        if (c.length != this.cgi_filtered_names.length) {
            return true
        }
        if (g.length != this.cgi_user_defined_names.length) {
            return true
        }
        a.sort();
        this.cgi_filtered_extensions.sort();
        for (d = 0; d < a.length; d++) {
            if (a[d] != this.cgi_filtered_extensions[d]) {
                return true
            }
        }
        c.sort();
        this.cgi_filtered_names.sort();
        for (d = 0; d < c.length; d++) {
            if (c[d] != this.cgi_filtered_names[d]) {
                return true
            }
        }
        b.sort();
        this.cgi_user_defined_extensions.sort();
        for (d = 0; d < b.length; d++) {
            if (b[d] != this.cgi_user_defined_extensions[d]) {
                return true
            }
        }
        g.sort();
        this.cgi_user_defined_names.sort();
        for (d = 0; d < g.length; d++) {
            if (g[d] != this.cgi_user_defined_names[d]) {
                return true
            }
        }
        return false
    },
    expandRootNode: function() {
        var a = this.componentQuery("selective_file_treepanel");
        a.getRootNode().expand(false, true)
    },
    getBuiltInExtensions: function() {
        return SYNO.SDS.SynologyDriveShareSync.SelectiveSync.BuiltInExtensions()
    },
    node_remove_mouseenter: function() {
        this.getUI().rimgNode.classList.add("rimg-over")
    },
    node_remove_mouseleave: function() {
        this.getUI().rimgNode.classList.remove("rimg-over")
    },
    node_remove_mousedown: function() {
        this.getUI().rimgNode.classList.add("rimg-click")
    },
    node_remove_mouseup: function() {
        this.getUI().rimgNode.classList.remove("rimg-click")
    },
    node_remove_clicked: function() {
        var c = this.parentNode;
        var a = true,
            b = false;
        this.parentNode.removeChild(this, true);
        Ext.each(c.childNodes, function(e) {
            var d = e.attributes.checked;
            a = (a && d);
            b = (b && !d)
        }, this);
        if (b === true) {
            c.attributes.checked = false
        } else {
            if (a === true) {
                c.attributes.checked = true
            } else {
                c.attributes.checked = "gray"
            }
        }
        c.ui.onCheckChange()
    },
    createBuiltInCategory: function(d, e) {
        var b = true,
            c = true;
        var a = {
            text: d.display_name,
            uiProvider: SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI,
            iconCls: d.icon_cls,
            children: [],
            is_customize_session: false,
            node_type: d.node_type
        };
        Ext.each(d.extensions, function(g) {
            g = g.toLowerCase();
            var f = (e.indexOf(g) >= 0) ? false : true;
            a.children.push(this.createExtensionNode(g, f, true));
            b = (b && f);
            c = (c && !f)
        }, this);
        if (b === true) {
            a.checked = true
        } else {
            if (c === true) {
                a.checked = false
            } else {
                a.checked = "gray"
            }
        }
        return a
    },
    createUserDefinedCategory: function(f, a, e, d) {
        var c = true;
        var b = {
            text: _SDSS("common", "customized"),
            uiProvider: SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI,
            iconCls: "syno-tree-node-customized",
            children: [],
            is_customize_session: true,
            node_type: "other"
        };
        Ext.each(f, function(h) {
            h = h.toLowerCase();
            var g = (a.indexOf(h) >= 0) ? false : true;
            b.children.push(this.createExtensionNode(h, g, false));
            c = (c && g)
        }, this);
        Ext.each(e, function(h) {
            var g = (d.indexOf(h) >= 0) ? false : true;
            b.children.push(this.createNameNode(h, g));
            c = (c && g)
        }, this);
        if (c === true) {
            b.checked = true
        } else {
            b.checked = "gray"
        }
        return b
    },
    addCustomNode: function(d) {
        var c = this.componentQuery("selective_file_treepanel");
        var e = c.getRootNode();
        var a = null;
        for (var b = e.childNodes.length - 1; b >= 0; b--) {
            if (true === e.childNodes[b].attributes.is_customize_session) {
                a = e.childNodes[b];
                break
            }
        }
        if (a === null) {
            return
        }
        a.appendChild(d);
        a.collapse(undefined, false);
        a.expand(undefined, false)
    },
    addCustomFileRule: function() {
        var b = this.componentQuery("selective_file_tab custom_file_ext").getValue();
        var a = this.componentQuery("selective_file_tab");
        b = b.toLowerCase();
        if (a.isExtRule(b)) {
            this.addExtRule(b.substr(1));
            this.componentQuery("selective_file_tab custom_file_ext").reset()
        } else {
            if (a.isNameRule(b)) {
                this.addNameRule(b);
                this.componentQuery("selective_file_tab custom_file_ext").reset()
            } else {
                var c = this.componentQuery("advanceSettingWindow").getFooterToolbar();
                this.setStatusError({
                    text: _T("common", "forminvalid"),
                    clear: true
                }, c);
                this.componentQuery("advanceSettingWindow tabPanel").setActiveTab("selective_file_tab");
                return
            }
        }
    },
    addExtRule: function(c) {
        var d = function(e) {
            return (e.attributes.extension_name === c)
        };
        var b = this.selectNode(d);
        if (b !== null) {
            b.attributes.checked = false;
            b.ui.onCheckChange();
            return
        }
        var a = this.createExtensionNode(c, false, false);
        this.addCustomNode(a);
        b = this.selectNode(d);
        b.ui.onCheckChange()
    },
    addNameRule: function(b) {
        var d = function(e) {
            return (e.attributes.file_name === b)
        };
        var c = this.selectNode(d);
        if (c !== null) {
            c.attributes.checked = false;
            c.ui.onCheckChange();
            return
        }
        var a = this.createNameNode(b, false);
        this.addCustomNode(a);
        c = this.selectNode(d);
        c.ui.onCheckChange()
    },
    isValid: function() {
        return this.componentQuery("selective_file_tab input_max_file_size").isValid()
    },
    isExtensionNode: function(a) {
        return ("ext" === a.node_type)
    },
    isNameNode: function(a) {
        return ("name" === a.node_type)
    },
    createExtensionNode: function(b, d, a) {
        var c = this.createBaseNode(d);
        c.node_type = "ext";
        c.extension_name = b;
        c.text = b.substr(1);
        if (!a) {
            c.text = "*" + b;
            c.qtip = Ext.util.Format.htmlEncode(c.text);
            c.rimgCls = "syno-tree-node-remove";
            c.listeners = {
                rimgmouseenter: this.node_remove_mouseenter,
                rimgmouseleave: this.node_remove_mouseleave,
                rimgmousedown: this.node_remove_mousedown,
                rimgmouseup: this.node_remove_mouseup,
                rimgclick: this.node_remove_clicked
            }
        }
        return c
    },
    createNameNode: function(a, c) {
        var b = this.createBaseNode(c);
        b.node_type = "name";
        b.file_name = a;
        b.text = a;
        b.qtip = Ext.util.Format.htmlEncode(b.text);
        b.rimgCls = "syno-tree-node-remove";
        b.listeners = {
            rimgmouseenter: this.node_remove_mouseenter,
            rimgmouseleave: this.node_remove_mouseleave,
            rimgmousedown: this.node_remove_mousedown,
            rimgmouseup: this.node_remove_mouseup,
            rimgclick: this.node_remove_clicked
        };
        return b
    },
    createBaseNode: function(a) {
        var b = {
            uiProvider: SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanelUI,
            text: undefined,
            checked: a,
            leaf: true,
            extension_name: undefined,
            file_name: undefined,
            node_type: undefined
        };
        return b
    },
    selectNode: function(f) {
        var a = this.componentQuery("selective_file_treepanel").getRootNode();
        var e = null;
        var d = function() {
            a.childNodes[c].childNodes[b].select();
            a.childNodes[c].childNodes[b].ensureVisible();
            setTimeout(function() {
                a.getOwnerTree().fleXcrollTo(a.childNodes[c].childNodes[b].getUI().getEl())
            }, 100)
        };
        a.expand();
        for (var c = 0; c < a.childNodes.length; c++) {
            for (var b = 0; b < a.childNodes[c].childNodes.length; b++) {
                if (f(a.childNodes[c].childNodes[b])) {
                    a.childNodes[c].expand(undefined, undefined, d);
                    e = a.childNodes[c].childNodes[b];
                    break
                }
            }
            if (null !== e) {
                break
            }
        }
        return e
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.SelectiveFolder", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    init: function() {
        this.owner = this.componentQuery("advanceSettingWindow");
        this.cgi_filtered_paths = undefined;
        this.local_share = undefined
    },
    loadPanel: function(a) {
        this.cgi_filtered_paths = a.filtered_paths;
        this.local_share = a.local_share;
        this.reloadPanel()
    },
    addFilteredNode: function(f) {
        if (f.indexOf("/") !== 0) {
            return
        }
        var h = this.componentQuery("selective_folder_chooser").getRootNode();
        var g = 0;
        var a;
        var e;
        var d = function(i) {
            if (i.attributes.path == a) {
                e = i
            }
        };
        while (true) {
            g = f.indexOf("/", g + 1);
            if (g >= 0) {
                a = f.substr(0, g)
            } else {
                a = f
            }
            var c = a.substr(a.lastIndexOf("/") + 1);
            e = undefined;
            Ext.each(h.childNodes, d);
            if (e === undefined) {
                var b = (a == f) ? false : "gray";
                e = new Ext.tree.AsyncTreeNode({
                    uiProvider: SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolderUI,
                    text: c,
                    iconCls: "x-tree-node-icon",
                    checked: b,
                    filtered: true,
                    map_entries: [],
                    path: a,
                    loader: this.loader
                });
                e = h.appendChild(e)
            }
            if (g < 0) {
                break
            }
            h = e
        }
    },
    reloadPanel: function() {
        this.setRootNode();
        Ext.each(this.cgi_filtered_paths, function(a) {
            this.addFilteredNode(a)
        }, this);
        this.expandRootNode()
    },
    getFilteredRules: function() {
        var c = function(e, d) {
            Ext.each(e.childNodes, function(f) {
                if (f.attributes.checked === false) {
                    d.push(f.attributes.path)
                }
                if (f.attributes.checked !== false) {
                    c(f, d)
                }
            })
        };
        var a = this.componentQuery("selective_folder_chooser").getRootNode();
        var b = [];
        c(a, b);
        return b
    },
    expandRootNode: function() {
        var a = this.componentQuery("selective_folder_chooser");
        a.getRootNode().expand(false, true)
    },
    setConn: function(a) {
        this.loader = new SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.FolderLoader.Regular({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list_subfolder",
            apiSender: this,
            baseParams: Ext.apply({}, a)
        });
        this.cgi_filtered_paths = undefined;
        this.local_share = undefined
    },
    setRootNode: function() {
        var b = (this.cgi_filtered_paths === undefined || this.cgi_filtered_paths.length === 0) ? true : "gray";
        var a = new Ext.tree.AsyncTreeNode({
            uiProvider: SYNO.SDS.SynologyDriveShareSync.Component.ExtendedTreePanel.SelectiveFolderUI,
            text: this.local_share,
            iconCls: "x-tree-node-icon",
            checked: b,
            map_entries: [{
                type: "local"
            }, {
                type: "remote"
            }],
            path: "/",
            loader: this.loader
        });
        this.componentQuery("selective_folder_chooser").setRootNode(a)
    },
    isDirty: function() {
        if (this.cgi_filtered_paths === undefined) {
            return false
        }
        var a = this.cgi_filtered_paths;
        var c = this.getFilteredRules();
        if (a.length != c.length) {
            return true
        }
        a = a.slice(0);
        a.sort();
        c.sort();
        for (var b = 0; b < a.length; b++) {
            if (a[b] != c[b]) {
                return true
            }
        }
        return false
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Model.Connection", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Model",
    fields: ["id", "server_name", "status"]
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Store.Connection", {
    extend: "SYNO.SDS.SynologyDriveShareSync.data.WebAPIStore",
    model: "SYNO.SDS.SynologyDriveShareSync.Model.Connection",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "list",
            idProperty: "id",
            root: "conn"
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Model.Share", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Model",
    fields: ["enable", {
        name: "org_enable",
        mapping: "enable"
    }, {
        name: "org_local_share",
        mapping: "local_share"
    }, "conn_id", "sess_id", "view_id", "node_id", "db_error", "db_status", "remote_share", "local_share", "used", "status", "perm_sync", "sync_direction", "version", "rw", "unfinished_files", "attribute_check_strength", "is_c2share", "local_rw"],
    isSupportDelete: function() {
        if (this.get("org_enable") || !this.get("used")) {
            return false
        }
        return true
    },
    isSupportFolderSetting: function() {
        if (this.get("org_enable") && this.get("org_local_share")) {
            return false
        }
        return true
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Store.Share", {
    extend: "SYNO.SDS.SynologyDriveShareSync.data.WebAPIStore",
    model: "SYNO.SDS.SynologyDriveShareSync.Model.Share",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            pruneModifiedRecords: true,
            autoLoad: false,
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list",
            root: "session",
            idProperty: "view_id",
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            baseParams: {
                offset: 0,
                limit: 1024
            }
        };
        return Ext.apply(a, b)
    },
    getModifiedShareList: function(d, c, b) {
        var a = [];
        this.each(function(k) {
            if (k.get("enable") !== k.get("org_enable")) {
                var j = k.get("remote_share"),
                    g = k.get("local_share"),
                    f = k.get("version"),
                    i = k.get("perm_sync"),
                    e = k.get("sync_direction"),
                    h = k.get("attribute_check_strength"),
                    l = k.get("is_c2share");
                if (!SYNO.SDS.SynologyDriveShareSync.Util.SupportPermissionSetting(k, d, c, b)) {
                    i = 2
                }
                a.push({
                    conn_id: k.get("conn_id"),
                    enable: k.get("enable"),
                    view_id: k.get("view_id"),
                    node_id: k.get("node_id"),
                    sess_id: k.get("sess_id"),
                    local_share: g,
                    remote_share: j,
                    is_c2share: l,
                    perm_sync: i,
                    sync_direction: e,
                    attribute_check_strength: h,
                    rw: k.get("rw"),
                    version: f
                })
            }
        }, this);
        return a
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Model.SyncLog", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Model",
    fields: ["path", "action", "is_dir", "time", "rename_opt", "unsynced_reason"]
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Store.SyncLog", {
    extend: "SYNO.SDS.SynologyDriveShareSync.data.WebAPIStore",
    model: "SYNO.SDS.SynologyDriveShareSync.Model.SyncLog",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            pruneModifiedRecords: true,
            autoLoad: false,
            totalProperty: "total",
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list_sync_history",
            root: "history_items",
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            baseParams: {
                offset: 0,
                limit: 200
            }
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Instance", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.App",
    appWindowName: "SYNO.SDS.SynologyDriveShareSync.View.Viewport",
    controllers: ["SYNO.SDS.SynologyDriveShareSync.Controller.Main", "SYNO.SDS.SynologyDriveShareSync.Controller.Connection", "SYNO.SDS.SynologyDriveShareSync.Controller.Share"],
    models: ["SYNO.SDS.SynologyDriveShareSync.Model.Connection", "SYNO.SDS.SynologyDriveShareSync.Model.Share"],
    stores: ["SYNO.SDS.SynologyDriveShareSync.Store.Connection", "SYNO.SDS.SynologyDriveShareSync.Store.Share"],
    init: function() {}
});
