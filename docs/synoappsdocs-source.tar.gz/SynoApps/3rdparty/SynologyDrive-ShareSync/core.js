/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SynologyDriveShareSync.core.App
 * @extends SYNO.SDS.AppInstance
 * SynologyDrive share sync application class
 *
 */
Ext.define("SYNO.SDS.SynologyDriveShareSync.core.App", {
    extend: "SYNO.SDS.AppInstance",
    models: [],
    stores: [],
    controllers: [],
    config: {},
    constructor: function() {
        this.application = null;
        this.mainApplication = null;
        this._controllerObjs = {};
        this._storeObjs = {};
        this._modelObjs = {};
        this._startComponent = null;
        this.callParent(arguments);
        this._init()
    },
    _init: function() {
        this.application = this;
        this.mainApplication = this;
        var a = Ext.applyIf({
            application: this.application,
            appWindow: this.mainApplication,
            mainApplication: this.mainApplication
        }, this.config);
        this.init();
        this._initModels(a);
        this._initStores(a);
        this._initControllers(a)
    },
    init: function() {},
    _initModels: function(a) {
        this.models.forEach(function(c) {
            var d = Ext.getClassByName(c);
            var b = c.slice(c.lastIndexOf(".") + 1);
            this._modelObjs[b] = d
        }, this)
    },
    _initStores: function(a) {
        this.stores.forEach(function(c) {
            var d = Ext.getClassByName(c);
            var e = c.slice(c.lastIndexOf(".") + 1);
            var b = new d(Ext.apply({}, a));
            this._storeObjs[e] = b;
            this.addManagedComponent(b)
        }, this)
    },
    _initControllers: function(a) {
        this.controllers.forEach(function(e) {
            var d = Ext.getClassByName(e);
            var c = e.slice(e.lastIndexOf(".") + 1);
            var b = new d(Ext.apply({}, a));
            this._controllerObjs[c] = b;
            this.addManagedComponent(b)
        }, this)
    },
    initInstance: function(d) {
        var b = this.window;
        var a = this.trayItem;
        d = d || {};
        d.windowState = Ext.applyIf({
            application: this.application
        }, d.windowState);
        this.callParent(arguments);
        if (!b && !a) {
            this._startComponent = this.window || this.trayItem.panel;
            for (var c in this._controllerObjs) {
                if (this._controllerObjs.hasOwnProperty(c)) {
                    this._controllerObjs[c].init()
                }
            }
            this.launch()
        }
    },
    launch: function() {},
    getApplication: function() {
        return this.application
    },
    app: function() {
        return this.getApplication()
    },
    getModel: function(a) {
        return this._modelObjs[a] || this.application._modelObjs[a]
    },
    getStore: function(a) {
        return this._storeObjs[a] || this.application._storeObjs[a]
    },
    getController: function(a) {
        return this._controllerObjs[a] || this.application._controllerObjs[a]
    },
    getComponentByItemId: function(e, d) {
        var b = null,
            a = e.split(" ");
        if (!d) {
            d = this._startComponent || this.application._startComponent
        }
        while (a.length !== 0) {
            var c = a.shift();
            if (!c) {
                continue
            }
            b = SYNO.SDS.SynologyDriveShareSync.core.App.prototype._getComponentByItemId.call(this, c, d);
            if (b === null) {
                return b
            }
            d = SYNO.SDS.SynologyDriveShareSync.core.App.prototype._getSubComponent.call(this, b)
        }
        return b
    },
    _getComponentByItemId: function(d, c) {
        var b = Ext.isArray(c) ? c : [c],
            a;
        do {
            a = b.shift();
            if (a.getItemId() === d) {
                return a
            }
            b = b.concat(SYNO.SDS.SynologyDriveShareSync.core.App.prototype._getSubComponent.call(this, a))
        } while (b.length !== 0);
        return null
    },
    _getSubComponent: function(b) {
        var a = [];
        if (b.items) {
            a = a.concat(b.items.items)
        }
        if (b.buttons) {
            a = a.concat(b.buttons)
        }
        if (b.menu && b.menu.items) {
            a = a.concat(b.menu.items.items)
        }
        return a
    },
    componentQuery: function(b, a) {
        return this.getComponentByItemId(b, a)
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.WebAPI", {
    extend: "Ext.util.Observable",
    constructor: function(a) {
        this.callParent(arguments);
        this.mainApplication = a.mainApplication
    },
    testShare: function(d, c, e, a) {
        var b = {
            sess_list: d
        };
        if (undefined !== c.conn_id) {
            b.conn_id = c.conn_id
        } else {
            b.conn_entry = c
        }
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "test",
            params: b,
            callback: e,
            scope: (a) ? a : this
        })
    },
    updateShare: function(d, e, k, l) {
        var g;
        var h = [];
        var f = [];
        var b = [];
        var c = [];
        var j = [];
        if (e.filterMap) {
            for (g = 0; g < d.length; g++) {
                var a = d[g].view_id;
                if (e.filterMap.hasOwnProperty(a)) {
                    Ext.apply(d[g], e.filterMap[a])
                }
            }
        }
        for (g = 0; g < d.length; g++) {
            if (!d[g].hasOwnProperty("enable")) {
                b.push(d[g])
            } else {
                if (!d[g].enable) {
                    if (d[g].hasOwnProperty("sess_id")) {
                        j.push(d[g].sess_id)
                    }
                } else {
                    if (!d[g].hasOwnProperty("sess_id") || d[g].sess_id === 0) {
                        f.push(d[g])
                    } else {
                        c.push(d[g])
                    }
                }
            }
        }
        if (j.length > 0) {
            h.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "disable",
                params: {
                    sess_list: j
                }
            })
        }
        if (f.length > 0) {
            h.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "create",
                params: {
                    sess_list: f
                }
            })
        }
        if (c.length > 0) {
            h.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "enable",
                params: {
                    sess_list: c
                }
            })
        }
        if (b.length > 0) {
            h.push({
                api: "SYNO.SynologyDriveShareSync.Session",
                version: 1,
                method: "set",
                params: {
                    sess_list: b
                }
            })
        }
        this.mainApplication.sendWebAPI({
            compound: {
                params: h
            },
            callback: k,
            scope: (l) ? l : this
        })
    },
    removeShare: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "delete",
            params: {
                sess_id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    testConnection: function(a, d, c, e, b) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "test",
            params: {
                address: a,
                use_ssl: d,
                assume_connection_exist: c
            },
            callback: e,
            scope: (b) ? b : this
        })
    },
    createLink: function(a, c, b) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "auth",
            params: {
                server_name: a.server_name,
                server_ip: a.server_ip,
                server_port: a.server_port,
                user_name: a.user_name,
                password: a.user_passwd,
                otp: a.otp,
                ssl_enable: a.ssl_enable,
                use_proxy: a.use_proxy,
                proxy_ip: a.proxy_ip,
                proxy_port: a.proxy_port,
                proxy_username: a.proxy_username,
                proxy_password: a.proxy_password,
                use_tunnel: a.use_tunnel,
                tunnel_ip: a.tunnel_ip,
                tunnel_port: a.tunnel_port,
                ver_build_no: a.ver_build_no,
                do_verify_ssl: a.do_verify_ssl,
                c_mode: a.c_mode,
                domain_name: a.domain_name
            },
            encryption: ["password", "proxy_password"],
            callback: c,
            scope: (b) ? b : this
        })
    },
    createConnection: function(a, c, b) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "create",
            params: a,
            callback: c,
            scope: (b) ? b : this
        })
    },
    editLink: function(d, a, b, e, c) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "set",
            params: {
                conn_id: d,
                conn_entry: a,
                allow_ssl_change: b
            },
            callback: e,
            scope: (c) ? c : this
        })
    },
    cancelConnection: function(a, c, b) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "unlink",
            params: {
                conn_entry: a
            },
            callback: c,
            scope: b || this
        })
    },
    pause: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "pause",
            params: {
                id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    resume: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "resume",
            params: {
                id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    deleteConnection: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "delete",
            params: {
                id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    listConnection: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "list",
            params: Ext.copyTo({}, b, "offset,limit,additional"),
            callback: c,
            scope: (a) ? a : this
        })
    },
    getConnection: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "get",
            params: {
                conn_id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    getConfig: function(b, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Config",
            version: 1,
            method: "get",
            callback: b,
            scope: (a) ? a : this
        })
    },
    setConfig: function(d, a, b, f, e, c) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Config",
            version: 1,
            method: "set",
            params: {
                repo_loc: d,
                conflict_policy: a,
                rename_conflict: b,
                synchronization_mode: f
            },
            callback: e,
            scope: (c) ? c : this
        })
    },
    getSession: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "get",
            params: {
                sess_id: b
            },
            callback: c,
            scope: (a) ? a : this
        })
    },
    listSyncFolder: function(b, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list_syncfolder",
            callback: b,
            scope: (a) ? a : this
        })
    },
    refreshSession: function(b, c, a) {
        this.mainApplication.sendWebAPI({
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "refresh",
            params: Ext.copyTo({}, b, "conn_id,fast_monitor"),
            callback: c,
            scope: (a) ? a : this
        })
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.core.Controller", {
    extend: "Ext.Component",
    views: [],
    models: [],
    stores: [],
    webapi: "SYNO.SDS.SynologyDriveShareSync.WebAPI",
    constructor: function(a) {
        this.application = null;
        this.mainApplication = null;
        this._viewClasses = {};
        this._modelObjs = {};
        this._storeObjs = {};
        this.callParent(arguments);
        this._init(a)
    },
    _init: function(a) {
        this._initViews(a);
        this._initModels(a);
        this._initStores(a);
        this._initWebAPI(a)
    },
    _initViews: function() {
        this.views.forEach(function(a) {
            var b = Ext.getClassByName(a);
            var c = a.slice(a.lastIndexOf(".") + 1);
            this._viewClasses[c] = b
        }, this)
    },
    _initWebAPI: function(a) {
        var b = Ext.getClassByName(this.webapi);
        this._webapi = new b(a)
    },
    _initModels: SYNO.SDS.SynologyDriveShareSync.core.App.prototype._initModels,
    _initStores: SYNO.SDS.SynologyDriveShareSync.core.App.prototype._initStores,
    getApplication: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getApplication,
    app: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getApplication,
    getController: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getController,
    getModel: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getModel,
    getStore: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getStore,
    getView: function(a) {
        return this._viewClasses[a]
    },
    getWebAPI: function() {
        return this._webapi
    },
    componentQuery: SYNO.SDS.SynologyDriveShareSync.core.App.prototype.getComponentByItemId,
    init: function() {},
    control: function(d) {
        for (var a in d) {
            if (d.hasOwnProperty(a)) {
                var e = d[a],
                    b = this.componentQuery(a);
                for (var c in e) {
                    if (e.hasOwnProperty(c)) {
                        var f = e[c];
                        b.addListener(c, f, this)
                    }
                }
            }
        }
    },
    createWidget: function(a, b) {
        b = Ext.applyIf({
            application: this.application,
            appWindow: this.appWindow,
            mainApplication: this.mainApplication
        }, b);
        var c = new a(b);
        this.addManagedComponent(c);
        return c
    },
    getMainApplication: function() {
        return this.mainApplication
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.core.Model", {
    extend: "Ext.data.Record",
    fields: [],
    getApplication: function() {
        return this.application
    },
    app: function() {
        return this.application
    },
    getMainApplication: function() {
        return this.mainApplication
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.core.Widget", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    viewport: "",
    views: [],
    models: [],
    stores: [],
    controllers: [],
    config: {},
    constructor: function(a) {
        this.application = null;
        this.mainApplication = null;
        this._controllerObjs = {};
        this._viewObjs = {};
        this._storeObjs = {};
        this._modelObjs = {};
        this._viewportObj = null;
        this._startComponent = null;
        a = a || {};
        this.config = Ext.apply({}, a);
        this.application = this;
        this.mainApplication = a.mainApplication;
        this.appWindow = a.mainApplication;
        a.application = this.application;
        this.callParent([a])
    },
    _init: function(a) {
        this._initModels(a);
        this._initStores(a);
        this._initControllers(a);
        this._initWebAPI(a);
        if (this.viewport) {
            var c = Ext.getClassByName(this.viewport);
            this._viewportObj = new c(a);
            this._startComponent = this._viewportObj
        }
        this.init();
        for (var b in this._controllerObjs) {
            if (this._controllerObjs.hasOwnProperty(b)) {
                this._controllerObjs[b].init()
            }
        }
    },
    _initControllers: SYNO.SDS.SynologyDriveShareSync.core.App.prototype._initControllers,
    getViewport: function() {
        return this._viewportObj
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.data.JsonStore", {
    extend: "Ext.data.Store",
    constructor: function(d) {
        var g;
        if (this.model) {
            var c = Ext.define(null, {
                    extend: this.model
                }),
                f = c.prototype,
                b = f.fields;
            f.self = Ext.getClassByName(this.model);
            f.application = d.application;
            f.mainApplication = d.mainApplication;
            f.fields = new Ext.util.MixedCollection(false, function(h) {
                return h.name
            });
            for (var e = 0, a = b.length; e < a; ++e) {
                f.fields.add(new Ext.data.Field(b[e]))
            }
            c.getField = function(h) {
                return f.fields.get(h)
            };
            d = Ext.apply({
                recordType: c
            }, d);
            g = c
        }
        return this.callParent([Ext.apply(d, {
            reader: new Ext.data.JsonReader(d, g)
        })])
    },
    loadData: function(c, a) {
        if (typeof a !== "object") {
            return this.callParent(arguments)
        }
        var b = this.reader.readRecords(c);
        this.loadRecords(b, a, true)
    },
    loadRecords: function(b, n, m) {
        if (this.isDestroyed === true) {
            return
        }
        if (!b || m === false || !n || n.update !== true) {
            return this.callParent(arguments)
        }
        var f, e, k, l, h = this.data.clone(),
            d = b.records,
            c = b.totalRecords || d.length;
        this.modified = [];
        for (f = 0; f < c; ++f) {
            l = d[f];
            k = this.getById(l.id);
            if (k) {
                if (n.preserveDirtyRecord) {
                    if (!n.preserveDirtyFields || !n.preserveDirtyFields.length) {
                        if (k.dirty) {
                            l.data = k.data;
                            l.modified = k.modified;
                            l.dirty = true
                        }
                    } else {
                        var a = n.preserveDirtyFields,
                            g;
                        for (e = 0; e < n.preserveDirtyFields.length; ++e) {
                            g = a[e];
                            if (k.isModified(g)) {
                                l.set(g, k.get(g))
                            }
                        }
                    }
                    if (l.dirty) {
                        this.modified.push(l)
                    }
                }
                this.doUpdate(l);
                h.removeKey(l.id)
            } else {
                this.insert(f, [l])
            }
        }
        this.totalLength = this.data.length;
        this.applySort();
        this.fireEvent("datachanged", this);
        this.fireEvent("load", this, d, n);
        if (n.callback) {
            n.callback.call(n.scope || this, d, n, true)
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.data.WebAPIStore", {
    extend: "SYNO.API.Store",
    constructor: function(d) {
        var g;
        if (this.model) {
            var c = Ext.define(null, {
                    extend: this.model
                }),
                f = c.prototype,
                b = f.fields;
            f.self = Ext.getClassByName(this.model);
            f.application = d.application;
            f.mainApplication = d.mainApplication;
            f.fields = new Ext.util.MixedCollection(false, function(h) {
                return h.name
            });
            for (var e = 0, a = b.length; e < a; ++e) {
                f.fields.add(new Ext.data.Field(b[e]))
            }
            c.getField = function(h) {
                return f.fields.get(h)
            };
            d = Ext.apply({
                recordType: c
            }, d);
            g = c
        }
        return this.callParent([Ext.apply(d, {
            reader: new Ext.data.JsonReader(d, g)
        })])
    },
    loadData: function(c, a) {
        if (typeof a !== "object") {
            return this.callParent(arguments)
        }
        var b = this.reader.readRecords(c);
        this.loadRecords(b, a, true)
    },
    loadRecords: function(b, n, m) {
        if (this.isDestroyed === true) {
            return
        }
        if (!b || m === false || !n || n.update !== true) {
            return this.callParent(arguments)
        }
        var f, e, k, l, h = this.data.clone(),
            d = b.records,
            c = b.totalRecords || d.length;
        this.modified = [];
        for (f = 0; f < c; ++f) {
            l = d[f];
            k = this.getById(l.id);
            if (k) {
                if (n.preserveDirtyRecord) {
                    if (!n.preserveDirtyFields || !n.preserveDirtyFields.length) {
                        if (k.dirty) {
                            l.data = k.data;
                            l.modified = k.modified;
                            l.dirty = true
                        }
                    } else {
                        var a = n.preserveDirtyFields,
                            g;
                        for (e = 0; e < n.preserveDirtyFields.length; ++e) {
                            g = a[e];
                            if (k.isModified(g)) {
                                l.set(g, k.get(g))
                            }
                        }
                    }
                    if (l.dirty) {
                        this.modified.push(l)
                    }
                }
                this.doUpdate(l);
                h.removeKey(l.id)
            } else {
                this.insert(f, [l])
            }
        }
        while (h.getCount() > 0) {
            k = h.first();
            h.removeKey(k.id);
            this.remove(k)
        }
        this.totalLength = this.data.length;
        this.applySort();
        this.fireEvent("datachanged", this);
        this.fireEvent("load", this, d, n);
        if (n.callback) {
            n.callback.call(n.scope || this, d, n, true)
        }
    }
});
Ext.ns("SYNO.SDS.SynologyDriveShareSync.Util");
SYNO.SDS.SynologyDriveShareSync.MinBuildNumberSupportPermissionSetting = 3100;
var _SDSS = function(b, a) {
    var c = _TT("SYNO.SDS.SynologyDriveShareSync.Instance", b, a);
    if (arguments.length <= 2) {
        return c
    } else {
        Array.prototype.splice.call(arguments, 0, 2, c);
        return String.format.apply(this, arguments)
    }
};
var _SDSSAPPNAME = _SDSS("app", "app_name");
SYNO.SDS.SynologyDriveShareSync.ErrorCode = {};
SYNO.SDS.SynologyDriveShareSync.ErrorTable = {};
(function() {
    function a(c, d) {
        var b = Array.prototype.slice.call(arguments, 2);
        SYNO.SDS.SynologyDriveShareSync.ErrorCode[d] = c;
        SYNO.SDS.SynologyDriveShareSync.ErrorTable[c] = {
            getMsg: function() {
                var e = [];
                Ext.each(b, function(f) {
                    if (Ext.isObject(f)) {
                        e.push(_SDSS(f.sec, f.key))
                    } else {
                        e.push(f)
                    }
                });
                return _SDSS.apply(this, e)
            }
        }
    }
    a(401, "GENERIC", "warning", "err_sys");
    a(402, "DATABASE", "warning", "err_database");
    a(403, "SSL_CHANGE", "warning", "err_ssl_change");
    a(404, "SHARE_CONFLICT", "warning", "err_share_folder_conflict");
    a(405, "INVALID_SHARE", "warning", "err_invalid_share");
    a(406, "DISABLE_SESSION_PARTIAL", "warning", "partial_share_disable_fail");
    a(407, "ENABLE_SESSION_PARTIAL", "warning", "partial_share_enable_fail");
    a(408, "DS_NOT_MATCH", "warning", "err_ds_not_match", {
        sec: "app",
        key: "pkg_name"
    });
    a(409, "LINK_SAME_DS", "warning", "err_link_same_ds");
    a(410, "INVALID_LOCALHOST", "warning", "err_invalid_localhost");
    a(411, "AUTOCONN_INVALID", "warning", "err_autoconn_invalidid2");
    a(412, "AUTOCONN_CTRL", "warning", "err_autoconn_ctrl");
    a(413, "AUTOCONN_TUNNEL_DISABLED", "msg", "err_tunnel_disabled");
    a(414, "LOCAL_COLD_SHARE_NOT_SUPPORTED", "msg", "err_local_cold_not_supported_share_name");
    a(415, "LOCAL_C2_SHARE_NOT_SUPPORTED", "msg", "err_local_c2_not_supported_share_name");
    a(500, "NO_SERVICE", "warning", "no_service");
    a(501, "UPGRADING", "msg", "msg_upgrading");
    a(502, "UPGRADE_FAIL", "msg", "err_upgrade_fail", _SDSSAPPNAME, {
        sec: "app",
        key: "pkg_name"
    });
    a(503, "REPO_MOVE", "warning", "err_drive_repomove");
    a(600, "SPACE_NOT_ENOUGH", "msg", "not_enough_space");
    a(601, "NO_SUCH_VOLUME", "msg", "volume_not_found");
    a(602, "VOLUME_READONLY", "msg", "volume_readonly");
    a(603, "INVALID_REPO", "msg", "invalid_repo_path");
    a(700, "NETWORK", "warning", "err_network");
    a(701, "PROTO", "warning", "err_proto", _SDSSAPPNAME);
    a(702, "VERSION_CLIENT", "warning", "err_version_client", _SDSSAPPNAME, {
        sec: "app",
        key: "pkg_name"
    });
    a(703, "VERSION_SERVER", "warning", "err_version_server");
    a(704, "AUTH", "warning", "err_auth");
    a(705, "DSM_DISABLE", "warning", "err_dsmdisable");
    a(706, "ADMIN_REQUIRED", "warning", "err_admin_required");
    a(707, "USERNAME_FAIL", "msg", "test_username_fail");
    a(708, "IP_NOT_ALLOWED", "warning", "err_ip_not_allowed");
    a(709, "MAX_TRIES", "warning", "err_max_tries");
    a(710, "OTP_REQUIRED", "warning", "err_otp_required");
    a(711, "OTP_INVALID", "warning", "err_otp_invalid");
    a(712, "OTP_ENFORCED", "warning", "err_otp_enforced");
    a(713, "PASSWORD_EXPIRED", "msg", "err_pwd_expired");
    a(714, "USER_NO_PRIVILEGE", "warning", "err_user_privilege");
    a(715, "USER_INFO_UNAVAIL", "warning", "err_user_info_unavailable");
    a(716, "SSL_VERIFY_FAIL", "warning", "err_ssl_verify_fail");
    a(717, "USER_NOT_ALLOWED", "warning", "err_user_not_allowed")
})();
SYNO.SDS.SynologyDriveShareSync.Util.IsEnableSessionPartialError = function(a) {
    var b = [SYNO.SDS.SynologyDriveShareSync.ErrorCode.LOCAL_COLD_SHARE_NOT_SUPPORTED, SYNO.SDS.SynologyDriveShareSync.ErrorCode.LOCAL_C2_SHARE_NOT_SUPPORTED];
    return b.indexOf(a) != -1
};
SYNO.SDS.SynologyDriveShareSync.Util.IsSupportColdStorageModel = function() {
    return _D("support_peta_volume") === "yes"
};
SYNO.SDS.SynologyDriveShareSync.Util.SupportPermissionSetting = function(f, h, e, c) {
    var g = f.get("remote_share"),
        b = f.get("version"),
        d = f.get("local_share");
    if (!e) {
        return false
    }
    if (h < SYNO.SDS.SynologyDriveShareSync.MinBuildNumberSupportPermissionSetting) {
        return false
    }
    if (SYNO.SDS.SynologyDriveShareSync.Util.IsSpecialShare(g)) {
        return false
    }
    if (_D("usbstation") === "yes") {
        return false
    }
    if (b !== 5) {
        return false
    }
    if (!c) {
        return false
    }
    if (d) {
        var a = Ext.each(c, function(k, i, j) {
            return (k.share_name == d) ? false : true
        }, this);
        if ((a !== undefined) && c[a].version !== 5) {
            return false
        }
        if (SYNO.SDS.SynologyDriveShareSync.Util.IsSpecialShare(d)) {
            return false
        }
    }
    return true
};
SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToDescription = function(a, b) {
    switch (a) {
        case "uptodate":
            return {
                cls: ["green-status"], status: _SDSS("tray", "uptodate"), description: _SDSS("msg", "desc_uptodate")
            };
        case "syncing":
            return {
                cls: ["blue-status"], status: _SDSS("msg", "try_syncing") + "...", description: String.format(_SDSS("msg", "syncing_n_files"), b)
            };
        case "connecting":
        case "err_io":
            return {
                cls: ["blue-status"], status: _SDSS("msg", "linking") + "...", description: _SDSS("msg", "desc_linking")
            };
        case "stop":
        case "pause":
            return {
                cls: ["gray-status"], status: _SDSS("msg", "pausing"), description: _SDSS("msg", "desc_pause")
            };
        case "unlink":
            return {
                cls: ["blue-status"], status: _SDSS("msg", "standby"), description: _SDSS("msg", "desc_unlink")
            };
        case "err_old_server_version":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_version_server")
            };
        case "err_old_client_version":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_version_client", _SDSSAPPNAME, _SDSS("app", "pkg_name"))
            };
        case "err_version":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_version_short")
            };
        case "err_dsid_change":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("tray", "ds_change")
            };
        case "err_ssl_verify_fail":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_ssl_verify_fail")
            };
        case "err_ssl_change":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_ssl_change")
            };
        case "err_auth":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_auth_short")
            };
        case "err_readonly":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "folder_readonly")
            };
        case "err_folder_miss":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_share_nonexist_short")
            };
        case "err_remote_disk_full":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: String.format(_SDSS("msg", "diskfull"), "2GB")
            };
        case "err_view":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_share_fail_enable")
            };
        case "err_ip_not_allowed":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_ip_not_allowed")
            };
        case "err_dsmdisable":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_dsmdisable")
            };
        case "err_user_privilege":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_user_privilege")
            };
        case "err_user_info_unavailable":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_user_info_unavailable")
            };
        case "err_local_disk_full":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "localdiskfull")
            };
        case "err_local_not_mounted":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "err_local_not_mounted")
            };
        case "err_local_cold_not_supported":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "err_local_cold_not_supported")
            };
        case "err_local_c2_not_supported":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "err_local_c2_not_supported")
            };
        case "err_user_not_allowed":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("warning", "err_user_not_allowed_short")
            };
        default:
        case "unknown":
        case "err_permission":
        case "err_quota":
        case "err_share_quota":
        case "err_unknown":
            return {
                cls: ["red-status"], status: _SDSS("msg", "notify_abnormal_short"), description: _SDSS("msg", "notify_abnormal", _SDSSAPPNAME)
            }
    }
};
SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToIconType = function(a) {
    switch (a) {
        case "uptodate":
            return "uptodate";
        case "syncing":
            return "syncing";
        case "connecting":
        case "err_io":
            return "connecting";
        case "stop":
        case "pause":
            return "pause";
        case "unlink":
            return "unlink";
        default:
        case "unknown":
        case "err_old_server_version":
        case "err_old_client_version":
        case "err_version":
        case "err_dsid_change":
        case "err_ssl_verify_fail":
        case "err_ssl_change":
        case "err_auth":
        case "err_unknown":
        case "err_view":
        case "err_readonly":
        case "err_permission":
        case "err_folder_miss":
        case "err_quota":
        case "err_share_quota":
        case "err_remote_disk_full":
        case "err_local_disk_full":
        case "err_ip_not_allowed":
        case "err_local_not_mounted":
        case "err_dsmdisable":
        case "err_user_info_unavailable":
        case "err_user_privilege":
        case "err_local_cold_not_supported":
        case "err_local_c2_not_supported":
        case "err_user_not_allowed":
            return "error"
    }
};
SYNO.SDS.SynologyDriveShareSync.Util.DecorateStatusString = function(b, a) {
    switch (b) {
        case "uptodate":
            return '<span class="green-status">' + a + "</span>";
        case "syncing":
        case "connecting":
        case "err_io":
        case "unlink":
            return '<span class="blue-status">' + a + "</span>";
        case "stop":
        case "pause":
            return '<span class="gray-status">' + a + "</span>";
        case "err_old_server_version":
        case "err_old_client_version":
        case "err_version":
        case "err_dsid_change":
        case "err_ssl_verify_fail":
        case "err_ssl_change":
        case "err_auth":
        case "err_readonly":
        case "err_folder_miss":
        case "err_view":
        case "err_duplicate_share":
        case "err_permission":
        case "err_quota":
        case "err_share_quota":
        case "err_remote_disk_full":
        case "err_local_disk_full":
        case "err_not_mounted":
        case "err_local_not_mounted":
        case "err_sync_direction":
        case "err_ip_not_allowed":
        case "err_dsmdisable":
        case "err_user_info_unavailable":
        case "err_user_privilege":
        case "err_local_cold_not_supported":
        case "err_local_c2_not_supported":
        case "err_user_not_allowed":
            return '<span class="red-status">' + a + "</span>";
        default:
            return a
    }
};
SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToString = function(a) {
    switch (a) {
        case "uptodate":
            return _SDSS("tray", "uptodate");
        case "syncing":
            return _SDSS("msg", "try_syncing");
        case "connecting":
        case "err_io":
            return _SDSS("msg", "linking");
        case "stop":
        case "pause":
            return _SDSS("msg", "pausing");
        case "preparing":
            return _SDSS("tray", "preparing");
        case "unlink":
            return _SDSS("msg", "standby");
        case "err_old_server_version":
            return _SDSS("warning", "err_version_server");
        case "err_old_client_version":
            return _SDSS("warning", "err_version_client", _SDSSAPPNAME, _SDSS("app", "pkg_name"));
        case "err_version":
            return _SDSS("warning", "err_version_short");
        case "err_dsid_change":
            return _SDSS("tray", "ds_change");
        case "err_ssl_verify_fail":
            return _SDSS("warning", "err_ssl_verify_fail");
        case "err_ssl_change":
            return _SDSS("warning", "err_ssl_change");
        case "err_auth":
            return _SDSS("warning", "err_auth_short");
        case "err_readonly":
            return _SDSS("msg", "folder_readonly");
        case "err_folder_miss":
            return _SDSS("warning", "err_share_nonexist_short");
        case "err_view":
            return _SDSS("warning", "err_share_fail_enable");
        case "err_duplicate_share":
            return _SDSS("warning", "err_duplicate_share");
        case "err_permission":
            return _SDSS("warning", "err_share_perm_short");
        case "err_quota":
            return _SDSS("msg", "quotafull");
        case "err_share_quota":
            return _SDSS("msg", "remote_share_quotafull");
        case "err_remote_disk_full":
            return String.format(_SDSS("msg", "diskfull"), "2GB");
        case "err_local_disk_full":
            return _SDSS("msg", "localdiskfull");
        case "err_local_not_mounted":
            return _SDSS("msg", "err_local_not_mounted");
        case "err_sync_direction":
            return _SDSS("msg", "err_sync_direction_dismatch");
        case "err_not_mounted":
            return _SDSS("msg", "err_remote_not_mounted");
        case "err_ip_not_allowed":
            return _SDSS("warning", "err_ip_not_allowed");
        case "err_dsmdisable":
            return _SDSS("warning", "err_dsmdisable");
        case "err_user_info_unavailable":
            return _SDSS("warning", "err_user_info_unavailable");
        case "err_user_privilege":
            return _SDSS("warning", "err_user_privilege");
        case "err_local_cold_not_supported":
            return _SDSS("msg", "err_local_cold_not_supported");
        case "err_local_c2_not_supported":
            return _SDSS("msg", "err_local_c2_not_supported");
        case "err_user_not_allowed":
            return _SDSS("warning", "err_user_not_allowed_short");
        default:
        case "unknown":
        case "err_unknown":
            return _SDSS("msg", "error", _SDSS("app", "pkg_name"))
    }
};
SYNO.SDS.SynologyDriveShareSync.Util.IsSpecialShare = function(a) {
    var b = ["photo", "surveillance"];
    if (b.indexOf(Ext.util.Format.lowercase(a)) != -1) {
        return true
    }
    return false
};
SYNO.SDS.SynologyDriveShareSync.Util.GetErrorString = function(a) {
    var b;
    if (!a) {
        return _SDSS("warning", "err_common")
    }
    if (a.has_fail) {
        b = SYNO.API.Util.GetFirstError(a)
    } else {
        b = a
    }
    if (SYNO.SDS.SynologyDriveShareSync.ErrorTable.hasOwnProperty(b.code)) {
        return SYNO.SDS.SynologyDriveShareSync.ErrorTable[b.code].getMsg()
    }
    return SYNO.API.getErrorString(b.code)
};
SYNO.SDS.SynologyDriveShareSync.Util.GetErrorStringWithErrorCode = function(a) {
    if (!a) {
        return _SDSS("warning", "err_common")
    }
    return SYNO.SDS.SynologyDriveShareSync.ErrorTable[a].getMsg()
};
Ext.ns("SYNO.SDS.SynologyDriveShareSync.SelectiveSync");
SYNO.SDS.SynologyDriveShareSync.SelectiveSync.BuiltInExtensions = function() {
    var a = [{
        node_type: "music",
        display_name: _SDSS("common", "music"),
        icon_cls: "syno-tree-node-music",
        extensions: [".aac", ".aif", ".aifc", ".aiff", ".ape", ".au", ".cdda", ".dff", ".dsf", ".eaac", ".flac", ".kar", ".l16", ".m3u", ".m4a", ".m4b", ".m4p", ".mid", ".midi", ".mp1", ".mp2", ".mp3", ".mpc", ".mpga", ".ogg", ".pcm", ".pls", ".ra", ".ram", ".snd", ".tta", ".vqf", ".wav", ".wma"]
    }, {
        node_type: "video",
        display_name: _SDSS("common", "video"),
        icon_cls: "syno-tree-node-video",
        extensions: [".3g2", ".3gp", ".aaf", ".amr", ".ani", ".asf", ".asx", ".avi", ".dat", ".dif", ".divx", ".dv", ".dvr-ms", ".f4v", ".flv", ".ifo", ".m1v", ".m2t", ".m2ts", ".m2v", ".m4u", ".m4v", ".mkv", ".mov", ".movie", ".mp4", ".mpe", ".mpeg", ".mpeg1", ".mpeg2", ".mpeg4", ".mpg", ".mts", ".mxf", ".mxu", ".ogm", ".ogv", ".qt", ".qtx", ".rec", ".rm", ".rmvb", ".swf", ".tp", ".trp", ".ts", ".vob", ".webm", ".wmv", ".wmv9", ".wmx", ".xvid"]
    }, {
        node_type: "image",
        display_name: _SDSS("common", "image"),
        icon_cls: "syno-tree-node-image",
        extensions: [".3fr", ".ari", ".arw", ".bay", ".bmp", ".cap", ".cgm", ".cr2", ".crw", ".dcr", ".dcs", ".djv", ".djvu", ".dng", ".drf", ".eip", ".erf", ".fff", ".gif", ".ico", ".ief", ".iff", ".iiq", ".ilbm", ".jp2", ".jpe", ".jpeg", ".jpg", ".k25", ".kdc", ".lbm", ".mac", ".mef", ".mng", ".mos", ".mrw", ".nef", ".nrw", ".obm", ".orf", ".pbm", ".pct", ".pcx", ".pef", ".pgm", ".pic", ".pict", ".png", ".pnm", ".pnt", ".pntg", ".ppm", ".psd", ".ptx", ".pxn", ".qti", ".qtif", ".r3d", ".raf", ".ras", ".raw", ".rgb", ".rw2", ".rwl", ".rwz", ".sr2", ".srf", ".srw", ".svg", ".tga", ".tif", ".tiff", ".ufo", ".wbmp", ".x3f", ".xbm", ".xpm", ".xwd"]
    }, {
        node_type: "document",
        display_name: _SDSS("common", "document"),
        icon_cls: "syno-tree-node-document",
        extensions: [".doc", ".docx", ".epub", ".htm", ".html", ".key", ".mobi", ".numbers", ".odp", ".ods", ".odt", ".pages", ".pdf", ".pps", ".ppsx", ".ppt", ".pptx", ".prc", ".txt", ".xls", ".xlsx"]
    }];
    return a
};
Ext.define("SYNO.SDS.SynologyDriveShareSync.Util.ProgressWebAPI", {
    constructor: function(a) {
        this.owner = a.owner;
        this.app = a.app;
        this.reg_id = undefined;
        this.api = a.api;
        this.version = a.version || 1;
        this.start_method = a.start_method || "start";
        this.status_method = a.status_method || "status";
        this.show_msgbox = a.show_msgbox;
        this.show_progress = a.show_progress;
        this.msg_text = a.msg_text;
        this.error_callback = a.error;
        this.success_callback = a.success;
        this.scope = a.scope || this
    },
    startTask: function(a) {
        this.owner.setStatusBusy(true);
        if (this.show_msgbox === true) {
            this.owner.getMsgBox().show({
                wait: false,
                progress: this.show_progress,
                closable: false,
                maxWidth: 300,
                title: this.owner.title,
                msg: this.msg_text
            })
        }
        this.app.sendWebAPI({
            api: this.api,
            version: this.version,
            method: this.start_method,
            params: a,
            callback: this.startTaskCB,
            scope: this
        })
    },
    startTaskCB: function(d, a, c, b) {
        this.owner.clearStatusBusy();
        if (!d) {
            if (Ext.isFunction(this.error_callback)) {
                this.error_callback.apply(this.scope, [a])
            }
            return
        }
        this.task_id = a.task_id;
        this.setPollingTask(true)
    },
    setPollingTask: function(a) {
        if (undefined !== this.polling_task) {
            this.polling_task.remove();
            this.polling_task = undefined
        }
        if (a) {
            this.reg_id = this.app.pollReg({
                interval: 1,
                immediate: true,
                webapi: {
                    api: this.api,
                    version: this.version,
                    method: this.status_method,
                    params: {
                        task_id: this.task_id
                    }
                },
                status_callback: this.pollingCB,
                scope: this
            });
            if (this.show_progress) {
                this.updateProgress(0, 0)
            }
        }
    },
    pollingCB: function(d, a, c, b) {
        if (!d || !a.success) {
            this.setPollingTask(false);
            this.finishTask();
            if (Ext.isFunction(this.error_callback)) {
                this.error_callback.apply(this.scope, [a])
            }
        } else {
            if (this.show_progress) {
                this.updateProgress(parseInt(a.data.total, 10), parseInt(a.data.current, 10))
            }
            if (a.finish) {
                this.finishTask();
                if (Ext.isFunction(this.success_callback)) {
                    this.success_callback.apply(this.scope, [a])
                }
            }
        }
    },
    updateProgress: function(c, d) {
        var b = 0;
        if (c > 0) {
            b = d / c
        }
        b = (b < 0.01) ? 0.01 : b;
        var a = b * 100;
        if (this.reg_id && this.show_msgbox) {
            this.owner.getMsgBox().updateProgress(b, a.toFixed(2).toString() + "%", this.msg_text)
        }
    },
    finishTask: function() {
        if (this.reg_id) {
            this.app.pollUnreg(this.reg_id);
            this.reg_id = undefined;
            if (this.show_msgbox) {
                this.owner.getMsgBox().hide()
            }
        }
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Util.SessionSetTask", {
    extend: "SYNO.SDS.SynologyDriveShareSync.Util.ProgressWebAPI",
    constructor: function(a) {
        var b = a;
        b.api = "SYNO.SynologyDriveShareSync.Session.Set";
        b.show_msgbox = true;
        b.show_progress = true;
        b.msg_text = _T("common", "saving");
        this.callParent([b])
    }
});
