/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.ActiveInsight.Application
 * @extends SYNO.SDS.AppInstance
 * ActiveInsight application class
 *
 */
Ext.define("SYNO.SDS.ActiveInsight.Application", {
    extend: "SYNO.SDS.AppInstance",
    onOpen: function(a) {
        window.open(window.location.protocol + "//insight.synology.com/");
        this.destroy()
    }
});
