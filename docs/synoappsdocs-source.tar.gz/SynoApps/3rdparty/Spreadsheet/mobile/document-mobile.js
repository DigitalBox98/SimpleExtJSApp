! function(t, e) {
    "object" == typeof exports && "object" == typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? exports.OF = e() : t.OF = e()
}(window, (function() {
    return function(t) {
        var e = {};

        function n(r) {
            if (e[r]) return e[r].exports;
            var i = e[r] = {
                i: r,
                l: !1,
                exports: {}
            };
            return t[r].call(i.exports, i, i.exports, n), i.l = !0, i.exports
        }
        return n.m = t, n.c = e, n.d = function(t, e, r) {
            n.o(t, e) || Object.defineProperty(t, e, {
                enumerable: !0,
                get: r
            })
        }, n.r = function(t) {
            "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
                value: "Module"
            }), Object.defineProperty(t, "__esModule", {
                value: !0
            })
        }, n.t = function(t, e) {
            if (1 & e && (t = n(t)), 8 & e) return t;
            if (4 & e && "object" == typeof t && t && t.__esModule) return t;
            var r = Object.create(null);
            if (n.r(r), Object.defineProperty(r, "default", {
                    enumerable: !0,
                    value: t
                }), 2 & e && "string" != typeof t)
                for (var i in t) n.d(r, i, function(e) {
                    return t[e]
                }.bind(null, i));
            return r
        }, n.n = function(t) {
            var e = t && t.__esModule ? function() {
                return t.default
            } : function() {
                return t
            };
            return n.d(e, "a", e), e
        }, n.o = function(t, e) {
            return Object.prototype.hasOwnProperty.call(t, e)
        }, n.p = "", n(n.s = 5)
    }([function(t, e) {
        t.exports = function(t, e) {
            t.prototype = Object.create(e.prototype), t.prototype.constructor = t, t.__proto__ = e
        }
    }, function(t, e) {
        function n(t, e) {
            for (var n = 0; n < e.length; n++) {
                var r = e[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
            }
        }
        t.exports = function(t, e, r) {
            return e && n(t.prototype, e), r && n(t, r), t
        }
    }, function(t, e, n) {
        var r = n(3),
            i = n(4);

        function o(e, n, s) {
            return i() ? t.exports = o = Reflect.construct : t.exports = o = function(t, e, n) {
                var i = [null];
                i.push.apply(i, e);
                var o = new(Function.bind.apply(t, i));
                return n && r(o, n.prototype), o
            }, o.apply(null, arguments)
        }
        t.exports = o
    }, function(t, e) {
        function n(e, r) {
            return t.exports = n = Object.setPrototypeOf || function(t, e) {
                return t.__proto__ = e, t
            }, n(e, r)
        }
        t.exports = n
    }, function(t, e) {
        t.exports = function() {
            if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
            if (Reflect.construct.sham) return !1;
            if ("function" == typeof Proxy) return !0;
            try {
                return Date.prototype.toString.call(Reflect.construct(Date, [], (function() {}))), !0
            } catch (t) {
                return !1
            }
        }
    }, function(t, e, n) {
        "use strict";
        n.r(e), n.d(e, "Doc", (function() {
            return St
        }));
        var r = {};
        n.r(r), n.d(r, "DEFAULT", (function() {
            return u
        })), n.d(r, "DIRECTION", (function() {
            return a
        })), n.d(r, "CHART_TYPE", (function() {
            return l
        })), n.d(r, "GROUPING", (function() {
            return c
        })), n.d(r, "ORIENTATION", (function() {
            return h
        })), n.d(r, "MARKER_SYMBOL", (function() {
            return f
        })), n.d(r, "LEGEND_POSITION", (function() {
            return g
        })), n.d(r, "LABEL_POSITION", (function() {
            return p
        })), n.d(r, "LINE_DASH", (function() {
            return d
        })), n.d(r, "BLANK_AS", (function() {
            return y
        }));
        var i = {};
        n.r(i), n.d(i, "isEmpty", (function() {
            return S
        })), n.d(i, "isDefined", (function() {
            return C
        })), n.d(i, "isFunction", (function() {
            return b
        })), n.d(i, "isNumber", (function() {
            return v
        })), n.d(i, "isString", (function() {
            return x
        })), n.d(i, "PLOT_STYLE", (function() {
            return A
        })), n.d(i, "getFontHeight", (function() {
            return m
        })), n.d(i, "capitalize", (function() {
            return T
        })), n.d(i, "trimArray", (function() {
            return L
        })), n.d(i, "ensureString", (function() {
            return _
        })), n.d(i, "parseHexColor", (function() {
            return w
        }));
        var o = n(0),
            s = n.n(o),
            u = {
                TYPE: "bar",
                BAR_DIR: "col",
                GROUPING: "standard",
                DATA_DIR: "row",
                ORIENTATION: "minMax",
                MARKER_SYMBOL: "circle",
                LEGEND_POSITION: "r",
                LABEL_POSITION: "t",
                LINE_DASH: "solid",
                BLANK_AS: "gap",
                BACKGROUND: "#FFFFFF"
            },
            a = {
                ROW: "row",
                COL: "col"
            },
            l = {
                BAR: "bar",
                LINE: "line",
                AREA: "area",
                PIE: "pie",
                SCATTER: "scatter",
                HYBRID: "hybrid"
            },
            c = {
                STANDARD: "standard",
                STACKED: "stacked",
                PERCENTAGE: "percentageStacked"
            },
            h = {
                SEQUENCE: "minMax",
                REVERSE: "maxMin"
            },
            f = {
                CIRCLE: "circle",
                DIAMOND: "diamond",
                TRIANGLE: "triangle",
                SQUARE: "square",
                NONE: "none"
            },
            g = {
                TOP: "t",
                LEFT: "l",
                RIGHT: "r",
                BOTTOM: "b"
            },
            p = {
                TOP: "t",
                LEFT: "l",
                RIGHT: "r",
                BOTTOM: "b",
                INSIDE_BASE: "inBase",
                INSIDE_END: "inEnd",
                INSIDE_CENTER: "inCenter"
            },
            d = {
                SOLID: "solid",
                DASH: "dash",
                DOT: "dot"
            },
            y = {
                ZERO: "zero",
                GAP: "gap",
                SPAN: "span"
            };

        function S(t) {
            return null == t || "" === t
        }

        function C(t) {
            return null != t
        }

        function b(t) {
            return "[object Function]" === Object.prototype.toString.call(t)
        }

        function v(t) {
            return "number" == typeof t && isFinite(t)
        }

        function x(t) {
            return "string" == typeof t
        }
        var A = {
            titleGap: 8,
            legendWidth: 72,
            padding: {
                top: 32,
                bottom: 32,
                left: 16,
                right: 16
            },
            plotGap: 12,
            cm2pxMultiplier: 72 / 2.54 / .75
        };

        function m(t) {
            return 1.4 * t
        }

        function T(t) {
            return t[0].toUpperCase() + t.slice(1)
        }

        function L(t, e) {
            for (var n;
                (n = t.length) && null == t[n - 1];) e && (t = t.slice(), e = !1), t.pop();
            return t
        }

        function _(t) {
            return C(t) ? String(t) : ""
        }

        function w(t) {
            return t.length <= 7 ? t : "rgba(" + parseInt(t.substr(1, 2), 16) + "," + parseInt(t.substr(3, 2), 16) + "," + parseInt(t.substr(5, 2), 16) + "," + Math.round(parseInt(t.substr(7, 2), 16) / 255 * 100) / 100 + ")"
        }
        var P = function() {
                function t(t) {
                    this.chartInfo = t
                }
                var e = t.prototype;
                return e.initData = function() {
                    var t = this._filterOutEmpty(this.chartInfo.getSeriesCat(), this.chartInfo.calcSeriesData()),
                        e = t.category,
                        n = t.data;
                    this._category = this._processCategory(e), this._data = this._processData(n)
                }, e._getNullValue = function() {
                    return null
                }, e._filterOutEmpty = function(t, e) {
                    e = e.filter((function(t) {
                        return t.data.some((function(t) {
                            return v(t)
                        }))
                    }));
                    var n = new Array(t.length).fill(!0).map((function(n, r) {
                            return !S(t[r]) || e.some((function(t) {
                                return v(t.data[r])
                            }))
                        })),
                        r = function(t, e) {
                            return n[e]
                        };
                    return t = t.filter(r), e.forEach((function(t) {
                        return t.data = t.data.filter(r)
                    })), {
                        category: t,
                        data: e
                    }
                }, e._processCategory = function(t) {
                    for (var e = 0, n = t.length; e < n; e++) S(t[e]) && (t[e] = "");
                    return t
                }, e._processData = function(t) {
                    for (var e = this._getNullValue(), n = 0, r = t.length; n < r; n++) {
                        for (var i = t[n].data, o = 0, s = i.length; o < s; o++) v(i[o]) || (i[o] = e);
                        t[n].name = this._uniquifyName(t[n].name, n)
                    }
                    return t
                }, e._calcPlotBound = function() {
                    var t = this.chartInfo.ensurePlotArea().ensureLayout();
                    return t.getEnabled() ? {
                        top: (t.getTop() || 0) * A.cm2pxMultiplier,
                        left: (t.getLeft() || 0) * A.cm2pxMultiplier,
                        right: (t.getRight() || 0) * A.cm2pxMultiplier,
                        bottom: (t.getBottom() || 0) * A.cm2pxMultiplier
                    } : this.chartInfo.calcPlotBound()
                }, e.convert = function(t, e) {
                    return this._containerWidth = t || 560, this._containerHeight = e || 410, this._plotBound = this._calcPlotBound(), {
                        title: this.convertTitle(),
                        legend: this.convertLegend(),
                        series: this.convertSeries(),
                        color: this.convertColor(),
                        backgroundColor: this.convertBackground(),
                        textStyle: this.convertTextStyle(this.chartInfo.ensureGlobalTextStyle()),
                        tooltip: this.convertTooltip(),
                        animation: !1
                    }
                }, e.convertTitle = function() {
                    var t = {
                            top: A.padding.top,
                            left: "center",
                            itemGap: A.titleGap
                        },
                        e = this.chartInfo.ensureChartTitle();
                    e && !e.getHidden() && Object.assign(t, {
                        text: e.getText(),
                        textStyle: this.convertTextStyle(e.ensureTextStyle())
                    });
                    var n = this.chartInfo.ensureChartSubtitle();
                    return n && !n.getHidden() && Object.assign(t, {
                        subtext: n.getText(),
                        subtextStyle: this.convertTextStyle(n.ensureTextStyle())
                    }), t
                }, e.convertLegend = function() {
                    var t = this.chartInfo.ensureChartLegend();
                    if (t.getHidden()) return {
                        show: !1
                    };
                    var e = {
                        selectedMode: !1,
                        itemWidth: 12,
                        itemHeight: 12,
                        padding: 0,
                        formatter: this._getOriginName
                    };
                    switch (t.getPosition()) {
                        case "t":
                            var n = t.ensureTextStyle().getFontSize() || this.chartInfo.ensureGlobalTextStyle().getFontSize();
                            e.top = this._plotBound.top - A.plotGap - m(n), e.orient = "horizontal";
                            break;
                        case "b":
                            e.bottom = A.padding.bottom, e.orient = "horizontal";
                            break;
                        case "l":
                            e.top = this._plotBound.top, e.right = this._containerWidth - this._plotBound.left + A.plotGap, e.orient = "vertical";
                            break;
                        default:
                            e.top = this._plotBound.top, e.left = this._containerWidth - this._plotBound.right + A.plotGap, e.orient = "vertical"
                    }
                    return e.textStyle = this.convertTextStyle(t.ensureTextStyle()), e.data = this._convertLegendIcon(), e
                }, e._convertLegendIcon = function() {
                    return this._data.map((function(t) {
                        return {
                            name: t.name,
                            icon: "rect"
                        }
                    }))
                }, e.convertSeries = function() {
                    var t = this;
                    return this._data.map((function(e, n) {
                        return t._convertSeries(t.chartInfo.ensureSeries(n), e)
                    }))
                }, e._convertSeries = function(t, e) {
                    var n = {
                            name: e.name,
                            data: e.data,
                            emphasis: this._convertSeriesEmphasis(),
                            tooltip: {
                                formatter: this._convertSeriesTooltipFormatter(t)
                            }
                        },
                        r = t.ensureLabel();
                    return r.getHidden() || (n.label = this._convertSeriesLabel(r, t)), n
                }, e._convertSeriesEmphasis = function() {
                    return {
                        itemStyle: {
                            shadowColor: "rgba(0,0,0,0.5)",
                            shadowBlur: 6,
                            shadowOffsetY: 2
                        }
                    }
                }, e._convertSeriesLabel = function(t, e) {
                    var n = Object.assign({
                        show: !0,
                        position: this._switchSeriesLabelPosition(t, e),
                        textBorderWidth: 3
                    }, this.convertTextStyle(t.ensureTextStyle()));
                    return n.textBorderColor = n.position.startsWith("inside") ? "auto" : this.chartInfo.ensureChart().getBackgroundColor(), n
                }, e._switchSeriesLabelPosition = function(t) {
                    var e = "top";
                    switch (t.getPosition()) {
                        case "r":
                            e = "right";
                            break;
                        case "b":
                            e = "bottom";
                            break;
                        case "l":
                            e = "left"
                    }
                    return e
                }, e.convertColor = function() {
                    var t = this,
                        e = this.chartInfo.getSeriesThemeColors();
                    return this._data.map((function(n, r) {
                        return t.chartInfo.getSeriesColor(r) || e[r % e.length]
                    }))
                }, e.convertBackground = function() {
                    return w(this.chartInfo.ensureChart().getBackgroundColor())
                }, e.convertTextStyle = function(t) {
                    return {
                        fontFamily: t.getFontFamily(),
                        fontSize: t.getFontSize(),
                        fontStyle: t.getItalic() ? "italic" : "normal",
                        fontWeight: t.getBold() ? "bold" : "normal",
                        color: t.getColor()
                    }
                }, e.convertTooltip = function() {
                    return {
                        show: !0,
                        position: "top",
                        transitionDuration: 0,
                        padding: [4, 12],
                        backgroundColor: "#606264",
                        borderWidth: 1,
                        borderColor: "#FFF",
                        extraCssText: "box-shadow: 0 1px 4px rgba(0,0,0,0.1); border-radius: 3px;"
                    }
                }, e._convertSeriesTooltipFormatter = function(t) {
                    var e = this;
                    return function(n) {
                        var r = "";
                        n.name && (r += '<span class="syno-o-chart-tooltip-category">' + n.name + "</span><br>"), r += '<span class="syno-o-chart-tooltip-icon" style="background-color: ' + n.color + '"></span>';
                        var i = e._getOriginName(n.seriesName);
                        return r += '<span class="syno-o-chart-tooltip-series">' + (i ? i + ": " : "") + e._tooltipValueFormatter(n.value, t.getRightAxis() ? "y2" : "y1") + "</span>"
                    }
                }, e._tooltipValueFormatter = function(t, e) {
                    return this._dataFormatter(t, e)
                }, e._dataFormatter = function(t, e) {
                    return b(this.chartInfo.dataFormatter) ? this.chartInfo.dataFormatter(t, e) : t
                }, e._uniquifyName = function(t, e) {
                    return (1e3 + e).toString().substr(1) + t
                }, e._getOriginName = function(t) {
                    return t.substr(3)
                }, t
            }(),
            R = function(t) {
                function e(e) {
                    var n, r = (n = t.call(this, e) || this).chartInfo.calcAxisBias();
                    return n._useAxis = [r <= 0, r >= 0], n
                }
                s()(e, t);
                var n = e.prototype;
                return n._getGridSpace = function(t) {
                    return t && t.getText() ? m(t.ensureTextStyle().getFontSize() || this.chartInfo.ensureGlobalTextStyle().getFontSize()) + 12 : 0
                }, n._calcGridBound = function() {
                    var t = this._plotBound,
                        e = t.top,
                        n = t.left,
                        r = t.right,
                        i = t.bottom;
                    return i += this._getGridSpace(this.chartInfo.ensureXAxis().ensureTitle()), {
                        top: e,
                        left: n += this._getGridSpace(this._useAxis[0] && this.chartInfo.ensureYAxis().ensureTitle()),
                        right: r += this._getGridSpace(this._useAxis[1] && this.chartInfo.ensureYAxis2().ensureTitle()),
                        bottom: i
                    }
                }, n.convert = function(e, n) {
                    var r = t.prototype.convert.call(this, e, n);
                    return r.grid = this.convertGrid(), r.xAxis = this.convertXaxis(!1), r.yAxis = this.convertYaxis(!0), r
                }, n.convertGrid = function() {
                    return Object.assign({
                        containLabel: !0
                    }, this._calcGridBound())
                }, n.convertXaxis = function(t) {
                    return this.convertCategoryAxis(this.chartInfo.ensureXAxis(), t)
                }, n.convertYaxis = function(t) {
                    var e = this;
                    return [this.chartInfo.ensureYAxis(), this.chartInfo.ensureYAxis2()].map((function(n, r) {
                        return e.convertValueAxis(e._useAxis[r] && n, t, "y" + (r + 1))
                    }))
                }, n.convertCategoryAxis = function(t, e) {
                    return Object.assign({
                        type: "category",
                        data: this._category,
                        inverse: t.ensureScaling().getRevert()
                    }, this.convertAxis(t, e))
                }, n.convertValueAxis = function(t, e, n) {
                    var r = this;
                    if (!t) return {
                        show: !1
                    };
                    var i = Object.assign({
                        splitNumber: t.getTickNumber(),
                        scale: !0
                    }, this.convertAxis(t, e), this.convertAxisScale(t.ensureScaling()));
                    return !1 !== i.axisLabel.show && (i.axisLabel.formatter = function(t) {
                        return r._dataFormatter(t, n)
                    }), i
                }, n.convertAxisScale = function(t) {
                    return {
                        type: t.getLog() && this.chartInfo.ensureChart().getGrouping() === c.STANDARD ? "log" : "value",
                        min: t.getMin(),
                        max: t.getMax()
                    }
                }, n.convertAxis = function(t, e) {
                    return Object.assign({
                        axisLine: {
                            show: !1
                        },
                        axisTick: {
                            show: !1
                        },
                        axisLabel: this.convertAxisLabel(t.ensureLabel(), e),
                        splitLine: {
                            lineStyle: this.convertAxisLine(t.ensureMajorGridLines(), e)
                        }
                    }, this.convertAxisTitle(t.ensureTitle(), e))
                }, n.convertAxisLine = function(t, e) {
                    return {
                        color: t.getHidden() ? "transparent" : t.getColor()
                    }
                }, n.convertAxisTitle = function(t, e) {
                    return t && t.getText() && !t.getHidden() ? {
                        name: t.getText(),
                        nameTextStyle: this.convertTextStyle(t.ensureTextStyle()),
                        nameLocation: "center",
                        nameGap: e ? 56 : 28
                    } : {}
                }, n.convertAxisLabel = function(t, e) {
                    return !t || t.getHidden() ? {
                        show: !1
                    } : Object.assign({
                        show: !0,
                        rotate: t.getRotate(),
                        margin: e ? 12 : 4
                    }, this.convertTextStyle(t.ensureTextStyle()))
                }, n.convertLegend = function() {
                    var e = t.prototype.convertLegend.call(this),
                        n = this.chartInfo.ensureChartLegend().getPosition();
                    return "l" !== n && "r" !== n || (e.top = this._plotBound.top), e
                }, n._convertSeries = function(e, n) {
                    var r = this,
                        i = t.prototype._convertSeries.call(this, e, n);
                    return e.getRightAxis() && (i.yAxisIndex = 1), i.label && (i.label.formatter = function(t) {
                        return r._labelValueFormmater(t.value, e.getRightAxis() ? "y2" : "y1")
                    }), i
                }, n._labelValueFormmater = function(t, e) {
                    return this._dataFormatter(t, e)
                }, e
            }(P),
            I = function(t) {
                function e(e) {
                    var n;
                    return (n = t.call(this, e) || this).stacked = n.chartInfo.ensureChart().getGrouping() === c.STACKED, n
                }
                s()(e, t);
                var n = e.prototype;
                return n._getNullValue = function() {
                    return this.stacked ? 0 : null
                }, n.convertValueAxis = function(e, n, r) {
                    var i = t.prototype.convertValueAxis.call(this, e, n, r);
                    return this.stacked && i.scale && (i.scale = !1), i
                }, n._convertSeries = function(e, n) {
                    var r = t.prototype._convertSeries.call(this, e, n);
                    return this.stacked && (r.stack = e.getRightAxis() ? "s0" : "s1"), r
                }, e
            }(R),
            B = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n._convertSeries = function(n, r) {
                    var i = t.prototype._convertSeries.call(this, n, r);
                    return e.fillSeriesOption(i, this.chartInfo, n, r)
                }, n._convertLegendIcon = function() {
                    var n = this,
                        r = t.prototype._convertLegendIcon.call(this);
                    return r.forEach((function(t, r) {
                        t.icon = e.switchLegendIcon(n.chartInfo.ensureSeries(r).ensureMarker().getSymbol())
                    })), r
                }, e.fillSeriesOption = function(t, n, r, i) {
                    t.type = "line";
                    var o = r.ensureMarker();
                    t.symbol = e.switchSeriesMarker(o.getSymbol()), t.symbolSize = o.getSize();
                    var s = r.ensureLineStyle(),
                        u = s.getType();
                    switch (u) {
                        case "dot":
                            u = "dotted";
                            break;
                        case "dash":
                            u = "dashed";
                            break;
                        default:
                            u = "solid"
                    }
                    return t.lineStyle = {
                        type: u,
                        width: s.getWidth()
                    }, r.getSmooth() && (t.smooth = !0), n.ensurePlotArea().getBlankAs() === y.SPAN && (t.connectNulls = !0), t
                }, e.switchSeriesMarker = function(t) {
                    var e;
                    switch (t) {
                        case f.NONE:
                            e = "image://data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=";
                            break;
                        case f.DIAMOND:
                            e = "diamond";
                            break;
                        case f.TRIANGLE:
                            e = "triangle";
                            break;
                        case f.SQUARE:
                            e = "rect";
                            break;
                        default:
                            e = "circle"
                    }
                    return e
                }, e.switchLegendIcon = function(t) {
                    var e = "line";
                    switch (t) {
                        case f.CIRCLE:
                            e = "circle";
                            break;
                        case f.DIAMOND:
                            e = "diamond";
                            break;
                        case f.TRIANGLE:
                            e = "triangle";
                            break;
                        case f.SQUARE:
                            e = "rect"
                    }
                    return e
                }, e
            }(I),
            D = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                return s()(e, t), e.prototype._convertSeries = function(e, n) {
                    var r = t.prototype._convertSeries.call(this, e, n);
                    return r.areaStyle = {
                        opacity: e.getOpacity()
                    }, r
                }, e
            }(B),
            F = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.convertXaxis = function(e) {
                    return this.chartInfo.ensureChart().getBarDir() === u.BAR_DIR ? t.prototype.convertXaxis.call(this, e) : t.prototype.convertYaxis.call(this, e)
                }, n.convertYaxis = function(e) {
                    return this.chartInfo.ensureChart().getBarDir() === u.BAR_DIR ? t.prototype.convertYaxis.call(this, e) : t.prototype.convertXaxis.call(this, e)
                }, n._convertSeries = function(n, r) {
                    var i = t.prototype._convertSeries.call(this, n, r);
                    return this.chartInfo.ensureChart().getBarDir() !== u.BAR_DIR && i.yAxisIndex && (i.xAxisIndex = i.yAxisIndex, delete i.yAxisIndex), e.fillSeriesOption(i, this.chartInfo, n, r)
                }, n._switchSeriesLabelPosition = function(t) {
                    var e = this.chartInfo.ensureChart().getBarDir() !== u.BAR_DIR,
                        n = e ? "right" : "top";
                    switch (t.getPosition()) {
                        case "inBase":
                            n = e ? "insideLeft" : "insideBottom";
                            break;
                        case "inCenter":
                            n = "inside";
                            break;
                        case "inEnd":
                            n = e ? "insideRight" : "insideTop"
                    }
                    return n
                }, e.fillSeriesOption = function(t) {
                    return t.type = "bar", t
                }, e
            }(I),
            k = function(t) {
                function e(e) {
                    return t.call(this, e) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n._processCategory = function(e) {
                    for (var n = 0, r = (e = t.prototype._processCategory.call(this, e)).length; n < r; n++) e[n] = this._uniquifyName(e[n], n);
                    return e
                }, n._processData = function(t) {
                    t.length = 1;
                    for (var e = t[0].data, n = 0, r = e.length; n < r; n++) {
                        var i = e[n];
                        e[n] = {
                            value: null == i ? null : Math.abs(i),
                            name: this._category[n]
                        }
                    }
                    return t
                }, n.convertColor = function() {
                    for (var t = this.chartInfo.getSeriesThemeColors(), e = t.length, n = this.chartInfo.ensurePieSeries().getPieColor(), r = [], i = 0, o = this._data[0].data.length; i < o; i++) r[i] = n && n[i] || t[i % e];
                    return r
                }, n._convertLegendIcon = function() {
                    return this._category.map((function(t) {
                        return {
                            name: t,
                            icon: "rect"
                        }
                    }))
                }, n.convertSeries = function() {
                    return [this._convertSeries(this.chartInfo.ensurePieSeries(), this._data[0])]
                }, n._convertSeries = function(t, e) {
                    var n = this._containerWidth - this._plotBound.left - this._plotBound.right,
                        r = this._containerHeight - this._plotBound.top - this._plotBound.bottom,
                        i = Math.min(n, r) / 2;
                    return {
                        type: "pie",
                        data: e.data,
                        emphasis: this._convertSeriesEmphasis(),
                        selectedMode: !1,
                        center: [this._plotBound.left + n / 2, this._plotBound.top + r / 2],
                        radius: [t.getPieHoleSize() / 100 * i, i],
                        itemStyle: {
                            borderColor: w(t.getPieBorderColor())
                        },
                        tooltip: {
                            formatter: this._convertSeriesTooltipFormatter(t)
                        },
                        label: this._convertSeriesLabel(t.ensureLabel())
                    }
                }, n._convertSeriesLabel = function(t) {
                    var e = this;
                    return Object.assign({
                        show: t.getShowCat() || t.getShowVal() || t.getShowPercent(),
                        formatter: function(n) {
                            var r = [];
                            return t.getShowCat() && r.push(e._getOriginName(n.name)), t.getShowVal() && r.push(e._dataFormatter(n.value, "y1")), t.getShowPercent() && r.push(r.length ? "(" + n.percent + "%)" : n.percent + "%"), r.join(" ")
                        }
                    }, this.convertTextStyle(t.ensureTextStyle()))
                }, n._convertSeriesTooltipFormatter = function() {
                    var t = this;
                    return function(e) {
                        var n = "",
                            r = t._getOriginName(e.name);
                        return r && (n += '<span class="syno-o-chart-tooltip-category">' + r + "</span><br>"), n += '<span class="syno-o-chart-tooltip-icon" style="background-color: ' + e.color + '"></span>', n += '<span class="syno-o-chart-tooltip-series">' + t._tooltipValueFormatter(e.value, "y1") + "</span>"
                    }
                }, e
            }(P),
            E = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n._processCategory = function(e) {
                    if (this._xHasNumber = !1, this.chartInfo.ensureXAxis().getTreatAsText()) return t.prototype._processCategory.call(this, e);
                    for (var n = 0, r = e.length; n < r; n++) v(e[n]) ? this._xHasNumber = !0 : e[n] = null;
                    return e
                }, n.convertXaxis = function() {
                    var e = this.chartInfo.ensureXAxis();
                    return e.getTreatAsText() ? t.prototype.convertXaxis.call(this) : this.convertValueAxis(e, !1, "x")
                }, n._convertSeries = function(e, n) {
                    var r = this,
                        i = t.prototype._convertSeries.call(this, e, n);
                    i.type = "scatter", this.chartInfo.ensureXAxis().getTreatAsText() || (i.data = i.data.map((function(t, e) {
                        return r._xHasNumber ? [r._category[e], t] : [e, t]
                    })));
                    var o = e.ensureMarker();
                    return i.symbol = B.switchSeriesMarker(o.getSymbol()), i.symbolSize = o.getSize(), i
                }, n._convertLegendIcon = function() {
                    var e = this,
                        n = t.prototype._convertLegendIcon.call(this);
                    return n.forEach((function(t, n) {
                        var r = B.switchLegendIcon(e.chartInfo.ensureSeries(n).ensureMarker().getSymbol());
                        t.icon = "line" === r ? "rect" : r
                    })), n
                }, n._tooltipValueFormatter = function(t, e) {
                    return Array.isArray(t) ? this._dataFormatter(t[0], "x") + "," + this._dataFormatter(t[1], e) : this._dataFormatter(t, e)
                }, n._labelValueFormmater = function(t, e) {
                    var n = Array.isArray(t) ? t[1] : t;
                    return this._dataFormatter(n, e)
                }, e
            }(R),
            N = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n._convertSeries = function(e, n) {
                    var r = t.prototype._convertSeries.call(this, e, n);
                    return e.getType(!0) === l.BAR ? F.fillSeriesOption(r, this.chartInfo, e, n) : B.fillSeriesOption(r, this.chartInfo, e, n)
                }, n._convertLegendIcon = function() {
                    var e = this,
                        n = t.prototype._convertLegendIcon.call(this);
                    return n.forEach((function(t, n) {
                        var r = e.chartInfo.ensureSeries(n);
                        r.getType() === l.LINE && (t.icon = B.switchLegendIcon(r.ensureMarker().getSymbol()))
                    })), n
                }, n._switchSeriesLabelPosition = function(e, n) {
                    return n.getType() === l.BAR ? F.prototype._switchSeriesLabelPosition.call(this, e, n) : t.prototype._switchSeriesLabelPosition.call(this, e, n)
                }, e
            }(R);
        var O = n(1),
            H = n.n(O),
            M = n(2),
            G = n.n(M),
            z = Object.prototype.hasOwnProperty;

        function j(t, e) {
            for (var n = Math.max(t ? t.length : 0, e ? e.length : 0), r = 0; r < n; ++r)
                if ((t && t[r]) != (e && e[r])) return !1;
            return !0
        }
        var U = function() {
                function t(t, e) {
                    this.fillArgs.apply(this, arguments), e && this.initSubConfig(e)
                }
                var e = t.prototype;
                return e.fillArgs = function(t, e) {
                    this._info = t, this._config = e
                }, t.createSupportMap = function() {
                    var t, e = Object.create(null);
                    return (t = this.configList) && t.forEach((function(t) {
                        e[t] = !0
                    })), (t = this.subConfigList) && t.forEach((function(t) {
                        e[t] = !0
                    })), e
                }, e.initSubConfig = function(t) {
                    var e = this.constructor.subConfigList;
                    if (e)
                        for (var n = 0, r = e.length; n < r; ++n) {
                            var i = e[n],
                                o = t[i];
                            if (C(o)) {
                                var s = "ensure" + T(i);
                                (this["_" + s] || this[s]).call(this, o)
                            }
                        }
                }, e._cloneConfig = function(t) {
                    return Object.assign(Object.create(null), t)
                }, e._getConfig = function(t, e, n, r) {
                    return t && C(t[e]) ? t[e] : r || null == n ? null : n
                }, e._setConfig = function(t, e, n) {
                    return C(n) ? t && t[e] === n || ((t = this._cloneConfig(t))[e] = n) : t && !(e in t) || delete(t = this._cloneConfig(t))[e], t
                }, e.build = function() {
                    var t, e = this.getRawConfig(),
                        n = this.constructor.supportMap;
                    for (var r in e)
                        if (z.call(e, r)) {
                            if (n[r]) continue;
                            t || (t = this._cloneConfig(e)), delete t[r]
                        } var i = this.constructor.subConfigList;
                    if (i && i.length)
                        for (var o = 0, s = i.length; o < s; ++o) {
                            var u = i[o],
                                a = this["get" + T(u)](),
                                l = void 0,
                                c = Array.isArray(a);
                            c ? (l = L(a.map((function(t) {
                                return t && t.build()
                            })))).length || (l = null) : l = a && a.build(), (e && u in e ? l && (c ? j(l, e[u]) : l === e[u]) : !l) || (t || (t = this._cloneConfig(e)), l ? t[u] = l : delete t[u])
                        }
                    return t && (e = t), e && ! function(t) {
                        for (var e in t)
                            if (Object.prototype.hasOwnProperty.call(t, e)) return !0;
                        return !1
                    }(e) && (e = null), this.setRawConfig(e), e
                }, e.compute = function(t) {
                    var e, n = Object.create(null);
                    if ((e = this.constructor.subConfigList) && e.length)
                        for (var r = 0, i = e.length; r < i; ++r) {
                            var o = e[r],
                                s = T(o),
                                u = "ensure" + s,
                                a = this[u](),
                                l = void 0;
                            if (Array.isArray(a)) {
                                var c = this["get" + s + "Count"],
                                    h = c ? c.call(this) : a.length;
                                l = [];
                                for (var f = 0; f < h; ++f) l.push(this[u](f).compute(t))
                            } else l = a.compute(t);
                            n[o] = l
                        }
                    if ((e = this.constructor.configList) && e.length)
                        for (var g = 0, p = e.length; g < p; ++g) {
                            var d = e[g],
                                y = this["get" + T(d)];
                            if (y) {
                                var S = y.call(this);
                                null != S && (n[d] = S)
                            }
                        }
                    return n
                }, e.cloneRawConfig = function() {
                    return Object.assign(Object.create(null), this.getRawConfig())
                }, e.getRawConfig = function() {
                    return this._config
                }, e.setRawConfig = function(t) {
                    return this._config !== t && (this._config = t, !0)
                }, e.getChartInfo = function() {
                    return this._info
                }, e.getSubConfig = function(t) {
                    return this[t]
                }, e.setSubConfig = function(t, e, n) {
                    return n || (e = this.createSubConfig(t, e)), this[t] = e
                }, e.createSubConfig = function(t, e) {
                    var n = this.getChartInfo(),
                        r = n.getConfigCls(t);
                    if (!r) throw new Error("Unknow sub-config name. (" + t + ")");
                    return e[0] !== n && (e = [n].concat(e)), G()(r, e)
                }, e.getConfig = function(t, e, n) {
                    return this._getConfig(this.getRawConfig(), t, e, n)
                }, e.setConfig = function(t, e) {
                    return this.setRawConfig(this._setConfig(this.getRawConfig(), t, e))
                }, H()(t, null, [{
                    key: "configName",
                    get: function() {
                        return ""
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return null
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return null
                    }
                }, {
                    key: "supportMap",
                    get: function() {
                        return z.call(this, "_supportMap") || (this._supportMap = this.createSupportMap()), this._supportMap
                    }
                }]), t
            }(),
            V = ["xAxis", "yAxis", "yAxis2", "series", "layout"],
            Y = ["blankAs", "useRowHeader", "useColumnHeader", "switchRowColumn"],
            W = ["plotArea", "title", "subtitle", "legend", "textStyle"],
            X = ["backgroundColor", "chartType", "barDir", "grouping"];

        function q(t, e) {
            return t.index - e.index
        }
        var K = ["min", "max", "orientation", "logBase"],
            Q = ["hidden", "color"],
            Z = ["title", "label", "scaling", "majorGridLines"],
            J = ["tickNumber", "treatAsText"],
            $ = ["symbol", "size"],
            tt = ["type", "width"],
            et = ["label", "marker", "lineStyle"],
            nt = ["type", "color", "axis2", "smooth", "opacity", "holeSize", "pieColors", "pieBorderColor"],
            rt = ["textStyle"],
            it = ["hidden", "position"],
            ot = ["textStyle"],
            st = ["hidden", "position", "rotate", "showVal", "showCat", "showPercent"],
            ut = ["textStyle"],
            at = ["hidden", "text"],
            lt = {
                title: {
                    fontSize: 16,
                    bold: !0
                },
                subtitle: {
                    fontSize: 13,
                    color: "#7E8082"
                },
                axisTitle: {
                    bold: !0
                },
                global: {
                    fontFamily: "Arial",
                    fontSize: 12,
                    italic: !1,
                    bold: !1,
                    color: "#000000"
                }
            },
            ct = ["fontFamily", "fontSize", "italic", "bold", "color"],
            ht = ["enabled", "top", "left", "right", "bottom"],
            ft = [function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.initSubConfig = function(e) {
                    t.prototype.initSubConfig.call(this, this.fixConfig(e))
                }, n.fixConfig = function(t) {
                    var e = t,
                        n = e.nonNumericAsZero,
                        r = e.zeroStart,
                        i = e.xAxisTitle,
                        o = e.yAxisTitle;
                    if (!(C(n) || r || i || o)) return t;
                    if (delete(t = this._cloneConfig(t)).nonNumericAsZero, delete t.zeroStart, delete t.xAxisTitle, delete t.yAxisTitle, !t.blankAs && C(n) && (t.blankAs = n ? y.ZERO : y.GAP), !t.xAxis && (i || r)) {
                        var s = t.xAxis = Object.create(null);
                        i && (s.title = i), r && (s.scaling = {
                            min: 0
                        })
                    }
                    if (!t.yAxis && (o || r)) {
                        var u = t.yAxis = Object.create(null);
                        o && (u.title = o), r && (u.scaling = {
                            min: 0
                        })
                    }
                    return !t.yAxis2 && r && (t.yAxis2 = {
                        scaling: {
                            min: 0
                        }
                    }), t
                }, n.getXAxis = function() {
                    return this.getSubConfig("xAxis")
                }, n.ensureXAxis = function(t) {
                    return this.getXAxis() || this.setSubConfig("xAxis", this.createSubConfig("axis", [t]), !0)
                }, n.getYAxis = function() {
                    return this.getSubConfig("yAxis")
                }, n.ensureYAxis = function(t) {
                    return this.getYAxis() || this.setSubConfig("yAxis", this.createSubConfig("axis", [t]), !0)
                }, n.getYAxis2 = function() {
                    return this.getSubConfig("yAxis2")
                }, n.ensureYAxis2 = function(t) {
                    return this.getYAxis2() || this.setSubConfig("yAxis2", this.createSubConfig("axis", [t]), !0)
                }, n._getSeries = function() {
                    return this.getSubConfig("series")
                }, n._ensureSeries = function(t) {
                    var e = this;
                    return this._getSeries() || this.setSubConfig("series", Array.isArray(t) ? t.map((function(t, n) {
                        return e.createSubConfig("series", [t, n])
                    })) : [], !0)
                }, n.getSeries = function(t) {
                    var e = this._getSeries();
                    return e ? v(t) ? e[t] : e : null
                }, n.ensureSeries = function(t, e) {
                    var n = this._ensureSeries();
                    return v(t) ? n[t] || (n[t] = this.createSubConfig("series", [e, t])) : n
                }, n.getSeriesCount = function() {
                    return this.getChartInfo().getSeriesCount()
                }, n.getLayout = function() {
                    return this.getSubConfig("layout")
                }, n.ensureLayout = function(t) {
                    return this.getLayout() || this.setSubConfig("layout", this.createSubConfig("layout", [t]), !0)
                }, n.getBlankAs = function(t) {
                    return this.getConfig("blankAs", u.BLANK_AS, t)
                }, n.setBlankAs = function(t) {
                    return this.setConfig("blankAs", t)
                }, n.getUseRowHeader = function() {
                    return this.getConfig("useRowHeader", !0)
                }, n.setUseRowHeader = function(t) {
                    return this.setConfig("useRowHeader", !!t)
                }, n.getUseColumnHeader = function() {
                    return this.getConfig("useColumnHeader", !0)
                }, n.setUseColumnHeader = function(t) {
                    return this.setConfig("useColumnHeader", !!t)
                }, n.getSwitchRowColumn = function() {
                    return this.getConfig("switchRowColumn", !1)
                }, n.setSwitchRowColumn = function(t) {
                    return this.setConfig("switchRowColumn", !!t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "plotArea"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return V
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return Y
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.initSubConfig = function(e) {
                    t.prototype.initSubConfig.call(this, this.fixConfig(e))
                }, n.fixConfig = function(t) {
                    var e = t.plotArea;
                    if (!e || e.series) return t;
                    var n = e.subCharts;
                    if (!n || !n.length) return t;
                    delete(e = (t = this._cloneConfig(t)).plotArea = this._cloneConfig(e)).subCharts;
                    for (var r = e.series = [], i = 0, o = n.length; i < o; ++i) {
                        for (var s = n[i], u = s.type, a = s.series, l = s.barDir, c = s.grouping, h = 0, f = a.length; h < f; ++h) {
                            var g = this._cloneConfig(a[h]);
                            g.type = u, r.push(g)
                        }
                        l && (t.barDir = l), c && (t.grouping = c)
                    }
                    return r.sort(q), t.chartType = n.length > 1 ? "hybrid" : n[0].type, t
                }, n.getPlotArea = function() {
                    return this.getSubConfig("plotArea")
                }, n.ensurePlotArea = function(t) {
                    return this.getPlotArea() || this.setSubConfig("plotArea", [t])
                }, n.getTitle = function() {
                    return this.getSubConfig("title")
                }, n.ensureTitle = function(t) {
                    return this.getTitle() || this.setSubConfig("title", [t, "title"])
                }, n.getSubtitle = function() {
                    return this.getSubConfig("subtitle")
                }, n.ensureSubtitle = function(t) {
                    return this.getSubtitle() || this.setSubConfig("subtitle", this.createSubConfig("title", [t, "subtitle"]), !0)
                }, n.getLegend = function() {
                    return this.getSubConfig("legend")
                }, n.ensureLegend = function(t) {
                    return this.getLegend() || this.setSubConfig("legend", [t])
                }, n.getTextStyle = function() {
                    return this.getSubConfig("textStyle")
                }, n.ensureTextStyle = function(t) {
                    return this.getTextStyle() || this.setSubConfig("textStyle", [t, "global"])
                }, n.getBackgroundColor = function(t) {
                    return this.getConfig("backgroundColor", u.BACKGROUND, t)
                }, n.setBackgroundColor = function(t) {
                    return this.setConfig("backgroundColor", t)
                }, n.getChartType = function(t) {
                    return this.getConfig("chartType", u.TYPE, t)
                }, n.setChartType = function(t) {
                    return this.setConfig("chartType", t)
                }, n.getBarDir = function(t) {
                    return this.getConfig("barDir", u.BAR_DIR, t)
                }, n.setBarDir = function(t) {
                    return this.setConfig("barDir", t)
                }, n.getGrouping = function(t) {
                    return this.getConfig("grouping", u.GROUPING, t)
                }, n.setGrouping = function(t) {
                    return this.setConfig("grouping", t)
                }, n.getType = function(t) {
                    return this.getChartType(t)
                }, n.setType = function(t) {
                    return this.setChartType(t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "chart"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return W
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return X
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getMin = function(t) {
                    return this.getConfig("min", null, t)
                }, n.setMin = function(t) {
                    return this.setConfig("min", v(t) ? t : null)
                }, n.getMax = function(t) {
                    return this.getConfig("max", null, t)
                }, n.setMax = function(t) {
                    return this.setConfig("max", v(t) ? t : null)
                }, n.getOrientation = function(t) {
                    return this.getConfig("orientation", u.ORIENTATION, t)
                }, n.setOrientation = function(t) {
                    return this.setConfig("orientation", t)
                }, n.getLogBase = function(t) {
                    return this.getConfig("logBase", null, t)
                }, n.setLogBase = function(t) {
                    return this.setConfig("logBase", v(t) ? t : null)
                }, n.getRevert = function() {
                    return this.getOrientation() === h.REVERSE
                }, n.setRevert = function(t) {
                    return this.setOrientation(t ? h.REVERSE : h.SEQUENCE)
                }, n.getLog = function() {
                    return !!C(this.getLogBase())
                }, n.setLog = function(t) {
                    return this.setLogBase(t ? 10 : null)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "scaling"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return K
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getHidden = function(t) {
                    return this.getConfig("hidden", !1, t)
                }, n.setHidden = function(t) {
                    return this.setConfig("hidden", !!t)
                }, n.getColor = function(t) {
                    return this.getConfig("color", "#CCCCCC", t)
                }, n.setColor = function(t) {
                    return this.setConfig("color", t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "majorGridLines"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return Q
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getTitle = function() {
                    return this.getSubConfig("title")
                }, n.ensureTitle = function(t) {
                    return this.getTitle() || this.setSubConfig("title", [t, "axisTitle"])
                }, n.getLabel = function() {
                    return this.getSubConfig("label")
                }, n.ensureLabel = function(t) {
                    return this.getLabel() || this.setSubConfig("label", [t])
                }, n.getScaling = function() {
                    return this.getSubConfig("scaling")
                }, n.ensureScaling = function(t) {
                    return this.getScaling() || this.setSubConfig("scaling", [t])
                }, n.getMajorGridLines = function() {
                    return this.getSubConfig("majorGridLines")
                }, n.ensureMajorGridLines = function(t) {
                    return this.getMajorGridLines() || this.setSubConfig("majorGridLines", [t])
                }, n.getTickNumber = function(t) {
                    return this.getConfig("tickNumber", 5, t)
                }, n.setTickNumber = function(t) {
                    return this.setConfig("tickNumber", v(t) ? t : null)
                }, n.getTreatAsText = function(t) {
                    return this.getConfig("treatAsText", !1, t)
                }, n.setTreatAsText = function(t) {
                    return this.setConfig("treatAsText", !!t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "axis"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return Z
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return J
                    }
                }]), e
            }(U), function(t) {
                function e(e, n) {
                    return !0 === n ? n = null : !1 === n && (n = {
                        symbol: f.NONE
                    }), t.call(this, e, n) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getSymbol = function(t) {
                    return this.getConfig("symbol", u.MARKER_SYMBOL, t)
                }, n.setSymbol = function(t) {
                    return this.setConfig("symbol", t)
                }, n.getSize = function(t) {
                    return this.getConfig("size", 5, t)
                }, n.setSize = function(t) {
                    return this.setConfig("size", v(t) ? t : null)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "marker"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return $
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getType = function(t) {
                    return this.getConfig("type", u.LINE_DASH, t)
                }, n.setType = function(t) {
                    return this.setConfig("type", t)
                }, n.getWidth = function(t) {
                    return this.getConfig("width", 2, t)
                }, n.setWidth = function(t) {
                    return this.setConfig("width", v(t) ? t : null)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "lineStyle"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return tt
                    }
                }]), e
            }(U), function(t) {
                function e(e, n, r) {
                    var i;
                    return (i = t.call(this, e, n) || this).index = v(r) ? r : 0, i
                }
                s()(e, t);
                var n = e.prototype;
                return n.getDefaultType = function() {
                    var t = this.getChartInfo().ensureChart().getType();
                    return t === l.HYBRID ? l.BAR : t
                }, n.getDefaultColor = function(t) {
                    var e = this.getChartInfo().getSeriesThemeColors();
                    return e[t % e.length]
                }, n.compute = function(e) {
                    var n = t.prototype.compute.call(this, e);
                    if (e) {
                        var r = this.getChartInfo();
                        r.dataHasCat() && (n.cat = r.getSourceSeriesCat()), r.dataHasTx() && (n.tx = r.getSourceSeriesTx(this.index)), n.val = r.getSourceSeriesVal(this.index)
                    }
                    return n
                }, n.getLabel = function() {
                    return this.getSubConfig("label")
                }, n.ensureLabel = function(t) {
                    return this.getLabel() || this.setSubConfig("label", [t])
                }, n.getMarker = function() {
                    return this.getSubConfig("marker")
                }, n.ensureMarker = function(t) {
                    return this.getMarker() || this.setSubConfig("marker", [t])
                }, n.getLineStyle = function() {
                    return this.getSubConfig("lineStyle")
                }, n.ensureLineStyle = function(t) {
                    return this.getLineStyle() || this.setSubConfig("lineStyle", [t])
                }, n.getType = function(t) {
                    var e = this.getConfig("type", null, t);
                    return t || e ? e : this.getDefaultType()
                }, n.setType = function(t) {
                    return this.setConfig("type", t)
                }, n.getColor = function(t) {
                    var e = this.getConfig("color", null, t);
                    return t || e ? e : this.getDefaultColor(this.index)
                }, n.setColor = function(t) {
                    return this.setConfig("color", t)
                }, n.getAxis2 = function(t) {
                    return this.getConfig("axis2", !1, t)
                }, n.setAxis2 = function(t) {
                    return this.setConfig("axis2", !!t)
                }, n.getSmooth = function(t) {
                    return this.getConfig("smooth", !1, t)
                }, n.setSmooth = function(t) {
                    return this.setConfig("smooth", !!t)
                }, n.getOpacity = function(t) {
                    return this.getConfig("opacity", .2, t)
                }, n.setOpacity = function(t) {
                    return this.setConfig("opacity", v(t) ? t : null)
                }, n.getHoleSize = function(t) {
                    return this.getConfig("holeSize", 0, t)
                }, n.setHoleSize = function(t) {
                    return this.setConfig("holeSize", t)
                }, n.getPieColors = function(t) {
                    return this.getConfig("pieColors", null, t)
                }, n.setPieColors = function(t) {
                    return this.setConfig("pieColors", Array.isArray(t) ? L(t, !0) : null)
                }, n.getPieBorderColor = function(t) {
                    return this.getConfig("pieBorderColor", "#FFFFFF00", t)
                }, n.setPieBorderColor = function(t) {
                    return this.setConfig("pieBorderColor", t)
                }, n.getRightAxis = function(t) {
                    return this.getAxis2(t)
                }, n.setRightAxis = function(t) {
                    return this.setAxis2(t)
                }, n.getLineSmooth = function(t) {
                    return this.getSmooth(t)
                }, n.setLineSmooth = function(t) {
                    return this.setSmooth(t)
                }, n.getAreaOpacity = function(t) {
                    return this.getOpacity(t)
                }, n.setAreaOpacity = function(t) {
                    return this.setOpacity(t)
                }, n.getPieHoleSize = function(t) {
                    return this.getHoleSize(t)
                }, n.setPieHoleSize = function(t) {
                    return this.setHoleSize(t)
                }, n.getPieColor = function(t, e) {
                    var n = this.getPieColors(e);
                    return n && Array.isArray(n) ? v(t) ? n[t] || this.getDefaultColor(t) : n : null
                }, n.setPieColor = function(t, e) {
                    if (v(t)) {
                        var n = this.getPieColors();
                        (n = n ? n.slice() : [])[t] = e, e = L(n)
                    }
                    return this.setPieColors(e)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "series"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return et
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return nt
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getTextStyle = function() {
                    return this.getSubConfig("textStyle")
                }, n.ensureTextStyle = function(t) {
                    return this.getTextStyle() || this.setSubConfig("textStyle", [t])
                }, n.getHidden = function(t) {
                    return this.getConfig("hidden", !1, t)
                }, n.setHidden = function(t) {
                    return this.setConfig("hidden", !!t)
                }, n.getPosition = function(t) {
                    return this.getConfig("position", u.LEGEND_POSITION, t)
                }, n.setPosition = function(t) {
                    return this.setConfig("position", t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "legend"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return rt
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return it
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getTextStyle = function() {
                    return this.getSubConfig("textStyle")
                }, n.ensureTextStyle = function(t) {
                    return this.getTextStyle() || this.setSubConfig("textStyle", [t])
                }, n.getHidden = function(t) {
                    return this.getConfig("hidden", !1, t)
                }, n.setHidden = function(t) {
                    return this.setConfig("hidden", !!t)
                }, n.getPosition = function(t) {
                    return this.getConfig("position", u.LABEL_POSITION, t)
                }, n.setPosition = function(t) {
                    return this.setConfig("position", t)
                }, n.getRotate = function(t) {
                    return this.getConfig("rotate", 0, t)
                }, n.setRotate = function(t) {
                    return this.setConfig("rotate", t)
                }, n.getShowVal = function(t) {
                    return this.getConfig("showVal", !1, t)
                }, n.setShowVal = function(t) {
                    return this.setConfig("showVal", !!t)
                }, n.getShowCat = function(t) {
                    return this.getConfig("showCat", !1, t)
                }, n.setShowCat = function(t) {
                    return this.setConfig("showCat", !!t)
                }, n.getShowPercent = function(t) {
                    return this.getConfig("showPercent", !1, t)
                }, n.setShowPercent = function(t) {
                    return this.setConfig("showPercent", !!t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "label"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return ot
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return st
                    }
                }]), e
            }(U), function(t) {
                function e(e, n, r) {
                    return x(n) && (n = {
                        text: n
                    }), t.call(this, e, n, r) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.fillArgs = function(e, n, r) {
                    t.prototype.fillArgs.apply(this, arguments), this.styleKey = r
                }, n.getTextStyle = function() {
                    return this.getSubConfig("textStyle")
                }, n.ensureTextStyle = function(t) {
                    return this.getTextStyle() || this.setSubConfig("textStyle", [t, this.styleKey])
                }, n.getHidden = function(t) {
                    return this.getConfig("hidden", !1, t)
                }, n.setHidden = function(t) {
                    return this.setConfig("hidden", !!t)
                }, n.getText = function(t) {
                    return this.getConfig("text", "", t)
                }, n.setText = function(t) {
                    return this.setConfig("text", t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "title"
                    }
                }, {
                    key: "subConfigList",
                    get: function() {
                        return ut
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return at
                    }
                }]), e
            }(U), function(t) {
                function e(e, n, r) {
                    var i;
                    return (i = t.call(this, e, n) || this).defaultStyle = lt[r], i
                }
                s()(e, t);
                var n = e.prototype;
                return n.getStyleConfig = function(t, e) {
                    var n = this.getConfig(t, null, e);
                    if (e || C(n)) return n;
                    var r = this.defaultStyle && this.defaultStyle[t];
                    return C(r) ? r : this.getChartInfo().ensureGlobalTextStyle()["get" + T(t)]()
                }, n.getFontFamily = function(t) {
                    return this.getStyleConfig("fontFamily", t)
                }, n.setFontFamily = function(t) {
                    return this.setConfig("fontFamily", t)
                }, n.getFontSize = function(t) {
                    return this.getStyleConfig("fontSize", t)
                }, n.setFontSize = function(t) {
                    return this.setConfig("fontSize", t)
                }, n.getItalic = function(t) {
                    return this.getStyleConfig("italic", t)
                }, n.setItalic = function(t) {
                    return this.setConfig("italic", !!t)
                }, n.getBold = function(t) {
                    return this.getStyleConfig("bold", t)
                }, n.setBold = function(t) {
                    return this.setConfig("bold", !!t)
                }, n.getColor = function(t) {
                    return this.getStyleConfig("color", t)
                }, n.setColor = function(t) {
                    return this.setConfig("color", t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "textStyle"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return ct
                    }
                }]), e
            }(U), function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.getEnabled = function(t) {
                    return this.getConfig("enabled", !1, t)
                }, n.setEnabled = function(t) {
                    return this.setConfig("enabled", t)
                }, n.getLeft = function(t) {
                    return this.getConfig("left", null, t)
                }, n.setLeft = function(t) {
                    return this.setConfig("left", t)
                }, n.getTop = function(t) {
                    return this.getConfig("top", null, t)
                }, n.setTop = function(t) {
                    return this.setConfig("top", t)
                }, n.getRight = function(t) {
                    return this.getConfig("right", null, t)
                }, n.setRight = function(t) {
                    return this.setConfig("right", t)
                }, n.getBottom = function(t) {
                    return this.getConfig("bottom", null, t)
                }, n.setBottom = function(t) {
                    return this.setConfig("bottom", t)
                }, H()(e, null, [{
                    key: "configName",
                    get: function() {
                        return "layout"
                    }
                }, {
                    key: "configList",
                    get: function() {
                        return ht
                    }
                }]), e
            }(U)].reduce((function(t, e) {
                return t[e.configName] = e, t
            }), Object.create(null)),
            gt = ["#509BE6", "#FFC100", "#F26166", "#AD70CC", "#4DBF4D", "#FF8F3D", "#8E6F69", "#00B6CE", "#E25FBC", "#4D5FFF", "#27D790", "#3B8795"],
            pt = i.isDefined,
            dt = r.DEFAULT,
            yt = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                s()(e, t);
                var n = e.prototype;
                return n.readOptionCfg = function(t) {
                    this.setRawData(t && t.data || this.constructor.createDefaultData())
                }, n.getData = function(e, n) {
                    if (this.getSwitchRowColumn()) {
                        var r = e;
                        e = n, n = r
                    }
                    return t.prototype.getData.call(this, e, n)
                }, n.getDataRowNumber = function() {
                    return this.getSwitchRowColumn() ? t.prototype.getDataColNumber.call(this) : t.prototype.getDataRowNumber.call(this)
                }, n.getDataColNumber = function() {
                    return this.getSwitchRowColumn() ? t.prototype.getDataRowNumber.call(this) : t.prototype.getDataColNumber.call(this)
                }, e.createDefaultData = function() {
                    return [
                        ["", "Number 1", "Number 2", "Number 3", "Number 4"],
                        ["Category A", 500, 520, 540, 520],
                        ["Category B", 520, 540, 560, 540],
                        ["Category C", 540, 560, 580, 560]
                    ]
                }, e.extractData = function(t, e) {
                    if (!t) return null;
                    var n = new this(t, e).ensureChart(),
                        r = n.getPlotArea();
                    if (!r) return null;
                    var i = r.getSeries();
                    if (!i) return null;
                    var o, s, u, a = i.length;
                    if (0 === a) return null;
                    if (e && (o = e.switchRowColumn, s = e.extractCat, u = e.extractTx), !pt(o) || !pt(s) || !pt(u)) {
                        var l = r.getRawConfig().dataDir;
                        o = !!l && l !== dt.DATA_DIR, s = !1, u = !1;
                        for (var c = 0; c < a; ++c) {
                            var h = i[c];
                            if (pt(h.cat) && (s = !0), pt(h.tx) && (u = !0), s && u) break
                        }
                    }
                    for (var f, g = [], p = s ? 1 : 0, d = u ? 1 : 0, y = 0, S = i.length; y < S; ++y) {
                        var C = i[y];
                        if (C) {
                            if (s && !f) {
                                var b = C.cat;
                                pt(b) && (this._fillDataRow(g, 0, d, this.translateDataValue(b), o), f = !0)
                            }
                            if (u) {
                                var v = C.tx;
                                if (pt(v)) {
                                    var x = this.translateDataValue(v);
                                    Array.isArray(x) && (x = x[0]), this._fillDataRow(g, p + y, 0, x, o)
                                }
                            }
                            var A = C.val;
                            pt(A) && this._fillDataRow(g, p + y, d, this.translateDataValue(A), o)
                        }
                    }
                    return s && u && this._fillDataRow(g, 0, 0, [n.getRawConfig().cornerData || ""]), this.ensureData(g)
                }, e.translateDataValue = function(t) {
                    return t
                }, e._fillDataRow = function(t, e, n, r, i) {
                    if (Array.isArray(r) || (r = [r]), i)
                        for (var o = 0, s = r.length; o < s; ++o) {
                            this._ensureDataRow(t, n + o)[e] = r[o]
                        } else
                            for (var u = this._ensureDataRow(t, e), a = 0, l = r.length; a < l; ++a) u[n + a] = r[a]
                }, e._ensureDataRow = function(t, e) {
                    return t[e] || (t[e] = [])
                }, e.ensureData = function(t) {
                    if (Array.isArray(t) && t.length) {
                        for (var e, n = t.length, r = null, i = 0; i < n; ++i) {
                            var o = void 0;
                            Array.isArray(t[i]) ? o = t[i].length : (o = 0, e = !0), null == r ? r = o : r !== o && (e = !0, r = Math.max(r, o))
                        }
                        if (0 === r) t = null;
                        else if (e) {
                            for (var s = [], u = 0; u < n; ++u) {
                                var a = t[u];
                                if (Array.isArray(a)) {
                                    var l = a.length;
                                    l !== r && ((a = a.slice()).length = r, a.fill("", l))
                                } else a = new Array(r).fill("");
                                s.push(a)
                            }
                            t = s
                        }
                    } else t = null;
                    return t
                }, e.fromNode = function(t) {
                    return this.fromAttrs(t.attrs)
                }, e.fromAttrs = function(t) {
                    return new this(t && t.config, t)
                }, e
            }(function() {
                function t(t, e) {
                    this.readChartCfg(t), this.readOptionCfg(e), this._options = e
                }
                var e = t.prototype;
                return e.getConfigMap = function() {
                    return ft
                }, e.getConfigCls = function(t) {
                    return this.getConfigMap()[t]
                }, e.readChartCfg = function(t) {
                    this._config = new(this.getConfigCls("chart"))(this, t)
                }, e.readOptionCfg = function(t) {}, e.getUseRowHeader = function() {
                    return this.ensurePlotArea().getUseRowHeader()
                }, e.getUseColumnHeader = function() {
                    return this.ensurePlotArea().getUseColumnHeader()
                }, e.getSwitchRowColumn = function() {
                    return this.ensurePlotArea().getSwitchRowColumn()
                }, e.dataHasCat = function() {
                    return this.getSwitchRowColumn() ? this.getUseColumnHeader() : this.getUseRowHeader()
                }, e.dataHasTx = function() {
                    return this.getSwitchRowColumn() ? this.getUseRowHeader() : this.getUseColumnHeader()
                }, e.setRawData = function(t) {
                    this.data = t
                }, e.getRawData = function() {
                    return this.data
                }, e.cloneRawData = function(t) {
                    var e = this.getRawData();
                    if (!e) return e;
                    if (t) {
                        for (var n = [], r = this._getDataColNumber(e), i = this._getDataRowNumber(e), o = 0; o < r; ++o) {
                            n[o] = [];
                            for (var s = 0; s < i; ++s) n[o][s] = this._getData(e, s, o)
                        }
                        return n
                    }
                    return e.map((function(t) {
                        return t.slice()
                    }))
                }, e._getData = function(t, e, n) {
                    var r = t && t[e] && t[e][n];
                    return null != r ? r : null
                }, e.getData = function(t, e) {
                    return this._getData(this.getRawData(), t, e)
                }, e._getDataRowNumber = function(t) {
                    return t ? t.length : 0
                }, e.getDataRowNumber = function() {
                    return this._getDataRowNumber(this.getRawData())
                }, e._getDataColNumber = function(t) {
                    return t && t[0] ? t[0].length : 0
                }, e.getDataColNumber = function() {
                    return this._getDataColNumber(this.getRawData())
                }, e.ensureChart = function() {
                    return this._config
                }, e.ensureChartTitle = function() {
                    return this.ensureChart().ensureTitle()
                }, e.ensureChartSubtitle = function() {
                    return this.ensureChart().ensureSubtitle()
                }, e.ensureChartLegend = function() {
                    return this.ensureChart().ensureLegend()
                }, e.ensureChartLegendStyle = function() {
                    return this.ensureChartLegend().ensureTextStyle()
                }, e.ensureGlobalTextStyle = function() {
                    return this.ensureChart().ensureTextStyle()
                }, e.ensurePlotArea = function() {
                    return this.ensureChart().ensurePlotArea()
                }, e.ensureSeries = function(t) {
                    return this.ensurePlotArea().ensureSeries(t)
                }, e.ensureSeriesLabel = function(t) {
                    return this.ensureSeries(t).ensureLabel()
                }, e.ensureSeriesLabelStyle = function(t) {
                    return this.ensureSeriesLabel(t).ensureTextStyle()
                }, e.ensurePieSeries = function() {
                    return this.ensureSeries(0)
                }, e.ensurePieLabel = function() {
                    return this.ensurePieSeries().ensureLabel()
                }, e.ensurePieLabelStyle = function() {
                    return this.ensurePieLabel().ensureTextStyle()
                }, e.ensureTitle = function(t) {
                    switch (t) {
                        case "title":
                            return this.ensureChartTitle();
                        case "subtitle":
                            return this.ensureChartSubtitle();
                        case "xTitle":
                            return this.ensureXAxis().ensureTitle();
                        case "yTitle":
                            return this.ensureYAxis().ensureTitle();
                        case "y2Title":
                            return this.ensureYAxis2().ensureTitle();
                        default:
                            return null
                    }
                }, e.ensureTitleStyle = function(t) {
                    var e = this.ensureTitle(t);
                    return e && e.ensureTextStyle()
                }, e.ensureXAxis = function() {
                    return this.ensurePlotArea().ensureXAxis()
                }, e.ensureYAxis = function() {
                    return this.ensurePlotArea().ensureYAxis()
                }, e.ensureYAxis2 = function() {
                    return this.ensurePlotArea().ensureYAxis2()
                }, e.ensureAxis = function(t) {
                    switch (t) {
                        case "x":
                            return this.ensureXAxis();
                        case "y":
                            return this.ensureYAxis();
                        case "y2":
                            return this.ensureYAxis2();
                        default:
                            return null
                    }
                }, e.ensureAxisScaling = function(t) {
                    var e = this.ensureAxis(t);
                    return e && e.ensureScaling()
                }, e.ensureAxisMajorGridLines = function(t) {
                    var e = this.ensureAxis(t);
                    return e && e.ensureMajorGridLines()
                }, e.ensureAxisLabel = function(t) {
                    var e = this.ensureAxis(t);
                    return e && e.ensureLabel()
                }, e.ensureAxisLabelStyle = function(t) {
                    var e = this.ensureAxisLabel(t);
                    return e && e.ensureTextStyle()
                }, e.build = function() {
                    return this.ensureChart().build()
                }, e.compute = function(t) {
                    return this.ensureChart().compute(t)
                }, e.getChartSetting = function() {
                    var t = this.ensureChart();
                    return this.filterChartSetting(t.getType(), t.getBarDir(), t.getGrouping(), !0)
                }, e.getSeriesCat = function(t) {
                    var e = this.dataHasTx() ? 1 : 0;
                    if (v(t)) return this.dataHasCat() ? _(this.getData(0, e + t)) : "";
                    var n = this.getDataColNumber(),
                        r = new Array(n - e);
                    if (this.dataHasCat())
                        for (var i = e; i < n; ++i) r[i - e] = this.getData(0, i);
                    else r.fill("");
                    return r
                }, e.getSourceSeriesCat = function() {
                    return this.getSeriesCat()
                }, e.getSeriesTx = function(t) {
                    var e = this.dataHasCat() ? 1 : 0;
                    if (v(t)) return this.dataHasTx() ? _(this.getData(e + t, 0)) : "";
                    var n = this.getDataRowNumber(),
                        r = new Array(n - e);
                    if (this.dataHasTx())
                        for (var i = e; i < n; ++i) r[i - e] = _(this.getData(i, 0));
                    else r.fill("");
                    return r
                }, e.getSourceSeriesTx = function(t) {
                    return this.getSeriesTx(t)
                }, e.getSeriesVal = function(t, e) {
                    var n = t + (this.dataHasCat() ? 1 : 0),
                        r = this.dataHasTx() ? 1 : 0;
                    if (v(e)) return this.getData(n, r + e);
                    for (var i = this.getDataColNumber(), o = [], s = r; s < i; ++s) o.push(this.getData(n, s));
                    return o
                }, e.getSourceSeriesVal = function(t, e) {
                    return this.getSeriesVal(t, e)
                }, e.getSeriesThemeColors = function() {
                    return gt
                }, e.getSeriesCount = function(t) {
                    var e = this.getDataRowNumber() - (this.dataHasCat() ? 1 : 0);
                    if (t) {
                        var n = this.ensureSeries().length;
                        e < n && (e = n)
                    }
                    return e
                }, e.getSeriesColor = function(t) {
                    return this.ensureChart().getType() === l.PIE ? this.ensurePieSeries().getPieColor(t) : this.ensureSeries(t).getColor()
                }, e.calcAxisBias = function() {
                    var t, e;
                    return this.forEachSeries((function(n) {
                        if (n.getRightAxis() ? e = !0 : t = !0, t && e) return !0
                    })), t && e ? 0 : t ? -1 : e ? 1 : NaN
                }, e.forEachSeries = function(t, e, n) {
                    for (var r = 0, i = this.getSeriesCount(n); r < i; ++r) {
                        var o = t.call(e, this.ensureSeries(r), r, i);
                        if (null != o) return o
                    }
                }, e.eachSeries = function(t) {
                    return this.forEachSeries((function(e, n) {
                        if (!1 === t.call(this, e, n)) return !1
                    }), this)
                }, e.filterChartSetting = function(t, e, n, r) {
                    switch (t) {
                        case l.BAR:
                        case l.LINE:
                        case l.AREA:
                            break;
                        default:
                            n = r ? u.GROUPING : null
                    }
                    return {
                        type: t,
                        barDir: t === l.BAR ? e : r ? u.BAR_DIR : null,
                        grouping: n
                    }
                }, e.handleSeries = function(t, e, n) {
                    v(t) ? e.call(n, this.ensureSeries(t), t) : this.forEachSeries(e, n)
                }, e._handleTitle = function(t, e, n) {
                    var r = this.ensureTitle(t);
                    r && e.call(n, r, t)
                }, e.handleTitle = function(t, e, n) {
                    var r = this;
                    t ? this._handleTitle(t, e, n) : ["title", "subtitle", "xTitle", "yTitle", "y2Title"].forEach((function(t) {
                        r._handleTitle(t, e, n)
                    }))
                }, e._handleAxis = function(t, e, n) {
                    var r = this.ensureAxis(t);
                    r && e.call(n, r, t)
                }, e.handleAxis = function(t, e, n) {
                    var r = this;
                    t ? this._handleAxis(t, e, n) : ["x", "y", "y2"].forEach((function(t) {
                        r._handleAxis(t, e, n)
                    }))
                }, e.getAllColors = function() {
                    var t = [];

                    function e(e) {
                        e && t.push(e.substr(1).toLowerCase())
                    }
                    return e(this.ensureChart().getBackgroundColor(!0)), this.handleTitle(null, (function(t) {
                        e(t.ensureTextStyle().getColor(!0))
                    }), this), this.forEachSeries((function(t) {
                        e(t.getColor(!0)), e(t.getPieBorderColor(!0)), e(t.ensureLabel().ensureTextStyle().getColor(!0)), (t.getPieColors(!0) || []).forEach(e)
                    }), this, !0), e(this.ensureChartLegendStyle().getColor(!0)), this.handleAxis(null, (function(t) {
                        e(t.ensureLabel().ensureTextStyle().getColor(!0)), e(t.ensureMajorGridLines().getColor(!0))
                    }), this), t
                }, t.checkCmdName = function(t) {
                    return t && t in this.prototype && "apply" !== t && (t.startsWith("apply") || t.startsWith("_apply"))
                }, e.apply = function(t, e) {
                    return !!this.constructor.checkCmdName(t) && (this[t].apply(this, e), !0)
                }, e.invert = function(t, e) {
                    if (!this.constructor.checkCmdName(t)) return !1;
                    var n = this[t.replace("apply", "invert")].apply(this, e);
                    return Array.isArray(n) || (n = [n]), n.forEach((function(e) {
                        e.name || (e.name = t)
                    })), n
                }, e.applyChartSetting = function(t, e, n) {
                    var r = this.filterChartSetting(t, e, n);
                    if (t = r.type, e = r.barDir, n = r.grouping, this._applyChartType(t), t === l.HYBRID) {
                        var i = this.getSeriesCount() / 2;
                        this.forEachSeries((function(t, e) {
                            t.setType(e < i ? l.BAR : null)
                        }), this, !0)
                    } else this.forEachSeries((function(t, e) {
                        t.setType(null)
                    }), this, !0);
                    this._applyChartBarDir(e), this._applyChartGrouping(n)
                }, e._applyChartType = function(t) {
                    this.ensureChart().setType(t)
                }, e._applyChartBarDir = function(t) {
                    this.ensureChart().setBarDir(t)
                }, e._applyChartGrouping = function(t) {
                    this.ensureChart().setGrouping(t)
                }, e.applyChartBackgroundColor = function(t) {
                    this.ensureChart().setBackgroundColor(t)
                }, e.applyChartBlankAs = function(t) {
                    this.ensurePlotArea().setBlankAs(t)
                }, e.applyChartShowBlank = function(t) {
                    this.applyChartBlankAs(t ? y.SPAN : y.GAP)
                }, e.applyGlobalFontFamily = function(t) {
                    this.ensureGlobalTextStyle().setFontFamily(t)
                }, e.applyUseColumnHeader = function(t) {
                    this.ensurePlotArea().setUseColumnHeader(t)
                }, e.applyUseRowHeader = function(t) {
                    this.ensurePlotArea().setUseRowHeader(t)
                }, e.applySwitchRowColumn = function(t) {
                    this.ensurePlotArea().setSwitchRowColumn(t)
                }, e.applyPieHoleSize = function(t) {
                    this.ensurePieSeries().setPieHoleSize(t)
                }, e.applyPieBorderColor = function(t) {
                    this.ensurePieSeries().setPieBorderColor(t)
                }, e.applyPieLabelDisplay = function(t) {
                    var e = this.ensurePieLabel();
                    e.setShowVal(t.val), e.setShowCat(t.cat), e.setShowPercent(t.percent)
                }, e.applyPieLabelFontFamily = function(t) {
                    this.ensurePieLabelStyle().setFontFamily(t)
                }, e.applyPieLabelFontSize = function(t) {
                    this.ensurePieLabelStyle().setFontSize(t)
                }, e.applyPieLabelBold = function(t) {
                    this.ensurePieLabelStyle().setBold(t)
                }, e.applyPieLabelItalic = function(t) {
                    this.ensurePieLabelStyle().setItalic(t)
                }, e.applyPieLabelColor = function(t) {
                    this.ensurePieLabelStyle().setColor(t)
                }, e.applyTitleText = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.setText(e)
                    }))
                }, e.applyTitleFontFamily = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.ensureTextStyle().setFontFamily(e)
                    }))
                }, e.applyTitleFontSize = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.ensureTextStyle().setFontSize(e)
                    }))
                }, e.applyTitleBold = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.ensureTextStyle().setBold(e)
                    }))
                }, e.applyTitleItalic = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.ensureTextStyle().setItalic(e)
                    }))
                }, e.applyTitleColor = function(t, e) {
                    this.handleTitle(t, (function(t) {
                        t.ensureTextStyle().setColor(e)
                    }))
                }, e.applySeriesType = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.setType(e)
                    }))
                }, e.applySeriesColor = function(t, e) {
                    if (v(t)) return this.ensureChart().getType() === l.PIE ? this._applyPieColor(t, e) : this._applySeriesColor(t, e)
                }, e._applyPieColor = function(t, e) {
                    this.ensurePieSeries().setPieColor(t, e)
                }, e._applySeriesColor = function(t, e) {
                    this.ensureSeries(t).setColor(e)
                }, e.applySeriesRightAxis = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.setRightAxis(e)
                    }))
                }, e.applySeriesSmooth = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.setSmooth(e)
                    }))
                }, e.applySeriesOpacity = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.setOpacity(e)
                    }))
                }, e.applySeriesLineType = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLineStyle().setType(e)
                    }))
                }, e.applySeriesLineWidth = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLineStyle().setWidth(e)
                    }))
                }, e.applySeriesMarkerSymbol = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureMarker().setSymbol(e)
                    }))
                }, e.applySeriesMarkerSize = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureMarker().setSize(e)
                    }))
                }, e.applySeriesLabelHidden = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().setHidden(e)
                    }))
                }, e.applySeriesLabelPosition = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().setPosition(e)
                    }))
                }, e.applySeriesLabelFontFamily = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setFontFamily(e)
                    }))
                }, e.applySeriesLabelFontSize = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setFontSize(e)
                    }))
                }, e.applySeriesLabelItalic = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setItalic(e)
                    }))
                }, e.applySeriesLabelBold = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setBold(e)
                    }))
                }, e.applySeriesLabelColor = function(t, e) {
                    this.handleSeries(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setColor(e)
                    }))
                }, e.applyLegendHidden = function(t) {
                    this.ensureChartLegend().setHidden(t)
                }, e.applyLegendPosition = function(t) {
                    this.ensureChartLegend().setPosition(t), this.applyLegendHidden(!1)
                }, e.applyLegendFontFamily = function(t) {
                    this.ensureChartLegendStyle().setFontFamily(t)
                }, e.applyLegendFontSize = function(t) {
                    this.ensureChartLegendStyle().setFontSize(t)
                }, e.applyLegendItalic = function(t) {
                    this.ensureChartLegendStyle().setItalic(t)
                }, e.applyLegendBold = function(t) {
                    this.ensureChartLegendStyle().setBold(t)
                }, e.applyLegendColor = function(t) {
                    this.ensureChartLegendStyle().setColor(t)
                }, e.applyAxisTickNumber = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.setTickNumber(e)
                    }))
                }, e.applyAxisTreatAsText = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.setTreatAsText(e)
                    }))
                }, e.applyAxisScalingMin = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setMin(e)
                    }))
                }, e.applyAxisScalingMax = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setMax(e)
                    }))
                }, e.applyAxisScalingOrientation = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setOrientation(e)
                    }))
                }, e.applyAxisScalingRevert = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setRevert(e)
                    }))
                }, e.applyAxisScalingLogBase = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setLogBase(e)
                    }))
                }, e.applyAxisScalingLog = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureScaling().setLog(e)
                    }))
                }, e.applyAxisGridHidden = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureMajorGridLines().setHidden(e)
                    }))
                }, e.applyAxisGridColor = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureMajorGridLines().setColor(e)
                    }))
                }, e.applyAxisLabelHidden = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().setHidden(e)
                    }))
                }, e.applyAxisLabelRotate = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().setRotate(e)
                    }))
                }, e.applyAxisLabelFontFamily = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setFontFamily(e)
                    }))
                }, e.applyAxisLabelFontSize = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setFontSize(e)
                    }))
                }, e.applyAxisLabelItalic = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setItalic(e)
                    }))
                }, e.applyAxisLabelBold = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setBold(e)
                    }))
                }, e.applyAxisLabelColor = function(t, e) {
                    this.handleAxis(t, (function(t) {
                        t.ensureLabel().ensureTextStyle().setColor(e)
                    }))
                }, e.applyPlotAreaLayoutEnabled = function(t, e) {
                    var n = this.ensurePlotArea().ensureLayout();
                    n.setEnabled(t), t && e ? (n.setTop(e.top || 0), n.setLeft(e.left || 0), n.setRight(e.right || 0), n.setBottom(e.bottom || 0)) : (n.setTop(null), n.setLeft(null), n.setRight(null), n.setBottom(null))
                }, e.applyPlotAreaLeft = function(t) {
                    this.ensurePlotArea().ensureLayout().setLeft(t)
                }, e.applyPlotAreaTop = function(t) {
                    this.ensurePlotArea().ensureLayout().setTop(t)
                }, e.applyPlotAreaRight = function(t) {
                    this.ensurePlotArea().ensureLayout().setRight(t)
                }, e.applyPlotAreaBottom = function(t) {
                    this.ensurePlotArea().ensureLayout().setBottom(t)
                }, e.invertChartSetting = function() {
                    var t = [];
                    return t.push.apply(t, this.invert("_applyChartGrouping")), t.push.apply(t, this.invert("_applyChartBarDir")), this.forEachSeries((function(e, n) {
                        t.push.apply(t, this.invert("applySeriesType", [n]))
                    }), this, !0), t.push.apply(t, this.invert("_applyChartType")), t
                }, e._invertChartType = function(t) {
                    return {
                        args: [this.ensureChart().getType(!0)]
                    }
                }, e._invertChartBarDir = function(t) {
                    return {
                        args: [this.ensureChart().getBarDir(!0)]
                    }
                }, e._invertChartGrouping = function(t) {
                    return {
                        args: [this.ensureChart().getGrouping(!0)]
                    }
                }, e.invertChartBackgroundColor = function(t) {
                    return {
                        args: [this.ensureChart().getBackgroundColor(!0)]
                    }
                }, e.invertChartBlankAs = function(t) {
                    return {
                        args: [this.ensurePlotArea().getBlankAs(!0)]
                    }
                }, e.invertChartShowBlank = function(t) {
                    return this.invert("applyChartBlankAs")
                }, e.invertGlobalFontFamily = function(t) {
                    return {
                        args: [this.ensureGlobalTextStyle().getFontFamily(!0)]
                    }
                }, e.invertUseColumnHeader = function(t) {
                    return {
                        args: [this.ensurePlotArea().getUseColumnHeader(!0)]
                    }
                }, e.invertUseRowHeader = function(t) {
                    return {
                        args: [this.ensurePlotArea().getUseRowHeader(!0)]
                    }
                }, e.invertSwitchRowColumn = function(t) {
                    return {
                        args: [this.ensurePlotArea().getSwitchRowColumn(!0)]
                    }
                }, e.invertPieHoleSize = function(t) {
                    return {
                        args: [this.ensurePieSeries().getPieHoleSize(!0)]
                    }
                }, e.invertPieBorderColor = function(t) {
                    return {
                        args: [this.ensurePieSeries().getPieBorderColor(!0)]
                    }
                }, e.invertPieLabelDisplay = function(t) {
                    var e = this.ensurePieLabel();
                    return {
                        args: [{
                            val: e.getShowVal(!0),
                            cat: e.getShowCat(!0),
                            percent: e.getShowPercent(!0)
                        }]
                    }
                }, e.invertPieLabelFontFamily = function(t) {
                    return {
                        args: [this.ensurePieLabelStyle().getFontFamily(!0)]
                    }
                }, e.invertPieLabelFontSize = function(t) {
                    return {
                        args: [this.ensurePieLabelStyle().getFontSize(!0)]
                    }
                }, e.invertPieLabelBold = function(t) {
                    return {
                        args: [this.ensurePieLabelStyle().getBold(!0)]
                    }
                }, e.invertPieLabelItalic = function(t) {
                    return {
                        args: [this.ensurePieLabelStyle().getItalic(!0)]
                    }
                }, e.invertPieLabelColor = function(t) {
                    return {
                        args: [this.ensurePieLabelStyle().getColor(!0)]
                    }
                }, e.invertTitleText = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.getText(!0)]
                        })
                    })), n
                }, e.invertTitleFontFamily = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureTextStyle().getFontFamily(!0)]
                        })
                    })), n
                }, e.invertTitleFontSize = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureTextStyle().getFontSize(!0)]
                        })
                    })), n
                }, e.invertTitleBold = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureTextStyle().getBold(!0)]
                        })
                    })), n
                }, e.invertTitleItalic = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureTextStyle().getItalic(!0)]
                        })
                    })), n
                }, e.invertTitleColor = function(t, e) {
                    var n = [];
                    return this.handleTitle(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureTextStyle().getColor(!0)]
                        })
                    })), n
                }, e.invertSeriesType = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.getType(!0)]
                        })
                    })), n
                }, e.invertSeriesColor = function(t, e) {
                    if (v(t)) return this.ensureChart().getType() === l.PIE ? this.invert("_applyPieColor", arguments) : this.invert("_applySeriesColor", arguments)
                }, e._invertPieColor = function(t, e) {
                    return {
                        args: [t, this.ensurePieSeries().getPieColor(t, !0)]
                    }
                }, e._invertSeriesColor = function(t, e) {
                    return {
                        args: [t, this.ensureSeries(t).getColor(!0)]
                    }
                }, e.invertSeriesRightAxis = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.getRightAxis(!0)]
                        })
                    })), n
                }, e.invertSeriesSmooth = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.getSmooth(!0)]
                        })
                    })), n
                }, e.invertSeriesOpacity = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.getOpacity(!0)]
                        })
                    })), n
                }, e.invertSeriesLineType = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLineStyle().getType(!0)]
                        })
                    })), n
                }, e.invertSeriesLineWidth = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLineStyle().getWidth(!0)]
                        })
                    })), n
                }, e.invertSeriesMarkerSymbol = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureMarker().getSymbol(!0)]
                        })
                    })), n
                }, e.invertSeriesMarkerSize = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureMarker().getSize(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelHidden = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().getHidden(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelPosition = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().getPosition(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelFontFamily = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getFontFamily(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelFontSize = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getFontSize(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelItalic = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getItalic(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelBold = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getBold(!0)]
                        })
                    })), n
                }, e.invertSeriesLabelColor = function(t, e) {
                    var n = [];
                    return this.handleSeries(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getColor(!0)]
                        })
                    })), n
                }, e.invertLegendHidden = function(t) {
                    return {
                        args: [this.ensureChartLegend().getHidden(!0)]
                    }
                }, e.invertLegendPosition = function(t) {
                    return [{
                        args: [this.ensureChartLegend().getPosition(!0)]
                    }, {
                        name: "applyLegendHidden",
                        args: [this.ensureChartLegend().getHidden(!0)]
                    }]
                }, e.invertLegendFontFamily = function(t) {
                    return {
                        args: [this.ensureChartLegendStyle().getFontFamily(!0)]
                    }
                }, e.invertLegendFontSize = function(t) {
                    return {
                        args: [this.ensureChartLegendStyle().getFontSize(!0)]
                    }
                }, e.invertLegendItalic = function(t) {
                    return {
                        args: [this.ensureChartLegendStyle().getItalic(!0)]
                    }
                }, e.invertLegendBold = function(t) {
                    return {
                        args: [this.ensureChartLegendStyle().getBold(!0)]
                    }
                }, e.invertLegendColor = function(t) {
                    return {
                        args: [this.ensureChartLegendStyle().getColor(!0)]
                    }
                }, e.invertAxisTickNumber = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.getTickNumber(!0)]
                        })
                    })), n
                }, e.invertAxisTreatAsText = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.getTreatAsText(!0)]
                        })
                    })), n
                }, e.invertAxisScalingMin = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureScaling().getMin(!0)]
                        })
                    })), n
                }, e.invertAxisScalingMax = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureScaling().getMax(!0)]
                        })
                    })), n
                }, e.invertAxisScalingOrientation = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureScaling().getOrientation(!0)]
                        })
                    })), n
                }, e.invertAxisScalingRevert = function(t, e) {
                    return this.invert("applyAxisScalingOrientation", [t])
                }, e.invertAxisScalingLogBase = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureScaling().getLogBase(!0)]
                        })
                    })), n
                }, e.invertAxisScalingLog = function(t, e) {
                    return this.invert("applyAxisScalingLogBase", [t])
                }, e.invertAxisGridHidden = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureMajorGridLines().getHidden(!0)]
                        })
                    })), n
                }, e.invertAxisGridColor = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureMajorGridLines().getColor(!0)]
                        })
                    })), n
                }, e.invertAxisLabelHidden = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().getHidden(!0)]
                        })
                    })), n
                }, e.invertAxisLabelRotate = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().getRotate(!0)]
                        })
                    })), n
                }, e.invertAxisLabelFontFamily = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getFontFamily(!0)]
                        })
                    })), n
                }, e.invertAxisLabelFontSize = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getFontSize(!0)]
                        })
                    })), n
                }, e.invertAxisLabelItalic = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getItalic(!0)]
                        })
                    })), n
                }, e.invertAxisLabelBold = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getBold(!0)]
                        })
                    })), n
                }, e.invertAxisLabelColor = function(t, e) {
                    var n = [];
                    return this.handleAxis(t, (function(t, e) {
                        n.push({
                            args: [e, t.ensureLabel().ensureTextStyle().getColor(!0)]
                        })
                    })), n
                }, e.invertPlotAreaLayoutEnabled = function(t) {
                    var e = this.ensurePlotArea().ensureLayout(),
                        n = {
                            top: e.getTop(!0),
                            left: e.getLeft(!0),
                            right: e.getRight(!0),
                            bottom: e.getBottom(!0)
                        };
                    return {
                        args: [e.getEnabled(!0), n]
                    }
                }, e.invertPlotAreaLeft = function(t) {
                    return {
                        args: [this.ensurePlotArea().ensureLayout().getLeft(!0)]
                    }
                }, e.invertPlotAreaTop = function(t) {
                    return {
                        args: [this.ensurePlotArea().ensureLayout().getTop(!0)]
                    }
                }, e.invertPlotAreaRight = function(t) {
                    return {
                        args: [this.ensurePlotArea().ensureLayout().getRight(!0)]
                    }
                }, e.invertPlotAreaBottom = function(t) {
                    return {
                        args: [this.ensurePlotArea().ensureLayout().getBottom(!0)]
                    }
                }, e.isDrawable = function() {
                    var t, e, n, r = this.ensureChart().getType() === l.PIE,
                        i = this.dataHasCat() ? 1 : 0,
                        o = this.dataHasTx() ? 1 : 0,
                        s = r ? i + 1 : this.getDataRowNumber(),
                        u = this.getDataColNumber();
                    if (i >= s || o >= u) return !1;
                    for (t = i; t < s; t++)
                        for (e = o; e < u; e++)
                            if (v(n = this.getData(t, e)) && (!r || n > 0)) return !0;
                    return !1
                }, e.calcSeriesData = function(t) {
                    for (var e = [], n = 0, r = this.getSeriesCount(); n < r; ++n) e.push({
                        name: this.getSeriesTx(n),
                        data: this.getSeriesVal(n)
                    });
                    return e
                }, e.calcPlotBound = function(t) {
                    var e = A.padding,
                        n = e.top,
                        r = e.bottom,
                        i = e.left,
                        o = e.right,
                        s = this.ensureGlobalTextStyle().getFontSize(),
                        u = this.ensureChartTitle();
                    u.getText() && (n += m(u.ensureTextStyle().getFontSize() || s));
                    var a = this.ensureChartSubtitle();
                    a.getText() && (n += m(a.ensureTextStyle().getFontSize() || s) + (u.getText() ? A.titleGap : 0));
                    var l = this.ensureChartLegend();
                    if (!l.getHidden()) switch (l.getPosition()) {
                        case "t":
                            n += m(l.ensureTextStyle().getFontSize() || s) + A.plotGap;
                            break;
                        case "b":
                            r += m(l.ensureTextStyle().getFontSize() || s) + A.plotGap;
                            break;
                        case "l":
                            i += A.legendWidth;
                            break;
                        default:
                            o += A.legendWidth
                    }
                    return n += A.plotGap, i += A.plotGap, o += A.plotGap, t && (n /= A.cm2pxMultiplier, i /= A.cm2pxMultiplier, o /= A.cm2pxMultiplier, r /= A.cm2pxMultiplier), {
                        top: n,
                        left: i,
                        right: o,
                        bottom: r
                    }
                }, e.getEchartParameters = function(t, e) {
                    var n = function(t) {
                        switch (t.ensureChart().getType()) {
                            case l.LINE:
                                return new B(t);
                            case l.AREA:
                                return new D(t);
                            case l.BAR:
                                return new F(t);
                            case l.PIE:
                                return new k(t);
                            case l.SCATTER:
                                return new E(t);
                            case l.HYBRID:
                                return new N(t)
                        }
                    }(this);
                    if (n) return n.initData(), n.convert(t, e)
                }, e.clone = function() {
                    return new this.constructor(this.getChartCfg(), this.getOptionCfg())
                }, e.getConfig = function() {
                    return {
                        chartCfg: this.getChartCfg(),
                        optionCfg: this.getOptionCfg()
                    }
                }, e.getChartCfg = function() {
                    return this.build()
                }, e.getOptionCfg = function() {
                    return this._options
                }, t
            }()),
            St = {
                API: new(function() {
                    function t() {
                        this.session = {
                            sid: "",
                            synotoken: "",
                            baseurl: "",
                            object_id: "",
                            password: ""
                        }, this.page_setup = {
                            orientation: "portrait",
                            top: 2.54,
                            bottom: 2.54,
                            left: 2.54,
                            right: 2.54,
                            page_type: "a4"
                        }
                    }
                    var e = t.prototype;
                    return e.convertCm2Pixel = function(t) {
                        return parseInt(37.795276 * t, 10)
                    }, e.init = function(t, e) {
                        this.session = t, "object" == typeof e && (this.page_setup = e), this.initContainer(), this.adjustPageStyle()
                    }, e.initContainer = function() {
                        var t, e = document.body.querySelector(".ProseMirror-content");
                        e || (e = document.body), t = e.getBoundingClientRect(), this.rect = {
                            top: t.top,
                            left: t.left
                        }, e.classList.add("syno-o-doc-mobile-view"), this.container = e
                    }, e.adjustPageStyle = function() {
                        Array.prototype.forEach.call(this.container.querySelectorAll(".syno-o-doc-pm-page-content, .syno-o-doc-pm-page"), (function(t) {
                            t.style.height = "auto", t.style.boxShadow = "none"
                        })), Array.prototype.forEach.call(this.container.querySelectorAll(".syno-o-doc-pm-page-body"), (function(t) {
                            t.style.height = "auto"
                        })), Array.prototype.forEach.call(this.container.querySelectorAll(".syno-o-doc-pm-page-content-container"), (function(t) {
                            t.style.width = "auto", t.style.position = "relative"
                        }))
                    }, e.fillImageUrl = function(t, e, n) {
                        window.Mobile.getAttachmentURL({
                            object_id: this.session.object_id,
                            file_id: e,
                            filename: encodeURIComponent(n || e + ".png"),
                            password: this.session.password
                        }, (function(e) {
                            t.src = e.url
                        }))
                    }, e.createImage = function(t) {
                        var e = document.createElement("img");
                        return e.style.width = t.width, e.style.height = t.height, this.fillImageUrl(e, t.file_id, t.file_alt), e
                    }, e.drawAll = function() {
                        this.drawChart(), this.drawImage(), this.wrapTable(), this.adjustHeading(), this.adjustEmptyTextblock(), this.adjustContentEditable()
                    }, e.wrapTable = function() {
                        for (var t, e, n = this.container.querySelectorAll("table"), r = n.length - 1; r >= 0; r--) e = n[r], (t = document.createElement("div")).className = "syno-o-doc-mobile-table-wrapper", e.parentNode.insertBefore(t, e), t.appendChild(e)
                    }, e.drawImage = function() {
                        var t, e, n, r = this.container.querySelectorAll('[synograph][data-graph-type="image"]');
                        for (n = r.length - 1; n >= 0; n--) t = r[n], e = JSON.parse(t.getAttribute("graph-config")), t.appendChild(this.createImage(e)), "break" === e.alignment && this.putElementToPoint(t, e.left, e.top);
                        for (n = (r = this.container.querySelectorAll('img[file-id][file-type="image"]')).length - 1; n >= 0; n--) {
                            var i = (t = r[n]).getAttribute("file-id");
                            this.fillImageUrl(t, i)
                        }
                    }, e.drawChart = function() {
                        var t, e, n, r, i, o, s = this.container.querySelectorAll("[synochart]");
                        r = document.body.appendChild(document.createElement("div"));
                        for (var u = s.length - 1; u >= 0; u--) e = s[u], r.style.width = e.style.width, r.style.height = e.style.height, o = JSON.parse(e.getAttribute("data-data")), t = new yt(JSON.parse(e.getAttribute("config")), {
                            data: o
                        }), (i = window.echarts.init(r)).setOption(t.getEchartParameters(i.getWidth(), i.getHeight())), (n = e.appendChild(document.createElement("img"))).setAttribute("src", i.getDataURL({
                            pixelRatio: 2 * (window.devicePixelRatio || 1)
                        })), n.style.width = i.getWidth() - 4 + "px", n.style.height = i.getHeight() - 4 + "px", i.dispose(), e.style.pointerEvents = "none";
                        document.body.removeChild(r)
                    }, e.putElementToPoint = function(t, e, n) {
                        for (var r = document.elementFromPoint(e + this.rect.left, n + this.rect.top); r && (1 !== r.nodeType || "SPAN" === r.nodeName);) r = r.parentNode;
                        r && r.parentNode.insertBefore(t, r)
                    }, e.adjustHeading = function() {
                        for (var t, e = this.container.querySelectorAll("[synohead]"), n = e.length - 1; n >= 0; n--)(t = e[n]).setAttribute("id", t.getAttribute("synohead"))
                    }, e.adjustEmptyTextblock = function() {
                        var t = this.container.ownerDocument;
                        Array.prototype.forEach.call(this.container.querySelectorAll("p, h1, h2, h3, h4, h5, h6"), (function(e) {
                            e.firstChild || e.appendChild(t.createElement("br"))
                        }))
                    }, e.adjustContentEditable = function() {
                        Array.prototype.forEach.call(this.container.querySelectorAll("[contenteditable]"), (function(t) {
                            t.removeAttribute("contenteditable")
                        }))
                    }, t
                }())
            }
    }])
}));