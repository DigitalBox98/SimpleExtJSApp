/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(t, e) {
    for (var i = 0; i < e.length; i++) {
        var n = e[i];
        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(t, n.key, n)
    }
}

function _createClass(t, e, i) {
    return e && _defineProperties(t.prototype, e), i && _defineProperties(t, i), t
}

function _typeof(t) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}
var _S, _TT;
/**
 * @class SYNO.SDS.TransitionEndHandler
 * @extends Ext.util.Observable
 * Spreadsheet transition end handler class
 *
 */
Ext.define("SYNO.SDS.TransitionEndHandler", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.el = t, t.on("transitionend", this.endTransition, this), this.callParent(arguments)
    },
    start: function() {
        this.startTime = new Date
    },
    endTransition: function() {
        this.fireEvent("aftertransition", this, new Date - this.startTime)
    }
}), Ext.define("SYNO.SDS._DeskTopManager", {
    extend: "Ext.util.Observable",
    list: null,
    front: null,
    desktopId: "sds-desktop",
    constructor: function() {
        this.list = {}, this.callParent()
    },
    register: function(t) {
        t.manager && t.manager.unregister(t), t.manager = this, this.list[t.id] = t, t.id !== this.desktopId && t !== this.desktopId || this.showDesktop()
    },
    unregister: function(t) {
        delete t.manager, delete this.list[t.id]
    },
    isDesktopOnTop: function() {
        return this.front === this.get(this.desktopId)
    },
    showDesktop: function() {
        var t = this.get(this.desktopId);
        this.bringToFront(t)
    },
    get: function(t) {
        return "object" == _typeof(t) ? t : this.list[t]
    },
    updateTransition: function(t, e) {
        e > 500 && (this.disableBlur = !0, this.transitionHandler.un("aftertransition", this.updateTransition, this))
    },
    bringToFront: function(t) {
        var e, i = this;
        return !((t = i.get(t)) === i.front || !t) && (e = t.doLayout, t.show(), i.front && i.front.id === i.desktopId ? i.front.addClass(i.backgroundTransparent ? "semi-transparent" : "sent-back") : i.front && i.front.hide(), i.front = t, e && t.doLayout(), !0)
    },
    hideAllExceptMe: function(t) {
        var e, i = this;
        for (var n in i.list) i.list.hasOwnProperty(n) && (e = i.list[n]) && e !== t && "function" != typeof i.list[n] && i.list[n].isVisible() && i.list[n].hide()
    },
    hideAll: function() {
        for (var t in this.list) this.list[t] && "function" != typeof this.list[t] && this.list[t].isVisible() && this.list[t].hide();
        this.front = null
    },
    getActive: function() {
        return this.front
    },
    each: function(t, e) {
        for (var i in this.list)
            if (this.list[i] && "function" != typeof this.list[i] && !1 === t.call(e || this.list[i], this.list[i])) return
    }
}), SYNO.SDS.DefineDesktopView = function(t, e) {
    Ext.define(t, {
        extend: e,
        animateShowHideCls: "sds-desktop-view-animate",
        showCls: "sds-desktop-view-show",
        constructor: function(t) {
            t = t || {}, t = Ext.apply(t, {
                tabIndex: -1,
                hideMode: "offsets",
                hidden: !0
            }), this.callParent([t]), this.initManager(t.manager || SYNO.SDS.DeskTopManager), t.taskBarConfig && this.initTaskbarButton(t.taskBarConfig), t.trayIconConfig && this.initTrayIconButton(t.trayIconConfig)
        },
        initManager: function(t) {
            this.manager = t, this.manager.register(this)
        },
        initTaskbarButton: function(t) {
            _S("standalone") || (t = t || {}, t = Ext.applyIf(t, {
                toggleHandler: this.onToggle.createDelegate(this)
            }), this.taskBarButton = SYNO.SDS.TaskBar.addDesktopViewButton(t))
        },
        initTrayIconButton: function(t) {
            _S("standalone") || (t = t || {}, t = Ext.applyIf(t, {
                toggleHandler: this.onToggle.createDelegate(this)
            }), this.taskBarButton = SYNO.SDS.TaskBar.addTrayIconViewButton(t))
        },
        toggleButton: function(t, e) {
            var i = this.taskBarButton;
            i && i.toggle(t, e)
        },
        onToggle: function(t, e) {
            this[e ? "activeView" : "showDesktop"]()
        },
        hide: function() {
            var t = this;
            t.transitionHandler.start(), t.removeClass(t.showCls), t.callParent(), t.toggleButton(!1, !0)
        },
        show: function() {
            this.transitionHandler.start(), this.addClass(this.showCls), this.callParent()
        },
        updateTransition: function(t, e) {
            e > 500 && (this.addClass("no-transition"), this.transitionHandler.un("aftertransition", this.updateTransition, this))
        },
        resetTransition: function() {
            this.disableBlur = !1, this.removeClass("no-transition")
        },
        activeView: function() {
            this.manager.bringToFront(this), this.focus()
        },
        showDesktop: function() {
            this.manager.showDesktop()
        },
        afterRender: function() {
            var t = this;
            t.callParent(), t.transitionHandler = t.transitionHandler || new SYNO.SDS.TransitionEndHandler(t.getEl()), t.transitionHandler.on("aftertransition", t.updateTransition, t), Ext.EventManager.onWindowResize(this.onWindowResize, this), t.animateShowHide && t.addClass(t.animateShowHideCls), t.el.on("mousedown", this.onClick, this), void 0 !== t.tabIndex && t.el.dom.setAttribute("tabIndex", t.tabIndex), t.keyNav = new Ext.KeyNav(t.el, {
                esc: this.onEnterEsc,
                scope: this
            })
        },
        onEnterEsc: function(t) {
            this.showDesktop()
        },
        onClick: function(t, e) {},
        resize: function(t, e) {},
        getViewSize: function() {
            return {
                viewH: Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                viewW: Ext.lib.Dom.getViewWidth()
            }
        },
        onWindowResize: function() {
            var t = this.getViewSize();
            this.resize(t.viewW, t.viewH)
        },
        refresh: function() {},
        addInstruction: function() {
            var t = Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                e = Ext.lib.Dom.getViewWidth();
            this.instruction = new Ext.Container({
                cls: "sds-app-widget-instruction",
                width: e,
                height: t,
                items: [{
                    xtype: "box",
                    cls: "message-container",
                    html: _T("desktop", "shortcut_zone_instruction")
                }, {
                    xtype: "box",
                    cls: "message-arrow"
                }],
                listeners: {
                    afterlayout: function() {
                        var t = this.el.child(".message-container"),
                            e = this.el.child(".message-arrow"),
                            i = .33 * this.getHeight();
                        t.alignTo(this.shortcutZoneLeft.el, "tl-tr", [-36, i]), e.alignTo(t, "r-l", [1, 5])
                    },
                    scope: this
                },
                resize: function() {
                    var t = Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                        e = Ext.lib.Dom.getViewWidth();
                    this.setSize(e, t), this.doLayout()
                },
                showTip: function() {
                    this.addClass("show")
                }
            }), this.add(this.instruction), this.on("show", this.showInstruction, this)
        },
        showInstruction: function() {
            this.showTaskId = Ext.defer(function() {
                this.instruction && (this.shortcutZoneLeft.addClass("on-instruction"), this.shortcutZoneRight.addClass("on-instruction"), this.shortcutZoneBottom && this.shortcutZoneBottom.addClass("on-instruction"), this.instruction.showTip())
            }, 500, this)
        },
        removeInstruction: function() {
            clearTimeout(this.showTaskId), this.resetTransition(), this.instruction && (this.remove(this.instruction, !0), this.instruction = null, this.shortcutZoneLeft.removeClass("on-instruction"), this.shortcutZoneRight.removeClass("on-instruction"), this.shortcutZoneBottom && this.shortcutZoneBottom.removeClass("on-instruction"), this.un("show", this.showInstruction, this), this.un("beforehide", this.removeInstruction, this))
        },
        destroy: function() {
            var t = this;
            t.transitionHandler.un("aftertransition", t.updateTransition, t), t.transitionHandler = null, Ext.EventManager.removeResizeListener(t.onWindowResize, t), Ext.destroy(t.keyNav), t.keyNav = null, t.taskBarButton.getEl().remove(), t.callParent(arguments)
        }
    })
}, SYNO.SDS.DefineDesktopView("SYNO.SDS._DesktopView", "Ext.Container"), SYNO.SDS.DefineDesktopView("SYNO.SDS.Box_DesktopView", "Ext.BoxComponent"), Ext.namespace("SYNO.SDS"), Ext.define("SYNO.SDS.DesktopSetting", {
    statics: {}
}), SYNO.SDS.ShortcutUtil = {
    allowedCfgProperty: ["jsID", "className", "param", "title", "formatedTitle", "desc", "icon", "type", "url", "urlDefMode", "urlTag", "urlTarget", "launchParams", "subItems", "icon_16", "icon_32", "allowStandalone", "port", "protocol", "windowLaunchEncodeFn", "windowLaunchDecodeFn"],
    getCfgPropertis: function() {
        return this.allowedCfgProperty.join(",")
    }
}, SYNO.SDS._StandaloneDesktop = Ext.extend(Ext.BoxComponent, {
    constructor: function() {
        SYNO.SDS._StandaloneDesktop.superclass.constructor.call(this, {
            id: "sds-desktop",
            style: "background: transparent; top: 0px; background-size: 100% 100%;",
            renderTo: document.body
        }), this.onWindowResize(), Ext.EventManager.onWindowResize(this.onWindowResize, this)
    },
    onWindowResize: function() {
        this.el.setHeight(Ext.lib.Dom.getViewHeight());
        var t = this.el.getBox(),
            e = SYNO.SDS.DesktopSetting.miniWidth || 1e3,
            i = SYNO.SDS.DesktopSetting.miniHeight || 580,
            n = t.width <= e ? "auto" : "hidden",
            s = t.height <= i ? "auto" : "hidden";
        this.el.setStyle({
            "overflow-x": n,
            "overflow-y": s
        })
    }
}), Ext.define("SYNO.SDS._Desktop", {
    extend: "SYNO.SDS.Box_DesktopView",
    defShortCuts: SYNO.SDS.isNVR ? [{
        className: "SYNO.SDS.PkgManApp.Instance"
    }, {
        className: "SYNO.SDS.AdminCenter.Application"
    }, {
        className: "SYNO.SDS.App.FileStation3.Instance"
    }, {
        className: "SYNO.SDS.HelpBrowser.Application"
    }, {
        className: "SYNO.SDS.SurveillanceStation"
    }] : [{
        className: "SYNO.SDS.PkgManApp.Instance"
    }, {
        className: "SYNO.SDS.AdminCenter.Application"
    }, {
        className: "SYNO.SDS.App.FileStation3.Instance"
    }, {
        className: "SYNO.SDS.HelpBrowser.Application"
    }],
    DROP_ALLOWED_CLS: "x-dd-drop-ok-add",
    DROP_DENIED_CLS: "x-dd-drop-nodrop",
    REPOSITION_OK_CLS: "x-dd-reposition-ok",
    CURSOR_OVER_TYPE: {
        ABOVE_ICON: 0,
        OVER_ICON: 1,
        BELOW_ICON: 2
    },
    items: null,
    iconItems: null,
    updateTask: null,
    updateDelay: 200,
    ICON_WIDTH: 136,
    ICON_HEIGHT: 116,
    isBeta: !1,
    opacityHideCls: "sds-desktop-hide",
    isItemUpdated: !1,
    constructor: function() {
        var t = this;
        SYNO.SDS.DesktopSetting.miniWidth = 1e3, SYNO.SDS.DesktopSetting.miniHeight = 580, this.allowedCfgProperty = SYNO.SDS.ShortcutUtil.getCfgPropertis(), this.hotkeyPlugin = new SYNO.SDS.DesktopHotKeyPlugin({
            module: this
        }), SYNO.SDS._Desktop.superclass.constructor.call(this, {
            id: "sds-desktop",
            taskBarConfig: {
                handler: this.onShowAll.createDelegate(this),
                tooltip: _T("desktop", "show_desktop"),
                renderTo: "sds-taskbar-showall"
            },
            plugins: [this.hotkeyPlugin],
            hidden: !1,
            renderTo: document.body
        }), this.items = [], this.iconItems = [], this.updateTask = new Ext.util.DelayedTask(this.updateItems, this), this.shortcutPanel = new SYNO.SDS.DesktopShortcutPanel({
            renderTo: "sds-desktop",
            module: this
        }), this.mon(this.el, "scroll", function(t) {
            var e = this.el.getBox();
            return this.el.dom.scrollTop > 0 && e.height >= SYNO.SDS.DesktopSetting.miniHeight && (this.el.dom.scrollTop = -100), t.preventDefault(), !1
        }, this), this.mon(Ext.getBody(), "scroll", function(t, e, i) {
            return e.scrollTop > 0 && (e.scrollTop = 0), t.preventDefault(), !1
        }, this), this.el.dragZone = new Ext.dd.DragZone(this.el, {
            ddGroup: "SDSShortCut",
            proxy: new SYNO.ux.StatusProxy({
                baseCls: "sds-launch-icon-dragging-proxy"
            }),
            validateTarget: function(t, e, i) {
                var n = e.getTarget("li.launch-icon");
                return !!(SYNO.SDS.Desktop.el.id === e.getTarget().id || n && Ext.fly(n).findParentNode(".sds-desktop-shortcut")) || (!(!e.getTarget("#sds-sub-container") && !e.getTarget("#sds-sub-container-shim")) || (this.getProxy().setStatus(this.dropNotAllowed), !1))
            },
            getDragData: this.getDragData.createDelegate(this, [], !0),
            getRepairXY: function() {
                return this.dragData.repairXY
            },
            endDrag: function(t) {
                SYNO.SDS.Desktop.onEndDrag(this.dragData)
            },
            onStartDrag: function(e, i) {
                var n = Ext.get(this.dragData.sourceEl).getBox(),
                    s = SYNO.SDS.Desktop.getEl().getBox(),
                    o = Ext.get(this.dragData.sourceEl);
                o.setVisibilityMode(Ext.Element.VISIBILITY), t.isInSelectState() || o.hide(), this.getProxy().getEl().disableShadow(), this.dragData.sourceEl.initPos = [e - o.getLeft(), i - o.getTop() + 30], this.dragData.sourceEl.moving = !1, this.minX = s.x, this.minY = s.y, this.maxX = s.right - n.width, this.maxY = s.bottom - n.height, this.constrainX = !0, this.constrainY = !0;
                var r = Ext.get("sds-desktop").dom.getElementsByTagName("iframe");
                Ext.each(r, function(t) {
                    var e = document.createElement("div");
                    e.addClassName("sds-shim-for-iframe"), Ext.get(t.parentNode).appendChild(e)
                })
            }
        }), this.el.dropZone = new Ext.dd.DropZone(Ext.getBody(), {
            dropAllowed: "x-dd-drop-ok-add",
            ddGroup: "SDSShortCut",
            getTargetFromEvent: function(t) {
                var e = t.getTarget("li.launch-icon");
                return e && Ext.fly(e).findParentNode(".sds-desktop-shortcut") ? e : null
            },
            onNodeOver: this.onNodeOver.createDelegate(this, [], !0),
            onContainerOver: this.onContainerOver.createDelegate(this, [], !0),
            onContainerDrop: this.onNotifyDrop.createDelegate(this, [], !0),
            onNodeDrop: this.onNodeDrop.createDelegate(this, [], !0)
        }), this.el.dropZone.addToGroup("AppReorderAndShortCut"), this.el.dropZone.addToGroup("AppShortCut"), this.wallpaper = this.createWallpaper(), this.onWindowResize(), Ext.EventManager.onWindowResize(this.onWindowResize, this), this.loadShortcutItems(), this.mon(SYNO.SDS.StatusNotifier, "servicechanged", this.onServiceChanged, this), this.mon(SYNO.SDS.StatusNotifier, "appprivilegechanged", this.onServiceChanged, this), this.mon(SYNO.SDS.StatusNotifier, "urltagchanged", this.refresh, this), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onThirdPartyChanged, this), _S("isMobile") && _S("is_admin") ? this.addMobileEditionButton() : t.isBeta && this.addBetaBugReportButton(), this.el.on("mousedown", this.onDesktopMouseDown, this)
    },
    onEndDrag: function(t) {
        var e = Ext.get(t._fromAppMenu ? t.desktopSrcEl : t.sourceEl),
            i = SYNO.SDS.Desktop;
        i.isInSelectState() && (Ext.removeNode(t.ddel), Ext.destroy(i.ddel)), e.show(), Ext.each(SYNO.SDS.Desktop.iconItems, function(t, e) {
            t && "SYNO.SDS.VirtualGroup" === t.className && t.validTempNode()
        });
        var n = Ext.get("sds-desktop").query(".sds-shim-for-iframe");
        Ext.each(n, function(t) {
            Ext.removeNode(t)
        }), this.el.focus()
    },
    setDesktopVisible: function(t) {
        Ext.get("sds-desktop").setVisibilityMode(Ext.Element.OFFSETS), this.bugReportButton && this.bugReportButton.setVisible(t)
    },
    hide: function() {
        this.setDesktopVisible(!1), this.addClass(this.opacityHideCls), this.removeClass(this.showCls), Ext.isIE && this.callParent()
    },
    show: function() {
        this.setDesktopVisible(!0), this.callParent(), this.removeClass(this.opacityHideCls), this.removeClass("semi-transparent"), this.removeClass("sent-back")
    },
    onShowAll: function() {
        this.showDesktop(), SYNO.SDS.WindowMgr.toggleAllWin(this.taskButton)
    },
    isInSelectState: function() {
        var t = !1;
        return Ext.each(this.iconItems, function(e) {
            t || e && e.isSelected() && (t = !0)
        }, this), t
    },
    getEvtXYWithScroll: function(t) {
        return [t.xy[0] + this.el.dom.scrollLeft, t.xy[1] + this.el.dom.scrollTop]
    },
    onDesktopMouseDown: function(t, e, i) {
        var n, s = this.el.getLeft(),
            o = this.getEvtXYWithScroll(t);
        o[0] > e.scrollWidth || o[1] > e.scrollHeight || t.target === this.el.dom && ((n = Ext.get(document.body)).on("mousemove", this.onDesktopMouseMove, this), n.on("mouseup", this.onDesktopMouseUp, this), n.on("mouseleave", this.onDesktopMouseLeave, this, {
            delay: 100
        }), this.el._beginDragPos = o, this._range && this._range.remove(), this._range = this.el.createChild({
            tag: "div",
            cls: "sds-desktop-select-range"
        }), this._range.setPosition = function(t, e, i) {
            this.setLeft(t[0] - s), this.setTop(t[1] - 32), this.setWidth(e), this.setHeight(i)
        }.createDelegate(this._range), this._range.setPosition(o, 0, 0))
    },
    onDesktopMouseMove: function(t) {
        if (this.el._beginDragPos && t) {
            var e = this.el._beginDragPos,
                i = this.getEvtXYWithScroll(t),
                n = i[0] - e[0],
                s = i[1] - e[1];
            i = [n > 0 ? e[0] : i[0], s > 0 ? e[1] : i[1]], n = Math.abs(n), s = Math.abs(s), this._range.setPosition(i, n, s), this.rangeDetectTask = new Ext.util.DelayedTask(this.detectOverlappedObjects, this), this.rangeDetectTask.delay(5)
        }
    },
    onDesktopMouseLeave: function(t) {
        this.cancelRangeDetectTask(), this.endRangeDetect()
    },
    onDesktopMouseUp: function(t) {
        this.cancelRangeDetectTask(), this.detectOverlappedObjects(), this.endRangeDetect()
    },
    cancelRangeDetectTask: function() {
        this.rangeDetectTask && (this.rangeDetectTask.cancel(), this.rangeDetectTask = null)
    },
    endRangeDetect: function() {
        var t = Ext.get(document.body);
        this._range && this._range.remove(), this._range = null, delete this.el._beginDragPos, t.un("mousemove", this.onDesktopMouseMove, this), t.un("mouseup", this.onDesktopMouseUp, this), t.un("mouseleave", this.onDesktopMouseLeave, this)
    },
    collisionDetect: function(t, e) {
        var i, n;
        if (t && e) return i = t.getRegion(), n = e.getRegion(), (i.left < n.right && i.right > n.right || i.left < n.left && i.right > n.left || i.left > n.left && i.right < n.right) && (i.top > n.top && i.bottom < n.bottom || i.top < n.bottom && i.bottom > n.bottom || i.bottom > n.top && i.top < n.top)
    },
    detectOverlappedObjects: function() {
        var t = 0;
        Ext.each(this.iconItems, function(e, i) {
            e.subItems || (this.collisionDetect(e.li_el, this._range) ? (this.selectItem(e, !0), t++) : this.selectItem(e, !1))
        }, this), 0 === t && Ext.destroy(this.ddel)
    },
    selectItem: function(t, e) {
        t && t.li_el && t.setSelected && (t.setSelected(e), e ? t.li_el.addClass("sds-desktop-icon-selected") : t.li_el.removeClass("sds-desktop-icon-selected"))
    },
    getCursorOverType: function(t, e) {
        var i;
        return t[0] - e[0], (i = t[1] - e[1]) <= 17 ? this.CURSOR_OVER_TYPE.ABOVE_ICON : i >= 80 ? this.CURSOR_OVER_TYPE.BELOW_ICON : this.CURSOR_OVER_TYPE.OVER_ICON
    },
    onContainerOver: function(t, e, i) {
        return i.ddText && t.getProxy().getGhost().update(i.ddText), e.getTarget("#sds-sub-container") ? this.REPOSITION_OK_CLS : e.getTarget("#sds-taskbar") ? this.DROP_DENIED_CLS : i._fromDesktop || i._fromAppMenu ? this.REPOSITION_OK_CLS : this.DROP_ALLOWED_CLS
    },
    onNodeOver: function(t, e, i, n) {
        return n._fromSubContainer || this.isSubContainerExist() ? this.onSubNodeOver(t, e, i, n) : n._fromDesktop || n._fromAppMenu ? this.onDesktopNodeOver(t, e, i, n) : this.DROP_ALLOWED_CLS
    },
    onSubNodeOver: function(t, e, i, n) {
        var s = i.xy,
            o = Ext.get(t).getXY(),
            r = [s[0] - o[0], s[1] - o[1]],
            a = null;
        this.appendSubItemMode ? a = this.getItemFromSubTempNode() : n._fromSubContainer ? a = this.getItemFromSubNode(n.sourceEl) : this._creatingVirtualGroup && (a = this.getItemFromSubTempNode());
        var S = this.getItemFromSubNode(t),
            l = this.iconItems[S[0]];
        return this.isVirtualGroup(l) ? (r[0] > 40 && S[1]++, l.rePosition(a[1], S[1]), this.REPOSITION_OK_CLS) : this.DROP_ALLOWED_CLS
    },
    onDesktopNodeOver: function(t, e, i, n) {
        var s, o, r, a, S, l = this.getItemFromNode(t);
        if (!((s = n._fromAppMenu ? this.getItemFromNode(n.desktopSrcEl) : this.getItemFromNode(n.sourceEl)) < 0 || l < 0)) return o = this.iconItems[s], r = this.iconItems[l], S = this.getCursorOverType(i.xy, Ext.get(t).getXY()), this.cancelDeferTask(), S === this.CURSOR_OVER_TYPE.OVER_ICON ? this.nodeOverToGrouping(t, s, l, o, r) : (S === this.CURSOR_OVER_TYPE.ABOVE_ICON ? (a = this.rePosition.defer(100, this, [s, l]), this.setDeferTaskId(a)) : (a = this.rePosition.defer(100, this, [s, l + 1]), this.setDeferTaskId(a)), this.REPOSITION_OK_CLS)
    },
    rePosition: function(t, e) {
        if (t !== e && !this.isInSelectState()) {
            var i = this.items[t],
                n = this.iconItems[t];
            this.items.splice(e, 0, i), this.iconItems.splice(e, 0, n), e < t && t++, this.items.splice(t, 1), this.iconItems.splice(t, 1), this.updateItemsSetting(), this.refresh()
        }
    },
    isVirtualGroup: function(t) {
        return !(!t || "SYNO.SDS.VirtualGroup" !== t.className)
    },
    nodeOverToGrouping: function(t, e, i, n, s) {
        var o, r = this.isVirtualGroup(n),
            a = this.isVirtualGroup(s);
        if (n && s) {
            if (n === s) return this.DROP_ALLOWED_CLS;
            if (this.isInSelectState()) return s.isSelected() ? void 0 : this.DROP_ALLOWED_CLS;
            if (t && a && !r) {
                var S = Ext.copyTo({}, n.managerItemConfig ? n.managerItemConfig : n, this.allowedCfgProperty);
                return o = this.deferTaskToShowFolder.defer(800, this, [i, S]), this.setDeferTaskId(o), this.DROP_ALLOWED_CLS
            }
            return !t || a || r ? void 0 : (o = this.deferCreateVirtualGroup.defer(800, this, [e, i, n, s]), this.setDeferTaskId(o), this.DROP_ALLOWED_CLS)
        }
    },
    deferCreateVirtualGroup: function(t, e, i, n) {
        var s, o;
        this.backupNode = {
            src: {
                index: t,
                item: this.items[t]
            },
            dst: {
                index: e,
                item: this.items[e]
            }
        }, this.setOldDstItem(n), n.li_el.hide(), s = this.createNewGroupIcon(e, n, !1), this._containerShown = !0, this._creatingVirtualGroup = !0, s.createSubContainer(), o = Ext.copyTo({}, i.managerItemConfig ? i.managerItemConfig : i, this.allowedCfgProperty), s.addSubItem(o), s.refresh()
    },
    getItemFromSubTempNode: function() {
        var t = [-1, -1];
        return Ext.each(this.iconItems, function(e, i) {
            if (t[1] >= 0) return !1;
            Ext.each(e.iconItems, function(e, n) {
                if (e) return e.li_el._temp ? (t[0] = i, t[1] = n, !1) : void 0
            })
        }), t
    },
    getItemFromSubNode: function(t) {
        var e = [-1, -1];
        return Ext.each(this.iconItems, function(i, n) {
            if (i) return !(e[1] >= 0) && void Ext.each(i.iconItems, function(i, s) {
                if (i && t === i.dragEl.dom) return e[0] = n, e[1] = s, !1
            })
        }), e
    },
    updateItemsSetting: function() {
        SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
    },
    deferTaskToShowFolder: function(t, e) {
        var i = this.iconItems[t];
        i && (i.createSubContainer(), e && (this.appendSubItemMode = !0, i.addSubItem(e), i.refresh()), this._containerShown = !0)
    },
    addMobileEditionButton: function() {
        this.bugReportButton = this.el.createChild({
            tag: "div",
            id: "sds-mobile-edition",
            title: _T("common", "mobile_edition")
        }), this.mon(Ext.fly("sds-mobile-edition"), "click", function() {
            window.location = "?forceDesktop=0"
        })
    },
    addBetaBugReportButton: function() {
        this.bugReportButton = this.el.createChild({
            tag: "div",
            id: "sds-bug-report-container",
            cn: [{
                tag: "div",
                id: "sds-bug-report",
                title: _T("pkgmgr", "report_desc")
            }]
        }), this.mon(Ext.fly("sds-bug-report"), "click", function() {
            _S("is_admin") ? SYNO.SDS.AppLaunch("SYNO.SDS.SupportForm.Application") : window.open("http://myds.synology.com/support/beta_dsm_form.php", "_blank")
        })
    },
    onWindowResize: function() {
        this.el.setHeight(Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight()), this.el.setWidth(Ext.lib.Dom.getViewWidth());
        var t = this.el.getBox();
        this.el.setStyle({
            "overflow-x": t.width <= SYNO.SDS.DesktopSetting.miniWidth ? "auto" : "hidden",
            "overflow-y": t.height <= SYNO.SDS.DesktopSetting.miniHeight ? "auto" : "hidden"
        }), this.wallpaper.resize(), this.refresh(), this.fireEvent("desktopresize", this)
    },
    getDragData: function(t) {
        var e, i, n = this.getItemFromNode(t.getTarget("li.launch-icon"));
        if (n >= 0) {
            if (!(i = this.iconItems[n])) return;
            if (this.isInSelectState()) {
                if (i.isSelected()) return this.getDragDataInSelectState(n, t);
                this.deselectItems()
            }
            return (e = i.dragEl.dom.cloneNode(!0)).style.position = "", e.style.left = "", e.style.top = "", e.id = Ext.id(), {
                _fromDesktop: !0,
                ddel: e,
                sourceEl: i.dragEl.dom,
                repairXY: i.dragEl.getXY(),
                SDSShortCut: i.managerItemConfig
            }
        }
        var s = this.getItemFromSubNode(t.getTarget("li.launch-icon")),
            o = this.iconItems[s[0]];
        if (o && !(o && o.iconItems && o.iconItems.length <= 0) && (i = o.iconItems[s[1]])) return (e = i.dragEl.dom.cloneNode(!0)).style.position = "", e.style.left = "", e.style.top = "", e.id = Ext.id(), {
            _fromDesktop: !1,
            _fromSubContainer: !0,
            ddel: e,
            sourceEl: i.dragEl.dom,
            repairXY: i.dragEl.getXY(),
            SDSShortCut: i.managerItemConfig
        }
    },
    getDragDataInSelectState: function(t, e) {
        var i, n, s = [];
        if (i = Ext.getBody().createChild({
                tag: "div",
                cls: "sds-desktop-dd-ct"
            }), Ext.destroy(this.ddel), this.ddel = i, Ext.each(this.iconItems, function(t) {
                var e;
                t && t.isSelected() && ((e = t.dragEl.dom.cloneNode(!0)).id = Ext.id(), s.push(e), i.appendChild(e))
            }, this), n = this.iconItems[t]) return (i = i.dom.cloneNode(!0)).style.top = "0px", i.id = Ext.id(), {
            _fromDesktop: !0,
            ddel: i,
            sourceEl: n.dragEl.dom,
            repairXY: n.dragEl.getXY(),
            SDSShortCut: n.managerItemConfig
        }
    },
    onNodeDropToInsertToGroup: function(t, e, i) {
        var n = this.getItemFromNode(i._fromAppMenu ? i.desktopSrcEl : i.sourceEl);
        n >= 0 ? this.iconItems[n].remove() : SYNO.Debug("Failed to get src node when insert to group"), this.appendSubItemMode = !1
    },
    onNotifyDrop: function(t, e, i) {
        return !(!e.getTarget("#sds-sub-container") && "sds-sub-container-shim" !== e.target.id || (this._creatingVirtualGroup && (this.removeOldDstItem(), this.iconItems[this.backupNode.src.index].remove(), this.updateItemsSetting(), this.refresh(), this.backupNode = null, this._creatingVirtualGroup = !1), this.appendSubItemMode && this.onNodeDropToInsertToGroup(t, e, i), "sds-sub-container-shim" === e.target.id)) || this.onNodeDrop(null, t, e, i)
    },
    onNodeDropSelectedToInsertToGroup: function(t, e, i, n) {
        var s, o = this.getItemFromNode(t),
            r = [];
        if (!(o < 0) && (s = this.iconItems[o]) && !s.isSelected()) return this.isVirtualGroup(s) || (s = this.createNewGroupIcon(o, s, !0)), Ext.each(this.iconItems, function(t, e) {
            var i, n;
            t && t.isSelected() && (n = this.items[e], i = Ext.copyTo({}, n.managerItemConfig ? n.managerItemConfig : n, this.allowedCfgProperty), s.addSubItem(i, !0), r.push(t))
        }, this), Ext.each(r, function(t) {
            t.remove()
        }, this), s.blinkForAdd(), s.refreshElementIcons(), this.refresh(), !0
    },
    createNewGroupIcon: function(t, e, i) {
        var n, s;
        if (!(e < 0) && e) {
            n = {
                className: "SYNO.SDS.VirtualGroup",
                title: "New Group",
                subItems: [Ext.copyTo({}, e.managerItemConfig ? e.managerItemConfig : e, this.allowedCfgProperty)]
            }, s = this.iconItems[t], this.items[t] = n;
            var o = {
                    x: s.li_el.dom.style.left,
                    y: s.li_el.dom.style.top
                },
                r = new SYNO.SDS.LaunchItem(Ext.apply({}, {
                    manager: this,
                    removable: !0,
                    module: this,
                    index: t
                }, n), this.shortcutPanel.getEl());
            return r.li_el.setLeft(o.x), r.li_el.setTop(o.y), r.li_el.addClass.defer(500, r.li_el, ["transition-cls"]), this.iconItems[t] = r, r.managerItemConfig = this.items[t], !0 === i && s.remove(), r
        }
    },
    onNodeDrop: function(t, e, i, n) {
        var s, o, r, a = -1,
            S = n.SDSShortCut;
        if (this.isInSelectState()) return this.onNodeDropSelectedToInsertToGroup(t, e, i, n);
        if (!n._fromFile && (!S || !S.className) || t && t === n.sourceEl) return !1;
        if (t && (a = this.getItemFromNode(t)), this.cancelDeferTask(), n._fromSubContainer && "sds-sub-container-shim" === i.target.id) {
            var l = this.getItemFromSubNode(n.sourceEl),
                c = this.iconItems[l[0]].iconItems[l[1]];
            c && c.remove(), this.addLaunchItem(n.SDSShortCut, -1)
        } else {
            if (n._fromSubContainer && i.getTarget("#sds-sub-container")) {
                var u = this.getItemFromSubNode(t),
                    d = this.getItemFromSubNode(n.sourceEl),
                    h = this.iconItems[u[0]];
                return h.iconItems[u[1]].li_el.show(), h.iconItems[d[1]].li_el.show(), !0
            }
            if ((n._fromDesktop || n._fromAppMenu) && i.getTarget("#sds-sub-container")) return this.onNotifyDrop(e, i, n);
            if (n._fromFile) {
                var p = i.getTarget();
                p && Ext.fly(p).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE) || ((s = this.isNodeDropOnIcon(t, e, i, n)) ? this.isVirtualGroup(s) ? Ext.isArray(n.SDSShortCut) && (Ext.each(n.SDSShortCut, function(t) {
                    var e = Ext.copyTo({}, t.config, this.allowedCfgProperty);
                    s.addSubItem(e, !0)
                }, this), s.blinkForAdd(), s.refreshElementIcons()) : Ext.isArray(n.SDSShortCut) && (r = this.createNewGroupIcon(a, s, !0), Ext.each(n.SDSShortCut, function(t) {
                    var e = Ext.copyTo({}, t.config, this.allowedCfgProperty);
                    r.addSubItem(e, !0)
                }, this), r.blinkForAdd(), r.refreshElementIcons()) : this.addLaunchItems(S, a))
            } else if (n.SDSShortCut && (n._fromControlPanel || n._fromDesktop || n._fromAppMenu)) {
                var g;
                if (s = this.isNodeDropOnIcon(t, e, i, n), n._fromDesktop || n._fromAppMenu) {
                    var f = this.getItemFromNode(n._fromAppMenu ? n.desktopSrcEl : n.sourceEl);
                    g = this.iconItems[f]
                }
                s ? this.isVirtualGroup(g) || (this.isVirtualGroup(s) ? (o = Ext.copyTo({}, n.SDSShortCut, this.allowedCfgProperty), (s = this.iconItems[a]).addSubItem(o, !0), s.blinkForAdd(), s.refreshElementIcons(), (n._fromDesktop || n._fromAppMenu) && g && g.remove()) : g !== s && (o = Ext.copyTo({}, n.SDSShortCut, this.allowedCfgProperty), (r = this.createNewGroupIcon(a, s, !0)).addSubItem(o, !0), r.blinkForAdd(), r.refreshElementIcons(), (n._fromDesktop || n._fromAppMenu) && g && g.remove(), this.refresh())) : n._fromControlPanel && this.addLaunchItem(n.SDSShortCut, a)
            }
        }
        return !0
    },
    isNodeDropOnIcon: function(t, e, i, n) {
        var s, o = -1;
        return t && (o = this.getItemFromNode(t), s = this.getCursorOverType(i.xy, Ext.get(t).getXY())), o >= 0 && s === this.CURSOR_OVER_TYPE.OVER_ICON && this.iconItems[o]
    },
    getItemFromNode: function(t) {
        var e = -1;
        if (t) return Ext.each(this.iconItems, function(i, n) {
            if (i && t === i.dragEl.dom) return e = n, !1
        }), e
    },
    validateItems: function() {
        var t = [],
            e = [];
        Ext.each(this.items, function(e, i) {
            var n = e.className || e.jsID;
            if (!_S("ha_safemode") || -1 != n.search("SYNO.SDS.HA") || -1 != n.search("SYNO.SDS.SupportForm") || -1 != n.search("SYNO.SDS.App.FileStation3"))
                if (this.isVirtualGroup(e)) t.push(e);
                else if (!this.isHiddenControlPanelModule(n, e)) {
                var s = e.needHide;
                SYNO.SDS.Config.FnMap[n] ? e.needHide = !SYNO.SDS.StatusNotifier.isAppEnabled(n) : e.needHide = !0, !0 === s && !1 === e.needHide ? e.needUpdate = !0 : e.needUpdate = !1, t.push(e)
            }
        }, this), this.items = t, SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), Ext.each(this.iconItems, function(t) {
            -1 === this.items.indexOf(t.managerItemConfig) && e.push(t)
        }, this), Ext.each(e, function(t) {
            t.remove()
        }, this), Ext.each(this.iconItems, function(t) {
            this.isVirtualGroup(t) && t.validateItems()
        }, this)
    },
    loadShortcutItems: function() {
        var t = SYNO.SDS.UserSettings.getProperty("Desktop", "ShortcutItems") || this.defShortCuts;
        t = this.removeDeprecatedShortcutItems(t), Ext.each(t, function(t) {
            this.addLaunchItem(t, -1, !0)
        }, this), this.updateTextColor()
    },
    onThirdPartyChanged: function(t, e, i) {
        if ("uninstall" === e) {
            var n = [],
                s = {};
            if (Array.isArray(i) && i.length > 0) {
                for (var o = 0; o < i.length; o++) {
                    s[i[o]] = !0
                }
                for (o = 0; o < this.items.length; o++) {
                    var r = this.items[o];
                    void 0 === s[r.className || r.jsID] && n.push(r)
                }
            }
            this.items = n, SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
        }
    },
    createWallpaper: function() {
        var t = new SYNO.SDS.DesktopStyleParser;
        return Ext.getBody().setStyle({
            backgroundImage: String.format('url("{0}")', t.getDefaultWallpaperPath()),
            backgroundColor: "transparent",
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover"
        }), new SYNO.SDS.Background(Ext.apply(t.getWallpaperCfg({
            wallpaper_path: ""
        }), {
            renderTo: "sds-wallpaper"
        }))
    },
    setBackground: function(t) {
        var e = new SYNO.SDS.DesktopStyleParser;
        this.wallpaper.destroy(), this.wallpaper = new SYNO.SDS.Background(Ext.apply(e.getWallpaperCfg(t), {
            renderTo: "sds-wallpaper"
        }))
    },
    updateTextColor: function(t) {
        var e = Ext.apply({}, SYNO.SDS.UserSettings.getProperty("Desktop", "wallpaper") || {}),
            i = "#FFFFFF";
        t && Ext.apply(e, t, {
            customize_color: !1,
            customize_wallpaper: !1
        }), e.customize_color && (i = e.text_color || "#FFFFFF"), !Ext.isIE9p && Ext.isIE ? (Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text", "color", i), Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text a", "color", i)) : Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text, #sds-desktop li.launch-icon .text a", "color", i)
    },
    onServiceChanged: function(t, e) {
        for (var i = 0; i < this.iconItems.length; i++) this.iconItems[i].className === t && this.refresh()
    },
    addLaunchItemCfg: function(t, e, i) {
        var n = Ext.copyTo({}, t, this.allowedCfgProperty);
        Ext.isNumber(e) && e >= 0 ? this.items.splice(e, 0, n) : this.items.push(n), !0 !== i && SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
    },
    addLaunchItem: function(t, e, i) {
        this.addLaunchItemCfg(t, e, i), this.refresh()
    },
    addLaunchItems: function(t, e) {
        Ext.each(t, function(t) {
            this.addLaunchItemCfg(t.config, e || t.pos, t.skipRegister)
        }, this), this.refresh()
    },
    addHiddenLaunchItem: function(t, e) {
        var i = Ext.copyTo({}, t, this.allowedCfgProperty),
            n = this.items.push(i) - 1;
        return this.refresh(), this.updateItems(), this.iconItems[n].el.hide(), SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), n
    },
    removeLaunchItem: function(t) {
        t.managerItemConfig && (this.iconItems.remove(t), this.items.remove(t.managerItemConfig), SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), this.refresh())
    },
    showHideItems: function(t) {
        this.showIcon = t, Ext.each(this.iconItems, function(e, i) {
            !0 === t ? e.el.show() : e.el.hide()
        }, this)
    },
    refresh: function() {
        this.updateTask.delay(this.updateDelay)
    },
    updateItems: function() {
        var t, e, i = 0,
            n = 0,
            s = this.iconItems.length <= 0;
        this.validateItems(), t = this.shortcutPanel.getEl();
        var o = 0,
            r = this.ICON_WIDTH,
            a = this.ICON_HEIGHT;
        Ext.each(this.items, function(S) {
            var l = o * r,
                c = n * a,
                u = !1;
            s || (e = this.iconItems[i]) && e.managerItemConfig !== S && (e = null), S.needUpdate && (e = this.iconItems[i], e = null, this.iconItems.splice(i, 1)), !s && e && e.li_el || ((e = new SYNO.SDS.LaunchItem(Ext.apply({}, {
                manager: this,
                removable: !0,
                module: this,
                index: i
            }, S), t)).param && e.el.addClass("hide-overflow"), this.iconItems.splice(i, 0, e), e.managerItemConfig = S, u = !0), this.setShortcutVisible(e, S.needHide), S.needHide ? ++i : (c + a > Ext.get("sds-desktop").getHeight() && (l = ++o * r, c = (n = 0) * a), ++i, ++n, this.animShortcutNode(e.li_el, l, c, !u))
        }, this), this.el.getBox().width < this.getTotalIconWidth() && (this.el.setStyle({
            "overflow-x": "scroll"
        }), this.fireEvent("desktopresize", this)), this.isItemUpdated = !0, this.fireEvent("desktopupdated")
    },
    setShortcutVisible: function(t, e) {
        t.el.setVisible(!e);
        var i = t.el.dom.childNodes;
        Ext.each(i, function(t) {
            var i = t.id,
                n = document.getElementById(i);
            n && n.classList.contains("launch-icon") && (n.style.visibility = e ? "hidden" : "visible")
        })
    },
    animShortcutNode: function(t, e, i, n) {
        if (t && t.dom)
            if (Ext.isIE && !t.dom.moving) {
                var s = t.getLeft(),
                    o = t.getTop();
                if (s === e && o === i) return;
                n ? t.shift({
                    left: e,
                    top: i,
                    easing: "easeOut",
                    duration: .5
                }) : t.setLeftTop(e, i)
            } else t.dom.moving || (n || t.removeClass("transition-cls"), t.setStyle("left", e + "px"), t.setStyle("top", i + "px"), t.addClass.defer(100, t, ["transition-cls"]))
    },
    isHiddenControlPanelModule: function(t, e) {
        if ("SYNO.SDS.ControlPanel.Instance" === t) return !0;
        if (!e.param || !e.param.fn) return !1;
        var i = e.param.fn;
        return !(!Ext.isDefined(SYNO.SDS.AppPrivilege[i]) || !1 !== SYNO.SDS.AppPrivilege[i])
    },
    msgBox: null,
    getMsgBox: function() {
        return this.msgBox && !this.msgBox.isDestroyed || (this.msgBox = new SYNO.SDS.MessageBoxV5({
            modal: !0,
            draggable: !1,
            renderTo: document.body
        })), this.msgBox.getWrapper()
    },
    removeDeprecatedShortcutItems: function(t) {
        var e = [];
        return Ext.each(t, function(t) {
            (function(t) {
                if (t.className) {
                    for (var e = ["SYNO.SDS.LogViewer.Application", "SYNO.SDS.App.WelcomeApp.Instance", "SYNO.SDS.SystemInfoApp.Application", "SYNO.SDS.ControlPanel.Instance", "SYNO.SDS.Tutorial.Application"], i = 0; i < e.length; i++) {
                        if (e[i] == t.className) return !0;
                        if ("SYNO.SDS.VirtualGroup" == t.className)
                            for (var n = t.subItems, s = n.length - 1; s >= 0; s--) e[i] == n[s].className && t.subItems.splice(s, 1)
                    }
                    return !1
                }
            })(t) || function(t) {
                return !("SYNO.SDS.AdminCenter.Application" !== t.className || !t.param || !t.param.fn || -1 === ["SYNO.SDS.AdminCenter.WebServices.Main"].indexOf(t.param.fn))
            }(t) || e.push(t)
        }, this), e
    },
    isSubContainerExist: function() {
        return !!Ext.getDom("sds-sub-container")
    },
    setDeferTaskId: function(t) {
        this._deferTaskId = t
    },
    getDeferTaskId: function() {
        return this._deferTaskId
    },
    cancelDeferTask: function() {
        var t = this.getDeferTaskId();
        t > 0 && (window.clearTimeout(t), this.setDeferTaskId(0))
    },
    getSelectedItems: function() {
        var t = [];
        return Ext.each(this.iconItems, function(e) {
            e && e.isSelected() && t.push(e)
        }, this), t
    },
    removeSelectedItems: function() {
        Ext.each(this.getSelectedItems(), function(t) {
            t.setSelected(!1), t.remove()
        }, this)
    },
    deselectItems: function() {
        Ext.each(this.getSelectedItems(), function(t) {
            this.selectItem(t, !1)
        }, this)
    },
    setOldDstItem: function(t) {
        this._oldDstItem && this._oldDstItem.remove(), this._oldDstItem = t
    },
    removeOldDstItem: function(t) {
        this._oldDstItem && this._oldDstItem.remove(), this._oldDstItem = null
    },
    getTotalIconWidth: function() {
        var t = Ext.get("sds-desktop").getHeight(),
            e = Math.floor(t / this.ICON_HEIGHT);
        return 10 + this.ICON_WIDTH * Math.ceil(this.items.length / e)
    }
}), Ext.define("SYNO.SDS.Classical._Desktop", {
    extend: "SYNO.SDS._Desktop",
    ICON_HEIGHT: 100,
    getCursorOverType: function(t, e) {
        var i;
        return t[0] - e[0], (i = t[1] - e[1]) <= 17 ? this.CURSOR_OVER_TYPE.ABOVE_ICON : i >= 64 ? this.CURSOR_OVER_TYPE.BELOW_ICON : this.CURSOR_OVER_TYPE.OVER_ICON
    }
}), Ext.namespace("SYNO.SDS"), _S = function(t) {
    return SYNO.SDS.Session[t]
}, _TT = function(t, e, i) {
    try {
        return SYNO.SDS.Strings[t][e][i]
    } catch (t) {
        return ""
    }
}, Ext.define("SYNO.SDS.DependencyProvider", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        Ext.apply(this, t), this.callParent(arguments)
    },
    resolve: function(t, e) {
        return this.fn ? this.fn.apply(t || window, e || []) : this.className
    }
}), Ext.define("SYNO.SDS._Injector", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.callParent(arguments), this.providers = {}, this.selector = t
    },
    getEnvironment: function() {
        return this.selector
    },
    register: function(t) {
        if (!(Ext.isEmpty(t) || Ext.isEmpty(t.cls) || Ext.isEmpty(t.realCls))) {
            var e = t.cls;
            if (this.selector === t.name) Ext.define(e, {
                extend: t.realCls
            });
            else {
                if (e === t.defaultCls) return;
                Ext.isEmpty(t.defaultCls) || Ext.define(e, {
                    extend: t.defaultCls
                })
            }
        }
    },
    configure: function(t) {
        var e, i, n;
        for (e in {}, t) t.hasOwnProperty(e) && (n = t[e], Ext.isString(n) ? i = new SYNO.SDS.DependencyProvider({
            identifier: e,
            className: n
        }) : Ext.isObject(n) && (i = new SYNO.SDS.DependencyProvider(Ext.apply({
            identifier: e
        }, n))), this.providers[e] = i)
    },
    resolve: function(t, e, i) {
        var n = this.providers[t];
        if (n) return n.resolve(e, i)
    }
}), Ext.define("SYNO.SDS.basic.Themer", {
    extend: "Ext.util.Observable",
    constructor: function() {
        this.callParent(arguments)
    },
    setTheme: function(t, e) {
        this.theme = t, this.themeCls = e, Ext.getBody().addClass(e)
    },
    getTheme: function() {
        return this.theme
    },
    getThemeCls: function() {
        return this.themeCls
    },
    getPath: function(t) {
        var e = arguments.length > 1;
        if (e || Ext.isArray(t)) {
            var i = [];
            return Ext.each(e ? arguments : t, function(t) {
                i.push(this.innerGetPath(t))
            }, this), i
        }
        return this.innerGetPath(t)
    },
    innerGetPath: function(t) {
        return SYNO.SDS.CompatibleMode && !0 === SYNO.SDS.CompatibleMode ? t.replace("default/", "") : t.replace("default/", this.themeCls + "/")
    }
}), Ext.define("SYNO.SDS.DSM.Themer", {
    extend: "SYNO.SDS.basic.Themer",
    statics: {
        BUSINESS: "business",
        DEFAULT: "default"
    },
    defaultThemeCls: "default",
    defaultThemeName: "dsm",
    constructor: function(t) {
        var e = this.defaultThemeCls;
        this.callParent(arguments), SYNO.SDS.DSM.Themer.BUSINESS === t.themeCls && (e = SYNO.SDS.DSM.Themer.BUSINESS), this.setTheme(this.defaultThemeName, e)
    }
}), Ext.define("SYNO.SDS.ESM.Themer", {
    extend: "SYNO.SDS.basic.Themer",
    defaultThemeCls: "business",
    defaultThemeName: "esm",
    constructor: function() {
        this.callParent(arguments), this.setTheme(this.defaultThemeName, this.defaultThemeCls)
    }
}), Ext.define("SYNO.SDS.interval.Task", {
    extend: "Ext.Component",
    constructor: function() {
        this.callParent(arguments), _S("isLogined") && this.getTimeout()
    },
    stopPollingTask: function() {
        this.pollTask && this.pollUnreg(this.pollTask)
    },
    startPollingTask: function() {
        var t = this,
            e = {
                interval: 60,
                webapi: {
                    api: "SYNO.Core.Desktop.Timeout",
                    version: 1,
                    method: "check"
                },
                scope: t,
                status_callback: t.handleResponese
            };
        t.stopPollingTask(), t.pollTask = t.pollReg(e), t.mon(SYNO.SDS.StatusNotifier, "halt", function() {
            this.pollUnreg(this.pollTask)
        }, t)
    },
    handleResponese: function(t, e, i, n) {},
    delayGetTimeOut: function() {
        this.getTimeout.defer(6e4, this)
    },
    getTimeout: function() {
        var t = {
            api: "SYNO.Core.Desktop.Timeout",
            method: "get",
            version: 1,
            params: {}
        };
        this.sendWebAPI({
            api: t.api,
            version: t.version,
            method: t.method,
            params: t.params,
            scope: this,
            callback: function(t, e, i, n) {
                t && Ext.isNumber(e.timeout) && e.timeout > 0 ? (this.intervalTime = e.timeout, this.startPollingTask()) : this.delayGetTimeOut()
            }
        })
    }
}), SYNO.SDS.iFrameAppToFront = function(t) {
    var e = SYNO.SDS.AppMgr.getByAppName(t);
    e.length && Ext.each(e, function(t) {
        if (t.window) return t.window.toFront(), !1
    })
}, SYNO.SDS.restoreLogoutTrigger = function() {
    SYNO.SDS.Utils.Logout.logoutTriggered = !1
}, SYNO.SDS.isCompatibleMode = function() {
    for (var t = document.getElementsByTagName("script"), e = 0; e < t.length; e++) {
        if (t[e].src.indexOf("compatible-6.x") >= 0) return !0
    }
    return !1
}, SYNO.SDS.onBasicBeforeUnload = function() {
    var t, e;
    if (Ext.isChrome && SYNO.SDS.DragToDesktop.destroy(), !_S("standalone") && (t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.WelcomeApp.Instance")) && t[0] && !t[0].window.canReload()) return _T("welcome", "unload_hint");
    if (!_S("standalone") && (t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.PkgManApp.Instance")) && t[0] && t[0].window.isUpdating()) return _T("pkgmgr", "close_updateall_confirm");
    if ((t = _S("standalone") ? SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance") : SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")) && t[0]) {
        e = _S("standalone") ? t[0].window.panelObj.monitorPanel : t[0].window;
        var i = "",
            n = _S("standalone") ? _T("tree", "leaf_filebrowser") : _D("os_name") || "DSM";
        if (e.uploadGrid.isProcessing() ? i += String.format(_T("filebrowser", "upload_confirm_unload"), n) : e.localGrid.isProcessing() ? i += String.format(_T("filebrowser", "local_confirm_unload"), n) : e.downloadGrid.isProcessing() && (i += String.format(_T("filebrowser", "download_confirm_unload"), n)), "" !== i) return SYNO.SDS.restoreLogoutTrigger.defer(10), i
    }
}, SYNO.SDS.getMsgBeforeUnload = function() {
    var t = SYNO.SDS.onBasicBeforeUnload();
    return !1 === SYNO.SDS.StatusNotifier.fireEvent("beforeunload") ? (SYNO.SDS.restoreLogoutTrigger.defer(10), _T("desktop", "confirm_leave")) : t ? (SYNO.SDS.restoreLogoutTrigger.defer(10), t) : void 0
}, SYNO.SDS.onBeforeUnload = function() {
    var t = _S("standalone") ? SYNO.SDS.Config.FnMap[_S("standaloneAppName")] : null,
        e = t && t.config ? SYNO.SDS.Utils.GetLocalizedString(t.config.title, t.config.jsID) : _D("os_name") || "DSM";
    return SYNO.SDS.getMsgBeforeUnload() || (!1 === SYNO.SDS.UserSettings.getProperty("Desktop", "disableLogoutConfirm") ? String.format(_T("desktop", "confirm_unload"), e) : void 0)
}, SYNO.SDS.onBeforeUnloadForApplication = function() {
    return SYNO.SDS.getMsgBeforeUnload()
}, SYNO.SDS.initData = function(t) {
    var e, i = Ext.urlDecode(window.location.search.substr(1));
    if (Ext.isNumber(t) && t > 0) SYNO.SDS.initData.defer(t, this);
    else {
        SYNO.SDS.CompatibleMode = SYNO.SDS.isCompatibleMode(), SYNO.SDS.InitUtils.handleServerError();
        var n = i.launchApp;
        !n && SYNO.SDS.Session && (n = SYNO.SDS.Session.rewriteApp), e = i.jsDebug ? {
            action: "debug",
            launch_app: n
        } : {
            launch_app: n
        };
        SYNO.SDS.InitUtils.initAPIManagerPromise().then(function() {
            return SYNO.SDS.InitUtils.fetchSYNODEFS()
        }).then(function() {
            return Promise.all([new Promise(function(t, i) {
                return SYNO.API.Request({
                    api: "SYNO.Core.Desktop.Initdata",
                    method: "get",
                    params: e,
                    version: 1,
                    callback: function(e, n, s, o) {
                        e ? t(n) : i(e, n)
                    }
                })
            }), (SYNO.SDS.Packages = new SYNO.SDS._Packages, SYNO.SDS.Packages.getData())])
        }).then(function(t) {
            t = t[0];
            var e = 1;

            function n() {
                0 === (e -= 1) && (Ext.isDefined(window._loadSynoLang) && window._loadSynoLang(), t.Session.SynoToken = _S("SynoToken"), SYNO.SDS.Session = t.Session, SYNO.SDS.Config.JSConfig = t.JSConfig, SYNO.SDS.Strings = t.Strings, SYNO.SDS.initUserSettings = t.UserSettings, SYNO.SDS.initGroupSettings = t.GroupSettings, SYNO.SDS.UrlTag = t.UrlTag, SYNO.SDS.AppPrivilege = t.AppPrivilege, SYNO.SDS.ServiceStatus = t.ServiceStatus, SYNO.SDS.UIFeatures.IconSizeManager.enableHDDisplay(t.SynohdpackStatus || !0), SYNO.SDS.init(), window.loginLang && _S("lang") !== window.loginLang && (Ext.form.VTypes.reloadVtypeStr(), SYNO.API.AssignErrorStr(), SYNO.SDS.Utils.StorageUtils.UiRenderHelper = SYNO.SDS.Utils.StorageUtils.UiRenderHelperInitializer(), SYNO.SDS.Relay.GetRelaydStatusStr = SYNO.SDS.Relay.GenRelaydStatusStr()), SYNO.SDS.appendMissingCSSFiles(t.CSSFiles), SYNO.SDS.InitUtils.removeForm())
            }
            var s = Ext.get(document.documentElement);
            switch (t.Session.lang) {
                case "cht":
                    s.set({
                        lang: "zh-Hant"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "chs":
                    s.set({
                        lang: "zh-Hans"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "jpn":
                    s.set({
                        lang: "ja"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "krn":
                    s.set({
                        lang: "ko"
                    }), Ext.getBody().addClass("syno-cjk")
            }
            var o = i.launchApp;
            !0 !== t.Session.is_admin || t.Session.rewriteApp || o ? window.loginLang && t.Session.lang !== window.loginLang ? SYNO.SDS.Utils.loadUIStrings(t.Session.lang, t.Session.fullversion, n) : n() : (e += 1, window.loginLang && t.Session.lang !== window.loginLang ? SYNO.SDS.Utils.loadUIStrings(t.Session.lang, t.Session.fullversion, n) : n(), SYNO.API.Request({
                api: "SYNO.Core.QuickStart.Info",
                method: "load_ds_info",
                version: 2,
                callback: function(e, i, s, o) {
                    if (!e) return t.Session.qckFailed = !0, void n();
                    Ext.isObject(i) && (Ext.copyTo(t.Session, i, ["welcome_hide", "admin_configured", "myds_unified", "found_myds_account", "udc_check_state", "udc_enabled"]), i.vol_path && (t.Session.vol_path = i.vol_path), t.Session.myds_region_api_base_url = i.myds_region_api_base_url), n()
                }
            }))
        }).catch(function(t) {
            SYNO.Debug("Failed to fetch DSM defs scripts", t), SYNO.SDS.initData(3e3)
        })
    }
}, SYNO.SDS.filterStandaloneCSSFiles = function(t) {
    if (!_S("standalone")) return t;
    var e, i, n, s, o = _S("standaloneAppName"),
        r = SYNO.SDS.Config.FnMap,
        a = [],
        S = function(e) {
            Ext.each(t, function(t) {
                if (t.indexOf(e) >= 0) return a.push(t), !1
            })
        };
    return (e = r[o] ? r[o].config : null) && (s = e.white_pkg_list) ? (Ext.each(s, function(t) {
        (i = r[t] ? r[t].config : null) && (n = i.jsBaseURL, S(n))
    }), S(e.jsBaseURL), a) : t
}, SYNO.SDS.appendMissingCSSFiles = function(t) {
    var e = -1,
        i = "";
    t = SYNO.SDS.filterStandaloneCSSFiles(t), Ext.each(t, function(t) {
        var n = !1,
            s = function(t) {
                var e = document.createElement("link");
                e.setAttribute("rel", "stylesheet"), e.setAttribute("type", "text/css"), e.setAttribute("href", t), document.getElementsByTagName("head")[0].appendChild(e)
            };
        if (0 !== t.indexOf("webman/3rdparty/")) return Ext.each(document.getElementsByTagName("style"), function(e) {
            if (e.innerHTML.indexOf(t) >= 0) return n = !0, !1
        }), void(n || (Ext.each(document.getElementsByTagName("style"), function(e) {
            var i = t.substr(0, t.indexOf("?v=")),
                n = new RegExp('@import url\\("' + i + '\\?v=[^"]+"\\);(\\n)?');
            e.innerHTML.indexOf(i) >= 0 && (e.innerHTML = e.innerHTML.replace(n, ""))
        }), s(t)));
        Ext.each(document.getElementsByTagName("link"), function(e) {
            if (0 < e.href.indexOf(t)) return n = !0, !1
        }), n || (! function(t) {
            Ext.each(document.getElementsByTagName("link"), function(n) {
                if (-1 !== (e = t.indexOf("?")) && (i = t.substring(0, e), 0 < n.href.indexOf(i))) return n.parentNode.removeChild(n), !1
            })
        }(t), s(t))
    })
}, SYNO.SDS.AutoLaunch = function() {
    var t = function(t, e) {
        var i, n = (SYNO.SDS.Config.FnMap[t] && SYNO.SDS.Config.FnMap[t].config ? SYNO.SDS.Config.FnMap[t].config : {}).canLaunch;
        if (Ext.isObject(n))
            for (i in n)
                if (!!_S(i) !== n[i]) return;
        0 === SYNO.SDS.AppMgr.getByAppName(t).length && SYNO.SDS.AppLaunch(t, {}, !1, e)
    };
    SYNO.SDS.Config.AutoLaunchFnList.each(function(e) {
        Ext.isObject(e) ? t(e.dependName, t.createDelegate(this, [e.appName])) : t(e)
    })
}, SYNO.SDS.reloadJSConfig = function(t) {
    if (Ext.isNumber(t) && t > 0) SYNO.SDS.reloadJSConfig.defer(t, this);
    else {
        var e = Ext.urlDecode(location.search.substr(1));
        SYNO.API.Request({
            api: "SYNO.Core.Desktop.Initdata",
            method: "get",
            version: 1,
            params: {
                action: "jsconfig",
                launch_app: e.launchApp
            },
            callback: function(t, e, i, n) {
                if (!t) return SYNO.Debug("SYNO.SDS.reloadJSConfig fail", arguments), void SYNO.SDS.reloadJSConfig(3e3);
                var s;
                SYNO.SDS.Config.JSConfig = e.JSConfig, SYNO.SDS.Strings = e.Strings, SYNO.SDS.ServiceStatus = e.ServiceStatus, SYNO.SDS.AppPrivilege = e.AppPrivilege, SYNO.SDS.UrlTag = e.UrlTag, SYNO.SDS.JSLoad.init(), SYNO.SDS.AppView.refresh(), SYNO.SDS.Desktop.refresh(), SYNO.SDS.appendMissingCSSFiles(e.CSSFiles), s = [], SYNO.SDS.AppMgr.each(function(t) {
                    var e = t.jsConfig.jsID;
                    Ext.isDefined(SYNO.SDS.Config.FnMap[e]) || s.push(t)
                }), Ext.invoke(s, "destroy"), SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("jsconfigLoaded"), SYNO.SDS.AutoLaunch()
            }
        }), SYNO.API.currentManager || (SYNO.API.currentManager = new SYNO.API.Manager), SYNO.API.currentManager.queryAPI("all")
    }
}, SYNO.SDS.CheckAndNotifySecurityAdvisor = function() {
    SYNO.API.Request({
        api: "SYNO.Core.SecurityScan.Conf",
        method: "first_get",
        version: 1,
        callback: function(t, e) {
            if (!t || e.firstLogAnalyzer || e.firstScan) {
                var i = String.format(_T("desktop", "notify_security_advisor"), '<a data-syno-app="SYNO.SDS.SecurityScan.Instance">', "</a>");
                SYNO.SDS.SystemTray.notifyMsg(null, _T("helptoc", "securityscan"), i, 0, !1)
            }
        },
        scope: this
    })
}, SYNO.SDS.CheckAndNotifyPackageStarting = function() {
    SYNO.API.Request({
        api: "SYNO.Core.Package",
        method: "list",
        version: 2,
        params: {
            additional: ["status"]
        },
        callback: function(t, e) {
            var i = e.packages;
            if (t && void 0 !== i)
                for (var n = {
                        installing: !0,
                        starting: !0,
                        upgrading: !0,
                        repairing: !0
                    }, s = 0; s < i.length; s++) {
                    var o = i[s].additional;
                    if (void 0 !== o && void 0 !== o.status && !0 === n[o.status]) {
                        var r = _T("notification", "pkg_still_enabling_title"),
                            a = _T("notification", "pkg_still_enabling_info");
                        return void SYNO.SDS.SystemTray.notifyMsg(null, r, a, 0, !0)
                    }
                }
        }
    })
}, SYNO.SDS.autoStart = function() {
    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "restoreParams") || [],
        e = SYNO.SDS.UserSettings.getLocalStorageRestoreParams();
    !Ext.isEmpty(e) && SYNO.SDS.UserSettings.getProperty("Desktop", "rememberWindowState") && (t = e), _S("is_admin") && (_S("welcome_hide") || (SYNO.SDS.CheckAndNotifySecurityAdvisor(), SYNO.API.Request({
        api: "SYNO.Core.QuickStart.Info",
        method: "hide_welcome",
        version: 1,
        callback: Ext.emptyFn
    })), !0 === SYNO.SDS.Session.admin_first_login_after_upgrade && (SYNO.SDS.CheckAndNotifyPackageStarting(), SYNO.SDS.CheckAndNotifySecurityAdvisor())), SYNO.SDS.AutoLaunch(), Ext.each(t, function(t) {
        SYNO.SDS.AppLaunch(t.className, Ext.apply({
            fromRestore: !0
        }, t.params), !0)
    }), SYNO.SDS.UserSettings.removeProperty("Desktop", "restoreParams"), SYNO.SDS.UserSettings.removeLocalStorageRestoreParams()
}, SYNO.SDS.CheckBadge = function() {
    ! function() {
        SYNO.API.Request({
            compound: {
                api: "SYNO.Entry.Request",
                version: 1,
                method: "request",
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.Core.Upgrade.Server",
                    method: "check",
                    version: 1,
                    params: {
                        need_auto_smallupdate: !0
                    }
                }, {
                    api: "SYNO.Core.Package.Server",
                    method: "check",
                    version: 1
                }]
            },
            scope: this,
            callback: Ext.emptyFn
        })
    }()
}, SYNO.SDS.init = function() {
    var t, e, i = Ext.urlDecode(location.search.substr(1)),
        n = i.launchApp,
        s = i.launchParam,
        o = i.jsDebug,
        r = i.report,
        a = SYNO.SDS.Session.rewriteApp,
        S = Ext.id();
    if (Ext.isDefined(r)) window.location = Ext.urlAppend(r);
    else {
        Ext.isDefined(o) && (SYNO.SDS.JSDebug = o), SYNO.SDS.initFramework();
        var l = SYNO.SDS.Config.FnMap[n],
            c = !1;
        if (l && l.config) {
            var u = l.config;
            "standalone" !== u.type && !0 !== u.allowStandalone && "url" !== u.type && "legacy" !== u.type || (c = !0)
        }
        if (c) SYNO.SDS.StatusNotifier.isAppEnabled(n) ? SYNO.SDS.initStandaloneDesktop(n, s) : window.location = "/";
        else if (a) {
            if (!SYNO.SDS.StatusNotifier.isAppEnabled(a)) return SYNO.SDS.StatusNotifier.fireEvent("logout"), window.alert(_JSLIBSTR("uicommon", "error_noprivilege")), void SYNO.SDS.Utils.Logout.action(!0);
            SYNO.SDS.Session.rewrite_mode = !0, SYNO.SDS.initStandaloneDesktop(a, s)
        } else {
            if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.Desktop")) return SYNO.SDS.StatusNotifier.fireEvent("logout"), window.alert(_JSLIBSTR("uicommon", "error_noprivilege")), void SYNO.SDS.Utils.Logout.action(!0);
            SYNO.SDS.initDesktop(n), SYNO.SDS.StatusNotifier.isAppEnabled(n) && SYNO.SDS.AppLaunch(n, s), window.Notification && SYNO.SDS.UserSettings.getProperty("Desktop", "enableDesktopNotification") && "default" === window.Notification.permission && (t = String.format('<span id={0} class="blue-status" style="cursor:pointer;">{1}</span>', S, _T("common", "here")), t = String.format(_T("common", "click_to_enable_notification"), t), e = SYNO.SDS.SystemTray.notifyMsg("", _T("common", "desktop"), t, 0, !1), Ext.get(S).on("click", function() {
                window.Notification.requestPermission(function(t) {
                    window.Notification.permission = t
                }), e.close()
            })), _S("is_admin") && SYNO.SDS.CheckBadge()
        }
        SYNO.SDS.GetExternalIP(), SYNO.SDS.initAccesibilityPlugin(), SYNO.SDS.HandleTimeoutTask = new SYNO.SDS.interval.Task
    }
}, SYNO.SDS.initAccesibilityPlugin = function() {
    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "disableAccessibility") || !1;
    setARIAPluginsDisabled(t)
}, SYNO.SDS.initFramework = function() {
    var t = Ext.getCmp("sds-login");
    if (t && t.el.fadeOut({
            callback: function() {
                t.destroy()
            }
        }), SYNO.SDS.LaunchTime = (new Date).getTime(), SYNO.SDS.JSLoad.init(), SYNO.SDS.StatusNotifier = new SYNO.SDS._StatusNotifier({}), SYNO.SDS.UserSettings = new SYNO.SDS._UserSettings, SYNO.SDS.GroupSettings = new SYNO.SDS._GroupSettings, SYNO.SDS.WindowMgr = new SYNO.SDS._WindowMgr, SYNO.SDS.FocusMgr = new SYNO.SDS._FocusMgr, SYNO.SDS.AppMgr = new SYNO.SDS._AppMgr, SYNO.SDS.GestureMgr = new SYNO.SDS._GestureMgr, SYNO.SDS.Injector = new SYNO.SDS._Injector(SYNO.SDS.Environment.GetEnvironment()), SYNO.SDS.Injector.configure({
            getDesktopClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classical._Desktop" : "SYNO.SDS._Desktop"
                }
            },
            getLaunchItemClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classical._LaunchItem" : "SYNO.SDS._LaunchItem"
                }
            },
            getAppMenuClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "appMenuStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classic._AppView" : "SYNO.SDS._AppView"
                }
            }
        }), SYNO.SDS._ActiveDesktop = Ext.getClassByName(SYNO.SDS.Injector.resolve("getDesktopClass")), SYNO.SDS.LaunchItem = Ext.getClassByName(SYNO.SDS.Injector.resolve("getLaunchItemClass")), SYNO.SDS._ActiveMenu = Ext.getClassByName(SYNO.SDS.Injector.resolve("getAppMenuClass")), SYNO.SDS.Injector.register({
            name: SYNO.SDS.Environment.ESM,
            cls: "SYNO.SDS.Themer",
            realCls: "SYNO.SDS.DSM.Themer",
            defaultCls: "SYNO.SDS.DSM.Themer"
        }), SYNO.SDS.ThemeProvider = new SYNO.SDS.Themer({
            themeCls: _S("theme_cls")
        }), Ext.isDefined(SYNO.SDS.JSDebug) && (SYNO.Debug("JS Loading Caching Disabled. (append _dc to js link)"), "all" === SYNO.SDS.JSDebug)) {
        var e = SYNO.SDS.Config.FnMap;
        for (var i in SYNO.Debug("JS Dynamic Loading Disabled."), e) e.hasOwnProperty(i) && SYNO.SDS.JSLoad(i)
    }
}, SYNO.SDS.initStandaloneDesktop = function(t, e) {
    _S("isLogined") && (SYNO.SDS.BackgroundTaskMgr = new SYNO.SDS._BackgroundTaskMgr, SYNO.SDS.UploadTaskMgr = new SYNO.SDS._UploadBackgroundTaskMgr, SYNO.SDS.MailTaskMgr = new SYNO.SDS._MailBackgroundTaskMgr, SYNO.SDS.SystemTray = new SYNO.SDS._SystemTray), SYNO.SDS.Session.standalone = !0, SYNO.SDS.Session.standaloneAppName = t, SYNO.SDS.Desktop = new SYNO.SDS._StandaloneDesktop, SYNO.SDS.AppLaunch(t, e), window.onbeforeunload = SYNO.SDS.onBeforeUnload, SYNO.SDS.DestroyLoginInstance && SYNO.SDS.DestroyLoginInstance()
}, SYNO.SDS.HideDesktop = function() {
    SYNO.SDS.TaskBar.hide(), SYNO.SDS.Desktop.hide(), Ext.get("sds-taskbar-shadow").hide()
}, SYNO.SDS.ShowDesktop = function() {
    var t = Ext.fly("sds-wallpaper");
    t.dom && t.dom.src && Ext.fly("sds-wallpaper").show(), SYNO.SDS.Desktop.show(), SYNO.SDS.TaskBar.show(), Ext.get("sds-taskbar-shadow").show()
}, Ext.define("SYNO.SDS.LaunchFullSizeApps", {
    statics: {
        appList: ["SYNO.SDS.App.WelcomeApp.Instance", "SYNO.SDS.UDC.Instance", "SYNO.SDS.App.WelcomeTip.Instance"],
        index: 0,
        start: function() {
            if (this.index < this.appList.length) return SYNO.SDS.AppLaunch(this.appList[this.index], {}, !1), void this.index++;
            this.index === this.appList.length && (SYNO.SDS.ShowDesktop(), SYNO.SDS.autoStart())
        }
    }
}), SYNO.SDS.initDesktop = function(t) {
    var e = !t && !_S("qckFailed") && _S("is_admin");
    SYNO.SDS.BackgroundTaskMgr = new SYNO.SDS._BackgroundTaskMgr, SYNO.SDS.UploadTaskMgr = new SYNO.SDS._UploadBackgroundTaskMgr, SYNO.SDS.PackageTaskMgr = new SYNO.SDS._PackageBackgroundTaskMgr, SYNO.SDS.MailTaskMgr = new SYNO.SDS._MailBackgroundTaskMgr, SYNO.SDS.DeskTopManager = new SYNO.SDS._DeskTopManager, SYNO.SDS.TaskBar = new SYNO.SDS._TaskBar, SYNO.SDS.TaskButtons = Ext.getCmp("sds-taskbuttons-panel"), SYNO.SDS.SystemTray = Ext.getCmp("sds-tray-panel"), SYNO.SDS.Desktop = new SYNO.SDS._ActiveDesktop, SYNO.SDS.AppView = new SYNO.SDS._ActiveMenu, SYNO.SDS.System = new SYNO.SDS._System, !1 !== SYNO.SDS.Session.boot_done ? (e && (SYNO.SDS.LaunchFullSizeApps.start(), SYNO.SDS.HideDesktop()), SYNO.SDS.PreviewBox = new SYNO.SDS._PreviewBox, window.onbeforeunload = SYNO.SDS.onBeforeUnload, SYNO.SDS.StatusNotifier.on("thirdpartychanged", SYNO.SDS.reloadJSConfig), SYNO.SDS.StatusNotifier.on("halt", function() {
        var t = Ext.getClassByName("SYNO.API.Request.Polling.Instance");
        SYNO.SDS.TaskMgr.setHalt(!0), Ext.isObject(t) && Ext.isFunction(t.endPolling) && t.endPolling("halt")
    }), SYNO.SDS.StatusNotifier.on("resumehalt", function() {
        var t = Ext.getClassByName("SYNO.API.Request.Polling.Instance");
        SYNO.SDS.TaskMgr.setHalt(!1), Ext.isObject(t) && Ext.isFunction(t.beginPolling) && t.beginPolling("halt")
    }), e ? SYNO.SDS.StatusNotifier.on("fullsizeappdestroy", function() {
        SYNO.SDS.LaunchFullSizeApps.start()
    }) : SYNO.SDS.autoStart()) : SYNO.SDS.System.WaitForBootUp()
}, SYNO.SDS.DragToDesktop = function() {
    var t = !1,
        e = [".syno-sds-fs-win", ".welcomedragable-url"],
        i = function(t) {
            var i = !1;
            Ext.each(e, function(e) {
                if (t.within(t.getTarget(e))) return i = !0, !1
            }, this), i || t.preventDefault()
        },
        n = function(t) {
            t.preventDefault();
            var e = this.timeStamp || (this.timeStamp = t.browserEvent.timeStamp);
            Math.abs(t.browserEvent.timeStamp - e) < 100 || (this.timeStamp = t.browserEvent.timeStamp, this.handleMouseMove(t))
        },
        s = function(t) {
            this.handleMouseUp(t), t.stopPropagation(), t.preventDefault()
        },
        o = function(t) {
            this.dragCurrent && this.handleMouseUp.defer(150, this, [t])
        },
        r = function(t) {
            t.preventDefault()
        };
    return {
        init: function() {
            Ext.dd.DragDropMgr.preventDefault = !1, Ext.EventManager.on(document, "dragstart", i, this, !0), Ext.EventManager.on(document, "dragenter", r, Ext.dd.DragDropMgr, !0), Ext.EventManager.on(document, "dragover", n, Ext.dd.DragDropMgr, !0), Ext.EventManager.on(document, "drop", s, Ext.dd.DragDropMgr, {
                preventDefault: !0
            }), Ext.EventManager.on(document, "dragend", o, Ext.dd.DragDropMgr, !0), t = !0
        },
        destroy: function() {
            Ext.dd.DragDropMgr.preventDefault = !0, Ext.EventManager.un(document, "dragstart", i, this, !0), Ext.EventManager.un(document, "dragover", n, Ext.dd.DragDropMgr, !0), Ext.EventManager.un(document, "dragenter", r, Ext.dd.DragDropMgr, !0), Ext.EventManager.un(document, "drop", s, Ext.dd.DragDropMgr), Ext.EventManager.un(document, "dragend", o, Ext.dd.DragDropMgr), t = !1
        },
        isEnable: function() {
            return t
        }
    }
}(), Ext.namespace("SYNO.SDS"), SYNO.SDS.GetExternalIP = function() {
    _S("isLogined") && SYNO.API.Request({
        api: "SYNO.Core.Desktop.Initdata",
        method: "get",
        version: 1,
        params: {
            action: "external_ip"
        },
        callback: function(t, e, i, n) {
            t ? (SYNO.SDS.Session.external_ip = e.external_ip, SYNO.SDS.Session.ddns_hostname = e.ddns_hostname) : SYNO.Debug("SYNO.SDS.GetExternalIP fail", arguments)
        }
    })
}, SYNO.SDS.HTML5Utils = function() {
    var t = window.XMLHttpRequest ? new XMLHttpRequest : {};
    return {
        HTML5Progress: !!t.upload,
        HTML5SendBinary: !(!t.sendAsBinary && !t.upload),
        HTML5ReadBinary: !!(window.FileReader || window.File && window.File.prototype.getAsBinary),
        HTML5Slice: !(!window.File || !(window.File.prototype.slice || window.File.prototype.mozSlice || window.File.prototype.webkitSlice)),
        isSupportHTML5Upload: function() {
            return (Ext.isChrome || !Ext.isSafari4 && !Ext.isSafari5_0 && !(Ext.isWindows && Ext.isSafari) && !Ext.isGecko3 && !Ext.isOpera) && (!!window.FormData || SYNO.SDS.HTML5Utils.HTML5SendBinary && SYNO.SDS.HTML5Utils.HTML5ReadBinary && SYNO.SDS.HTML5Utils.HTML5Slice)
        },
        isDragFile: function(t) {
            try {
                if (Ext.isWebKit) return t.dataTransfer.types && -1 != t.dataTransfer.types.indexOf("Files");
                if (Ext.isGecko) return t.dataTransfer.types.contains && t.dataTransfer.types.contains("application/x-moz-file") || 0 <= t.dataTransfer.types.indexOf("application/x-moz-file");
                if (Ext.isIE10 || Ext.isModernIE) return t.dataTransfer.files && t.dataTransfer.types && t.dataTransfer.types.contains("Files")
            } catch (t) {
                SYNO.Debug.error("Error in isDragFile")
            }
            return !1
        }
    }
}(), SYNO.SDS.SSOUtils = function() {
    return {
        callbackFn: {
            fn: Ext.emptyFn,
            scope: this
        },
        setCallback: function(t, e) {
            this.callbackFn.fn = t, Ext.isDefined(e) && (this.callbackFn.scope = e)
        },
        isSupport: function() {
            return _S("sso_support") && _S("sso_server") && _S("sso_appid") && "SYNOSSO" in window && Ext.isFunction(SYNOSSO.init)
        },
        init: function(t, e) {
            if (this.isSupport()) {
                this.setCallback(t, e);
                try {
                    SYNOSSO.init({
                        oauthserver_url: _S("sso_server"),
                        app_id: _S("sso_appid"),
                        redirect_uri: document.URL,
                        callback: this.callback.createDelegate(this)
                    })
                } catch (t) {}
            }
        },
        callback: function(t) {
            SYNOSSO.status = t.status, this.callbackFn.fn.call(this.callbackFn.scope, t)
        },
        login: function(t, e) {
            this.setCallback(t, e), SYNOSSO.login()
        },
        logout: function(t, e) {
            e && t.createDelegate(e), "sso" === (Ext.util.Cookies.get("login_type") || "sso") && SYNOSSO.logout(t)
        }
    }
}(), SYNO.SDS.AzureSSOUtils = function() {
    var t = screen.width / 2 - 250,
        e = screen.height / 2 - 300,
        i = String.format("height={0},width={1},left={2},top={3}", 600, 500, t, e);
    return {
        login: function(t, e) {
            var n = function(i) {
                    t(e, i)
                }.createDelegate(this),
                s = _S("dsm_https_port"),
                o = Ext.urlEncode({
                    action: "signin",
                    method: "azure_oidc",
                    origin: location.origin
                }),
                r = "https://" + location.hostname + ":" + s + "/webman/index.cgi?" + o;
            window.addEventListener("message", n), window.open(r, "OIDC", i)
        },
        logout: function() {
            var t = "webman/logout.cgi?" + Ext.urlEncode({
                asso: "true"
            });
            window.open(t, "OIDC", i)
        }
    }
}(), SYNO.SDS.WebSphereSSOUtils = function() {
    var t = screen.width / 2 - 250,
        e = screen.height / 2 - 300,
        i = String.format("height={0},width={1},left={2},top={3}", 600, 500, t, e);
    return {
        login: function(t, e) {
            var n = function(i) {
                    t(e, i)
                }.createDelegate(this),
                s = _S("dsm_https_port"),
                o = Ext.urlEncode({
                    action: "signin",
                    method: "websphere_oidc",
                    origin: location.origin
                }),
                r = "https://" + location.hostname + ":" + s + "/webman/index.cgi?" + o;
            window.addEventListener("message", n), window.open(r, "OIDC", i)
        },
        logout: function() {
            var t = "webman/logout.cgi?" + Ext.urlEncode({
                webspheresso: "true"
            });
            window.open(t, "OIDC", i)
        }
    }
}(), Ext.define("SYNO.SDS.IEUpgradeAlert", {
    extend: "SYNO.SDS.Window",
    constructor: function() {
        var t = {
            cls: "ie-upgrade-alert",
            width: 450,
            height: 230,
            maximizable: !1,
            title: _D("manager"),
            items: [{
                xtype: "syno_formpanel",
                name: "ie_alert_form",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("desktop", "upgrade_ie_browser")
                }, {
                    name: "skip_alert",
                    xtype: "syno_checkbox",
                    checked: !1,
                    boxLabel: _T("common", "dont_alert_again")
                }]
            }],
            fbar: {
                toolbarCls: "x-panel-fbar x-statusbar",
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: function() {
                        var t = this.find("name", "skip_alert")[0],
                            e = new Date;
                        !0 === t.getValue() && Ext.util.Cookies.set("skip_upgrade_ie_alert", !0, e.add(Date.YEAR, 1)), this.close()
                    },
                    scope: this
                }]
            }
        };
        this.callParent([t])
    }
}), Ext.define("SYNO.SDS.InitUtils", {
    singleton: !0,
    checkTargetSelectable: function(t) {
        if (t.getTarget(".selectabletext")) return !0;
        if (t.getTarget("textarea")) return !0;
        var e = t.getTarget("input"),
            i = e && e.type ? e.type.toLowerCase() : "";
        return ("text" === i || "textarea" === i || "password" === i) && !e.readOnly
    },
    checkTargetTextFiledorTextArea: function(t) {
        var e = t.getTarget("input"),
            i = e && e.type ? e.type.toLowerCase() : "";
        return !!t.getTarget("textarea") || ("text" === i || "password" === i)
    },
    hideForms: function() {
        var t = Ext.get("sds-login-dialog-form"),
            e = Ext.get("sds-apply-preview-form");
        return t && t.setStyle("display", "none"), e && e.setStyle("display", "none"), this
    },
    removeForm: function() {
        var t = Ext.get("sds-login-dialog-form");
        return t && t.remove(), this
    },
    initQuickTips: function() {
        return Ext.QuickTips.init(), Ext.isIE9m && !Ext.isIE9 || Ext.QuickTips.getQuickTip().getEl().disableShadow(), this
    },
    initDragDrop: function() {
        return Ext.dd.DragDropMgr.stopPropagation = !1, Ext.dd.DragDropMgr.clickTimeThresh = -1, Ext.WindowMgr.zseed = 12e3, this
    },
    disableIESelect: function() {
        return Ext.isIE && Ext.getDoc().on("selectstart", function(t) {
            this.checkTargetSelectable(t) || t.stopEvent()
        }, this), this
    },
    disableSelectAllKeyboard: function() {
        return Ext.getDoc().on("keydown", function(t) {
            t.ctrlKey && t.A === t.getKey() && !this.checkTargetSelectable(t) && t.stopEvent();
            var e, i = SYNO.SDS.WindowMgr,
                n = i ? i.getActiveAppWindow() : null;
            n && (e = n.appInstance), e && e.jsConfig && !0 != !e.jsConfig.allowBackspace || t.BACKSPACE !== t.getKey() || this.checkTargetTextFiledorTextArea(t) || t.preventDefault(), Ext.isIE && t.ESC === t.getKey() && this.checkTargetTextFiledorTextArea(t) && t.preventDefault()
        }, this), this
    },
    disableRightClick: function() {
        return Ext.getBody().on("contextmenu", function(t) {
            this.checkTargetSelectable(t) || t.getTarget(".allowDefCtxMenu") || t.stopEvent()
        }, this), this
    },
    handleServerError: function() {
        return Ext.Ajax.on("requestcomplete", function(t, e, i) {
            try {
                SYNO.SDS.Utils.CheckServerError(e) && (t.purgeListeners(), delete i.success, delete i.failure, delete i.callback)
            } catch (t) {
                if (!Ext.isIE8) throw t
            }
        }), this
    },
    initHTML5Upload: function() {
        return SYNO.SDS.HTML5Utils.isSupportHTML5Upload() && Ext.getBody().on("dragover", function(t) {
            SYNO.SDS.HTML5Utils.isDragFile(t.browserEvent) && (t.preventDefault(), t.browserEvent.dataTransfer.dropEffect = "none")
        }), this
    },
    IEUpgradeAlert: function() {
        (Ext.isIE6 || Ext.isIE7 || Ext.isIE8 || Ext.isIE9) && (Ext.util.Cookies.get("skip_upgrade_ie_alert") || (new SYNO.SDS.IEUpgradeAlert).show());
        return this
    },
    defaultCSSSelectors: function() {
        _S("diskless") && Ext.getBody().addClass("syno-diskless"), Ext.isIE10Touch && Ext.getBody().addClass("syno-ie10-touch");
        var t = Ext.urlDecode(location.search.substr(1)).accessible;
        return Ext.isDefined(t) && Ext.getBody().addClass("accessible"), this
    },
    initAPIManagerPromise: function() {
        return SYNO.API.currentManager || (SYNO.API.currentManager = new SYNO.API.Manager), new Promise(function(t, e) {
            SYNO.API.currentManager.queryAPI("all", t)
        })
    },
    checkTokenLogin: function() {
        return Ext.isWindows && !1 === _S("isLogined") && !0 === _S("enable_http_negotiate") ? new Promise(function(t, e) {
            Ext.Ajax.request({
                url: "webman/login.cgi?negotiate=" + Math.floor(window.performance.now()),
                method: "Get",
                success: function(e, i) {
                    var n = Ext.decode(e.responseText);
                    !0 === n.success ? (Ext.isEmpty(n.SynoToken) || (SYNO.SDS.Session.SynoToken = encodeURIComponent(n.SynoToken)), t(!0)) : t(!1)
                },
                failure: function() {
                    e()
                },
                scope: this
            })
        }) : Promise.resolve(!1)
    },
    initHDPack: function() {
        return SYNO.SDS.UIFeatures.IconSizeManager.addHDClsAndCSS(_S("SynohdpackStatus")), this
    },
    initLoginDialog: function() {
        return void 0 !== SYNO.SDS.ForgotPass ? new SYNO.SDS.ChangePassPage({}) : _S("isLogined") ? _S("preview") ? (window.opener && window.opener.previewParam && window.opener.previewParam.preview_modified && new SYNO.SDS.LoginApplyPreviewForm({}), new SYNO.SDS.LoginDialog({
            preview: !0
        })) : "no" !== _S("enable_syno_token") ? SYNO.SDS.UpdateSynoToken(this.readyToInitData) : this.readyToInitData() : 0 < window.location.search.indexOf("SynoToken=") ? window.location.search = window.location.search.replace(/&SynoToken=.*/, "") : _S("public_access") ? this.readyToInitData() : (window.loginLang = _S("lang"), new SYNO.SDS.LoginDialog({})), this
    },
    readyToInitData: function() {
        return SYNO.SDS.initData(), this
    },
    fetchSYNODEFS: function() {
        return new Promise(function(t, e) {
            if (!0 === _S("isLogined")) t();
            else {
                var i = "webapi/entry.cgi?api=SYNO.Core.Desktop.Defs&version=1&method=getjs";
                i = Ext.urlAppend(i, ""), SYNO.SDS.JSLoader.requestJSFileByScript(i, t, e)
            }
        })
    }
}), Ext.ns("SYNO.SDS.Office"), window._S || (window._S = function(t) {
    return SYNO.SDS.Session[t]
}), window._TT = function(t, e, i) {
    try {
        return SYNO.SDS.Strings[t][e][i]
    } catch (t) {
        return ""
    }
}, SYNO.SDS._BackgroundTaskMgr = SYNO.SDS._UploadBackgroundTaskMgr = SYNO.SDS._MailBackgroundTaskMgr = SYNO.SDS._SystemTray = SYNO.SDS._GroupSettings = SYNO.SDS.initAccesibilityPlugin = Ext.emptyFn, SYNO.SDS._Injector = function() {
    return {
        configure: Ext.emptyFn,
        register: Ext.emptyFn,
        resolve: function() {
            return ""
        }
    }
}, SYNO.SDS.Themer = SYNO.SDS.DSM.Themer, SYNO.SDS.reloadJSConfig = function(t) {
    if (Ext.isNumber(t) && t > 0) SYNO.SDS.reloadJSConfig.defer(t, this);
    else {
        var e = Ext.urlDecode(location.search.substr(1)),
            i = [];
        i.push(new Promise(function(t, i) {
            SYNO.API.Request({
                api: "SYNO.Core.Desktop.Initdata",
                method: "get",
                version: 1,
                params: {
                    action: "jsconfig",
                    launch_app: e.launchApp || SYNO.SDS.Session.rewriteApp
                },
                callback: function(e, n, s, o) {
                    if (e) {
                        SYNO.SDS.Config.JSConfig = n.JSConfig, SYNO.SDS.Strings = Object.assign(SYNO.SDS.Strings || {}, n.Strings), SYNO.SDS.ServiceStatus = n.ServiceStatus, SYNO.SDS.AppPrivilege = n.AppPrivilege, SYNO.SDS.UrlTag = n.UrlTag, SYNO.SDS.JSLoad.init();
                        var r, a = [];
                        n.CSSFiles.forEach(function(t) {
                            -1 !== t.indexOf("Chat") && a.push(t)
                        }), SYNO.SDS.appendMissingCSSFiles(a), r = [], SYNO.SDS.AppMgr.each(function(t) {
                            var e = t.jsConfig.jsID;
                            Ext.isDefined(SYNO.SDS.Config.FnMap[e]) || r.push(t)
                        }), Ext.invoke(r, "destroy"), t()
                    } else i()
                }
            })
        })), i.push(new Promise(function(t, e) {
            SYNO.API.currentManager.queryAPI("all", t)
        })), Promise.all(i).then(function() {
            SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("jsconfigLoaded")
        })
    }
}, SYNO.SDS.JSLoader.requestJSFileByAjax = SYNO.SDS.JSLoader.requestJSFileByScript = function(t, e, i) {
    var n = document.getElementsByTagName("head")[0],
        s = document.createElement("script"),
        o = t;
    var r, a = SYNO.SDS.JSLoad.JSStatus[t];
    a && (r = a.version), o = Ext.urlAppend(o, "v=" + (r || _S("fullversion"))), SYNO.Debug.debug("JSLoad requesting for  " + t + " by script tag"), s.type = "text/javascript", Ext.isIE ? (s.onready = e, s.onreadystatechange = function() {
        "complete" !== this.readyState && "loaded" !== this.readyState || this.onready()
    }) : s.onload = e, s.onerror = i, s.src = o, n.appendChild(s)
}, SYNO.SDS.InitUtils.initAPIManagerPromise = function() {
    return SYNO.API.Manager && !SYNO.API.currentManager ? SYNO.API.currentManager = new SYNO.API.Manager : SYNO.API._Manager && !SYNO.API.Manager && (SYNO.API.Manager = new SYNO.API._Manager), Promise.resolve()
}, SYNO.API.Manager.prototype.getKnownAPI = function(t, e) {
    var i, n, s, o;
    if (i = "entry.cgi/", s = "JSON", (o = SYNO.SDS.Office.isDSM7() ? {
            "SYNO.API.Info": {
                apiPath: "query.cgi",
                requestFormat: "raw"
            },
            "SYNO.API.Auth": {
                requestFormat: "raw"
            },
            "SYNO.API.OTP": {
                apiPath: "otp.cgi",
                requestFormat: "raw"
            }
        } : {
            "SYNO.API.Info": {
                apiPath: "query.cgi",
                requestFormat: "raw"
            },
            "SYNO.API.Auth": {
                apiPath: "auth.cgi",
                requestFormat: "raw"
            },
            "SYNO.API.OTP": {
                apiPath: "otp.cgi",
                requestFormat: "raw"
            },
            "SYNO.API.Encryption": {
                apiPath: "encryption.cgi",
                requestFormat: "raw"
            }
        }).hasOwnProperty(t)) {
        var r = o[t];
        r.apiPath && (i = r.apiPath), r.requestFormat && (s = r.requestFormat)
    }
    return "SYNO.Entry.Request" === t && Ext.isObject(e) && Ext.isArray(e.compound) ? (n = [], Ext.each(e.compound, function(t) {
        Ext.isString(t.api) && n.push(t.api)
    }), i += n.join()) : i += t, {
        api: t,
        path: i,
        requestFormat: s
    }
}, Ext.define("SYNO.SDS.Environment", {
    statics: {
        GetEnvironment: function() {
            return ""
        }
    }
}), SYNO.SDS.initData = function(t) {
    SYNO.SDS.ServiceStatus = SYNO.SDS.GroupSettings = SYNO.SDS.UrlTag = {}, SYNO.SDS.CompatibleMode = SYNO.SDS.isCompatibleMode(), _S("isLogined") || (SYNO.SDS.Session.user = String.format(_TT("SYNO.SDS.Drive.Application", "common", "guest"), ""), SYNO.SDS.UserSettings = {
        getProperty: Ext.emptyFn
    }), SYNO.SDS.init()
}, SYNO.SDS.UIFeatures.IconSizeManager.addHDClsAndCSS = function() {
    var t = !1;
    SYNO.SDS.UIFeatures.test("isRetina") && (document.documentElement.classList.add(this.cls), t = !0), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = t
}, SYNO.SDS.Office.isDSM7 = function() {
    return SYNO.SDS.isCompatibleMode && SYNO.SDS.isCompatibleMode()
}, Ext.define("SYNO.SDS.Office.SSOUtils", {
    singleton: !0,
    isCheck: function() {
        return !_S("isLogined") && window.getDriveErrCode && 1002 === window.getDriveErrCode()
    },
    init: function() {
        SYNO.SDS.SSOUtils.init(this.isCheck() ? this.onSSOCallback : Ext.emptyFn, this)
    },
    onSSOCallback: function(t) {
        "login" === t.status && t.access_token && 40 === t.access_token.length && (window.location.href = EarlyInit.getDSMURL())
    }
}), SYNO.SDS.Office.init = function() {
    _S("isLogined") || (SYNO.SDS.InitUtils.handleServerError = Ext.emptyFn), SYNO.SDS.Office.SSOUtils.init(), SYNO.SDS.Office.isDSM7() ? SYNO.SDS.InitUtils.initAPIManagerPromise().then(function() {
        SYNO.SDS.LoginInitUtils.checkTokenLogin().then(function() {
            SYNO.SDS._Packages && (SYNO.SDS.Packages = new SYNO.SDS._Packages), SYNO.SDS.initData(), SYNO.SDS.InitUtils.initQuickTips().initDragDrop().handleServerError(), SYNO.SDS.LoginInitUtils.disableKeyboardEvent().disableRightClick().initHTML5Upload().IEUpgradeAlert().defaultCSSSelectors().initHDPack()
        })
    }) : SYNO.SDS.InitUtils.initAPIManagerPromise().then(function() {
        SYNO.SDS.InitUtils.checkTokenLogin().then(function() {
            SYNO.SDS.initData(), SYNO.SDS.InitUtils.initHDPack().hideForms().initQuickTips().initDragDrop().disableIESelect().disableSelectAllKeyboard().disableRightClick().initHTML5Upload().IEUpgradeAlert().defaultCSSSelectors().handleServerError()
        }).catch(function() {
            SYNO.SDS.InitUtils.initHDPack()
        })
    })
}, Ext.namespace("SYNO.SDS");
var pkgStatus = {
        start: ["running"],
        error: ["broken", "broken_by_other", "version_limit", "license_error", "stopped_by_dep_limit", "start_failed"],
        doing: ["installing", "upgrading", "starting", "repairing", "stopping", "uninstalling"],
        stop: ["stop", "stopped"]
    },
    tipStatus = {
        repair: _T("pkg_detail_status", "repairing"),
        install: _T("pkg_detail_status", "installing"),
        start: _T("pkg_detail_status", "starting"),
        stop: _T("pkg_detail_status", "stopping"),
        uninstall: _T("pkg_detail_status", "uninstalling"),
        upgrade: _T("pkg_detail_status", "upgrading"),
        installing: _T("pkg_detail_status", "installing"),
        upgrading: _T("pkg_detail_status", "upgrading"),
        starting: _T("pkg_detail_status", "starting"),
        repairing: _T("pkg_detail_status", "repairing"),
        stopping: _T("pkg_detail_status", "stopping"),
        uninstalling: _T("pkg_detail_status", "uninstalling"),
        error: _T("error", "error_error"),
        broken: _T("pkgmgr", "pkgmgr_pkg_broken"),
        broken_by_other: _T("pkgmgr", "pkgmgr_pkg_broken"),
        license_error: _T("pkgmgr", "pkgmgr_pkg_broken"),
        version_limit: _T("pkgmgr", "status_version_limit"),
        start_failed: _T("pkgmgr", "pkgmgr_pkg_stopped"),
        stopped_by_dep_limit: _T("pkgmgr", "stopped_by_dep_limit")
    },
    pkgSocketStatus = {
        start: {
            condition: function(t) {
                return ("start" === t.action || "upgrade" === t.action || "restart" === t.action) && !0 === t.finished && !0 === t.success
            }
        },
        error: {
            condition: function(t) {
                return !0 === t.finished && !1 === t.success
            }
        },
        doing: {
            condition: function(t) {
                return !1 === t.finished
            }
        },
        stop: {
            condition: function(t) {
                return "stop" === t.action && !0 === t.finished && !0 === t.success
            }
        },
        install: {
            condition: function(t) {
                return "install" === t.action && !0 === t.finished && !0 === t.success
            }
        },
        uninstall: {
            condition: function(t) {
                return "uninstall" === t.action && !0 === t.finished && !0 === t.success
            }
        }
    },
    PKG_ALL = "_all";
SYNO.SDS._Packages = function() {
    function t() {
        _classCallCheck(this, t), this._packages = Object.create(null), this._mapPackages = new Map, this._onChangeCallbacks = [], this._onAllPackagesChange = [], this.anonymous = !1
    }
    return _createClass(t, [{
        key: "getAllPackages",
        value: function() {
            return Object.assign({}, this._packages)
        }
    }, {
        key: "registerSocketPackageStatus",
        value: function() {
            var t = this;
            SYNO.SDS.SocketInst.registerSDKEvent("package_status_changed", function(e) {
                try {
                    t._onPackageStatusChange.apply(t, [e])
                } catch (t) {
                    SYNO.Debug.error(t, e)
                }
            }), SYNO.SDS.SocketInst.registerSDKEvent("package_progress_changed", function() {
                t.getData()
            })
        }
    }, {
        key: "_notifyAllPackagesChanged",
        value: function() {
            var t = !0,
                e = !1,
                i = void 0;
            try {
                for (var n, s = this._onAllPackagesChange[Symbol.iterator](); !(t = (n = s.next()).done); t = !0) {
                    var o = n.value,
                        r = o.callback,
                        a = o.context;
                    r.apply(a || this)
                }
            } catch (t) {
                e = !0, i = t
            } finally {
                try {
                    t || null == s.return || s.return()
                } finally {
                    if (e) throw i
                }
            }
        }
    }, {
        key: "_notifyPackageStatusChange",
        value: function(t, e) {
            var i = !0,
                n = !1,
                s = void 0;
            try {
                for (var o, r = this._onChangeCallbacks[Symbol.iterator](); !(i = (o = r.next()).done); i = !0) {
                    var a = o.value,
                        S = a.callback,
                        l = a.context,
                        c = a.pkgId;
                    c !== PKG_ALL && c !== t.package || S.apply(l || this, [e, t])
                }
            } catch (t) {
                n = !0, s = t
            } finally {
                try {
                    i || null == r.return || r.return()
                } finally {
                    if (n) throw s
                }
            }
        }
    }, {
        key: "_onPackageStatusChange",
        value: function(t) {
            var e = this.transformPkgStatus(t);
            if (e) {
                var i = this.getInfo(t.package, "pkgId");
                if (i && 0 !== i.length) {
                    var n = !0,
                        s = !1,
                        o = void 0;
                    try {
                        for (var r, a = i[Symbol.iterator](); !(n = (r = a.next()).done); n = !0) {
                            var S = r.value;
                            S._socketAction = t.action, S.status = e, delete S._pkgStatus
                        }
                    } catch (t) {
                        s = !0, o = t
                    } finally {
                        try {
                            n || null == a.return || a.return()
                        } finally {
                            if (s) throw o
                        }
                    }
                    this._notifyPackageStatusChange(t, e)
                }
            }
        }
    }, {
        key: "transformPkgStatus",
        value: function(t) {
            return "socket" === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "socket") ? Object.entries(pkgSocketStatus).reduce(function(e, i) {
                var n = i[0],
                    s = i[1];
                return s.condition && !0 === s.condition.apply(s, [t]) ? n : e
            }, null) : this._mappingPkgStatus(t.status)
        }
    }, {
        key: "getPackageTip",
        value: function(t) {
            var e = this.getInfo(t, "pkgId");
            if (e && 0 !== e.length) {
                var i = e[0];
                return "doing" === i.status ? tipStatus[i._socketAction] || tipStatus[i._pkgStatus] || _T("pkg_detail_status", "waiting") : "error" === i.status ? tipStatus[i._pkgStatus] || tipStatus.error : void 0
            }
        }
    }, {
        key: "shouldLaunchPkgCenter",
        value: function(t) {
            return "doing" === t || "stop" === t || "error" === t
        }
    }, {
        key: "clear",
        value: function() {
            this._packages = Object.create(null), this._mapPackages = new Map
        }
    }, {
        key: "insert",
        value: function(t, e) {
            (this._packages[t] = e, this._mapPackages.has(e.pkgId)) ? this._mapPackages.get(e.pkgId).push(e): this._mapPackages.set(e.pkgId, [e])
        }
    }, {
        key: "isPackage",
        value: function(t) {
            return !!this._packages[t]
        }
    }, {
        key: "isStop",
        value: function(t) {
            var e = this._packages[t];
            return !!e && "stop" === e.status
        }
    }, {
        key: "isStart",
        value: function(t) {
            var e = this._packages[t];
            return !!e && "start" === e.status
        }
    }, {
        key: "getInfo",
        value: function(t) {
            var e = "appId" === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "appId") ? this._packages[t] : this._mapPackages.get(t);
            return e || null
        }
    }, {
        key: "isAnonymous",
        value: function() {
            return this.anonymous
        }
    }, {
        key: "getData",
        value: function() {
            var t = this;
            return _S("public_access") ? (this.anonymous = !0, Promise.resolve()) : SYNO.API.RequestPromise({
                api: "SYNO.Core.Package",
                method: "list",
                version: 2,
                params: {
                    additional: ["status", "dsm_apps"]
                }
            }).then(function(e) {
                return t.clear(), t.processPackagesResponse(e.packages), t._notifyAllPackagesChanged(), t._packages
            }).catch(function(t) {
                SYNO.Debug.error(t)
            })
        }
    }, {
        key: "getPackage",
        value: function(t) {
            var e = this;
            return SYNO.API.RequestPromise({
                api: "SYNO.Core.Package",
                method: "get",
                version: 1,
                params: {
                    id: t,
                    additional: ["status", "dsm_apps"]
                }
            }).then(function(t) {
                e.processPackageResponse(t)
            }).catch(function(t) {
                SYNO.Debug.error(t)
            })
        }
    }, {
        key: "processPackageResponse",
        value: function(t) {
            var e = t.additional.dsm_apps.split(" "),
                i = !0,
                n = !1,
                s = void 0;
            try {
                for (var o, r = e[Symbol.iterator](); !(i = (o = r.next()).done); i = !0) {
                    var a = o.value,
                        S = t.additional.status;
                    this.insert(a, {
                        id: a,
                        pkgId: t.id,
                        name: t.name,
                        _pkgStatus: S,
                        version: t.version,
                        status: this.transformPkgStatus({
                            status: S
                        }, "webapi")
                    })
                }
            } catch (t) {
                n = !0, s = t
            } finally {
                try {
                    i || null == r.return || r.return()
                } finally {
                    if (n) throw s
                }
            }
        }
    }, {
        key: "processPackagesResponse",
        value: function(t) {
            var e = !0,
                i = !1,
                n = void 0;
            try {
                for (var s, o = t[Symbol.iterator](); !(e = (s = o.next()).done); e = !0) {
                    var r = s.value;
                    this.processPackageResponse(r)
                }
            } catch (t) {
                i = !0, n = t
            } finally {
                try {
                    e || null == o.return || o.return()
                } finally {
                    if (i) throw n
                }
            }
        }
    }, {
        key: "_mappingPkgStatus",
        value: function(t) {
            return Object.entries(pkgStatus).reduce(function(e, i) {
                var n = i[0];
                return i[1].includes(t) ? n : e
            }, null)
        }
    }, {
        key: "registerAllPackagesChange",
        value: function(t, e) {
            this._onAllPackagesChange.push({
                callback: t,
                context: e || this
            })
        }
    }, {
        key: "registerPackageStatusChange",
        value: function(t, e) {
            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : PKG_ALL;
            this._onChangeCallbacks.push({
                callback: t,
                context: e || this,
                pkgId: i
            })
        }
    }, {
        key: "unregisterPackageStatusChange",
        value: function(t, e) {
            this._onChangeCallbacks = this._onChangeCallbacks.filter(function(i) {
                var n = i.callback,
                    s = i.context;
                return n !== t || s !== e
            })
        }
    }, {
        key: "unregisterAllPackagesChange",
        value: function(t, e) {
            this._onAllPackagesChange = this._onAllPackagesChange.filter(function(i) {
                var n = i.callback,
                    s = i.context;
                return n !== t || s !== e
            })
        }
    }, {
        key: "isEnable",
        value: function(t) {
            return !!this.isAnonymous() || this.isStart(t)
        }
    }, {
        key: "getJsId",
        value: function(t) {
            var e = this.getInfo(t, "pkgId");
            return e && e.length > 0 ? e[0].id : null
        }
    }]), t
}();
