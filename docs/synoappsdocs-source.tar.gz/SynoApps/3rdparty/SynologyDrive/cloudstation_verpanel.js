/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.CSTN"), 
/**
 * @class SYNO.SDS.CSTN.ProgressWebAPI
 * SynologyDrive progress web api class
 *
 */
Ext.define("SYNO.SDS.CSTN.ProgressWebAPI", {
    constructor: function(e) {
        this.owner = e.owner, this.polling_task = void 0, this.win_panel = e.win_panel, this.api = e.api, this.version = e.version || 1, this.start_method = e.start_method || "start", this.status_method = e.status_method || "status", this.stop_method = e.stop_method || "stop", this.task_type = e.task_type, this.show_msgbox = e.show_msgbox, this.show_progress = e.show_progress, this.msg_text = e.msg_text
    },
    startTask: function(e) {
        this.owner.setStatusBusy(!0), !0 === this.show_msgbox && this.owner.getMsgBox().show({
            wait: !1,
            progress: this.show_progress,
            closable: !1,
            maxWidth: 300,
            title: _STR("app", "app_name"),
            msg: this.msg_text
        }), this.win_panel.sendWebAPI({
            api: this.api,
            version: this.version,
            method: this.start_method,
            params: e,
            callback: this.startTaskCB,
            scope: this
        })
    },
    startTaskCB: function(e, t, i, o) {
        this.owner.clearStatusBusy(), SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, o, {
            success: this.startTaskSuccessCB,
            failure: this.startTaskFailCB
        })
    },
    startTaskSuccessCB: function(e) {
        this.setPollingTask(!0)
    },
    startTaskFailCB: function(e) {
        var t = SYNO.SDS.CSTN.getErrorString(e);
        this.owner.getMsgBox().alert(_STR("app", "app_name"), t, function() {}, this)
    },
    setPollingTask: function(e) {
        void 0 !== this.polling_task && (this.polling_task.remove(), this.polling_task = void 0), e && (this.polling_task = this.win_panel.addWebAPITask({
            id: this.polling_cgi,
            interval: 2e3,
            autoJsonDecode: !0,
            api: this.api,
            version: this.version,
            method: this.status_method,
            callback: this.pollingCB,
            scope: this
        }), this.polling_task.start(!0), this.show_progress && this.updateProgress(0))
    },
    pollingCB: function(e, t, i) {
        if (e) {
            var o = 0,
                n = parseInt(t.total, 10),
                s = parseInt(t.current, 10);
            n > 0 && (o = s / n), o = o < .01 ? .01 : o, this.show_progress && this.updateProgress(o), s == n && (this.finishTask(), this.win_panel.doRefresh())
        } else {
            var a = SYNO.SDS.CSTN.getErrorString(t);
            this.cancelTask(), this.owner.getMsgBox().alert(_STR("app", "app_name"), a)
        }
    },
    updateProgress: function(e) {
        var t = 100 * e,
            i = t.toFixed(2).toString() + "%";
        this.polling_task && this.show_msgbox && this.owner.getMsgBox().updateProgress(e, i, this.msg_text)
    },
    cancelTask: function() {
        this.win_panel.sendWebAPI({
            api: this.api,
            version: this.version,
            method: this.stop_method
        }), this.setPollingTask(!1), this.show_msgbox && this.owner.getMsgBox().hide()
    },
    finishTask: function() {
        this.setPollingTask(!1), this.show_msgbox && this.owner.getMsgBox().hide()
    }
}), Ext.define("SYNO.SDS.CSTN.RestoreTask", {
    extend: "SYNO.SDS.CSTN.ProgressWebAPI",
    constructor: function(e) {
        var t = e || {};
        this.recycle_panel = e.recycle_panel, this.copy_to = e.copy_to || "", this.override = !!e.override, t.win_panel = e.recycle_panel, t.api = SYNO.SDS.CSTN.WebAPI.Node.Restore.api, t.show_msgbox = !0, t.show_progress = !0, t.msg_text = _STR("clientinfo", "restoring"), t.stop_method = "finish", this.callParent([t])
    },
    startRestore: function(e, t, i, o, n) {
        this.startTask({
            target: e,
            nodes: t,
            copy_to: this.copy_to,
            override: this.override,
            decrypt: o,
            include_removed: n || !1,
            view_role: i
        })
    },
    finishTask: function() {
        this.win_panel.sendWebAPI({
            api: this.api,
            version: this.version,
            method: "finish"
        }), this.callParent([])
    }
}), Ext.define("SYNO.SDS.CSTN.DownloadTask", {
    extend: "SYNO.SDS.CSTN.ProgressWebAPI",
    statics: {
        IFrameTemplate: new Ext.Template('<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><form accept-charset="utf-8" name="dlform" action="{cgi}/{dlname}" method="POST"><input type="hidden" name="api" value="" /><input type="hidden" name="version" value="" /><input type="hidden" name="method" value="" /><input type="hidden" name="nodes" value="" /><input type="hidden" name="task_id" value="" /><input type="hidden" name="outname" value="" /></form></body></html>').compile()
    },
    constructor: function(e) {
        var t = e;
        this.recycle_panel = e.recycle_panel, this.timelinedate = e.timelinedate, t.win_panel = e.recycle_panel, t.api = SYNO.SDS.CSTN.WebAPI.Node.Download.api, t.show_msgbox = !0, t.show_progress = !0, t.msg_text = _STR("clientinfo", "download_preparing"), this.callParent([t])
    },
    startDownload: function(e, t, i, o, n) {
        this.nodes_info = t, this.startTask({
            target: e,
            nodes: this.nodes_info,
            view_role: i,
            decrypt: o,
            include_removed: n || !1,
            encryption: !0 === Ext.isArray(o) && o.length && ["decrypt"] || []
        })
    },
    startTaskSuccessCB: function(e) {
        this.task_id = e.task_id, this.callParent([e])
    },
    finishTask: function() {
        var e = {},
            t = "",
            i = new Date(1e3 * (this.timelinedate || this.nodes_info[0].modify_time)).toLocaleString();
        if (1 == this.nodes_info.length) {
            var o = this.nodes_info[0].name;
            if (0 === this.nodes_info[0].file_type) {
                var n = o.lastIndexOf("."); - 1 != n && (o = o.substr(0, n))
            }
            t = String.format("{0} ({1} ver)", o, i)
        } else t = String.format("Drive Admin Console - ({0} ver)", i);
        e = {
            with_file_name: !0,
            task_id: this.task_id,
            outname: Ext.encode(t),
            nodes: Ext.encode(this.nodes_info)
        };
        var s = "/cstndownload/" + encodeURIComponent(t);
        if (s = Ext.urlAppend(s, Ext.urlEncode(e)), (Ext.isIE || Ext.isEdge) && s.length >= 2046 - (window.location.protocol + "//" + window.location.hostname + ":" + window.location.port).length) return this.Download(e, t), void this.callParent([]);
        var a = SYNO.SDS.CSTN.GetDownloadIframe.apply(this.recycle_panel);
        if (!a) return void this.callParent([]);
        Ext.EventManager.on(a, "load", function i() {
            Ext.EventManager.removeListener(a, "load", i, this), this.Download(e, t)
        }, this), a.src = s, this.callParent([])
    },
    Download: function(e, t) {
        var i = SYNO.SDS.Session.SynoToken ? "?SynoToken=" + SYNO.SDS.Session.SynoToken : "",
            o = SYNO.SDS.CSTN.DownloadTask.IFrameTemplate.applyTemplate({
                cgi: SYNO.SDS.CSTN.CGI_PATH,
                dlname: encodeURIComponent(SYNO.SDS.CSTN.replaceDLNameSpecChars(t)) + i
            }),
            n = SYNO.SDS.CSTN.GetDownloadIframe.apply(this);
        if (n) {
            var s = Ext.isIE ? n.contentWindow.document : n.contentDocument || window.frames[n.id].document;
            s.open("text/html"), s.write(o), s.close(), s.dlform.task_id.value = e.task_id, s.dlform.outname.value = e.outname, s.dlform.nodes.value = e.nodes, s.dlform.api.value = SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".Node.Download", s.dlform.version.value = 1, s.dlform.method.value = "finish", Ext.EventManager.on(n, "load", function e() {
                var t = Ext.isIE ? n.contentWindow.document : n.contentDocument || window.frames[n.id].document;
                Ext.EventManager.removeListener(n, "load", e, this);
                try {
                    var i;
                    return !(!t || !t.body) && (i = Ext.decode(t.body.innerHTML.unescapeHTML()).error, i.code !== SYNO.SDS.CSTN.ErrorCode.CANNOT_ACCESS ? this.owner.getMsgBox().alert(_T("service", "service_cloudstation_title"), _T("common", "error_system")) : this.owner.getMsgBox().alert(_STR("app", "app_name"), SYNO.SDS.CSTN.getErrorString(i)), !0)
                } catch (e) {}
                return !1
            }, this), s.dlform.submit()
        }
    }
}), Ext.define("SYNO.SDS.CSTN.DeleteNodeTask", {
    extend: "SYNO.SDS.CSTN.ProgressWebAPI",
    constructor: function(e) {
        var t = e;
        this.recycle_panel = e.recycle_panel, t.win_panel = e.recycle_panel, t.api = SYNO.SDS.CSTN.WebAPI.Node.Delete.api, t.show_msgbox = !0, t.show_progress = !1, t.msg_text = _STR("clientinfo", "db_cleaning"), this.callParent([t])
    },
    startDeleteNode: function(e, t, i) {
        this.owner.setStatusBusy(), this.startTask({
            target: e,
            fileinfo: t,
            view_role: i
        })
    },
    startDeleteAll: function(e, t, i) {
        this.owner.setStatusBusy(), this.startTask({
            target: e,
            name_filter: t || "",
            view_role: i
        })
    }
}), Ext.ns("SYNO.SDS.CSTN.VERSION"), SYNO.SDS.CSTN.VERSION.RenderUpdater = function(e, t) {
    return t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e)) + '"'), Ext.util.Format.htmlEncode(e)
}, SYNO.SDS.CSTN.VERSION.DlFrameTemplate = new Ext.Template('<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><form accept-charset="utf-8" name="dlform" action="{cgi}/{dlfile}" method="POST"><input type="hidden" name="action" value="" /><input type="hidden" name="nodeinfo" value="" /></form></body></html>'), SYNO.SDS.CSTN.VERSION.DlFrameTemplate.compile(), Ext.define("SYNO.SDS.CSTN.VERSION.PanelVersion", {
    extend: "SYNO.ux.GridPanel",
    hasRestore: !1,
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.win = e.win, this.file_info = void 0;
        var t = this.fillConfig(e);
        this.callParent([t]), this.restore_task = new SYNO.SDS.CSTN.RestoreTask({
            owner: this.owner,
            recycle_panel: this,
            override: !0
        }), this.download_task = new SYNO.SDS.CSTN.DownloadTask({
            owner: this.owner,
            recycle_panel: this
        }), this.getSelectionModel().on("rowselect", function(e) {
            0 === e.getCount() || this.win._S("demo_mode") || (this.getTopToolbar().getComponent("btnDownload").enable(), this.getTopToolbar().getComponent("btnRestore").enable()), !this.getSelectRec()[0].is_removed && e.isSelected(0) && this.getTopToolbar().getComponent("btnRestore").disable()
        }, this), this.getSelectionModel().on("rowdeselect", function(e) {
            0 === e.getCount() && this.getTopToolbar().getComponent("btnDownload").disable()
        }, this)
    },
    fillConfig: function(e) {
        this.pageSize = 50;
        var t = [{
                id: "create_time",
                width: 150,
                header: _TT("SYNO.SDS.CSTN.Instance", "common", "create_time"),
                dataIndex: "create_time",
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                renderer: SYNO.SDS.CSTN.RenderTime
            }, {
                id: "modify_time",
                width: 150,
                header: _TT("SYNO.SDS.CSTN.Instance", "common", "modify_time"),
                dataindex: "modify_time",
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                renderer: SYNO.SDS.CSTN.RenderTime
            }, {
                id: "version_updater",
                header: _TT("SYNO.SDS.CSTN.Instance", "clientinfo", "title_id"),
                dataIndex: "version_updater",
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                renderer: SYNO.SDS.CSTN.VERSION.RenderUpdater
            }, {
                id: "path",
                header: "path",
                dataIndex: "path",
                hidden: !0
            }, {
                id: "sync_id",
                header: "sync_id",
                dataIndex: "sync_id",
                hidden: !0
            }],
            i = new Ext.grid.ColumnModel({
                columns: t
            }),
            o = this.createStore(),
            n = new Ext.Toolbar;
        n.add({
            xtype: "syno_button",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this.win._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnDownload",
            text: _TT("SYNO.SDS.CSTN.Instance", "action", "download"),
            handler: this.onDL,
            scope: this
        }), n.add({
            xtype: "syno_button",
            disabled: !0,
            tooltip: this.win._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnRestore",
            text: _TT("SYNO.SDS.CSTN.Instance", "btn", "restore"),
            handler: this.onRestore,
            scope: this
        }), n.add({
            xtype: "syno_button",
            text: _STR("btn", "refresh"),
            handler: this.doRefresh,
            scope: this
        });
        var s = {
            width: 650,
            height: 380,
            tbar: n,
            view: new SYNO.ux.FleXcroll.grid.GridView({}),
            stripeRows: !0,
            enableColLock: !1,
            enableHdMenu: !1,
            enableColumnMove: !1,
            colModel: i,
            ds: o,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            autoExpandColumn: "version_updater",
            loadMask: !0,
            owner: e.owner,
            listeners: {
                viewready: function() {
                    this.is_office && this.popup_win && window.setTimeout(function() {
                        this.owner.close()
                    }.createDelegate(this), 100)
                },
                scope: this
            }
        };
        return Ext.apply(s, e), s
    },
    onPageActivate: function(e) {
        this.file_info = e, this.view_role = e.view_role || this.win._S("user"), this.is_office = e.is_office;
        var t = e.filename;
        this.getStore().setBaseParam("path", e.path), this.getStore().setBaseParam("node_id", e.nodeid ? e.nodeid : "0"), this.getStore().setBaseParam("target", e.target), this.getStore().setBaseParam("view_role", this.view_role), this.owner.setTitle(String.format(_TT("SYNO.SDS.CSTN.Instance", "verlist", "title"), Ext.util.Format.ellipsis(t, 45))), this.getStore().load(), this.is_office && (this.popup_win = e.popup_win)
    },
    onActivate: function(e) {
        this.onPageActivate(e)
    },
    createStore: function() {
        var e = ["create_time", "modify_time", "version_updater", "path", "sync_id", "node_id", "version_is_removed"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Node.api,
                    version: 1,
                    method: "list_version",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    id: "id",
                    is_removed: "is_removed",
                    permanent_id: "permanent_id",
                    permanent_link: "permanent_link",
                    modify_time: "modify_time"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    offset: 0,
                    limit: this.pageSize,
                    sort_by: "create_time",
                    sort_direction: "DESC",
                    user: this.win._S("user")
                },
                listeners: {
                    scope: this,
                    load: function(e) {
                        this.is_office && this.popup_win ? this.popup_win.location = window.location.origin + "/oo/r/" + e.reader.jsonData.permanent_link + "#version_time=" + (new Date).getTime() / 1e3 : this.file_info.is_removed = e.reader.jsonData.is_removed
                    },
                    exception: function(e, t, i, o, n) {
                        n && n.code && SYNO.SDS.CSTN.webapiErrHdl.apply(this, [n])
                    }
                }
            });
        return this.addManagedComponent(t), t
    },
    getSelectRec: function() {
        var e = this.getSelectionModel().getSelected();
        return [{
            path: e.get("path"),
            sync_id: e.get("sync_id").toString(),
            node_id: e.get("node_id").toString(),
            permanent_id: this.getStore().reader.jsonData.permanent_id,
            name: this.file_info.filename,
            file_type: this.file_info.file_type,
            is_removed: this.file_info.is_removed,
            modify_time: e.get("modify_time")
        }]
    },
    onDL: function() {
        this.download_task.startDownload(this.file_info.target, this.getSelectRec(), this.view_role, [], !0)
    },
    onRestore: function() {
        this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "restore_confirm"), function(e) {
            "yes" === e && this.restore_task.startRestore(this.file_info.target, this.getSelectRec(), this.view_role, [], !0)
        }, this)
    },
    doRefresh: function() {
        this.getTopToolbar().getComponent("btnDownload").disable(), this.getTopToolbar().getComponent("btnRestore").disable(), this.getStore().load()
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.DialogVersion", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.panel = new SYNO.SDS.CSTN.VERSION.PanelVersion({
            owner: this,
            win: this.owner
        });
        var t = void 0;
        SYNO.SDS.CSTN.IsDSM7OrAbove() && (t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "close"),
                itemId: "cancel",
                handler: this.onCancel,
                scope: this
            }]
        }), this.callParent([Ext.apply({
            title: _STR("verlist", "title"),
            cls: "syno-cstn-version-window",
            width: 700,
            height: 450,
            resizable: !1,
            autoScroll: !0,
            closable: !0,
            layout: "fit",
            fbar: t,
            items: [this.panel]
        }, e)])
    },
    winShow: function(e) {
        this.panel.onActivate(e), this.open()
    },
    onCancel: function() {
        this.close()
    }
});
