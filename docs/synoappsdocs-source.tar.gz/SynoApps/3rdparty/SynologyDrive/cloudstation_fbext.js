/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Drive.Extension"), 
/**
 * @class SYNO.SDS.Drive.Extension.Instance
 * @extends SYNO.SDS.AppInstance
 * SynologyDrive extension application instance class
 *
 */
Ext.define("SYNO.SDS.Drive.Extension.Instance", {
    extend: "SYNO.SDS.AppInstance",
    statics: {
        _serviceConfig: null,
        isApplicationEnabled: function() {
            return null !== this._serviceConfig && !0 === this._serviceConfig.user_enabled
        },
        isHomeServiceEnabled: function() {
            return null !== this._serviceConfig && !0 === this._serviceConfig.home_enabled
        },
        isEnabledSharedFolder: function(e) {
            if (null === this._serviceConfig) return !1;
            for (var n = 0; n < this._serviceConfig.share_list.length; n++)
                if (e === this._serviceConfig.share_list[n].name) return !0;
            return !1
        },
        splitPath: function(e) {
            var n = e.split("/");
            return n.shift(), n
        },
        joinPath: function(e) {
            return "/" + e.join("/")
        },
        isInCloudStationFolder: function(e) {
            var n = this.splitPath(e);
            return !!(this.isHomeServiceEnabled() && n.length >= 3 && "home" === n[0] && "Drive" === n[1]) || !!(n.length >= 2 && this.isEnabledSharedFolder(n[0]))
        },
        isInCloudStationHomeFolder: function(e) {
            var n = this.splitPath(e);
            return !!(this.isHomeServiceEnabled() && n.length >= 3 && "home" === n[0] && "Drive" === n[1])
        },
        isCloudStationFolder: function(e) {
            var n = this.splitPath(e);
            return !(!this.isHomeServiceEnabled() || 2 !== n.length || "home" !== n[0] || "Drive" !== n[1]) || !(1 !== n.length || !this.isEnabledSharedFolder(n[0]))
        },
        isUnderCloudStationFolder: function(e) {
            var n = this.splitPath(e);
            return !!(this.isHomeServiceEnabled() && n.length >= 2 && "homes" === n[0] && "Drive" === n[2]) || !!(n.length >= 1 && this.isEnabledSharedFolder(n[0]))
        },
        getCloudStationRelativePath: function(e) {
            var n = this.splitPath(e);
            return "home" === n[0] ? (n.splice(0, 2), this.joinPath(n)) : (n.splice(0, 1), this.joinPath(n))
        },
        isFiltered: function(e, n, t, i) {
            if (null === this._serviceConfig || !this._serviceConfig.rules) return !1;
            e = e.toLowerCase(), n = n.toLowerCase();
            var r = this._serviceConfig.rules;
            if (r.common.max_path_length > 0 && n.length > r.common.max_path_length) return !0;
            var o, s = this.getCloudStationRelativePath(n),
                a = this.splitPath(s),
                l = function(e, n, t, i, r) {
                    var o, s = e.toLowerCase();
                    for (o = 0; o < n.length; o++)
                        if (0 === s.indexOf(n[o].toLowerCase())) return !0;
                    for (o = 0; o < t.length; o++)
                        if (-1 !== s.indexOf(t[o].toLowerCase(), s.length - t[o].length)) return !0;
                    for (o = 0; o < i.length; o++)
                        if (s === i[o].toLowerCase()) return !0;
                    for (o = 0; o < r.length; o++)
                        if (-1 !== s.indexOf(r[o])) return !0;
                    return !1
                };
            for (o = 0; o < r.common.dir_prefix.length; o++) {
                var S = r.common.dir_prefix[o].toLowerCase();
                if (s.length >= S.length && 0 === s.indexOf(S) && (s.length === S.length || "/" === s[S.length])) return !0
            }
            for (o = 0; o < a.length; o++) {
                if (r.common.max_name_length > 0 && a[o].length > r.common.max_name_length) return !0;
                if (!t && o + 1 === a.length) break;
                if (l(a[o], r.common.prefix, r.common.suffix, r.common.name, r.common.character)) return !0;
                if (l(a[o], r.dir.prefix, r.dir.suffix, r.dir.name, r.dir.character)) return !0
            }
            if (!t) {
                if (r.file.max_size > 0 && i > r.file.max_size) return !0;
                var c = e.lastIndexOf(".");
                if (c > 0) {
                    var f = e.substr(c + 1);
                    for (o = 0; o < r.file.ext.length; o++)
                        if (f === r.file.ext[o].toLowerCase()) return !0
                }
                if (l(e, r.common.prefix, r.common.suffix, r.common.name, r.common.character)) return !0;
                if (l(e, r.file.prefix, r.file.suffix, r.file.name, r.file.character)) return !0
            }
            return !1
        },
        isOfficeFile: function(e, n) {
            if (n) return !1;
            var t = e.lastIndexOf(".");
            if (-1 === t) return !1;
            switch (e.substr(t + 1).toLowerCase()) {
                case "odoc":
                case "osheet":
                case "oslides":
                    return !0;
                default:
                    return !1
            }
            return !1
        }
    },
    constructor: function(e) {
        this.callParent(arguments)
    },
    initInstance: function(e) {
        SYNO.SDS.CSTN.WebAPI.getExtension.call(this, function(e, n, t, i) {
            SYNO.SDS.Drive.Extension.Instance._serviceConfig = e ? n.service_config : null
        }, this)
    },
    startPollingTask: function() {
        return !0
    }
}), Ext.ns("SYNO.SDS.Drive.Extension.IconOverlay"), SYNO.SDS.Drive.Extension.IconOverlay.getIconFn = function(e, n, t) {
    var i = n.get("icon"),
        r = n.get("filename"),
        o = n.get("path"),
        s = n.get("isdir"),
        a = n.get("filesize");
    return i || (i = "folder.png"), a || (a = 0), !!SYNO.SDS.Drive.Extension.Instance.isApplicationEnabled() && (SYNO.SDS.Drive.Extension.Instance.isCloudStationFolder(o) ? {
        url: "images/SynologyDrive_256.png"
    } : !!SYNO.SDS.Drive.Extension.Instance.isInCloudStationFolder(o) && (!!SYNO.SDS.Drive.Extension.Instance.isFiltered(r, o, s, a) && function(e, n) {
        return {
            css: "syno-cstn-thumb-cover"
        }
    }()))
}, Ext.ns("SYNO.SDS.Drive.Extension.VersionBrowser"), SYNO.SDS.Drive.Extension.VersionBrowser.checkFn = function(e, n) {
    var t = n[0],
        i = t.get("filename"),
        r = t.get("path"),
        o = t.get("isdir"),
        s = t.get("filesize");
    return !!SYNO.SDS.Drive.Extension.Instance.isApplicationEnabled() && (!SYNO.SDS.Drive.Extension.Instance.isFiltered(i, r, o, s) && (!o && !!SYNO.SDS.Drive.Extension.Instance.isInCloudStationFolder(r)))
}, SYNO.SDS.Drive.Extension.VersionBrowser.launchFn = function(e) {
    var n, t, i = e[0].get("filename"),
        r = e[0].get("path"),
        o = SYNO.SDS.Drive.Extension.Instance.splitPath(r),
        s = SYNO.SDS.Drive.Extension.Instance.getCloudStationRelativePath(r),
        a = SYNO.SDS.CloudStation.IsOfficeItem(i);
    !0 === a && (t = window.open("")), n = "home" === o[0] ? "user" : "@" + o[0], SYNO.SDS.AppLaunch("SYNO.SDS.CSTN.VERSION.Instance", {
        file_info: {
            filename: i,
            path: s,
            target: n,
            is_office: a,
            popup_win: t
        }
    })
}, Ext.ns("SYNO.SDS.Drive.Extension.HistoryBrowser"), SYNO.SDS.Drive.Extension.HistoryBrowser.checkFn = function(e, n) {
    var t = n[0],
        i = t.get("filename"),
        r = t.get("path"),
        o = t.get("isdir");
    return !!_S("is_admin") && (!!SYNO.SDS.Drive.Extension.Instance.isApplicationEnabled() && (!!SYNO.SDS.Drive.Extension.Instance.isInCloudStationFolder(r) && !SYNO.SDS.Drive.Extension.Instance.isOfficeFile(i, o)))
}, SYNO.SDS.Drive.Extension.HistoryBrowser.launchFn = function(e) {
    var n, t, i = e[0].get("filename"),
        r = e[0].get("path"),
        o = SYNO.SDS.Drive.Extension.Instance.splitPath(r),
        s = SYNO.SDS.Drive.Extension.Instance.getCloudStationRelativePath(r);
    n = "home" === o[0] ? "My Drive" : "Team Folder/" + o[0], t = "/root/" + n + (0 === s.lastIndexOf("/") ? "" : s.substr(0, s.lastIndexOf("/"))), SYNO.SDS.AppLaunch("SYNO.SDS.CSTN.Explore.Instance", {
        path: t,
        filename: i
    })
};
