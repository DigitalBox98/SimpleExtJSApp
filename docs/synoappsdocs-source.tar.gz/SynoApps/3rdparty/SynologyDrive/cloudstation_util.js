/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.CSTN.Icon
 * SynologyDrive icon util 
 *
 */
Ext.define("SYNO.SDS.CSTN.Icon", {
    statics: {
        FOLDER_ICON: "folder.png",
        FILE_ICON: "file.png",
        EXT_ICON_PREFIX: "normal/",
        ENCRYPTED_FILE_EXT_ICONS: {
            odoc: "synodoc_encrypted.png",
            osheet: "synosheet_encrypted.png",
            oslides: "synoslides_encrypted.png"
        },
        FILE_EXT_ICONS: {
            "3fr": "bmp.png",
            "3g2": "avi.png",
            "3gp": "avi.png",
            "7z": "tar.png",
            aac: "mp3.png",
            ac3: "mp3.png",
            acc: "acc.png",
            accdb: "acc.png",
            accde: "acc.png",
            accdr: "acc.png",
            accdt: "acc.png",
            actproj: "js.png",
            ad: "js.png",
            ade: "acc.png",
            adn: "acc.png",
            adp: "acc.png",
            ai: "ai.png",
            aif: "mp3.png",
            akp: "js.png",
            amr: "avi.png",
            ape: "mp3.png",
            applescript: "js.png",
            arw: "bmp.png",
            as: "js.png",
            as3: "js.png",
            asax: "js.png",
            asc: "js.png",
            ascx: "js.png",
            asf: "avi.png",
            asm: "js.png",
            asmx: "js.png",
            asp: "js.png",
            aspx: "js.png",
            asr: "js.png",
            avi: "avi.png",
            bin: "iso.png",
            bmp: "bmp.png",
            bz2: "tar.png",
            c: "js.png",
            cc: "js.png",
            cda: "mp3.png",
            cmake: "js.png",
            coffee: "js.png",
            cpp: "js.png",
            cr2: "bmp.png",
            crw: "bmp.png",
            cs: "js.png",
            css: "js.png",
            cxx: "js.png",
            daa: "iso.png",
            dat: "avi.png",
            dcr: "bmp.png",
            diff: "txt.png",
            divx: "avi.png",
            dng: "bmp.png",
            doc: "doc.png",
            docx: "doc.png",
            dts: "mp3.png",
            "dvr-ms": "avi.png",
            erb: "js.png",
            erf: "bmp.png",
            erl: "txt.png",
            exe: "exe.png",
            f4v: "swf.png",
            fla: "fla.png",
            flac: "mp3.png",
            flv: "swf.png",
            folder: "folder.png",
            gif: "gif.png",
            groovy: "js.png",
            gvy: "js.png",
            gz: "tar.png",
            h: "js.png",
            haml: "js.png",
            hh: "js.png",
            hpp: "js.png",
            htm: "htm.png",
            html: "htm.png",
            hxx: "js.png",
            ico: "bmp.png",
            ifo: "avi.png",
            img: "iso.png",
            indd: "indd.png",
            iso: "iso.png",
            java: "js.png",
            jpe: "jpg.png",
            jpeg: "jpg.png",
            jpg: "jpg.png",
            js: "js.png",
            json: "txt.png",
            jsx: "js.png",
            k25: "bmp.png",
            kdc: "bmp.png",
            less: "js.png",
            lst: "txt.png",
            m: "js.png",
            m1v: "avi.png",
            m2t: "avi.png",
            m2ts: "avi.png",
            m2v: "avi.png",
            m4a: "mp3.png",
            m4b: "mp3.png",
            m4v: "avi.png",
            maf: "acc.png",
            make: "js.png",
            mam: "acc.png",
            maq: "acc.png",
            mar: "acc.png",
            markdown: "txt.png",
            mat: "acc.png",
            md: "txt.png",
            mda: "acc.png",
            mdb: "acc.png",
            mde: "acc.png",
            mdf: "acc.png",
            mdn: "acc.png",
            mdown: "txt.png",
            mds: "iso.png",
            mdt: "acc.png",
            mdw: "acc.png",
            mef: "bmp.png",
            mhtml: "js.png",
            mid: "mp3.png",
            misc: "misc.png",
            mka: "mp3.png",
            mkdn: "txt.png",
            mkv: "avi.png",
            ml: "js.png",
            mm: "js.png",
            mos: "bmp.png",
            mov: "avi.png",
            mp2: "mp3.png",
            mp3: "mp3.png",
            mp4: "avi.png",
            mpc: "mp3.png",
            mpe: "avi.png",
            mpeg: "avi.png",
            mpeg1: "avi.png",
            mpeg2: "avi.png",
            mpeg4: "avi.png",
            mpg: "avi.png",
            mrw: "bmp.png",
            mts: "avi.png",
            nef: "bmp.png",
            nrg: "iso.png",
            odp: "ppt.png",
            ogg: "mp3.png",
            ogv: "avi.png",
            orf: "bmp.png",
            otf: "ttf.png",
            out: "txt.png",
            patch: "txt.png",
            pcm: "mp3.png",
            pdf: "pdf.png",
            pef: "bmp.png",
            php: "js.png",
            pl: "js.png",
            plist: "js.png",
            png: "png.png",
            pps: "ppt.png",
            ppsx: "ppt.png",
            ppt: "ppt.png",
            pptx: "ppt.png",
            properties: "js.png",
            psd: "psd.png",
            ptx: "bmp.png",
            py: "js.png",
            qt: "avi.png",
            ra: "mp3.png",
            raf: "bmp.png",
            rar: "rar.png",
            raw: "bmp.png",
            rb: "js.png",
            rm: "avi.png",
            rmvb: "avi.png",
            rtf: "doc.png",
            rw2: "bmp.png",
            sass: "js.png",
            scala: "js.png",
            scm: "js.png",
            script: "js.png",
            scss: "js.png",
            sh: "js.png",
            sml: "txt.png",
            sql: "js.png",
            sr2: "bmp.png",
            srf: "bmp.png",
            swf: "swf.png",
            swift: "js.png",
            tar: "tar.png",
            tbz: "tar.png",
            tgz: "tar.png",
            tif: "bmp.png",
            tiff: "bmp.png",
            tp: "avi.png",
            trp: "avi.png",
            ts: "avi.png",
            tsx: "js.png",
            ttc: "ttf.png",
            ttf: "ttf.png",
            txt: "txt.png",
            ufo: "bmp.png",
            vb: "js.png",
            vi: "js.png",
            vim: "js.png",
            vob: "avi.png",
            wav: "mp3.png",
            webm: "avi.png",
            wma: "wma.png",
            wmv: "avi.png",
            wri: "doc.png",
            x3f: "bmp.png",
            xhtml: "js.png",
            xla: "xls.png",
            xlam: "xls.png",
            xlb: "xls.png",
            xlc: "xls.png",
            xld: "xls.png",
            xlk: "xls.png",
            xll: "xls.png",
            xlm: "xls.png",
            xls: "xls.png",
            xlsb: "xls.png",
            xlsm: "xls.png",
            xlsx: "xls.png",
            xlt: "xls.png",
            xltm: "xls.png",
            xlv: "xls.png",
            xlw: "xls.png",
            xml: "js.png",
            xsd: "js.png",
            xsl: "js.png",
            xvid: "avi.png",
            yaml: "js.png",
            yml: "js.png",
            zip: "tar.png",
            odoc: "synodoc.png",
            osheet: "synosheet.png",
            oslides: "synoslides.png"
        }
    }
}), Ext.ns("SYNO.SDS.CSTN"), SYNO.SDS.CSTN.IsDSM7OrAbove = function() {
    return _S("majorversion") >= 7
}, SYNO.SDS.CSTN.DBG = function(e) {
    SYNO.Debug(e)
}, SYNO.SDS.CSTN.CGI_PATH = "webapi/entry.cgi", SYNO.SDS.CSTN.WEBAPI_NAMESPACE = "SYNO.SynologyDrive", SYNO.SDS.CSTN.WIN_WIDTH = 1200, SYNO.SDS.CSTN.VERSION_WIN_WIDTH = SYNO.SDS.CSTN.IsDSM7OrAbove() ? 1e3 : 1200, SYNO.SDS.CSTN.DEFAULT_HEIGHT = 580, SYNO.SDS.CSTN.WIN_MINWIDTH = 968, SYNO.SDS.CSTN.WIN_MINHEIGHT = SYNO.SDS.CSTN.IsDSM7OrAbove() ? 568 : 580, SYNO.SDS.CSTN.WIN_MAXWIDTH = 1024, SYNO.SDS.CSTN.WIN_MAXHEIGHT = 580, SYNO.SDS.CSTN.LIST_WIDTH = 220, SYNO.SDS.CSTN.CARD_WIDTH = 748, SYNO.SDS.CSTN.FORM_LABELWIDTH = 230, SYNO.SDS.CSTN.FORM_TEXTWIDTH = 150, SYNO.SDS.CSTN.FORM_NUMWIDTH = 50;
var _STR = function(e, t) {
    var S = _TT("SYNO.SDS.CSTN.Instance", e, t) || _T(e, t);
    return S || e + ":" + t
};
SYNO.SDS.CSTN.LogType = {
        cloudstn_save: 0,
        priv_save: 1,
        share_save: 2,
        client_unlink: 3,
        restore_node: 4,
        delfile_forever: 5,
        delfile_recyclebin: 6,
        rotate_set: 7,
        volume_set: 8,
        log_rotate_cnt_set: 9,
        log_rotate_span_set: 10,
        log_delete: 11,
        client_link: 12,
        add_event: 13,
        remove_event: 14,
        modify_event: 15,
        version_rotate: 16,
        rename_event: 17,
        copy_event: 18,
        restore_a_copy_event: 19,
        delete_from_bin_event: 20,
        restore_from_bin_event: 21,
        log_export: 22,
        download_event: 23,
        preview_event: 24,
        normal_link_permission: 25,
        normal_link_download: 26,
        normal_link_invitee: 27,
        adv_link_create: 28,
        adv_link_delete: 29,
        adv_link_permission: 30,
        adv_link_download: 31,
        adv_link_password: 32,
        adv_link_expiration: 33,
        log_rotate_policy: 34,
        ownship_transfer: 35
    }, SYNO.SDS.CSTN.LogEvent = {
        files: 0,
        sharing: 1,
        service: 2,
        admin_action: 3
    }, SYNO.SDS.CSTN.getLogSpanOptions = function() {
        return [
            [2592e3, _STR("log", "del_time_1_mon")],
            [7776e3, _STR("log", "del_time_3_mon")],
            [15552e3, _STR("log", "del_time_6_mon")],
            [31104e3, _STR("log", "del_time_1_year")]
        ]
    }, SYNO.SDS.CSTN.getMaxLogCountOptions = function() {
        return [
            [1e6, _STR("log", "del_cnt_1_mil")],
            [3e6, _STR("log", "del_cnt_3_mil")],
            [5e6, _STR("log", "del_cnt_5_mil")],
            [1e7, _STR("log", "del_cnt_10_mil")],
            [5e7, _STR("log", "del_cnt_50_mil")]
        ]
    }, SYNO.SDS.CSTN.ErrorCode = {}, SYNO.SDS.CSTN.ErrorTable = {},
    function() {
        function e(e, t, S, n, o) {
            SYNO.SDS.CSTN.ErrorCode[t] = e, SYNO.SDS.CSTN.ErrorTable[e] = {
                msg: o,
                msgKey: S,
                msgValue: n
            }
        }
        e(102, "NO_SUCH_API", void 0, void 0, SYNO.API.getErrorString(102)), e(401, "GENERIC", "warning", "err_sys"), e(402, "ADMIN_ONLY", "warning", "err_admin_only"), e(403, "CANNOT_ACCESS", "warning", "error_privilege_not_enough"), e(404, "GET_CLIENT_DOWNLOAD_LINK", "warning", "err_get_download_link_fail"), e(405, "DOWNLOAD_TASK_RUNNING", "warning", "download_single_task"), e(406, "RESTORE_TASK_RUNNING", "warning", "restore_single_task"), e(407, "DELETE_TASK_RUNNING", "warning", "delete_single_task"), e(408, "RESTORE_CONFLICT", "warning", "restore_conflict"), e(409, "RESTORE_NO_SPACE", "warning", "restore_err_no_space"), e(410, "DBUSAGE_TASK_RUNNING", void 0, void 0, "db_usage_task_running"), e(411, "TRANSFER_RUNNING", "warning", "transfer_running"), e(412, "TRANSFER_USER_INVALID", "warning", "transfer_user_invalid"), e(500, "PKG_NOT_ENABLED", "warning", "err_drive_disabled"), e(501, "SERVICE_DISABLED", "warning", "err_drive_disabled"), e(502, "SYS_DISK_FULL", "cstn", "drive_diskfull_desc"), e(503, "REPO_MOVE", "warning", "error_drive_repomove"), e(600, "LOCAL_DISK_FULL", "warning", "not_enough_space"), e(601, "NO_SUCH_VOLUME", "warning", "error_volume_not_found"), e(602, "VOLUME_READONLY", "warning", "error_volume_readonly"), e(603, "SHARE_NOT_MOUNT", "warning", "error_not_mounted"), e(604, "INVALID_REPO", "warning", "invalid_repo_path"), e(701, "USERKEY_CONFLICT", "warning", "user_key_conflict"), e(702, "INVALID_USERKEY", "warning", "invalid_user_key"), e(703, "NO_SUCH_USER", "warning", "no_such_user"), e(800, "WRONG_PASSWORD", "common", "err_pass"), e(900, "C2_SERVER_OFFLINE", "warning", "c2_server_offline"), e(1027, "ERR_MYDRIVE_DISABLED", "warning", "err_enable_homes")
    }(), SYNO.SDS.CSTN.RenderUserStatus = function(e) {
        return "normal" === e ? '<span class="green-status">' + _STR("common", "normal") + "</span>" : "disabled" === e ? '<span class="red-status">' + _STR("common", "disable") + "</span>" : "home_disabled" === e ? '<span class="red-status">' + _STR("common", "home_disable") + "</span>" : void 0
    }, SYNO.SDS.CSTN.RenderShareName = function(e, t, S) {
        var n;
        return n = "homes/mydrive" == e ? _STR("cstn", "users_my_drive") : e, "c2_share" == S.get("share_type") && (n = "<span>" + n + '</span><span class="syno-cstn-panel-sharing-hybrid-share" ext:qtip="' + _STR("common", "hybrid_share_folder") + '">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>'), n
    }, SYNO.SDS.CSTN.RenderShareStatus = function(e, t, S) {
        var n, o = S.get("share_enable"),
            a = S.get("share_status"),
            r = S.get("share_name");
        return n = !0 === o ? "encrypt" === a ? '<span class="red-status">' + _STR("common", "share_not_mounted") + "</span>" : "home_not_supported" === a ? '<span class="red-status" ext:qtip="' + _STR("common", "home_not_supported_tip") + '">' + _STR("common", "home_not_supported") + "</span>" : '<span class="green-status">' + _STR("common", "enable") + "</span>" : "home_disabled" === a ? '<span class="red-status">' + _STR("common", "home_disable") + "</span>" : "not_available" === a ? '<span class="gray-status" ext:qtip="' + _STR("common", "sharedfolder_not_available_tip") + '">' + _STR("common", "not_available") + "</span>" : "not_supported" === a ? '<span class="gray-status" ext:qtip="' + _STR("common", "shared_on_cold_storage_not_supported_tip") + '">' + _STR("common", "not_available") + "</span>" : '<span class="gray-status">' + _STR("common", "can_be_enabled") + "</span>", "homes" === r && (n += '<span class="syno-cstn-panel-sharing-homes" ext:qtip="' + _STR("info_tip", "teamfolder_homes_tooltip") + '">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>'), n
    }, SYNO.SDS.CSTN.RenderShareRotateCount = function(e, t, S) {
        return "0" == e ? _STR("common", "none") : e
    }, SYNO.SDS.CSTN.RenderShareRotatePolicy = function(e) {
        return "-" != e ? "smart" == e ? _STR("common", "on") : _STR("common", "off") : e
    }, SYNO.SDS.CSTN.PrintFakePass = function(e) {
        return "$$$$$$$$" == e ? '<font color="red">Wrong Password</font>' : "@@@@@@@@" == e ? "" : "********" == e ? "********" : "Modified"
    }, SYNO.SDS.CSTN.RenderUpTime = function(e) {
        if (0 > (e = Number(e))) return "N/A";
        var t = Math.floor(e / 3600),
            S = Math.floor(e % 3600 / 60),
            n = Math.floor(e % 3600 % 60);
        return (t > 0 ? t + ":" : "") + (S > 0 ? (t > 0 && S < 10 ? "0" : "") + S + ":" : "0:") + (n < 10 ? "0" : "") + n
    }, SYNO.SDS.CSTN.CalculateSizeUnit = function(e) {
        for (var t = ["B", "KB", "MB", "GB", "TB", "PB"], S = 0; e >= 1024 && S != t.length - 1;) e /= 1024, S++;
        return (Math.round(10 * e) / 10).toString() + " " + t[S]
    }, SYNO.SDS.CSTN.cbLoad = function() {
        this.getStore().load()
    }, SYNO.SDS.CSTN.getErrorString = function(e) {
        if (SYNO.SDS.CSTN.ErrorTable.hasOwnProperty(e.code)) {
            var t = SYNO.SDS.CSTN.ErrorTable[e.code];
            return t.msg || (t.msg = _STR(t.msgKey, t.msgValue)), t.msg
        }
        return SYNO.API.getErrorString(e.code)
    }, SYNO.SDS.CSTN.needCloseWindow = function(e) {
        switch (e) {
            case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
            case SYNO.SDS.CSTN.ErrorCode.REPO_MOVE:
            case SYNO.SDS.CSTN.ErrorCode.PKG_NOT_ENABLED:
            case SYNO.SDS.CSTN.ErrorCode.SERVICE_DISABLED:
            case SYNO.SDS.CSTN.ErrorCode.CANNOT_ACCESS:
                return !0
        }
        return !1
    }, SYNO.SDS.CSTN.webapiErrHdl = function(e) {
        var t, S, n = !1;
        t = e.has_fail ? SYNO.API.Util.GetFirstError(e) : e, SYNO.SDS.CSTN.needCloseWindow(t.code) && (n = !0), S = SYNO.SDS.CSTN.getErrorString(t), this.owner.getMsgBox().alert(_STR("app", "app_name"), S, function() {
            _S("is_admin") && !n || this.owner.close()
        }, this)
    }, SYNO.SDS.CSTN.webapiErrHdlMain = function(e) {
        var t, S, n = !1;
        t = e.has_fail ? SYNO.API.Util.GetFirstError(e) : e, SYNO.SDS.CSTN.needCloseWindow(t.code) && (n = !0), S = SYNO.SDS.CSTN.getErrorString(t), this.owner.getMsgBox().alert(_STR("app", "app_name"), S, function() {
            _S("is_admin") && !n || this.owner.close(), this.owner.selectPage && this.owner.selectPage("SYNO.SDS.CSTN.PanelCloudStn")
        }, this)
    }, SYNO.SDS.CSTN.webapiHdl = function(e, t, S, n, o) {
        if (this.owner.clearStatusBusy(), e || t && (t.code || t.has_fail)) {
            var a = t && t.has_fail,
                r = e && !a ? o.success : o.failure;
            Ext.isFunction(r) && r.call(this, t)
        } else this.owner.getMsgBox().alert(_STR("app", "app_name"), _T("common", "error_system"))
    }, SYNO.SDS.CSTN.GetDownloadIframe = function() {
        var e = Ext.fly("cstn_dl_iframe");
        if (e) {
            e.removeAllListeners(), e = e.dom;
            try {
                var t = Ext.isIE ? e.contentWindow.document : e.contentDocument || window.frames[e.id].document;
                t.open(), t.close()
            } catch (e) {
                return this.owner.getMsgBox().alert(_T("service", "service_cloudstation_title"), _T("common", "error_system")), Ext.destroy(Ext.get("cstn_dl_iframe")), null
            }
        } else e = Ext.DomHelper.append(document.body, {
            tag: "iframe",
            id: "cstn_dl_iframe",
            frameBorder: 0,
            width: 0,
            height: 0,
            css: "display:none;visibility:hidden;height:1px;"
        }), e.src = Ext.SSL_SECURE_URL;
        return e
    }, SYNO.SDS.CSTN.replaceDLNameSpecChars = function(e) {
        return e.replace(/[\/\\\:\?\><\*\"\;\|\#\%]/g, "-")
    }, SYNO.SDS.CSTN.getFormatDateTime = function(e) {
        return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
            type: "datetimesec"
        }) : e.format("Y-m-d H:i:s")
    }, SYNO.SDS.CSTN.getFormatDate = function(e) {
        return SYNO.SDS.DateTimeFormatter ? SYNO.SDS.DateTimeFormatter(e, {
            type: "date"
        }) : e.format("Y-m-d")
    }, SYNO.SDS.CSTN.getDateFormat = function() {
        return SYNO.SDS.DateTimeUtils ? SYNO.SDS.DateTimeUtils.GetDateFormat() : "Y-m-d"
    }, SYNO.SDS.CSTN.RenderClientType = function(e) {
        switch (e) {
            case "web_portal":
                return _STR("clientinfo", "client_web_portal");
            case "serversync":
                return _STR("clientinfo", "client_serversync");
            case "drive":
            case "drive_backup":
                return _STR("clientinfo", "client_drive");
            case "drive_mobile":
                return _STR("clientinfo", "client_drive_mobile");
            case "system":
                return _STR("common", "others");
            default:
                return "--"
        }
    }, SYNO.SDS.CSTN.RenderLog = function(e) {
        var t, S, n, o, a = SYNO.SDS.CSTN.LogType,
            r = "",
            i = {
                share_name_field: "target_share_name",
                share_type_field: "target_share_type",
                link_prefix_field: "target_link_prefix",
                accessable_field: "target_accessable"
            },
            s = {
                UnknownRole: "0",
                DeniedRole: "1",
                ViewerRole: "2",
                CommenterRole: "3",
                EditorRole: "4",
                OrganizerRole: "5",
                PreviewerRole: "6",
                PreviewCommenterRole: "7"
            },
            _ = {
                UnknownTarget: "0",
                UserTarget: "1",
                GroupTarget: "2",
                InternalTarget: "3",
                PublicTarget: "4"
            },
            l = {
                False: "0",
                True: "1"
            },
            p = {
                log_cnt: "0",
                log_span: "1"
            };
        switch (o = e.get("username"), "" === o && (o = _STR("common", "system")), e.get("type")) {
            case a.cloudstn_save:
                t = "1" === e.get("p1") ? _STR("log", "log_action_enable") : _STR("log", "log_action_disable"), r = "1" === e.get("p1") ? _STR("log", "log_drive_enable") : _STR("log", "log_drive_disable");
                break;
            case a.priv_save:
                t = "1" === e.get("p1") ? _STR("log", "log_action_enable") : _STR("log", "log_action_disable"), r = String.format(_STR("log", "log_priv_save"), o, t, e.get("s2"));
                break;
            case a.share_save:
                t = "1" === e.get("p1") ? _STR("log", "log_action_enable") : _STR("log", "log_action_disable"), r = String.format(_STR("log", "log_share_save"), o, t, SYNO.SDS.CSTN.GetShareFolderLink(e));
                break;
            case a.client_unlink:
                r = String.format(_STR("log", "log_client_unlink_device"), o, e.get("s1"), e.get("s2"));
                break;
            case a.restore_node:
                r = String.format(_STR("log", "log_restore_node"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.delfile_forever:
                r = String.format(_STR("log", "log_delfile_forever"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.delfile_recyclebin:
                r = 1 !== e.get("share_type") ? String.format(_STR("log", "log_delfile_all_in_home"), o, e.get("share_name")) : String.format(_STR("log", "log_delfile_all"), o, e.get("share_name"));
                break;
            case a.rotate_set:
                if ("" === e.get("s1")) r = String.format(_STR("log", "log_rotate_set"), o, e.get("p1"));
                else {
                    var g = "default" === e.get("p1") ? _STR("common", "default") : e.get("p1");
                    r = "homes" === e.get("s1") ? String.format(_STR("log", "log_view_rotate_set_home"), o, g) : String.format(_STR("log", "log_view_rotate_set"), o, SYNO.SDS.CSTN.GetShareFolderLink(e), g)
                }
                break;
            case a.volume_set:
                var c = _STR("common", "volume_info") + " " + e.get("p1").substr(7),
                    m = _STR("common", "volume_info") + " " + e.get("p2").substr(7);
                r = String.format(_STR("log", "log_volume_set"), o, c, m);
                break;
            case a.log_rotate_cnt_set:
                var N, T = SYNO.SDS.CSTN.getMaxLogCountOptions();
                for (n = 0; n < T.length; n++) parseInt(e.get("p2"), 10) == T[n][0] && (N = T[n][1]);
                r = String.format(_STR("log", "log_logrotate_cnt_change"), o, N);
                break;
            case a.log_rotate_span_set:
                var d, f = SYNO.SDS.CSTN.getLogSpanOptions();
                for (n = 0; n < f.length; n++) parseInt(e.get("p2"), 10) == f[n][0] && (d = f[n][1]);
                r = String.format(_STR("log", "log_logrotate_span_change"), o, d);
                break;
            case a.log_delete:
                r = String.format(_STR("log", "log_delete"), o);
                break;
            case a.client_link:
                r = String.format(_STR("log", "log_client_link"), o, Ext.util.Format.htmlEncode(e.get("s1")));
                break;
            case a.add_event:
                "/" === e.get("s1") ? r = 1 !== e.get("share_type") ? String.format(_STR("log", "log_add_user_home_event"), o, e.get("share_name")) : String.format(_STR("log", "log_add_event"), o, _STR("log", "log_shared_folder"), SYNO.SDS.CSTN.GetShareFolderLink(e)) : (S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = "" === e.get("s2") ? String.format(_STR("log", "log_add_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_add_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"), Ext.util.Format.htmlEncode(e.get("s2"))));
                break;
            case a.remove_event:
                S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = "" === e.get("s2") ? String.format(_STR("log", "log_remove_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_remove_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"), Ext.util.Format.htmlEncode(e.get("s2")));
                break;
            case a.modify_event:
                var O = o.split(",").length;
                O > 1 && (o = o.split(",")[0]), "/" === e.get("s1") ? r = 1 !== e.get("share_type") ? String.format(_STR("log", "log_modify_user_home_event"), o, e.get("share_name")) : String.format(_STR("log", "log_modify_share_folder_event"), o, SYNO.SDS.CSTN.GetShareFolderLink(e)) : (S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = "" === e.get("s2") ? O > 2 ? String.format(_STR("log", "log_modify_event_with_others"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : 2 == O ? String.format(_STR("log", "log_modify_event_with_another"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_modify_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_modify_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"), Ext.util.Format.htmlEncode(e.get("s2"))));
                break;
            case a.version_rotate:
                r = "/" === e.get("s1") ? 1 !== e.get("share_type") ? String.format(_STR("log", "log_version_rotate_user_home"), e.get("share_name")) : String.format(_STR("log", "log_version_rotate_share_folder"), SYNO.SDS.CSTN.GetShareFolderLink(e)) : String.format(_STR("log", "log_version_rotate"), SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.rename_event:
                if (S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), "" === e.get("s4")) r = "" === e.get("s3") ? String.format(_STR("log", "log_rename_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s2", {
                    is_accessable: e.get("p3"),
                    file_type: e.get("p2"),
                    open_type: "version",
                    node_id: e.get("p3")
                }), SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_rename_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s2", {
                    is_accessable: e.get("p3"),
                    file_type: e.get("p2"),
                    open_type: "version",
                    node_id: e.get("p3")
                }), SYNO.SDS.CSTN.GetFileLink(e, "s1"), Ext.util.Format.htmlEncode(e.get("s3")));
                else {
                    var D = {};
                    e.get("target_share_name") && (D = i), r = "" === e.get("s3") ? String.format(_STR("log", "log_move_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1", Ext.apply({}, D)), SYNO.SDS.CSTN.GetFileLink(e, "s5", {
                        is_accessable: e.get("p5"),
                        file_type: "1"
                    }), SYNO.SDS.CSTN.GetFileLink(e, "s4", Ext.apply({
                        is_accessable: e.get("p4"),
                        file_type: "1"
                    }, D))) : String.format(_STR("log", "log_move_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1", Ext.apply({}, D)), SYNO.SDS.CSTN.GetFileLink(e, "s5", {
                        is_accessable: e.get("p5"),
                        file_type: "1"
                    }), SYNO.SDS.CSTN.GetFileLink(e, "s4", Ext.apply({
                        is_accessable: e.get("p4"),
                        file_type: "1"
                    }, D)), Ext.util.Format.htmlEncode(e.get("s3")))
                }
                break;
            case a.copy_event:
                S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = "" === e.get("s3") ? String.format(_STR("log", "log_copy_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1", Ext.apply({}, i)), SYNO.SDS.CSTN.GetFileLink(e, "s5", {
                    is_accessable: e.get("p5"),
                    file_type: "1"
                }), SYNO.SDS.CSTN.GetFileLink(e, "s4", Ext.apply({
                    is_accessable: e.get("p4"),
                    file_type: "1"
                }, i))) : String.format(_STR("log", "log_copy_event_from"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1", Ext.apply({}, i)), SYNO.SDS.CSTN.GetFileLink(e, "s5", {
                    is_accessable: e.get("p5"),
                    file_type: "1"
                }), SYNO.SDS.CSTN.GetFileLink(e, "s4", Ext.apply({
                    is_accessable: e.get("p4"),
                    file_type: "1"
                }, i)), Ext.util.Format.htmlEncode(e.get("s3")));
                break;
            case a.restore_a_copy_event:
                r = String.format(_STR("log", "log_restore_a_copy"), o, SYNO.SDS.CSTN.GetFileLink(e, "s2", {
                    is_accessable: e.get("p3"),
                    file_type: e.get("p2"),
                    open_type: "version",
                    node_id: e.get("p3")
                }), SYNO.SDS.CSTN.GetFileLink(e, "s4", Ext.apply({
                    is_accessable: e.get("p4"),
                    file_type: "1"
                }, i)));
                break;
            case a.restore_from_bin_event:
                S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = String.format(_STR("log", "log_restore_from_recycle_bin"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.delete_from_bin_event:
                S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = String.format(_STR("log", "log_delete_from_recycle_bin"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.log_export:
                r = String.format(_STR("log", "log_export"), o);
                break;
            case a.download_event:
                S = SYNO.SDS.CSTN.GetFileTypeString(e.get("p2")), r = String.format(_STR("log", "log_download_event"), o, S, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.preview_event:
                r = String.format(_STR("log", "log_preview_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.normal_link_permission:
                var u = e.get("p2"),
                    C = e.get("p3"),
                    v = e.get("p4"),
                    b = e.get("p5"),
                    Y = function(e, t) {
                        var S = "";
                        return t === s.DeniedRole ? S = _STR("perm", "limit") + " - " + _STR("perm", "limit_desc") : e === _.InternalTarget ? (S = _STR("perm", "app") + " - ", t === s.ViewerRole || t === s.PreviewerRole ? S += _STR("perm", "app_ro_desc") : t === s.CommenterRole || t === s.PreviewCommenterRole ? S += _STR("perm", "app_commenter_desc") : t !== s.EditorRole && t !== s.OrganizerRole || (S += _STR("perm", "app_rw_desc"))) : e === _.PublicTarget && (S = _STR("perm", "public") + " - ", t === s.ViewerRole || t === s.PreviewerRole ? S += _STR("perm", "public_ro_desc") : t === s.CommenterRole || t === s.PreviewCommenterRole ? S += _STR("perm", "public_commenter_desc") : t !== s.EditorRole && t !== s.OrganizerRole || (S += _STR("perm", "public_rw_desc"))), 0 === S.length && (S = _STR("perm", "limit") + " - " + _STR("perm", "limit_desc")), S
                    },
                    R = Y(v, b),
                    y = Y(u, C);
                r = String.format(_STR("log", "log_link_permission_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"), R, y);
                break;
            case a.normal_link_download:
                r = "1" === e.get("p2") ? String.format(_STR("log", "log_allow_link_download_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_disallow_link_download_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.normal_link_invitee:
                var h = e.get("p2"),
                    k = e.get("s2"),
                    I = e.get("p4"),
                    x = e.get("p5"),
                    E = "";
                switch (I) {
                    case s.ViewerRole:
                        E = _STR("perm", "viewer").toLowerCase();
                        break;
                    case s.CommenterRole:
                        E = _STR("perm", "commenter").toLowerCase();
                        break;
                    case s.EditorRole:
                        E = _STR("perm", "editor").toLowerCase();
                        break;
                    case s.OrganizerRole:
                        E = _STR("perm", "manager").toLowerCase();
                        break;
                    case s.PreviewerRole:
                        E = _STR("perm", "previewer").toLowerCase();
                        break;
                    case s.PreviewCommenterRole:
                        E = _STR("perm", "preview_commenter").toLowerCase()
                }
                r = x === s.UnknownRole || x === s.DeniedRole ? String.format(_STR("log", "log_new_link_invitee_event"), o, k, E, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : I === s.UnknownRole || I === s.DeniedRole ? String.format(_STR("log", "log_delete_link_invitee_event"), o, k, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_change_link_invitee_event"), o, k, E, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.adv_link_create:
                r = String.format(_STR("log", "log_adv_link_create_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.adv_link_delete:
                r = String.format(_STR("log", "log_adv_link_delete_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.adv_link_permission:
                var I = e.get("p2"),
                    x = e.get("p3"),
                    Y = function(e) {
                        switch (e) {
                            case s.ViewerRole:
                            case s.PreviewerRole:
                                return _STR("perm", "public_ro_desc");
                            case s.CommenterRole:
                            case s.PreviewCommenterRole:
                                return _STR("perm", "public_commenter_desc");
                            case s.EditorRole:
                            case s.OrganizerRole:
                                return _STR("perm", "public_rw_desc")
                        }
                        return ""
                    },
                    y = Y(I),
                    R = Y(x);
                r = String.format(_STR("log", "log_link_permission_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"), R, y);
                break;
            case a.adv_link_download:
                r = e.get("p2") === l.True ? String.format(_STR("log", "log_allow_adv_link_download_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_disallow_adv_link_download_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.adv_link_password:
                r = e.get("p2") === l.True ? String.format(_STR("log", "log_adv_link_password_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1")) : String.format(_STR("log", "log_adv_link_password_remove_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                break;
            case a.adv_link_expiration:
                if (e.get("p2") === l.False) r = String.format(_STR("log", "log_adv_link_expiration_remove_event"), o, SYNO.SDS.CSTN.GetFileLink(e, "s1"));
                else {
                    var w = SYNO.SDS.CSTN.getFormatDate(new Date(1e3 * parseInt(e.get("p2"))));
                    r = String.format(_STR("log", "log_adv_link_expiration_event"), o, w, SYNO.SDS.CSTN.GetFileLink(e, "s1"))
                }
                break;
            case a.log_rotate_policy:
                var h = e.get("p1"),
                    L = "1" === e.get("p2");
                if (h === p.log_cnt) {
                    var N, T = SYNO.SDS.CSTN.getMaxLogCountOptions();
                    for (n = 0; n < T.length; n++) parseInt(e.get("p3"), 10) == T[n][0] && (N = T[n][1]);
                    r = L ? String.format(_STR("log", "log_logrotate_policy_cnt_enable"), o, N) : String.format(_STR("log", "log_logrotate_policy_cnt_disable"), o)
                } else if (h === p.log_span) {
                    var d, f = SYNO.SDS.CSTN.getLogSpanOptions();
                    for (n = 0; n < f.length; n++) parseInt(e.get("p3"), 10) == f[n][0] && (d = f[n][1]);
                    r = L ? String.format(_STR("log", "log_logrotate_policy_span_enable"), o, d) : String.format(_STR("log", "log_logrotate_policy_span_disable"), o)
                }
                break;
            case a.ownship_transfer:
                var A = e.get("s1"),
                    P = e.get("s2");
                r = String.format(_STR("log", "log_transfer_ownership"), o, A, P);
                break;
            default:
                r = "Type: " + e.get("type")
        }
        return r
    }, SYNO.SDS.CSTN.RenderUserName = function(e, t) {
        var S;
        return S = "" === e ? _STR("common", "system") : e.split(",").join(", "), t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(S) + '"'), S
    }, SYNO.SDS.CSTN.RenderTime = function(e, t) {
        var S, n;
        return e != parseInt(e, 10) ? e : (S = new Date(1e3 * e), n = SYNO.SDS.CSTN.getFormatDateTime(S), t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(n) + '"'), n)
    }, SYNO.SDS.CSTN.RenderLastDays = function(e, t) {
        if (e != parseInt(e, 10)) return e;
        var S = new Date(1e3 * e),
            n = SYNO.SDS.CSTN.getFormatDateTime(S);
        t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(n) + '"');
        var o = Math.abs((new Date).getTime() - S.getTime()),
            a = Math.floor(o / 864e5),
            r = Math.floor(o / 36e5),
            i = Math.floor(o / 6e4);
        return 0 === a && 0 === r ? i <= 1 ? String.format(_STR("common", "timediff_minute"), i.toString()) : String.format(_STR("common", "timediff_minutes"), i.toString()) : 0 === a ? r <= 1 ? String.format(_STR("common", "timediff_hour"), r.toString()) : String.format(_STR("common", "timediff_hours"), r.toString()) : a <= 1 ? String.format(_STR("common", "timediff_day"), a.toString()) : String.format(_STR("common", "timediff_days"), a.toString())
    }, SYNO.SDS.CSTN.RenderEventType = function(e) {
        var t = "";
        switch (e) {
            case SYNO.SDS.CSTN.LogType.cloudstn_save:
                t = _STR("log", "log_type_drive_save");
                break;
            case SYNO.SDS.CSTN.LogType.priv_save:
                t = _STR("log", "log_type_priv_save");
                break;
            case SYNO.SDS.CSTN.LogType.share_save:
                t = _STR("log", "log_type_share_save");
                break;
            case SYNO.SDS.CSTN.LogType.client_unlink:
                t = _STR("log", "log_type_client_unlink");
                break;
            case SYNO.SDS.CSTN.LogType.restore_node:
                t = _STR("log", "log_type_restore_node");
                break;
            case SYNO.SDS.CSTN.LogType.delfile_forever:
                t = _STR("log", "log_type_delfile_forever");
                break;
            case SYNO.SDS.CSTN.LogType.delfile_recyclebin:
                t = _STR("log", "log_type_delfile_recyclebin");
                break;
            case SYNO.SDS.CSTN.LogType.rotate_set:
                t = _STR("log", "log_type_rotate_set");
                break;
            case SYNO.SDS.CSTN.LogType.volume_set:
                t = _STR("log", "log_type_volume_set");
                break;
            case SYNO.SDS.CSTN.LogType.log_rotate_cnt_set:
                t = _STR("log", "log_type_log_rotate_cnt_set");
                break;
            case SYNO.SDS.CSTN.LogType.log_rotate_span_set:
                t = _STR("log", "log_type_log_rotate_span_set");
                break;
            case SYNO.SDS.CSTN.LogType.log_delete:
                t = _STR("log", "log_type_log_delete");
                break;
            case SYNO.SDS.CSTN.LogType.client_link:
                t = _STR("log", "log_type_client_link");
                break;
            case SYNO.SDS.CSTN.LogType.add_event:
                t = _STR("log", "log_type_add_event");
                break;
            case SYNO.SDS.CSTN.LogType.remove_event:
                t = _STR("log", "log_type_remove_event");
                break;
            case SYNO.SDS.CSTN.LogType.modify_event:
                t = _STR("log", "log_type_modify_event");
                break;
            case SYNO.SDS.CSTN.LogType.version_rotate:
                t = _STR("log", "log_type_version_rotate");
                break;
            case SYNO.SDS.CSTN.LogType.rename_event:
                t = _STR("log", "log_type_rename_event");
                break;
            case SYNO.SDS.CSTN.LogType.copy_event:
                t = _STR("log", "log_type_copy_event");
                break;
            case SYNO.SDS.CSTN.LogType.restore_a_copy_event:
                t = _STR("log", "log_type_restore_a_copy_event");
                break;
            case SYNO.SDS.CSTN.LogType.delete_from_bin_event:
                t = _STR("log", "log_type_delete_from_bin_event");
                break;
            case SYNO.SDS.CSTN.LogType.restore_from_bin_event:
                t = _STR("log", "log_type_restore_from_bin_event");
                break;
            case SYNO.SDS.CSTN.LogType.log_export:
                t = _STR("log", "log_type_log_export");
                break;
            case SYNO.SDS.CSTN.LogType.download_event:
                t = _STR("log", "log_type_download_event");
                break;
            case SYNO.SDS.CSTN.LogType.preview_event:
                t = _STR("log", "log_type_preview_event");
                break;
            case SYNO.SDS.CSTN.LogType.normal_link_permission:
            case SYNO.SDS.CSTN.LogType.adv_link_permission:
                t = _STR("log", "log_type_changed_link_perm");
                break;
            case SYNO.SDS.CSTN.LogType.normal_link_download:
                t = _STR("log", "log_type_allow_download_link");
                break;
            case SYNO.SDS.CSTN.LogType.adv_link_download:
                t = _STR("log", "log_type_allow_download_adv_link");
                break;
            case SYNO.SDS.CSTN.LogType.normal_link_invitee:
                t = _STR("log", "log_type_set_invitee_link");
                break;
            case SYNO.SDS.CSTN.LogType.adv_link_create:
            case SYNO.SDS.CSTN.LogType.adv_link_delete:
                t = _STR("log", "log_type_save_adv_link");
                break;
            case SYNO.SDS.CSTN.LogType.adv_link_password:
                t = _STR("log", "log_type_set_pass_adv_link");
                break;
            case SYNO.SDS.CSTN.LogType.adv_link_expiration:
                t = _STR("log", "log_type_set_expiration_adv_link");
                break;
            case SYNO.SDS.CSTN.LogType.log_rotate_policy:
                t = _STR("log", "log_type_rotate_policy");
                break;
            case SYNO.SDS.CSTN.LogType.ownship_transfer:
                t = _STR("log", "log_type_transfer_ownership");
                break;
            default:
                t = "--"
        }
        return t
    }, SYNO.SDS.CSTN.RenderIPAddress = function(e) {
        return /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(e) ? e : "--"
    }, SYNO.SDS.CSTN.GetFileTypeString = function(e) {
        return "1" === e ? _STR("log", "log_folder") : "2" === e ? "symbolic link" : _STR("log", "log_file")
    }, SYNO.SDS.CSTN.GetFileLink = function(e, t, S) {
        var n = "",
            o = "",
            a = "",
            r = e.get(t);
        return S = S || {}, Ext.applyIf(S, {
            open_type: "filestation",
            accessable_field: "accessable",
            share_name_field: "share_name",
            share_type_field: "share_type",
            link_prefix_field: "filestation_link_prefix"
        }), void 0 === S.file_type && (S.file_type = e.get("p2")), n = void 0 === S.is_accessable ? !0 === e.get(S.accessable_field) ? " syno-cstn-log-filename-exist" : "" : S.is_accessable ? " syno-cstn-log-filename-exist" : "", "/" == r ? (o = 1 !== e.get(S.share_type_field) ? _STR("common", "user_home") : _STR("log", "log_shared_folder") + " " + e.get(S.share_name_field), a = e.get(S.link_prefix_field)) : (o = r.substr(r.lastIndexOf("/") + 1), a = e.get(S.link_prefix_field) + r), "filestation" == S.open_type ? '<a data-open-type="filestation" data-file-type="' + S.file_type + '" data-path="' + Ext.util.Format.htmlEncode(a) + '" class="syno-cstn-log-filename' + n + '" ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(a)) + '">' + Ext.util.Format.htmlEncode(o) + "</a>" : '<a data-open-type="version" data-file-type="' + S.file_type + '" data-node-id="' + S.node_id + '" data-target="' + e.get("target") + '" data-path="' + Ext.util.Format.htmlEncode(a) + '" class="syno-cstn-log-filename' + n + '" ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(a)) + '">' + Ext.util.Format.htmlEncode(o) + "</a>"
    }, SYNO.SDS.CSTN.GetShareFolderLink = function(e) {
        var t;
        if (e.get("type") == SYNO.SDS.CSTN.LogType.share_save || e.get("type") == SYNO.SDS.CSTN.LogType.rotate_set) return '<a data-open-type="filestation" data-file-type="1" data-path="' + (t = "/" + e.get("s1")) + '" class="syno-cstn-log-filename syno-cstn-log-filename-exist" ext:qtip="' + t + '">' + e.get("s1") + "</a>";
        var S = !0 === e.get("accessable") ? " syno-cstn-log-filename-exist" : "";
        return '<a data-open-type="filestation" data-file-type="1" data-path="' + (t = "/" + e.get("share_name")) + '" class="syno-cstn-log-filename' + S + '" ext:qtip="' + t + '">' + e.get("share_name") + "</a>"
    }, SYNO.SDS.CSTN.GetFileSizeUnits = function() {
        return ["Byte", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"]
    }, SYNO.SDS.CSTN.HasOffice = function() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Office.AppInstance")
    }, Ext.ns("SYNO.SDS.CloudStation.SelectiveSync"), SYNO.SDS.CloudStation.SelectiveSync.getBuiltInExtensions = function() {
        return [{
            node_type: "music",
            display_name: _STR("common", "music"),
            icon_cls: "syno-tree-node-music",
            extensions: ["aac", "aif", "aifc", "aiff", "ape", "au", "cdda", "dff", "dsf", "eaac", "flac", "kar", "l16", "m3u", "m4a", "m4b", "m4p", "mid", "midi", "mp1", "mp2", "mp3", "mpc", "mpga", "ogg", "pcm", "pls", "ra", "ram", "snd", "tta", "vqf", "wav", "wma"]
        }, {
            node_type: "video",
            display_name: _STR("common", "video"),
            icon_cls: "syno-tree-node-video",
            extensions: ["3g2", "3gp", "aaf", "amr", "ani", "asf", "asx", "avi", "dat", "dif", "divx", "dv", "dvr-ms", "f4v", "flv", "ifo", "m1v", "m2t", "m2ts", "m2v", "m4u", "m4v", "mkv", "mov", "movie", "mp4", "mpe", "mpeg", "mpeg1", "mpeg2", "mpeg4", "mpg", "mts", "mxf", "mxu", "ogm", "ogv", "qt", "qtx", "rec", "rm", "rmvb", "swf", "tp", "trp", "ts", "vob", "webm", "wmv", "wmv9", "wmx", "xvid"]
        }, {
            node_type: "image",
            display_name: _STR("common", "image"),
            icon_cls: "syno-tree-node-image",
            extensions: ["3fr", "ari", "arw", "bay", "bmp", "cap", "cgm", "cr2", "crw", "dcr", "dcs", "djv", "djvu", "dng", "drf", "eip", "erf", "fff", "gif", "ico", "ief", "iff", "iiq", "ilbm", "jp2", "jpe", "jpeg", "jpg", "k25", "kdc", "lbm", "mac", "mef", "mng", "mos", "mrw", "nef", "nrw", "obm", "orf", "pbm", "pct", "pcx", "pef", "pgm", "pic", "pict", "png", "pnm", "pnt", "pntg", "ppm", "psd", "ptx", "pxn", "qti", "qtif", "r3d", "raf", "ras", "raw", "rgb", "rw2", "rwl", "rwz", "sr2", "srf", "srw", "svg", "tga", "tif", "tiff", "ufo", "wbmp", "x3f", "xbm", "xpm", "xwd"]
        }, {
            node_type: "document",
            display_name: _STR("common", "document"),
            icon_cls: "syno-tree-node-document",
            extensions: ["doc", "docx", "epub", "htm", "html", "key", "mobi", "numbers", "odp", "ods", "odt", "pages", "pdf", "pps", "ppsx", "ppt", "pptx", "prc", "txt", "xls", "xlsx"]
        }]
    }, SYNO.SDS.CloudStation.IsSRM = function() {
        return "SRM" === _D("os_name")
    }, SYNO.SDS.CloudStation.LaunchQuickConnectSetting = function() {
        SYNO.SDS.CloudStation.IsSRM() ? SYNO.SDS.AppLaunch("SYNO.SDS.NSMHome.Instance", {
            fn: "SYNO.SDS.NSMHome.Internet.Main",
            tab: "QuickConnectTab"
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
            fn: "SYNO.SDS.AdminCenter.QuickConnect.Main"
        })
    }, SYNO.SDS.CloudStation.LaunchHomeServiceSetting = function() {
        SYNO.SDS.CloudStation.IsSRM() ? _S("version") < 6360 ? SYNO.SDS.AppLaunch("SYNO.SDS.NSMUSBStorage.Instance", {
            fn: "SYNO.SDS.NSMUSBStorage.Privilege.Main",
            userHomeDialog: !0
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.NSMAdminCenter.Instance", {
            fn: "SYNO.SDS.NSMAdminCenter.User.Main",
            userHomeDialog: !0
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
            fn: "SYNO.SDS.AdminCenter.User.Main",
            userHomeDialog: !0
        })
    }, SYNO.SDS.CloudStation.SupportAppPrivilege = function() {
        return _S("majorversion") >= 6 || !!SYNO.SDS.CloudStation.IsSRM()
    }, SYNO.SDS.CloudStation.IsOfficeItem = function(e) {
        var t = e.lastIndexOf(".");
        return ["odoc", "osheet", "oslides"].indexOf(e.substr(t + 1).toLowerCase()) >= 0
    }, SYNO.SDS.CloudStation.getIconPath = function(e, t) {
        var S = "/images/files_ext/" + SYNO.SDS.CSTN.Icon.EXT_ICON_PREFIX + (SYNO.SDS.UIFeatures.test("isRetina") ? "2x/" : "1x/");
        if (t) return S + SYNO.SDS.CSTN.Icon.FOLDER_ICON;
        var n = e.toLowerCase().split(".").pop(),
            o = SYNO.SDS.CSTN.Icon.FILE_EXT_ICONS[n];
        return S + (o || SYNO.SDS.CSTN.Icon.FILE_ICON)
    }, SYNO.SDS.CSTN.SupportHybridShare = function() {
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.C2FS.Application")
    }, Ext.define("SYNO.SDS.CSTN.UIGuidelineStyle", {
        statics: {
            FONT_FAMILY: "Verdana, Arial, Microsoft JhengHei, sans-serif",
            COLOR_FONT_TIER1: "rgba(65,75,85,1)",
            COLOR_FONT_TIER2: "rgba(65,75,85,0.6)",
            COLOR_BORDER_TIER1: "rgba(198,212,224,0.9)",
            COLOR_BORDER_TIER2: "rgba(198,212,224,0.7)",
            COLOR_BORDER_TIER3: "rgba(198,212,224,0.4)"
        }
    }),
    function() {
        function e(e, t) {
            var S = e ? "." + e : "",
                n = Ext.ns("SYNO.SDS.CSTN.WebAPI" + S);
            Ext.apply(n, t), n.api = SYNO.SDS.CSTN.WEBAPI_NAMESPACE + S
        }
        e(void 0, {
            request: function(e, t, S, n, o) {
                this.sendWebAPI({
                    api: e,
                    version: 1,
                    method: t,
                    params: S,
                    callback: n,
                    scope: o || this
                })
            },
            getStatus: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "get_status", {}, e, t)
            },
            getDirSrvStatus: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "get_directory_service_status", {}, e, t)
            },
            getClientLink: function(e, t, S, n, o) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "get_client_link", {
                    os_type: e,
                    platform: t,
                    app: S
                }, n, o)
            },
            getExtension: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "get_extension", {}, e, t)
            },
            checkUser: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "check_user", {}, e, t)
            },
            deleteDatabase: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "delete_database", {}, e, t)
            },
            resumeFreeze: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.api, "resume_freeze", {}, e, t)
            }
        }), e("Node", {
            list: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.api, "list", Ext.copyTo({}, t, "offset,limit,sort_by,sort_direction,target,node_id,path,pattern,recursive"), S, n)
            },
            listParent: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.api, "list_parent", {
                    target: e,
                    node_id: t
                }, S, n)
            },
            listVersion: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.api, "list_version", Ext.copyTo({
                    target: e
                }, t, "node_id,path"), S, n)
            },
            dryrun: function(e, t, S, n, o, a) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.api, "dry_run", {
                    target: e,
                    nodes: t,
                    include_removed: S,
                    view_role: n
                }, o, a)
            }
        }), e("Dashboard", {
            top_access_files: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Dashboard.api, "top_access_files", Ext.copyTo({}, e, "offset,limit,ranking_by"), t, S)
            }
        }), e("Statistics", {
            top_access_files: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Dashboard.api, "get", {}, t, S)
            }
        }), e("Migration.UserHome", {
            start: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api, "start", {}, t, S)
            },
            list: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api, "list", {}, t, S)
            },
            status: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api, "status", {}, t, S)
            }
        }), e("Node.Restore", {
            start: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Restore.api, "start", {
                    target: e,
                    nodes: t
                }, S, n)
            },
            status: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Restore.api, "status", {}, e, t)
            },
            finish: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Restore.api, "finish", {}, e, t)
            }
        }), e("Node.Download", {
            start: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Download.api, "start", {
                    target: e,
                    nodes: t
                }, S, n)
            },
            status: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Download.api, "status", {}, e, t)
            },
            stop: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Download.api, "stop", {}, e, t)
            }
        }), e("Node.Delete", {
            start: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Delete.api, "start", Ext.copyTo({
                    target: e
                }, t, "fileinfo,name_filter"), S, n)
            },
            status: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Node.Delete.api, "status", {}, e, t)
            }
        }), e("Profile", {
            list: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Profile.api, "list", {}, e, t)
            },
            set: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Profile.api, "set", {
                    profiles: e
                }, t, S)
            },
            delete: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Profile.api, "delete", {
                    id: e
                }, t, S)
            }
        }), e("Share", {
            listActive: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Share.api, "list_active", Ext.copyTo({}, e, "exclude_home"), t, S)
            },
            list: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Share.api, "list", Ext.copyTo({}, e, "offset,limit,sort_by,sort_direction"), t, S)
            },
            set: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Share.api, "set", {
                    share: e
                }, t, S)
            },
            get_hybrid_share_rotate_span: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Share.api, "get_hybrid_share_rotate_span", {
                    share: e
                }, t, S)
            }
        }), e("Log", {
            list: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Log.api, "list", Ext.copyTo({}, e, "offset,limit,target,share_type,log_type,get_all,keyword,date_from,date_to"), t, S)
            },
            delete: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Log.api, "delete", {}, e, t)
            },
            export: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Log.api, "export", Ext.copyTo({}, e, "target,type"), t, S)
            }
        }), e("Config", {
            get: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Config.api, "get", {}, e, t)
            },
            set: function(e, t, S, n, o, a, r) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Config.api, "set", {
                    db_volume: e,
                    use_del_by_cnt: t,
                    del_cnt: S,
                    use_del_by_span: n,
                    del_span: o
                }, a, r)
            }
        }), e("Connection", {
            list: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Connection.api, "list", Ext.copyTo({}, e, "offset,limit,sort_by,sort_direction"), t, S)
            },
            delete: function(e, t, S, n) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Connection.api, "delete", {
                    client_sess_id: e,
                    data_wipe: t
                }, S, n)
            },
            summary: function(e, t) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.Connection.api, "summary", {}, e, t)
            }
        }), e("KeyManagement", {
            list: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.KeyManagement.api, "list", Ext.copyTo({}, e, "offset,limit,sort_by,sort_direction,username"), t, S)
            },
            set: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.KeyManagement.api, "set", Ext.copyTo({}, e, "id,username,key"), t, S)
            },
            delete: function(e, t, S) {
                SYNO.SDS.CSTN.WebAPI.request.call(this, SYNO.SDS.CSTN.WebAPI.KeyManagement.api, "delete", {
                    ids: e
                }, t, S)
            }
        })
    }();
