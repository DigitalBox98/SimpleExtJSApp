/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.CSTN.VERSION"), 
 SYNO.SDS.Strings["SYNO.SDS.CSTN.VERSION.MainWindow"] = SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"], 
 /**
 * @class SYNO.SDS.CSTN.VERSION.Instance
 * @extends SYNO.SDS.AppInstance
 * SynologyDrive version application instance class
 *
 */
 Ext.define("SYNO.SDS.CSTN.VERSION.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.CSTN.VERSION.MainWindow",
    constructor: function() {
        this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.CSTN.VERSION.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(n) {
        this.owner = n.owner, this.mainPanel = null, this.appInstance = n.appInstance, this.panel = new SYNO.SDS.CSTN.VERSION.PanelVersion({
            owner: this,
            win: this
        }), this.callParent([Ext.apply({
            resizable: !1,
            maximizable: !1,
            minimizable: !0,
            width: 700,
            height: 450,
            useStatusBar: !0,
            layout: "fit",
            cls: "syno-cstn",
            showHelp: !1,
            items: [this.panel]
        }, n)])
    },
    onOpen: function(n) {
        this.callParent([n]), this.onActivatePanel(n)
    },
    onRequest: function(n) {
        this.callParent([n]), this.onActivatePanel(n)
    },
    onActivatePanel: function(n) {
        var i = {
            filename: n.file_info.filename,
            path: n.file_info.path,
            target: n.file_info.target,
            file_type: 0,
            is_office: n.file_info.is_office,
            popup_win: n.file_info.popup_win
        };
        this.panel.onActivate(i)
    },
    onClose: function() {
        return !1 !== this.callParent(arguments)
    }
});
