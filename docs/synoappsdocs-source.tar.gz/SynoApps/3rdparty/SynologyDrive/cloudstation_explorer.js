/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.CSTN.Explore.ToolbarController
 * SynologyDrive toolbar controller 
 *
 */
Ext.define("SYNO.SDS.CSTN.Explore.ToolbarController", {
    statics: {
        kSTATE_INIT: "init",
        kSTATE_SHARED_FOLDER: "shared_folder",
        kSTATE_ENABLE_DELETE_VERS: "enable_delete_vers",
        kSTATE_ENABLE_VIEW: "enable_view",
        kSTATE_DEFAULT: "default",
        adjustToolbar: function(e, t, i) {
            for (var n = t.getComponent("btn_action").menu, o = 0; o < e.length; o++) {
                switch (e[o]) {
                    case this.kSTATE_INIT:
                        t.getComponent("btn_show_version").disable(), t.getComponent("btn_restore").disable(), t.getComponent("btn_download").disable(), t.getComponent("btn_action").enable(), i.getComponent("menu_copy").disable(), i.getComponent("menu_restore").disable(), i.getComponent("menu_download").disable(), i.getComponent("menu_show_version").disable(), n.getComponent("btn_delete_forever").disable(), n.getComponent("btn_copy").disable();
                        break;
                    case this.kSTATE_SHARED_FOLDER:
                        t.getComponent("btn_action").enable();
                        break;
                    case this.kSTATE_ENABLE_VIEW:
                        t.getComponent("btn_action").enable(), t.getComponent("btn_show_version").enable(), i.getComponent("menu_show_version").enable();
                        break;
                    case this.kSTATE_ENABLE_RESTORE_RELATED:
                        t.getComponent("btn_restore").enable(), t.getComponent("btn_download").enable(), i.getComponent("menu_copy").enable(), i.getComponent("menu_restore").enable(), i.getComponent("menu_download").enable(), n.getComponent("btn_copy").enable();
                        break;
                    case this.kSTATE_ENABLE_DELETE_VERS:
                        n.getComponent("btn_delete_forever").enable();
                        break;
                    case this.kSTATE_DEFAULT:
                    default:
                        t.getComponent("btn_show_version").enable(), t.getComponent("btn_restore").enable(), t.getComponent("btn_download").enable(), t.getComponent("btn_action").enable(), i.getComponent("menu_copy").enable(), i.getComponent("menu_restore").enable(), i.getComponent("menu_download").enable(), i.getComponent("menu_show_version").enable(), n.getComponent("btn_delete_forever").disable(), n.getComponent("btn_copy").enable()
                }
            }
        }
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.HistoryManager", {
    constructor: function() {
        this.history = [], this.historyPoint = -1, this.historyMaxLength = 30
    },
    storePath: function(e) {
        this.history[this.historyPoint] != e && (this.history.splice(this.historyPoint + 1, this.history.length - (this.historyPoint + 1), e), this.history.length > this.historyMaxLength && this.history.shift(), this.historyPoint = this.history.length - 1)
    },
    clearHistory: function() {
        this.history = [], this.historyPoint = -1
    },
    moveToPrevPath: function() {
        return this.historyPoint > 0 ? (this.historyPoint--, this.history[this.historyPoint]) : null
    },
    moveToNextPath: function() {
        return this.historyPoint + 1 < this.history.length ? (this.historyPoint++, this.history[this.historyPoint]) : null
    },
    getPrevPath: function() {
        return this.historyPoint > 0 ? this.history[this.historyPoint - 1] : null
    },
    getNextPath: function() {
        return this.historyPoint + 1 < this.history.length ? this.history[this.historyPoint + 1] : null
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.PathBar", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: "syno-cstn-explorer-pathbar",
            path: "",
            pathSeparator: "/",
            rootVisible: !0
        };
        return Ext.apply(t, e)
    },
    initComponent: function() {
        this.callParent(arguments), this.addEvents("itemclick"), this.mon(this, "afterlayout", this.onAfterLayout, this)
    },
    onAfterLayout: function() {},
    setPath: function(e) {
        if (this.path == e) return !1;
        this.removeAll();
        var t = "";
        Ext.each(e.split(this.pathSeparator).slice(1), function(e, i, n) {
            t += this.pathSeparator + e, this.add(new SYNO.SDS.CSTN.Explore.PathItem({
                path: t,
                text: e,
                tooltip: e,
                first: this.rootVisible ? 0 === i : 1 === i,
                hidden: 0 === i && !this.rootVisible,
                listeners: {
                    click: function(e) {
                        this.fireEvent("itemclick", this, e.path)
                    },
                    scope: this
                }
            }))
        }, this), this.path = e, this.doLayout()
    },
    getPath: function() {
        return this.path
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.PathItem", {
    extend: "SYNO.ux.Button",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: e.first ? "syno-cstn-explorer-pathbutton-first" : "syno-cstn-explorer-pathbutton",
            iconCls: "syno-cstn-explorer-pathbutton-text",
            path: "",
            first: !1
        };
        return Ext.apply(t, e)
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.PathMenuItem", {
    extend: "SYNO.ux.Button",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: "cs-pathbuttons-selection-btn",
            menu: new Ext.menu.Menu
        };
        return Ext.apply(t, e)
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.Filter.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    dateType: {
        custom: 1,
        today: 2,
        yesterday: 4,
        lastweek: 8,
        lastmonth: 16
    },
    defaultAnimation: ["#000", 1, {
        duration: .35
    }],
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
                width: 368,
                heigh: 480,
                cls: "syno-cstn-search-panel",
                bodyStyle: (SYNO.SDS.CSTN.IsDSM7OrAbove(), "padding: 4px 24px 16px 24px;"),
                autoFlexcroll: !1,
                shadow: !1,
                hideLabels: !0,
                defaults: {
                    anchor: "100%"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("log", "attr_keyword") + _T("common", "colon")
                }, {
                    xtype: "syno_textfield",
                    name: "keyword"
                }, {
                    xtype: "syno_displayfield",
                    value: _STR("log", "log_type") + _T("common", "colon")
                }, {
                    xtype: "syno_combobox",
                    mode: "local",
                    editable: !1,
                    name: "fileType",
                    tpl: this.createComboBoxTplWithQTips(),
                    store: new Ext.data.ArrayStore({
                        fields: ["value", "displayText"],
                        data: [
                            ["any", _STR("search", "search_any")],
                            ["folder", _STR("search", "any_folder")],
                            ["file", _STR("search", "any_file")]
                        ]
                    }),
                    displayField: "displayText",
                    valueField: "value",
                    value: "any"
                }, {
                    xtype: "syno_displayfield",
                    value: _T("common", "size") + " (" + _T("common", "size_mb") + ")" + _T("common", "colon")
                }, {
                    xtype: "syno_compositefield",
                    defaultMargins: "0 8 0 0",
                    items: [{
                        xtype: "syno_combobox",
                        mode: "local",
                        editable: !1,
                        name: "fileSizeOption",
                        tpl: this.createComboBoxTplWithQTips(),
                        flex: 1,
                        store: new Ext.data.ArrayStore({
                            fields: ["value", "displayText"],
                            data: [
                                ["any", _STR("search", "search_any")],
                                ["equal", _STR("search", "size_equal")],
                                ["greater", _STR("search", "size_greater")],
                                ["less", _STR("search", "size_less")]
                            ]
                        }),
                        displayField: "displayText",
                        valueField: "value",
                        value: "any",
                        listeners: {
                            select: this.onSelectFileSizeOption,
                            scope: this
                        }
                    }, {
                        xtype: "syno_numberfield",
                        name: "fileSize",
                        flex: 1,
                        minValue: 0,
                        maxValue: 4294967296,
                        allowNegative: !1,
                        allowDecimals: !1,
                        autoStripChars: !0,
                        disabled: !0
                    }]
                }, {
                    xtype: "syno_displayfield",
                    value: _STR("showdel", "attr_modify_time") + _T("common", "colon")
                }, {
                    xtype: "syno_combobox",
                    mode: "local",
                    editable: !1,
                    name: "dateRange",
                    tpl: this.createComboBoxTplWithQTips(),
                    store: new Ext.data.ArrayStore({
                        fields: ["value", "displayText"],
                        data: [
                            [this.dateType.custom, _STR("log", "date_custom")],
                            [this.dateType.today, _STR("log", "date_today")],
                            [this.dateType.yesterday, _STR("log", "date_yesterday")],
                            [this.dateType.lastweek, _STR("log", "date_lastweek")],
                            [this.dateType.lastmonth, _STR("log", "date_lastmonth")]
                        ]
                    }),
                    displayField: "displayText",
                    valueField: "value",
                    value: this.dateType.custom,
                    listeners: {
                        select: this.onSelectDateOption,
                        scope: this
                    }
                }, {
                    xtype: "syno_compositefield",
                    defaultMargins: "0 8 0 0",
                    items: [{
                        xtype: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "syno_datetimefield" : "syno_datefield",
                        name: "searchdatefrom",
                        editable: !1,
                        flex: 1,
                        format: SYNO.SDS.CSTN.getDateFormat(),
                        emptyText: _T("log", "date_from"),
                        hideClearButton: !0,
                        listeners: {
                            select: function(e, t) {
                                this.form.findField("searchdateto").setMinValue(t)
                            },
                            scope: this
                        }
                    }, {
                        xtype: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "syno_datetimefield" : "syno_datefield",
                        name: "searchdateto",
                        editable: !1,
                        flex: 1,
                        format: SYNO.SDS.CSTN.getDateFormat(),
                        emptyText: _T("log", "date_to"),
                        hideClearButton: !0,
                        listeners: {
                            select: function(e, t) {
                                this.form.findField("searchdatefrom").setMaxValue(t)
                            },
                            scope: this
                        }
                    }]
                }, {
                    xtype: "syno_toolbar",
                    itemId: "btns",
                    toolbarCls: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "search-panel-fbar-btnPanel" : "",
                    style: (SYNO.SDS.CSTN.IsDSM7OrAbove(), "margin-top: 20px;"),
                    items: ["->"]
                }],
                keys: [{
                    key: [10, 13],
                    fn: this.onClickSearch,
                    scope: this
                }]
            },
            i = [{
                xtype: "syno_button",
                btnStyle: "blue",
                style: "margin-right: 10px",
                text: _T("log", "search"),
                itemId: "btn_search",
                handler: this.onClickSearch,
                scope: this
            }, {
                xtype: "syno_button",
                minWidth: 80,
                text: _T("common", "reset"),
                handler: this.onClickReset,
                scope: this
            }];
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && i.reverse(), t.items.push.apply(t.items[t.items.length - 1].items, i), Ext.apply(t, e)
    },
    initComponent: function() {
        this.callParent(arguments), this.addEvents("search")
    },
    createComboBoxTplWithQTips: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText:htmlEncode}">', "{displayText:htmlEncode}", "</div>", "</tpl>")
    },
    onSelectDateOption: function(e, t, i) {
        var n = this.getDateRangeFromOption(t.get("value"));
        this.setDateRange(n.from, n.to)
    },
    getDateRangeFromOption: function(e) {
        var t, i, n = new Date,
            o = n.getDay();
        switch (e) {
            case this.dateType.today:
                t = n, i = n;
                break;
            case this.dateType.yesterday:
                t = n.add(Date.DAY, -1), i = t;
                break;
            case this.dateType.lastweek:
                t = n.add(Date.DAY, -7 - o), i = t.add(Date.DAY, 6);
                break;
            case this.dateType.lastmonth:
                t = n.getFirstDateOfMonth(), i = n.getLastDateOfMonth();
                break;
            default:
                t = n, i = n
        }
        return {
            from: t,
            to: i
        }
    },
    setDateRange: function(e, t) {
        this.playFrameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation), this.playFrameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation), this.form.findField("searchdatefrom").setMaxValue(t), this.form.findField("searchdatefrom").setValue(e), this.form.findField("searchdateto").setMinValue(e), this.form.findField("searchdateto").setValue(t)
    },
    playFrameAnimation: function(e, t) {
        e && e.isVisible() && Ext.Element.prototype.frame.apply(e, t)
    },
    onSelectFileSizeOption: function(e, t, i) {
        var n = this.form.findField("fileSize");
        "any" !== t.get("value") ? (this.playFrameAnimation(n.el, this.defaultAnimation), n.enable()) : n.disable()
    },
    onClickSearch: function(e, t) {
        this.search()
    },
    onClickReset: function() {
        this.reset()
    },
    search: function() {
        this.getForm().isValid() && this.fireEvent("search", this, this.getSearchCriteria())
    },
    reset: function() {
        this.form.items.each(function(e) {
            e.isDirty() && this.playFrameAnimation(e.el, this.defaultAnimation)
        }, this), this.form.reset(), this.form.findField("fileSize").disable(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null), this.fireEvent("reset", this, this.getSearchCriteria())
    },
    setKeyword: function(e) {
        var t = this.form.findField("keyword");
        t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
    },
    getSearchCriteria: function() {
        var e = this.getForm(),
            t = e.findField("keyword").getValue(),
            i = e.findField("fileType").getValue(),
            n = e.findField("fileSizeOption").getValue(),
            o = 1024 * parseInt(e.findField("fileSize").getValue(), 10) * 1024,
            s = o + 1048576,
            a = e.findField("searchdatefrom"),
            r = e.findField("searchdateto"),
            l = 60 * (new Date).getTimezoneOffset();
        return {
            pattern: t,
            list_file_type: i,
            ver_file_size_upper_bound: "less" === n ? o : "equal" === n ? s : 0,
            ver_file_size_lower_bound: "greater" === n ? o : "equal" === n ? o : 0,
            ver_mtime_lower_bound: a.getRawValue() ? Date.parseDate(a.getRawValue() + " 00:00:00", a.format + " H:i:s").getTime() / 1e3 - l : 0,
            ver_mtime_upper_bound: r.getRawValue() ? Date.parseDate(r.getRawValue() + " 23:59:59", r.format + " H:i:s").getTime() / 1e3 - l : 0
        }
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initComponent: function() {
        this.callParent(arguments), this.searchPanel = new SYNO.SDS.CSTN.Explore.Filter.FormPanel({
            floating: !0,
            renderTo: Ext.getBody(),
            hidden: !0,
            listeners: {
                beforeshow: function(e) {
                    return e.getEl().alignTo(this.wrap, "tr-br?", SYNO.SDS.CSTN.IsDSM7OrAbove() ? [0, 1] : [6, 0]), !0
                },
                scope: this
            }
        }), this.addEvents("search")
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(this, "keypress", this.onKeyPress, this), this.mon(this.searchPanel, "search", this.onSearch, this), this.mon(this.searchPanel, "reset", this.onReset, this)
    },
    onMouseDown: function(e) {
        !this.searchPanel || !this.searchPanel.isVisible() || e.within(this.searchPanel.getEl()) || e.within(this.searchtrigger) || this.isInnerComponent(e, this.searchPanel.form) || this.searchPanel.hide()
    },
    isInnerComponent: function(e, t) {
        var i = !1;
        return t.items.each(function(t) {
            if (t instanceof Ext.form.ComboBox) {
                if (t.view && e.within(t.view.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.DateField) {
                if (t instanceof SYNO.ux.DateTimeField) {
                    if (t.isWithinEl(e)) return i = !0, !1
                } else if (t.menu && e.within(t.menu.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.CompositeField && this.isInnerComponent(e, t)) return i = !0, !1
        }, this), i
    },
    onKeyPress: function(e) {
        e.getKey() === Ext.EventObject.ENTER && (this.searchPanel.setKeyword(this.getValue()), this.searchPanel.search())
    },
    onSearch: function(e, t) {
        this.searchPanel.hide(), this.setValue(t.pattern), this.fireEvent("search", t)
    },
    onReset: function(e, t) {
        this.setValue(t.pattern), this.fireEvent("reset", t)
    },
    onSearchTriggerClick: function() {
        this.callParent(arguments), this.searchPanel.isVisible() ? this.searchPanel.hide() : (this.searchPanel.setKeyword(this.getValue()), this.searchPanel.show())
    },
    onTriggerClick: function() {
        this.callParent(arguments), this.searchPanel.reset()
    },
    getSearchCriteria: function() {
        return this.searchPanel.getSearchCriteria()
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.PathSelector", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        return this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            title: _STR("btn", "copy_to") + " ... - " + _STR("msg", "select_path"),
            bodyStyle: "padding-right: 20px; padding-left: 20px;",
            width: 480,
            height: 500,
            layout: "fit",
            minWidth: 480,
            minHeight: 500,
            items: [{
                xtype: "syno_treepanel",
                itemId: "tree_panel",
                loader: this.createTreeLoader(),
                border: !1,
                rootVisible: !1,
                root: new Ext.tree.AsyncTreeNode({
                    name: "fm_top_root",
                    id: "fm_top_root",
                    text: _S("hostname"),
                    cls: "root_node",
                    expanded: !0,
                    disabled: !0,
                    children: [{
                        name: "fm_fav_root",
                        id: "fm_fav_root",
                        text: _STR("common", "fav_title"),
                        cls: "root_node",
                        expanded: !0,
                        disabled: !0
                    }, {
                        name: "fm_root",
                        id: "fm_root",
                        path: "/",
                        text: _S("hostname"),
                        cls: "root_node",
                        expanded: !0,
                        disabled: !0,
                        listeners: {
                            expand: {
                                fn: function(e) {
                                    var t = e.childNodes;
                                    t && t.length > 0 && Ext.each(t, function(e) {
                                        return this.getComponent("tree_panel").getSelectionModel().select(e), !1
                                    }, this)
                                },
                                scope: this,
                                single: !0
                            }
                        }
                    }]
                }),
                autoFlexcroll: !0,
                cls: "syno-cstn-explorer-pathselector-treepanel",
                style: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding-top: 8px;" : "",
                bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 8px;" : "padding-left:0px; padding-right: 12px;",
                useArrows: !0,
                bbarCfg: {
                    cls: "syno-cstn-explorer-pathselector-bbar"
                },
                bbar: [new Ext.form.Label({
                    height: 32,
                    text: _STR("msg", "same_file_description") + ":"
                }), new SYNO.ux.DisplayField({
                    style: "width: 13px",
                    fieldLabel: "",
                    value: "&nbsp;",
                    htmlEncode: !1
                }), new SYNO.ux.Radio({
                    itemId: "skip",
                    boxLabel: _STR("btn", "btn_skip"),
                    name: "writestrategy",
                    inputValue: "skip",
                    checked: !0
                }), new SYNO.ux.DisplayField({
                    style: "width: 13px",
                    fieldLabel: "",
                    value: "&nbsp;",
                    htmlEncode: !1
                }), new SYNO.ux.Radio({
                    itemId: "override",
                    boxLabel: _STR("btn", "btn_overwrite"),
                    name: "writestrategy",
                    inputValue: "override"
                })]
            }],
            buttons: [{
                text: _T("common", "apply"),
                btnStyle: "blue",
                handler: this.onClickApply,
                scope: this
            }, {
                text: _T("common", "cancel"),
                handler: this.onClickCancel,
                scope: this
            }]
        };
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && t.buttons.reverse(), Ext.apply(t, e)
    },
    initEvents: function() {
        this.callParent(arguments);
        var e = this.getComponent("tree_panel");
        this.mon(e.getLoader(), "load", function(t, i) {
            i.firstChild && e.getSelectionModel().select(i.firstChild)
        }, this, {
            single: !0
        }), this.addEvents("apply")
    },
    onClickApply: function() {
        var e = this.getComponent("tree_panel"),
            t = e.getSelectionModel().getSelectedNode();
        if (!t) return void this.getMsgBox().alert(_STR("app", "app_name"), _STR("warning", "not_choose"), this);
        var i = t.attributes.abspath,
            n = e.getBottomToolbar().getComponent("override").checked;
        this.fireEvent("apply", this, {
            dest_path: i,
            override: n
        }), this.close()
    },
    onClickCancel: function() {
        this.close()
    },
    createTreeLoader: function() {
        var e = _S("majorversion"),
            t = ["real_path", "mount_point_type", "perm", "owner"];
        return new SYNO.API.TreeLoader({
            api: "SYNO.FileStation.List",
            method: "list_share",
            version: e >= 6 ? 2 : 1,
            dataroot: ["data", "shares"],
            requestMethod: "POST",
            baseParams: {
                superuser: !1,
                onlywritable: !0,
                status_filter: "valid",
                filetype: "dir",
                folder_path: "",
                additional: e >= 6 ? t : t.join(",")
            },
            appWindow: this,
            processResponse: function(e, t, i, n) {
                var o, s = e.responseText;
                try {
                    var a = e.responseData || Ext.decode(s);
                    o = "fm_fav_root" === t.id ? ["data", "favorites"] : "fm_root" === t.id ? ["data", "shares"] : ["data", "files"], Ext.isArray(o) || (o = o.split(","));
                    for (var r in o) o.hasOwnProperty(r) && (a = a[o[r]]);
                    t.beginUpdate();
                    for (var l = 0, h = a.length; l < h; l++) {
                        var d = this.createNode(a[l], t);
                        d && t.appendChild(d)
                    }
                    t.endUpdate(), this.runCallback(i, n || t, [t])
                } catch (t) {
                    this.handleFailure(e)
                }
            },
            createNode: function(e, t) {
                var i;
                if (t && ("fm_fav_root" === t.id ? i = "remotefav" : "fm_root" === t.id && (i = "remote")), "fm_fav_root" !== e.id && "fm_root" !== e.id)
                    if (e.spath) {
                        if ("RW" != e.right) return null;
                        e.id = i + e.spath, e.abspath = e.path, e.path = e.spath, e.text = e.text
                    } else e.id = i + e.path, e.abspath = e.additional.real_path || e.path, e.path = e.path, e.text = e.name;
                return SYNO.API.TreeLoader.prototype.createNode.call(this, e)
            },
            listeners: {
                beforeload: function(e, t, i) {
                    "fm_fav_root" === t.id ? (e.api = "SYNO.FileStation.Favorite", e.method = "list", e.dataroot = ["data", "favorites"], e.baseParams.enum_cluster = !0) : "fm_root" === t.id ? (e.api = "SYNO.FileStation.List", e.method = "list_share", e.dataroot = ["data", "shares"]) : (e.api = "SYNO.FileStation.List", e.method = "list", e.dataroot = ["data", "files"], e.baseParams.folder_path = t.attributes.path)
                },
                loadexception: function(e, t, i) {
                    i && i.code && SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [i])
                },
                scope: this
            }
        })
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.TimePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        SYNO.SDS.CSTN.IsDSM7OrAbove() ? this.dateField = new SYNO.SDS.CSTN.Explore.DateTimeField({
            itemId: "date_field",
            margins: "4 6 0 0"
        }) : this.dateField = new SYNO.SDS.CSTN.Explore.DateField({
            itemId: "date_field",
            margins: "4 8 0 0"
        });
        var t = {
            cls: "syno-cstn-explorer-time-panel",
            height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 44 : 42,
            width: 600,
            layout: "hbox",
            rootVisible: !0,
            bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 4px 0px 0px 0px;" : "",
            items: [{
                xtype: "syno_displayfield",
                value: _STR("time", "time_time") + _T("common", "colon"),
                margins: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "4 6 0 0" : "4 8 0 3"
            }, this.dateField, this.timeField = new SYNO.SDS.CSTN.Explore.TimeField({
                itemId: "time_field",
                margins: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "4 6 0 0" : "4 8 0 0"
            }), {
                xtype: "syno_button",
                itemId: "time_panel_go_btn",
                margins: "4 0 0 0",
                tooltip: _STR("welcome", "welcome_go"),
                text: _STR("welcome", "welcome_go"),
                cls: "syno-ux-button-blue syno-cstn-explore-btn-go",
                listeners: {
                    click: this.onGoBtnClick,
                    scope: this
                }
            }]
        };
        return Ext.apply(t, e)
    },
    initComponent: function() {
        this.callParent(arguments)
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this.dateField, "select", this.onSelectDate, this)
    },
    onGoBtnClick: function() {
        !0 === this.timeField.checkTimeValidAndParse() && this.fireEvent("timeselected", this)
    },
    onSelectDate: function(e, t) {
        var i = new Date,
            n = i.getTime() / 1e3;
        t.getTime() / 1e3 + this.timeField.getTimeSeconds() > n && this.timeField.setValue(i.format("H:i"))
    },
    getUTCTimeSeconds: function() {
        return this.dateField.getValue().getTime() / 1e3 + this.timeField.getTimeSeconds()
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.DateField", {
    extend: "SYNO.ux.DateField",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: "syno-cstn-explorer-date-field",
            editable: !1,
            format: SYNO.SDS.CSTN.getDateFormat(),
            maxValue: new Date,
            minValue: Date.parseDate("1/1/2000", "n/j/Y"),
            value: new Date,
            margins: "1 6 1 6",
            width: 160
        };
        return Ext.apply(t, e)
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.DateTimeField", {
    extend: "SYNO.ux.DateTimeField",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = {
            cls: "syno-cstn-explorer-date-field",
            editable: !1,
            format: SYNO.SDS.CSTN.getDateFormat(),
            maxValue: new Date,
            minValue: Date.parseDate("1/1/2000", "n/j/Y"),
            value: new Date,
            margins: "1 6 1 6",
            hideClearButton: !0,
            width: 160
        };
        return Ext.apply(t, e)
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.TimeField", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(e) {
        this.callParent([this.fillConfig(e || {})])
    },
    fillConfig: function(e) {
        var t = (new Date).format("H:i"),
            i = [
                ["00:00"],
                ["01:00"],
                ["02:00"],
                ["03:00"],
                ["04:00"],
                ["05:00"],
                ["06:00"],
                ["07:00"],
                ["08:00"],
                ["09:00"],
                ["10:00"],
                ["11:00"],
                ["12:00"],
                ["13:00"],
                ["14:00"],
                ["15:00"],
                ["16:00"],
                ["17:00"],
                ["18:00"],
                ["19:00"],
                ["20:00"],
                ["21:00"],
                ["22:00"],
                ["23:00"]
            ];
        i.push([t]), i.sort(function(e, t) {
            return e[0].localeCompare(t[0])
        }), i.unshift([_STR("time", "time_now")]);
        var n = {
            cls: "syno-cstn-explorer-time-field",
            format: "H:i",
            editable: !0,
            margins: "1 6 1 6",
            value: t,
            width: 160,
            displayField: "value",
            valueField: "value",
            autoSelect: !0,
            maxlength: 5,
            validator: this.checkTimeValidAndParse,
            store: new Ext.data.SimpleStore({
                idIndex: 0,
                autoDestroy: !0,
                fields: ["value"],
                data: i
            }),
            tpl: '<tpl for="."><div class="x-combo-list-item">{value}</div><tpl if="xindex == 1"><hr class="syno-cstn-explorer-time-field-hr"/></tpl></tpl>',
            listeners: {
                select: this.onSelectHour,
                keyup: this.checkTimeValidAndParse,
                blur: this.onBlur,
                scope: this
            }
        };
        return Ext.apply(n, e)
    },
    initComponent: function() {
        this.time = {
            hour: 0,
            min: 0
        }
    },
    onSelectHour: function(e, t, i) {
        t.get("value") === _STR("time", "time_now") && this.setValue((new Date).format("H:i")), this.checkTimeValidAndParse()
    },
    getTime: function() {
        return this.time
    },
    getTimeSeconds: function() {
        return 60 * (60 * parseInt(this.time.hour) + parseInt(this.time.min))
    },
    setTime: function(e, t) {
        this.time.hour = e, this.time.min = t
    },
    onBlur: function() {
        if (this.checkTimeValidAndParse()) {
            var e = this.toTimeStr(this.time.hour) + ":" + this.toTimeStr(this.time.min);
            e !== this.getEl("item").getValue() && this.setValue(e)
        }
    },
    checkTimeValidAndParse: function() {
        var e = this.getEl("item").getValue(),
            t = e.match(/^(\d{1,2}):(\d{1,2})$/);
        return !!t && (t[1] > 23 ? (this.resetHour(), !1) : t[2] > 59 ? (this.resetTime(), !1) : (this.time.hour = t[1], this.time.min = t[2], !0))
    },
    resetTime: function() {
        this.resetHour(), this.resetMinute()
    },
    resetHour: function() {
        this.time.hour = 0, this.setValue("00:" + this.toTimeStr(this.time.min))
    },
    resetMinute: function() {
        this.time.min = 0, this.setValue(this.toTimeStr(this.time.hour) + ":00")
    },
    toTimeStr: function(e) {
        return ("0" + e).slice(-2)
    }
}), Ext.define("SYNO.SDS.CSTN.EncryptedFileDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.jsConfig = e.owner.jsConfig;
        var t = {
            title: _STR("app", "app_name"),
            width: 600,
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: this.fillItems(e),
            buttons: [{
                text: _T("common", "apply"),
                btnStyle: "blue",
                itemId: "apply_btn",
                handler: this.onClickApply,
                scope: this
            }, {
                text: _T("common", "cancel"),
                handler: this.onClickCancel,
                scope: this
            }]
        };
        SYNO.SDS.CSTN.IsDSM7OrAbove() && t.buttons.reverse(), this.callParent([Ext.apply(t, e)])
    },
    onViewReady: function() {
        this.getComponent("grid").getView().refresh(), this.addPasswordListener(), this.addActionListener()
    },
    onPasswordInputKeyup: function(e, t) {
        var i = t.getAttribute("data-syno-file-id"),
            n = this.getStore().getById(i);
        n.data.passed = !0, n.data.decrypt = t.value, this.validatePassword(t, n)
    },
    onActionClick: function(e, t) {
        var i = t.getAttribute("data-syno-file-id"),
            n = this.getStore().getById(i);
        this.getStore().remove(n)
    },
    addPasswordListener: function() {
        var e = this.getComponent("grid").getEl().dom.querySelectorAll("input[data-syno-file-id]");
        Ext.each(e, function(e) {
            Ext.get(e).on("keyup", this.onPasswordInputKeyup, this)
        }, this)
    },
    addActionListener: function() {
        var e = this.getComponent("grid").getEl().dom.querySelectorAll("span.action");
        Ext.each(e, function(e) {
            Ext.get(e).on("click", this.onActionClick, this)
        }, this)
    },
    initEvents: function() {
        this.callParent(arguments), this.addEvents("apply")
    },
    fillItems: function(e) {
        var t = new Ext.grid.ColumnModel({
            columns: [{
                header: _STR("common", "file_name"),
                dataIndex: "name",
                resizable: !1,
                renderer: this.nameRenderer,
                scope: this,
                width: 300
            }, {
                header: _T("common", "password"),
                renderer: this.passwordRenderer,
                width: 198,
                resizable: !1
            }, {
                header: _STR("common", "action"),
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                renderer: this.actionRenderer
            }]
        });
        return [{
            xtype: "syno_editorgrid",
            itemId: "grid",
            enableHdMenu: !1,
            cls: "syno-cstn-enc-dialog-grid",
            clicksToEdit: 1,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                handleMouseDown: Ext.emptyFn
            }),
            colModel: t,
            store: this.getStore(e.nodes_info),
            flex: 1,
            view: new SYNO.ux.FleXcroll.grid.GridView({
                autoFlexcroll: !0
            }),
            listeners: {
                viewready: this.onViewReady,
                scope: this
            }
        }]
    },
    getStore: function(e) {
        return !1 === Ext.isDefined(this.store) && (this.store = new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["name", "path", "permanent_id", "permanent_link", "sync_id", "node_id", "extension", "passed", "decrypt"],
            data: e,
            idProperty: "node_id"
        })), this.store
    },
    parseDisplayPath: function(e) {
        return !0 === e.get("is_share") ? String.format("/{0}{1}", _STR("category", "team_folder"), e.get("path")) : String.format("/{0}{1}", _STR("category", "node"), e.get("path"))
    },
    nameRenderer: function(e, t, i, n, o, s) {
        var a = i.get("extension"),
            r = this.jsConfig.jsBaseURL + "/images/files_ext/" + SYNO.SDS.CSTN.Icon.EXT_ICON_PREFIX + (SYNO.SDS.UIFeatures.test("isRetina") ? "2x/" : "1x/") + "syn" + a + ".png";
        return t.attr += String.format('ext:qtip="{0}"', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(this.parseDisplayPath(i)))), String.format('<span class="file-type-icon" style="background-image:url({0}); background-size: 16px 16px;"></span>{1}', r, Ext.util.Format.htmlEncode(i.get("name")))
    },
    passwordRenderer: function(e, t, i, n, o, s) {
        return String.format('<input data-syno-file-id="{0}" type="password" placeholder="{1}"></input>', i.get("node_id"), _T("common", "password"))
    },
    actionRenderer: function(e, t, i, n, o, s) {
        return String.format('<span class="action"><a data-syno-file-id="{0}">{1}</a></span>', i.get("node_id"), _T("common", "skip"))
    },
    onClickApply: function() {
        var e = this,
            t = this.countPassed();
        0 === t && this.ori_nodes_info.length === this.getStore().getCount() ? e.close() : this.confirmSkip(t).then(function() {
            e.fireEvent("apply", e.genDecInfoList()), e.close()
        }).catch(function() {})
    },
    onClickCancel: function() {
        this.close()
    },
    confirmSkip: function(e) {
        return new Promise(function(t, i) {
            if (this.getStore().getCount() === e) return void t();
            this.getMsgBox().confirm(_STR("app", "app_name"), _STR("confirm", "no_password"), function(e) {
                "yes" === e ? t() : i()
            })
        }.createDelegate(this))
    },
    countPassed: function() {
        var e = 0;
        return this.getStore().each(function(t) {
            !0 === t.get("passed") && e++
        }), e
    },
    genDecInfoList: function() {
        var e = [];
        return this.getStore().each(function(t) {
            t.data.decrypt && e.push(Ext.copyTo({}, t.data, "node_id,decrypt"))
        }, this), e
    },
    validatePassword: function(e, t) {
        var i = e.getAttribute("data-syno-file-id"),
            n = e.value;
        this.sendWebAPI({
            api: "SYNO.Office.Node.Encrypt",
            version: 1,
            method: "check",
            params: {
                path: "link:" + t.data.permanent_link,
                password: n
            },
            encryption: ["password"],
            callback: function(t) {
                if (!this.isDestoryed && this.getEl() && this.getEl().dom && e) {
                    var n = Ext.get(e).parent(),
                        o = this.getStore().getById(i);
                    !0 === t && Ext.isDefined(o) ? (n.removeClass("failed"), n.addClass("success"), e.itip = "") : (n.removeClass("success"), n.addClass("failed"), e.itip = _T("common", "err_pass"))
                }
            },
            scope: this
        })
    }
}), Ext.define("SYNO.SDS.CSTN.Explore.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.CSTN.Explore.AppWindow",
    constructor: function() {
        void 0 === SYNO.SDS.Strings["SYNO.SDS.CSTN.Explore.AppWindow"] && (SYNO.SDS.Strings["SYNO.SDS.CSTN.Explore.AppWindow"] = SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"]), this.callParent(arguments)
    }
}), Ext.ns("SYNO.SDS.AdminCenter"), SYNO.SDS.AdminCenter.USER_PAGING_SIZE || (SYNO.SDS.AdminCenter.USER_PAGING_SIZE = 100), Ext.define("SYNO.SDS.CSTN.Explore.AppWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(e) {
        this.gridStore = this.createGridStore(), this.gridMenu = this.createGridMenu(), this.historyManager = new SYNO.SDS.CSTN.Explore.HistoryManager, this.ldapHomeServiceEnabled = !1, this.domainHomeServiceEnabled = !1, this.callParent([this.fillConfig(e || {})]), this.setWidth(SYNO.SDS.CSTN.VERSION_WIN_WIDTH), this.sendWebAPI({
            api: "SYNO.Core.User.Home",
            method: "get",
            version: 1,
            params: {},
            scope: this,
            callback: function(e, t, i) {
                e && (this.domainHomeServiceEnabled = t.enable_domain, this.ldapHomeServiceEnabled = t.enable_ldap)
            }
        }), this.setViewRole(_S("user"))
    },
    fillConfig: function(e) {
        var t = {
            cls: "syno-cstn-explorer",
            title: _STR("func", "version_explorer"),
            layout: "fit",
            height: 580,
            minHeight: 400,
            width: SYNO.SDS.CSTN.VERSION_WIN_WIDTH,
            minWidth: SYNO.SDS.CSTN.VERSION_WIN_WIDTH,
            closable: !0,
            resizable: !0,
            useStatusBar: !1,
            showHelp: !1,
            tbar: new Ext.Container({
                layout: {
                    type: "vbox",
                    pack: "start",
                    align: "stretch"
                },
                height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 122 : 124,
                flex: 1,
                items: [{
                    xtype: "toolbar",
                    itemId: "time_bar",
                    cls: "syno-cstn-time-bar",
                    margins: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "0 16 6 16" : "0 12 8 12",
                    listeners: {
                        resize: function(e, t, i, n, o) {
                            var s = e.getComponent("view_role_link").el,
                                a = 0;
                            e.items.each(function(e, t, i) {
                                void 0 !== e.el && "view_role_link" !== e.getItemId() && (a += e.getWidth())
                            }, this), s.setStyle("max-width", Math.max(t - a - 80, 20) + "px")
                        }
                    },
                    items: [new SYNO.SDS.CSTN.Explore.TimePanel({
                        itemId: "time_panel"
                    }), {
                        xtype: "tbfill"
                    }, {
                        xtype: "syno_displayfield",
                        itemId: "view_role_left",
                        fieldClass: "syno-cstn-view-role-title",
                        value: _STR("cstn", "view_role") + _T("common", "colon"),
                        hidden: !1
                    }, {
                        xtype: "syno_displayfield",
                        itemId: "view_role_link",
                        fieldClass: "syno-cstn-view-role-display",
                        hidden: !0,
                        value: _S("user")
                    }, {
                        xtype: "syno_displayfield",
                        itemId: "view_role_right",
                        cls: "change_view_role_link",
                        hidden: !0,
                        hideLabel: !0,
                        htmlEncode: !1,
                        value: ' (<a id="' + Ext.id() + '" class="link-font" href="">' + _STR("cstn", "change_view_role") + "</a>)",
                        listeners: {
                            render: function(e) {
                                var t = e.el.first("a");
                                t && this.mon(t, "click", function(e) {
                                    e.preventDefault();
                                    var t = new SYNO.SDS.UserChooser({
                                        owner: this,
                                        module: this.module,
                                        domainForceIgnore: !this.domainHomeServiceEnabled,
                                        ldapForceIgnore: !this.ldapHomeServiceEnabled,
                                        height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 480 : 300,
                                        setStoreConfig: function() {
                                            return {
                                                api: "SYNO.SynologyDrive.Privilege",
                                                method: "list",
                                                version: "1",
                                                id: "name",
                                                root: "users",
                                                totalProperty: "total",
                                                listeners: {
                                                    load: function(e, t, i) {
                                                        for (var n = 0; n < t.length; ++n) {
                                                            var o = t[n].get("status");
                                                            "disabled" !== o && "home_disabled" !== o || e.remove(t[n])
                                                        }
                                                    }
                                                }
                                            }
                                        },
                                        setApiParams: function() {
                                            return {
                                                additional: ["status", "enabled"]
                                            }
                                        },
                                        setStoreField: function() {
                                            return ["name", "enable", "status"]
                                        },
                                        setColModel: function() {
                                            return [{
                                                id: "name",
                                                header: _T("user", "user_account"),
                                                dataIndex: "name",
                                                width: 150
                                            }]
                                        },
                                        setTextFilterConfig: function() {
                                            return {
                                                queryAction: "list",
                                                queryParam: "substr"
                                            }
                                        },
                                        setGridPanelConfig: function() {
                                            return {
                                                enableHdMenu: !1
                                            }
                                        },
                                        singleSelect: !0,
                                        localOnly: !1
                                    });
                                    this.mon(t, "beforeclose", this.onBeforeCloseUserChooser, this), this.suspendPanels(!0), t.chooseUsers()
                                }, this)
                            },
                            scope: this,
                            single: !0,
                            buffer: 80
                        }
                    }]
                }, {
                    xtype: "toolbar",
                    itemId: "navigation_bar",
                    cls: "syno-cstn-rb-ttbar",
                    layout: "hbox",
                    items: [{
                        xtype: "syno_button",
                        itemId: "btn_back",
                        tooltip: _T("common", "back"),
                        cls: "syno-cstn-rb-tbar-btn-back",
                        iconCls: "syno-cstn-rb-tbar-back",
                        disabled: !0,
                        listeners: {
                            click: this.onClickPathBack,
                            scope: this
                        }
                    }, {
                        xtype: "syno_button",
                        itemId: "btn_next",
                        tooltip: _T("common", "next"),
                        cls: "syno-cstn-rb-tbar-btn-next",
                        iconCls: "syno-cstn-rb-tbar-next",
                        disabled: !0,
                        margins: "0 6 0 0",
                        listeners: {
                            click: this.onClickPathNext,
                            scope: this
                        }
                    }, new SYNO.SDS.CSTN.Explore.PathBar({
                        itemId: "path_bar",
                        flex: 1,
                        rootVisible: !1
                    }), new SYNO.SDS.CSTN.Explore.AdvancedSearchField({
                        itemId: "adv_search",
                        width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 208 : 188,
                        margins: "0 0 0 6",
                        emptyText: _STR("cstn", "search_current_folder")
                    })]
                }, {
                    xtype: "toolbar",
                    itemId: "action_bar",
                    margins: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "6 0 0 0 " : "8 0 0 0",
                    items: [{
                        xtype: "syno_button",
                        itemId: "btn_show_version",
                        text: _STR("btn", "showver"),
                        disabled: !0,
                        listeners: {
                            click: this.onClickShowVersions,
                            scope: this
                        }
                    }, {
                        xtype: "syno_button",
                        itemId: "btn_restore",
                        text: _STR("btn", "restore"),
                        disabled: !0,
                        listeners: {
                            click: this.onClickRestore,
                            scope: this
                        }
                    }, {
                        xtype: "syno_button",
                        itemId: "btn_download",
                        text: _STR("showdel", "btn_dl"),
                        disabled: !0,
                        listeners: {
                            click: this.onClickDownload,
                            scope: this
                        }
                    }, {
                        xtype: "syno_button",
                        itemId: "btn_action",
                        text: _STR("category", "more"),
                        menu: new Ext.menu.Menu({
                            defaultOffsets: SYNO.SDS.CSTN.IsDSM7OrAbove() ? [0, 1] : [0, 0],
                            items: [{
                                itemId: "btn_copy",
                                text: _STR("btn", "copy_to") + "...",
                                disabled: !0,
                                listeners: {
                                    click: this.onClickCopyTo,
                                    scope: this
                                }
                            }, {
                                itemId: "btn_delete_forever",
                                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                                text: _STR("showdel", "btn_delforever"),
                                disabled: !0,
                                listeners: {
                                    click: this.onClickDeleteForever,
                                    scope: this
                                }
                            }]
                        })
                    }, {
                        xtype: "tbfill"
                    }, {
                        xtype: "syno_checkbox",
                        itemId: "btn_show_removed",
                        boxLabel: _STR("btn", "show_removed_files"),
                        listeners: {
                            check: this.onCheckShowRemovedFiles,
                            scope: this
                        }
                    }]
                }]
            }),
            items: [{
                xtype: "syno_panel",
                itemId: "content",
                cls: "syno-cstn-explorer-filebrowser-mainpanel",
                layout: "border",
                items: [{
                    xtype: "syno_treepanel",
                    bodyStyle: "padding-right: 12px;",
                    bwrapStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding-top: 0px" : "padding-top: 8px;",
                    itemId: "tree_panel",
                    loader: this.createTreeLoader(),
                    root: new Ext.tree.AsyncTreeNode({
                        id: "/",
                        name: "root",
                        absolute_path: "/",
                        cls: "root_node",
                        expanded: !0
                    }),
                    rootVisible: !1,
                    region: "west",
                    cls: "syno-cstn-explorer-filebrowser-treepanel",
                    useArrows: !0,
                    split: !0,
                    width: e.appInstance.getUserSettings("tree_panel_width") || SYNO.SDS.CSTN.IsDSM7OrAbove() ? 232 : 180,
                    minWidth: 150,
                    maxWidth: 500
                }, {
                    xtype: "syno_gridpanel",
                    itemId: "grid_panel",
                    region: "center",
                    cls: "syno-cstn-explorer-filebrowser-gridpanel",
                    colModel: this.createGridColumnModel(),
                    store: this.gridStore,
                    loadMask: !0,
                    bbar: {
                        xtype: "syno_paging",
                        store: this.gridStore,
                        pageSize: 1e3,
                        displayInfo: !0,
                        listeners: {
                            beforechange: function() {
                                this.onGridSelectionChange(this.gridPanel.selModel)
                            },
                            scope: this
                        }
                    }
                }]
            }]
        };
        return Ext.apply(t, e)
    },
    initComponent: function() {
        this.callParent(arguments), this.timePanel = this.getTopToolbar().getComponent("time_bar").getComponent("time_panel"), this.pathToolbar = this.getTopToolbar().getComponent("navigation_bar"), this.pathBar = this.pathToolbar.getComponent("path_bar"), this.searchBar = this.pathToolbar.getComponent("adv_search"), this.treePanel = this.getComponent("content").getComponent("tree_panel"), this.gridPanel = this.getComponent("content").getComponent("grid_panel"), this.gridPanel.doRefresh = Ext.createDelegate(function() {
            this.updatePath(this.pathBar.getPath(), {
                skipHistory: !0,
                refresh: !0
            })
        }, this)
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this.treePanel, "load", function(e) {
            this.path ? this.updatePath(this.path, {
                filename: this.filename,
                expandTreeNode: !0
            }) : e.firstChild && this.updatePath(e.firstChild.getPath("name"))
        }, this, {
            single: !0
        }), this.mon(this, "close", this.onCloseWindow, this), this.mon(this.pathBar, "itemclick", this.onClickPathItem, this), this.mon(this.searchBar, "search", this.onClickSearch, this), this.mon(this.searchBar, "reset", this.onClickSearchReset, this), this.mon(this.treePanel, "resize", this.onTreePanelResize, this), this.mon(this.treePanel.getSelectionModel(), "selectionchange", this.onTreeSelectionChange, this), this.mon(this.gridPanel, "rowcontextmenu", this.onRightClickGrid, this), this.mon(this.gridPanel, "rowdblclick", this.onDoubleClickGrid, this), this.mon(this.gridPanel.getSelectionModel(), "selectionchange", this.onGridSelectionChange, this), this.mon(this.timePanel, "timeselected", this.onTimeSelected, this)
    },
    onOpen: function(e) {
        return Ext.apply(this, e), this.callParent(arguments)
    },
    onRequest: function(e) {
        if (Ext.apply(this, e), e.path) {
            var t = {
                filename: e.filename
            };
            this.isUnderMyDrive(e.path) && (t.viewRole = _S("user")), this.updatePath(e.path, t)
        }
        return this.callParent(arguments)
    },
    onCloseWindow: function() {
        this.appInstance.setUserSettings("tree_panel_width", this.treePanel.getWidth())
    },
    onTreePanelResize: function() {
        this.appInstance.setUserSettings("tree_panel_width", this.treePanel.getWidth())
    },
    onBeforeCloseUserChooser: function(e) {
        var t, i = e.getRecords();
        if (this.resumePanels(!0), 0 === i.length) return !0;
        t = i[0].data.name, this.getViewRole(this.pathBar.getPath()) !== t && this.updatePath(this.getViewRootPath(this.pathBar.getPath()), {
            refresh: !0,
            viewRole: t
        })
    },
    createTreeLoader: function() {
        return new SYNO.API.TreeLoader({
            api: SYNO.SDS.CSTN.WebAPI.Node.api,
            method: "list",
            timeout: 3e5,
            version: 1,
            requestMethod: "POST",
            appWindow: this,
            clearOnLoad: !1,
            processResponse: function(e, t, i, n) {
                if (t.ui) {
                    var o = e.responseText;
                    try {
                        var s = e.responseData || Ext.decode(o);
                        if (s = s.data.items, t.beginUpdate(), "/" === t.attributes.absolute_path) {
                            for (var a = [], r = 0, l = s.length; r < l; r++)
                                if ("/Drive" === s[r].absolute_path) {
                                    var h = this.createNode(Ext.apply(s[r], {
                                        iconCls: "syno-cstn-explorer-filebrowser-treepanel-home-icon"
                                    }));
                                    h && (h.setText(_STR("category", "node")), h.setTooltip(_STR("category", "node")), t.appendChild(h))
                                } else a.push(s[r]);
                            t.appendChild(new Ext.tree.AsyncTreeNode({
                                id: "/Team Folder",
                                absolute_path: "/",
                                name: "Team Folder",
                                text: _STR("category", "team_folder"),
                                qtip: _STR("category", "team_folder"),
                                expanded: !0,
                                children: a
                            }))
                        } else
                            for (var r = 0, l = s.length; r < l; r++) {
                                var h = this.createNode(s[r]);
                                h && t.appendChild(h)
                            }
                        t.endUpdate(), this.runCallback(i, n || t, [t])
                    } catch (t) {
                        this.handleFailure(e)
                    }
                }
            },
            createNode: function(e) {
                return e.id = e.absolute_path, e.text = e.name, e.qtip = e.name, e.leaf = 1 != e.file_type, SYNO.API.TreeLoader.prototype.createNode.call(this, e)
            },
            listeners: {
                beforeload: function(e, t) {
                    e.baseParams = Ext.apply(e.baseParams, {
                        list_removed: this.show_removed_file,
                        ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds()
                    }), e.baseParams = Ext.apply(e.baseParams, {
                        node_id: parseInt(t.attributes.node_id, 10),
                        target: t.attributes.absolute_path.split("/")[1],
                        path: t.attributes.path,
                        list_dir_only: !0,
                        sort_by: "name",
                        sort_direction: "ASC",
                        view_role: this.getViewRole(this.pathBar.getPath())
                    })
                },
                loadexception: function(e, t, i) {
                    this.displayErrorMessage(Ext.decode(i.responseText || "{}").error)
                },
                scope: this
            }
        })
    },
    getViewRootPath: function(e) {
        return e.split("/", 3).join("/")
    },
    isUnderMyDrive: function(e) {
        return "/root/My Drive" === this.getViewRootPath(e)
    },
    getViewRole: function(e) {
        if (_S("is_admin") && this.isUnderMyDrive(e)) {
            return this.getTopToolbar().getComponent("time_bar").getComponent("view_role_link").el.dom.innerText
        }
        return _S("user")
    },
    setViewRole: function(e) {
        var t = this.getTopToolbar().getComponent("time_bar").getComponent("view_role_link").el;
        t.update(e), t.set({
            "ext:qtip": e
        }), this.getTopToolbar().getComponent("time_bar").syncSize()
    },
    updateViewRoleLink: function() {
        var e = this.getTopToolbar().getComponent("time_bar").getComponent("view_role_link"),
            t = this.getTopToolbar().getComponent("time_bar").getComponent("view_role_left"),
            i = this.getTopToolbar().getComponent("time_bar").getComponent("view_role_right");
        _S("is_admin") && this.isUnderMyDrive(this.pathBar.getPath()) ? (e.setVisible(!0), t.setVisible(!0), i.setVisible(!0)) : (e.setVisible(!1), t.setVisible(!1), i.setVisible(!1)), this.getTopToolbar().getComponent("time_bar").syncSize()
    },
    suspendPanels: function(e) {
        e && (this.treePanel.getEl().mask(), this.gridPanel.getEl().mask()), this.treePanel.getSelectionModel().suspendEvents()
    },
    resumePanels: function(e) {
        this.treePanel.getSelectionModel().resumeEvents(), e && (this.treePanel.getEl().unmask(), this.gridPanel.getEl().unmask())
    },
    displayErrorMessage: function(e) {
        if (e && e.code) {
            var t = SYNO.SDS.CSTN.getErrorString(e);
            this.getMsgBox().alert(_STR("app", "app_name"), t, function() {
                (SYNO.SDS.CSTN.needCloseWindow(e.code) || e.code === SYNO.SDS.CSTN.ErrorCode.SYS_DISK_FULL) && this.close()
            }, this)
        } else this.getMsgBox().alert(_STR("app", "app_name"), _T("common", "error_system"))
    },
    createGridStore: function() {
        return new SYNO.API.JsonStore({
            api: SYNO.SDS.CSTN.WebAPI.Node.api,
            timeout: 3e5,
            version: 1,
            method: "list",
            appWindow: this,
            root: "items",
            totalProperty: "total",
            idProperty: "id",
            fields: ["node_id", "sync_id", "permanent_id", "permanent_link", "name", "path", "v_file_size", "mtime", "ver_cnt", "file_type", "is_removed", "is_encrypted", "is_share", "absolute_path"],
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            remoteSort: !0,
            baseParams: {
                offset: 0,
                limit: 1e3
            },
            listeners: {
                beforeload: function(e, t) {
                    return Ext.apply(t.params, this.getBaseParams()), t
                },
                exception: function(e, t, i, n, o, s) {
                    this.displayErrorMessage(o)
                },
                scope: this
            }
        })
    },
    createGridMenu: function() {
        return new SYNO.ux.Menu({
            cls: "syno-cstn-explorer-filebrowser-menu",
            items: [{
                itemId: "menu_show_version",
                text: _STR("btn", "showver"),
                iconCls: "syno-cstn-explorer-filebrowser-show-version",
                disabled: !0,
                listeners: {
                    click: this.onClickShowVersions,
                    scope: this
                }
            }, {
                itemId: "menu_copy",
                text: _STR("btn", "copy_to") + "...",
                iconCls: "syno-cstn-explorer-filebrowser-copy-icon",
                disabled: !0,
                listeners: {
                    click: this.onClickCopyTo,
                    scope: this
                }
            }, {
                itemId: "menu_restore",
                text: _STR("btn", "restore"),
                iconCls: "syno-cstn-explorer-filebrowser-restore-icon",
                disabled: !0,
                listeners: {
                    click: this.onClickRestore,
                    scope: this
                }
            }, {
                itemId: "menu_download",
                text: _STR("showdel", "btn_dl"),
                iconCls: "syno-cstn-explorer-filebrowser-download-icon",
                disabled: !0,
                listeners: {
                    click: this.onClickDownload,
                    scope: this
                }
            }]
        })
    },
    createGridColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: _STR("showdel", "attr_name"),
                dataIndex: "name",
                sortable: !0,
                iconUrl: this.jsConfig.jsBaseURL,
                renderer: function(e, t, i, n, o, s) {
                    var a = i.data,
                        r = SYNO.SDS.CSTN.Icon.EXT_ICON_PREFIX + (SYNO.SDS.UIFeatures.test("isRetina") ? "2x/" : "1x/"),
                        l = /(?:\.([^.]+))?$/.exec(e.toLowerCase())[1];
                    1 === a.file_type ? r += SYNO.SDS.CSTN.Icon.FOLDER_ICON : 2 !== a.file_type && l ? l && (!0 === a.is_encrypted && l in SYNO.SDS.CSTN.Icon.ENCRYPTED_FILE_EXT_ICONS ? r += SYNO.SDS.CSTN.Icon.ENCRYPTED_FILE_EXT_ICONS[l] : l in SYNO.SDS.CSTN.Icon.FILE_EXT_ICONS ? r += SYNO.SDS.CSTN.Icon.FILE_EXT_ICONS[l] : r += SYNO.SDS.CSTN.Icon.FILE_ICON) : r += SYNO.SDS.CSTN.Icon.FILE_ICON;
                    var h, d = this.iconUrl + "/images/files_ext/" + r + "?v=" + _S("version");
                    return a.is_removed ? (h = '<div class="{0}" style="background-image:url({1})"></div>', h += '<div class="syno-removed-icon"></div>', h += '<div class="syno-text-indent">&nbsp;{2}</div>') : h = SYNO.SDS.CSTN.IsDSM7OrAbove() ? '<div class="{0}" style="background:url({1}) no-repeat; background-size: 16px 16px; padding-left: 24px; background-position: left center;">&nbsp;{2}</div>' : '<div class="{0}"><img width="16" height="16" src="{1}" align="absmiddle"/>&nbsp;{2}</div>', String.format(h, a.is_removed ? "syno-file-icon" : "", d, Ext.util.Format.htmlEncode(e))
                }
            }, {
                header: _STR("showdel", "attr_size"),
                dataIndex: "v_file_size",
                sortable: !0,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "right",
                renderer: function(e, t, i, n, o, s) {
                    return 1 === i.data.file_type || i.data.is_removed ? "" : Ext.util.Format.fileSize(e)
                }
            }, {
                header: _STR("showdel", "attr_type"),
                dataIndex: "file_type",
                sortable: !0,
                renderer: function(e, t, i, n, o, s) {
                    var a = /(?:\.([^.]+))?$/.exec(i.get("name"))[1];
                    return 1 === e ? _STR("showdel", "attr_type_folder") : 2 === e ? "Symbolic Link" : a ? Ext.util.Format.htmlEncode(a.toUpperCase() + " " + _STR("showdel", "attr_type_file")) : _STR("showdel", "attr_type_file")
                }
            }, {
                header: _STR("showdel", "attr_modify_time"),
                dataIndex: "mtime",
                sortable: !0,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "right",
                renderer: SYNO.SDS.CSTN.RenderTime
            }]
        })
    },
    getBaseParams: function() {
        var e = this.treePanel.getSelectionModel().getSelectedNode(),
            t = e.attributes.absolute_path.split("/")[1],
            i = e.attributes.absolute_path.substr(t.length + 1),
            n = "/" === e.attributes.absolute_path,
            o = {
                list_removed: this.show_removed_file,
                ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds(),
                node: this.pathBar.getPath(),
                target: t,
                path: i || "/",
                exclude_home: n,
                view_role: this.getViewRole(this.pathBar.getPath())
            };
        return e.attributes.node_id && Ext.apply(o, {
            node_id: parseInt(e.attributes.node_id, 10)
        }), Ext.apply(o, this.searchBar.getSearchCriteria()), o
    },
    updatePath: function(e, t) {
        if (t = t || {}, e) {
            if (t.viewRole && t.viewRole !== this.getViewRole(e) && (this.setViewRole(t.viewRole), this.historyManager.clearHistory()), t.skipHistory || this.historyManager.storePath(e), this.pathBar.setPath(e), this.historyManager.getPrevPath() ? this.pathToolbar.items.get(0).enable() : this.pathToolbar.items.get(0).disable(), this.historyManager.getNextPath() ? this.pathToolbar.items.get(1).enable() : this.pathToolbar.items.get(1).disable(), this.treeLoading) return clearInterval(this.delayUpdateTimer), void(this.delayUpdateTimer = setInterval(function() {
                this.treeLoading || (clearInterval(this.delayUpdateTimer), this.updatePath(e, t))
            }.createDelegate(this), 200));
            this.treeLoading = !0, t.refresh ? (this.suspendPanels(!0), this.treePanel.getRootNode().reload(function() {
                this.treePanel.selectPath(e, "name", Ext.createDelegate(function(e, t, i) {
                    this.getTopToolbar().getComponent("action_bar").getComponent("btn_action").menu;
                    if (this.resumePanels(!0), this.treeLoading = !1, !e) return this.gridPanel.getStore().removeAll(), void this.gridPanel.bwrap.mask(_STR("warning", "error_folder_not_exist"), "syno-ux-mask-info");
                    i.expandTreeNode && t.expand(), this.updateGridPanel(i.filename), this.updateViewRoleLink()
                }, this, [t], !0))
            }, this)) : (this.suspendPanels(!1), this.treePanel.selectPath(e, "name", Ext.createDelegate(function(e, t, i) {
                this.getTopToolbar().getComponent("action_bar").getComponent("btn_action").menu;
                if (this.resumePanels(!1), this.treeLoading = !1, !e) return this.gridPanel.getStore().removeAll(), void this.gridPanel.bwrap.mask(_STR("warning", "error_folder_not_exist"), "syno-ux-mask-info");
                i.expandTreeNode && t.expand(), this.updateGridPanel(i.filename), this.updateViewRoleLink()
            }, this, [t], !0)))
        }
    },
    updateGridPanel: function(e) {
        var t = this.gridPanel.getStore(),
            i = this.treePanel.getSelectionModel().getSelectedNode(),
            n = this.getBaseParams();
        i.attributes.node_id && (n.node_id = parseInt(i.attributes.node_id, 10)), Ext.isEmpty(t.proxy.activeRequest.read) || Ext.Ajax.abort(t.proxy.activeRequest.read), t.load({
            params: n,
            callback: function(i, n, o) {
                if (o && e) {
                    var s = t.find("name", e); - 1 !== s ? this.gridPanel.selModel.selectRow(s) : this.onGridSelectionChange(this.gridPanel.selModel)
                }
            },
            scope: this
        })
    },
    openOfficeHistoryView: function(e, t) {
        window.open(window.location.origin + "/oo/r/" + e + "#version_time=" + t)
    },
    isCopyingOfficeItems: function(e) {
        var t = this;
        return new Promise(function(i, n) {
            if (!0 === e) return void i();
            t.getMsgBox().confirm(_STR("app", "app_name"), _STR("confirm", "copy_to_export"), function(e) {
                "yes" === e ? i() : n()
            })
        })
    },
    dryrunForPasswd: function(e, t, i) {
        SYNO.SDS.CSTN.WebAPI.Node.dryrun.call(this, e, t, this.show_removed_file, this.getViewRole(this.pathBar.getPath()), function(e, n) {
            if (this.getEl().unmask(), !1 === e || !1 === Ext.isDefined(n)) return void this.getMsgBox().alert(_STR("app", "app_name"), _STR("warning", "err_sys"));
            if (0 === n.length) return void i.call(this);
            var o = new SYNO.SDS.CSTN.EncryptedFileDialog({
                owner: this,
                nodes_info: n,
                ori_nodes_info: t
            });
            this.mon(o, "apply", i, this, {
                single: !0
            }), o.show()
        }, this)
    },
    onClickPathBack: function() {
        var e = this.historyManager.moveToPrevPath();
        e && this.updatePath(e, {
            skipHistory: !0
        })
    },
    onClickPathNext: function() {
        var e = this.historyManager.moveToNextPath();
        e && this.updatePath(e, {
            skipHistory: !0
        })
    },
    onClickPathItem: function(e, t) {
        this.updatePath(t)
    },
    onClickSearch: function(e, t) {
        this.updatePath(this.pathBar.getPath(), {
            skipHistory: !0,
            refresh: !0
        })
    },
    onClickSearchReset: function(e, t) {
        this.updatePath(this.pathBar.getPath(), {
            skipHistory: !0,
            refresh: !0
        })
    },
    onCheckShowRemovedFiles: function(e, t, i) {
        this.show_removed_file = t, this.updatePath(this.pathBar.getPath(), {
            skipHistory: !0
        })
    },
    onClickShowVersions: function(e, t, i) {
        var n = this.treePanel.getSelectionModel().getSelectedNode(),
            o = n.attributes.absolute_path.split("/")[1],
            s = this.gridPanel.getSelectionModel().getSelected();
        SYNO.SDS.Drive.Extension.Instance.isOfficeFile(s.get("name")) ? this.openOfficeHistoryView(s.get("permanent_link"), this.timePanel.getUTCTimeSeconds()) : new SYNO.SDS.CSTN.DialogVersion({
            owner: this
        }).winShow({
            target: o,
            nodeid: s.get("node_id"),
            filename: s.get("name"),
            path: s.get("path"),
            file_type: s.get("file_type"),
            is_removed: s.get("is_removed"),
            view_role: this.getViewRole(this.pathBar.getPath())
        })
    },
    onClickDeleteForever: function(e, t, i) {
        var n = this.treePanel.getSelectionModel().getSelectedNode(),
            o = n.attributes.absolute_path.split("/")[1],
            s = this.gridPanel.getSelectionModel().getSelections(),
            a = [];
        Ext.each(s, function(e) {
            a.push({
                node_id: e.get("node_id"),
                sync_id: e.get("is_removed") ? "0" : e.get("sync_id"),
                ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds(),
                name: e.get("name"),
                path: e.get("path"),
                file_type: e.get("file_type"),
                is_removed: e.get("is_removed")
            })
        }, this), this.getMsgBox().confirm(_STR("app", "app_name"), _STR("showdel", "msg_confirmdel"), function(e) {
            if ("yes" === e) {
                new SYNO.SDS.CSTN.DeleteNodeTask({
                    owner: this,
                    recycle_panel: this.gridPanel
                }).startDeleteNode(o, a, this.getViewRole(this.pathBar.getPath()))
            }
        }, this)
    },
    onClickCopyTo: function() {
        var e = new SYNO.SDS.CSTN.Explore.PathSelector({
            owner: this
        });
        this.mon(e, "apply", this.onPathSelectorApply, this, {
            single: !0
        }), e.open()
    },
    onPathSelectorApply: function(e, t) {
        var i = this.treePanel.getSelectionModel().getSelectedNode(),
            n = i.attributes.absolute_path.split("/")[1],
            o = this.gridPanel.getSelectionModel().getSelections(),
            s = [];
        Ext.each(o, function(e) {
            s.push({
                node_id: e.get("node_id"),
                sync_id: e.get("sync_id"),
                permanent_id: e.get("permanent_id"),
                ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds(),
                name: e.get("name"),
                path: e.get("path"),
                file_type: e.get("file_type"),
                is_removed: e.get("is_removed")
            })
        }, this);
        var a = this,
            r = function(e) {
                a.isCopyingOfficeItems(h).then(function() {
                    new SYNO.SDS.CSTN.RestoreTask({
                        owner: a,
                        recycle_panel: a.gridPanel,
                        copy_to: t.dest_path,
                        override: t.override
                    }).startRestore(n, s, a.getViewRole(a.pathBar.getPath()), e, a.show_removed_file)
                }).catch(function() {})
            },
            l = t.dest_path.indexOf("/", 1),
            h = SYNO.SDS.Drive.Extension.Instance.isUnderCloudStationFolder(t.dest_path.substr(l));
        !1 === h ? this.dryrunForPasswd(n, s, r) : r()
    },
    onClickDownload: function() {
        var e = this.treePanel.getSelectionModel().getSelectedNode(),
            t = e.attributes.absolute_path.split("/")[1],
            i = this.gridPanel.getSelectionModel().getSelections(),
            n = [];
        this.getEl().mask(), Ext.each(i, function(e) {
            n.push({
                node_id: e.get("node_id"),
                sync_id: e.get("sync_id"),
                permanent_id: e.get("permanent_id"),
                ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds(),
                name: e.get("name"),
                path: e.get("path"),
                file_type: e.get("file_type"),
                is_removed: e.get("is_removed")
            })
        }, this);
        var o = function(e) {
            new SYNO.SDS.CSTN.DownloadTask({
                owner: this,
                recycle_panel: this.gridPanel,
                timelinedate: this.timePanel.getUTCTimeSeconds()
            }).startDownload(t, n, this.getViewRole(this.pathBar.getPath()), e, this.show_removed_file)
        };
        this.dryrunForPasswd(t, n, o)
    },
    onClickRestore: function() {
        var e = this.treePanel.getSelectionModel().getSelectedNode(),
            t = e.attributes.absolute_path.split("/")[1],
            i = this.gridPanel.getSelectionModel().getSelections(),
            n = [];
        Ext.each(i, function(e) {
            n.push({
                node_id: e.get("node_id"),
                sync_id: e.get("sync_id"),
                permanent_id: e.get("permanent_id"),
                ver_ctime_upper_bound: this.timePanel.getUTCTimeSeconds(),
                name: e.get("name"),
                path: e.get("path"),
                file_type: e.get("file_type"),
                is_removed: e.get("is_removed")
            })
        }, this);
        var o = function(e) {
            this.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "restore_confirm"), function(i) {
                if ("yes" === i) {
                    new SYNO.SDS.CSTN.RestoreTask({
                        owner: this,
                        recycle_panel: this.gridPanel,
                        override: !0
                    }).startRestore(t, n, this.getViewRole(this.pathBar.getPath()), e, this.show_removed_file)
                }
            }, this)
        };
        this.dryrunForPasswd(t, n, o)
    },
    onTreeSelectionChange: function(e, t) {
        t && this.updatePath(t.getPath("name"))
    },
    onGridSelectionChange: function(e) {
        var t = !1,
            i = !1,
            n = !1,
            o = !1,
            s = !1,
            a = !1,
            r = this.getTopToolbar().getComponent("action_bar"),
            l = this.gridMenu,
            h = !1,
            d = [SYNO.SDS.CSTN.Explore.ToolbarController.kSTATE_INIT];
        Ext.each(e.getSelections(), function(e) {
            SYNO.SDS.Drive.Extension.Instance.isOfficeFile(e.get("name")) && (h = !0), 0 === e.get("file_type") ? t = !0 : 1 === e.get("file_type") ? i = !0 : 2 === e.get("file_type") && (n = !0), 0 === e.get("ver_cnt") && (o = !0), e.get("is_removed") || (s = !0), e.get("is_share") && (a = !0)
        }), _S("demo_mode") || 0 === e.getSelections().length || (a ? d.push(SYNO.SDS.CSTN.Explore.ToolbarController.kSTATE_SHARED_FOLDER) : (d.push(SYNO.SDS.CSTN.Explore.ToolbarController.kSTATE_ENABLE_RESTORE_RELATED), !t || o || n || i || 1 !== e.getSelections().length || d.push(SYNO.SDS.CSTN.Explore.ToolbarController.kSTATE_ENABLE_VIEW), s || h || d.push(SYNO.SDS.CSTN.Explore.ToolbarController.kSTATE_ENABLE_DELETE_VERS))), SYNO.SDS.CSTN.Explore.ToolbarController.adjustToolbar(d, r, l)
    },
    onRightClickGrid: function(e, t, i) {
        if (!0 !== e.store.getAt(t).get("is_share")) {
            this.gridMenu.showAt(i.getXY());
            var n = e.getSelectionModel();
            n.selectRow(t, n.isSelected(t))
        }
    },
    onDoubleClickGrid: function(e, t, i) {
        var n = e.getStore().getAt(t);
        1 === n.get("file_type") ? this.updatePath(this.pathBar.getPath() + "/" + n.get("name")) : SYNO.SDS.Drive.Extension.Instance.isOfficeFile(n.get("name")) ? this.openOfficeHistoryView(n.get("permanent_link"), this.timePanel.getUTCTimeSeconds()) : 0 === n.get("file_type") && this.onClickDownload()
    },
    onTimeSelected: function(e) {
        var t = this.treePanel.getSelectionModel().getSelectedNode();
        this.updatePath(this.pathBar.getPath(), {
            skipHistory: !0,
            refresh: !0,
            expandTreeNode: !!t && t.isExpanded()
        })
    }
});
