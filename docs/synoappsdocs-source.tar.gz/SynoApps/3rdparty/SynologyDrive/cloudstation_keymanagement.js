/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.CSTN"), 
/**
 * @class SYNO.SDS.CSTN.KeyManagement.EditDialog
 * @extends SYNO.SDS.ModalWindow
 * SynologyDrive key management edit dialog class
 *
 */
Ext.define("SYNO.SDS.CSTN.KeyManagement.EditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        this.owner = t.owner, this.appWin = t.appWin, this.editMode = t.editMode, this.callParent([this.fillConfig(t || {})])
    },
    fillConfig: function(t) {
        var e = t.editParams || {},
            n = {
                title: this.editMode ? _STR("userkey", "edit_key") : _STR("userkey", "add_key"),
                width: 600,
                minWidth: 600,
                height: 350,
                minHeight: 350,
                resizable: !1,
                layout: "fit",
                items: [{
                    xtype: "syno_formpanel",
                    itemId: "form",
                    labelAlign: "left",
                    trackResetOnLoad: !0,
                    waitMsgTarget: !0,
                    border: !1,
                    labelWidth: 161,
                    items: [{
                        xtype: "syno_combobox",
                        fieldLabel: _T("common", "owner"),
                        labelStyle: "margin-left: 0px; width: 180px;",
                        itemId: "username",
                        displayField: "name",
                        valueField: "name",
                        mode: "remote",
                        pageSize: 50,
                        editable: !1,
                        width: 380,
                        listWidth: 380,
                        maxHeight: 360,
                        minChars: 1,
                        typeAhead: !0,
                        store: this.createAccountStore(),
                        allowBlank: !1,
                        blankText: _T("user", "error_noname"),
                        validateOnBlur: !0,
                        validationDelay: 250,
                        validationEvent: "keyup",
                        hidden: this.editMode,
                        disabled: this.editMode
                    }, {
                        xtype: "syno_displayfield",
                        fieldLabel: _T("common", "owner"),
                        width: 380,
                        name: "text_owner",
                        value: e.username,
                        hidden: !this.editMode
                    }, {
                        xtype: "syno_textarea",
                        textType: "text",
                        fieldLabel: _STR("userkey", "ssh_key"),
                        itemId: "key",
                        width: 380,
                        height: 210,
                        name: "user_key",
                        value: e.keyContent,
                        startValidate: !1,
                        validator: function() {
                            return !0
                        }
                    }]
                }],
                fbar: {
                    xtype: "statusbar",
                    hideMode: "visibility",
                    defaultText: "&nbsp;",
                    statusAlign: "left",
                    buttonAlign: "left",
                    items: [{
                        xtype: "syno_button",
                        btnStyle: "blue",
                        hidden: !1,
                        text: this.editMode ? _STR("btn", "btn_save") : _STR("btn", "btn_add"),
                        itemId: "btn_apply",
                        scope: this,
                        handler: this.editMode ? this.onClickSave : this.onClickAdd
                    }, {
                        xtype: "syno_button",
                        btnStyle: "grey",
                        hidden: !1,
                        text: _T("common", "alt_cancel"),
                        itemId: "btn_cancel",
                        scope: this,
                        handler: this.onClickCancel
                    }]
                }
            };
        return Ext.apply(n, t)
    },
    initComponent: function() {
        this.callParent(arguments), this.addEvents("add", "save")
    },
    createAccountStore: function() {
        return new SYNO.API.JsonStore({
            autoDestroy: !0,
            api: "SYNO.Core.User",
            method: "list",
            version: 1,
            appWindow: this.owner,
            baseParams: {
                type: "all",
                offset: 0,
                limit: -1
            },
            root: "users",
            totalProperty: "total",
            id: "name",
            fields: [{
                name: "name",
                sortType: "asNaturalUCString"
            }],
            remoteSort: !0,
            defaultSortable: !0,
            pruneModifiedRecords: !0,
            scope: this
        })
    },
    onClickAdd: function() {
        var t = this.getComponent("form"),
            e = t.getComponent("username").getValue(),
            n = t.getComponent("key").getValue();
        if (!t.getForm().isValid()) return void this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        });
        SYNO.SDS.CSTN.WebAPI.KeyManagement.set.call(this.appWin, {
            username: e,
            key: n
        }, function(t, e, n, i) {
            if (!t || e && e.code) return void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [e]);
            this.fireEvent("add"), this.close()
        }, this)
    },
    onClickSave: function() {
        var t = this.getComponent("form"),
            e = t.getComponent("key").getValue(),
            n = this.editParams.id;
        if (!t.getForm().isValid()) return void this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        });
        SYNO.SDS.CSTN.WebAPI.KeyManagement.set.call(this.appWin, {
            id: n,
            key: e
        }, function(t, e, n, i) {
            if (!t || e && e.code) return void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [e]);
            this.fireEvent("save"), this.close()
        }, this)
    },
    onClickCancel: function() {
        this.close()
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.KeyManagement.ImportDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        this.owner = t.owner, this.appWin = t.appWin, this.callParent([this.fillConfig(t || {})])
    },
    fillConfig: function(t) {
        var e = {
            width: 500,
            height: 180,
            resizable: !1,
            title: _STR("btn", "btn_import"),
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                itemId: "formpanel",
                labelAlign: "left",
                labelWidth: 150,
                fileUpload: !0,
                url: t.appWin.getBaseURL({
                    api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".KeyManagement",
                    method: "import",
                    version: 1
                }),
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("userkey", "import_desc")
                }, {
                    xtype: "syno_filebutton",
                    fieldLabel: _T("common", "file"),
                    name: "upload_key"
                }],
                listeners: {
                    actioncomplete: this.onActionComplete,
                    actionfailed: this.onActionFailed,
                    scope: this
                }
            }],
            buttons: [{
                btnStyle: "blue",
                text: _STR("btn", "btn_import"),
                handler: this.onClickImport,
                scope: this
            }, {
                text: _T("common", "close"),
                handler: this.close,
                scope: this
            }]
        };
        return Ext.apply(e, t)
    },
    onClickImport: function() {
        var t = this.getComponent("formpanel").getForm();
        t.isValid() && (t.isDirty() || this.close(), this.setStatusBusy({
            text: _T("common", "saving")
        }), t.submit())
    },
    onActionComplete: function(t, e) {
        this.clearStatusBusy(), this.fireEvent("import"), this.close()
    },
    onActionFailed: function(t, e) {
        this.clearStatusBusy(), this.setStatusError({
            text: SYNO.SDS.CSTN.getErrorString(e.result.error)
        })
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.KeyManagement.MainWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        this.owner = t.owner, this.appWin = t.owner, this.callParent([this.fillConfig(t || {})])
    },
    fillConfig: function(t) {
        var e = this.createGridStore(),
            n = {
                title: _STR("userkey", "userkey_titile"),
                width: 680,
                height: 480,
                resizable: !0,
                layout: "fit",
                items: [{
                    xtype: "syno_gridpanel",
                    itemId: "grid_panel",
                    tbar: {
                        xtype: "toolbar",
                        items: [{
                            xtype: "syno_button",
                            cls: "syno-cstn-tab-btn-main-el",
                            ctCls: "syno-cstn-tab-btn",
                            disabled: this._S("demo_mode"),
                            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                            itemId: "btn_add",
                            text: _T("common", "add"),
                            handler: this.onClickAdd,
                            scope: this
                        }, {
                            xtype: "syno_button",
                            cls: "syno-cstn-tab-btn-main-el",
                            ctCls: "syno-cstn-tab-btn",
                            disabled: !0,
                            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                            itemId: "btn_edit",
                            text: _T("common", "alt_edit"),
                            handler: this.onClickEdit,
                            scope: this
                        }, {
                            xtype: "syno_button",
                            cls: "syno-cstn-tab-btn-main-el",
                            ctCls: "syno-cstn-tab-btn",
                            disabled: !0,
                            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                            itemId: "btn_delete",
                            text: _T("common", "delete"),
                            handler: this.onClickDelete,
                            scope: this
                        }, {
                            xtype: "syno_button",
                            cls: "syno-cstn-tab-btn-main-el",
                            ctCls: "syno-cstn-tab-btn",
                            disabled: this._S("demo_mode"),
                            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                            itemId: "btn_import",
                            text: _STR("btn", "btn_import"),
                            handler: this.onClickImport,
                            scope: this
                        }, {
                            xtype: "syno_button",
                            cls: "syno-cstn-tab-btn-main-el",
                            ctCls: "syno-cstn-tab-btn",
                            disabled: this._S("demo_mode"),
                            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                            itemId: "btn_export",
                            text: _STR("btn", "btn_export"),
                            handler: this.onClickExport,
                            scope: this
                        }]
                    },
                    colModel: this.createGridColumnModel(),
                    store: e,
                    loadMask: !0,
                    bbar: {
                        xtype: "syno_paging",
                        cls: "cstn-paging-toolbar",
                        store: e,
                        pageSize: 100,
                        displayInfo: !0
                    }
                }],
                fbar: {
                    xtype: "statusbar",
                    hideMode: "visibility",
                    defaultText: "&nbsp;",
                    statusAlign: "left",
                    buttonAlign: "left",
                    items: [{
                        xtype: "syno_button",
                        btnStyle: "grey",
                        hidden: !1,
                        text: _T("common", "close"),
                        itemId: "btn_close",
                        scope: this,
                        handler: this.onClickClose
                    }]
                }
            };
        return Ext.apply(n, t)
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this.getComponent("grid_panel").getSelectionModel(), "selectionchange", this.onGridSelectionChange, this)
    },
    onClickAdd: function() {
        var t = new SYNO.SDS.CSTN.KeyManagement.EditDialog({
            owner: this,
            appWin: this.owner,
            editMode: !1
        });
        this.mon(t, "add", this.reloadGrid, this), t.open()
    },
    onClickEdit: function() {
        var t = this.getComponent("grid_panel").getSelectionModel().getSelected(),
            e = new SYNO.SDS.CSTN.KeyManagement.EditDialog({
                owner: this,
                appWin: this.owner,
                editMode: !0,
                editParams: {
                    id: t.get("id"),
                    username: t.get("username"),
                    keyContent: t.get("key_content")
                }
            });
        this.mon(e, "save", this.reloadGrid, this), e.open()
    },
    onClickDelete: function() {
        this.getMsgBox().alert(_STR("app", "app_name"), _STR("common", "confirm_remove"), function() {
            var t = this.getComponent("grid_panel").getSelectionModel().getSelections(),
                e = [];
            Ext.each(t, function(t) {
                e.push(t.get("id"))
            }), SYNO.SDS.CSTN.WebAPI.KeyManagement.delete.call(this.appWin, e, function(t, e, n, i) {
                if (!t || e && e.code) return void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [e]);
                this.reloadGrid()
            }, this)
        }, this)
    },
    onClickExport: function() {
        this.getMsgBox().alert(_STR("app", "app_name"), _STR("warning", "warning_wait_for_key_export"), function() {
            this.owner.downloadWebAPI({
                webapi: {
                    api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".KeyManagement",
                    version: 1,
                    method: "export"
                }
            })
        }, this)
    },
    onClickImport: function() {
        var t = new SYNO.SDS.CSTN.KeyManagement.ImportDialog({
            owner: this,
            appWin: this.owner
        });
        this.mon(t, "import", this.reloadGrid, this), t.open()
    },
    reloadGrid: function() {
        this.getComponent("grid_panel").getStore().reload()
    },
    createGridColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                width: 40,
                header: _T("common", "owner"),
                dataIndex: "username",
                align: "left",
                sortable: !0
            }, {
                header: _STR("userkey", "ssh_key"),
                dataIndex: "key_description",
                align: "left",
                sortable: !1
            }]
        })
    },
    createGridStore: function() {
        return new SYNO.API.JsonStore({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".KeyManagement",
            version: 1,
            method: "list",
            appWindow: this,
            root: "items",
            totalProperty: "total",
            idProperty: "id",
            fields: ["id", "uid", "username", "key_description", "key_content"],
            autoLoad: !0,
            remoteSort: !0,
            sortInfo: {
                field: "username",
                direction: "ASC"
            },
            baseParams: {
                offset: 0,
                limit: 100
            }
        })
    },
    onClickClose: function() {
        this.close()
    },
    onGridSelectionChange: function(t) {
        var e = this.getComponent("grid_panel").getTopToolbar(),
            n = t.getSelections();
        this._S("demo_mode") || (0 === n.length ? (e.getComponent("btn_edit").disable(), e.getComponent("btn_delete").disable()) : 1 === n.length ? (e.getComponent("btn_edit").enable(), e.getComponent("btn_delete").enable()) : (e.getComponent("btn_edit").disable(), e.getComponent("btn_delete").enable()))
    }
});
