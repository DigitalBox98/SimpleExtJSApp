/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.WelcomeWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.owner = e.owner;
        var t = [{
            illustrationImage: "illustration-img01",
            title: _STR("cstn", "welcome_title_intro"),
            description: _STR("cstn", "welcome_desc_intro")
        }];
        SYNO.SDS.CSTN.HasOffice() || t.push({
            illustrationImage: "illustration-img02",
            title: _STR("cstn", "welcome_title_office"),
            description: String.format(_STR("cstn", "welcome_desc_office"), '<a id="synopkg-office">' + _STR("cstn", "package_center") + "</a>"),
            description_listeners: {
                afterrender: function() {
                    Ext.get("synopkg-office").on("click", function() {
                        _S("majorversion") >= 7 ? SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                            action: "open",
                            packages: ["Spreadsheet"]
                        }) : SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance")
                    }, this)
                }
            }
        }), t.push({
            illustrationImage: "illustration-img03",
            title: _STR("cstn", "welcome_title_team_folder"),
            description: _STR("cstn", "welcome_desc_team_folder"),
            buttonText: _STR("btn", "proceed"),
            buttonHandler: function() {
                this.owner.selectPage("SYNO.SDS.CSTN.PanelSharing"), this.owner.appInstance.setUserSettings("welcome_window_ds_id", e.ds_id), this.destroy()
            }.bind(this)
        });
        var i = {
            cls: "syno-cstn-welcome",
            width: 680,
            height: 531,
            header: !1,
            elements: "body",
            useStatusBar: !1,
            resizable: !1,
            closable: !1,
            draggable: !1,
            layout: "fit",
            items: new SYNO.SDS.CSTN.WelcomeWindowFlow({
                steps: t
            })
        };
        return Ext.apply(i, e)
    }
}), Ext.ns("SYNO.SDS.CSTN.WelcomeWindow"), Ext.define("SYNO.SDS.CSTN.WelcomeWindowFlow", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        return this.steps = e.steps, this.currentStepIndex = 0, this.currentStep = new SYNO.SDS.CSTN.WelcomeWindowStep({
            owner: this,
            step: this.steps[this.currentStepIndex],
            stepIndex: this.currentStepIndex,
            totalStep: this.steps.length
        }), {
            layout: "fit",
            items: this.currentStep
        }
    },
    gotoStep: function(e) {
        if (!(e >= this.steps.length)) {
            var t = new SYNO.SDS.CSTN.WelcomeWindowStep({
                owner: this,
                step: this.steps[e],
                stepIndex: e,
                totalStep: this.steps.length
            });
            this.remove(this.currentStep), this.add(t), this.currentStep = t, this.currentStepIndex = e, this.doLayout()
        }
    },
    nextStep: function() {
        this.gotoStep(this.currentStepIndex + 1)
    }
}), Ext.define("SYNO.SDS.CSTN.WelcomeWindowStep", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.owner = e.owner;
        var t = e.step;
        return {
            layout: {
                type: "vbox",
                align: "center"
            },
            items: [{
                xtype: "container",
                cls: "illustration-spacer"
            }, {
                xtype: "container",
                cls: t.illustrationImage
            }, {
                xtype: "syno_displayfield",
                cls: "illustration-title",
                value: t.title
            }, {
                xtype: "spacer",
                height: 12
            }, {
                xtype: "container",
                cls: "illustration-desc",
                html: t.description,
                listeners: t.description_listeners
            }, {
                xtype: "spacer",
                height: 20
            }, {
                xtype: "syno_button",
                cls: "illustration-button",
                btnStyle: "blue",
                autoWidth: !1,
                text: t.buttonText ? t.buttonText : _T("common", "next"),
                handler: t.buttonHandler ? t.buttonHandler : this.owner.nextStep.bind(this.owner)
            }, this.generateDotIndicators(e.stepIndex, e.totalStep)]
        }
    },
    generateDotIndicators: function(e, t) {
        for (var i = [], n = 0; n < t; ++n) 0 !== n && i.push({
            xtype: "container",
            cls: "dot-indicator-space"
        }), i.push({
            xtype: "syno_button",
            cls: n === e ? "dot-indicator-current" : "dot-indicator",
            targetIndex: n,
            owner: this.owner,
            handler: function() {
                this.owner.gotoStep(this.targetIndex)
            }
        });
        return {
            xtype: "container",
            layout: "hbox",
            cls: "dot-indicator-zone",
            items: i
        }
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PanelCloudStn", {
    extend: "SYNO.SDS.Utils.FormPanel",
    layout: "fit",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.enableStatusPollTask = void 0, this.isStatusNormal = !1, this.getStatus = {
            api: SYNO.SDS.CSTN.WebAPI.api,
            version: 1,
            method: "get_status",
            params: {}
        }, this.getConnectionSummary = {
            api: SYNO.SDS.CSTN.WebAPI.Connection.api,
            version: 2,
            method: "summary",
            params: {}
        }, this.getConfig = {
            api: SYNO.SDS.CSTN.WebAPI.Config.api,
            version: 1,
            method: "get",
            params: {}
        }, this.getUsageTrend = {
            api: SYNO.SDS.CSTN.WebAPI.Statistics.api,
            version: 1,
            method: "get",
            params: {
                after: parseInt(((new Date).getTime() - 2592e6) / 1e3)
            }
        }, this.statusPanelItem = new SYNO.SDS.CSTN.Overview.Status({
            owner: this,
            status_type: "preparing"
        }), this.clientInfoPanel = new SYNO.SDS.CSTN.Overview.PanelClientInfo({
            owner: this.owner,
            module: this.module
        }), this.lastAuthTimePanel = new SYNO.SDS.CSTN.PanelLastOnline({
            owner: this.owner,
            module: this.module
        }), this.topFilesPanel = new SYNO.SDS.CSTN.GridPanelTopFiles({
            owner: this.owner,
            module: this.module
        }), this.databaseUsagePanel = new SYNO.SDS.CSTN.Overview.PanelDatabaseUsage({
            owner: this.owner,
            module: this.module
        });
        var t = SYNO.SDS.CSTN.IsDSM7OrAbove() ? 16 : 10,
            i = {
                itemId: "overview",
                cls: "syno-cstn-overview-content",
                border: !1,
                items: [{
                    xtype: "panel",
                    id: this.statusPanelId = Ext.id(),
                    bodyStyle: "padding: 0px;",
                    border: !1,
                    layout: "fit",
                    cls: "syno-cstn-overview-panel",
                    items: this.statusPanelItem
                }, {
                    xtype: "spacer",
                    height: t
                }, {
                    xtype: "panel",
                    bodyStyle: "padding: 0px;",
                    border: !1,
                    height: 190,
                    layout: "fit",
                    cls: "syno-cstn-overview-panel",
                    items: this.clientInfoPanel
                }, {
                    xtype: "spacer",
                    height: t
                }, {
                    xtype: "panel",
                    bodyStyle: "padding: 0px;",
                    border: !1,
                    height: 267,
                    layout: "fit",
                    cls: "syno-cstn-overview-panel",
                    items: [{
                        xtype: "syno_fieldset",
                        title: _STR("cstn", "last_online_time_title"),
                        items: [this.lastAuthTimePanel]
                    }]
                }, {
                    xtype: "spacer",
                    height: t
                }, {
                    xtype: "panel",
                    bodyStyle: "padding: 0px;",
                    border: !1,
                    height: 294,
                    layout: "fit",
                    cls: "syno-cstn-overview-panel",
                    items: [{
                        xtype: "syno_fieldset",
                        title: _STR("cstn", "top_accessed_files"),
                        items: [this.topFilesPanel]
                    }]
                }, {
                    xtype: "spacer",
                    height: t
                }, {
                    xtype: "panel",
                    bodyStyle: "padding: 0px;",
                    border: !1,
                    height: 286,
                    layout: "fit",
                    cls: "syno-cstn-overview-panel syno-cstn-database-panel",
                    items: this.databaseUsagePanel
                }, {
                    xtype: "spacer",
                    height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 20 : 12
                }]
            },
            n = {
                itemId: "overview-out",
                bodyStyle: "padding-top: 0px;",
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                listeners: {
                    scope: this,
                    flexcroll: this.onFleXcroll
                },
                items: [i]
            };
        this.callParent([Ext.apply(n, e)])
    },
    shouldShowWelcomeWindow: function(e) {
        return this.owner.appInstance.getUserSettings("welcome_window_ds_id") != e
    },
    showWelcomeWindow: function(e) {
        new SYNO.SDS.CSTN.WelcomeWindow({
            owner: this.owner,
            ds_id: e
        }).open()
    },
    freezeResume: function() {
        this.resumeService()
    },
    ajaxDeleteDatabaseCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.resumeService,
            failure: SYNO.SDS.CSTN.webapiErrHdl
        })
    },
    onDeleteDatabase: function() {
        this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "msg_remove_drive_db"), function(e) {
            "yes" === e && SYNO.SDS.CSTN.WebAPI.deleteDatabase.call(this.owner, this.ajaxDeleteDatabaseCB, this)
        }, this)
    },
    resumeService: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.resumeFreeze.call(this.owner, function() {
            this.owner.clearStatusBusy(), this.loadForm()
        }, this)
    },
    updateStatus: function(e) {
        var t = {
            owner: this
        };
        if (Ext.isDefined(e.enable_status)) {
            switch (e.enable_status) {
                case "updating":
                case "done":
                    t.status_type = "preparing", t.status_desc = _STR("warning", "msg_upgrading"), this.ctrlEnableStatusPollingTask(!0);
                    break;
                case "initializing":
                    t.status_type = "preparing", t.status_desc = _STR("warning", "msg_initializing"), this.ctrlEnableStatusPollingTask(!0);
                    break;
                case "checking":
                    t.status_type = "preparing", t.status_desc = _STR("warning", "msg_checking_db"), this.ctrlEnableStatusPollingTask(!0);
                    break;
                case "enabled":
                    if (e.cstn_freeze) {
                        var i = _STR("warning", "free_up_volume"),
                            n = [];
                        Ext.each(e.freeze_volume_id, function(e) {
                            n.push(_T("volume", "volume") + " " + e)
                        }, this), t.status_type = "error", t.status_text = _STR("warning", "err_diskfull"), t.status_desc = String.format(i, n.join(", ")), t.additional_button = "resume", this.ctrlEnableStatusPollingTask(!1)
                    } else e.no_folder_available ? (t.status_type = "no_folder_available", this.isStatusNormal = !0, this.ctrlEnableStatusPollingTask(!0)) : (t.status_type = "enabled", this.isStatusNormal = !0, this.ctrlEnableStatusPollingTask(!0));
                    break;
                case "upgradefail":
                case "dbnewer":
                case "dbunexist":
                    t.status_type = "error", "upgradefail" === e.enable_status ? (t.status_text = _STR("common", "database_upgrade_failed"), t.status_desc = _STR("warning", "error_drive_upgradefail")) : "dbnewer" === e.enable_status ? (t.status_text = _STR("common", "database_error"), t.status_desc = _STR("warning", "error_upgrade_db_newer_delete")) : "dbunexist" === e.enable_status && (t.status_text = _STR("common", "database_error"), t.status_desc = _STR("warning", "error_db_unexist_delete")), t.additional_button = "db_delete", this.ctrlEnableStatusPollingTask(!1);
                    break;
                case "homedisabled":
                    t.status_type = "error", t.status_text = _STR("common", "error"), t.status_desc = _STR("warning", "err_enable_homes"), this.ctrlEnableStatusPollingTask(!1);
                    break;
                case "portconflict":
                    t.status_type = "error", t.status_text = _STR("common", "port_error"), t.status_desc = String.format(_STR("warning", "warn_drive_port_conflict"), "6690"), t.additional_button = "resume", this.ctrlEnableStatusPollingTask(!1)
            }
            if (!this.statusPanelItem.isEquivalentStatus(t)) {
                var s = Ext.getCmp(this.statusPanelId);
                s.remove(this.statusPanelItem), this.statusPanelItem = new SYNO.SDS.CSTN.Overview.Status(t), s.add(this.statusPanelItem), this.doLayout(), this.module.enableStatus = e.enable_status
            }
        }
    },
    ctrlEnableStatusPollingTask: function(e) {
        e ? void 0 === this.enableStatusPollTask && (this.enableStatusPollTask = this.addWebAPITask({
            id: "enable_status_polltask",
            interval: 5e3,
            autoJsonDecode: !0,
            api: SYNO.SDS.CSTN.WebAPI.api,
            version: 1,
            method: "get_status",
            callback: function(e, t, i) {
                if (t.code) switch (t.code) {
                    case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
                        return void this.ctrlEnableStatusPollingTask(!1)
                }
                this.loadStatusDone(e, t)
            },
            scope: this
        }), this.enableStatusPollTask.start(!1)) : void 0 !== this.enableStatusPollTask && (this.enableStatusPollTask.stop(), this.enableStatusPollTask = void 0)
    },
    loadStatusDone: function(e, t) {
        if (this.isStatusNormal = !1, t.code) {
            switch (t.code) {
                case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
                case SYNO.SDS.CSTN.ErrorCode.REPO_MOVE:
                case SYNO.SDS.CSTN.ErrorCode.CANNOT_ACCESS:
                    this.ctrlEnableStatusPollingTask(!1)
            }
            return SYNO.SDS.CSTN.webapiErrHdl.call(this, t), !1
        }
        return this.updateStatus(t), this.module.cstnInfo = t, this.doLayout(), !0
    },
    loadConfigDone: function(e, t) {
        if (!e) return this.isStatusNormal && SYNO.SDS.CSTN.webapiErrHdl.call(this, t), !1;
        var i = !t.enable_non_admin_user_sync;
        return this.clientInfoPanel.changeButtonList(i), this.shouldShowWelcomeWindow(t.ds_id) && this.showWelcomeWindow(t.ds_id), !0
    },
    loadUsageTrendDone: function(e, t) {
        var i = ["database", "repo", "office"],
            n = {};
        i.forEach(function(e) {
            n[e] = []
        });
        var s = 1;
        t.statistics.forEach(function(e) {
            var t = e.labels.type;
            null !== t && -1 !== i.indexOf(t) && (n[t].push([1e3 * e.timestamp, e.value]), e.value > s && (s = e.value))
        });
        for (var o = 0; s >= 1024;) o++, s /= 1024;
        return this.databaseUsagePanel.updateData(n, o), !0
    },
    loadClientInfoDone: function(e, t) {
        return e ? (this.getForm().findField("client_count_total").setValue(t.summary.total), this.getForm().findField("client_count_sharesync").setValue(t.summary.sharesync), this.getForm().findField("client_count_desktop").setValue(t.summary.desktop), this.getForm().findField("client_count_mobile").setValue(t.summary.mobile), this.doLayout(), !0) : (this.isStatusNormal && SYNO.SDS.CSTN.webapiErrHdl.call(this, t), !1)
    },
    ajaxLoadFormCB: function(e, t, i, n) {
        var s = t.result;
        this.owner.clearStatusBusy();
        for (var o = 0; o < s.length; ++o) {
            var a = null;
            if (SYNO.ux.Utils.checkApiConsistency(this.getStatus, s[o]) ? a = this.loadStatusDone : SYNO.ux.Utils.checkApiConsistency(this.getConnectionSummary, s[o]) ? a = this.loadClientInfoDone : SYNO.ux.Utils.checkApiConsistency(this.getConfig, s[o]) ? a = this.loadConfigDone : SYNO.ux.Utils.checkApiConsistency(this.getUsageTrend, s[o]) && (a = this.loadUsageTrendDone), a && !1 === a.call(this, s[o].success, s[o].data || s[o].error)) break
        }
    },
    loadForm: function() {
        SYNO.SDS.CSTN.DBG("PanelCSTN loadForm"), this.owner.setStatusBusy(), this.lastAuthTimePanel.onPageActivate(), this.topFilesPanel.onPageActivate(), this.sendWebAPI({
            stop_when_error: !1,
            compound: {
                params: [this.getStatus, this.getConfig, this.getUsageTrend, this.getConnectionSummary]
            },
            callback: this.ajaxLoadFormCB,
            scope: this
        })
    },
    onPageActivate: function() {
        this.loadForm(), this.ctrlEnableStatusPollingTask(!0), this.ownerCt.addClass("syno-cstn-overview"), this.doLayout()
    },
    onPageDeactivate: function() {
        this.ownerCt.removeClass("syno-cstn-overview")
    },
    onActivate: function() {
        this.onPageActivate()
    },
    onDeactivate: function() {
        this.onPageDeactivate()
    },
    onFleXcroll: function(e, t) {
        var i = this.clientInfoPanel.getDownloadButton();
        i && i.menu.fireEvent("onScroll", t)
    }
}), Ext.ns("SYNO.SDS.CSTN.Overview"), Ext.define("SYNO.SDS.CSTN.Overview.Status", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.owner = e.owner, this.statusConfig = this.applyDefaultConfig(e);
        var t = SYNO.SDS.CSTN.IsDSM7OrAbove(),
            i = !!this.statusConfig.additional_button,
            n = {
                xtype: "container",
                layout: {
                    type: "hbox",
                    align: "stretch"
                },
                items: [{
                    xtype: "container",
                    width: t ? 91 : 123,
                    items: {
                        xtype: "container",
                        cls: "syno-cstn-overview-icon-" + this.statusConfig.status
                    }
                }, {
                    xtype: "container",
                    flex: 1,
                    layout: {
                        type: "vbox",
                        pack: "center",
                        align: "stretch"
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-cstn-overview-icon-text-" + this.statusConfig.status,
                        value: this.statusConfig.status_text
                    }, {
                        xtype: "spacer",
                        height: t ? 4 : 8
                    }, this.generateStatusDescription()]
                }]
            },
            s = {};
        t ? s = {
            itemId: "status",
            height: 106,
            layout: {
                type: "hbox",
                align: "stretch"
            },
            items: [Ext.apply(n, {
                flex: 1
            }), {
                xtype: "container",
                style: {
                    padding: "17px 19px 0px 0px"
                },
                items: this.generateAdditionalButton()
            }]
        } : (s = {
            itemId: "status",
            height: i ? 140 : 104,
            layout: {
                type: "vbox",
                pack: "center",
                align: "stretch"
            },
            style: {
                padding: "0px 30px 0px 0px"
            },
            items: [Ext.apply(n, {
                height: 64
            })]
        }, i && s.items.push({
            xtype: "spacer",
            height: 8
        }, {
            xtype: "container",
            height: 28,
            items: this.generateAdditionalButton()
        })), this.callParent([Ext.apply(s)])
    },
    applyDefaultConfig: function(e) {
        var t = {};
        switch (e.status_type) {
            case "enabled":
                t = {
                    status: e.status_type,
                    status_text: _STR("common", "drive_enable"),
                    status_desc: _STR("cstn", "desc_server_enabled")
                };
                break;
            case "preparing":
                t = {
                    status: e.status_type,
                    status_text: _STR("common", "preparing_drive"),
                    status_desc: ""
                };
                break;
            case "no_folder_available":
                t = {
                    status: "warning",
                    status_text: _STR("common", "no_available_folder"),
                    status_desc: {
                        html: String.format(_STR("warning", "enable_team_folder"), '<a id="teamfolder-link">' + _STR("category", "team_folder") + "</a>"),
                        listeners: {
                            afterrender: function() {
                                Ext.get("teamfolder-link").on("click", function() {
                                    this.owner.owner.selectPage("SYNO.SDS.CSTN.PanelSharing")
                                }, this)
                            }
                        }
                    }
                };
                break;
            case "error":
                t = {
                    status: e.status_type,
                    status_text: _STR("common", "error"),
                    status_desc: ""
                }
        }
        return Ext.apply(t, e)
    },
    generateAdditionalButton: function() {
        switch (this.statusConfig.additional_button) {
            case "resume":
                return this.generateResumeDriveButton();
            case "db_delete":
                return this.generateDbRemoveButton();
            default:
                return
        }
    },
    generateResumeDriveButton: function() {
        return {
            xtype: "syno_button",
            cls: "syno-cstn-overview-button",
            btnStyle: "grey",
            text: _STR("cstn", "btn_resume_drive_server"),
            handler: this.owner.freezeResume,
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            scope: this.owner
        }
    },
    generateDbRemoveButton: function() {
        return {
            xtype: "syno_button",
            cls: "syno-cstn-overview-button",
            btnStyle: "red",
            text: _STR("cstn", "btn_remove_db"),
            handler: this.owner.onDeleteDatabase,
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            scope: this.owner
        }
    },
    generateStatusDescription: function() {
        var e = {
            xtype: "syno_displayfield",
            autoHeight: !0,
            cls: "syno-cstn-overview-icon-desc",
            owner: this.owner
        };
        return Ext.isObject(this.statusConfig.status_desc) ? Ext.apply(e, this.statusConfig.status_desc) : Ext.apply(e, {
            value: this.statusConfig.status_desc
        })
    },
    isEquivalentStatus: function(e) {
        var t = this.applyDefaultConfig(e);
        return Ext.isObject(this.statusConfig.status_desc) ? t.status === this.statusConfig.status && t.status_text === this.statusConfig.status_text && t.status_desc.html === this.statusConfig.status_desc.html && t.additional_button === this.statusConfig.additional_button : t.status === this.statusConfig.status && t.status_text === this.statusConfig.status_text && t.status_desc === this.statusConfig.status_desc && t.additional_button === this.statusConfig.additional_button
    }
}), Ext.define("SYNO.SDS.CSTN.Overview.Panel", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e || {});
        this.callParent([t])
    },
    getTitleConfig: function() {
        return ""
    },
    getTitleItems: function() {},
    getButtonListConfig: function() {
        return []
    },
    getContentConfig: function() {
        return {}
    },
    fillConfig: function(e) {
        this.buttonList = this.getButtonListConfig();
        var t = this.generateButtonListWithSeperator(this.buttonList),
            i = {
                height: 190,
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                items: [{
                    xtype: "container",
                    cls: "syno-cstn-overview-panel-title",
                    layout: {
                        type: "hbox",
                        align: "stretch"
                    },
                    items: [{
                        xtype: "container",
                        cls: "syno-cstn-title-text",
                        flex: 1,
                        html: this.getTitleConfig(),
                        items: this.getTitleItems()
                    }, {
                        xtype: "container",
                        id: this.buttonListId = Ext.id(),
                        cls: "syno-cstn-button-list",
                        layout: {
                            type: "hbox",
                            pack: "end"
                        },
                        items: t
                    }]
                }, this.getContentConfig()]
            };
        return Ext.apply(i, e), i
    },
    generateButtonListWithSeperator: function(e) {
        var t = [];
        return Ext.each(e, function(i, n) {
            i.cls = "syno-cstn-title-button " + i.cls, t.push(i), n !== e.length - 1 && (t = t.concat([{
                xtype: "spacer",
                width: 12
            }, {
                xtype: "container",
                cls: "syno-cstn-title-seperator"
            }, {
                xtype: "spacer",
                width: 12
            }]))
        }), t
    },
    changeButtonList: function(e) {
        var t = !0;
        if (e.length !== this.buttonList.length ? t = !1 : Ext.each(e, function(e, i) {
                if (e.itemId !== this.buttonList[i].itemId) return t = !1, !1
            }, this), !t) {
            this.buttonList = e;
            var i = Ext.getCmp(this.buttonListId);
            i.removeAll(), i.add(this.generateButtonListWithSeperator(e))
        }
    }
}), Ext.define("SYNO.SDS.CSTN.Overview.DownloadWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner;
        var t = {
                xtype: "statusbar",
                defaultText: "&nbsp;",
                buttonAlign: "left",
                items: [{
                    xtype: "syno_button",
                    btnStyle: "grey",
                    text: _T("common", "close"),
                    scope: this,
                    handler: this.close
                }]
            },
            i = {
                resizable: !1,
                width: 600,
                height: 420,
                title: _STR("cstn", "download_mobile_client"),
                cls: "syno-cstn-download-window",
                fbar: t,
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                items: [{
                    xtype: "container",
                    layout: {
                        type: "vbox",
                        align: "center"
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        cls: "syno-cstn-desc",
                        value: _STR("common", "mobile_desc")
                    }]
                }, {
                    xtype: "container",
                    flex: 1,
                    cls: "syno-cstn-qrcode-section",
                    layout: {
                        type: "hbox",
                        pack: "center",
                        align: "middle"
                    },
                    items: [{
                        xtype: "container",
                        items: {
                            xtype: "container",
                            cls: "syno-cstn-qrcode",
                            layout: {
                                type: "vbox",
                                pack: "center",
                                align: "center"
                            },
                            items: [{
                                xtype: "container",
                                cls: "syno-cstn-qrcode-ios"
                            }, {
                                xtype: "syno_displayfield",
                                cls: "syno-cstn-qrcode-text",
                                value: _T("common", "ios")
                            }]
                        },
                        listeners: {
                            scope: this,
                            afterrender: {
                                single: !0,
                                fn: function(e) {
                                    this.mon(e.getEl(), "click", function() {
                                        window.open("https://itunes.apple.com/us/app/synology-drive/id1267275421?ls=1&mt=8", "_blank")
                                    }, this)
                                }
                            }
                        }
                    }, {
                        xtype: "spacer",
                        width: 60
                    }, {
                        xtype: "container",
                        items: {
                            xtype: "container",
                            cls: "syno-cstn-qrcode",
                            layout: {
                                type: "vbox",
                                pack: "center",
                                align: "center"
                            },
                            items: [{
                                xtype: "container",
                                cls: "syno-cstn-qrcode-android"
                            }, {
                                xtype: "syno_displayfield",
                                cls: "syno-cstn-qrcode-text",
                                value: _T("common", "android")
                            }]
                        },
                        listeners: {
                            scope: this,
                            afterrender: {
                                single: !0,
                                fn: function(e) {
                                    this.mon(e.getEl(), "click", function() {
                                        window.open("https://play.google.com/store/apps/details?id=com.synology.dsdrive", "_blank")
                                    }, this)
                                }
                            }
                        }
                    }]
                }, {
                    xtype: "spacer",
                    height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 23 : 26
                }]
            };
        this.callParent([Ext.apply(i, e)])
    }
}), Ext.define("SYNO.SDS.CSTN.Overview.PanelClientInfo", {
    extend: "SYNO.SDS.CSTN.Overview.Panel",
    constructor: function(e) {
        this.callParent(arguments), this.lastScrollTop = 0
    },
    getDownloadButton: function() {
        return Ext.getCmp(this.downloadButtonId)
    },
    getTitleConfig: function() {
        return _STR("cstn", "title_overview_clientinfo")
    },
    getButtonListConfig: function(e) {
        var t = {
                xtype: "syno_button",
                id: this.downloadButtonId = Ext.id(),
                itemId: "download_button",
                tooltip: _STR("common", "download_client"),
                cls: "syno-cstn-download-icon",
                menuAlign: "tl-bl?",
                menu: {
                    xtype: "syno_menu",
                    listeners: {
                        scope: this,
                        onScroll: this.onScroll
                    },
                    items: [{
                        text: _STR("cstn", "download_desktop_client"),
                        listeners: {
                            scope: this,
                            click: this.onClickGetDesktopClient
                        }
                    }, {
                        text: _STR("cstn", "download_mobile_client"),
                        listeners: {
                            scope: this,
                            click: this.onClickGetMobileClient
                        }
                    }]
                }
            },
            i = {
                xtype: "syno_button",
                itemId: "jumpto_button",
                tooltip: String.format(_STR("cstn", "tooltip_goto_other_tab"), _STR("func", "mgr_clientinfo")),
                cls: "syno-cstn-jumpto-icon",
                scope: this,
                handler: this.onJumptoClientList
            };
        return e ? [i] : [t, i]
    },
    onScroll: function(e) {
        this.lastScrollTop !== e.scrollTop && this.getDownloadButton().menu.hide(), this.lastScrollTop = e.scrollTop
    },
    onClickGetDesktopClient: function() {
        SYNO.SDS.CSTN.WebAPI.getClientLink.call(this, this.getOS(), window.navigator.platform, "drive", function(e, t, i, n) {
            var s = _STR("warning", "err_get_download_link_fail");
            e ? SYNO.SDS.Utils.IFrame.request(t.download_link, function(e, t, i, n) {
                "timeout" === e || Ext.isGecko && !Ext.isObject(n) || this.owner.getMsgBox().alert("", s)
            }, this) : this.owner.getMsgBox().alert("", s)
        }, this)
    },
    getOS: function() {
        return Ext.isMac ? "Mac" : Ext.isWindows ? "Windows" : Ext.isLinux ? "Linux" : "default"
    },
    onClickGetMobileClient: function() {
        var e = new SYNO.SDS.CSTN.Overview.DownloadWindow({
            owner: this.owner
        });
        e.doLayout(), e.open()
    },
    onJumptoClientList: function() {
        this.owner.selectPage("SYNO.SDS.CSTN.PanelClient")
    },
    getContentConfig: function() {
        return {
            xtype: "container",
            flex: 1,
            cls: "syno-cstn-client-panel",
            layout: {
                type: "hbox",
                align: "stretch"
            },
            defaults: {
                xtype: "container",
                flex: 1,
                layout: {
                    type: "vbox",
                    pack: "center",
                    align: "center"
                }
            },
            items: [{
                xtype: "spacer",
                width: 21
            }, {
                cls: "syno-cstn-client-panel-total",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-cstn-client-panel-total-value",
                    name: "client_count_total",
                    value: "-"
                }, {
                    xtype: "container",
                    cls: "syno-cstn-client-panel-total-title",
                    html: _STR("clientinfo", "total_client")
                }]
            }, {
                xtype: "spacer",
                width: 40
            }, {
                xtype: "container",
                width: 1,
                cls: "syno-cstn-client-panel-seperator"
            }, {
                xtype: "spacer",
                width: 40
            }, {
                cls: "syno-cstn-client-panel-box",
                items: [{
                    xtype: "container",
                    cls: "syno-cstn-client-icon-sharesync"
                }, {
                    xtype: "container",
                    cls: "syno-cstn-client-panel-title",
                    html: _STR("clientinfo", "client_serversync"),
                    listeners: {
                        render: function(e) {
                            e.getEl().set({
                                "ext:qtip": _STR("clientinfo", "client_serversync")
                            })
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-cstn-client-panel-value",
                    name: "client_count_sharesync",
                    value: "-"
                }]
            }, {
                xtype: "spacer",
                width: 40
            }, {
                cls: "syno-cstn-client-panel-box",
                items: [{
                    xtype: "container",
                    cls: "syno-cstn-client-icon-desktop"
                }, {
                    xtype: "container",
                    cls: "syno-cstn-client-panel-title",
                    html: _STR("clientinfo", "client_drive"),
                    listeners: {
                        render: function(e) {
                            e.getEl().set({
                                "ext:qtip": _STR("clientinfo", "client_drive")
                            })
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-cstn-client-panel-value",
                    name: "client_count_desktop",
                    value: "-"
                }]
            }, {
                xtype: "spacer",
                width: 40
            }, {
                cls: "syno-cstn-client-panel-box",
                items: [{
                    xtype: "container",
                    cls: "syno-cstn-client-icon-mobile"
                }, {
                    xtype: "container",
                    cls: "syno-cstn-client-panel-title",
                    html: _STR("clientinfo", "client_mobile"),
                    listeners: {
                        render: function(e) {
                            e.getEl().set({
                                "ext:qtip": _STR("clientinfo", "client_mobile")
                            })
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    cls: "syno-cstn-client-panel-value",
                    name: "client_count_mobile",
                    value: "-"
                }]
            }, {
                xtype: "spacer",
                width: 21
            }]
        }
    },
    changeButtonList: function(e) {
        this.callParent([this.getButtonListConfig(e)])
    }
}), Ext.define("SYNO.SDS.CSTN.PanelLastOnline", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = [{
                id: "client_type",
                header: _STR("clientinfo", "client_type"),
                dataIndex: "client_type",
                align: "left",
                sortable: !1,
                flex: 1,
                renderer: function(e) {
                    return {
                        drive: _STR("clientinfo", "client_drive"),
                        drive_backup: _STR("clientinfo", "client_drive"),
                        drive_mobile: _STR("clientinfo", "client_drive_mobile"),
                        backup: _STR("clientinfo", "client_backup"),
                        ds_cloud: _STR("clientinfo", "client_ds_cloud"),
                        cloudstation: _STR("clientinfo", "client_cloudstation"),
                        sharesync: _STR("clientinfo", "client_sharesync"),
                        serversync: _STR("clientinfo", "client_serversync"),
                        unknown: "--"
                    } [e]
                }
            }, {
                id: "client_id",
                header: _STR("cstn", "device_name"),
                dataIndex: "client_id",
                align: "left",
                flex: 1,
                sortable: !1
            }, {
                id: "client_name",
                header: _STR("common", "usrname"),
                dataIndex: "client_name",
                align: "left",
                flex: 1,
                sortable: !1
            }, {
                id: "last_auth_time",
                header: _STR("cstn", "last_online_time"),
                dataIndex: "last_auth_time",
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "right",
                renderer: function(e, t, i) {
                    return 0 === e ? _STR("common", "no_data") : "on_line" == i.get("client_status") ? _STR("clientinfo", "connected") : SYNO.SDS.CSTN.RenderLastDays(e, t)
                },
                flex: 1,
                sortable: !1
            }, {
                id: "client_padding",
                header: "",
                dataIndex: "",
                width: 16,
                fixed: !0,
                sortable: !1
            }],
            i = new Ext.grid.ColumnModel({
                columns: t
            }),
            n = this.createStore();
        n.on("load", function(e, t, i) {
            0 === t.length ? this.el.select(".x-grid3-header").addClass("hide-headers") : this.el.select(".x-grid3-header").removeClass("hide-headers")
        }.bind(this));
        var s = {
            bodyStyle: "padding-bottom: 3px;",
            cls: "syno-cstn-last-online-panel",
            itemId: "client",
            view: new SYNO.ux.FleXcroll.grid.GridView({
                emptyText: _STR("empty", "sync_client")
            }),
            stripeRows: !1,
            enableColLock: !1,
            enableHdMenu: !1,
            disableSelection: !0,
            enableColumnResize: !1,
            colModel: i,
            ds: n,
            loadMask: !0,
            height: 228
        };
        return SYNO.SDS.CSTN.IsDSM7OrAbove() || Ext.apply(s, {
            bodyStyle: "padding-bottom: 8px;",
            height: 230
        }), SYNO.LayoutConfig.fill(s), Ext.apply(s, e), s
    },
    createStore: function() {
        var e = ["client_id", "client_name", "client_status", "client_type", "last_auth_time"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Connection.api,
                    version: 1,
                    method: "list",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    idProperty: "id"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    offset: 0,
                    limit: 50,
                    sort_by: "last_auth_time",
                    sort_direction: "ASC",
                    exclude_client_types: ["drive_mobile"]
                },
                remoteSort: !0
            });
        return this.addManagedComponent(t), t
    },
    onPageActivate: function() {
        this.headerBtnWrap && this.headerBtnWrap.remove(), this.store.load()
    }
}), Ext.define("SYNO.SDS.CSTN.GridPanelTopFiles", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = [{
                id: "file_index",
                dataIndex: "file",
                align: "left",
                sortable: !1,
                width: 53,
                fixed: !0,
                renderer: function(e, t, i, n) {
                    return String.format('<div class="syno-cstn-file-string syno-cstn-file-index">{0}</div><div class="syno-cstn-file-icon" style="background-image:url({1});"></div>', n + 1, this.owner.jsConfig.jsBaseURL + SYNO.SDS.CloudStation.getIconPath(e.name, "dir" === e.type))
                }.bind(this)
            }, {
                id: "file_name",
                dataIndex: "file",
                align: "left",
                sortable: !1,
                flex: 1,
                renderer: function(e, t, i, n) {
                    return t.attr += String.format('ext:qtip="{0}"', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.name))), Ext.util.Format.htmlEncode(e.name)
                }.bind(this)
            }, {
                id: "file_folder",
                dataIndex: "file",
                align: "left",
                sortable: !1,
                flex: 1,
                renderer: function(e, t, i, n) {
                    var s = e.full_path.substring(0, e.full_path.lastIndexOf("/"));
                    return t.attr += String.format('ext:qtip="{0}"', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(s))), Ext.util.Format.htmlEncode(s)
                }
            }, {
                id: "count",
                dataIndex: "count",
                width: 125,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "right",
                fixed: !0,
                sortable: !1,
                renderer: function(e, t, i, n) {
                    var s = "",
                        o = '<div class="syno-cstn-top-file-tooltip"> <p class="syno-cstn-top-file-tooltip-left">' + _STR("cstn", "previews") + _T("common", "colon") + '</p> &nbsp; <p class="syno-cstn-top-file-tooltip-right">' + i.data.file.preview_count + "</p> </div>",
                        a = '<div class="syno-cstn-top-file-tooltip"> <p class="syno-cstn-top-file-tooltip-left">' + _STR("cstn", "downloads") + _T("common", "colon") + '</p> &nbsp; <p class="syno-cstn-top-file-tooltip-right">' + i.data.file.download_count + "</p> </div>";
                    switch (this.getType()) {
                        case "preview":
                            s += o;
                            break;
                        case "download":
                            s += a;
                            break;
                        case "both":
                            s += o, s += a
                    }
                    return t.attr += String.format('ext:qtip="{0}"', Ext.util.Format.htmlEncode(s)), Ext.util.Format.htmlEncode(e)
                }.bind(this)
            }, {
                id: "padding",
                width: 0,
                fixed: !0,
                sortable: !1
            }],
            i = new Ext.grid.ColumnModel({
                columns: t
            }),
            n = this.createStore();
        this.ds_rank = new Ext.data.JsonStore({
            fields: ["display", "value", "log_type"],
            data: [{
                display: _STR("cstn", "previews_and_downloads"),
                value: "both",
                log_type: [SYNO.SDS.CSTN.LogType.download_event, SYNO.SDS.CSTN.LogType.preview_event]
            }, {
                display: _STR("cstn", "downloads"),
                value: "download",
                log_type: [SYNO.SDS.CSTN.LogType.download_event]
            }, {
                display: _STR("cstn", "previews"),
                value: "preview",
                log_type: [SYNO.SDS.CSTN.LogType.preview_event]
            }]
        }), this.rank_combo = new SYNO.ux.ComboBox({
            ctCls: "syno-cstn-grid syno-cstn-grid-combo",
            name: "combo_share",
            mode: "local",
            hideLabel: !1,
            editable: !1,
            store: this.ds_rank,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: "both",
            width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 340 : 320,
            height: 38,
            hidden: !1,
            listeners: {
                scope: this,
                select: function(e, t, i) {
                    this.loadData()
                }
            }
        }), this.ds_time = new Ext.data.JsonStore({
            fields: ["display", "value"],
            data: [{
                display: String.format(_STR("cstn", "last_hours"), "24"),
                value: 1
            }, {
                display: String.format(_STR("cstn", "last_days"), "7"),
                value: 7
            }, {
                display: String.format(_STR("cstn", "last_days"), "30"),
                value: 30
            }]
        }), this.time_combo = new SYNO.ux.ComboBox({
            ctCls: "syno-cstn-grid syno-cstn-grid-combo",
            name: "combo_share",
            mode: "local",
            hideLabel: !1,
            editable: !1,
            store: this.ds_time,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: 1,
            width: 180,
            height: 28,
            hidden: !1,
            listeners: {
                scope: this,
                select: function(e, t, i) {
                    this.loadData()
                }
            }
        });
        var s = new Ext.Toolbar;
        s.add({
            xtype: "syno_displayfield",
            value: _STR("cstn", "ranking_by") + _T("common", "colon")
        }), s.add(" "), s.add(this.rank_combo), s.add("->"), s.add(this.time_combo);
        var o = {
            cls: "syno-cstn-top-file-panel",
            itemId: "client",
            view: new SYNO.ux.FleXcroll.grid.GridView({
                emptyText: _STR("empty", "grid")
            }),
            hideHeaders: !0,
            tbar: s,
            stripeRows: !1,
            enableColLock: !1,
            enableHdMenu: !1,
            disableSelection: !0,
            colModel: i,
            ds: n,
            autoExpandColumn: "file_folder",
            loadMask: !0,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            listeners: {
                cellclick: function(e, t, i, n) {
                    if (1 === i) {
                        var s = e.getStore().data.items[t].data,
                            o = this.rank_combo.getStore().find("value", this.rank_combo.getValue());
                        this.owner.setPreConfig("SYNO.SDS.CSTN.PanelLog", {
                            keyword: s.file.name,
                            username: "anonymous",
                            types: this.rank_combo.getStore().getAt(o).data.log_type
                        }), this.owner.selectPage("SYNO.SDS.CSTN.PanelLog")
                    }
                }
            }
        };
        return SYNO.LayoutConfig.fill(o), Ext.apply(o, e), o
    },
    createStore: function() {
        var e = ["count", "file"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Dashboard.api,
                    version: 1,
                    method: "top_access_files",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "files",
                    totalProperty: "total",
                    idProperty: "id"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit"
                },
                baseParams: {
                    offset: 0,
                    limit: 50,
                    ranking_by: "both",
                    period_days: 1
                },
                remoteSort: !0
            });
        return this.addManagedComponent(t), t
    },
    onPageActivate: function() {
        this.headerBtnWrap && this.headerBtnWrap.remove(), this.loadData()
    },
    loadData: function() {
        this.store.setBaseParam("period_days", this.time_combo.getValue()), this.store.setBaseParam("ranking_by", this.rank_combo.getValue()), this.store.load()
    },
    getType: function() {
        return this.rank_combo.getValue()
    }
}), Ext.define("SYNO.SDS.CSTN.Overview.PanelDatabaseUsage", {
    extend: "SYNO.SDS.CSTN.Overview.Panel",
    constructor: function(e) {
        this.callParent(arguments), this.getEchartsPromise()
    },
    getEchartsPromise: function() {
        return this.echartsPromise ? this.echartsPromise : this.echartsPromise = new Promise(function(e, t) {
            if ("undefined" != typeof echarts) return void e();
            var i = document.createElement("script");
            i.onload = e, i.onerror = t, i.async = !0, i.type = "text/javascript", i.src = "webman/3rdparty/SynologyDrive/echarts.min.js", document.head.appendChild(i)
        })
    },
    getTitleConfig: function() {},
    getTitleItems: function() {
        return [{
            xtype: "container",
            html: _STR("cstn", "server_usage_trend"),
            cls: "syno-cstn-database-panel-title",
            listeners: {
                afterrender: function(e) {
                    var t = SYNO.SDS.CSTN.IsDSM7OrAbove() ? _STR("cstn", "usage_trend_tooltip") : _STR("cstn", "usage_trend_tooltip_simplified");
                    SYNO.ux.AddTip ? SYNO.ux.AddTip(this.getEl(), t) : SYNO.SDS.Utils.AddTip && SYNO.SDS.Utils.AddTip(this.getEl(), t)
                }
            }
        }]
    },
    getButtonListConfig: function(e) {
        return [{
            xtype: "syno_button",
            tooltip: String.format(_STR("cstn", "tooltip_goto_other_tab"), _STR("func", "database_title")),
            cls: "syno-cstn-jumpto-icon",
            scope: this,
            handler: function() {
                this.owner.selectPage("SYNO.SDS.CSTN.PanelConfigure")
            }.bind(this)
        }]
    },
    updateData: function(e, t) {
        e.database.length > 0 && (Ext.getCmp(this.usageTitleId).setVisible(!0), Ext.getCmp(this.usageTextId).setValue(String.format(_STR("cstn", "usage"), SYNO.SDS.CSTN.GetFileSizeUnits()[t])), this.epsChart.updateData(e, t))
    },
    getContentConfig: function() {
        this.epsChart = new SYNO.SDS.CSTN.EchartsPanel({
            collapsible: !1,
            flex: 1,
            height: 200,
            hideMode: "offsets"
        }, this.getEchartsPromise());
        var e = {
            xtype: "container",
            cls: "syno-cstn-database-panel-right",
            flex: 5,
            items: [{
                xtype: "container",
                cls: "syno-cstn-database-panel-right-dot",
                style: "background-color: " + SYNO.SDS.CSTN.EchartsPanel.setting.repo.lightColor
            }, {
                xtype: "syno_displayfield",
                html: String.format('<span ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.repo.tip)), Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.repo.name)),
                cls: "syno-cstn-database-panel-right-item"
            }, {
                xtype: "container",
                cls: "syno-cstn-database-panel-right-dot",
                style: "background-color: " + SYNO.SDS.CSTN.EchartsPanel.setting.database.lightColor
            }, {
                xtype: "syno_displayfield",
                html: String.format('<span ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.database.tip)), Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.database.name)),
                cls: "syno-cstn-database-panel-right-item"
            }]
        };
        return SYNO.SDS.CSTN.HasOffice() && e.items.push({
            xtype: "container",
            cls: "syno-cstn-database-panel-right-dot",
            style: "background-color: " + SYNO.SDS.CSTN.EchartsPanel.setting.office.lightColor
        }, {
            xtype: "syno_displayfield",
            html: String.format('<span ext:qtip="{0}">{1}</span>', Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.office.tip)), Ext.util.Format.htmlEncode(SYNO.SDS.CSTN.EchartsPanel.setting.office.name)),
            cls: "syno-cstn-database-panel-right-item"
        }), config = {
            xtype: "container",
            cls: "syno-cstn-database-panel-container",
            flex: 1,
            items: [{
                xtype: "container",
                height: 22,
                id: this.usageTitleId = Ext.id(),
                hidden: !0,
                layout: {
                    type: "hbox",
                    align: "stretch"
                },
                defaults: {
                    flex: 1
                },
                items: [{
                    xtype: "syno_displayfield",
                    id: this.usageTextId = Ext.id(),
                    value: String.format(_STR("cstn", "usage"), SYNO.SDS.CSTN.GetFileSizeUnits()[0]),
                    cls: "syno-cstn-database-panel-left",
                    flex: 2
                }, e]
            }, this.epsChart]
        }, config
    },
    changeButtonList: function(e) {
        this.callParent([this.getButtonListConfig(e)])
    }
}), Ext.define("SYNO.SDS.CSTN.EchartsPanel", {
    extend: "Ext.Panel",
    statics: {
        setting: {
            repo: {
                name: "",
                tip: "",
                darkColor: "#FAAF00",
                lightColor: "#FAAF00"
            },
            database: {
                name: "",
                tip: "",
                darkColor: "#00BFBF",
                lightColor: "#00BFBF"
            },
            office: {
                name: "",
                tip: "",
                darkColor: "#3399FF",
                lightColor: "#3399FF"
            }
        },
        seriesTemplate: {
            type: "line",
            showSymbol: !1,
            itemStyle: {
                normal: {
                    borderWidth: 4
                }
            },
            lineStyle: {
                normal: {
                    width: 2
                }
            }
        },
        styleGuide: {
            FONT_FAMILY: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.FONT_FAMILY : "OpenSans, Microsoft JhengHei, sans-serif",
            COLOR_FONT_TIER1: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.COLOR_FONT_TIER1 : "#505A64",
            COLOR_FONT_TIER2: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.COLOR_FONT_TIER2 : "#505A64",
            COLOR_BORDER_TIER1: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.COLOR_BORDER_TIER1 : "rgba(198,212,224,0.9)",
            COLOR_BORDER_TIER2: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.COLOR_BORDER_TIER2 : "rgba(198,212,224,0.7)",
            COLOR_BORDER_TIER3: SYNO.SDS.CSTN.IsDSM7OrAbove() ? SYNO.SDS.CSTN.UIGuidelineStyle.COLOR_BORDER_TIER3 : "rgba(198,212,224,0.4)"
        }
    },
    constructor: function(e, t) {
        SYNO.SDS.CSTN.EchartsPanel.setting.repo.name = _STR("cstn", "historical_version"), SYNO.SDS.CSTN.EchartsPanel.setting.repo.tip = _STR("cstn", "historical_version_desc"), SYNO.SDS.CSTN.EchartsPanel.setting.database.name = _STR("cstn", "app_database"), SYNO.SDS.CSTN.EchartsPanel.setting.database.tip = _STR("cstn", "app_database_desc"), SYNO.SDS.CSTN.EchartsPanel.setting.office.name = _STR("cstn", "synology_office"), SYNO.SDS.CSTN.EchartsPanel.setting.office.tip = _STR("cstn", "synology_office_desc"), this.echartsPromise = t;
        var i = {
            border: !1,
            cls: "syno-cstn-database-panel-echarts"
        };
        this.echartsOption = {
            backgroundColor: "#FFFFFF",
            tooltip: {
                axis: "x",
                backgroundColor: "#FFFFFF",
                borderColor: SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_BORDER_TIER1,
                borderRadius: 3,
                borderWidth: 1,
                padding: [6, 10],
                transitionDuration: 0,
                trigger: "axis",
                confine: !0,
                axisPointer: {
                    lineStyle: {
                        color: [SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_BORDER_TIER1]
                    }
                },
                extraCssText: "box-shadow: 0px 2px 6px rgba(0, 0, 0, 0.1);",
                formatter: function(e) {
                    var t = e[0].axisValue,
                        i = '<div class="syno-cstn-usage-trend-tooltip">';
                    return i += '<div class="syno-cstn-usage-trend-tooltip-title">' + this.convertEpochTime(t) + ", " + new Date(t).getUTCFullYear() + "</div>", e.forEach(function(e) {
                        var t = e.seriesName,
                            n = e.data[1],
                            s = e.color;
                        i += '<div> <p class="syno-cstn-usage-trend-tooltip-left">' + t + _T("common", "colon") + '</p> <p class="syno-cstn-usage-trend-tooltip-right" style="color:' + s + '">' + this.formatSize(n) + "</p> </div> <br>"
                    }.bind(this)), i += "</div>"
                }.bind(this)
            },
            grid: {
                backgroundColor: "#FAFCFF",
                borderColor: SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_BORDER_TIER2,
                top: 10,
                bottom: 2,
                left: 18,
                right: 0,
                containLabel: !0
            },
            xAxis: {
                min: (new Date).getTime() - 2592e6,
                max: (new Date).getTime(),
                axisLine: {
                    show: !1
                },
                axisTick: {
                    show: !1
                },
                splitLine: !1,
                type: "time",
                boundaryGap: !1,
                axisLabel: {
                    color: SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_FONT_TIER1,
                    fontSize: 12,
                    fontFamily: SYNO.SDS.CSTN.EchartsPanel.styleGuide.FONT_FAMILY,
                    formatter: function(e) {
                        return this.convertEpochTime(parseInt(e))
                    }.bind(this),
                    showMaxLabel: !1
                }
            },
            yAxis: {
                type: "value",
                axisLine: {
                    show: !1
                },
                axisTick: {
                    show: !1
                },
                splitLine: {
                    lineStyle: {
                        color: [SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_BORDER_TIER3]
                    }
                },
                axisLabel: {
                    color: SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_FONT_TIER1,
                    fontSize: 12,
                    fontFamily: SYNO.SDS.CSTN.EchartsPanel.styleGuide.FONT_FAMILY,
                    formatter: function(e) {
                        return (parseInt(e) / this.yDivisor).toFixed(1)
                    }.bind(this)
                }
            },
            series: []
        }, this.echartsOption.series.push(this.getSeriesConfig("repo")), this.echartsOption.series.push(this.getSeriesConfig("database")), this.hasOffice = SYNO.SDS.CSTN.HasOffice(), this.hasOffice && this.echartsOption.series.push(this.getSeriesConfig("office")), this.yDivisor = 1, this.option = {
            title: {
                show: !0,
                textStyle: {
                    color: SYNO.SDS.CSTN.EchartsPanel.styleGuide.COLOR_FONT_TIER2,
                    fontSize: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 13 : 12,
                    fontWeight: "normal",
                    fontFamily: SYNO.SDS.CSTN.EchartsPanel.styleGuide.FONT_FAMILY
                },
                text: _STR("empty", "grid"),
                left: "center",
                top: "center"
            },
            xAxis: {
                show: !1
            },
            yAxis: {
                show: !1
            },
            series: []
        }, Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "afterlayout", function() {
            this.collapsed || this.drawChart()
        }, this), this.mon(this, "expand", function() {
            this.drawChart()
        }, this)
    },
    updateData: function(e, t) {
        this.option = this.echartsOption, this.yDivisor = Math.pow(1024, t), 1 === e.database.length && this.echartsOption.series.forEach(function(t) {
            1 === e.database.length ? t.showSymbol = !0 : t.showSymbol = !1
        }), this.echartsOption.series[0].data = e.repo, this.echartsOption.series[1].data = e.database, this.hasOffice && (this.echartsOption.series[2].data = e.office), this.drawChart()
    },
    drawChart: function() {
        this.echartsPromise.then(this._drawChart.bind(this)).catch()
    },
    _drawChart: function() {
        if (this.collapsed || this.isDestroyed) return !0;
        this.chartInstance || (this.chartInstance = echarts.init(this.body.dom)), this.chartInstance.resize(), this.chartInstance.setOption(this.option, !0)
    },
    convertEpochTime: function(e) {
        var t, i = "";
        return Ext.isNumber(e) ? (t = new Date(e), i += String.format(_STR("date", "month_day"), _STR("date", "mon_" + (t.getMonth() + 1)), t.getDate())) : i
    },
    formatSize: function(e) {
        for (var t = 0; e >= 1024;) t++, e /= 1024;
        return e.toFixed(1) + " " + SYNO.SDS.CSTN.GetFileSizeUnits()[t]
    },
    getSeriesConfig: function(e) {
        var t = JSON.parse(JSON.stringify(SYNO.SDS.CSTN.EchartsPanel.seriesTemplate));
        return t.name = SYNO.SDS.CSTN.EchartsPanel.setting[e].name, t.itemStyle.normal.color = SYNO.SDS.CSTN.EchartsPanel.setting[e].lightColor, t.lineStyle.normal.color = SYNO.SDS.CSTN.EchartsPanel.setting[e].darkColor, t
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PanelClient", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e);
        this.callParent([t]), this.getSelectionModel().on("rowselect", function(e) {
            0 === e.getCount() || this._S("demo_mode") || this.getTopToolbar().getComponent("btnUnlink").enable()
        }, this), this.getSelectionModel().on("rowdeselect", function(e) {
            0 === e.getCount() && this.getTopToolbar().getComponent("btnUnlink").disable()
        }, this), this.getStore().on("beforeload", function() {
            this.getTopToolbar().getComponent("btnUnlink").disable()
        }, this)
    },
    fillConfig: function(e) {
        var t;
        this.pageSize = 50, t = !this._S("is_admin");
        var i = [{
                id: "client_id",
                header: _STR("clientinfo", "title_id"),
                dataIndex: "client_id",
                align: "left",
                width: 150,
                sortable: !0
            }, {
                id: "client_name",
                header: _STR("common", "usrname"),
                dataIndex: "client_name",
                align: "left",
                hidden: t,
                width: 120,
                sortable: !0
            }, {
                id: "client_type",
                header: _STR("clientinfo", "client_type"),
                dataIndex: "client_type",
                align: "left",
                sortable: !0,
                width: 130,
                renderer: function(e) {
                    return {
                        drive: _STR("clientinfo", "client_drive"),
                        drive_backup: _STR("clientinfo", "client_drive"),
                        drive_mobile: _STR("clientinfo", "client_drive_mobile"),
                        backup: _STR("clientinfo", "client_backup"),
                        ds_cloud: _STR("clientinfo", "client_ds_cloud"),
                        cloudstation: _STR("clientinfo", "client_cloudstation"),
                        sharesync: _STR("clientinfo", "client_sharesync"),
                        serversync: _STR("clientinfo", "client_serversync"),
                        unknown: "--"
                    } [e]
                }
            }, {
                id: "login_time",
                header: _STR("clientinfo", "title_linktime"),
                dataIndex: "login_time",
                align: "left",
                renderer: function(e, t, i) {
                    return "off_line" == i.get("client_status") ? "" : SYNO.SDS.CSTN.RenderTime(e, t)
                },
                width: 130,
                sortable: !0
            }, {
                id: "client_status",
                header: _STR("clientinfo", "syncing_status"),
                dataIndex: "client_status",
                align: "left",
                renderer: function(e) {
                    return {
                        off_line: _STR("clientinfo", "disconnected"),
                        on_line: '<span class="green-status">' + _STR("clientinfo", "connected") + "</span>",
                        syncing: '<span class="blue-status">' + _STR("clientinfo", "syncing") + "</span>",
                        wipe: _STR("clientinfo", "wiped")
                    } [e]
                },
                width: 130,
                sortable: !0
            }, {
                id: "client_ip",
                header: _STR("clientinfo", "last_ip"),
                align: "left",
                dataIndex: "client_ip",
                width: 130,
                sortable: !0
            }, {
                id: "client_location",
                header: _STR("clientinfo", "client_location"),
                align: "left",
                dataIndex: "client_location",
                width: 130,
                sortable: !0
            }, {
                id: "client_session_id",
                dataIndex: "client_session_id",
                hidden: !0,
                sortable: !0
            }, {
                id: "client_is_relay",
                dataIndex: "client_is_relay",
                hidden: !0,
                sortable: !0
            }],
            n = new Ext.grid.ColumnModel({
                columns: i
            }),
            s = this.createStore(),
            o = new Ext.Toolbar;
        o.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnUnlink",
            text: _STR("clientinfo", "action_unlink"),
            handler: this.onDisconnect,
            scope: this
        }), o.add({
            xtype: "syno_button",
            ctCls: "syno-cstn-tab-btn",
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnRefres",
            text: _STR("btn", "refresh"),
            handler: this.onRefresh,
            scope: this
        }), o.add({
            xtype: "syno_button",
            ctCls: "syno-cstn-tab-btn",
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnKeyManagement",
            text: _STR("userkey", "userkey_titile"),
            handler: this.onClickKeyManagement,
            hidden: !0,
            scope: this
        });
        var a = new SYNO.ux.PagingToolbar({
                cls: "cstn-paging-toolbar",
                store: s,
                pageSize: this.pageSize,
                displayInfo: !0,
                owner: this
            }),
            r = {
                cls: "syno-cstn-panel-padding",
                itemId: "client",
                tbar: o,
                view: new SYNO.ux.FleXcroll.grid.GridView,
                stripeRows: !0,
                enableColLock: !1,
                enableHdMenu: !1,
                enableColumnMove: !1,
                colModel: n,
                ds: s,
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: !1
                }),
                autoExpandColumn: "login_time",
                loadMask: !0,
                bbar: a
            };
        return SYNO.LayoutConfig.fill(r), Ext.apply(r, e), r
    },
    createStore: function() {
        var e = ["client_id", "client_name", "login_time", "client_status", "client_session_id", "client_ip", "client_is_relay", "client_type", "client_version", "client_can_wipe", "client_location", "device_uuid"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Connection.api,
                    version: 1,
                    method: "list",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    idProperty: "id"
                }, e),
                sortInfo: {
                    field: "login_time",
                    direction: "DESC"
                },
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    offset: 0,
                    limit: this.pageSize,
                    sort_by: "login_time",
                    sort_direction: "DESC"
                },
                listeners: {
                    scope: this,
                    exception: function(e, t, i, n, s) {
                        s && s.code && this.owner.getMsgBox().alert(_STR("app", "app_name"), SYNO.SDS.CSTN.getErrorString(s))
                    }
                },
                remoteSort: !0
            });
        return this.addManagedComponent(t), t
    },
    applyDisconnect: function(e) {
        this.owner.setStatusBusy();
        var t = this.getSelectionModel().getSelections(),
            i = [];
        Ext.each(t, function(e) {
            i.push(e.get("client_session_id"))
        }), SYNO.SDS.CSTN.WebAPI.Connection.delete.call(this.owner, i, e, this.ajaxCheckSrvStatusCB, this)
    },
    ajaxCheckSrvStatusCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: SYNO.SDS.CSTN.cbLoad,
            failure: SYNO.SDS.CSTN.webapiErrHdlMain
        })
    },
    checkSrvStatus: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
    },
    onPageActivate: function() {
        this.checkSrvStatus()
    },
    onActivate: function() {
        this.onPageActivate()
    },
    onDisconnect: function() {
        this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "msg_confirmunlink"), function(e) {
            "yes" === e && this.applyDisconnect(!1)
        }, this)
    },
    onRefresh: function() {
        this.checkSrvStatus()
    },
    onClickKeyManagement: function() {
        new SYNO.SDS.CSTN.KeyManagement.MainWindow({
            owner: this.owner
        }).open()
    }
}), Ext.define("SYNO.SDS.CSTN.PanelSearch", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        }, this.dataRange = [
            [this.dateType.custom, _STR("log", "date_custom")],
            [this.dateType.today, _STR("log", "date_today")],
            [this.dateType.yesterday, _STR("log", "date_yesterday")],
            [this.dateType.lastweek, _STR("log", "date_lastweek")],
            [this.dateType.lastmonth, _STR("log", "date_lastmonth")]
        ], this.logType = SYNO.SDS.CSTN.LogType, this.logEvent = SYNO.SDS.CSTN.LogEvent, this.logDescEvent = [
            [this.logEvent.files, _STR("log", "log_event_files"), "log_files"],
            [this.logEvent.sharing, _STR("log", "log_event_sharing"), "log_sharing"],
            [this.logEvent.service, _STR("log", "log_event_service"), "log_service"],
            [this.logEvent.admin_action, _STR("log", "log_event_admin_action"), "log_admin_action"]
        ], this.logTypeTree = [{
            text: _STR("log", "log_event_files"),
            id: "log_event_files",
            children: [{
                text: _STR("log", "log_type_add_event"),
                id: "log_type_add_event",
                logType: this.logType.add_event
            }, {
                text: _STR("log", "log_type_remove_event"),
                id: "log_type_remove_event",
                logType: this.logType.remove_event
            }, {
                text: _STR("log", "log_type_modify_event"),
                id: "log_type_modify_event",
                logType: this.logType.modify_event
            }, {
                text: _STR("log", "log_type_rename_event"),
                id: "log_type_rename_event",
                logType: this.logType.rename_event
            }, {
                text: _STR("log", "log_type_version_rotate"),
                id: "log_type_version_rotate",
                logType: this.logType.version_rotate
            }, {
                text: _STR("log", "log_type_copy_event"),
                id: "log_type_copy_event",
                logType: this.logType.copy_event
            }, {
                text: _STR("log", "log_type_download_event"),
                id: "log_type_download_event",
                logType: this.logType.download_event
            }, {
                text: _STR("log", "log_type_preview_event"),
                id: "log_type_preview_event",
                logType: this.logType.preview_event
            }, {
                text: _STR("log", "log_type_restore_node"),
                id: "log_type_restore_node",
                logType: this.logType.restore_node
            }, {
                text: _STR("log", "log_type_delfile_forever"),
                id: "log_type_delfile_forever",
                logType: this.logType.delfile_forever
            }, {
                text: _STR("log", "log_type_share_save"),
                id: "log_type_share_save",
                logType: this.logType.share_save
            }, {
                text: _STR("log", "log_type_restore_a_copy_event"),
                id: "log_type_restore_a_copy_event",
                logType: this.logType.restore_a_copy_event
            }, {
                text: _STR("log", "log_type_delete_from_bin_event"),
                id: "log_type_delete_from_bin_event",
                logType: this.logType.delete_from_bin_event
            }, {
                text: _STR("log", "log_type_restore_from_bin_event"),
                id: "log_type_restore_from_bin_event",
                logType: this.logType.restore_from_bin_event
            }]
        }, {
            text: _STR("log", "log_event_sharing"),
            id: "log_event_sharing",
            children: [{
                text: _STR("log", "log_type_changed_link_perm"),
                id: "log_type_changed_link_perm",
                logType: this.logType.normal_link_permission
            }, {
                text: _STR("log", "log_type_save_adv_link"),
                id: "log_type_save_adv_link",
                logType: this.logType.adv_link_create
            }, {
                text: _STR("log", "log_type_allow_download_link"),
                id: "log_type_allow_download_link",
                logType: this.logType.normal_link_download
            }, {
                text: _STR("log", "log_type_allow_download_adv_link"),
                id: "log_type_allow_download_adv_link",
                logType: this.logType.adv_link_download
            }, {
                text: _STR("log", "log_type_set_pass_adv_link"),
                id: "log_type_set_pass_adv_link",
                logType: this.logType.adv_link_password
            }, {
                text: _STR("log", "log_type_set_expiration_adv_link"),
                id: "log_type_set_expiration_adv_link",
                logType: this.logType.adv_link_expiration
            }, {
                text: _STR("log", "log_type_set_invitee_link"),
                id: "log_type_set_invitee_link",
                logType: this.logType.normal_link_invitee
            }]
        }, {
            text: _STR("log", "log_event_service"),
            id: "log_event_service",
            children: [{
                text: _STR("log", "log_type_drive_save"),
                id: "log_type_drive_save",
                logType: this.logType.cloudstn_save
            }, {
                text: _STR("log", "log_type_client_link"),
                id: "log_type_client_link",
                logType: this.logType.client_link
            }, {
                text: _STR("log", "log_type_client_unlink"),
                id: "log_type_client_unlink",
                logType: this.logType.client_unlink
            }]
        }, {
            text: _STR("log", "log_event_admin_action"),
            id: "log_event_admin_action",
            children: [{
                text: _STR("log", "log_type_rotate_set"),
                id: "log_type_rotate_set",
                logType: this.logType.rotate_set
            }, {
                text: _STR("log", "log_type_volume_set"),
                id: "log_type_volume_set",
                logType: this.logType.volume_set
            }, {
                text: _STR("log", "log_type_log_rotate_cnt_set"),
                id: "log_type_log_rotate_cnt_set",
                logType: this.logType.log_rotate_cnt_set
            }, {
                text: _STR("log", "log_type_log_rotate_span_set"),
                id: "log_type_log_rotate_span_set",
                logType: this.logType.log_rotate_span_set
            }, {
                text: _STR("log", "log_type_log_delete"),
                id: "log_type_log_delete",
                logType: this.logType.log_delete
            }, {
                text: _STR("log", "log_type_priv_save"),
                id: "log_type_priv_save",
                logType: this.logType.priv_save
            }, {
                text: _STR("log", "log_type_log_export"),
                id: "log_type_log_export",
                logType: this.logType.log_export
            }, {
                text: _STR("log", "log_type_rotate_policy"),
                id: "log_type_rotate_policy",
                logType: this.logType.log_rotate_policy
            }, {
                text: _STR("log", "log_type_delfile_recyclebin"),
                id: "log_type_delfile_recyclebin",
                logType: this.logType.delfile_recyclebin
            }, {
                text: _STR("log", "log_type_transfer_ownership"),
                id: "log_type_transfer_ownership",
                logType: this.logType.ownship_transfer
            }]
        }], this.defaultAnimation = ["#000", 1, {
            duration: .35
        }], Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function() {
        var e, t, i, n, s = [];
        e = this.createKeyword(), UserName = this.createUserName(), IpAddress = this.createIpAddress(), t = this.createFriendlyDate(), i = this.createCustDate(), n = this.createType(), s.push(e), s.push(UserName), s.push(IpAddress), s.push(t), s.push(i), s.push(n);
        var o = {
                xtype: "toolbar",
                border: !1,
                itemId: "btns",
                toolbarCls: "search-panel-fbar-btnPanel",
                items: [{
                    xtype: "tbfill"
                }]
            },
            a = [{
                xtype: "syno_button",
                btnStyle: "blue",
                style: "margin-right: 10px",
                text: _T("log", "search"),
                itemId: "btn_search",
                handler: this.onSearch,
                scope: this
            }, {
                xtype: "syno_button",
                minWidth: 80,
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }];
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && a.reverse(), o.items.push.apply(o.items, a), s.push(o), {
            width: 368,
            heigh: 480,
            floating: !0,
            labelAlign: "left",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            border: !0,
            bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 16px 24px 16px 24px; font-size: 24px;" : "padding: 20px; padding-top: 0px; font-size: 24px;",
            autoFlexcroll: !1,
            defaults: {
                hideLabel: !0,
                anchor: "100%"
            },
            items: s
        }
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "keyword",
            flex: 2,
            value: ""
        }]
    },
    createUserName: function() {
        return [{
            xtype: "syno_displayfield",
            value: _STR("common", "user") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "username",
            flex: 2,
            value: ""
        }]
    },
    createIpAddress: function() {
        return [{
            xtype: "syno_displayfield",
            value: _STR("clientinfo", "last_ip") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "ipaddress",
            flex: 2,
            value: "",
            vtype: "v4ip"
        }]
    },
    setDate: function(e, t, i) {
        !0 === i && (this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation), this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)), this.form.findField("searchdatefrom").setMaxValue(t), this.form.findField("searchdateto").setMinValue(e), this.form.findField("searchdatefrom").setValue(e), this.form.findField("searchdateto").setValue(t)
    },
    getFromToDate: function(e) {
        var t, i, n = new Date;
        if (e === this.dateType.today) t = n, i = n;
        else if (e === this.dateType.yesterday) t = n.add(Date.DAY, -1), i = t;
        else if (e === this.dateType.lastweek) {
            var s = n.getDay();
            t = n.add(Date.DAY, -7 - s), i = t.add(Date.DAY, 6)
        } else e === this.dateType.lastmonth && (n = n.add(Date.MONTH, -1), t = n.getFirstDateOfMonth(), i = n.getLastDateOfMonth());
        return {
            from: t,
            to: i
        }
    },
    friendlyDateSelect: function(e, t) {
        var i = t.get("id"),
            n = this.getFromToDate(i);
        this.setDate(n.from, n.to, !0)
    },
    getFriendlyDateStore: function() {
        var e = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["id", "displayText"],
            data: e
        })
    },
    createFriendlyDate: function() {
        return this.FriendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: !1,
            name: "dateRange",
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforeselect: this.friendlyDateSelect
            }
        }), [{
            xtype: "syno_displayfield",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        return this.DateFrom = {
            xtype: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "syno_datetimefield" : "syno_datefield",
            name: "searchdatefrom",
            editable: !1,
            format: SYNO.SDS.CSTN.getDateFormat(),
            emptyText: _T("log", "date_from"),
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdateto").setMinValue(t)
                }
            }
        }, this.DateTo = {
            xtype: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "syno_datetimefield" : "syno_datefield",
            name: "searchdateto",
            editable: !1,
            format: SYNO.SDS.CSTN.getDateFormat(),
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdatefrom").setMaxValue(t)
                }
            }
        }, [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: !0,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    createType: function() {
        this.logTypeBtn = new SYNO.ux.Button({
            text: _STR("log", "log_title_all"),
            cls: "syno-cstn-type-btn",
            menu: this.getTypeMenu(),
            tooltip: "",
            listeners: {
                menushow: this.onClickTypeBtn,
                menuhide: this.onCloseTypeMenu,
                scope: this
            }
        });
        var e = SYNO.SDS.CSTN.IsDSM7OrAbove() ? 320 : 328,
            t = SYNO.SDS.CSTN.IsDSM7OrAbove() ? [0, 1] : [0, 0];
        return this.logTypeBtn.menu.setWidth(e), this.logTypeBtn.menu.defaultOffsets = t, [{
            xtype: "syno_displayfield",
            name: "logTypeLabel",
            value: _STR("log", "log_type") + _T("common", "colon"),
            flex: 1
        }, this.logTypeBtn]
    },
    onClickTypeBtn: function() {
        this.logTypeBtn.addClass("syno-cstn-type-btn-clicked")
    },
    onCloseTypeMenu: function(e, t) {
        var i = this.generateTypeString(this.getLogTypeValue());
        this.frameAnimation(this.logTypeBtn.getEl(), this.defaultAnimation), this.logTypeBtn.removeClass("syno-cstn-type-btn-clicked"), this.logTypeBtn.setTooltip(i), this.logTypeBtn.setText(this.doTrimString(i))
    },
    doTrimString: function(e) {
        var t = document.createElement("canvas"),
            i = t.getContext("2d"),
            n = SYNO.SDS.CSTN.IsDSM7OrAbove() ? 260 : 246;
        i.font = SYNO.SDS.CSTN.IsDSM7OrAbove() ? "13px OpenSans" : "12px Arial";
        for (var s = 20; s < e.length; ++s) {
            var o = e.substr(0, s) + "...";
            if (i.measureText(o).width > n) return o
        }
        return e
    },
    onResetType: function() {
        Ext.each(this.logTypeBtn.menu.items.items, function(e) {
            e.menu && e.menu.onReset()
        }), this.logTypeBtn.setText(_STR("log", "log_title_all"))
    },
    getLogTypeValue: function() {
        var e = [];
        return Ext.each(this.logTypeBtn.menu.items.items, function(t) {
            t.menu && (e = e.concat(t.menu.getLogType()))
        }), e
    },
    getTypeMenu: function() {
        var e = [{
            cls: "syno-cstn-type-menu-item",
            text: _STR("log", "log_title_all"),
            listeners: {
                click: function() {
                    this.onResetType()
                },
                scope: this
            }
        }, {
            xtype: "menuseparator"
        }];
        return Ext.each(this.logTypeTree, function(t) {
            var i = {
                text: t.text,
                id: t.id,
                cls: "syno-cstn-type-menu-item",
                menu: new SYNO.SDS.CSTN.TriCheckboxMenu({
                    children: t.children
                }),
                listeners: {
                    click: function() {
                        return !1
                    },
                    scope: this
                }
            };
            e.push(i)
        }, this), e
    },
    frameAnimation: function(e, t) {
        e && e.isVisible() && Ext.Element.prototype.frame.apply(e, t)
    },
    setKeyWord: function(e) {
        var t = this.form.findField("keyword");
        t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
    },
    setUsername: function(e) {
        var t = this.form.findField("username");
        t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
    },
    setTypes: function(e) {
        Ext.each(this.logTypeBtn.menu.items.items, function(t) {
            t.menu && t.menu.setPreConfigLogType(e)
        }, this);
        var t = this.generateTypeString(e);
        this.logTypeBtn.setTooltip(t), this.logTypeBtn.setText(this.doTrimString(t))
    },
    generateTypeString: function(e) {
        var t = [];
        return Ext.each(this.logTypeTree, function(i) {
            Ext.each(i.children, function(i) {
                -1 != e.indexOf(i.logType) && t.push(i.text)
            })
        }), 0 == t.length ? _STR("log", "log_title_all") : t.join(", ")
    },
    onSearch: function() {
        if (this.getForm().findField("ipaddress").isValid()) {
            var e, t, i, n, s, o, a, r, l;
            e = this.getForm(), t = e.findField("keyword").getValue(), i = e.findField("username").getValue(), n = !!t && !!_STR("common", "system").match(new RegExp(t, "i")), n = n || !!i && !!_STR("common", "system").match(new RegExp(i, "i")), s = e.findField("ipaddress").getValue(), o = e.findField("searchdatefrom"), a = e.findField("searchdateto"), r = this.getLogTypeValue().sort(), l = {
                keyword: t,
                username: i,
                username_include_system: n,
                ipaddress: s,
                datefrom: o.getRawValue() ? Date.parseDate(o.getRawValue() + " 00:00:00", o.format + " H:i:s").getTime() / 1e3 : 0,
                dateto: a.getRawValue() ? Date.parseDate(a.getRawValue() + " 23:59:59", a.format + " H:i:s").getTime() / 1e3 : 0,
                log_type: r
            }, this.fireEvent("search", this, l)
        }
    },
    onReset: function() {
        this.form.items.each(function(e) {
            e.isDirty() && this.frameAnimation(e.el, this.defaultAnimation)
        }, this), this.form.reset(), this.onResetType(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null)
    },
    isWithInLogTypeMenu: function(e) {
        if (e.within(this.logTypeBtn.menu.getEl())) return !0;
        var t = !1;
        return Ext.each(this.logTypeBtn.menu.items.items, function(i) {
            if (i.menu && i.menu.isWithIn(e)) return t = !0, !1
        }), t
    }
}), Ext.define("SYNO.SDS.CSTN.TriCheckboxMenu", {
    extend: "SYNO.ux.Menu",
    constructor: function(e) {
        this.callParent([this.fillConfig(e.children || {})]), this.children = [];
        for (var t = 2; t < this.items.length; ++t) this.children.push(this.get(t));
        this.preConfigLogTypeArray = [], this.logTypeArray = [], this.initEvent()
    },
    fillConfig: function(e) {
        var t = [this.triCheckbox = new SYNO.ux.TriModeCheckbox({
            boxLabel: _STR("log", "log_event_all"),
            name: "log_event_all",
            isChild: !1,
            value: !1,
            triMode: !0
        }), {
            xtype: "menuseparator"
        }];
        return e.length && Ext.each(e, function(e) {
            e.isChild = !0, e.xtype = "syno_checkbox", e.boxLabel = e.boxLabel ? e.boxLabel : e.text, t.push(e)
        }), {
            xtype: "menuitem",
            cls: "syno-cstn-log-type-submenu",
            items: t,
            listeners: {
                beforeshow: this.onMenuBeforeShow,
                scope: this
            }
        }
    },
    initEvent: function() {
        this.mon(this.triCheckbox, "check", this.onUpdateChecked, this), Ext.each(this.children, function(e) {
            this.mon(e, "check", this.onUpdateChecked, this)
        }, this)
    },
    updateParent: function() {
        if (this.triCheckbox.checkIcon) {
            var e = 0,
                t = [];
            Ext.each(this.children, function(i) {
                i.getValue() && (t.push(i.logType), e += 1)
            }), this.logTypeArray = t, this.triCheckbox.suspendEvents(!1), e === this.children.length ? this.triCheckbox.setValue(!0) : e > 0 ? this.triCheckbox.setValue(null) : this.triCheckbox.setValue(!1), this.triCheckbox.resumeEvents()
        }
    },
    updateChildren: function(e) {
        var t = [];
        Ext.each(this.children, function(i) {
            e && t.push(i.logType), i.suspendEvents(!1), i.setValue(e), i.resumeEvents()
        }), this.logTypeArray = t
    },
    onUpdateChecked: function(e, t) {
        e.isChild ? this.updateParent() : null === t ? e.setValue(!1) : this.updateChildren(t)
    },
    onReset: function() {
        this.preConfigLogTypeArray = [], this.logTypeArray = [], this.updateChildren(!1), this.updateParent()
    },
    onMenuBeforeShow: function() {
        0 != this.preConfigLogTypeArray.length && (this.logTypeArray = [], Ext.each(this.children, function(e) {
            var t = -1 != this.preConfigLogTypeArray.indexOf(e.logType);
            e.suspendEvents(!1), e.setValue(t), e.resumeEvents(), this.logTypeArray.push(e.logType)
        }, this), this.updateParent(), this.preConfigLogTypeArray = [])
    },
    setPreConfigLogType: function(e) {
        this.preConfigLogTypeArray = [], Ext.each(this.children, function(t) {
            -1 != e.indexOf(t.logType) && this.preConfigLogTypeArray.push(t.logType)
        }, this)
    },
    getLogType: function() {
        return 0 != this.preConfigLogTypeArray.length ? this.preConfigLogTypeArray : this.logTypeArray
    },
    isWithIn: function(e) {
        return e.within(this.getEl())
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.ns("SYNO.SDS.CSTN.LOG"), SYNO.SDS.CSTN.LOG.LOG_PAGE_LIMIT = 1e3, SYNO.SDS.CSTN.LOG.CLIENT_COL_WIDTH = 120, SYNO.SDS.CSTN.LOG.LOG_COL_WIDTH = 592, SYNO.SDS.CSTN.LOG.USER_COL_WIDTH = 100, SYNO.SDS.CSTN.LOG.TIME_COL_WIDTH = 200, SYNO.SDS.CSTN.LOG.EVENT_COL_WIDTH = 200, SYNO.SDS.CSTN.LOG.IP_COL_WIDTH = 100, Ext.define("SYNO.SDS.CSTN.PanelLog", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    initEvents: function() {
        this.callParent(), this.mon(this.searchPanel, "search", this.onSearch, this, {
            buffer: this.searchBuffer
        }), this.mon(this, "beforedestroy", function() {
            this.searchPanel.destroy()
        }, this)
    },
    fillConfig: function(e) {
        this.pageSize = SYNO.SDS.CSTN.LOG.LOG_PAGE_LIMIT;
        var t = [{
                id: "client_type",
                header: _STR("clientinfo", "client_type"),
                dataIndex: "client_type",
                align: "left",
                renderer: function(e, t) {
                    return SYNO.SDS.CSTN.RenderClientType(e, t)
                },
                width: SYNO.SDS.CSTN.LOG.CLIENT_COL_WIDTH
            }, {
                id: "log",
                header: _STR("func", "mgr_log"),
                dataIndex: "log",
                align: "left",
                renderer: function(e, t, i, n) {
                    return i.ridx = n, SYNO.SDS.CSTN.RenderLog(i)
                },
                width: SYNO.SDS.CSTN.LOG.LOG_COL_WIDTH
            }, {
                id: "user",
                header: _STR("common", "user"),
                dataIndex: "username",
                align: "left",
                hidden: !0,
                renderer: function(e, t) {
                    return SYNO.SDS.CSTN.RenderUserName(e, t)
                },
                width: SYNO.SDS.CSTN.LOG.USER_COL_WIDTH
            }, {
                id: "time",
                header: _STR("common", "time"),
                dataIndex: "time",
                align: "left",
                renderer: function(e, t) {
                    return SYNO.SDS.CSTN.RenderTime(e, t)
                },
                width: SYNO.SDS.CSTN.LOG.TIME_COL_WIDTH
            }, {
                id: "event",
                header: _STR("log", "log_event_type"),
                dataIndex: "type",
                align: "left",
                hidden: !0,
                renderer: function(e, t) {
                    return SYNO.SDS.CSTN.RenderEventType(e, t)
                },
                width: SYNO.SDS.CSTN.LOG.EVENT_COL_WIDTH
            }, {
                id: "ip_address",
                header: _STR("clientinfo", "last_ip"),
                dataIndex: "ip_address",
                align: "left",
                hidden: !0,
                renderer: function(e, t) {
                    return SYNO.SDS.CSTN.RenderIPAddress(e, t)
                },
                width: SYNO.SDS.CSTN.LOG.IP_COL_WIDTH
            }],
            i = new Ext.grid.ColumnModel({
                columns: t
            }),
            n = this.createStore();
        this.ds_share = new Ext.data.JsonStore({
            fields: ["share_name", "share_type"],
            data: [{
                share_name: _STR("log", "log_title_all"),
                share_type: "all"
            }]
        }), this.searchPanel = new SYNO.SDS.CSTN.PanelSearch({
            itemId: "search",
            cls: "syno-cstn-search-panel syno-cstn-search-log-panel",
            renderTo: Ext.getBody(),
            shadow: !1,
            jsConfig: this.owner.jsConfig,
            hidden: !0,
            owner: this
        }), this.findField = new SYNO.SDS.CSTN.AdvancedSearchField({
            iconStyle: "filter",
            owner: this
        }), this.findField.searchPanel = this.searchPanel, this.selected_index = 0, this.combo_share = new SYNO.ux.ComboBox({
            ctCls: "syno-cstn-grid syno-cstn-grid-combo",
            name: "combo_share",
            mode: "local",
            hideLabel: !1,
            editable: !1,
            store: this.ds_share,
            displayField: "share_name",
            valueField: "share_name",
            triggerAction: "all",
            value: "all",
            hidden: !1,
            listeners: {
                scope: this,
                select: function(e, t, i) {
                    this.selected_index = i, this.getStore().load()
                }
            }
        });
        var s = new Ext.Toolbar({
            cls: "syno-cstn-log-toolbar"
        });
        s.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            text: _STR("btn", "btn_export"),
            handler: this.onExportBtnClicked,
            scope: this
        }), s.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            text: _STR("common", "setting"),
            handler: this.onSettingsBtnClicked,
            scope: this
        }), s.add("->"), s.add(this.combo_share), s.add(this.findField), SYNO.SDS.CSTN.IsDSM7OrAbove() || s.add(" ");
        var o = new SYNO.ux.PagingToolbar({
                cls: "cstn-paging-toolbar",
                store: n,
                pageSize: this.pageSize,
                displayInfo: !0,
                displayMsg: "",
                moveLast: function() {
                    this.store.setBaseParam("get_all", !0), this.store.load()
                },
                listeners: {
                    change: function() {
                        var e = Math.floor(this.store.totalLength / this.pageSize);
                        this.store.totalLength % this.pageSize != 0 && e++;
                        var t = this.getPageData().pages;
                        !0 === this.store.baseParams.get_all && (this.setFocusPage(e), this.cursor = (e - 1) * this.pageSize, this.first.setDisabled(1 == e), this.prev.setDisabled(1 == e), this.next.setDisabled(e == t), this.last.setDisabled(e == t), this.store.setBaseParam("get_all", !1))
                    }
                }
            }),
            a = {
                cls: "syno-cstn-panel-padding",
                itemId: "log",
                tbar: s,
                view: new SYNO.ux.FleXcroll.grid.GridView({
                    listeners: {
                        refresh: {
                            scope: this,
                            fn: function() {
                                Ext.select(".syno-cstn-log-filename-exist").on("click", function(e, t) {
                                    t = Ext.get(t);
                                    var i = t.getAttribute("data-open-type"),
                                        n = t.getAttribute("data-path"),
                                        s = t.getAttribute("data-file-type");
                                    if ("version" == i) {
                                        var o = t.getAttribute("data-node-id"),
                                            a = t.getAttribute("data-target");
                                        "0" === s && o && this.showDialogVersion(a, n, o)
                                    } else "1" === s ? SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                                        opendir: n
                                    }, !0) : SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                                        openfile: n
                                    }, !0)
                                }, this)
                            }
                        }
                    }
                }),
                stripeRows: !0,
                enableColLock: !1,
                enableHdMenu: !0,
                enableColumnMove: !1,
                colModel: i,
                ds: n,
                autoExpandColumn: "log",
                loadMask: !0,
                bbar: o,
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: !1
                }),
                listeners: {
                    rowdblclick: {
                        fn: this.rowDoubleClick,
                        scope: this
                    }
                }
            };
        return SYNO.LayoutConfig.fill(a), Ext.apply(a, e), a
    },
    canShowVer: function(e) {
        var t = String(e.get("type")),
            i = SYNO.SDS.CSTN.LogType;
        return (t == i.restore_node || t == i.add_event || t == i.remove_event || t == i.modify_event || t == i.version_rotate || t == i.rename_event) && "" !== e.get("p1")
    },
    rowDoubleClick: function(e, t) {
        var i = this.getStore().getAt(t);
        this.canShowVer(i) && this.showDialogVersion(i.get("target"), i.get("s1"), i.get("p1"))
    },
    showDialogVersion: function(e, t, i) {
        if (!SYNO.SDS.Drive.Extension.Instance.isOfficeFile(t)) {
            var n = new SYNO.SDS.CSTN.DialogVersion({
                    owner: this.owner
                }),
                s = {
                    target: e,
                    nodeid: i,
                    filename: t.substring(t.lastIndexOf("/") + 1),
                    path: "@" == t.charAt(0) ? t.substring(1) : t,
                    file_type: 0,
                    is_removed: !1
                };
            n.winShow(s)
        }
    },
    createStore: function() {
        var e = ["type", "username", "username_include_system", "target", "share_name", "share_type", "time", "accessable", "filestation_link_prefix", "s1", "s2", "s3", "s4", "s5", "p1", "p2", "p3", "p4", "p5", "target_share_name", "target_share_type", "target_accessable", "target_link_prefix", "client_type", "ip_address"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Log.api,
                    version: 1,
                    method: "list",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    idProperty: "id"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    share_type: "all",
                    offset: 0,
                    limit: this.pageSize,
                    get_all: !1
                },
                listeners: {
                    scope: this,
                    beforeload: function() {
                        var e = this.combo_share.getStore().getAt(this.selected_index);
                        this.getStore().setBaseParam("share_type", e.get("share_type")), "share" == e.get("share_type") ? this.getStore().setBaseParam("target", "@" + e.get("share_name")) : this.getStore().setBaseParam("target", "user")
                    }
                }
            });
        return this.addManagedComponent(t), t
    },
    getShareCombo: function() {
        SYNO.SDS.CSTN.WebAPI.Share.listActive.call(this.owner, {
            exclude_home: !0
        }, function(e, t, i, n) {
            if (e) {
                for (var s = [{
                        share_name: _STR("log", "log_title_all"),
                        share_type: "all"
                    }], o = 0; o < t.total; o++) s = "home" == t.items[o].type ? s.concat([{
                    share_name: _STR("category", "node"),
                    share_type: t.items[o].type
                }]) : s.concat([{
                    share_name: t.items[o].name,
                    share_type: t.items[o].type
                }]);
                this.ds_share.loadData(s)
            }
            SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
                success: this.listActiveCallback,
                failure: SYNO.SDS.CSTN.webapiErrHdlMain
            })
        }, this)
    },
    listActiveCallback: function() {
        this.loadPreConfigAndSearch()
    },
    clearSearchParam: function() {
        var e = {
            keyword: "",
            datefrom: 0,
            dateto: 0,
            log_type: []
        };
        Ext.apply(this.getStore().baseParams, e), this.combo_share.setValue(_STR("log", "log_title_all")), this.selected_index = 0, this.searchPanel.onReset(), this.findField.setValue("")
    },
    onSearch: function(e, t) {
        e.hide(), Ext.apply(this.getStore().baseParams, t), this.getStore().load()
    },
    onPageActivate: function() {
        this.clearSearchParam(), this.owner.setStatusBusy(), this.getShareCombo()
    },
    loadPreConfigAndSearch: function() {
        var e = this.owner.fetchPreConfig();
        e && (this.searchPanel.setKeyWord(e.keyword ? e.keyword : ""), this.searchPanel.setUsername(e.username ? e.username : ""), this.searchPanel.setTypes(e.types ? e.types : [])), this.searchPanel.onSearch()
    },
    onDeactivate: function() {},
    onActivate: function() {
        this.onPageActivate()
    },
    onExportBtnClicked: function() {
        var e = this.combo_share.selectedIndex;
        e = -1 === e ? 0 : e;
        var t = this.combo_share.store.getAt(e).data;
        this.owner.downloadWebAPI({
            webapi: {
                api: "SYNO.SynologyDrive.Log",
                version: 1,
                method: "export",
                params: {
                    type: "csv",
                    target: "all" === t.share_type ? "" : t.share_name
                }
            }
        })
    },
    onSettingsBtnClicked: function() {
        new SYNO.SDS.CSTN.DialogLogSettings({
            owner: this.owner,
            logPanel: this
        }).open()
    },
    reloadLogs: function() {
        this.getStore().reload()
    }
}), Ext.define("SYNO.SDS.CSTN.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(this, "keypress", function(e, t) {
            t.getKey() == Ext.EventObject.ENTER && (this.searchPanel.setKeyWord(this.getValue()), this.searchPanel.onSearch())
        }, this)
    },
    isInnerComponent: function(e, t) {
        var i = !1;
        return t.items.each(function(t) {
            if (t instanceof Ext.form.ComboBox) {
                if (t.view && e.within(t.view.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.DateField) {
                if (t instanceof SYNO.ux.DateTimeField) {
                    if (t.isWithinEl(e)) return i = !0, !1
                } else if (t.menu && e.within(t.menu.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.CompositeField && this.isInnerComponent(e, t)) return i = !0, !1
        }, this), i
    },
    onMouseDown: function(e) {
        var t = this.searchPanel;
        !t || !t.isVisible() || t.isDestroyed || t.inEl || e.within(t.getEl()) || t.attriWin && t.attriWin.isVisible() || e.within(this.searchtrigger) || this.isInnerComponent(e, t.getForm()) || t.isWithInLogTypeMenu(e) || t.hide()
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) return void this.searchPanel.hide();
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", SYNO.SDS.CSTN.IsDSM7OrAbove() ? [0, 1] : [6, 0]), this.searchPanel.show(), this.getValue() && this.getValue().length > 0 && this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent(), this.searchPanel.onReset(), this.searchPanel.onSearch()
    }
}), Ext.define("SYNO.SDS.CSTN.DialogLogSettings", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.win = e.owner, this.logPanel = e.logPanel;
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "commit"),
                itemId: "apply",
                id: this.BtnApplyId = Ext.id(),
                scope: this,
                handler: this.onSave
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "cancel"),
                itemId: "cancel",
                id: this.BtnCancelId = Ext.id(),
                scope: this,
                handler: this.onCancel
            }]
        };
        SYNO.SDS.CSTN.IsDSM7OrAbove() && t.items.reverse(), this.settingForm = new SYNO.SDS.CSTN.LogSettingsForm({
            owner: this,
            module: this.module,
            logPanel: this.logPanel
        }), this.callParent([Ext.apply({
            itemId: "log_setting_editor",
            title: SYNO.SDS.CSTN.IsDSM7OrAbove() ? _STR("log", "log_delete_rule_title") : _STR("cstn", "log_settings"),
            width: 600,
            height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 280 : 300,
            resizable: !1,
            autoScroll: !0,
            layout: "fit",
            items: [this.settingForm],
            fbar: t
        }, e)])
    },
    onShow: function() {
        this.loadForm()
    },
    onCancel: function() {
        this.close()
    },
    onSave: function() {
        this.settingForm.isDirty() ? this.settingForm.save(this.onSaveCallback.bind(this)) : this.close()
    },
    loadForm: function() {
        this.settingForm.loadForm()
    },
    onSaveCallback: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.onSaveSuccess.bind(this),
            failure: SYNO.SDS.CSTN.webapiHdl
        })
    },
    onSaveSuccess: function() {
        this.owner.getMsgBox().alert(_STR("app", "app_name"), _T("common", "setting_applied")), this.close()
    }
}), Ext.define("SYNO.SDS.CSTN.LogSettingsForm", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.logPanel = e.logPanel;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        return SYNO.SDS.CSTN.IsDSM7OrAbove() ? this.fillConfigDSM7() : this.fillConfigDSM6()
    },
    fillConfigDSM6: function(e) {
        var t = {
            border: !1,
            plain: !0,
            itemId: "configure",
            items: [{
                xtype: "syno_fieldset",
                title: _STR("log", "log_delete_rule_title"),
                collapsible: !1,
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("log", "log_delete_rule_desc")
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [{
                        xtype: "syno_checkbox",
                        boxLabel: _STR("log", "log_delete_by_count"),
                        width: 220,
                        name: "use_del_by_cnt"
                    }, {
                        xtype: "syno_combobox",
                        name: "del_cnt",
                        width: 200,
                        mode: "local",
                        value: 1e6,
                        editable: !1,
                        store: this.storeLogDelCntGet(),
                        forceSelection: !0,
                        displayField: "display",
                        valueField: "value",
                        typeAhead: !0,
                        triggerAction: "all",
                        lazyRender: !0
                    }]
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [{
                        xtype: "syno_checkbox",
                        boxLabel: _STR("log", "log_delete_by_time"),
                        width: 220,
                        name: "use_del_by_span"
                    }, {
                        xtype: "syno_combobox",
                        name: "del_span",
                        width: 200,
                        mode: "local",
                        value: 2,
                        editable: !1,
                        store: this.storeLogDelTimeGet(),
                        forceSelection: !0,
                        displayField: "display",
                        valueField: "value",
                        typeAhead: !0,
                        triggerAction: "all",
                        lazyRender: !0
                    }]
                }, {
                    xtype: "syno_button",
                    disabled: this._S("demo_mode"),
                    tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    text: _STR("log", "log_delete_all_logs"),
                    scope: this,
                    handler: this.onDeleteLog
                }]
            }]
        };
        return SYNO.LayoutConfig.fill(t), Ext.apply(t, e), t
    },
    fillConfigDSM7: function(e) {
        var t = {
            border: !1,
            plain: !0,
            padding: 0,
            itemId: "configure",
            items: [{
                xtype: "syno_displayfield",
                value: _STR("log", "log_delete_rule_desc")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: _STR("log", "log_delete_by_count"),
                    width: 240,
                    name: "use_del_by_cnt"
                }, {
                    xtype: "syno_combobox",
                    name: "del_cnt",
                    width: 220,
                    mode: "local",
                    value: 1e6,
                    editable: !1,
                    store: this.storeLogDelCntGet(),
                    forceSelection: !0,
                    displayField: "display",
                    valueField: "value",
                    typeAhead: !0,
                    triggerAction: "all",
                    lazyRender: !0
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: _STR("log", "log_delete_by_time"),
                    width: 240,
                    name: "use_del_by_span"
                }, {
                    xtype: "syno_combobox",
                    name: "del_span",
                    width: 220,
                    mode: "local",
                    value: 2,
                    editable: !1,
                    store: this.storeLogDelTimeGet(),
                    forceSelection: !0,
                    displayField: "display",
                    valueField: "value",
                    typeAhead: !0,
                    triggerAction: "all",
                    lazyRender: !0
                }]
            }, {
                xtype: "syno_button",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _STR("log", "log_delete_all_logs"),
                scope: this,
                handler: this.onDeleteLog
            }]
        };
        return SYNO.LayoutConfig.fill(t), Ext.apply(t, e), t
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "afterlayout", function() {
            var e = this.getForm();
            new SYNO.SDS.Utils.EnableCheckGroup(e, "use_del_by_cnt", ["del_cnt"]), new SYNO.SDS.Utils.EnableCheckGroup(e, "use_del_by_span", ["del_span"])
        }, this, {
            single: !0
        })
    },
    loadForm: function() {
        this.owner.setStatusBusy(), this.sendWebAPI({
            api: SYNO.SDS.CSTN.WebAPI.Config.api,
            method: "get",
            version: 1,
            callback: function(e, t, i, n) {
                SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
                    success: this.fillForm,
                    failure: SYNO.SDS.CSTN.webapiErrHdlMain
                })
            },
            scope: this
        })
    },
    fillForm: function(e) {
        this.getForm().setValues(e)
    },
    storeLogDelCntGet: function() {
        return new Ext.data.SimpleStore({
            autoDestroy: !0,
            fields: ["value", "display"],
            data: SYNO.SDS.CSTN.getMaxLogCountOptions()
        })
    },
    storeLogDelTimeGet: function() {
        return new Ext.data.SimpleStore({
            autoDestroy: !0,
            fields: ["value", "display"],
            data: SYNO.SDS.CSTN.getLogSpanOptions()
        })
    },
    reloadLogPanel: function() {
        this.logPanel.reloadLogs()
    },
    deleteLogCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.reloadLogPanel.bind(this),
            failure: this.reloadLogPanel.bind(this)
        })
    },
    onDeleteLog: function() {
        this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("log", "log_delete_all_logs_confirm"), function(e) {
            "yes" === e && (this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.Log.delete.call(this.owner, this.deleteLogCB, this))
        }, this)
    },
    save: function(e) {
        var t = this.getForm().findField("use_del_by_cnt"),
            i = this.getForm().findField("del_cnt"),
            n = this.getForm().findField("use_del_by_span"),
            s = this.getForm().findField("del_span");
        this.sendWebAPI({
            api: SYNO.SDS.CSTN.WebAPI.Config.api,
            method: "set",
            version: 1,
            params: {
                use_del_by_cnt: t.getValue(),
                del_cnt: i.getValue(),
                use_del_by_span: n.getValue(),
                del_span: s.getValue()
            },
            callback: e,
            scope: this
        })
    },
    isDirty: function() {
        return this.getForm().isDirty()
    }
}), Ext.ns("SYNO.SDS.CSTN.SHARING"), SYNO.SDS.CSTN.SHARING.STATUS_COL_WIDTH = 150, SYNO.SDS.CSTN.SHARING.ROTATE_COL_WIDTH = 150, SYNO.SDS.CSTN.SHARING.SHARENAME_COL_WIDTH = 250, SYNO.SDS.CSTN.SHARING.PAGE_ITEM_LIMIT = 50, Ext.define("SYNO.SDS.CSTN.PanelSharing", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.my_ds_center_email = "";
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        this.pageSize = SYNO.SDS.CSTN.SHARING.PAGE_ITEM_LIMIT;
        var t = [{
                id: "share_name",
                header: _STR("common", "shared_folder"),
                dataIndex: "share_name",
                sortable: !0,
                align: "left",
                width: SYNO.SDS.CSTN.SHARING.SHARENAME_COL_WIDTH,
                renderer: SYNO.SDS.CSTN.RenderShareName
            }, {
                id: "share_status",
                header: _STR("common", "status"),
                dataIndex: "share_status",
                sortable: !0,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                width: SYNO.SDS.CSTN.SHARING.STATUS_COL_WIDTH,
                renderer: SYNO.SDS.CSTN.RenderShareStatus
            }, {
                header: _STR("version", "number_of_versions"),
                dataIndex: "rotate_cnt",
                sortable: !0,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                width: SYNO.SDS.CSTN.SHARING.ROTATE_COL_WIDTH,
                renderer: SYNO.SDS.CSTN.RenderShareRotateCount
            }, {
                header: _STR("version", "smart_rotation"),
                dataIndex: "rotate_policy",
                sortable: !0,
                align: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "left" : "center",
                width: SYNO.SDS.CSTN.SHARING.ROTATE_COL_WIDTH,
                renderer: SYNO.SDS.CSTN.RenderShareRotatePolicy
            }],
            i = new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: function(e) {
                        var t = e.getSelections(),
                            i = !1,
                            n = !1,
                            s = !1,
                            o = !1,
                            a = this.getTopToolbar().get("btnEnable"),
                            r = this.getTopToolbar().get("btnDisable"),
                            l = this.getTopToolbar().get("btnVersionCnt");
                        this._S("demo_mode") || (Ext.each(t, function(e) {
                            return "c2_share" == e.get("share_type") && (o = !0), e.get("share_enable") ? (n = !0, s = !0) : "not_available" != e.get("share_status") && "not_supported" != e.get("share_status") && (i = !0), !0
                        }), o && t.length > 1 && (i = !1), l.setDisabled(!n), a.setDisabled(!i), r.setDisabled(!s))
                    },
                    scope: this
                }
            }),
            n = new Ext.grid.ColumnModel({
                columns: t
            }),
            s = this.createStore(),
            o = new SYNO.ux.TextFilter({
                itemId: "search",
                emptyText: _STR("btn", "search"),
                store: s,
                pageSize: this.pageSize,
                enumAction: "list",
                queryAction: "list"
            }),
            a = new Ext.Toolbar;
        a.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnEnable",
            text: _STR("btn", "btn_enable"),
            handler: this.onEnable,
            scope: this
        }), a.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnDisable",
            text: _STR("btn", "btn_disable"),
            handler: this.onDisable,
            scope: this
        }), a.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "btnVersionCnt",
            text: _STR("version", "version"),
            handler: this.onVersionSet,
            scope: this
        }), a.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !1,
            itemId: "btnVersionExplorer",
            text: _STR("func", "version_explorer"),
            handler: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.CSTN.Explore.Instance", {})
            }
        }), a.add("->"), a.add(o);
        var r = new SYNO.ux.PagingToolbar({
                cls: "cstn-paging-toolbar",
                store: s,
                pageSize: this.pageSize,
                displayInfo: !0
            }),
            l = {
                xtype: "syno_displayfield",
                cls: "syno-cstn-sharing-note-toolbar",
                html: '<span class="sharing-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + String.format(_STR("cstn", "goto_sharedfolder_setting_desc"), '<a id="' + (this.gotoSharedFolderId = Ext.id()) + '" class="link">' + _STR("cstn", "shared_folders") + "</a>"),
                listeners: {
                    scope: this,
                    afterrender: function() {
                        Ext.get(this.gotoSharedFolderId).on("click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                owner: this,
                                fn: "SYNO.SDS.AdminCenter.Share.Main"
                            })
                        })
                    }
                }
            },
            d = {
                cls: "syno-cstn-panel-padding",
                itemId: "sharing",
                tbar: a,
                view: new SYNO.ux.FleXcroll.grid.GridView,
                stripeRows: !0,
                enableColLock: !1,
                enableHdMenu: !1,
                enableColumnMove: !1,
                colModel: n,
                sm: i,
                ds: s,
                autoExpandColumn: "share_name",
                loadMask: !0,
                bbar: {
                    autoHeight: !0,
                    cls: "syno-cstn-teamfolder-bbar",
                    layout: {
                        type: "vbox",
                        align: "stretch"
                    },
                    items: [r, l]
                }
            };
        return SYNO.LayoutConfig.fill(d), Ext.apply(d, e), d
    },
    getC2ShareAccounts: function() {
        this.sendWebAPI({
            api: "SYNO.C2FS.Share",
            method: "list",
            version: 1,
            scope: this,
            async: !1,
            callback: function(e, t) {
                e && (this.c2_share_accounts = t)
            }
        })
    },
    shareArrC2ShareCount: function(e) {
        var t = 0;
        return Ext.each(e, function(e) {
            "c2_share" === e.share_type && t++
        }), t
    },
    createStore: function() {
        var e = ["share_name", "share_type", "share_status", "share_enable", "rotate_cnt", "rotate_policy", "rotate_days"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WebAPI.Share.api,
                    version: 1,
                    method: "list",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "items",
                    totalProperty: "total",
                    idProperty: "id"
                }, e),
                sortInfo: {
                    field: "share_name",
                    direction: "ASC"
                },
                paramNames: {
                    start: "offset",
                    limit: "limit",
                    sort: "sort_by",
                    dir: "sort_direction"
                },
                baseParams: {
                    offset: 0,
                    limit: SYNO.SDS.CSTN.SHARING.PAGE_ITEM_LIMIT,
                    sort_by: "share_name",
                    sort_direction: "ASC"
                },
                remoteSort: !0,
                listeners: {
                    scope: this,
                    beforeload: function() {
                        SYNO.SDS.CSTN.SupportHybridShare() && this.getC2ShareAccounts()
                    },
                    load: function(e, t) {
                        e.filterBy(function(e) {
                            return "c2_share" === e.get("share_type") && SYNO.SDS.CSTN.SupportHybridShare() || "c2_share" !== e.get("share_type")
                        })
                    },
                    exception: function(e, t, i, n, s) {
                        s && s.code && SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [s])
                    }
                }
            });
        return this.addManagedComponent(t), t
    },
    showEnableShareRemainder: function(e, t) {
        (function() {
            var e = _STR("warning", "msg_sharing_hint");
            e += "<br/><br/>" + _STR("warning", "warn_mount"), this.owner.getMsgBox().alert(_STR("app", "app_name"), e, function() {
                SYNO.SDS.CSTN.cbLoad.apply(this)
            }, this)
        }).bind(this)()
    },
    ajaxCheckSrvStatusCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: SYNO.SDS.CSTN.cbLoad,
            failure: SYNO.SDS.CSTN.webapiErrHdlMain
        })
    },
    checkSrvStatus: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
    },
    onPageActivate: function() {
        this.checkSrvStatus()
    },
    onActivate: function() {
        this.onPageActivate()
    },
    checkDirty: function() {
        return !1
    },
    applyGridDoneFail: function(e) {
        this.getStore().rejectChanges();
        var t = "";
        switch (e.code) {
            case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
            case SYNO.SDS.CSTN.ErrorCode.PKG_NOT_ENABLED:
            case SYNO.SDS.CSTN.ErrorCode.SERVICE_DISABLED:
            case SYNO.SDS.CSTN.ErrorCode.ADMIN_ONLY:
            case SYNO.SDS.CSTN.ErrorCode.SYS_DISK_FULL:
                return void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [e]);
            default:
                t = SYNO.SDS.CSTN.getErrorString(e)
        }
        this.owner.getMsgBox().alert(_STR("app", "app_name"), t)
    },
    ajaxApplyGridCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: SYNO.SDS.CSTN.cbLoad,
            failure: this.applyGridDoneFail
        })
    },
    beforeApplyGrid: function(e) {
        var t = this.getAffectedShareInfo(e ? "enable" : "disable"),
            i = [],
            n = !1,
            s = !1;
        if (Ext.each(t, function(t) {
                "homes/mydrive" === t.share_name && (n = !0), "c2_share" == t.share_type && (s = !0), i.push({
                    share_name: t.share_name,
                    share_enable: e,
                    share_status: t.share_status,
                    share_type: t.share_type
                })
            }), !1 === e)
            if (n && 1 == t.length) this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "disable_home_service"), function(e) {
                "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    owner: this,
                    fn: "SYNO.SDS.AdminCenter.User.Main",
                    tab: "option_tab"
                })
            }, this);
            else if (s) {
            var o = String.format(_STR("warning", "hybrid_share_disable_sync"), t[0].share_name, this.c2_share_accounts[t[0].share_name].synology_account);
            this.owner.getMsgBox().confirm(_STR("app", "app_name"), o, function(e) {
                "yes" === e && this.applyGrid(i, !1)
            }, this)
        } else this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "msg_remove_user_share_db"), function(e) {
            "yes" === e && (n ? this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "disable_home_service_with_team_folder"), function(e) {
                this.applyGrid(i, !1), "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    owner: this,
                    fn: "SYNO.SDS.AdminCenter.User.Main",
                    tab: "option_tab"
                })
            }, this) : this.applyGrid(i, !1))
        }, this);
        else {
            var a = function(e) {
                var t = e.getEnableShareArr();
                t.length > 0 && this.showEnableShareRemainder(t, s)
            };
            dialog = new SYNO.SDS.CSTN.DialogRotateSetting({
                sharing_this: this,
                init_share: !0,
                owner: this.owner,
                share_arr: i,
                c2_share_accounts: this.c2_share_accounts,
                listeners: {
                    scope: this,
                    close: a
                }
            }), dialog.winShow(), n && dialog.getMsgBox().confirm(_STR("app", "app_name"), _STR("warning", "enable_home_service"), function(e) {
                "yes" === e ? SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.User.Main",
                    tab: "option_tab"
                }) : 1 == t.length ? dialog.close() : dialog.ignoreShare("homes/mydrive")
            }, this)
        }
    },
    applyDefaultRotatePolicy: function(e) {
        Ext.each(e, function(e) {
            e.rotate_policy = "fifo"
        })
    },
    applyGrid: function(e) {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.Share.set.call(this, e, this.ajaxApplyGridCB, this)
    },
    getSingleShareInfo: function(e) {
        return {
            share_name: e.get("share_name"),
            share_enable: e.get("share_enable"),
            share_status: e.get("share_status"),
            share_type: e.get("share_type"),
            rotate_cnt: e.get("rotate_cnt"),
            rotate_policy: e.get("rotate_policy"),
            rotate_days: e.get("rotate_days")
        }
    },
    getAffectedShareInfo: function(e) {
        var t = this.getSelectionModel().getSelections(),
            i = [];
        return Ext.each(t, function(t) {
            var n = this.getSingleShareInfo(t);
            "enable" == e ? n.share_enable || i.push(n) : "disable" == e ? n.share_enable && i.push(n) : "version_set" == e ? n.share_enable && i.push(n) : i.push(n)
        }, this), i
    },
    onEnable: function() {
        this.beforeApplyGrid(!0)
    },
    onDisable: function() {
        this.beforeApplyGrid(!1)
    },
    onVersionSet: function() {
        var e, t = this.getAffectedShareInfo("version_set"),
            i = [];
        Ext.each(t, function(e) {
            i.push({
                share_name: e.share_name,
                share_enable: e.share_enable,
                share_type: e.share_type,
                rotate_cnt: e.rotate_cnt,
                rotate_policy: e.rotate_policy,
                rotate_days: e.rotate_days
            })
        }), e = new SYNO.SDS.CSTN.DialogRotateSetting({
            sharing_this: this,
            init_share: !1,
            owner: this.owner,
            c2_share_accounts: this.c2_share_accounts,
            share_arr: i,
            listeners: {
                close: this.onDialogClose,
                scope: this
            }
        }), e.winShow()
    },
    onDialogClose: function(e) {}
}), Ext.define("SYNO.SDS.CSTN.DialogRotateSetting", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.share_arr = e.share_arr, this.enable_share_arr = [];
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "apply"),
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                itemId: "apply",
                handler: this.onSave,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "cancel"),
                itemId: "cancel",
                handler: this.onCancel,
                scope: this
            }]
        };
        SYNO.SDS.CSTN.IsDSM7OrAbove() && t.items.reverse(), this.panel = new SYNO.ux.FormPanel({
            cls: "no-scroll",
            labelAlign: "left",
            border: !1,
            autoFlexcroll: !1,
            items: this.getPanelItems()
        }), this.callParent([Ext.apply({
            cls: "syno-cstn-version-info-dlg",
            title: _STR("version", "version"),
            width: 600,
            height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 570 : 538,
            resizable: !1,
            layout: "fit",
            items: [this.panel],
            fbar: t
        }, e)]), this.on("afterlayout", this.onAfterLayout, this, {
            single: !0
        })
    },
    getPanelItems: function() {
        return [{
            cls: "min-fieldset",
            xtype: "syno_fieldset",
            items: [{
                xtype: "syno_displayfield",
                value: _STR("version", "version_description")
            }, {
                xtype: "syno_checkbox",
                name: "enable_version",
                boxLabel: _STR("version", "enable_versioning")
            }, this.inputField = new SYNO.ux.NumberField({
                xtype: "syno_numberfield",
                name: "rotate_count",
                fieldLabel: _STR("cstn", "label_version_limit"),
                indent: 1,
                maxValue: 32,
                minValue: 1,
                maxlength: 2,
                allowBlank: !1,
                allowNegative: !1,
                regex: /^\d+$/,
                width: 180
            }), {
                cls: "min-fieldset",
                xtype: "syno_fieldset",
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("version", "rotate_policy"),
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    boxLabel: _STR("version", "fifo_rotation"),
                    name: "rotate_policy",
                    inputValue: "fifo",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    boxLabel: _STR("version", "smart_rotation"),
                    name: "rotate_policy",
                    inputValue: "smart",
                    indent: 1,
                    listeners: {
                        afterrender: function(e) {
                            SYNO.SDS.Utils.AddTip(e.el.dom, _STR("version", "intelliversion_tooltip"))
                        }
                    }
                }]
            }, {
                cls: "min-fieldset",
                xtype: "syno_fieldset",
                items: [{
                    xtype: "syno_checkbox",
                    name: "enable_rotate_days",
                    boxLabel: _STR("version", "enable_rotate_days_checkbox"),
                    indent: 1,
                    listeners: {
                        afterrender: function(e) {
                            SYNO.SDS.Utils.AddTip(e.el.dom, _STR("version", "rotate_days_tooltip"))
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: _STR("version", "enable_rotate_days_checkbox_desc"),
                    indent: 2
                }, {
                    xtype: "syno_combobox",
                    displayField: "display",
                    valueField: "value",
                    hideLabel: !0,
                    indent: 2,
                    mode: "local",
                    name: "rotate_days",
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["display", "value"],
                        data: [7, 30, 60, 120].map(function(e) {
                            return [String.format(_STR("version", "days"), e), e]
                        })
                    })
                }]
            }, {
                cls: "min-fieldset",
                xtype: "syno_fieldset",
                items: [{
                    id: this.summaryBoxId = Ext.id(),
                    xtype: "box",
                    cls: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "highlight-box" : "summary-box"
                }]
            }]
        }]
    },
    onAfterLayout: function() {
        new SYNO.ux.Utils.EnableCheckGroup(this.panel.getForm(), "enable_version", ["rotate_count", "rotate_policy", "enable_rotate_days"]), new SYNO.ux.Utils.EnableRadioGroup(this.panel.getForm(), "rotate_policy", {
            fifo: [],
            smart: []
        }), new SYNO.ux.Utils.EnableCheckGroup(this.panel.getForm(), "enable_rotate_days", ["rotate_days"]), this.init_share ? this.showDefaultValue() : this.showMergedValue(), this.updateSummaryField(), this.mountFieldEvent("enable_version", "check", this.updateSummaryField, this), this.mountFieldEvent("enable_rotate_days", "check", this.updateSummaryField, this), this.mountFieldEvent("rotate_count", "change", this.updateSummaryField, this), this.mountFieldEvent("rotate_days", "change", this.updateSummaryField, this)
    },
    mountFieldEvent: function(e, t, i, n) {
        var s = this.findField(e);
        s.mon(s, t, i, n)
    },
    findField: function(e) {
        return SYNO.ux.Utils.findFormField(this.panel.getForm(), e)
    },
    updateSummaryField: function() {
        var e = function(e) {
                return "<b>" + e + "</b>"
            },
            t = function() {
                var t;
                return t = this.findField("enable_version").getValue() ? this.findField("enable_rotate_days").getValue() ? "summary_desc_with_rotate_days" : "summary_desc_without_rotate_days" : "summary_desc_none", String.format(_STR("version", t), e(this.findField("rotate_count").getValue()), e(this.findField("rotate_days").getValue()))
            }.bind(this),
            i = Ext.get(this.summaryBoxId),
            n = String.format("<h2>{0}</h2><p>{1}</p>", _STR("version", "summary_title"), t());
        i.update(n), i.show()
    },
    getDefaultValue: function() {
        return {
            enable_version: !0,
            rotate_count: 8,
            rotate_policy: "fifo",
            enable_rotate_days: !1,
            rotate_days: 120
        }
    },
    showDefaultValue: function() {
        var e = this.getDefaultValue();
        "c2_share" == this.share_arr[0].share_type && (e.enable_version = !1), this.panel.getForm().setValues(e), this.updateOriginalValues(e)
    },
    showMergedValue: function() {
        var e = this.getMergedRotateCount(),
            t = this.getMergedRotatePolicy(),
            i = {};
        i.enable_version = 0 !== e, i.rotate_policy = t, i.rotate_days = this.share_arr.reduce(function(e, t) {
            return 0 != t.rotate_days ? t.rotate_days : e
        }, 0), i.enable_rotate_days = i.rotate_days > 0, i.rotate_days = 0 === i.rotate_days ? 120 : i.rotate_days, -1 != e && (i.rotate_count = e), i.enable_version || (i = this.getDefaultValue(), i.enable_version = !1), this.panel.getForm().setValues(i), this.updateOriginalValues(i)
    },
    updateOriginalValues: function(e) {
        this.oriValues = Ext.apply({}, e)
    },
    getMergedRotateCount: function() {
        for (var e = -1, t = 0; t < this.share_arr.length; t++) {
            if (-1 != e && e != this.share_arr[t].rotate_cnt) return -1;
            e = this.share_arr[t].rotate_cnt
        }
        return e
    },
    getMergedRotatePolicy: function() {
        for (var e = "", t = 0; t < this.share_arr.length; t++) {
            if ("" !== e && e !== this.share_arr[t].rotate_policy) return "";
            e = this.share_arr[t].rotate_policy
        }
        return e
    },
    ignoreShare: function(e) {
        this.share_arr = this.share_arr.filter(function(t) {
            return t.share_name !== e
        }, this)
    },
    winShow: function() {
        this.open()
    },
    onCancel: function() {
        this.close()
    },
    onSave: function() {
        var e, t, i, n, s = [],
            o = this.panel.getForm().getValues(),
            a = !1;
        if ("true" === o.enable_version) {
            if (!1 === this.inputField.validate()) return;
            if (!o.rotate_policy) return void this.setStatusError({
                text: _STR("warning", "not_choose"),
                clear: !0
            });
            e = parseInt(o.rotate_count, 10), t = o.rotate_policy, i = "true" === o.enable_rotate_days ? parseInt(o.rotate_days, 10) : 0
        } else e = 0, t = "fifo", i = 0;
        for (n = 0; n < this.share_arr.length; n++) this.share_arr[n].share_enable && (s.push({
            share_name: this.share_arr[n].share_name,
            rotate_cnt: e,
            rotate_policy: t,
            rotate_days: i,
            share_type: this.share_arr[n].share_type
        }), "c2_share" === this.share_arr[n].share_type && (a = !0, this.enabled_c2share = this.share_arr[n]));
        if (this.init_share)
            for (n = 0; n < s.length; n++) "homes/mydrive" !== s[n].share_name && (s[n].share_enable = !0), this.enable_share_arr.push(s[n]);
        var r = function() {
                this.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.Share.set.call(this.owner, s, this.ajaxApplyGridCB, this)
            }.bind(this),
            l = this.oriValues.enable_version && "false" === o.enable_version || this.oriValues.rotate_count > e || !this.oriValues.enable_rotate_days && "true" === o.enable_rotate_days || this.oriValues.enable_rotate_days && "true" === o.enable_rotate_days && this.oriValues.rotate_days > i;
        if (this.need_show_inc = a && (!this.oriValues.enable_version && "true" === o.enable_version || this.oriValues.rotate_count < e || this.oriValues.enable_rotate_days && "false" === o.enable_rotate_days || this.oriValues.enable_rotate_days && "true" === o.enable_rotate_days && this.oriValues.rotate_days < i), !this.init_share && l) {
            var d = a ? String.format(_STR("warning", "hybrid_share_version_start_cleanup"), this.c2_share_accounts[this.enabled_c2share.share_name].synology_account) : _STR("warning", "version_start_cleanup");
            this.owner.getMsgBox().confirm(_STR("app", "app_name"), d, function(e) {
                "yes" === e && r()
            })
        } else if (a && (this.init_share || this.need_show_inc)) {
            var c = '<ol style="list-style:decimal;padding-left:16px;padding-bottom:12px;">' + ("true" === o.enable_version ? "<li>" + String.format(_STR("version", "hybrid_share_localcache_desc")) : "") + "<li>" + String.format(_STR("version", "hybrid_share_enable"), this.c2_share_accounts[this.enabled_c2share.share_name].synology_account) + "</ol>" + _STR("common", "confirm_continue");
            this.owner.getMsgBox().confirm(_STR("app", "app_name"), c, function(e) {
                "yes" === e ? r() : this.enable_share_arr = []
            }, this)
        } else r()
    },
    getEnableShareArr: function() {
        return this.enable_share_arr
    },
    getNeedShowInc: function() {
        return this.need_show_inc
    },
    getEnabledC2Share: function() {
        return this.enabled_c2share
    },
    ajaxApplyGridSuccessCB: function() {
        this.sharing_this.getStore().load(), this.close()
    },
    ajaxApplyGridFailedCB: function() {
        this.enable_share_arr = [], SYNO.SDS.CSTN.webapiErrHdl.apply(this, arguments)
    },
    ajaxApplyGridCB: function(e, t, i, n) {
        this.clearStatusBusy(), SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.ajaxApplyGridSuccessCB,
            failure: this.ajaxApplyGridFailedCB
        })
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PanelDatabase", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.BtnApplyId = void 0, this.BtnCancelId = void 0, this.BtnDBUsageId = void 0, this.polling_task = void 0, this.clearRecycleMgr = new SYNO.SDS.CSTN.PanelDatabaseUtils.ClearRecycleManager({
            owner: this,
            stateDisplayField: new SYNO.ux.DisplayField({
                value: _STR("common", "idle"),
                isDirty: function() {
                    return !1
                }
            }),
            clearRecycleBinBtn: new SYNO.ux.Button({
                text: _STR("recycle", "clean_all_view_btn")
            })
        });
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "afterlayout", function() {
            var e = this.getForm();
            new SYNO.SDS.Utils.EnableCheckGroup(e, "enable_vmtouch", ["vmtouch_reserve_mem"])
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        var t = {
            labelAlign: "left",
            labelWidth: 150,
            border: !1,
            itemId: "configure",
            cls: "syno-cstn-database-panel",
            id: this.databasePanelId = Ext.id(),
            trackResetOnLoad: !0,
            items: this.getItems(),
            buttons: [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "commit"),
                itemId: "apply",
                id: this.BtnApplyId = Ext.id(),
                scope: this,
                handler: this.onSave
            }, {
                xtype: "syno_button",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "reset"),
                itemId: "cancel",
                id: this.BtnCancelId = Ext.id(),
                scope: this,
                handler: this.onCancel
            }]
        };
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && t.buttons.reverse(), t = this.addStatusBar(t), SYNO.LayoutConfig.fill(t), Ext.apply(t, e), t
    },
    getItems: function() {
        this.enableDefaultContentIndexing = new SYNO.ux.Checkbox({
            name: "default_enable_full_content_indexing",
            boxLabel: _STR("drive", "index_enable_team_folder")
        }), this.launchContentIndexingSettings = new SYNO.ux.Button({
            name: "launch_sus",
            text: _STR("drive", "detailed_indexing_settings"),
            handler: function() {
                SYNO.SDS.AppLaunch("SYNO.Finder.Application", {
                    fn: "preference",
                    data: {
                        tab: "fileindex",
                        data: {
                            tab: SYNO.SDS.Drive.Extension.Instance.isHomeServiceEnabled() ? "SYNO.SDS.Drive.Application:drive:displayname" : "SYNO.SDS.Drive.Application:drive:displayname_teamfolder"
                        }
                    }
                })
            },
            scope: this
        }), this.noteHybridShareNotContentIndexing = {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: String.format('<span class="syno-ux-note">{0}:</span> {1}', _STR("common", "note"), _STR("drive", "content_indexing_hybrid_share_not_supported"))
        }, this.enableVMTouch = new SYNO.ux.Checkbox({
            name: "enable_vmtouch",
            boxLabel: _STR("drive", "enable_vmtouch")
        }), this.vmtouchReserveMem = new SYNO.ux.NumberField({
            name: "vmtouch_reserve_mem",
            indent: 1,
            minValue: 10,
            maxValue: 90,
            width: 80,
            fieldLabel: _STR("drive", "vmtouch_reserve_mem")
        }), this.emailDesc = new SYNO.ux.DisplayField({
            ctCls: "syno-d-setting-email-desc",
            value: _STR("setting", "notification_email_desc")
        }), this.emailBtn = {
            xtype: "syno_button",
            text: _STR("setting", "notification_email_launch"),
            handler: function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Notification.Main"
                })
            },
            scope: this
        }, this.enableNonAdminUserSync = new SYNO.ux.Checkbox({
            name: "enable_non_admin_user_sync",
            boxLabel: _STR("setting", "enable_non_admin_syncing_checkbox")
        }), this.transferHomeMgr = new SYNO.SDS.CSTN.PanelDatabaseUtils.TransferHomeManager({
            owner: this.owner,
            fromUserCombo: new SYNO.ux.ComboBox({
                fieldLabel: "",
                name: "from_user",
                cls: "syno-cstn-database-panel-combobox",
                lazyInit: !1,
                width: 200,
                emptyText: _STR("cstn", "user_a"),
                listEmptyText: _STR("common", "no_data"),
                editable: !0,
                hideTrigger: !0,
                store: this.getDisabledUserStore(),
                minChars: 1,
                valueField: "name",
                displayField: "name",
                queryParam: "query",
                mode: "remote",
                enableKeyEvents: !1,
                invalidText: _STR("cstn", "invalid_transfer_from_user"),
                submitValue: !1,
                isDirty: function() {
                    return !1
                }
            }),
            toUserCombo: new SYNO.ux.ComboBox({
                xtype: "syno_combobox",
                fieldLabel: "",
                name: "to_user",
                cls: "syno-cstn-database-panel-combobox",
                lazyInit: !1,
                width: 200,
                emptyText: _STR("cstn", "user_b"),
                listEmptyText: _STR("common", "no_data"),
                editable: !0,
                hideTrigger: !0,
                store: this.getEnabledUserStore(),
                minChars: 1,
                valueField: "name",
                displayField: "name",
                queryParam: "query",
                mode: "remote",
                enableKeyEvents: !1,
                invalidText: _STR("cstn", "invalid_transfer_to_user"),
                submitValue: !1,
                isDirty: function() {
                    return !1
                }
            }),
            transferButton: new SYNO.ux.Button({
                text: _STR("cstn", "transfer_files"),
                scope: this,
                handler: this.onTransferHome
            }),
            transferProgress: new Ext.ProgressBar({
                width: 200,
                value: .5,
                style: "padding-left: 20px; padding-top: 5px;"
            })
        });
        var e = [{
            xtype: "syno_displayfield",
            value: _STR("drive", "content_indexing_desc"),
            indent: 0
        }, this.enableDefaultContentIndexing, {
            xtype: "syno_displayfield",
            value: _STR("drive", "customize_indexing_detail"),
            indent: 0
        }, this.launchContentIndexingSettings];
        SYNO.SDS.CSTN.SupportHybridShare() && e.push(this.noteHybridShareNotContentIndexing);
        var t = [{
            xtype: "syno_fieldset",
            title: _STR("func", "database_title"),
            labelWidth: "220",
            items: [{
                xtype: "syno_displayfield",
                html: _STR("cstn", "desc_db_location_setting"),
                indent: 0,
                isDirty: function() {
                    return !1
                },
                reset: function() {}
            }, {
                xtype: "syno_displayfield",
                cls: "drive_warning_msg",
                value: "",
                indent: 1,
                hidden: !0,
                name: "warning"
            }, {
                xtype: "syno_combobox",
                name: "volume_select",
                ctCls: "syno-cstn-grid-combo",
                fieldLabel: _STR("func", "db_location"),
                valueField: "mount_point",
                displayField: "display",
                value: 1,
                store: new Ext.data.JsonStore({
                    fields: ["mount_point", "display"],
                    data: [{
                        mount_point: "/volume1",
                        display: "Volume1"
                    }]
                }),
                forceSelection: !0,
                mode: "local",
                hideLabel: !1,
                selectOnFocus: !0,
                triggerAction: "all",
                editable: !1,
                hidden: !1,
                width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 340 : 300,
                listeners: {
                    scope: this,
                    select: function(e, t) {
                        if (t.get("mount_point") != e.originalValue) {
                            var i = {};
                            i.warning = _STR("warning", "warn_move"), this.getForm().findField("warning").setVisible(!0), this.getForm().setValues(i)
                        } else this.getForm().findField("warning").setVisible(!1)
                    }
                }
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("func", "usage") + ":",
                    width: 215
                }, {
                    xtype: "syno_button",
                    text: _STR("btn", "db_usage_calculate"),
                    id: this.BtnDBUsageId = Ext.id(),
                    scope: this,
                    handler: this.startCalculateDBUsage
                }, {
                    xtype: "syno_displayfield",
                    name: "usage",
                    value: _STR("func", "db_usage_not_calculated"),
                    cls: "syno-cstn-database-panel-usage-text",
                    isDirty: function() {
                        return !1
                    },
                    reset: function() {}
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                id: this.summaryBoxParent = Ext.id(),
                hidden: !0,
                items: [{
                    xtype: "spacer",
                    width: 215
                }, {
                    cls: "min-fieldset",
                    xtype: "syno_fieldset",
                    items: [{
                        id: this.summaryBoxId = Ext.id(),
                        xtype: "box",
                        cls: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "highlight-box" : "summary-box",
                        html: ""
                    }]
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("recycle", "clean_all_view") + ":",
                    width: 215
                }, this.clearRecycleMgr.stateDisplayField]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "spacer",
                    width: 215
                }, this.clearRecycleMgr.clearRecycleBinBtn]
            }]
        }, {
            xtype: "syno_fieldset",
            title: _STR("drive", "content_indexing"),
            labelWidth: "220",
            items: e
        }];
        return SYNO.SDS.CSTN.SupportHybridShare() && t.push({
            xtype: "syno_fieldset",
            title: _STR("drive", "c2_offload_title"),
            labelWidth: "220",
            items: [{
                xtype: "syno_displayfield",
                value: _STR("drive", "c2_offload_desc"),
                indent: 0
            }, {
                xtype: "syno_checkbox",
                name: "enable_c2share_offload",
                boxLabel: _STR("drive", "c2_offload_option"),
                indent: 0
            }]
        }), Array.prototype.push.apply(t, [{
            xtype: "syno_fieldset",
            itemId: "performanceSection",
            title: _STR("drive", "performance"),
            labelWidth: "220",
            items: [this.enableVMTouch, this.vmtouchReserveMem]
        }, {
            xtype: "syno_fieldset",
            title: _STR("setting", "notification_email"),
            items: [this.emailDesc, this.emailBtn]
        }, {
            xtype: "syno_fieldset",
            title: _STR("func", "displayname"),
            labelWidth: "220",
            items: [{
                xtype: "syno_displayfield",
                value: _STR("func", "displayname_des"),
                indent: 0,
                isDirty: function() {
                    return !1
                },
                reset: function() {}
            }, {
                xtype: "syno_combobox",
                name: "displayname_select",
                ctCls: "syno-cstn-grid-combo",
                fieldLabel: _STR("func", "displayname_default"),
                valueField: "value",
                displayField: "display",
                store: new Ext.data.JsonStore({
                    fields: ["value", "display"],
                    data: [{
                        value: "username",
                        display: _STR("common", "usrname")
                    }, {
                        value: "nickname",
                        display: _STR("common", "nickname")
                    }]
                }),
                forceSelection: !0,
                mode: "local",
                hideLabel: !1,
                selectOnFocus: !0,
                triggerAction: "all",
                editable: !1,
                hidden: !1,
                width: 300
            }]
        }, {
            xtype: "syno_fieldset",
            title: _STR("setting", "enable_non_admin_syncing"),
            labelWidth: "220",
            items: [{
                xtype: "syno_displayfield",
                html: _STR("setting", "enable_non_admin_syncing_desc") + ' <a id="disable-sync-learn-more">' + _STR("share", "know_more") + "</a>",
                indent: 0,
                listeners: {
                    scope: this,
                    afterrender: function() {
                        Ext.get("disable-sync-learn-more").on("click", function() {
                            var e = "SYNO.SDS.Drive.Application:drive_admin_console.html",
                                t = "disable-sync-learn-more";
                            _S("standalone") ? SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: e,
                                anchor: t
                            }) : SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: e,
                                anchor: t
                            }, !1)
                        })
                    }
                },
                isDirty: function() {
                    return !1
                },
                reset: function() {}
            }, this.enableNonAdminUserSync]
        }, {
            xtype: "syno_fieldset",
            title: _STR("cstn", "file_owner_transfer"),
            collapsible: !1,
            items: [{
                xtype: "syno_displayfield",
                value: _STR("cstn", "file_owner_transfer_desc"),
                isDirty: function() {
                    return !1
                },
                reset: function() {}
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("cstn", "transfer_from"),
                    width: 215
                }, this.transferHomeMgr.fromUserCombo]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _STR("cstn", "transfer_to"),
                    width: 215
                }, this.transferHomeMgr.toUserCombo]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [this.transferHomeMgr.transferButton, this.transferHomeMgr.transferProgress]
            }]
        }]), t
    },
    onTransferHome: function() {
        var e = !0,
            t = this.form.findField("from_user"),
            i = this.form.findField("to_user");
        return 0 !== t.getValue().length && -1 != this.findIndexUser(this.getDisabledUserStore(), t.getValue()) || (t.markInvalid(), e = !1), 0 !== i.getValue().length && -1 != this.findIndexUser(this.getEnabledUserStore(), i.getValue()) || (i.markInvalid(), e = !1), i.getValue() === t.getValue() && (i.markInvalid(), t.markInvalid(), e = !1), !0 === e && this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("cstn", "file_owner_transfer_alert"), function(e) {
            "yes" === e && (this.transferHomeMgr.disableComponents(), this.sendWebAPI({
                api: SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api,
                version: 1,
                method: "start",
                params: {
                    from: t.getValue(),
                    to: i.getValue()
                },
                callback: this.transferHomeMgr.transferCB.bind(this.transferHomeMgr)
            }))
        }, this), e
    },
    findIndexUser: function(e, t) {
        var i = e.createFilterFn("name", t, !1, !1, !0);
        return (e.snapshot || e.data).findIndexBy(i)
    },
    getEnabledUserStore: function() {
        return this.enabledUserStore || (this.enabledUserStore = this.getUserStore(!0))
    },
    getDisabledUserStore: function() {
        return this.disabledUserStore || (this.disabledUserStore = this.getUserStore(!1))
    },
    getUserStore: function(e) {
        return new SYNO.API.Store({
            appWindow: this,
            autoLoad: !1,
            autoDestroy: !0,
            pruneModifiedRecords: !0,
            baseParams: {
                query: "",
                type: e ? "enabled" : "disabled"
            },
            proxy: new SYNO.API.Proxy(Ext.apply({
                listeners: {
                    scope: this,
                    load: function() {
                        this.query || this.blQueryEmpty || (this.blQueryEmpty = !0)
                    }
                }
            }, {
                api: SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api,
                method: "list",
                version: 1
            })),
            reader: new Ext.data.JsonReader({
                root: "items",
                idProperty: "",
                fields: ["name"]
            })
        })
    },
    addStatusBar: function(e) {
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: []
        };
        return e.buttons && (t.items = t.items.concat(e.buttons), delete e.buttons), Ext.applyIf(e, {
            fbar: t
        }), e
    },
    applyFormFail: function(e) {
        var t = "";
        switch (errinfo = SYNO.API.Util.GetFirstError(e), errinfo.code) {
            case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
            case SYNO.SDS.CSTN.ErrorCode.PKG_NOT_ENABLED:
            case SYNO.SDS.CSTN.ErrorCode.SERVICE_DISABLED:
            case SYNO.SDS.CSTN.ErrorCode.ADMIN_ONLY:
            case SYNO.SDS.CSTN.ErrorCode.SYS_DISK_FULL:
            case SYNO.SDS.CSTN.ErrorCode.REPO_MOVE:
            case SYNO.SDS.CSTN.ErrorCode.CANNOT_ACCESS:
                return this.onCancel(), void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [errinfo]);
            default:
                t = SYNO.SDS.CSTN.getErrorString(errinfo)
        }
        this.owner.getMsgBox().alert(_STR("app", "app_name"), t), this.loadForm()
    },
    applyFormSuccess: function() {
        this.owner.setStatusOK(), this.setStatusOK({
            text: _T("common", "setting_applied"),
            clear: !0
        }), this.loadForm()
    },
    ajaxApplyFormCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.applyFormSuccess,
            failure: this.applyFormFail
        })
    },
    applySetting: function() {
        var e = this.getForm(),
            t = e.findField("volume_select"),
            i = e.findField("enable_vmtouch"),
            n = e.findField("vmtouch_reserve_mem"),
            s = e.findField("default_enable_full_content_indexing"),
            o = e.findField("displayname_select"),
            a = e.findField("enable_non_admin_user_sync"),
            r = e.findField("enable_c2share_offload") || {
                isDirty: function() {
                    return !1
                },
                getValue: function() {
                    return !1
                }
            },
            l = _STR("common", "saving"),
            d = [];
        this.owner.setStatusBusy({
            text: l
        }), (s.isDirty() || o.isDirty() || r.isDirty()) && d.push({
            api: "SYNO.SynologyDrive.Settings",
            method: "update",
            version: 2,
            params: {
                default_enable_full_content_indexing: s.getValue(),
                default_displayname: o.getValue(),
                enable_c2share_offload: r.getValue()
            }
        }), (t.isDirty() || i.isDirty() || n.isDirty() || a.isDirty()) && (t.isDirty() && (l = _STR("warning", "error_drive_repomove")), d.push({
            api: SYNO.SDS.CSTN.WebAPI.Config.api,
            method: "set",
            version: 1,
            params: {
                db_volume: t.getValue(),
                enable_vmtouch: i.getValue(),
                vmtouch_reserve_mem: n.getValue(),
                enable_non_admin_user_sync: a.getValue()
            }
        })), this.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: d
            },
            callback: this.ajaxApplyFormCB,
            scope: this
        })
    },
    loadFormDoneSuccess: function(e) {
        if (!this.isDestroyed) {
            var t = SYNO.API.Util.GetValByAPI(e, "SYNO.SynologyDrive.Settings", "list"),
                i = SYNO.API.Util.GetValByAPI(e, SYNO.SDS.CSTN.WebAPI.Config.api, "get"),
                n = Ext.apply(Ext.apply({}, i), t);
            this.getForm().findField("volume_select").getStore().loadData(n.volume_list), this.getForm().findField("warning").setVisible(!1), this.getForm().findField("displayname_select").setValue(n.default_displayname), this.getForm().findField("displayname_select").originalValue = n.default_displayname, this.getForm().setValues(n), n.support_moving_repository || this.getForm().findField("volume_select").setDisabled(!0);
            var s = this.getComponent("performanceSection");
            !s || s.hidden || n.display_vmtouch_option || (this.getComponent("performanceSection").hide(), this.doLayout())
        }
    },
    ajaxLoadFormCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.loadFormDoneSuccess,
            failure: SYNO.SDS.CSTN.webapiErrHdlMain
        })
    },
    loadForm: function() {
        this.owner.setStatusBusy(), this.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.SynologyDrive.Settings",
                    method: "list",
                    version: 2
                }, {
                    api: SYNO.SDS.CSTN.WebAPI.Config.api,
                    method: "get",
                    version: 1
                }]
            },
            callback: this.ajaxLoadFormCB,
            scope: this
        })
    },
    checkSrvStatusSuccess: function() {
        this.loadForm()
    },
    ajaxCheckSrvStatusCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.checkSrvStatusSuccess,
            failure: SYNO.SDS.CSTN.webapiErrHdl
        })
    },
    checkSrvStatus: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
    },
    setPollingTask: function(e) {
        void 0 !== this.polling_task && (this.polling_task.remove(), this.polling_task = void 0), e && (this.polling_task = this.addWebAPITask({
            interval: 2e3,
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".DBUsage",
            version: 1,
            method: "status",
            params: {},
            callback: this.updateUsage,
            scope: this
        }), this.polling_task.start(!0))
    },
    startTaskCB: function(e, t, i, n) {
        e || t.code == SYNO.SDS.CSTN.ErrorCode.DBUSAGE_TASK_RUNNING ? (this.setPollingTask(!0), Ext.getCmp(this.BtnDBUsageId).setText(_T("common", "cancel")), Ext.getCmp(this.BtnDBUsageId).setHandler(this.stopDBCalculateTask, this), this.doLayout()) : this._setUsageStatus("failed")
    },
    updateUsage: function(e, t, i, n) {
        !e || t.finish ? (this.finishPolling(), this.getCachedDBUsage()) : this._setUsageStatus("processing")
    },
    finishPolling: function() {
        this.setPollingTask(!1), Ext.getCmp(this.BtnDBUsageId).setText(_STR("btn", "db_usage_calculate")), Ext.getCmp(this.BtnDBUsageId).setHandler(this.startCalculateDBUsage, this), this.doLayout()
    },
    stopDBCalculateTask: function() {
        this.sendWebAPI({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".DBUsage",
            version: 1,
            method: "stop",
            params: {},
            scope: this
        })
    },
    startCalculateDBUsage: function() {
        this.sendWebAPI({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".DBUsage",
            version: 1,
            method: "start",
            params: {},
            callback: this.startTaskCB,
            scope: this
        })
    },
    getCachedDBUsageCB: function(e, t, i, n) {
        if (e) {
            if (!t.update_time) return void this._setUsageStatus("empty");
            var s = SYNO.SDS.CSTN.getFormatDateTime(new Date(1e3 * t.update_time)),
                o = SYNO.SDS.CSTN.CalculateSizeUnit(t.repo_size),
                a = SYNO.SDS.CSTN.CalculateSizeUnit(t.database_size),
                r = SYNO.SDS.CSTN.CalculateSizeUnit(t.office_size);
            this._setUsageStatus("done", s, o, a, r)
        } else this._setUsageStatus("failed")
    },
    getCachedDBUsage: function() {
        this.sendWebAPI({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".DBUsage",
            version: 1,
            method: "get",
            params: {},
            callback: this.getCachedDBUsageCB,
            scope: this
        })
    },
    onPageActivate: function() {
        this._S("is_admin") ? (this.loadForm(), this.getCachedDBUsage()) : this.checkSrvStatus(), this.clearRecycleMgr.fireEvent("activate"), this.transferHomeMgr.fireEvent("activate")
    },
    onPageDeactivate: function() {
        void 0 !== this.polling_task && (this.stopDBCalculateTask(), this.finishPolling()), this.clearRecycleMgr.fireEvent("deactivate"), this.transferHomeMgr.fireEvent("deactivate")
    },
    onActivate: function() {
        this.onPageActivate()
    },
    onDeactivate: function() {
        this.onPageDeactivate()
    },
    checkDirty: function() {
        return this.getForm().isDirty()
    },
    onSave: function() {
        return this.checkDirty() ? this.getForm().isValid() ? void this.applySetting() : void this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }) : void this.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        })
    },
    onCancel: function() {
        this.getForm().findField("warning").setVisible(!1), this.getForm().reset()
    },
    _updateSummeryBox: function(e, t, i, n) {
        var s = Ext.getCmp(this.summaryBoxId),
            o = Ext.getCmp(this.summaryBoxParent);
        if (!e) return o.setVisible(!1), void this.doLayout();
        s.update(this._getSummeryBoxContent(t, i, n)), o.setVisible(!0), this.doLayout()
    },
    _getSummeryBoxContent: function(e, t, i) {
        var n = "",
            s = '<p class="left-text">{0}</p> <p class="right-text">{1}</p>';
        return n += String.format(s, Ext.util.Format.htmlEncode(_STR("cstn", "usage_historical_version") + _T("common", "colon")), Ext.util.Format.htmlEncode(e)), n += "<br>", n += String.format(s, Ext.util.Format.htmlEncode(_STR("cstn", "usage_app_database") + _T("common", "colon")), Ext.util.Format.htmlEncode(t)), SYNO.SDS.CSTN.HasOffice() && (n += "<br>", n += String.format(s, Ext.util.Format.htmlEncode(_STR("cstn", "usage_synology_office") + _T("common", "colon")), Ext.util.Format.htmlEncode(i))), n
    },
    _setUsageStatus: function(e, t, i, n, s) {
        var o = this.getForm().findField("usage");
        o.removeClass("gray-text"), o.removeClass("blue-text"), o.removeClass("red-text"), "done" === e ? (o.setValue(t + " (" + _STR("cstn", "label_overview_db_last_caculated") + ")"), this._updateSummeryBox(!0, i, n, s)) : "processing" === e ? (o.addClass("blue-text"), o.setValue(_STR("func", "db_usage_calculating")), this._updateSummeryBox(!1)) : "failed" === e ? (o.addClass("red-text"), o.setValue(_STR("func", "db_usage_last_calculation_failed")), this._updateSummeryBox(!1)) : (o.addClass("gray-text"), o.setValue(_STR("func", "db_usage_not_calculated")), this._updateSummeryBox(!1))
    }
}), Ext.define("SYNO.SDS.CSTN.PanelDatabaseUtils.TransferHomeManager", {
    extend: "Ext.util.Observable",
    constructor: function(e) {
        Ext.apply(this, e), this.callParent(), this.addEvents(["activate", "deactivate"]), this.on("activate", this.onActivate, this), this.on("deactivate", this.onDeactivate, this)
    },
    onActivate: function() {
        this.disableComponents(), this.updateState()
    },
    onDeactivate: function() {
        this.stopPolling()
    },
    updateState: function() {
        this.owner.sendWebAPI({
            api: SYNO.SDS.CSTN.WebAPI.Migration.UserHome.api,
            version: 1,
            method: "status",
            params: {},
            callback: this.statusCB,
            scope: this
        })
    },
    statusCB: function(e, t, i, n) {
        e && ("none" === t.status ? (this.enabledComponents(), this.stopPolling()) : "in_progress" === t.status ? (this.onProgress(t.progress, t.from_user, t.to_user), this.startPolling()) : "finished" === t.status ? (this.owner.getMsgBox().alert(this.owner.title, String.format(_STR("cstn", "finished_transfer_msg"), t.from_user, t.to_user)), this.stopPolling(), this.clearComponents()) : "failed" === t.status && (this.owner.getMsgBox().alert(this.owner.title, _STR("cstn", "failed_transfer_msg")), this.stopPolling(), this.clearComponents()))
    },
    disableComponents: function() {
        this.fromUserCombo.setDisabled(!0), this.toUserCombo.setDisabled(!0), this.transferButton.setDisabled(!0), this.transferProgress.setVisible(!1)
    },
    enabledComponents: function() {
        this.fromUserCombo.setDisabled(!1), this.toUserCombo.setDisabled(!1), this.transferButton.setDisabled(!1), this.transferProgress.setVisible(!1)
    },
    clearComponents: function() {
        this.fromUserCombo.setDisabled(!1), this.fromUserCombo.setValue(""), this.fromUserCombo.clearInvalid(), this.toUserCombo.setDisabled(!1), this.toUserCombo.setValue(""), this.toUserCombo.clearInvalid(), this.transferButton.setDisabled(!1), this.transferProgress.reset(), this.transferProgress.setVisible(!1)
    },
    onProgress: function(e, t, i) {
        this.fromUserCombo.setDisabled(!0), this.fromUserCombo.setValue(t), this.fromUserCombo.clearInvalid(), this.toUserCombo.setDisabled(!0), this.toUserCombo.setValue(i), this.toUserCombo.clearInvalid(), this.transferButton.setDisabled(!0), this.transferProgress.updateProgress(e / 100, e + " %"), this.transferProgress.setVisible(!0)
    },
    transferCB: function(e, t, i, n) {
        if (!e) {
            var s = SYNO.SDS.CSTN.getErrorString(t);
            return this.owner.getMsgBox().alert(_STR("app", "app_name"), s), void(SYNO.SDS.CSTN.ErrorCode.TRANSFER_RUNNING === t.code ? this.startPolling() : (this.stopPolling(), this.enabledComponents()))
        }
        return this.statusCB(e, t, i, n)
    },
    startPolling: function() {
        this.stopPolling(), this.polling_task = setTimeout(this.updateState.bind(this), 2e3)
    },
    stopPolling: function() {
        this.polling_task && (clearTimeout(this.polling_task), this.polling_task = null)
    }
}), Ext.define("SYNO.SDS.CSTN.PanelDatabaseUtils.ClearRecycleManager", {
    extend: "Ext.util.Observable",
    constructor: function(e) {
        SYNO.Assert(e.stateDisplayField, "need stateDisplayField"), SYNO.Assert(e.clearRecycleBinBtn, "need clearRecycleBinBtn"), Ext.apply(this, e), this.callParent(), this.addEvents(["activate", "deactivate"]), this.on("activate", this.onActivate, this), this.on("deactivate", this.onDeactivate, this), this.clearRecycleBinBtn.on("click", this.onBtnClick, this)
    },
    onActivate: function() {
        this.updateState()
    },
    onDeactivate: function() {
        this.stopPolling()
    },
    onBtnClick: function() {
        this.owner.sendWebAPI({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".Node.Delete",
            version: 1,
            method: "start",
            params: {},
            callback: this.startCB,
            scope: this
        })
    },
    startCB: function(e, t, i, n) {
        if (e) this.setState("running"), this.startPolling();
        else {
            var s = SYNO.SDS.CSTN.getErrorString(t);
            this.owner.owner.getMsgBox().alert(_STR("app", "app_name"), s)
        }
    },
    updateState: function() {
        this.owner.sendWebAPI({
            api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".Node.Delete",
            version: 1,
            method: "status",
            params: {},
            callback: this.statusCB,
            scope: this
        })
    },
    statusCB: function(e, t, i, n) {
        if (!e) return void this.setState("error");
        t.total !== t.current ? (this.setState("running"), this.startPolling()) : this.setState("idle")
    },
    setState: function(e) {
        var t = "",
            i = !1;
        switch (e) {
            case "error":
                t = _STR("common", "error");
                break;
            case "running":
                t = _STR("common", "running"), i = !0;
                break;
            case "idle":
                t = _STR("common", "idle")
        }
        this.clearRecycleBinBtn.setDisabled(i), this.stateDisplayField.setValue(t)
    },
    startPolling: function() {
        this.stopPolling(), this.polling_task = setTimeout(this.updateState.bind(this), 2e3)
    },
    stopPolling: function() {
        this.polling_task && (clearTimeout(this.polling_task), this.polling_task = null)
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PanelSharingLink", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin, this.BtnApplyId = void 0, this.BtnCancelId = void 0, this.sharing_link_options = null;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "afterlayout", function() {
            var e = this.getForm();
            new SYNO.SDS.Utils.EnableCheckGroup(e, "enable_sharing_link_customization", ["sharing_link_customization", "customized_sharing_link_preview"]), new SYNO.ux.Utils.EnableRadioGroup(e, "sharing_level", {
                public: ["sharing_force_selected", "sharing_force_password", "sharing_force_expiration_checkbox"]
            }), new SYNO.SDS.Utils.EnableCheckGroup(e, "sharing_force_expiration_checkbox", ["sharing_force_expiration_text"])
        }, this, {
            single: !0
        })
    },
    fillConfig: function(e) {
        this.forceHTTPSSharingLink = new SYNO.ux.Checkbox({
            name: "force_https_sharing_link",
            boxLabel: _STR("setting", "force_https_sharing_link")
        }), this.enableCustomizedSharingLink = new SYNO.ux.Checkbox({
            name: "enable_sharing_link_customization",
            boxLabel: _STR("setting", "enable_sharing_link_customization")
        }), this.customizedSharingLinkOptions = new SYNO.ux.ComboBox({
            name: "sharing_link_customization",
            fieldLabel: _STR("setting", "sharing_link_domain"),
            indent: 1,
            ctCls: "syno-cstn-grid-combo",
            valueField: "option_id",
            displayField: "display",
            store: new Ext.data.JsonStore({
                fields: ["option_id", "display"],
                data: []
            }),
            forceSelection: !0,
            mode: "local",
            hideLabel: !1,
            selectOnFocus: !0,
            triggerAction: "all",
            editable: !1,
            hidden: !1,
            width: 300,
            validator: function(e) {
                if (null === this.sharing_link_options) return !0;
                for (var t = 0; t < this.sharing_link_options.length; t++)
                    if (this.sharing_link_options[t].display === e) return this.sharing_link_options[t].valid;
                return !1
            }.createDelegate(this),
            listeners: {
                scope: this,
                afterrender: function(e) {
                    SYNO.SDS.Utils.AddTip(e.el.dom, _STR("setting", "customized_sharing_link_options_tooltip"))
                },
                select: function(e, t) {
                    this.rearrangeSharingLinkComponent(t.data.option_id)
                },
                enable: function() {
                    this.rearrangeSharingLinkComponent()
                },
                disable: function() {
                    this.getForm().findField("sharing_link_fully_custom_url").setDisabled(!0)
                }
            }
        }), this.customizedSharingLinkPreview = new SYNO.ux.DisplayField({
            name: "customized_sharing_link_preview",
            value: "dummy",
            fieldLabel: _STR("setting", "customized_sharing_link_preview"),
            hidden: !0,
            indent: 1
        }), this.customizedSharingLinkInputField = new SYNO.ux.TextField({
            name: "sharing_link_fully_custom_url",
            fieldLabel: _STR("setting", "sharing_link_last_fully_custom_url"),
            emptyText: "https://example.com",
            validator: function(e) {
                return url_regex_str = ["^(", "(?:(?:http|https):\\/\\/)?", "(?:((?!\\/)\\S)+(?::((?!\\/)\\S)*)?@)?", "(?:", "(?:", "\\[(?:", "([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|", "([0-9a-fA-F]{1,4}:){1,7}:|", "([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|", "([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|", "([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|", "([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|", "([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|", "[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|", ":((:[0-9a-fA-F]{1,4}){1,7}|:)|", "fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|", "::(ffff(:0{1,4}){0,1}:){0,1}", "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|", "([0-9a-fA-F]{1,4}:){1,4}:", "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])", ")\\]|", "((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])", ")|", "(?:", "(?:[a-zA-Z0-9][a-zA-Z0-9_-]*)", "(?:", "(?:\\.[a-zA-Z0-9][a-zA-Z0-9_-]*)*", "(?:\\.[a-zA-Z]{2,})", ")?", ")", ")", "(?::\\d{2,5})?", "(?:\\/[^\\s]*)?", ")$"].join(""), new RegExp(url_regex_str).test(e)
            },
            hidden: !0,
            indent: 1
        }), this.customizedSharingLinkInputField.setWidth(300), this.selectedButtonId = Ext.id(), this.selectedTextId = Ext.id(), this.selectedCheckboxId = Ext.id(), this.selectedUids = [], this.selectedGids = [], this.firstPanel = [{
            xtype: "syno_displayfield",
            value: _STR("cstn", "sharing_permissions")
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "public_sharing_title"),
            name: "sharing_level",
            inputValue: "public",
            indent: 1,
            handler: function(e, t) {
                t ? (this.enableSharingInternalLevel(!0), this.enableSharingSelected(!0)) : this.enableSharingSelected(!1)
            }.bind(this)
        }, {
            xtype: "syno_checkbox",
            boxLabel: _STR("cstn", "allow_selected_to_share"),
            name: "sharing_force_selected",
            indent: 2,
            id: this.selectedCheckboxId,
            handler: function(e, t) {
                !0 === t ? (e.setValue(!0), Ext.getCmp(this.selectedButtonId).setDisabled(!1)) : (e.setValue(!1), Ext.getCmp(this.selectedButtonId).setDisabled(!0), this.updateSelectedUid([]), this.updateSelectedGid([])), this.updateSelectedText()
            }.bind(this)
        }, {
            xtype: "syno_panel",
            layout: "table",
            bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 2px 0px 2px 84px;" : "padding: 2px 0px 2px 96px;",
            items: [{
                xtype: "syno_button",
                name: "sharing_force_selected_button",
                inputValue: "fifo",
                text: _STR("common", "edit"),
                style: "margin-right: 32px !important;",
                id: this.selectedButtonId,
                handler: function() {
                    new SYNO.SDS.CSTN.Sharing.DialogSelectionEdit({
                        owner: this.owner,
                        panel: this
                    }).open()
                }.bind(this)
            }, {
                xtype: "syno_displayfield",
                name: "sharing_force_selected_text",
                value: _STR("cstn", "no_selection"),
                style: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding-top: 0px;" : "",
                id: this.selectedTextId
            }]
        }, {
            xtype: "syno_checkbox",
            boxLabel: _STR("cstn", "force_password"),
            name: "sharing_force_password",
            indent: 2
        }, {
            xtype: "syno_checkbox",
            boxLabel: _STR("cstn", "force_expired"),
            name: "sharing_force_expiration_checkbox",
            indent: 2,
            handler: function(e, t) {
                var i = this.getForm().findField("sharing_force_expiration_text");
                t ? i.setValue("30") : i.setValue("")
            }.bind(this)
        }, {
            xtype: "syno_panel",
            bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 2px 0px 2px 84px;" : "padding: 2px 0px 2px 96px;",
            layout: {
                type: "table"
            },
            items: [{
                xtype: "syno_displayfield",
                value: _STR("cstn", "max_force_expired_days"),
                style: "margin-right: 32px;"
            }, {
                xtype: "syno_textfield",
                value: "30",
                width: 100,
                style: "margin-right: 8px;",
                name: "sharing_force_expiration_text",
                invalidText: String.format(_STR("cstn", "max_force_expired_days_invaild_text"), 1, 999),
                validator: function(e) {
                    if (!this.getForm().findField("sharing_force_expiration_checkbox").checked) return !0;
                    var t = parseInt(e, 10);
                    return t > 0 && t <= 999
                }.bind(this)
            }]
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "internal_sharing_title"),
            name: "sharing_level",
            inputValue: "internal",
            indent: 1,
            handler: function(e, t) {
                t && (this.enableSharingInternalLevel(!0), this.enableSharingSelected(!1))
            }.bind(this)
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "disallow_sharing_title"),
            name: "sharing_level",
            inputValue: "disallow",
            indent: 1,
            handler: function(e, t) {
                t && (this.enableSharingInternalLevel(!1), this.enableSharingSelected(!1))
            }.bind(this)
        }], this.secondPanel = [{
            xtype: "syno_displayfield",
            value: _STR("cstn", "internel_sharing_rule"),
            name: "sharing_internal_level_panel"
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "internal_sharing_both"),
            name: "sharing_internal_level",
            inputValue: "both",
            indent: 1
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "internal_sharing_link"),
            name: "sharing_internal_level",
            inputValue: "link",
            indent: 1
        }, {
            xtype: "syno_radio",
            boxLabel: _STR("cstn", "internal_sharing_invite"),
            name: "sharing_internal_level",
            inputValue: "invite",
            indent: 1
        }];
        var t = {
            labelAlign: "left",
            labelWidth: 150,
            border: !1,
            itemId: "configure-sharing-link",
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_fieldset",
                title: _STR("cstn", "sharing_setting_for_non_admin"),
                items: [this.firstPanel, this.secondPanel]
            }, {
                xtype: "syno_fieldset",
                cls: "syno-cstn-sharing-link-field",
                title: _STR("drive", "custom_sharing_link_url"),
                labelWidth: "220",
                items: [this.forceHTTPSSharingLink, this.enableCustomizedSharingLink, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: _STR("drive", "customized_sharing_link_desc"),
                    indent: 1
                }, this.customizedSharingLinkOptions, this.customizedSharingLinkPreview, this.customizedSharingLinkInputField, {
                    xtype: "syno_displayfield",
                    name: "sharing_link_note",
                    htmlEncode: !1,
                    value: '<span class="syno-ux-note">' + _STR("common", "note") + _STR("common", "colon") + " </span>" + _STR("drive", "customized_sharing_link_note"),
                    indent: 1
                }]
            }],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "commit"),
                itemId: "apply",
                id: this.BtnApplyId = Ext.id(),
                scope: this,
                handler: this.onSave
            }, {
                xtype: "syno_button",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "reset"),
                itemId: "cancel",
                id: this.BtnCancelId = Ext.id(),
                scope: this,
                handler: this.onCancel
            }]
        };
        return SYNO.SDS.CSTN.IsDSM7OrAbove() && t.buttons.reverse(), t = this.addStatusBar(t), SYNO.LayoutConfig.fill(t), Ext.apply(t, e), t
    },
    getSelectedUid: function() {
        return this.selectedUids
    },
    getSelectedGid: function() {
        return this.selectedGids
    },
    updateSelectedUid: function(e) {
        this.selectedUids = e, this.updateSelectedText()
    },
    updateSelectedGid: function(e) {
        this.selectedGids = e, this.updateSelectedText()
    },
    updateSelectedText: function() {
        var e = Ext.getCmp(this.selectedTextId);
        return !0 !== Ext.getCmp(this.selectedCheckboxId).getValue() ? void e.setVisible(!1) : this.selectedUids.length > 0 || this.selectedGids.length > 0 ? void e.setVisible(!1) : void e.setVisible(!0)
    },
    enableFormItem: function(e, t) {
        for (var i = 0; i < this.getForm().items.items.length; i++) this.getForm().items.items[i].name === e && this.getForm().items.items[i].setDisabled(!t)
    },
    enableSharingInternalLevel: function(e) {
        this.enableFormItem("sharing_internal_level", e)
    },
    enableSharingSelected: function(e) {
        var t = !0;
        !1 !== e && !1 !== Ext.getCmp(this.selectedCheckboxId).getValue() || (t = !1),
            Ext.getCmp(this.selectedButtonId).setDisabled(!t), this.enableFormItem("sharing_force_selected_text", !t)
    },
    addStatusBar: function(e) {
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: []
        };
        return e.buttons && (t.items = t.items.concat(e.buttons), delete e.buttons), Ext.applyIf(e, {
            fbar: t
        }), e
    },
    applyFormFail: function(e) {
        var t = "";
        switch (errinfo = SYNO.API.Util.GetFirstError(e), errinfo.code) {
            case SYNO.SDS.CSTN.ErrorCode.NO_SUCH_API:
            case SYNO.SDS.CSTN.ErrorCode.PKG_NOT_ENABLED:
            case SYNO.SDS.CSTN.ErrorCode.SERVICE_DISABLED:
            case SYNO.SDS.CSTN.ErrorCode.ADMIN_ONLY:
            case SYNO.SDS.CSTN.ErrorCode.SYS_DISK_FULL:
            case SYNO.SDS.CSTN.ErrorCode.REPO_MOVE:
            case SYNO.SDS.CSTN.ErrorCode.CANNOT_ACCESS:
                return this.onCancel(), void SYNO.SDS.CSTN.webapiErrHdlMain.apply(this, [errinfo]);
            default:
                t = SYNO.SDS.CSTN.getErrorString(errinfo)
        }
        this.owner.getMsgBox().alert(_STR("app", "app_name"), t), this.loadForm()
    },
    applyFormSuccess: function() {
        this.owner.setStatusOK(), this.setStatusOK({
            text: _T("common", "setting_applied"),
            clear: !0
        }), this.loadForm()
    },
    ajaxApplyFormCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.applyFormSuccess,
            failure: this.applyFormFail
        })
    },
    getRadioResult: function(e) {
        for (var t = 0; t < this.getForm().items.items.length; t++) {
            var i = this.getForm().items.items[t];
            if (i.name === e && i.checked) return i.inputValue
        }
    },
    getRadioIsDirty: function(e) {
        for (var t = 0; t < this.getForm().items.items.length; t++) {
            var i = this.getForm().items.items[t];
            if (i.name === e && i.isDirty()) return !0
        }
        return !1
    },
    setSelectedFieldDirty: function() {
        this.selectSelectedFieldDirty = !0
    },
    isSelectedFieldDirty: function() {
        return !0 === this.selectSelectedFieldDirty
    },
    resetSelectedField: function() {
        this.selectSelectedFieldDirty = void 0, this.selectedUids = this.oldSelectedUid, this.selectedGids = this.oldSelectedGid, this.updateSelectedText()
    },
    applySetting: function() {
        var e = this.getForm(),
            t = e.findField("sharing_force_selected"),
            i = e.findField("sharing_force_password"),
            n = e.findField("sharing_force_expiration_checkbox"),
            s = e.findField("sharing_force_expiration_text"),
            o = e.findField("force_https_sharing_link"),
            a = e.findField("enable_sharing_link_customization"),
            r = e.findField("sharing_link_customization"),
            l = e.findField("sharing_link_fully_custom_url"),
            d = _STR("common", "saving"),
            c = [];
        this.owner.setStatusBusy({
            text: d
        }), (this.getRadioIsDirty("sharing_level") || this.getRadioIsDirty("sharing_internal_level") || t.isDirty() || this.isSelectedFieldDirty() || i.isDirty() || n.isDirty() || n.checked && s.isDirty() || o.isDirty() || a.isDirty() || r.isDirty() || l.isDirty()) && c.push({
            api: "SYNO.SynologyDrive.Settings",
            method: "update",
            version: 2,
            params: {
                sharing_level: this.getRadioResult("sharing_level"),
                sharing_internal_level: this.getRadioResult("sharing_internal_level"),
                sharing_force_selected: t.getValue(),
                sharing_force_password: i.getValue(),
                sharing_force_expiration: n.checked && parseInt(s.getValue(), 10) >= 0 ? parseInt(s.getValue(), 10) : 0,
                force_https_sharing_link: o.getValue(),
                enable_sharing_link_customization: a.getValue(),
                sharing_link_customization: r.getValue(),
                sharing_link_fully_custom_url: l.getValue(),
                sharing_force_selected_users: this.getSelectedUid(),
                sharing_force_selected_groups: this.getSelectedGid()
            }
        }), this.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: c
            },
            callback: this.ajaxApplyFormCB,
            scope: this
        })
    },
    loadFormDoneSuccess: function(e) {
        if (!this.isDestroyed) {
            var t = SYNO.API.Util.GetValByAPI(e, "SYNO.SynologyDrive.Settings", "list");
            this.sharing_link_options = t.sharing_link_options;
            for (var i = [], n = 0; n < this.sharing_link_options.length; n++) this.sharing_link_options[n].display = _STR("setting", "sharing_url_type_" + this.sharing_link_options[n].option_id), this.sharing_link_options[n].valid ? i.push(this.sharing_link_options[n]) : t.sharing_link_customization === this.sharing_link_options[n].option_id && (t.sharing_link_customization = this.sharing_link_options[n].display);
            this.getForm().findField("sharing_link_customization").getStore().loadData(i);
            var s = t.sharing_force_expiration;
            s > 0 ? (this.getForm().setValues({
                sharing_force_expiration_checkbox: !0
            }), this.getForm().setValues({
                sharing_force_expiration_text: s
            })) : (this.getForm().setValues({
                sharing_force_expiration_checkbox: !1
            }), this.getForm().setValues({
                sharing_force_expiration_text: ""
            })), this.getForm().setValues(t), "" === t.sharing_link_customization && i.length > 0 ? (this.getForm().setValues({
                sharing_link_customization: i[0].option_id
            }), this.rearrangeSharingLinkComponent(i[0].option_id)) : this.rearrangeSharingLinkComponent(t.sharing_link_customization), this.oldSelectedUid = t.sharing_force_selected_users, this.oldSelectedGid = t.sharing_force_selected_groups, this.resetSelectedField()
        }
    },
    ajaxLoadFormCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.loadFormDoneSuccess,
            failure: SYNO.SDS.CSTN.webapiErrHdlMain
        })
    },
    loadForm: function() {
        this.owner.setStatusBusy(), this.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.SynologyDrive.Settings",
                    method: "list",
                    version: 2
                }]
            },
            callback: this.ajaxLoadFormCB,
            scope: this
        })
    },
    checkSrvStatusSuccess: function() {
        this.loadForm()
    },
    ajaxCheckSrvStatusCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.checkSrvStatusSuccess,
            failure: SYNO.SDS.CSTN.webapiErrHdl
        })
    },
    checkSrvStatus: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
    },
    onPageActivate: function() {
        this._S("is_admin") ? this.loadForm() : this.checkSrvStatus()
    },
    onActivate: function() {
        this.onPageActivate()
    },
    onPageDeactivate: function() {},
    onDeactivate: function() {
        this.onPageDeactivate()
    },
    checkDirty: function() {
        return this.getForm().isDirty() || this.isSelectedFieldDirty()
    },
    onSave: function() {
        return this.checkDirty() ? this.getForm().isValid() ? void this.applySetting() : void this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }) : void this.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        })
    },
    onCancel: function() {
        this.getForm().reset(), this.resetSelectedField(), this.rearrangeSharingLinkComponent()
    },
    rearrangeSharingLinkComponent: function(e) {
        var t = this.getForm().findField("sharing_link_customization");
        e = e || t.getValue();
        var i = this.getForm().findField("customized_sharing_link_preview"),
            n = this.getForm().findField("sharing_link_note"),
            s = this.getForm().findField("sharing_link_fully_custom_url");
        if ("fully_customized" != e) {
            for (var o = 0; o < this.sharing_link_options.length; o++) this.sharing_link_options[o].option_id === e && this.getForm().setValues({
                customized_sharing_link_preview: this.sharing_link_options[o].preview
            });
            i.setVisible(!0), n.setVisible(!0), s.setVisible(!1), s.setDisabled(!0)
        } else i.setVisible(!1), n.setVisible(!1), s.setVisible(!0), t.disabled || s.setDisabled(!1);
        this.doLayout()
    }
}), Ext.define("SYNO.SDS.CSTN.Sharing.DialogSelectionEdit", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.win = e.owner, this.panel = e.panel;
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "blue",
                hidden: !1,
                text: _T("common", "commit"),
                itemId: "apply",
                id: this.BtnApplyId = Ext.id(),
                scope: this,
                handler: this.onSave
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                hidden: !1,
                text: _T("common", "cancel"),
                itemId: "cancel",
                id: this.BtnCancelId = Ext.id(),
                scope: this,
                handler: this.onCancel
            }]
        };
        SYNO.SDS.CSTN.IsDSM7OrAbove() && t.items.reverse(), this.callParent([Ext.apply({
            title: _STR("cstn", "select_user_group"),
            width: 500,
            height: 506,
            padding: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "16px 20px 12px 20px" : "0px 20px 0px 20px",
            resizable: !1,
            autoScroll: !0,
            cls: "syno-cstn-sharing-link-user-window",
            layout: "fit",
            bodyStyle: "padding: 5px 5px 0px 5px;",
            items: [{
                xtype: "cstn_sharing_selection",
                itemId: "selection_apply",
                panel: e.panel,
                owner: e.owner,
                win: this
            }],
            fbar: t
        }, e)])
    },
    winShow: function() {
        this.open()
    },
    onCancel: function() {
        this.close()
    },
    onSave: function() {
        this.get("selection_apply").saveModification();
        var e = this.get("selection_apply").cachedSelectedUids,
            t = this.get("selection_apply").cachedSelectedGids;
        this.panel.updateSelectedUid(e), this.panel.updateSelectedGid(t), this.get("selection_apply").isDirty() && this.panel.setSelectedFieldDirty(), this.close()
    }
}), Ext.define("SYNO.SDS.CSTN.Sharing.PanelSelection", {
    extend: "SYNO.ux.EditorGridPanel",
    xtype: "cstn_sharing_selection",
    constructor: function(e) {
        this.owner = e.owner, this.win = e.win, this.panel = e.panel, this.callParent([this.fillConfig(e)]), this.cachedSelectedUids = this.panel.getSelectedUid().slice(), this.cachedSelectedGids = this.panel.getSelectedGid().slice(), this.type_combo = this.getTopToolbar().getComponent("typeCombo"), this.fillTypeCombo(), this.mon(this.type_combo, "select", this.onUserTypeSelect, this)
    },
    fillConfig: function(e) {
        var t = new SYNO.ux.EnableColumn({
                header: _STR("common", "enable"),
                dataIndex: "enable",
                defaultValue: !1,
                align: "center",
                width: 110
            }),
            i = [t, {
                header: _STR("showdel", "attr_name"),
                dataIndex: "name",
                align: "left",
                width: 250,
                sortable: !0
            }],
            n = new Ext.grid.ColumnModel({
                columns: i
            }),
            s = this.createTargetStore();
        this.paging_bar = new SYNO.ux.PagingToolbar({
            cls: "cstn-paging-toolbar syno-cstn-sharinglink-toolbar",
            store: s,
            pageSize: 100,
            style: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "" : "border-width: 1px 0px 1px 0px;",
            diplayInfo: !0
        }), this.findField = new SYNO.ux.TextFilter({
            itemId: "search",
            emptyText: _STR("btn", "search"),
            listeners: {
                keyup: {
                    scope: this,
                    fn: function(e) {
                        this.saveModification(), this.getStore().baseParams.substr = e.getValue(), this.getStore().load()
                    },
                    buffer: 300
                },
                afterrender: {
                    scope: this,
                    single: !0,
                    fn: function(e) {
                        e.mon(e.trigger, "click", function() {
                            this.saveModification(), this.getStore().baseParams.substr = e.getValue(), this.getStore().load()
                        }, this)
                    }
                }
            }
        }), this.noteBar = {
            xtype: "syno_displayfield",
            cls: "syno-cstn-sharing-setting-toolbar",
            html: '<span class="sharing-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _STR("cstn", "select_public_sharing_desc")
        };
        var o = {
            layout: "fit",
            border: "false",
            cm: n,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !1
            }),
            enableColLock: !1,
            enableHdMenu: !1,
            enableColumnMove: !1,
            loadMask: !0,
            plugins: [t],
            store: s,
            bbar: {
                autoHeight: !0,
                cls: "syno-cstn-sharing-setting-bbar",
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                items: [this.paging_bar, this.noteBar]
            },
            listeners: {
                scope: this,
                afterrender: function() {
                    this.getStore().load()
                }
            },
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: "syno_combobox",
                    itemId: "typeCombo",
                    displayField: "display",
                    valueField: "index",
                    value: 0,
                    labelStyle: "margin-left: 0 !important",
                    width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 220 : 200,
                    store: new Ext.data.JsonStore({
                        fields: ["display", "type", "value", "content_type", "index"],
                        data: [{
                            display: _STR("cstn", "local_user"),
                            type: "local",
                            value: "",
                            index: 0,
                            content_type: "user"
                        }]
                    })
                }, "->", this.findField]
            })
        };
        return Ext.apply(o, e)
    },
    createTargetStore: function() {
        var e = ["name", "id", "type", "enable"],
            t = new SYNO.API.Store({
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.SynologyDrive.Settings",
                    version: 2,
                    method: "list_targets",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "list",
                    totalProperty: "total"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit"
                },
                baseParams: {
                    offset: 0,
                    limit: 100,
                    type: "local",
                    domain_name: "",
                    content_type: "user",
                    substr: ""
                },
                remoteSort: !1,
                listeners: {
                    scope: this,
                    beforeload: this.onPageChange,
                    load: function() {
                        var e = this.type_combo.getStore(),
                            i = e.find(this.type_combo.valueField, this.type_combo.getValue());
                        if (-1 != i) {
                            content_type = e.getAt(i).get("content_type");
                            var n = [];
                            "user" === content_type ? n = this.cachedSelectedUids : "group" === content_type && (n = this.cachedSelectedGids), n.length && t.each(function(e) {
                                var t = e.get("id"); - 1 !== n.indexOf(t) && e.set("enable", !0)
                            }.bind(this)), t.commitChanges()
                        }
                    },
                    exception: function(e, t, i, n, s) {
                        s && s.code && this.win.getMsgBox().alert(_STR("app", "app_name"), SYNO.SDS.CSTN.getErrorString(s))
                    }
                }
            });
        return t
    },
    saveModification: function() {
        var e = this.getStore().getModifiedRecords();
        return e.length > 0 && (this.dirty = !0, Ext.each(e, function(e) {
            var t = e.get("type"),
                i = e.get("id");
            if (i <= 0 || !t) return !0;
            var n = [];
            if ("user" === t ? n = this.cachedSelectedUids : "group" === t && (n = this.cachedSelectedGids), !0 === e.get("enable")) n.push(i);
            else
                for (var s = n.length - 1; s >= 0; s--)
                    if (n[s] === i) return n.splice(s, 1), !0
        }.bind(this)), this.getStore().commitChanges()), e && e.length > 0
    },
    isDirty: function() {
        var e = this.getStore().getModifiedRecords();
        return this.dirty || e > 0
    },
    onUserTypeSelect: function(e, t) {
        this.saveModification();
        var i = this.getStore();
        Ext.apply(i.baseParams, {
            domain_name: t.get("value"),
            type: t.get("type"),
            content_type: t.get("content_type")
        }), i.load()
    },
    fillTypeCombo: function() {
        SYNO.SDS.CSTN.WebAPI.getDirSrvStatus.call(this.win, function(e, t) {
            if (e) {
                var i = [{
                        display: _STR("cstn", "local_user"),
                        type: "local",
                        value: "",
                        index: 0,
                        content_type: "user"
                    }, {
                        display: _STR("cstn", "local_group"),
                        type: "local",
                        value: "",
                        index: 1,
                        content_type: "group"
                    }],
                    n = 2;
                Ext.each(t.domain_names, function(e) {
                    var t = "-",
                        s = "-";
                    "ldap" === e.type ? (t = _STR("cstn", "ldap_user"), s = _STR("cstn", "ldap_group")) : "domain" === e.type && (t = _STR("cstn", "domain_user") + " (" + e.value + ")", s = _STR("cstn", "domain_group") + " (" + e.value + ")"), i.push({
                        display: t,
                        type: e.type,
                        value: e.value,
                        index: n++,
                        content_type: "user"
                    }), i.push({
                        display: s,
                        type: e.type,
                        value: e.value,
                        index: n++,
                        content_type: "group"
                    })
                }), this.type_combo.getStore().loadData(i, !1)
            } else this.win.getMsgBox().alert(_STR("app", "app_name"), _T("common", "error_system"))
        }, this)
    },
    onPageChange: function(e, t) {
        this.saveModification() && this.getStore().load(t)
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.ns("SYNO.SDS.CSTN.PROFILE"), SYNO.SDS.CSTN.PROFILE.STATUS_COL_WIDTH = 150, SYNO.SDS.CSTN.PROFILE.CHECKBOX_COL_WIDTH = 110, SYNO.SDS.CSTN.PROFILE.USERNAME_COL_WIDTH = 250, SYNO.SDS.CSTN.RenderUserType = function(e) {
    return "local" === e ? _T("share", "share_local_user") : "ldap" === e ? _T("share", "ldap_user") : "domain" === e ? _T("app_privilege", "domain_user") : "invalid_user_type"
}, Ext.define("SYNO.SDS.CSTN.PROFILE.PanelProfileApply", {
    extend: "SYNO.ux.EditorGridPanel",
    xtype: "cstn_profile_apply",
    constructor: function(e) {
        this.owner = e.owner, this.win = e.win, this.callParent([this.fillConfig(e)]), this.profile_info || (this.profile_info = {}, this.profile_info.profile_applied = []), this.type_combo = this.getTopToolbar().getComponent("userTypeCombo"), this.mon(this.type_combo, "select", this.onUserTypeSelect, this), this.mon(this, "activate", this.fillUserTypeCombo, this)
    },
    fillConfig: function(e) {
        var t = new SYNO.ux.EnableColumn({
                header: _STR("common", "enable"),
                dataIndex: "user_enable",
                align: "center",
                width: SYNO.SDS.CSTN.PROFILE.CHECKBOX_COL_WIDTH
            }),
            i = [t, {
                id: "user_name",
                header: _STR("common", "usrname"),
                dataIndex: "name",
                align: "left",
                width: SYNO.SDS.CSTN.PROFILE.USERNAME_COL_WIDTH,
                sortable: !0
            }, {
                id: "user_type",
                header: _STR("common", "user_type"),
                dataIndex: "user_type",
                align: "left",
                width: SYNO.SDS.CSTN.PROFILE.STATUS_COL_WIDTH,
                renderer: SYNO.SDS.CSTN.RenderUserType,
                sortable: !0
            }],
            n = new Ext.grid.ColumnModel({
                columns: i
            }),
            s = this.createUserStore();
        this.paging_bar = new SYNO.ux.PagingToolbar({
            cls: "cstn-paging-toolbar",
            store: s,
            pageSize: 100,
            displayInfo: !1
        });
        var o = {
            itemId: "cstn_profile_apply_tab",
            title: _STR("profile", "profile_applied"),
            layout: "fit",
            border: "false",
            cm: n,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: !1
            }),
            enableColLock: !1,
            enableHdMenu: !1,
            enableColumnMove: !1,
            loadMask: !0,
            plugins: [t],
            store: s,
            bbar: this.paging_bar,
            listeners: {
                scope: this,
                afterrender: function() {
                    this.getStore().load()
                }
            },
            tbar: new Ext.Toolbar({
                items: [{
                    xtype: "syno_combobox",
                    itemId: "userTypeCombo",
                    displayField: "display",
                    valueField: "value",
                    value: "",
                    labelStyle: "margin-left: 0 !important",
                    width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 220 : 200,
                    store: new Ext.data.JsonStore({
                        fields: ["display", "type", "value"],
                        data: [{
                            display: _T("share", "share_local_user"),
                            type: "local",
                            value: ""
                        }]
                    })
                }]
            })
        };
        return Ext.apply(o, e)
    },
    createUserStore: function() {
        var e = ["name"],
            t = new SYNO.API.Store({
                pruneModifiedRecords: !0,
                autoLoad: !1,
                proxy: new SYNO.API.Proxy({
                    api: SYNO.SDS.CSTN.WEBAPI_NAMESPACE + ".Privilege",
                    version: 1,
                    method: "list",
                    appWindow: this.owner
                }),
                reader: new Ext.data.JsonReader({
                    root: "users",
                    totalProperty: "total",
                    id: "id"
                }, e),
                paramNames: {
                    start: "offset",
                    limit: "limit"
                },
                baseParams: {
                    offset: 0,
                    limit: 100,
                    type: "local",
                    domain_name: ""
                },
                remoteSort: !1,
                listeners: {
                    scope: this,
                    beforeload: this.onPageChange,
                    load: function() {
                        var e = this.type_combo.getStore(),
                            i = e.find(this.type_combo.valueField, this.type_combo.getValue()),
                            n = "local";
                        if (-1 != i && (n = e.getAt(i).get("type")), t.each(function(e) {
                                e.set("user_type", n), e.set("user_enable", !1)
                            }), this.profile_info.profile_applied.length) {
                            var s = [];
                            Ext.each(this.profile_info.profile_applied, function(e) {
                                s.push(e.user_name)
                            }), t.each(function(e) {
                                var t = e.get("name"); - 1 !== s.indexOf(t, 0) && e.set("user_enable", !0)
                            })
                        }
                        t.commitChanges()
                    },
                    exception: function(e, t, i, n, s) {
                        s && s.code && this.win.getMsgBox().alert(_STR("app", "app_name"), SYNO.SDS.CSTN.getErrorString(s))
                    }
                }
            });
        return t
    },
    getSetting: function() {
        var e = this.profile_info.profile_applied.slice(),
            t = this.getStore().getModifiedRecords();
        return t.length > 0 && (this.dirty = !0, Ext.each(t, function(t) {
            var i = t.get("name");
            if (!0 === t.get("user_enable")) e.splice(-1, 0, {
                user_name: t.get("name")
            });
            else
                for (var n = e.length - 1; n >= 0; n--) e[n].user_name === i && e.splice(n, 1)
        })), e = e.sort(function(e, t) {
            return e.user_name.toLowerCase() > t.user_name.toLowerCase()
        })
    },
    isDirty: function() {
        var e = this.getStore().getModifiedRecords();
        return this.dirty || e > 0
    },
    onUserTypeSelect: function(e, t) {
        var i = this.getStore();
        Ext.apply(i.baseParams, {
            domain_name: t.get("value"),
            type: t.get("type")
        }), i.load()
    },
    fillUserTypeCombo: function() {
        SYNO.SDS.CSTN.WebAPI.getDirSrvStatus.call(this.win, function(e, t) {
            e ? this.type_combo.getStore().loadData([{
                display: _T("share", "share_local_user"),
                type: "local",
                value: ""
            }].concat(t.domain_names), !1) : this.win.getMsgBox().alert(_STR("app", "app_name"), _T("common", "error_system"))
        }, this)
    },
    onPageChange: function(e, t) {
        if (this.getStore().getModifiedRecords().length) return this.win.getMsgBox().confirm(_STR("app", "app_name"), _T("share", "share_save_chg_before_reload"), function(e) {
            return "yes" == e && (this.profile_info.profile_applied = this.getSetting()), this.getStore().rejectChanges(), this.getStore().load(t), !0
        }, this), !1
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanel.BaseTree", {
    extend: "SYNO.ux.TreePanel",
    constructor: function(e) {
        var t = Ext.apply({
            useArrows: !0,
            autoScroll: !0,
            containerScroll: !0,
            bodyStyle: "overflow-x: hidden;overflow-y:auto; padding-right: 12px;",
            enableDD: !1
        }, e);
        return this.callParent([t])
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanel.SelectiveFile", {
    extend: "SYNO.SDS.CloudStation.Component.ExtendedTreePanel.BaseTree",
    constructor: function(e) {
        var t = Ext.apply({
            useArrows: !0,
            autoScroll: !0,
            containerScroll: !0,
            bodyStyle: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "overflow-x: hidden; overflow-y: auto; padding-top: 0px; padding-right: 2px; padding-left: 0px" : "overflow-x: hidden;overflow-y:auto; padding-right: 12px;",
            enableDD: !1,
            root: new Ext.tree.TreeNode
        }, e);
        return this.callParent([t])
    },
    initEvents: function() {
        var e = this.callParent(arguments);
        return this.mon(this, "checkchange", this.onCheckChange, this), e
    },
    get_state_by_children: function(e) {
        var t = 0,
            i = 0,
            n = 0;
        return e.eachChild(function(e) {
            var s = e.getUI() || {};
            !s.checkbox || !Ext.isFunction(s.getCheckValue) || Ext.isFunction(s.isDisabled) && s.isDisabled() || (!0 === s.getCheckValue() ? i += 1 : !1 === s.getCheckValue() && (n += 1), t += 1)
        }), "other" == e.attributes.node_type ? t == i || "gray" : 0 === t ? e.getUI().getCheckValue() : i === t || n !== t && "gray"
    },
    propagate_down: function(e, t) {
        !0 === t ? e.eachChild(function(e) {
            var t = e.getUI();
            !t || !Ext.isFunction(t.setCheckValue) || Ext.isFunction(t.isDisabled) && t.isDisabled() || t.setCheckValue(!0)
        }, this) : !1 === t && e.eachChild(function(e) {
            var t = e.getUI();
            t && Ext.isFunction(t.setCheckValue) && t.setCheckValue(!1)
        }, this)
    },
    set_pnode_checked: function(e) {
        var t = e.getUI();
        t && Ext.isFunction(t.getCheckValue) && (e.attributes.checked = this.get_state_by_children(e), t.syncCheckCssClass())
    },
    propagate_up: function(e, t) {
        for (; e;) this.set_pnode_checked(e), e = e.parentNode
    },
    onCheckChange: function(e, t) {
        this.propagate_down(e, t), this.propagate_up(e.parentNode)
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanelUI", {
    extend: "Ext.tree.TreeNodeUI",
    renderElements: function(e, t, i, n) {
        this.indentMarkup = e.parentNode ? e.parentNode.ui.getChildIndent() : "";
        var s, o = Ext.isBoolean(t.checked) || "gray" === t.checked,
            a = Ext.isBoolean(t.hide_checkbox) && !0 === t.hide_checkbox,
            r = Ext.isString(t.rimgCls),
            l = Ext.util.Format.htmlEncode,
            d = t.input,
            c = this.getHref(t.href),
            h = ['<li class="x-tree-node syno-extended-tree-node"><div ext:tree-node-id="', l(e.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', t.cls, '" unselectable="on">', r ? '<img alt="" src="' + this.emptyIcon + '" class= "' + t.rimgCls + '" style="float: right" />' : "", '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', o ? '<img alt="" src="' + this.emptyIcon + '"' + (a ? ' style="display: none;"' : "") + ' class="syno-tree-node-cb syno-ux-checkbox-icon" />' : "", '<img alt="" src="', t.icon || this.emptyIcon, '" class="x-tree-node-icon', t.icon ? " x-tree-node-inline-icon" : "", t.iconCls ? " " + t.iconCls : "", '" unselectable="on" ', (t.icon || t.iconCls ? "" : 'style="display: none;"') + "/>", t.icon || t.iconCls ? "<span>&nbsp</span>" : "", '<a hidefocus="on" class="x-tree-node-anchor" href="', c, '" tabIndex="1" ', t.hrefTarget ? ' target="' + t.hrefTarget + '"' : "", '><span unselectable="on">', Ext.util.Format.htmlEncode(e.text), "</span></a>", "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        !0 !== n && e.nextSibling && (s = e.nextSibling.ui.getEl()) ? this.wrap = Ext.DomHelper.insertHtml("beforeBegin", s, h) : this.wrap = Ext.DomHelper.insertHtml("beforeEnd", i, h), this.elNode = this.wrap.childNodes[0], this.ctNode = this.wrap.childNodes[1];
        var S = this.elNode.childNodes,
            u = 0;
        r && (this.rimgNode = S[u++]), this.indentNode = S[u++], this.ecNode = S[u++], o && (this.checkbox = S[u++], this.syncCheckCssClass()), this.iconNode = S[u++], this.anchor = S[u++], this.textNode = this.anchor.firstChild, d && (this.createInputField(d, t, this.elNode), u++), e.on("disabledchange", this.onDisabled, this)
    },
    onIdChange: function(e) {
        var t = Ext.util.Format.htmlEncode;
        this.rendered && this.elNode.setAttribute("ext:tree-node-id", t(e))
    },
    createInputField: function(e, t, i) {
        var n = e;
        switch (Ext.isObject(e) ? (this.inputConfig = Ext.apply({}, e), n = e.xtype || "textfield", delete e.xtype) : this.inputConfig = {}, Ext.isDefined(t.value) && (this.inputConfig.value = t.value), this.inputConfig.renderTo = i, n) {
            case "textfield":
                this.input = new SYNO.ux.TextField(this.inputConfig);
                break;
            case "numberfield":
                this.input = new SYNO.ux.NumberField(this.inputConfig)
        }
    },
    initEvents: function() {
        var e = this.callParent(arguments);
        return this.rimgNode && Ext.EventManager.on(this.rimgNode, "click", this.onRImgClick, this), e
    },
    onRImgClick: function() {
        this.node.fireEvent("rimgclick")
    },
    isDisabled: function() {
        return !0 === this.node.disabled
    },
    onClick: function(e) {
        if (!e.getTarget(".x-form-field")) return e.getTarget(".syno-tree-node-cb") && this.toggleCheck(), this.callParent(arguments)
    },
    onDblClick: function(e) {
        e.preventDefault(), this.disabled || !1 !== this.fireEvent("beforedblclick", this.node, e) && (!this.animating && this.node.isExpandable() && this.node.toggle(), this.fireEvent("dblclick", this.node, e))
    },
    onDisabled: function(e, t) {
        this.input && (t ? this.input.disable() : this.input.enable()), this.checkbox && (t ? this.checkbox.addClassName("syno-ux-cb-disabled") : this.checkbox.removeClassName("syno-ux-cb-disabled"))
    },
    onCheckChange: function() {
        this.syncCheckCssClass(), this.fireEvent("checkchange", this.node, this.getCheckValue())
    },
    isValid: function() {
        return !!this.node.disabled || !(this.input && !this.input.isValid())
    },
    getInputValue: function() {
        if (this.input && !this.disabled) return this.input.getValue()
    },
    setInputValue: function(e) {
        this.input && this.input.setValue(e)
    },
    isChecked: function() {
        return this.getCheckValue()
    },
    getCheckValue: function() {
        return this.node.attributes.checked
    },
    toggleCheck: function() {
        var e = this.checkbox;
        !0 !== this.node.disabled && e && this.setCheckValue(!this.getCheckValue())
    },
    setCheckValue: function(e) {
        this.node.disabled || e !== this.getCheckValue() && (e = "false" !== e && "off" !== e && "0" !== e && ("gray" === e ? "gray" : !!e), this.node.attributes.checked = e, this.onCheckChange())
    },
    syncCheckCssClass: function() {
        var e = this.getCheckValue();
        this.checkbox && (Ext.each(["checked", "grayed", "disabled"], function(e) {
            this.checkbox.classList.remove("syno-ux-cb-" + e)
        }, this), !0 === e ? this.checkbox.classList.add("syno-ux-cb-checked") : "gray" === e && this.checkbox.classList.add("syno-ux-cb-grayed"), this.node.disabled && this.checkbox.classList.add("syno-ux-cb-disabled"))
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanel.FolderLoader.Base", {
    extend: "Ext.tree.TreeLoader",
    createNode: function(e) {
        if (e.uiProvider = "SYNO.SDS.CloudStation.Component.ExtendedTreePanelUI", e.iconCls = "x-tree-node-icon", e.draggable = !1, !Ext.isFunction(this.createNodeFn) || !1 !== this.createNodeFn.call(this.createNodeScope || this, e)) return this.callParent(arguments)
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PROFILE.PanelSeletiveFile", {
    extend: "SYNO.ux.FormPanel",
    xtype: "cstn_selective_file",
    constructor: function(e) {
        this.remove_id_list = [], e.profile_info = Ext.apply({
            profile_name: "",
            profile_desc: {
                filtered_extensions: [],
                user_defined_extensions: [],
                user_defined_names: [],
                filtered_names: [],
                filtered_max_upload_size: 0
            }
        }, e.profile_info), this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            itemId: "cstn_selective_file_tab",
            title: _STR("profile", "file_selective"),
            layout: "border",
            border: !1,
            cls: "syno-cstn-profile-edit",
            autoFlexcroll: !SYNO.SDS.CSTN.IsDSM7OrAbove(),
            items: [{
                region: "north",
                border: !1,
                xtype: "syno_fieldset",
                labelWidth: 200,
                itemId: "top_part",
                items: [{
                    fieldLabel: _STR("profile", "profile_name"),
                    xtype: "syno_textfield",
                    itemId: "input_profile_name",
                    allowBlank: !1,
                    stripCharsRe: /(^\s+|\s+$)/g,
                    validator: function(e) {
                        var t = this.profile_grid.getStore(),
                            i = this.profile_grid.getSelectionModel().getSelected();
                        return !(!i || e !== i.get("profile_name")) || (-1 === t.findExact("profile_name", e) || _STR("common", "name_used"))
                    }.createDelegate(this)
                }, {
                    border: !1,
                    fieldLabel: _STR("profile", "max_size_label"),
                    xtype: "syno_numberfield",
                    itemId: "input_max_size",
                    regex: /^\d+$/,
                    maxlength: 8,
                    listeners: {
                        render: function(e) {
                            e.getEl().set({
                                "ext:qtip": _STR("profile", "size_tool_tip")
                            })
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    style: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "" : "padding: 10px 0 0 0",
                    value: _STR("profile", "seletive_file")
                }]
            }, {
                region: "center",
                layout: "fit",
                border: !0,
                itemId: "center_part",
                items: [this.getSelectiveFilePanel(e)]
            }, {
                region: "south",
                border: !1,
                layout: "border",
                height: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 34 : 32,
                itemId: "south_part",
                style: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "padding: 6px 0 0" : "padding: 4px 0 0",
                items: [{
                    region: "center",
                    layout: "border",
                    border: !1,
                    itemId: "custom_file_row",
                    items: [{
                        region: "center",
                        xtype: "syno_textfield",
                        itemId: "custom_file",
                        validator: this.isValidRule.createDelegate(this),
                        emptyText: _STR("profile", "name_tool_tip"),
                        enableKeyEvents: !0,
                        listeners: {
                            render: function(e) {
                                e.getEl().set({
                                    "ext:qtip": e.emptyText
                                })
                            },
                            keyup: function(e) {
                                "" !== e.getValue() ? e.getEl().set({
                                    "ext:qtip": Ext.util.Format.htmlEncode(e.getValue())
                                }) : e.getEl().set({
                                    "ext:qtip": e.emptyText
                                })
                            }
                        },
                        allowBlank: !0
                    }, {
                        region: "east",
                        border: !1,
                        width: SYNO.SDS.CSTN.IsDSM7OrAbove() ? 6 : 16
                    }]
                }, {
                    region: "east",
                    itemId: "add_custom_file_rule",
                    xtype: "syno_button",
                    btnStyle: "gray",
                    text: _T("common", "add"),
                    listeners: {
                        click: this.addCustomFileRule,
                        scope: this
                    }
                }]
            }]
        };
        return Ext.apply(t, e)
    },
    getSelectiveFilePanel: function(e) {
        return void 0 === this.selectiveFilePanel && (this.selectiveFilePanel = new SYNO.SDS.CloudStation.Component.ExtendedTreePanel.SelectiveFile({
            owner: e.owner,
            itemId: "selective_file_treepanel",
            ctCls: SYNO.SDS.CSTN.IsDSM7OrAbove() ? "syno-cstn-profile-edit-treepanel" : "",
            border: !1,
            rootVisible: !1,
            listeners: {
                afterrender: function() {
                    this.reloadPanel()
                },
                scope: this
            }
        })), this.selectiveFilePanel
    },
    isValidRule: function(e) {
        return !("" !== e && !this.isExtRule(e) && !this.isNameRule(e))
    },
    getBuiltinExtensions: function() {
        return SYNO.SDS.CloudStation.SelectiveSync.getBuiltInExtensions()
    },
    reloadPanel: function() {
        var e = this.selectiveFilePanel.getRootNode();
        e.removeAll(), this.get("south_part").get("custom_file_row").get("custom_file").setValue("");
        var t = this.getBuiltinExtensions();
        Ext.each(t, function(t) {
                var i = this.createBuiltInCategory(t, this.profile_info.profile_desc.filtered_extensions);
                e.appendChild(i)
            }, this), e.appendChild(this.createUserDefinedCategory()), e.expand(),
            function() {
                for (var t = 0; t < e.childNodes.length; t++) e.childNodes[t].expand(void 0, !1), !1 === e.childNodes[t].attributes.is_customize_session && e.childNodes[t].collapse(void 0, !1), e.childNodes[t].ui.syncCheckCssClass()
            }(), e.childNodes[0].ensureVisible(),
            function() {
                var e = this.get("top_part").get("input_max_size"),
                    t = Math.round(this.profile_info.profile_desc.filtered_max_upload_size / 1024 / 1024);
                e.setMinValue(0), e.setMaxValue(1024e4), e.setValue(t)
            }.createDelegate(this)(), this.get("top_part").get("input_profile_name").setValue(this.profile_info.profile_name)
    },
    createBuiltInCategory: function(e, t) {
        var i = !0,
            n = !0,
            s = {
                text: e.display_name,
                uiProvider: SYNO.SDS.CloudStation.Component.ExtendedTreePanelUI,
                iconCls: e.icon_cls,
                children: [],
                is_customize_session: !1,
                node_type: e.node_type
            };
        return Ext.each(e.extensions, function(e) {
            e = e.toLowerCase();
            var o = !(t.indexOf(e) >= 0);
            s.children.push(this.createExtensionNode(e, o, !0)), i = i && o, n = n && !o
        }, this), s.checked = !0 === i || !0 !== n && "gray", s
    },
    node_remove_clicked: function() {
        var e = this.parentNode,
            t = !0,
            i = !1;
        this.parentNode.removeChild(this, !0), Ext.each(e.childNodes, function(e) {
            var n = e.attributes.checked;
            t = t && n, i = i && !n
        }, this), e.attributes.checked = !0 !== i && (!0 === t || "gray"), e.ui.onCheckChange()
    },
    createExtensionNode: function(e, t, i) {
        var n = this.createBaseNode(t);
        return n.node_type = "ext", n.extension_name = e, n.text = e, n.qtip = Ext.util.Format.htmlEncode(n.text), i || (n.text = "*." + e, n.rimgCls = "syno-tree-node-remove", n.listeners = {
            rimgclick: this.node_remove_clicked
        }), n
    },
    createNameNode: function(e, t) {
        var i = this.createBaseNode(t);
        return i.node_type = "name", i.file_name = e, i.text = e, i.qtip = Ext.util.Format.htmlEncode(i.text), i.rimgCls = "syno-tree-node-remove", i.listeners = {
            rimgclick: this.node_remove_clicked
        }, i
    },
    createBaseNode: function(e) {
        return {
            uiProvider: SYNO.SDS.CloudStation.Component.ExtendedTreePanelUI,
            text: void 0,
            checked: e,
            leaf: !0,
            extension_name: void 0,
            file_name: void 0,
            node_type: void 0
        }
    },
    createUserDefinedCategory: function() {
        var e = !0,
            t = this.profile_info.profile_desc,
            i = {
                text: _STR("profile", "customize"),
                uiProvider: SYNO.SDS.CloudStation.Component.ExtendedTreePanelUI,
                iconCls: "syno-tree-node-customized",
                children: [],
                is_customize_session: !0,
                node_type: "other"
            };
        return Ext.each(t.user_defined_extensions, function(n) {
            n = n.toLowerCase();
            var s = !(t.filtered_extensions.indexOf(n) >= 0);
            i.children.push(this.createExtensionNode(n, s, !1)), e = e && s
        }, this), Ext.each(t.user_defined_names, function(n) {
            var s = !(t.filtered_names.indexOf(n) >= 0);
            i.children.push(this.createNameNode(n, s)), e = e && s
        }, this), i.checked = !0 === e || "gray", i
    },
    isExtensionNode: function(e) {
        return "ext" === e.node_type
    },
    isNameNode: function(e) {
        return "name" === e.node_type
    },
    getSettings: function() {
        var e = this.get("top_part").get("input_max_size"),
            t = this.get("center_part").get("selective_file_treepanel").getRootNode(),
            i = [],
            n = [],
            s = [],
            o = [],
            a = 0 < e.getValue() ? 1024 * e.getValue() * 1024 : 0,
            r = function(e) {
                this.isExtensionNode(e.attributes) ? s.indexOf(e.attributes.extension_name) < 0 && s.push(e.attributes.extension_name) : this.isNameNode(e.attributes) && o.indexOf(e.attributes.file_name) < 0 && o.push(e.attributes.file_name)
            }.createDelegate(this),
            l = function(e) {
                this.isExtensionNode(e.attributes) ? i.indexOf(e.attributes.extension_name) < 0 && i.push(e.attributes.extension_name) : this.isNameNode(e.attributes) && n.indexOf(e.attributes.file_name) < 0 && n.push(e.attributes.file_name)
            }.createDelegate(this);
        return Ext.each(t.childNodes, function(e) {
            Ext.each(e.childNodes, function(t) {
                !1 === t.attributes.checked && l(t), !0 === e.attributes.is_customize_session && r(t)
            }, this)
        }, this), {
            filtered_max_upload_size: a,
            filtered_extensions: i,
            filtered_names: n,
            user_defined_extensions: s,
            user_defined_names: o
        }
    },
    isDirty: function() {
        var e = this.get("top_part").get("input_profile_name"),
            t = this.get("top_part").get("input_max_size");
        if (e.getValue() !== this.profile_info.profile_name) return !0;
        if (1048576 * t.getValue() !== this.profile_info.profile_desc.filtered_max_upload_size) return !0;
        var i = this.getSettings();
        if (this.profile_info.profile_desc.filtered_extensions.length !== i.filtered_extensions.length) return !0;
        if (this.profile_info.profile_desc.filtered_names.length !== i.filtered_names.length) return !0;
        if (this.profile_info.profile_desc.user_defined_extensions.length !== i.user_defined_extensions.length) return !0;
        if (this.profile_info.profile_desc.user_defined_names.length !== i.user_defined_names.length) return !0;
        var n = 0;
        for (this.profile_info.profile_desc.filtered_extensions.sort(), i.filtered_extensions.sort(), n = 0; n < i.filtered_extensions.length; n++)
            if (i.filtered_extensions[n] != this.profile_info.profile_desc.filtered_extensions[n]) return !0;
        for (this.profile_info.profile_desc.filtered_names.sort(), i.filtered_names.sort(), n = 0; n < i.filtered_names.length; n++)
            if (i.filtered_names[n] != this.profile_info.profile_desc.filtered_names[n]) return !0;
        for (this.profile_info.profile_desc.user_defined_extensions.sort(), i.filtered_extensions.sort(), n = 0; n < i.user_defined_extensions.length; n++)
            if (i.user_defined_extensions[n] != this.profile_info.profile_desc.user_defined_extensions[n]) return !0;
        for (this.profile_info.profile_desc.user_defined_names.sort(), i.filtered_extensions.sort(), n = 0; n < i.user_defined_names.length; n++)
            if (i.user_defined_names[n] != this.profile_info.profile_desc.user_defined_names[n]) return !0;
        return !1
    },
    getInfo: function() {
        var e = this.get("top_part").get("input_profile_name"),
            t = this.get("top_part").get("input_max_size");
        return !(!e.isValid() || !t.isValid()) && (this.profile_info.profile_desc = this.getSettings(), this.profile_info.profile_name = e.getValue(), this.profile_info)
    },
    addCustomizeNode: function(e) {
        for (var t = this.get("center_part").get("selective_file_treepanel"), i = t.getRootNode(), n = null, s = i.childNodes.length - 1; s >= 0; s--)
            if (!0 === i.childNodes[s].attributes.is_customize_session) {
                n = i.childNodes[s];
                break
            } null !== n && (n.appendChild(e), n.collapse(void 0, !1), n.expand(void 0, !1))
    },
    addCustomFileRule: function() {
        var e = this.get("south_part").get("custom_file_row").get("custom_file"),
            t = e.getValue();
        t = t.toLowerCase(), this.isExtRule(t) ? (this.addExtRule(t.substring(2, t.length)), e.reset()) : this.isNameRule(t) && (this.addNameRule(t), e.reset())
    },
    isExtRule: function(e) {
        var t = /^\*\.[^\*\:\?\"<\>\|\\\/]*$/;
        return "" !== e && t.test(e)
    },
    isNameRule: function(e) {
        var t = /[\*\:\?\"<\>\|\\\/]+/;
        return "" !== e && !t.test(e)
    },
    addExtRule: function(e) {
        var t = function(t) {
                return t.attributes.extension_name === e
            },
            i = this.selectNode(t);
        if (null !== i) return i.attributes.checked = !1, void i.ui.onCheckChange();
        var n = this.createExtensionNode(e, !1, !1);
        this.addCustomizeNode(n), i = this.selectNode(t), i.ui.onCheckChange()
    },
    addNameRule: function(e) {
        var t = function(t) {
                return t.attributes.file_name === e
            },
            i = this.selectNode(t);
        if (null !== i) return i.attributes.checked = !1, void i.ui.onCheckChange();
        var n = this.createNameNode(e, !1);
        this.addCustomizeNode(n), i = this.selectNode(t), i.ui.onCheckChange()
    },
    selectNode: function(e) {
        var t = this.get("center_part").get("selective_file_treepanel").getRootNode(),
            i = null,
            n = function() {
                t.childNodes[s].childNodes[o].select(), t.childNodes[s].childNodes[o].ensureVisible()
            };
        t.expand();
        for (var s = 0; s < t.childNodes.length; s++) {
            for (var o = 0; o < t.childNodes[s].childNodes.length; o++)
                if (e(t.childNodes[s].childNodes[o])) {
                    t.childNodes[s].expand(void 0, void 0, n), i = t.childNodes[s].childNodes[o];
                    break
                } if (null !== i) break
        }
        return i
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.DialogProfileEdit", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.win = e.owner;
        var t = {
            xtype: "statusbar",
            hideMode: "visibility",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "commit"),
                itemId: "apply",
                id: this.BtnApplyId = Ext.id(),
                scope: this,
                handler: this.onSave
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                hidden: !1,
                text: _T("common", "cancel"),
                itemId: "cancel",
                id: this.BtnCancelId = Ext.id(),
                scope: this,
                handler: this.onCancel
            }]
        };
        SYNO.SDS.CSTN.IsDSM7OrAbove() && t.items.reverse(), this.callParent([Ext.apply({
            itemId: "profile_editor",
            title: _STR("profile", "profile_editor"),
            width: 500,
            height: 500,
            resizable: !1,
            autoScroll: !0,
            layout: "fit",
            items: [{
                xtype: "syno_tabpanel",
                itemId: "profile_tab_panel",
                deferredRender: !1,
                layoutOnTabChange: !0,
                border: !1,
                plain: !0,
                activeTab: 0,
                items: [{
                    xtype: "cstn_selective_file",
                    itemId: "selective_file",
                    profile_info: e.profile_info,
                    profile_grid: e.profile_grid,
                    owner: e.owner,
                    win: this
                }, {
                    xtype: "cstn_profile_apply",
                    itemId: "profile_apply",
                    profile_info: e.profile_info,
                    profile_grid: e.profile_grid,
                    owner: e.owner,
                    win: this
                }]
            }],
            listeners: {
                beforeclose: this.onCancel,
                scope: this
            },
            fbar: t
        }, e)])
    },
    winShow: function() {
        this.open()
    },
    onCancel: function() {
        return this.get("profile_tab_panel").get("selective_file").isDirty() || this.get("profile_tab_panel").get("profile_apply").isDirty() ? SYNO.SDS.CSTN.IsDSM7OrAbove() ? this.owner.confirmLostChangePromise({
            save: function() {
                this.onSave()
            }.bind(this),
            cancel: Ext.emptyFn,
            dontSave: function() {
                this.doClose()
            }.bind(this)
        }, this) : this.getMsgBox().confirm(_STR("app", "app_name"), _T("common", "confirm_lostchange"), function(e) {
            "yes" === e && this.close()
        }, this) : this.doClose(), !1
    },
    onSave: function() {
        var e = this.get("profile_tab_panel").get("selective_file").getInfo(),
            t = this.get("profile_tab_panel").get("profile_apply").getSetting();
        if (!1 === e) return this.get("profile_tab_panel").setActiveTab("selective_file"), this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }), !1;
        "create" === this.open_mode ? function() {
            var i = this.profile_grid.getStore(),
                n = new i.recordType({
                    profile_applied: t,
                    profile_desc: e.profile_desc,
                    profile_name: e.profile_name,
                    profile_id: -1
                });
            this.profile_grid.getStore().add(n), n.markDirty(), SYNO.SDS.CSTN.IsDSM7OrAbove() && this.profile_grid.onSave()
        }.createDelegate(this)() : "edit" === this.open_mode && function() {
            var i = this.profile_grid.getSelectionModel().getSelected();
            i.set("profile_applied", t), i.set("profile_desc", e.profile_desc), i.set("profile_name", e.profile_name), i.set("profile_id", this.profile_info.profile_id), i.markDirty(), SYNO.SDS.CSTN.IsDSM7OrAbove() && this.profile_grid.onSave()
        }.createDelegate(this)(), this.doClose()
    }
}), Ext.ns("SYNO.SDS.CSTN"), SYNO.SDS.CSTN.RenderProfile = function(e, t) {
    var i = "",
        n = !1;
    return e.filtered_max_upload_size && e.filtered_max_upload_size > 0 && (i += String.format(_STR("profile", "profile_max_size"), e.filtered_max_upload_size / 1024 / 1024), n = !0), e.filtered_extensions && e.filtered_extensions.length > 0 && (n && (i += "; "), i += String.format(_STR("profile", "profile_filtered_ext"), e.filtered_extensions.join(", ")), n = !0), e.filtered_names && e.filtered_names.length > 0 && (n && (i += "; "), i += String.format(_STR("profile", "profile_filtered_names"), e.filtered_names.join(", ")), n = !0), t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(i)) + '"'), Ext.util.Format.htmlEncode(i)
}, SYNO.SDS.CSTN.RenderAppliedUser = function(e, t) {
    var i = "",
        n = [];
    return Ext.each(e, function(e) {
        n.push(e.user_name)
    }, this), e.length > 0 && (i += n.join(", ")), t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(i)) + '"'), i
}, Ext.define("SYNO.SDS.CSTN.PanelProfile", {
    extend: "SYNO.ux.GridPanel",
    hasRestore: !1,
    constructor: function(e) {
        this.owner = e.owner, this.win = e.win;
        var t = this.fillConfig(e);
        this.deleted_profile_ids = [], this.callParent([t])
    },
    fillConfig: function(e) {
        var t = new Ext.Toolbar;
        t.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "profile_create",
            text: _STR("common", "create"),
            handler: this.onCreate,
            scope: this
        }), t.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "profile_edit",
            text: _STR("common", "edit"),
            handler: this.onEdit,
            scope: this
        }), t.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: !0,
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            itemId: "profile_delete",
            text: _STR("common", "remove"),
            handler: this.onDelete,
            scope: this
        }), SYNO.SDS.CSTN.IsDSM7OrAbove() || (t.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            disabled: this._S("demo_mode"),
            tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
            hidden: !1,
            text: _T("common", "commit"),
            itemId: "profile_save",
            scope: this,
            handler: this.onSave
        }), t.add({
            xtype: "syno_button",
            cls: "syno-cstn-tab-btn-main-el",
            ctCls: "syno-cstn-tab-btn",
            hidden: !1,
            itemId: "profile_reset",
            text: _T("common", "reset"),
            scope: this,
            handler: this.onReset
        }));
        var i = [{
                id: "profile_id",
                header: "profile_id",
                dataIndex: "profile_id",
                hidden: !0
            }, {
                id: "profile_name",
                width: 40,
                header: _STR("profile", "profile_name"),
                dataIndex: "profile_name",
                align: "left",
                sortable: !0
            }, {
                id: "profile_desc",
                header: _STR("profile", "profile_desc"),
                dataIndex: "profile_desc",
                align: "left",
                renderer: SYNO.SDS.CSTN.RenderProfile
            }, {
                id: "profile_applied",
                header: _STR("profile", "profile_applied"),
                dataIndex: "profile_applied",
                align: "left",
                width: 150,
                renderer: SYNO.SDS.CSTN.RenderAppliedUser
            }],
            n = new Ext.grid.ColumnModel({
                columns: i
            }),
            s = this.CreateProfileStore(),
            o = {
                tbar: t,
                view: new SYNO.ux.FleXcroll.grid.GridView,
                stripeRows: !0,
                enableColLock: !1,
                enableHdMenu: !1,
                enableColumnMove: !1,
                colModel: n,
                ds: s,
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: !0,
                    listeners: {
                        rowselect: function() {
                            this.win._S("demo_mode") || (this.getTopToolbar().get("profile_edit").enable(), this.getTopToolbar().get("profile_delete").enable())
                        },
                        rowdeselect: this.disableEditAndDeleteButton,
                        scope: this
                    }
                }),
                loadMask: !0,
                owner: e.owner
            };
        return Ext.apply(o, e), o
    },
    CreateProfileStore: function() {
        var e = ["profile_id", "profile_name", "profile_desc", "profile_applied"];
        return new SYNO.API.Store({
            pruneModifiedRecords: !0,
            autoLoad: !1,
            proxy: new SYNO.API.Proxy({
                api: SYNO.SDS.CSTN.WebAPI.Profile.api,
                version: 1,
                method: "list",
                appWindow: this.owner
            }),
            reader: new Ext.data.JsonReader({
                root: "profile_list",
                totalProperty: "total",
                id: "id"
            }, e),
            baseParams: {
                start: 0,
                limit: this.pageSize,
                user: this.win._S("user")
            },
            listeners: {
                scope: this,
                exception: function(e, t, i, n, s) {
                    s && s.code && this.owner.getMsgBox().alert(_STR("app", "app_name"), SYNO.SDS.CSTN.getErrorString(s))
                },
                load: this.disableEditAndDeleteButton
            },
            remoteSort: !1
        })
    },
    doRefresh: function(e, t) {
        this.getStore().removeAll(), this.getStore().load({
            callback: e,
            scope: t
        }), this.deleted_profile_ids = []
    },
    disableEditAndDeleteButton: function() {
        this.getTopToolbar().get("profile_edit").disable(), this.getTopToolbar().get("profile_delete").disable()
    },
    onCreate: function() {
        this.getSelectionModel().clearSelections(), new SYNO.SDS.CSTN.DialogProfileEdit({
            owner: this.owner,
            profile_grid: this,
            open_mode: "create"
        }).open()
    },
    onEdit: function() {
        var e = this.getSelectionModel().getSelected();
        new SYNO.SDS.CSTN.DialogProfileEdit({
            owner: this.owner,
            profile_info: e.data,
            profile_grid: this,
            open_mode: "edit"
        }).open()
    },
    onDelete: function() {
        this.owner.getMsgBox().confirm(_STR("app", "app_name"), _STR("common", "confirm_remove"), function(e) {
            if ("yes" == e) {
                var t = this.getSelectionModel().getSelected(),
                    i = t.get("profile_id"); - 1 != i && this.deleted_profile_ids.push(i), this.getStore().remove(t), this.getTopToolbar().get("profile_edit").disable(), this.getTopToolbar().get("profile_delete").disable(), SYNO.SDS.CSTN.IsDSM7OrAbove() && this.onSave()
            }
        }, this)
    },
    ajaxCheckSrvStatusCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: SYNO.SDS.CSTN.cbLoad,
            failure: SYNO.SDS.CSTN.webapiErrHdlMain
        })
    },
    checkSrvStatus: function() {
        this.owner.setStatusBusy(), SYNO.SDS.CSTN.WebAPI.checkUser.call(this.owner, this.ajaxCheckSrvStatusCB, this)
    },
    onPageActivate: function() {
        this.checkSrvStatus()
    },
    onPageDeactivate: function() {},
    checkDirty: function() {
        return this.getStore().getModifiedRecords().length > 0 || this.deleted_profile_ids.length > 0
    },
    onReset: function() {
        this.doRefresh()
    },
    onSave: function() {
        var e = this.getStore(),
            t = [],
            i = this.deleted_profile_ids,
            n = e.getModifiedRecords(),
            s = [];
        if (!this.checkDirty()) return void this.owner.getMsgBox().alert(_STR("app", "app_name"), _T("error", "nochange_subject"));
        Ext.each(n, function(e) {
            t.push({
                profile_name: e.get("profile_name"),
                profile_desc: e.get("profile_desc"),
                profile_applied: e.get("profile_applied"),
                profile_id: e.get("profile_id")
            })
        }), t.length > 0 && s.push({
            api: SYNO.SDS.CSTN.WebAPI.Profile.api,
            version: 1,
            method: "set",
            params: {
                profiles: t
            }
        }), i.length > 0 && s.push({
            api: SYNO.SDS.CSTN.WebAPI.Profile.api,
            version: 1,
            method: "delete",
            params: {
                id: i
            }
        }), this.owner.setStatusBusy(), this.sendWebAPI({
            compound: {
                params: s
            },
            callback: this.ajaxApplyGridCB,
            scope: this
        })
    },
    ajaxApplyGridSuccessCB: function() {
        this.doRefresh(function() {
            this.owner.getMsgBox().alert(_STR("app", "app_name"), _T("common", "setting_applied"))
        }, this)
    },
    ajaxApplyGridCB: function(e, t, i, n) {
        SYNO.SDS.CSTN.webapiHdl.call(this, e, t, i, n, {
            success: this.ajaxApplyGridSuccessCB,
            failure: SYNO.SDS.CSTN.webapiErrHdl
        })
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PanelConfigure", {
    extend: "SYNO.ux.TabPanel",
    constructor: function(e) {
        this.owner = e.owner || e.appWin, this.module = e.module || e.appWin;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = new SYNO.SDS.CSTN.PanelDatabase({
                owner: this.owner,
                win: this.owner,
                module: this.module,
                title: _STR("setting", "general")
            }),
            i = new SYNO.SDS.CSTN.PanelProfile({
                owner: this.owner,
                win: this.owner,
                module: this.module,
                title: _STR("profile", "profile_manager")
            }),
            n = new SYNO.SDS.CSTN.PanelSharingLink({
                owner: this.owner,
                win: this.owner,
                module: this.module,
                title: _STR("setting", "share")
            }),
            s = {
                cls: "syno-cstn-panel-padding",
                itemId: "tabPanel",
                deferredRender: !1,
                layoutOnTabChange: !0,
                border: !1,
                plain: !0,
                region: "center",
                items: [],
                listeners: {
                    beforetabchange: {
                        fn: this.onTabChange
                    },
                    activate: {
                        fn: function() {
                            this.needCheck = !1
                        }
                    }
                }
            };
        return s.items.push(t), s.items.push(i), s.items.push(n), Ext.apply(s, e), s
    },
    onTabChange: function(e, t, i) {
        return this.needCheck && this.checkDirty() ? (SYNO.SDS.CSTN.IsDSM7OrAbove() ? this.owner.confirmLostChangePromise({
            save: function() {
                this.needCheck = !1, this.onSave(), i && i.onPageDeactivate(), e.setActiveTab(t), t.onPageActivate()
            }.bind(this),
            cancel: Ext.emptyFn,
            dontSave: function() {
                this.needCheck = !1, this.onCancel(), i && i.onPageDeactivate(), e.setActiveTab(t), t.onPageActivate()
            }.bind(this)
        }, this) : (this.needCheck = !1, this.owner.getMsgBox().confirm(_STR("app", "app_name"), _T("common", "confirm_lostchange"), function(n) {
            "yes" === n && (i && i.onPageDeactivate(), e.setActiveTab(t), t.onPageActivate()), this.needCheck = !0
        }, this)), !1) : (i && i.onPageDeactivate(), t.onPageActivate(), this.needCheck = !0, !0)
    },
    checkDirty: function() {
        var e = this.getActiveTab();
        return !!e && e.checkDirty()
    },
    onSave: function() {
        this.getActiveTab().onSave()
    },
    onCancel: function() {
        this.getActiveTab().onCancel()
    },
    onPageActivate: function() {},
    onPageDeactivate: function() {
        this.getActiveTab().onPageDeactivate()
    },
    onActivate: function() {
        this.onPageActivate()
    },
    onDeactivate: function() {
        this.onPageDeactivate()
    }
}), 
/**
 * @class SYNO.SDS.CSTN.Instance
 * @extends SYNO.SDS.AppInstance
 * SynologyDrive application instance class
 *
 */
Ext.ns("SYNO.SDS.CSTN"), SYNO.SDS.CSTN.Instance = Ext.extend(SYNO.SDS.AppInstance, {
    appWindowName: "SYNO.SDS.CSTN.MainAppWindow",
    constructor: function() {
        void 0 === SYNO.SDS.Strings["SYNO.SDS.CSTN.MainAppWindow"] && (SYNO.SDS.Strings["SYNO.SDS.CSTN.MainAppWindow"] = SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"]), void 0 === SYNO.SDS.Strings["SYNO.SDS.CSTN.MainWindow"] && (SYNO.SDS.Strings["SYNO.SDS.CSTN.MainWindow"] = SYNO.SDS.Strings["SYNO.SDS.CSTN.Instance"]), SYNO.SDS.CSTN.Instance.superclass.constructor.apply(this, arguments)
    }
}), Ext.define("SYNO.SDS.CSTN.MainAppWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    constructor: function(e) {
        this.enableStatus = void 0, this.cstnInfo = {}, this.forceChangePage = !1, this.preConfigMap = {};
        var t = this.fillConfig(e);
        this.callParent([t]), this.setWidth(SYNO.SDS.CSTN.WIN_WIDTH), this.getPageList().findNext = !1
    },
    fillConfig: function(e) {
        var t = [{
            text: _STR("func", "mgr_overview"),
            iconCls: "syno-cstn-list-cloudstn",
            fn: "SYNO.SDS.CSTN.PanelCloudStn"
        }];
        return t.push({
            text: _STR("func", "mgr_clientinfo"),
            iconCls: "syno-cstn-list-client",
            fn: "SYNO.SDS.CSTN.PanelClient"
        }), t.push({
            text: _STR("func", "mgr_log"),
            iconCls: "syno-cstn-list-log",
            fn: "SYNO.SDS.CSTN.PanelLog"
        }), this._S("is_admin") && (t.push({
            text: _STR("func", "mgr_sharing"),
            iconCls: "syno-cstn-list-teamfolder",
            fn: "SYNO.SDS.CSTN.PanelSharing"
        }), t.push({
            text: _STR("func", "settings"),
            iconCls: "syno-cstn-list-configure",
            fn: "SYNO.SDS.CSTN.PanelConfigure"
        })), Ext.apply({
            useGradient: !1,
            cls: "syno-cstn",
            activePage: "SYNO.SDS.CSTN.PanelCloudStn",
            autoScroll: !1,
            minWidth: SYNO.SDS.CSTN.WIN_MINWIDTH,
            minHeight: SYNO.SDS.CSTN.WIN_MINHEIGHT,
            width: SYNO.SDS.CSTN.WIN_WIDTH,
            listItems: t
        }, e)
    },
    getPageCt: function() {
        return this.pageCt || (this.pageCt = new Ext.Panel({
            layout: "card",
            padding: "0px 0px 0px 0px",
            border: !1,
            frame: !1,
            hideMode: "offsets",
            region: "center"
        })), this.pageCt
    },
    setPreConfig: function(e, t) {
        this.preConfigMap[e] = t
    },
    fetchPreConfig: function(e) {
        var t = e || this.activePage.itemId,
            i = this.preConfigMap[t];
        return this.preConfigMap[t] = void 0, i
    },
    onBeforeSelect: function(e, t, i) {
        if (!this.forceChangePage && !this.canChangePage(e, t, i)) return !1;
        if (i && i.leaf) {
            var n = this.pageCt.getComponent(i.attributes.fn);
            n && Ext.isFunction(n.onPageDeactivate) && n.onPageDeactivate()
        }
        if (Ext.isIE) return this.forceChangePage = !1, !0;
        var s = SYNO.SDS.CSTN.DEFAULT_HEIGHT;
        if (this.curHeight == s) return this.forceChangePage = !1, !0;
        SYNO.SDS.CSTN.DBG("cstn: mw, switchPanel: do anim"), this.el.disableShadow();
        var o = this.body,
            a = function() {
                o.clearOpacity(), this.getEl().setHeight("auto"), o.setHeight("auto"), this.setHeight(s), this.el.enableShadow(), this.syncShadow(), this.selectPage(t.attributes.fn), this.forceChangePage = !1
            };
        return o.shift({
            height: s - 54,
            duration: .3,
            opacity: .1,
            scope: this,
            callback: a
        }), this.curHeight = s, !1
    },
    onClickHelp: function() {
        var e = "SYNO.SDS.Drive.Application:drive_admin_console.html";
        _S("standalone") ? SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: e
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: e
        }, !1)
    },
    canChangePage: function(e, t, i) {
        var n = t.attributes.fn,
            s = i ? i.attributes.fn : null,
            o = this.getActivePage();
        if (n != s && "SYNO.SDS.CSTN.PanelCloudStn" !== n) {
            var a, r = !1;
            switch (this.enableStatus) {
                case "enabled":
                    this.cstnInfo && !0 === this.cstnInfo.cstn_freeze && "SYNO.SDS.CSTN.PanelConfigure" !== n ? a = _STR("cstn", "drive_diskfull_desc") : r = !0;
                    break;
                case "done":
                case "updating":
                case "initializing":
                    a = _STR("warning", "msg_upgrading");
                    break;
                case "checking":
                    a = _STR("warning", "msg_checking_db");
                    break;
                case "upgradefail":
                    a = _STR("warning", "error_drive_upgradefail");
                    break;
                case "dbnewer":
                    a = _STR("warning", "error_upgrade_drive_db_newer");
                    break;
                case "dbunexist":
                    a = _STR("warning", "error_drive_db_unexist");
                    break;
                case "homedisabled":
                    a = _STR("warning", "err_enable_homes");
                    break;
                case "portconflict":
                    a = String.format(_STR("warning", "warn_drive_port_conflict"), "6690");
                    break;
                default:
                    r = !0
            }
            if (!1 === r) return this.getMsgBox().alert(_STR("app", "app_name"), a), r
        }
        return !(o && Ext.isFunction(o.checkDirty) && o.checkDirty()) || (SYNO.SDS.CSTN.IsDSM7OrAbove() ? this.confirmLostChangePromise({
            save: function() {
                o.onSave(), this.forceChangePage = !0, this.selectPage(n)
            }.bind(this),
            cancel: Ext.emptyFn,
            dontSave: function() {
                o.onCancel(), this.forceChangePage = !0, this.selectPage(n)
            }.bind(this)
        }, this) : this.getMsgBox().confirm(_STR("app", "app_name"), _T("common", "confirm_lostchange"), function(e) {
            "yes" === e && (this.forceChangePage = !0, this.selectPage(n))
        }, this), !1)
    }
}), SYNO.SDS.CSTN.MainWindow = Ext.extend(SYNO.SDS.AppWindow, {
    appInstance: null,
    mainPanel: null,
    constructor: function(e) {
        this.appInstance = e.appInstance, this.mainPanel = new SYNO.SDS.CSTN.MainPanel({
            owner: this
        }), SYNO.SDS.CSTN.MainWindow.superclass.constructor.call(this, Ext.apply({
            resizable: !0,
            maximizable: !1,
            minimizable: !0,
            minWidth: SYNO.SDS.CSTN.WIN_WIDTH,
            minHeight: SYNO.SDS.CSTN.DEFAULT_HEIGHT,
            width: SYNO.SDS.CSTN.WIN_WIDTH,
            height: SYNO.SDS.CSTN.DEFAULT_HEIGHT,
            layout: "fit",
            cls: "syno-cstn",
            items: [this.mainPanel]
        }, e))
    },
    onOpen: function(e) {
        SYNO.SDS.CSTN.MainWindow.superclass.onOpen.call(this, e), this.mainPanel.onActivate(), e.sel_func && this.mainPanel.onActivate(e.sel_func)
    },
    onRequest: function(e) {
        SYNO.SDS.CSTN.MainWindow.superclass.onRequest.call(this, e)
    },
    onClose: function() {
        if (!1 === SYNO.SDS.CSTN.MainWindow.superclass.onClose.apply(this, arguments)) return !1;
        var e = this.mainPanel,
            t = e.formPanel.getLayout().activeItem.itemId;
        return !e.isPanelDirty(t) || (this.getMsgBox().confirm(_STR("app", "app_name"), _T("common", "confirm_lostchange"), function(e) {
            "yes" === e && this.doClose()
        }, this), !1)
    },
    setStatus: function(e) {
        e = e || {};
        var t = this.mainPanel.formPanel.getLayout().activeItem.getFooterToolbar();
        t && Ext.isFunction(t.setStatus) ? t.setStatus(e) : this.getMsgBox().alert("alert from MainWindow.js", e.text)
    }
}), Ext.ns("SYNO.SDS.CSTN"), Ext.define("SYNO.SDS.CSTN.PathBar", {
    extend: "Ext.util.Observable",
    constructor: function(e) {
        this.init(e.rb), this.callParent(arguments), this.addEvents("updatepath")
    },
    init: function(e) {
        return this.rb = e, this.tbPanel = new SYNO.SDS.CSTN.PathButtonsPanel({
            cls: "syno-cstn-pathtoolbar",
            rb: this.rb
        }), this
    },
    addPathButton: function(e, t, i, n, s, o, a) {
        return this.tbPanel.addButton(e, t, i, n, s, o, a, this.rb)
    },
    updatePathButton: function(e, t, i, n, s, o) {
        return this.tbPanel.updateButton(e, t, i, n, s, o)
    },
    addPathButtons: function(e) {
        for (var t = this.tbPanel.items.length < e.length ? e.length : this.tbPanel.items.length, i = e.length - 1, n = 0; n < t; n++)
            if (n < this.tbPanel.items.length && n < e.length) this.updatePathButton(n, e[n].text, e[n].tooltip, e[n].path, e[n].node_id, n === i);
            else {
                if (!(n < e.length)) {
                    this.removePathButtons(n, t);
                    break
                }
                this.addPathButton(this.tbPanel.items.length, e[n].text, e[n].tooltip, e[n].path, e[n].node_id, 0 === n, n === i)
            } this.tbPanel.setActiveButton(this.tbPanel.items[this.tbPanel.items.length - 1]), this.fireEvent("updatepath", this)
    },
    removePathButtons: function(e, t) {
        this.tbPanel.removeButtons(e, t)
    },
    removeAllButtons: function() {
        this.tbPanel.removeAllButtons()
    },
    setWidth: function(e) {
        this.tbPanel.setWidth(e)
    }
}), Ext.define("SYNO.SDS.CSTN.PathButtonsPanel", {
    extend: "Ext.BoxComponent",
    onRender: function() {
        this.activeButton = null, this.enableScroll = !0, this.scrollIncrement = 0, this.scrollRepeatInterval = 400, this.scrollDuration = .35, this.animScroll = !0, this.buttonWidthSet = !1, this.allowDomMove = !1, this.callParent(arguments), this.mon(this, "resize", this.delegateUpdates), this.items = [], this.selMenu = new SYNO.ux.Menu({
            items: [],
            listeners: {
                click: {
                    fn: function(e, t) {
                        if (t.obj.getPath()) {
                            var i = t.obj.getPath(),
                                n = t.obj.getNodeId();
                            if (n) {
                                var s = {};
                                s.name = i, s.node_id = n, t.obj.rb.onChangeDir("normal", s)
                            }
                        }
                    },
                    scope: this
                }
            }
        }), this.stripWrap = Ext.get(this.el).createChild({
            cls: "cs-pathbuttons-strip-wrap",
            cn: {
                tag: "ul",
                cls: "cs-pathbuttons-strip"
            }
        }), this.stripSpacer = Ext.get(this.el).createChild({
            cls: "cs-pathbuttons-strip-spacer"
        }), this.strip = new Ext.Element(this.stripWrap.dom.firstChild), this.edge = this.strip.createChild({
            tag: "li",
            cls: "cs-pathbuttons-edge"
        }), this.strip.createChild({
            cls: "x-clear"
        })
    },
    addButton: function(e, t, i, n, s, o, a, r) {
        var l = this.strip.createChild({
                tag: "li"
            }, this.edge),
            d = new SYNO.SDS.CSTN.PathBar.PathButton(l, e, t, i, n, s, o, a, r);
        return this.items.push(d), this.buttonWidthSet || (this.lastButtonWidth = d.container.getWidth()), this.addManagedComponent(d), d
    },
    updateButton: function(e, t, i, n, s, o) {
        this.items[e].updateButton(t, i, n, s, o)
    },
    removeButtons: function(e, t) {
        for (var i, n, s = e; s < t; s++) n = this.items[s], i = document.getElementById(n.container.id), this.removeManagedComponent(n), n.destroy(), i.parentNode.removeChild(i);
        var o = [];
        for (s = 0; s < e; s++) o.push(this.items[s]);
        this.items = o, this.delegateUpdates()
    },
    removeAllButtons: function() {
        for (var e, t, i = this.items.length, n = 0; n < i; n++) t = this.items[n], e = document.getElementById(t.container.id), this.removeManagedComponent(t), t.destroy(), e.parentNode.removeChild(e);
        this.items = [], this.delegateUpdates()
    },
    setActiveButton: function(e) {
        this.activeButton = e, this.delegateUpdates()
    },
    delegateUpdates: function() {
        this.enableScroll && this.rendered && this.autoScroll()
    },
    autoScroll: function() {
        var e = this.items.length,
            t = this.el.dom.clientWidth,
            i = this.stripWrap,
            n = i.dom.offsetWidth,
            s = this.getScrollPos(),
            o = this.edge.getOffsetsTo(this.stripWrap)[0] + s;
        !this.enableScroll || e < 1 || n < 20 || (i.setWidth(t), o <= t ? (i.dom.scrollLeft = 0, this.showSelBtn && (this.showSelBtn = !1, this.el.removeClass("x-pathbuttons-selection-btn-displayed"), this.menuBtn.hide())) : (this.showSelBtn || this.el.addClass("x-pathbuttons-selection-btn-displayed"), t -= i.getMargins("lr"), i.setWidth(t > 20 ? t : 20), this.showSelBtn || (this.menuBtn ? (this.showSelBtn = !0, this.menuBtn.show()) : this.createMenuBtn()), this.updateScrollandSelMenu()))
    },
    createMenuBtn: function() {
        var e = this.el.dom.offsetHeight,
            t = this.el.insertFirst({
                cls: "cs-pathbuttons-selection-btn"
            });
        t.setHeight(e), t.addClassOnOver("cs-pathbuttons-selection-btn-over"), t.addClassOnClick("cs-pathbuttons-selection-btn-click"), this.leftRepeater = new Ext.util.ClickRepeater(t, {
            interval: this.scrollRepeatInterval,
            handler: this.onShowMenu,
            scope: this
        }), this.menuBtn = t
    },
    onShowMenu: function() {
        var e = this.menuBtn.getXY();
        this.selMenu.isVisible() ? this.selMenu.hide() : this.selMenu.showAt([e[0] + -5, e[1] + 28])
    },
    updateScrollandSelMenu: function() {
        for (var e, t = this.items.length, i = t - 1, n = 0, s = this.stripWrap.getWidth(), o = i; o >= 0 && (e = this.items[o].el.child(".cs-pathbutton-center"), !((n += e.getWidth() + 14) > s)); o--);
        o == i && (o -= 1), this.selMenu.removeAll();
        for (var a = 0; a <= o; a++) this.selMenu.addItem({
            obj: this.items[a],
            text: this.items[a].text
        });
        var r = this.items[o + 1],
            l = this.stripWrap.dom.scrollLeft,
            d = r.el.getOffsetsTo(this.stripWrap)[0] + l;
        this.stripWrap.scrollTo("left", d - 14)
    },
    getScrollWidth: function() {
        return this.edge.getOffsetsTo(this.stripWrap)[0] + this.getScrollPos()
    },
    getScrollPos: function() {
        return parseInt(this.stripWrap.dom.scrollLeft, 10) || 0
    },
    getScrollAnim: function() {
        return {
            duration: this.scrollDuration,
            scope: this
        }
    }
}), SYNO.SDS.CSTN.PathBar.PathButton = function(e, t, i, n, s, o, a, r, l) {
    this.rb = l, this.setPath(s), this.setNodeId(o);
    var d = a ? this.firstBtnCls : "",
        c = r ? this.lastBtnCls : "";
    SYNO.SDS.CSTN.PathBar.PathButton.superclass.constructor.call(this, {
        text: i,
        itemId: t,
        renderTo: e,
        tooltip: n,
        clickEvent: "mousedown",
        listeners: {
            click: {
                fn: function() {
                    var e = this.getPath(),
                        t = this.getNodeId();
                    if (t) {
                        var i = {};
                        i.name = e, i.node_id = t, this.rb.onChangeDir("normal", i)
                    }
                },
                scope: this
            }
        },
        template: new Ext.Template('<table cellspacing="0" class="x-btn ' + d + " " + c + ' {3}"><tbody><tr>', '<td class="cs-pathbutton-left"></td>', '<td class="cs-pathbutton-center"><em class="{5} unselectable="on">', '<button class="x-btn-text {2}" type="{1}" style="height:18px;">{0}</button>', "</em></td>", '<td class="cs-pathbutton-right"></td>', "</tr></tbody></table>")
    }), this.setPath(s)
}, Ext.extend(SYNO.SDS.CSTN.PathBar.PathButton, Ext.Button, {
    firstBtnCls: "x-first-btn",
    lastBtnCls: "x-last-btn",
    setPath: function(e) {
        this.path = e
    },
    getPath: function() {
        return this.path
    },
    setNodeId: function(e) {
        this.node_id = e
    },
    getNodeId: function() {
        return this.node_id
    },
    updateButton: function(e, t, i, n, s) {
        this.setPath(i), this.setText(e), this.setTooltip(t), this.setNodeId(n), s ? this.addClass(this.lastBtnCls) : this.removeClass(this.lastBtnCls)
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanel.SelectiveFolder", {
    extend: "SYNO.SDS.CloudStation.Component.ExtendedTreePanel.BaseTree",
    constructor: function(e) {
        var t = Ext.apply({}, e);
        return this.callParent([t])
    },
    initEvents: function() {
        var e = this.callParent(arguments);
        return this.mon(this, "checkchange", this.onCheckChange, this), this.mon(this, "beforeexpandnode", this.beforeExpandNode, this), this.mon(this, "beforeappend", this.beforeAppend, this), e
    },
    get_state_by_children: function(e) {
        var t = 0,
            i = 0,
            n = 0;
        return e.eachChild(function(e) {
            var s = e.getUI() || {};
            !s.checkbox || !Ext.isFunction(s.getCheckValue) || Ext.isFunction(s.isDisabled) && s.isDisabled() || (!0 === s.getCheckValue() ? i += 1 : !1 === s.getCheckValue() && (n += 1), t += 1)
        }), 0 === t ? e.getUI().getCheckValue() : i === t || "gray"
    },
    propagate_down: function(e, t) {
        var i = function(e, t) {
            e.eachChild(function(e) {
                i(e, t)
            });
            var n = e.getUI();
            n && Ext.isFunction(n.setCheckValue) && n.setCheckValue(t)
        };
        i(e, t)
    },
    set_pnode_checked: function(e, t) {
        var i = e.getUI();
        i && Ext.isFunction(i.getCheckValue) && (e.attributes.checked = this.get_state_by_children(e), i.syncCheckCssClass())
    },
    propagate_up: function(e, t) {
        for (; e;) this.set_pnode_checked(e, t), e = e.parentNode
    },
    onCheckChange: function(e, t) {
        this.propagate_down(e, t), this.propagate_up(e.parentNode, t)
    },
    beforeExpandNode: function(e, t, i) {
        e.eachChild(function(t) {
            !0 === t.attributes.checked_TBD && (t.attributes.checked = !1 !== e.attributes.checked, t.attributes.checked_TBD = !1, t.getUI().syncCheckCssClass())
        }, this), e.sort(function(e, t) {
            var i = e.attributes.text,
                n = t.attributes.text;
            return i < n ? -1 : i > n
        })
    },
    beforeAppend: function(e, t, i) {
        var n, s = i.attributes.path;
        return Ext.each(t.childNodes, function(e) {
            e.attributes.path == s && (n = e)
        }), !n || (n.attributes.filtered = n.attributes.filtered || i.attributes.filtered, n.attributes.map_entries.push.apply(n.attributes.map_entries, i.attributes.map_entries), !1)
    }
}), Ext.define("SYNO.SDS.CloudStation.Component.ExtendedTreePanel.FolderLoader.Regular", {
    extend: "SYNO.SDS.CloudStation.Component.ExtendedTreePanel.FolderLoader.Base",
    clearOnLoad: !1,
    paramsAsHash: !0,
    constructor: function() {
        var e = this.callParent(arguments),
            t = this.baseParams;
        return this.baseParams = {
            url: this.url,
            params: t
        }, this.on("beforeload", function(e, t) {
            this.removeNotFilteredChildren(t), this.baseParams.params.map_entries = t.attributes.map_entries, this.baseParams.params.path = t.attributes.path
        }, this), e
    },
    createNode: function(e) {
        return e.checked = !0, e.checked_TBD = !0, this.callParent(arguments)
    },
    removeNotFilteredChildren: function(e) {
        for (var t = e.childNodes.length - 1; t >= 0; t--) !1 === e.childNodes[t].attributes.filtered && e.removeChild(e.childNodes[t], !0)
    },
    directFn: function(e, t) {
        Ext.Ajax.request({
            method: "POST",
            url: e.url,
            params: Ext.encode(e.params),
            callback: function(e, i, n) {
                var s = Ext.decode(n.responseText),
                    o = {};
                s.success ? o.status = !0 : o.status = !1, t(s.children, o)
            },
            scope: this
        })
    }
});
