/* Copyright (c) 2020 Synology Inc. All rights reserved. */


Ext.define("SYNO.SDS.USBCopy.View.TaskListView", {
    extend: "SYNO.ux.FleXcroll.DataView",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemSelector: "div.syno-usbcopy-task",
            itemId: "taskListView",
            singleSelect: true,
            overClass: "x-view-over",
            emptyText: "<div></div>",
            store: {
                xtype: "jsonstore",
                fields: ["id", "name", "type_icon", "status"],
                root: "tasks"
            },
            tpl: this.getInnerTpl(),
            ctCls: "syno-usbcopy-task-list"
        };
        return Ext.apply(a, b)
    },
    getInnerTpl: function() {
        var a = new Ext.XTemplate("<div>", '<tpl for=".">', '<div class="syno-usbcopy-task">', '<div class="syno-usbcopy-tasktype syno-usbcopy-tasktype-{type_icon}"></div>', '<div ext:qtip="{[this.encodeTwice(values.name)]}"class="normal-font syno-usbcopy-tasktext">{[this.encode(values.name)]}</div>', '<div class="syno-usbcopy-taskstatus syno-usbcopy-task-{status}"></div>', "</div>", "</tpl>", "</div>", {
            encode: function(b) {
                return Ext.util.Format.htmlEncode(b)
            },
            encodeTwice: function(b) {
                return this.encode(this.encode(b))
            }
        });
        a.compile();
        return a
    }
});
Ext.define("SYNO.SDS.USBCopy.View.TaskListPanel", {
    extend: "Ext.Panel",
    taskListView: null,
    button_width: 68,
    button_height: 28,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "taskListPanel",
            xtype: "panel",
            bodyStyle: "border-top: 0px; border-right: 1px; border-left: 0px; border-bottom: 0px; border-color: #c6d4e0b3; border-style: solid",
            region: "west",
            layout: {
                type: "vbox",
                align: "stretch"
            },
            margins: "0 15 0 0",
            width: 240,
            items: [{
                xtype: "panel",
                layout: "hbox",
                layoutConfig: {
                    defaultMargins: {
                        top: 0,
                        right: 6,
                        bottom: 0,
                        left: 0
                    }
                },
                align: "stretch",
                padding: "16px 12px",
                border: false,
                cls: "syno-usbcopy-button-panel",
                items: [{
                    itemId: "createBtn",
                    xtype: "syno_button",
                    btnStyle: "blue",
                    width: this.button_width,
                    height: this.button_height,
                    iconCls: "syno-usbcopy-create-btn-icon",
                    tooltip: _USBCOPY_STR("common", "create_task"),
                    scope: this
                }, {
                    itemId: "logBtn",
                    xtype: "syno_button",
                    width: this.button_width,
                    height: this.button_height,
                    iconCls: "syno-usbcopy-log-btn-icon",
                    tooltip: _USBCOPY_STR("common", "log"),
                    scope: this
                }, {
                    itemId: "configureBtn",
                    xtype: "syno_button",
                    width: this.button_width,
                    height: this.button_height,
                    iconCls: "syno-usbcopy-configure-btn-icon",
                    tooltip: _USBCOPY_STR("common", "set_global_setting"),
                    scope: this
                }]
            }, {
                xtype: "panel",
                layout: "fit",
                align: "stretch",
                border: false,
                cls: "syno-ux-modulelist",
                flex: 1,
                items: [this.getTaskListView(b)]
            }]
        };
        return Ext.apply(a, b)
    },
    getTaskListView: function(a) {
        if (null === this.taskListView) {
            this.taskListView = new SYNO.SDS.USBCopy.View.TaskListView({
                owner: this.owner,
                application: a.application,
                flex: 1
            })
        }
        return this.taskListView
    }
});
Ext.define("SYNO.SDS.USBCopy.View.OverviewTab", {
    extend: "Ext.Panel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(c) {
        var b = new Ext.Container({
            itemId: "overviewButtons",
            layout: "hbox",
            layoutConfig: {
                defaultMargins: {
                    top: 0,
                    right: 6,
                    bottom: 0,
                    left: 0
                }
            },
            items: [{
                xtype: "syno_button",
                itemId: "runButton",
                text: _T("common", "run"),
                scope: this
            }, {
                xtype: "syno_button",
                itemId: "cancelButton",
                text: _T("common", "cancel"),
                hidden: true,
                scope: this
            }, {
                xtype: "syno_button",
                itemId: "enableButton",
                text: _USBCOPY_STR("common", "enable"),
                hidden: true,
                scope: this
            }, {
                xtype: "syno_button",
                itemId: "disableButton",
                text: _USBCOPY_STR("common", "disable"),
                hidden: true,
                scope: this
            }, {
                xtype: "syno_button",
                itemId: "deleteButton",
                text: _T("common", "delete"),
                scope: this
            }]
        });
        var a = {
            itemId: "overviewTab",
            title: _USBCOPY_STR("common", "overview"),
            layout: {
                type: "vbox",
                align: "stretch"
            },
            border: false,
            bodyStyle: "padding: 8px 0px 0px 0px;",
            items: [{
                xtype: "container",
                itemId: "topContainer",
                cls: "syno-usbcopy-overview-card",
                layout: {
                    type: "hbox"
                },
                bodyStyle: "padding: 0px;",
                border: true,
                autoHeight: true,
                margins: "0 0 14 0",
                items: [{
                    itemId: "overviewIcon",
                    xtype: "box",
                    tpl: '<div class="syno-usbcopy syno-usbcopy-overview-icon syno-usbcopy-overview-icon-{status}"></div>'
                }, {
                    xtype: "container",
                    margins: {
                        top: 28,
                        right: 20,
                        bottom: 14,
                        left: 20
                    },
                    autoHeight: true,
                    flex: 1,
                    items: [{
                        itemId: "overviewText",
                        xtype: "box",
                        tpl: '<div id="icon-text" class="syno-usbcopy syno-usbcopy-overview-icon-text syno-usbcopy-overview-icon-text-{status}">{status_title}</div><div id="update-desc" class="normal-font syno-usbcopy syno-usbcopy-overview-update-desc">{status_desc}</div>'
                    }, b]
                }]
            }, {
                xtype: "syno_panel",
                cls: "syno-usbcopy-overview-card",
                itmeId: "infoPanel",
                autoHeight: true,
                padding: "18px 20px 9px 20px",
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "title",
                    cls: "syno-usbcopy-overview-summary-title",
                    value: _USBCOPY_STR("common", "information")
                }, {
                    xtype: "syno_fieldset",
                    itemId: "infoFieldset",
                    cls: "syno-usbcopy-overview-summary-fieldset",
                    labelWidth: 220
                }]
            }]
        };
        return Ext.apply(a, c)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.BasicSettingPanel", {
    extend: "SYNO.ux.FormPanel",
    filedWidth: 314,
    labelWidth: 200,
    toolTipWidth: 24,
    folderIconWidth: 28,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    getlabelStyle: function(a) {
        return SYNO.SDS.USBCopy.getlabelStyle(a, this.labelWidth)
    },
    getTaskNameField: function() {
        return {
            xtype: "syno_textfield",
            itemId: "taskName",
            name: "name",
            fieldLabel: _USBCOPY_STR("common", "task_name"),
            width: this.filedWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "task_name")),
            allowBlank: false,
            maxLength: 64
        }
    },
    getSourceFolderField: function() {
        return {
            xtype: "syno_compositefield",
            itemId: "sourceFolderCompos",
            fieldLabel: _USBCOPY_STR("common", "source_folder"),
            width: this.filedWidth + this.toolTipWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "source_folder")),
            items: [{
                xtype: "syno_textfield",
                itemId: "sourceFolderPath",
                name: "source_path",
                width: this.filedWidth,
                cls: "folderpath-textfield",
                allowBlank: false,
                readOnly: true
            }, {
                xtype: "syno_displayfield",
                itemId: "sourceBrowserButton",
                cls: "syno-usbcopy-folder-icon"
            }]
        }
    },
    getDestinationFolderField: function() {
        return {
            xtype: "syno_compositefield",
            itemId: "destinationFolderCompos",
            fieldLabel: _USBCOPY_STR("common", "destination_folder"),
            width: this.filedWidth + this.toolTipWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "destination_folder")),
            items: [{
                xtype: "syno_textfield",
                itemId: "destinationFolderPath",
                name: "destination_path",
                width: this.filedWidth,
                cls: "folderpath-textfield",
                allowBlank: false,
                readOnly: true
            }, {
                xtype: "syno_displayfield",
                itemId: "destinationBrowserButton",
                cls: "syno-usbcopy-folder-icon"
            }]
        }
    },
    getImportPhotoRemoveSrcFileCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "importPhotoRemoveSrcFile",
            name: "import_photo_remove_src_file",
            checked: false,
            hidden: true,
            boxLabel: _USBCOPY_STR("common", "remove_source_file")
        }
    },
    getCopyStrategyCombobox: function() {
        var a = new Ext.data.ArrayStore({
            fields: ["value", "display"],
            data: [
                ["versioning", _USBCOPY_STR("common", "copy_strategy_versioning")],
                ["mirror", _USBCOPY_STR("common", "copy_strategy_mirror")],
                ["incremental", _USBCOPY_STR("common", "copy_strategy_incremental")]
            ]
        });
        return {
            xtype: "syno_combobox",
            itemId: "copyStrategy",
            name: "copy_strategy",
            fieldLabel: _USBCOPY_STR("common", "copy_strategy"),
            width: this.filedWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "copy_strategy")),
            displayField: "display",
            valueField: "value",
            store: a,
            value: "versioning"
        }
    }
});
Ext.define("SYNO.SDS.USBCopy.View.StrategyDisplayField", {
    extend: "SYNO.ux.DisplayField",
    realValue: "",
    setValue: function(a) {
        this.realValue = a;
        switch (a) {
            case "versioning":
                this.callParent([_USBCOPY_STR("common", "copy_strategy_versioning")]);
                break;
            case "mirror":
                this.callParent([_USBCOPY_STR("common", "copy_strategy_mirror")]);
                break;
            case "incremental":
                this.callParent([_USBCOPY_STR("common", "copy_strategy_incremental")]);
                break
        }
    },
    getValue: function() {
        return this.realValue
    }
});
Ext.reg("syno_usbcopy_strategy_displayfield", SYNO.SDS.USBCopy.View.StrategyDisplayField);
Ext.define("SYNO.SDS.USBCopy.View.SettingTab", {
    extend: "SYNO.SDS.USBCopy.View.BasicSettingPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "settingTab",
            title: _USBCOPY_STR("common", "task_setting"),
            useDefaultBtn: true,
            trackResetOnLoad: true,
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            autoFlexcroll: true,
            items: [this.getTaskNameField(), this.getTaskNameDisplayField(), this.getSourceFolderField(), this.getDestinationFolderField(), this.getImportPhotoRemoveSrcFileCheckbox(), this.getCopyStrategyAndButtons()]
        };
        return Ext.apply(a, b)
    },
    getTaskNameDisplayField: function() {
        return {
            xtype: "syno_displayfield",
            itemId: "taskNameDisplayField",
            fieldLabel: _USBCOPY_STR("common", "task_name"),
            width: this.filedWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "task_name"))
        }
    },
    getCopyStrategyAndButtons: function() {
        return {
            xtype: "syno_compositefield",
            itemId: "copyStrategyCompositeField",
            fieldLabel: _USBCOPY_STR("common", "copy_strategy"),
            width: this.filedWidth,
            labelWidth: this.labelWidth,
            labelStyle: this.getlabelStyle(_USBCOPY_STR("common", "copy_strategy")),
            items: [this.getCopyStrategyCombobox(), this.getRotationSettingButton(), this.getIncrementalSettingButton()]
        }
    },
    getCopyStrategyCombobox: function() {
        return {
            xtype: "syno_usbcopy_strategy_displayfield",
            itemId: "copyStrategy",
            name: "copy_strategy",
            height: 28
        }
    },
    getRotationSettingButton: function() {
        return {
            xtype: "syno_button",
            itemId: "rotationSetting",
            text: _USBCOPY_STR("common", "rotation_settings"),
            hidden: true,
            ref: "../rotation_setting"
        }
    },
    getIncrementalSettingButton: function() {
        return {
            xtype: "syno_button",
            itemId: "incrementalSetting",
            text: _USBCOPY_STR("common", "advanced_setting"),
            hidden: true,
            ref: "../incremental_setting"
        }
    },
    applyHandler: function() {
        this.fireEvent("applyButtonClick", this)
    },
    cancelHandler: function() {
        this.fireEvent("resetButtonClick", this)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.TriggerTimeTab", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getRunTaskWhenPlugInDeviceCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "runTaskWhenPlugInDevice",
            name: "run_when_plug_in",
            checked: false,
            boxLabel: _USBCOPY_STR("common", "run_task_when_plug_in_device")
        }
    },
    getEjectAfterTaskFinishedCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "ejectAfterTaskFinished",
            name: "eject_when_task_done",
            checked: true,
            boxLabel: _USBCOPY_STR("common", "eject_after_task_finished")
        }
    },
    getTaskHelpSection: function() {
        return {
            xtype: "box",
            itemId: "taskHelp",
            autoWidth: true,
            tpl: '<div class="task-help-section"><div class="task-help-title">{title}:</div><div class="task-help-content">{content}</div></div>'
        }
    },
    getScheduleContainer: function() {
        return {
            xtype: "container",
            items: [{
                xtype: "syno_checkbox",
                itemId: "enableSchedule",
                checked: false,
                boxLabel: _USBCOPY_STR("common", "enable_schedule")
            }, new SYNO.SDS.TaskScheduler2.EditSchedulePanel({
                itemId: "synoSchedule",
                autoHeight: true,
                disabled: true
            })]
        }
    },
    setStatus: function(d) {
        d = d || {};
        var c = this.getFooterToolbar();
        if (c && Ext.isFunction(c.setStatus)) {
            c.setStatus(d)
        }
    },
    setStatusOK: function(b) {
        b = b || {};
        Ext.applyIf(b, {
            text: _T("common", "setting_applied"),
            iconCls: "syno-ux-statusbar-success",
            clear: true
        });
        this.setStatus(b)
    },
    setStatusError: function(b) {
        b = b || {};
        Ext.applyIf(b, {
            text: _T("common", "error_system"),
            iconCls: "syno-ux-statusbar-error"
        });
        this.setStatus(b)
    },
    fillConfig: function(b) {
        var a = {
            itemId: "triggerTimeTab",
            title: _USBCOPY_STR("common", "trigger_time_title"),
            cls: "syno-ux-formpanel",
            bodyStyle: "top: -8px",
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            autoFlexcroll: true,
            items: [this.getRunTaskWhenPlugInDeviceCheckbox(), this.getEjectAfterTaskFinishedCheckbox(), this.getTaskHelpSection(), this.getScheduleContainer()],
            fbar: {
                xtype: "statusbar",
                defaultText: "&nbsp;",
                statusAlign: "left",
                buttonAlign: "left",
                items: [{
                    itemId: "resetButton",
                    xtype: "syno_button",
                    btnStyle: "grey",
                    text: _T("common", "reset")
                }, {
                    itemId: "applyButton",
                    xtype: "syno_button",
                    btnStyle: "blue",
                    text: _T("common", "commit")
                }]
            }
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.BasicFilterPanel", {
    extend: "SYNO.ux.FormPanel",
    fileExtensionsTreePanel: undefined,
    treeWidth: 620,
    treeHeight: 240,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.basicFillConfig(a)])
    },
    getFileExtensionsTreePanel: function() {
        if (this.fileExtensionsTreePanel === undefined) {
            var a = {
                itemId: "fileExtensionsTreePanel",
                cls: "syno-usbcopy-basic-file-extension-tree-panel",
                updateScrollBarEventNames: ["afterlayout", "expandnode", "collapsenode", "resize", "append", "remove"],
                owner: this.owner,
                width: this.treeWidth,
                height: this.treeHeight,
                useArrows: true,
                rootVisible: false,
                padding: 0,
                margins: {
                    top: 5,
                    right: 0,
                    bottom: 3,
                    left: 0
                },
                useGradient: false,
                enableDD: false,
                root: new Ext.tree.TreeNode({
                    text: ""
                })
            };
            this.fileExtensionsTreePanel = new SYNO.ux.TreePanel(a)
        }
        return this.fileExtensionsTreePanel
    },
    getCustomInputField: function() {
        return {
            xtype: "syno_panel",
            itemId: "customInoutCompos",
            layout: "border",
            width: "100%",
            height: 34,
            border: false,
            items: [{
                xtype: "syno_textfield",
                itemId: "customExtension",
                region: "center",
                allowBlank: false,
                enableKeyEvents: true,
                validationEvent: false,
                margins: {
                    top: 0,
                    right: 6,
                    bottom: 5,
                    left: 0
                },
                reset: function() {
                    SYNO.ux.TextField.prototype.reset.call(this);
                    this.fireEvent("fieldreset")
                },
                regex: /^(\*\.)?[^\*\:\?\"<\>\|\\\/]+$/,
                emptyText: _USBCOPY_STR("common", "customized_comment")
            }, {
                xtype: "syno_button",
                itemId: "customExtensionButton",
                margins: {
                    top: 0,
                    right: 0,
                    bottom: 5,
                    left: 0
                },
                region: "east",
                disabled: true,
                text: _USBCOPY_STR("common", "add")
            }]
        }
    },
    basicFillConfig: function(b) {
        var a = {
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            items: [{
                xtype: "syno_displayfield",
                value: _USBCOPY_STR("common", "file_filter_comment")
            }, this.getFileExtensionsTreePanel(), {
                xtype: "syno_displayfield",
                style: {
                    paddingTop: "8px",
                    paddingBottom: "0px"
                },
                value: _USBCOPY_STR("common", "customized_desc")
            }, this.getCustomInputField()]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.FilterTab", {
    extend: "SYNO.SDS.USBCopy.View.BasicFilterPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "filterTab",
            title: _USBCOPY_STR("common", "filter_setting"),
            useDefaultBtn: true,
            listeners: {
                resize: function(c, h, f, e, g, d) {
                    this.getFileExtensionsTreePanel().setWidth(h - 20);
                    this.getFileExtensionsTreePanel().setHeight(f - 165)
                },
                scope: this
            }
        };
        return Ext.apply(a, b)
    },
    applyHandler: function() {
        this.fireEvent("applyButtonClick", this)
    },
    cancelHandler: function() {
        this.fireEvent("resetButtonClick", this)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.TaskTabPanel", {
    extend: "SYNO.ux.TabPanel",
    overviewTab: null,
    settingTab: null,
    triggerTimeTab: null,
    filterTab: null,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "taskTabPanel",
            cls: "syno-usbcopy-task-tab",
            deferredRender: false,
            layoutOnTabChange: true,
            border: false,
            plain: true,
            activeTab: 0,
            region: "center",
            height: 500,
            style: "padding: 16px 16px 0px 16px",
            items: [this.getOverviewTab(b), this.getSettingTab(b), this.getTriggerTimeTab(b), this.getFilterTab(b)]
        };
        return Ext.apply(a, b)
    },
    getOverviewTab: function() {
        if (null === this.overviewTab) {
            this.overviewTab = new SYNO.SDS.USBCopy.View.OverviewTab({
                owner: this.owner
            })
        }
        return this.overviewTab
    },
    getSettingTab: function() {
        if (null === this.settingTab) {
            this.settingTab = new SYNO.SDS.USBCopy.View.SettingTab({
                owner: this.owner
            })
        }
        return this.settingTab
    },
    getTriggerTimeTab: function() {
        if (null === this.triggerTimeTab) {
            this.triggerTimeTab = new SYNO.SDS.USBCopy.View.TriggerTimeTab({
                owner: this.owner
            })
        }
        return this.triggerTimeTab
    },
    getFilterTab: function() {
        if (null === this.filterTab) {
            this.filterTab = new SYNO.SDS.USBCopy.View.FilterTab({
                owner: this.owner
            })
        }
        return this.filterTab
    }
});
Ext.define("SYNO.SDS.USBCopy.View.MainPanel", {
    extend: "Ext.Panel",
    taskListPanel: null,
    taskTabPanel: null,
    backgroundPanel: null,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "mainPanel",
            border: false,
            width: SYNO.SDS.USBCopy.WinWidth,
            layout: "border",
            cls: "syno-usbcopy",
            items: [this.getTaskListPanel(b), this.getTaskTabPanel(b)]
        };
        return Ext.apply(a, b)
    },
    getTaskListPanel: function(a) {
        if (null === this.taskListPanel) {
            this.taskListPanel = new SYNO.SDS.USBCopy.View.TaskListPanel({
                margins: "0 0 0 0",
                owner: this.owner,
                application: a.application
            })
        }
        return this.taskListPanel
    },
    getTaskTabPanel: function(a) {
        if (null === this.taskTabPanel) {
            this.taskTabPanel = new SYNO.SDS.USBCopy.View.TaskTabPanel({
                owner: this.owner,
                application: a.application
            })
        }
        return this.taskTabPanel
    }
});
/**
 * @class SYNO.SDS.USBCopy.View.MainWindow
 * @extends SYNO.SDS.AppWindow
 * USBCopy main window class
 *
 */
Ext.define("SYNO.SDS.USBCopy.View.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    panelMain: null,
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.setWidth(SYNO.SDS.USBCopy.WinWidth);
        this.setHeight(SYNO.SDS.USBCopy.WinHeight)
    },
    getMainPanel: function(a) {
        if (null === this.panelMain) {
            this.panelMain = new SYNO.SDS.USBCopy.View.MainPanel({
                owner: this,
                application: a.application
            })
        }
        return this.panelMain
    },
    fillConfig: function(a) {
        return Ext.apply({
            dsmStyle: "v5",
            itemId: "appWindow",
            minWidth: SYNO.SDS.USBCopy.MinWidth,
            minHeight: SYNO.SDS.USBCopy.MinHeight,
            maximizable: true,
            resizable: true,
            layout: "fit",
            cls: "",
            items: [this.getMainPanel(a)]
        }, a)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.Wizard.TypePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getTypeButton: function(a) {
        return {
            xtype: "container",
            itemId: a.itemId,
            cls: "syno-usbcopy-wizard-task-type-select",
            hideBorders: true,
            border: false,
            margins: a.margins,
            height: 116,
            width: 620,
            layout: {
                type: "hbox",
                align: "middle"
            },
            items: [{
                xtype: "box",
                width: 72,
                height: 72,
                margins: {
                    top: 0,
                    right: 32,
                    bottom: 0,
                    left: 32
                },
                html: '<div class="' + a.icon + '">'
            }, {
                xtype: "box",
                tpl: '<div class="syno-usbcopy-wizard-task-type-title">{title}</div><div class="syno-usbcopy-wizard-task-type-content">{content}</div>',
                data: {
                    title: a.title,
                    content: a.content
                }
            }]
        }
    },
    fillConfig: function(b) {
        var a = {
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            autoFlexcroll: false,
            cls: "syno-usbcopy-wizard-task-type-panel",
            layout: {
                type: "vbox",
                align: "center"
            },
            items: [this.getTypeButton({
                itemId: "importPhotosTask",
                icon: "syno-usbcopy-wizard-task-type-select-icon-import_photo",
                title: _USBCOPY_STR("type", "icon_import_photo"),
                content: _USBCOPY_STR("type", "detail_import_photo"),
                margins: "0 0 20 0"
            }), this.getTypeButton({
                itemId: "importTask",
                icon: "syno-usbcopy-wizard-task-type-select-icon-import",
                title: _USBCOPY_STR("type", "icon_import_general"),
                content: _USBCOPY_STR("type", "detail_import_general"),
                margins: "0 0 20 0"
            }), this.getTypeButton({
                itemId: "exportTask",
                icon: "syno-usbcopy-wizard-task-type-select-icon-export",
                title: _USBCOPY_STR("type", "icon_export_general"),
                content: _USBCOPY_STR("type", "detail_export_general"),
                margins: "0 0 4 0"
            })]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.Wizard.SettingPanel", {
    extend: "SYNO.SDS.USBCopy.View.BasicSettingPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getHardwareBehaviorHelp: function() {
        return {
            xtype: "syno_displayfield",
            itemId: "hardwareBehaviorHelp",
            htmlEncode: false,
            value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _USBCOPY_STR("common", "hardware_behavior_desc")
        }
    },
    getCopyStrategyHelp: function() {
        return {
            xtype: "box",
            itemId: "copyStrategyHelp",
            autoWidth: true,
            tpl: '<div class="copy-strategy-help-section"><div class="copy-strategy-help-title">{title}:</div><div class="copy-strategy-help-content">{content}</div></div>'
        }
    },
    getRunTaskWhenPlugInDeviceCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "runTaskWhenPlugInDevice",
            checked: false,
            boxLabel: _USBCOPY_STR("common", "run_task_when_plug_in_device")
        }
    },
    getEjectAfterTaskFinishedCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "ejectAfterTaskFinished",
            checked: true,
            boxLabel: _USBCOPY_STR("common", "eject_after_task_finished")
        }
    },
    getIncrementalBackupSettingField: function() {
        return new SYNO.SDS.USBCopy.View.IncrementalSettingWindow.IncrementalSettingPanel({
            owner: this.owner
        })
    },
    fillConfig: function(b) {
        var a = {
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            autoFlexcroll: true,
            items: [this.getTaskNameField(), this.getSourceFolderField(), this.getDestinationFolderField(), this.getRunTaskWhenPlugInDeviceCheckbox(), this.getEjectAfterTaskFinishedCheckbox(), this.getImportPhotoRemoveSrcFileCheckbox(), this.getCopyStrategyCombobox(), this.getHardwareBehaviorHelp(), this.getCopyStrategyHelp(), this.getIncrementalBackupSettingField()]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.Wizard.RotationSettingPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getEnableRotationCheckbox: function() {
        return {
            region: "north",
            xtype: "syno_checkbox",
            itemId: "enable_rotation",
            name: "enable_rotation",
            boxLabel: _USBCOPY_STR("common", "enable_backup_rotation"),
            scope: this
        }
    },
    getRotateForm: function() {
        return {
            xtype: "syno_formpanel",
            region: "center",
            border: false,
            frame: false,
            itemId: "rotate_form",
            labelWidth: 200,
            fieldWidth: 230,
            items: [{
                xtype: "syno_displayfield",
                hideLabel: true,
                itemId: "versions_desc",
                indent: 1,
                value: _USBCOPY_STR("common", "versions_desc")
            }, {
                xtype: "syno_radio",
                itemId: "earliest_versions",
                name: "rotation_policy",
                checked: true,
                boxLabel: _USBCOPY_STR("common", "oldest_version"),
                inputValue: SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION,
                indent: 2
            }, {
                xtype: "syno_radio",
                itemId: "smart_recycle",
                name: "rotation_policy",
                boxLabel: _USBCOPY_STR("common", "smart_recycle"),
                inputValue: SYNO.SDS.USBCopy.ROTATION_SMART_RECYCLE,
                indent: 2
            }, {
                xtype: "syno_displayfield",
                hideLabel: true,
                itemId: "version_numbers_desc",
                indent: 1,
                value: _USBCOPY_STR("common", "version_numbers_desc")
            }, {
                xtype: "syno_numberfield",
                itemId: "max_version_count",
                name: "max_version_count",
                indent: 2,
                labelWidth: 200,
                fieldLabel: _USBCOPY_STR("common", "max_version_count"),
                regex: /^\d+$/,
                allowBlank: false,
                allowNegative: false,
                maxlength: 5,
                minValue: 1,
                maxValue: 65535,
                enableKeyEvents: true
            }]
        }
    },
    getWrapperPanel: function() {
        return {
            xtype: "syno_panel",
            itemId: "wrapper_panel",
            name: "wrapper_panel",
            layout: "border",
            height: 280,
            padding: 0,
            items: [this.getEnableRotationCheckbox(), this.getRotateForm()]
        }
    },
    fillConfig: function(b) {
        var a = {
            padding: "24px, 0px, 0px, 0px",
            autoFlexcroll: false,
            items: [this.getWrapperPanel()]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.Wizard.TriggerTimePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getRunTaskWhenPlugInDeviceCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "runTaskWhenPlugInDevice",
            checked: false,
            boxLabel: _USBCOPY_STR("common", "run_task_when_plug_in_device")
        }
    },
    getEjectAfterTaskFinishedCheckbox: function() {
        return {
            xtype: "syno_checkbox",
            itemId: "ejectAfterTaskFinished",
            checked: true,
            boxLabel: _USBCOPY_STR("common", "eject_after_task_finished")
        }
    },
    getScheduleContainer: function() {
        return {
            xtype: "container",
            layout: "form",
            labelWidth: 230,
            items: [{
                xtype: "syno_checkbox",
                itemId: "enableSchedule",
                checked: false,
                boxLabel: _USBCOPY_STR("common", "enable_schedule")
            }, {
                xtype: "syno_schedulefield",
                itemId: "runOnDays",
                fieldLabel: _T("schedule", "run_on_days"),
                name: "basic_weekday",
                indent: 1,
                width: 304,
                disabled: true,
                allowBlank: false,
                editable: false
            }, {
                xtype: "syno_compositefield",
                itemId: "firstRunTime",
                fieldLabel: _T("schedule", "run_time_first"),
                indent: 1,
                disabled: true,
                items: [{
                    xtype: "syno_combobox",
                    store: SYNO.SDS.USBCopy.createTimeItemStore("hour"),
                    displayField: "display",
                    itemId: "hour",
                    valueField: "value",
                    value: 0,
                    triggerAction: "all",
                    mode: "local",
                    width: 145,
                    editable: false
                }, {
                    xtype: "syno_displayfield",
                    value: ":",
                    tabindex: -1
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.USBCopy.createTimeItemStore("min"),
                    displayField: "display",
                    itemId: "minute",
                    valueField: "value",
                    value: 0,
                    triggerAction: "all",
                    width: 145,
                    mode: "local",
                    editable: false
                }]
            }]
        }
    },
    fillConfig: function(b) {
        var a = {
            hideLabel: true,
            hideBorders: true,
            border: false,
            header: false,
            autoFlexcroll: true,
            items: [this.getRunTaskWhenPlugInDeviceCheckbox(), this.getEjectAfterTaskFinishedCheckbox(), this.getScheduleContainer()]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.Wizard.WizardWindow", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    typePanel: undefined,
    settingPanel: undefined,
    rotationSettingPanel: undefined,
    filterPanel: undefined,
    triggerTimePanel: undefined,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    getTypePanel: function() {
        if (this.typePanel === undefined) {
            this.typePanel = new SYNO.SDS.USBCopy.View.Wizard.TypePanel({
                itemId: "typePanel",
                headline: _USBCOPY_STR("common", "welcome"),
                showFooter: false,
                owner: this
            })
        }
        return this.typePanel
    },
    getSettingPanel: function() {
        if (this.settingPanel === undefined) {
            this.settingPanel = new SYNO.SDS.USBCopy.View.Wizard.SettingPanel({
                itemId: "settingPanel",
                headline: _USBCOPY_STR("common", "task_setting"),
                owner: this
            })
        }
        return this.settingPanel
    },
    getRotationSettingPanel: function() {
        if (this.rotationSettingPanel === undefined) {
            this.rotationSettingPanel = new SYNO.SDS.USBCopy.View.Wizard.RotationSettingPanel({
                itemId: "rotationSettingPanel",
                headline: _USBCOPY_STR("common", "rotation_settings_title"),
                owner: this
            })
        }
        return this.rotationSettingPanel
    },
    getTriggerTimePanel: function() {
        if (this.triggerTimePanel === undefined) {
            this.triggerTimePanel = new SYNO.SDS.USBCopy.View.Wizard.TriggerTimePanel({
                itemId: "triggerTimePanel",
                headline: _USBCOPY_STR("common", "trigger_time_title"),
                owner: this
            })
        }
        return this.triggerTimePanel
    },
    getFilterPanel: function() {
        if (this.filterPanel === undefined) {
            this.filterPanel = new SYNO.SDS.USBCopy.View.BasicFilterPanel({
                itemId: "filterPanel",
                headline: _USBCOPY_STR("common", "filter_setting"),
                owner: this
            })
        }
        return this.filterPanel
    },
    fillConfig: function(b) {
        var a = {
            itemId: "wizardWindow",
            title: _USBCOPY_STR("common", "app_name"),
            dsmStyle: "v5",
            cls: "syno-usbcopy",
            width: 700,
            height: 540,
            steps: [this.getTypePanel(), this.getSettingPanel(), this.getRotationSettingPanel(), this.getTriggerTimePanel(), this.getFilterPanel()]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.TypePanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    lastSelectedComponent: undefined,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    getNext: function() {
        return "settingPanel"
    },
    getTaskAttributes: function() {
        return {
            type: this.taskType
        }
    },
    onTaskTypeButtonClick: function(a) {
        if (a.itemId === "importTask") {
            this.taskType = "import_general"
        } else {
            if (a.itemId === "exportTask") {
                this.taskType = "export_general"
            } else {
                if (a.itemId === "importPhotosTask") {
                    this.taskType = "import_photo"
                }
            }
        }
        if (this.lastSelectedComponent !== undefined) {
            this.lastSelectedComponent.removeClass("syno-usbcopy-wizard-task-type-selected")
        }
        a.addClass("syno-usbcopy-wizard-task-type-selected");
        this.lastSelectedComponent = a;
        this.create_wizard_widget.go_to(this.getNext())
    },
    clearTaskTypeButtonStyle: function() {
        var b = this.componentQuery("wizardWindow typePanel importTask");
        b.removeClass("syno-usbcopy-wizard-task-type-selected");
        var c = this.componentQuery("wizardWindow typePanel exportTask");
        c.removeClass("syno-usbcopy-wizard-task-type-selected");
        var a = this.componentQuery("wizardWindow typePanel importPhotosTask");
        a.removeClass("syno-usbcopy-wizard-task-type-selected")
    },
    checkShareExist: function() {
        var a = this.componentQuery("wizardWindow");
        a.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.Share",
            version: 1,
            method: "list",
            params: {
                shareType: ["local", "usb", "dec", "c2"]
            },
            callback: function(h, b, d) {
                a.clearStatusBusy();
                if (h) {
                    var c, g, f = 0,
                        e = 0;
                    for (c = 0; c < b.shares.length; c++) {
                        g = b.shares[c].external_dev_type;
                        if (g === "USB" || g === "SDCARD") {
                            f++
                        } else {
                            e++
                        }
                    }
                    if (f === 0) {
                        a.getMsgBox().alert("", _USBCOPY_STR("warning", "no_usb_share"), function() {
                            a.close()
                        }, this)
                    } else {
                        if (e === 0) {
                            a.getMsgBox().confirm("", _USBCOPY_STR("confirm", "no_ds_share"), function(i) {
                                if (i === "yes") {
                                    SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                        fn: "SYNO.SDS.AdminCenter.Share.Main"
                                    })
                                }
                                a.close()
                            }, this)
                        }
                    }
                } else {
                    a.getMsgBox().alert("", _USBCOPY_STR("warning", "err_sys"), function() {
                        a.close()
                    }, this)
                }
            },
            scope: this
        })
    },
    init: function() {
        this.create_wizard_widget = this.application;
        this.checkShareExist();
        var a = this.componentQuery("wizardWindow").getStep("typePanel");
        a.getNext = Ext.createDelegate(this.getNext, this);
        var c = this;
        var d = this.componentQuery("wizardWindow typePanel importTask");
        d.mon(d.getEl(), "click", function() {
            c.onTaskTypeButtonClick(d)
        });
        var e = this.componentQuery("wizardWindow typePanel exportTask");
        e.mon(e.getEl(), "click", function() {
            c.onTaskTypeButtonClick(e)
        });
        var b = this.componentQuery("wizardWindow typePanel importPhotosTask");
        b.mon(b.getEl(), "click", function() {
            c.onTaskTypeButtonClick(b)
        });
        this.control({
            "wizardWindow typePanel": {
                beforeshow: this.clearTaskTypeButtonStyle
            }
        })
    }
});
Ext.define("SYNO.SDS.USBCopy.View.IncrementalSettingWindow.IncrementalSettingWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "incrementalSettingWindow",
            title: _USBCOPY_STR("common", "advanced_setting"),
            cls: "syno-usbcopy",
            resizable: false,
            layout: "fit",
            width: 600,
            height: 420,
            padding: "11px 20px 0px 20px",
            items: [new SYNO.SDS.USBCopy.View.IncrementalSettingWindow.IncrementalSettingPanel({
                owner: this
            })],
            buttons: [{
                itemId: "cancelBtn",
                btnStyle: "grey",
                text: _T("common", "cancel")
            }, {
                itemId: "OKBtn",
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "apply")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.IncrementalSettingWindow.IncrementalSettingPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            xtype: "container",
            layout: "form",
            itemId: "incrementalBackupSetting",
            autoFlexcroll: false,
            padding: 0,
            items: [{
                xtype: "syno_checkbox",
                itemId: "dontKeepSourceFolder",
                name: "not_keep_dir_structure",
                boxLabel: _USBCOPY_STR("common", "dont_keep_source_folder")
            }, {
                xtype: "syno_radio",
                itemId: "createFolderByMtime",
                name: "dontKeepSourceOption",
                inputValue: "createFolder",
                boxLabel: _USBCOPY_STR("common", "smart_reorganize_all_file_by_file_mtime"),
                disabled: true,
                checked: true,
                indent: 1
            }, {
                xtype: "syno_radio",
                itemId: "renamePhotosByMtime",
                name: "dontKeepSourceOption",
                inputValue: "renamePhoto",
                boxLabel: _USBCOPY_STR("common", "rename_photos_by_file_mtime"),
                disabled: true,
                indent: 1
            }, {
                xtype: "syno_radio",
                itemId: "createFolderRenamePhoto",
                inputValue: "createFolderRenamePhoto",
                name: "dontKeepSourceOption",
                boxLabel: _USBCOPY_STR("common", "smart_reorganize_rename_photo"),
                disabled: true,
                indent: 1
            }, {
                xtype: "syno_checkbox",
                itemId: "removeSrcFile",
                name: "remove_src_file",
                boxLabel: _USBCOPY_STR("common", "remove_source_file"),
                checked: false
            }, {
                xtype: "syno_displayfield",
                value: _USBCOPY_STR("common", "conflict_policy")
            }, {
                itemId: "rename",
                xtype: "syno_radio",
                name: "conflict_policy",
                inputValue: "rename",
                boxLabel: _USBCOPY_STR("common", "rename"),
                checked: true,
                indent: 1
            }, {
                itemId: "overwrite",
                xtype: "syno_radio",
                name: "conflict_policy",
                inputValue: "overwrite",
                boxLabel: _USBCOPY_STR("common", "overwrite"),
                indent: 1
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.IncrementalSettingWindow.IncrementalSettingWindow", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.IncrementalSettingWindow.IncrementalSettingWindow",
    controllers: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a]);
        this.task = a.task
    },
    setData: function(a) {
        this.componentQuery("removeSrcFile", this.panel).setValue(a.remove_src_file);
        this.componentQuery("dontKeepSourceFolder", this.panel).setValue(a.not_keep_dir_structure);
        if (!a.not_keep_dir_structure) {
            this.componentQuery("createFolderByMtime", this.panel).setDisabled(true);
            this.componentQuery("renamePhotosByMtime", this.panel).setDisabled(true);
            this.componentQuery("createFolderRenamePhoto", this.panel).setDisabled(true)
        }
        if (a.smart_create_date_dir === true && a.rename_photo_video === false) {
            this.componentQuery("createFolderByMtime", this.panel).setValue(true)
        } else {
            if (a.smart_create_date_dir === false && a.rename_photo_video === true) {
                this.componentQuery("renamePhotosByMtime", this.panel).setValue(true)
            } else {
                if (a.smart_create_date_dir === true && a.rename_photo_video === true) {
                    this.componentQuery("createFolderRenamePhoto", this.panel).setValue(true)
                }
            }
        }
        if (a.conflict_policy === "rename") {
            this.componentQuery("rename", this.panel).setValue(true)
        } else {
            this.componentQuery("overwrite", this.panel).setValue(true)
        }
    },
    getData: function() {
        var a = {};
        a.remove_src_file = this.componentQuery("removeSrcFile", this.panel).getValue();
        a.not_keep_dir_structure = this.componentQuery("dontKeepSourceFolder", this.panel).getValue();
        if (a.not_keep_dir_structure) {
            if (this.componentQuery("createFolderByMtime", this.panel).getValue()) {
                a.smart_create_date_dir = true;
                a.rename_photo_video = false
            } else {
                if (this.componentQuery("renamePhotosByMtime", this.panel).getValue()) {
                    a.smart_create_date_dir = false;
                    a.rename_photo_video = true
                } else {
                    a.smart_create_date_dir = true;
                    a.rename_photo_video = true
                }
            }
        } else {
            a.smart_create_date_dir = false;
            a.rename_photo_video = false
        }
        if (this.componentQuery("rename", this.panel).getValue()) {
            a.conflict_policy = "rename"
        } else {
            a.conflict_policy = "overwrite"
        }
        return a
    },
    loadSetting: function() {
        this.window.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "get",
            params: {
                id: this.task.id
            },
            callback: function(e, c, d) {
                if (e) {
                    var b = c.task;
                    var a = this.getIncrementalSetting(b);
                    this.setData(a);
                    Ext.apply(this.task, b);
                    this.window.clearStatusBusy()
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(c))
                }
            },
            scope: this
        });
        return
    },
    onDontKeepSourceFolderSet: function(d) {
        if (undefined === d) {
            d = this.componentQuery("dontKeepSourceFolder", this.panel)
        }
        var a = this.componentQuery("createFolderByMtime", this.panel);
        var b = this.componentQuery("renamePhotosByMtime", this.panel);
        var c = this.componentQuery("createFolderRenamePhoto", this.panel);
        if (d.getValue() === true) {
            a.enable();
            b.enable();
            c.enable()
        } else {
            a.disable();
            b.disable();
            c.disable()
        }
    },
    isDirty: function(a, b) {
        for (var c in a) {
            if (b[c] !== a[c]) {
                return true
            }
        }
        return false
    },
    getIncrementalSetting: function(b) {
        var a = {};
        a.remove_src_file = b.remove_src_file;
        a.not_keep_dir_structure = b.not_keep_dir_structure;
        a.smart_create_date_dir = b.smart_create_date_dir;
        a.rename_photo_video = b.rename_photo_video;
        a.conflict_policy = b.conflict_policy;
        return a
    },
    setIncrementalSetting: function(a) {
        var b = {};
        Ext.apply(b, this.task);
        b.remove_src_file = a.remove_src_file;
        b.not_keep_dir_structure = a.not_keep_dir_structure;
        b.smart_create_date_dir = a.smart_create_date_dir;
        b.rename_photo_video = a.rename_photo_video;
        b.conflict_policy = a.conflict_policy;
        return b
    },
    onOKBtnClick: function() {
        var c = this.owner.application.getController("TaskListPanel").getTaskStatus(this.task.id);
        var b = this.getData();
        var d = this.getIncrementalSetting(this.task);
        var a = this.isDirty(b, d);
        if (!a) {
            this.window.close();
            return
        }
        var e = this.setIncrementalSetting(b);
        if ((c === "waiting" || c === "copying") && a) {
            this.owner.getMsgBox().confirm(_USBCOPY_STR("app", "app_name"), _USBCOPY_STR("confirm", "abort_task"), function(f) {
                if (f === "yes") {
                    this.doSettingApply(e)
                }
            }, this);
            return false
        }
        this.doSettingApply(e)
    },
    doSettingApply: function(a) {
        this.window.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_setting",
            params: {
                id: a.id,
                task_setting: a
            },
            callback: function(e, c, d) {
                if (e) {
                    Ext.apply(this.task, a);
                    var b = this.app().mainApplication;
                    b.getController("TaskListPanel").updateTask(this.task.id, function() {
                        b.getController("OverviewTab").loadOverview();
                        this.owner.clearStatusBusy()
                    }, this);
                    this.window.close()
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(c))
                }
            },
            scope: this
        })
    },
    onCancelBtnClick: function() {
        this.window.close()
    },
    init: function() {
        this.control({
            "incrementalSettingWindow incrementalBackupSetting dontKeepSourceFolder": {
                check: this.onDontKeepSourceFolderSet
            },
            "incrementalSettingWindow OKBtn": {
                click: this.onOKBtnClick
            },
            "incrementalSettingWindow cancelBtn": {
                click: this.onCancelBtnClick
            }
        });
        this.window = this.getViewport();
        this.panel = this.componentQuery("incrementalBackupSetting", this.window);
        this.loadSetting()
    }
});
Ext.define("SYNO.SDS.USBCopy.View.RotationSettingWindow.RotationSettingWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "rotationSettingWindow",
            title: _USBCOPY_STR("common", "rotation_settings_title"),
            cls: "syno-usbcopy",
            resizable: false,
            layout: "fit",
            width: 600,
            height: 340,
            padding: "11px 20px 0px 20px",
            items: [new SYNO.SDS.USBCopy.View.RotationSettingWindow.RotationSettingPanel({
                owner: this
            })],
            buttons: [{
                itemId: "cancelBtn",
                btnStyle: "grey",
                text: _T("common", "cancel")
            }, {
                itemId: "OKBtn",
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "commit")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.RotationSettingWindow.RotationSettingPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "rotationSettingPanel",
            cls: "syno-usbcopy-rotation-setting-panel",
            autoFlexcroll: false,
            layout: "border",
            padding: 0,
            items: [{
                region: "north",
                xtype: "syno_checkbox",
                itemId: "enable_rotation",
                name: "enable_rotation",
                boxLabel: _USBCOPY_STR("common", "enable_backup_rotation"),
                scope: this
            }, {
                xtype: "syno_formpanel",
                region: "center",
                border: false,
                frame: false,
                itemId: "rotate_form",
                labelWidth: 200,
                fieldWidth: 230,
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: true,
                    itemId: "versions_desc",
                    indent: 1,
                    value: _USBCOPY_STR("common", "versions_desc")
                }, {
                    xtype: "syno_radio",
                    itemId: "earliest_versions",
                    name: "rotation_policy",
                    checked: true,
                    boxLabel: _USBCOPY_STR("common", "oldest_version"),
                    inputValue: SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION,
                    indent: 2
                }, {
                    xtype: "syno_radio",
                    itemId: "smart_recycle",
                    name: "rotation_policy",
                    boxLabel: _USBCOPY_STR("common", "smart_recycle"),
                    inputValue: SYNO.SDS.USBCopy.ROTATION_SMART_RECYCLE,
                    indent: 2
                }, {
                    xtype: "syno_displayfield",
                    hideLabel: true,
                    itemId: "version_numbers_desc",
                    indent: 1,
                    value: _USBCOPY_STR("common", "version_numbers_desc")
                }, {
                    xtype: "syno_numberfield",
                    itemId: "max_version_count",
                    name: "max_version_count",
                    indent: 2,
                    labelWidth: 200,
                    fieldLabel: _USBCOPY_STR("common", "max_version_count"),
                    regex: /^\d+$/,
                    allowBlank: false,
                    allowNegative: false,
                    maxlength: 5,
                    minValue: 1,
                    maxValue: 65535,
                    enableKeyEvents: true
                }]
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.RotationSettingWindow.RotationSettingWindow", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.RotationSettingWindow.RotationSettingWindow",
    controllers: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a]);
        this.task = a.task
    },
    setData: function(a) {
        if (!a.enable_rotation) {
            this.componentQuery("rotate_form", this.panel).setDisabled(true)
        }
        this.componentQuery("enable_rotation", this.panel).setValue(a.enable_rotation);
        if (SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION === a.rotation_policy) {
            this.componentQuery("earliest_versions", this.panel).setValue(true)
        } else {
            if (SYNO.SDS.USBCopy.ROTATION_SMART_RECYCLE === a.rotation_policy) {
                this.componentQuery("smart_recycle", this.panel).setValue(true)
            }
        }
        this.componentQuery("max_version_count", this.panel).setValue(a.max_version_count)
    },
    getData: function() {
        var a = {};
        a.enable_rotation = this.componentQuery("enable_rotation", this.panel).getValue();
        a.rotation_policy = this.componentQuery("earliest_versions", this.panel).getGroupValue();
        a.max_version_count = this.componentQuery("max_version_count", this.panel).getValue();
        return a
    },
    loadSetting: function() {
        this.window.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "get",
            params: {
                id: this.task.id
            },
            callback: function(e, b, c) {
                if (e) {
                    var a = b.task;
                    var d = this.getRotationSetting(a);
                    this.setData(d);
                    Ext.apply(this.task, a);
                    this.window.clearStatusBusy()
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(b))
                }
            },
            scope: this
        });
        return
    },
    onCheckEnableRotation: function(c, b) {
        var a = this.componentQuery("rotate_form", this.panel);
        if (b) {
            a.setDisabled(false)
        } else {
            a.setDisabled(true)
        }
    },
    isValid: function() {
        var a = this.componentQuery("max_version_count", this.panel).validate();
        return a
    },
    isDirty: function(c, a) {
        for (var b in c) {
            if (a[b] !== c[b]) {
                return true
            }
        }
        return false
    },
    getRotationSetting: function(a) {
        var b = {};
        b.enable_rotation = a.enable_rotation;
        b.rotation_policy = a.rotation_policy;
        b.max_version_count = a.max_version_count;
        return b
    },
    setRotationSetting: function(b) {
        var a = {};
        Ext.apply(a, this.task);
        a.enable_rotation = b.enable_rotation;
        a.rotation_policy = b.rotation_policy;
        a.max_version_count = b.max_version_count;
        return a
    },
    onOKBtnClick: function() {
        if (!this.isValid()) {
            this.window.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return
        }
        var b = this.getData();
        var a = this.getRotationSetting(this.task);
        if (!this.isDirty(b, a)) {
            this.window.close();
            return
        }
        var c = this.setRotationSetting(b);
        this.window.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_setting",
            params: {
                id: c.id,
                task_setting: c
            },
            callback: function(g, e, f) {
                if (g) {
                    Ext.apply(this.task, c);
                    var d = this.app().mainApplication;
                    d.getController("TaskListPanel").updateTask(this.task.id, function() {
                        d.getController("OverviewTab").loadOverview();
                        this.owner.clearStatusBusy()
                    }, this);
                    this.window.close()
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(e))
                }
            },
            scope: this
        })
    },
    onCancelBtnClick: function() {
        this.window.close()
    },
    init: function() {
        this.control({
            "rotationSettingWindow enable_rotation": {
                check: this.onCheckEnableRotation
            },
            "rotationSettingWindow OKBtn": {
                click: this.onOKBtnClick
            },
            "rotationSettingWindow cancelBtn": {
                click: this.onCancelBtnClick
            }
        });
        this.window = this.getViewport();
        this.panel = this.componentQuery("rotationSettingPanel", this.window);
        var a = this.componentQuery("smart_recycle", this.panel);
        var b = _T("backup", "rotate_action_smart_recycle_description") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_hourly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_hourly_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_daily") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_daily_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_weekly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_weekly_hint") + "<br/>";
        SYNO.ux.AddTip(a.getEl(), b);
        this.loadSetting()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.BasicSettingPanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    settingPanel: undefined,
    taskType: undefined,
    getTaskSetting: function() {
        var a = {};
        a.name = this.componentQuery("taskName", this.settingPanel).getValue();
        a.source_path = this.componentQuery("sourceFolderCompos sourceFolderPath", this.settingPanel).getValue();
        a.destination_path = this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel).getValue();
        a.copy_strategy = this.componentQuery("copyStrategy", this.settingPanel).getValue();
        a.import_photo_remove_src_file = this.componentQuery("importPhotoRemoveSrcFile", this.settingPanel).getValue();
        return a
    },
    onCopyStrategySet: function(b) {
        if (undefined === b) {
            b = this.componentQuery("copyStrategy", this.settingPanel)
        }
        var a = this.componentQuery("incrementalBackupSetting", this.settingPanel);
        if (b.getValue() === "incremental") {
            a.setVisible(true)
        } else {
            a.setVisible(false)
        }
        this.settingPanel.doLayout()
    },
    onSourceBrowserButtonClick: function() {
        var d = SYNO.SDS.USBCopy.isImportType(this.taskType) ? "usb" : "ds";
        var a = this.componentQuery("sourceFolderCompos sourceFolderPath", this.settingPanel);
        var b = SYNO.SDS.USBCopy.getFileChooserCfg(this.owner, a, d);
        var c = new SYNO.SDS.USBCopy.Component.FileChooser.Chooser(b);
        c.show()
    },
    onDestinationBrowserButtonClick: function() {
        var d = SYNO.SDS.USBCopy.isImportType(this.taskType) ? "ds" : "usb";
        var a = this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel);
        var b = SYNO.SDS.USBCopy.getFileChooserCfg(this.owner, a, d);
        var c = new SYNO.SDS.USBCopy.Component.FileChooser.Chooser(b);
        c.show()
    },
    basicInit: function(d) {
        var a = {};
        a[d + "copyStrategy"] = {
            select: this.onCopyStrategySet
        };
        this.control(a);
        var c = this.componentQuery("sourceFolderCompos sourceBrowserButton", this.settingPanel);
        c.mon(c.getEl(), "click", this.onSourceBrowserButtonClick, this);
        var b = this.componentQuery("destinationFolderCompos destinationBrowserButton", this.settingPanel);
        b.mon(b.getEl(), "click", this.onDestinationBrowserButtonClick, this)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.SettingPanel", {
    extend: "SYNO.SDS.USBCopy.Controller.BasicSettingPanel",
    getTaskAttributes: function() {
        var a = this.getTaskSetting();
        if (a.copy_strategy === "incremental") {
            Ext.apply(a, this.getIncrementalSetting())
        }
        if (this.taskType === "import_photo") {
            a.remove_src_file = a.import_photo_remove_src_file;
            a.run_when_plug_in = this.componentQuery("runTaskWhenPlugInDevice", this.settingPanel).getValue();
            a.eject_when_task_done = this.componentQuery("ejectAfterTaskFinished", this.settingPanel).getValue()
        } else {
            if (a.copy_strategy !== "incremental") {
                a.remove_src_file = false
            }
        }
        delete a.import_photo_remove_src_file;
        return a
    },
    getIncrementalSetting: function() {
        var a = {};
        var b = this.componentQuery("incrementalBackupSetting", this.settingPanel);
        a.remove_src_file = this.componentQuery("removeSrcFile", b).getValue();
        a.not_keep_dir_structure = this.componentQuery("dontKeepSourceFolder", b).getValue();
        if (a.not_keep_dir_structure) {
            if (this.componentQuery("createFolderByMtime", b).getValue()) {
                a.smart_create_date_dir = true;
                a.rename_photo_video = false
            } else {
                if (this.componentQuery("renamePhotosByMtime", b).getValue()) {
                    a.smart_create_date_dir = false;
                    a.rename_photo_video = true
                } else {
                    a.smart_create_date_dir = true;
                    a.rename_photo_video = true
                }
            }
        } else {
            a.smart_create_date_dir = false;
            a.rename_photo_video = false
        }
        if (this.componentQuery("rename", b).getValue()) {
            a.conflict_policy = "rename"
        } else {
            a.conflict_policy = "overwrite"
        }
        return a
    },
    setStrategyHelp: function(a) {
        this.componentQuery("copyStrategyHelp", this.settingPanel).update({
            title: _USBCOPY_STR("common", "copy_strategy_" + a),
            content: _USBCOPY_STR("common", "copy_strategy_desc_" + a)
        });
        this.settingPanel.doLayout()
    },
    onSettingPanelActivate: function() {
        this.taskType = this.app().getController("TypePanel").getTaskAttributes().type;
        if (this.previousType === this.taskType) {
            return
        }
        this.previousType = this.taskType;
        this.settingPanel.getForm().reset();
        var b = this.componentQuery("copyStrategy", this.settingPanel);
        var e = this.componentQuery("incrementalBackupSetting", this.settingPanel);
        var c = this.componentQuery("runTaskWhenPlugInDevice", this.settingPanel);
        var a = this.componentQuery("ejectAfterTaskFinished", this.settingPanel);
        var d = this.componentQuery("importPhotoRemoveSrcFile", this.settingPanel);
        if (this.taskType === "import_photo") {
            c.setVisible(true);
            a.setVisible(true);
            d.setVisible(true);
            b.setVisible(false);
            b.setValue("incremental");
            this.setStrategyHelp("import_photo");
            e.setVisible(false);
            var g = this.componentQuery("incrementalBackupSetting dontKeepSourceFolder", this.settingPanel);
            g.setValue(true);
            this.onDontKeepSourceFolderSet(g);
            var f = this.componentQuery("incrementalBackupSetting createFolderRenamePhoto", this.settingPanel);
            f.setValue(true);
            this.settingPanel.nextId = null
        } else {
            if (this.taskType === "import_general" || this.taskType === "export_general") {
                c.setVisible(false);
                a.setVisible(false);
                d.setVisible(false);
                b.setVisible(true);
                this.setStrategyHelp("versioning");
                e.setVisible(false);
                this.settingPanel.nextId = "filterPanel"
            }
        }
    },
    onCopyStrategySet: function(d, a, b, c) {
        this.setStrategyHelp(d.getValue());
        this.componentQuery("incrementalBackupSetting dontKeepSourceFolder", this.settingPanel).reset();
        this.componentQuery("incrementalBackupSetting createFolderByMtime", this.settingPanel).reset();
        this.componentQuery("incrementalBackupSetting renamePhotosByMtime", this.settingPanel).reset();
        this.componentQuery("incrementalBackupSetting removeSrcFile", this.settingPanel).reset();
        this.componentQuery("incrementalBackupSetting rename", this.settingPanel).reset();
        this.componentQuery("incrementalBackupSetting overwrite", this.settingPanel).reset();
        this.callParent(arguments)
    },
    onDontKeepSourceFolderSet: function(d) {
        if (undefined === d) {
            d = this.componentQuery("dontKeepSourceFolder", this.settingPanel)
        }
        var a = this.componentQuery("createFolderByMtime", this.settingPanel);
        var b = this.componentQuery("renamePhotosByMtime", this.settingPanel);
        var c = this.componentQuery("createFolderRenamePhoto", this.settingPanel);
        if (d.getValue() === true) {
            a.enable();
            b.enable();
            c.enable()
        } else {
            a.disable();
            b.disable();
            c.disable()
        }
    },
    getNext: function() {
        var c = this.componentQuery("wizardWindow");
        if (!this.settingPanel.getForm().isValid()) {
            c.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), _USBCOPY_STR("warning", "please_check_your_setting"));
            return false
        }
        if (this.taskType === "import_photo") {
            var a = {};
            Ext.apply(a, this.app().getController("TypePanel").getTaskAttributes());
            Ext.apply(a, this.app().getController("SettingPanel").getTaskAttributes());
            this.app().getController("FilterPanel").loadDefaultFilter("import_photo");
            Ext.apply(a, this.app().getController("FilterPanel").getTaskAttributes());
            a.schedule_enabled = false;
            a.schedule_content = SYNO.SDS.USBCopy.getDefaultSchedule();
            this.app().createTask(a);
            return false
        } else {
            if (this.taskType === "import_general" || this.taskType === "export_general") {
                var b = this.componentQuery("copyStrategy", this.settingPanel).getValue();
                if (b === "versioning") {
                    return "rotationSettingPanel"
                } else {
                    if (b === "incremental") {
                        return "triggerTimePanel"
                    } else {
                        if (b === "mirror") {
                            this.confirmMirrorStrategy();
                            return false
                        }
                    }
                }
            }
        }
        return false
    },
    confirmMirrorStrategy: function() {
        this.componentQuery("wizardWindow").getMsgBox().confirm(_USBCOPY_STR("common", "copy_strategy_mirror"), _USBCOPY_STR("common", "copy_strategy_confirmation_mirror"), function(a) {
            if ("yes" === a) {
                this.create_wizard_widget.go_to("triggerTimePanel")
            }
        }, this)
    },
    init: function() {
        this.owner = this.componentQuery("wizardWindow");
        this.settingPanel = this.componentQuery("wizardWindow").getStep("settingPanel");
        this.basicInit("wizardWindow settingPanel ");
        this.control({
            "wizardWindow settingPanel": {
                activate: this.onSettingPanelActivate
            },
            "wizardWindow settingPanel incrementalBackupSetting dontKeepSourceFolder": {
                check: this.onDontKeepSourceFolderSet
            }
        });
        this.create_wizard_widget = this.application;
        this.settingPanel.getNext = Ext.createDelegate(this.getNext, this)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.RotationSettingPanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    getTaskAttributes: function() {
        return this.getData()
    },
    setData: function(a) {
        if (!a.enable_rotation) {
            this.componentQuery("rotate_form", this.Panel).setDisabled(true)
        }
        this.componentQuery("enable_rotation", this.Panel).setValue(a.enable_rotation);
        if (SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION === a.rotation_policy) {
            this.componentQuery("earliest_versions", this.Panel).setValue(true)
        } else {
            if (SYNO.SDS.USBCopy.ROTATION_SMART_RECYCLE === a.rotation_policy) {
                this.componentQuery("smart_recycle", this.Panel).setValue(true)
            }
        }
        this.componentQuery("max_version_count", this.Panel).setValue(a.max_version_count)
    },
    getData: function() {
        var a = {};
        a.enable_rotation = this.componentQuery("enable_rotation", this.panel).getValue();
        a.rotation_policy = this.componentQuery("earliest_versions", this.panel).getGroupValue();
        a.max_version_count = this.componentQuery("max_version_count", this.panel).getValue();
        return a
    },
    onRotationSettingPanelActivate: function() {
        this.taskType = this.app().getController("TypePanel").getTaskAttributes().type;
        if (this.previousType === this.taskType) {
            return
        }
        this.previousType = this.taskType;
        var a = this.getDefaultRotationSetting();
        this.setData(a)
    },
    onCheckEnableRotation: function(c, b) {
        var a = this.componentQuery("rotate_form", this.panel);
        if (b) {
            a.setDisabled(false)
        } else {
            a.setDisabled(true)
        }
    },
    isValid: function() {
        var a = this.componentQuery("max_version_count", this.panel).validate();
        return a
    },
    getNext: function() {
        var a = this.componentQuery("wizardWindow");
        if (!this.isValid()) {
            a.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), _USBCOPY_STR("warning", "please_check_your_setting"));
            return false
        }
        return "triggerTimePanel"
    },
    getDefaultRotationSetting: function() {
        var a = {};
        a.enable_rotation = false;
        a.rotation_policy = SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION;
        a.max_version_count = 256;
        return a
    },
    getRotationSetting: function(a) {
        var b = {};
        b.enable_rotation = a.enable_rotation;
        b.rotation_policy = a.rotation_policy;
        b.max_version_count = a.max_version_count;
        return b
    },
    init: function() {
        this.owner = this.componentQuery("wizardWindow");
        this.Panel = this.componentQuery("wizardWindow").getStep("rotationSettingPanel");
        this.control({
            "wizardWindow rotationSettingPanel": {
                activate: this.onRotationSettingPanelActivate
            },
            "wizardWindow enable_rotation": {
                check: this.onCheckEnableRotation
            }
        });
        var a = this.componentQuery("smart_recycle", this.panel);
        var b = _T("backup", "rotate_action_smart_recycle_description") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_hourly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_hourly_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_daily") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_daily_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_weekly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_weekly_hint") + "<br/>";
        SYNO.ux.AddTip(a.getEl(), b);
        this.Panel.getNext = Ext.createDelegate(this.getNext, this)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.TriggerTimePanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    getTaskAttributes: function() {
        var a = {};
        a.run_when_plug_in = this.componentQuery("runTaskWhenPlugInDevice", this.triggerTimePanel).getValue();
        a.eject_when_task_done = this.componentQuery("ejectAfterTaskFinished", this.triggerTimePanel).getValue();
        a.schedule_enabled = this.componentQuery("enableSchedule", this.triggerTimePanel).getValue();
        a.schedule_content = SYNO.SDS.USBCopy.getDefaultSchedule();
        if (a.schedule_enabled) {
            a.schedule_content.week_day = this.componentQuery("runOnDays", this.triggerTimePanel).getValue();
            a.schedule_content.hour = this.componentQuery("hour", this.triggerTimePanel).getValue();
            a.schedule_content.minute = this.componentQuery("minute", this.triggerTimePanel).getValue()
        }
        return a
    },
    onTriggerTimePanelActivate: function() {
        this.taskType = this.app().getController("TypePanel").getTaskAttributes().type;
        if (this.previousType === this.taskType) {
            return
        }
        this.previousType = this.taskType;
        this.triggerTimePanel.getForm().reset()
    },
    onEnableScheduleCheck: function(b, a) {
        this.componentQuery("runOnDays", this.triggerTimePanel).setDisabled(!a);
        this.componentQuery("firstRunTime", this.triggerTimePanel).setDisabled(!a)
    },
    init: function() {
        this.owner = this.componentQuery("wizardWindow");
        this.triggerTimePanel = this.componentQuery("wizardWindow").getStep("triggerTimePanel");
        this.control({
            "wizardWindow triggerTimePanel": {
                activate: this.onTriggerTimePanelActivate
            },
            "wizardWindow triggerTimePanel enableSchedule": {
                check: this.onEnableScheduleCheck
            }
        });
        var a = this.componentQuery("ejectAfterTaskFinished", this.triggerTimePanel);
        var b = _USBCOPY_STR("common", "eject_after_task_finished_qtip") + "<br/>" + _USBCOPY_STR("common", "eject_when_each_tasks_done_qtip");
        SYNO.ux.AddTip(a.getEl(), b)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.BasicFilterPanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    filterPanel: undefined,
    othersSymbol: "*",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    isExtension: function(a) {
        if (a.length < 3) {
            return false
        }
        return a.substr(0, 2) === "*."
    },
    getExtensionName: function(a) {
        if (!this.isExtension(a)) {
            return a
        }
        return a.substr(2)
    },
    checkedAndFocusNode: function(b, a) {
        a.getUI().setCheckboxStatus("checked");
        b.expand(false, false);
        b.getOwnerTree().updateFleXcroll();
        a.select();
        a.ensureVisible()
    },
    createCategoryNode: function(a) {
        return new Ext.tree.TreeNode({
            nodeLevel: "category",
            nodeId: a,
            text: _USBCOPY_STR("common", a),
            uiProvider: SYNO.SDS.USBCopy.Component.FileExtensionsTreeNodeUI,
            checked: true,
            iconCls: "syno-usbcopy-selective-file-category-icon-" + a
        })
    },
    addNewFilterRule: function() {
        var k = this.componentQuery("customInoutCompos customExtension", this.filterPanel);
        if (k.validate() === false) {
            this.customTextKeyup(k);
            return
        }
        var h = k.getValue();
        var a = this.componentQuery("fileExtensionsTreePanel", this.filterPanel).getRootNode();
        var l = !this.isExtension(h);
        var g;
        for (var e = 0; e < a.childNodes.length; e++) {
            var f = a.childNodes[e];
            if (f.attributes.nodeId !== "customized" && l === true) {
                continue
            }
            if (f.attributes.nodeId === "customized") {
                g = f
            }
            for (var d = 0; d < f.childNodes.length; d++) {
                var c = f.childNodes[d];
                if (c.attributes.nodeId === h) {
                    this.checkedAndFocusNode(f, c);
                    k.reset();
                    return
                }
            }
        }
        var b = new Ext.tree.TreeNode({
            nodeLevel: "subItem",
            nodeId: h,
            text: h,
            uiProvider: SYNO.SDS.USBCopy.Component.FileExtensionsTreeNodeUI,
            hasRemoveButton: true,
            checked: true,
            leaf: true
        });
        if (!g) {
            g = this.createCategoryNode("customized");
            a.appendChild(g)
        }
        g.appendChild(b);
        this.checkedAndFocusNode(g, b);
        k.reset()
    },
    customTextKeyup: function(a) {
        if (a.getValue() === "") {
            this.componentQuery("customInoutCompos customExtensionButton", this.filterPanel).disable()
        } else {
            this.componentQuery("customInoutCompos customExtensionButton", this.filterPanel).enable()
        }
    },
    customTextReset: function() {
        this.componentQuery("customInoutCompos customExtensionButton", this.filterPanel).disable()
    },
    basicInit: function(b) {
        var a = {};
        a[b + "customInoutCompos customExtension"] = {
            keyup: this.customTextKeyup,
            fieldreset: this.customTextReset
        };
        a[b + "customInoutCompos customExtensionButton"] = {
            click: this.addNewFilterRule
        };
        this.control(a);
        new Ext.KeyMap(this.componentQuery("customExtension", this.filterPanel).getEl(), {
            key: Ext.EventObject.ENTER,
            fn: this.addNewFilterRule,
            scope: this
        })
    },
    isNodeChecked: function(a) {
        return a.getUI().getCheckboxStatus() === "checked"
    },
    getCategoryNode: function(a, c) {
        for (var b = 0; b < a.childNodes.length; b++) {
            if (a.childNodes[b].attributes.nodeId === c) {
                return a.childNodes[b]
            }
        }
    },
    addIfChecked: function(b, c, k, h) {
        for (var f = 0; f < b.childNodes.length; f++) {
            var g = b.childNodes[f];
            for (var e = 0; e < g.childNodes.length; e++) {
                var d = g.childNodes[e];
                if (c !== this.isNodeChecked(d)) {
                    continue
                }
                var a = d.attributes.nodeId;
                if (g.attributes.nodeId !== "customized" || this.isExtension(a)) {
                    k.push(this.getExtensionName(a))
                } else {
                    h.push(a)
                }
            }
        }
    },
    getFilterList: function() {
        var d = {
            white_list: {
                extensions: [],
                names: []
            },
            black_list: {
                extensions: [],
                names: [".SynologyUSBCopy.config"]
            },
            customized_list: {
                extensions: [],
                names: []
            }
        };
        var a = this.componentQuery("fileExtensionsTreePanel", this.filterPanel).getRootNode();
        var e = this.isNodeChecked(this.getCategoryNode(a, "others"));
        if (e) {
            d.white_list.extensions.push(this.othersSymbol);
            d.white_list.names.push(this.othersSymbol);
            this.addIfChecked(a, false, d.black_list.extensions, d.black_list.names)
        } else {
            this.addIfChecked(a, true, d.white_list.extensions, d.white_list.names)
        }
        var c = this.getCategoryNode(a, "customized");
        for (var b = 0; c && b < c.childNodes.length; b++) {
            var f = c.childNodes[b].attributes.nodeId;
            if (this.isExtension(f)) {
                d.customized_list.extensions.push(this.getExtensionName(f))
            } else {
                d.customized_list.names.push(f)
            }
        }
        return d
    },
    appendSubItemNodes: function(e, h, c) {
        for (var d = 0; d < h.length; d++) {
            var g = h[d];
            var a = g.nodeId,
                j = g.nodeId,
                f = "";
            if (c === "extension") {
                a = "*." + g.nodeId;
                j = "*." + g.nodeId
            }
            var b = new Ext.tree.TreeNode({
                nodeLevel: "subItem",
                nodeId: a,
                text: j,
                uiProvider: SYNO.SDS.USBCopy.Component.FileExtensionsTreeNodeUI,
                rimgCls: f,
                hasRemoveButton: (e.attributes.nodeId === "customized"),
                checked: true,
                leaf: true
            });
            e.appendChild(b);
            b.getUI().setCheckboxStatus((g.isChecked === true) ? "checked" : "unchecked")
        }
    },
    setFilterTree: function(c) {
        var a = this.componentQuery("fileExtensionsTreePanel", this.filterPanel);
        var d = a.getRootNode();
        if (!Ext.isEmpty(d.childNodes)) {
            d.childNodes[0].ensureVisible()
        }
        d.removeAll();
        for (var e = 0; e < c.length; e++) {
            var b = c[e];
            if (b.nodeId === "customized" && Ext.isEmpty(b.extensionfilter) && Ext.isEmpty(b.fileNamefilter)) {
                continue
            }
            var f = this.createCategoryNode(b.nodeId);
            d.appendChild(f);
            f.getUI().setCheckboxStatus((b.isChecked === true) ? "checked" : "unchecked");
            this.appendSubItemNodes(f, b.extensionfilter, "extension");
            this.appendSubItemNodes(f, b.fileNamefilter, "fileName")
        }
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.FilterPanel", {
    extend: "SYNO.SDS.USBCopy.Controller.BasicFilterPanel",
    onFilterPanelActivate: function() {
        this.taskType = this.app().getController("TypePanel").getTaskAttributes().type;
        if (this.previousType === this.taskType) {
            return
        }
        this.previousType = this.taskType;
        this.loadDefaultFilter(this.taskType)
    },
    loadDefaultFilter: function(a) {
        this.setFilterTree(SYNO.SDS.USBCopy.getDefaultFilterTree(a))
    },
    getTaskAttributes: function() {
        return {
            filter: this.getFilterList()
        }
    },
    onApplyButtonClick: function() {
        var b = this.componentQuery("customInoutCompos customExtension", this.filterPanel);
        if (b.isDirty()) {
            b.markInvalid(_USBCOPY_STR("warning", "click_add"));
            return false
        }
        var a = {};
        Ext.apply(a, this.app().getController("TypePanel").getTaskAttributes());
        Ext.apply(a, this.app().getController("SettingPanel").getTaskAttributes());
        if (a.copy_strategy === "versioning") {
            Ext.apply(a, this.app().getController("RotationSettingPanel").getTaskAttributes())
        }
        Ext.apply(a, this.app().getController("TriggerTimePanel").getTaskAttributes());
        Ext.apply(a, this.app().getController("FilterPanel").getTaskAttributes());
        this.app().createTask(a);
        return false
    },
    init: function() {
        this.owner = this.componentQuery("wizardWindow");
        this.filterPanel = this.componentQuery("wizardWindow").getStep("filterPanel");
        this.basicInit("wizardWindow filterPanel ");
        this.control({
            "wizardWindow filterPanel": {
                activate: this.onFilterPanelActivate
            }
        });
        this.filterPanel.getNext = Ext.createDelegate(this.onApplyButtonClick, this)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.Wizard.WizardWindow", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.Wizard.WizardWindow",
    controllers: ["SYNO.SDS.USBCopy.Controller.Wizard.TypePanel", "SYNO.SDS.USBCopy.Controller.Wizard.SettingPanel", "SYNO.SDS.USBCopy.Controller.Wizard.RotationSettingPanel", "SYNO.SDS.USBCopy.Controller.Wizard.TriggerTimePanel", "SYNO.SDS.USBCopy.Controller.Wizard.FilterPanel"],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    go_to: function(a) {
        if (typeof a === "string") {
            this.componentQuery("wizardWindow").goNext(a)
        }
    },
    createTask: function(a) {
        var b = this.componentQuery("wizardWindow");
        b.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "create",
            params: {
                task: a
            },
            callback: function(e, c, d) {
                if (e) {
                    this.app().mainApplication.getController("TaskListPanel").listAndSelectTask(c.task_id, function() {
                        b.clearStatusBusy();
                        b.close()
                    }, this)
                } else {
                    b.clearStatusBusy();
                    b.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), SYNO.SDS.USBCopy.GetErrorString(c))
                }
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.USBCopy.View.ConfigureWindow.ConfigureWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "configureWindow",
            title: _USBCOPY_STR("common", "congfigure_title"),
            cls: "syno-usbcopy",
            resizable: false,
            width: 600,
            height: 240,
            padding: "16px 20px 0px 20px",
            items: [new SYNO.SDS.USBCopy.View.ConfigureWindow.ConfigurePanel({
                owner: this
            })],
            buttons: [{
                itemId: "cancelBtn",
                btnStyle: "grey",
                text: _T("common", "cancel")
            }, {
                itemId: "OKBtn",
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "apply")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.ConfigureWindow.ConfigurePanel", {
    extend: "SYNO.ux.FormPanel",
    fieldWidth: 314,
    labelWidth: 230,
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "configurePanel",
            border: false,
            padding: "0px",
            autoFlexcroll: false,
            trackResetOnLoad: true,
            items: [{
                itemId: "repoCombo",
                xtype: "syno_combobox",
                name: "repo_volume_path",
                fieldLabel: _USBCOPY_STR("common", "database_repo_setting"),
                labelWidth: this.labelWidth,
                width: this.fieldWidth,
                allowBlank: false,
                emptyText: _USBCOPY_STR("common", "choose_repo"),
                store: {
                    xtype: "jsonstore",
                    fields: ["mount_point", "display"]
                },
                valueField: "mount_point",
                displayField: "display",
                triggerAction: "all",
                mode: "local"
            }, {
                itemId: "logRotateCount",
                xtype: "syno_numberfield",
                name: "log_rotate_count",
                fieldLabel: _USBCOPY_STR("common", "log_rotate_count"),
                labelWidth: this.labelWidth,
                width: this.fieldWidth,
                maxValue: SYNO.SDS.USBCopy.MaxLogCount,
                minValue: SYNO.SDS.USBCopy.MinLogCount,
                allowBlank: false,
                allowNegative: false,
                regex: /^\d+$/,
                maxlength: 6
            }, {
                xtype: "syno_checkbox",
                name: "beep_on_task_start_end",
                boxLabel: _USBCOPY_STR("common", "beep_on_task_start_end")
            }]
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.ConfigureWindow.ConfigureWindow", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.ConfigureWindow.ConfigureWindow",
    controllers: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    loadSetting: function() {
        this.window.setStatusBusy();
        var b = {
            api: "SYNO.Core.Storage.Volume",
            version: 1,
            method: "list",
            params: {
                limit: -1,
                offset: 0,
                location: "internal"
            }
        };
        var a = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "get_global_setting"
        };
        var c = [b, a];
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: c
            },
            callback: function(l, f, e, d) {
                if (l && !f.has_fail) {
                    var k = SYNO.API.Response.GetValByAPI(f, "SYNO.Core.Storage.Volume", "list");
                    var h = SYNO.API.Response.GetValByAPI(f, SYNO.SDS.USBCopy.WebAPI, "get_global_setting");
                    if (Ext.isEmpty(k.volumes)) {
                        this.owner.getMsgBox().confirm("", _T("error", "volume_no_volumes"), function(i) {
                            if (i === "yes") {
                                SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                            }
                            this.window.close()
                        }, this)
                    } else {
                        var m = this.componentQuery("repoCombo", this.panel);
                        var j = [],
                            g;
                        for (g = 0; g < k.volumes.length; g++) {
                            j.push({
                                mount_point: k.volumes[g].volume_path,
                                display: SYNO.SDS.Utils.StorageUtils.VolumeNameSizeRenderer(k.volumes[g])
                            })
                        }
                        m.getStore().loadData(j);
                        this.panel.getForm().setValues(h);
                        this.window.hasRepo = (m.getValue() !== "");
                        this.window.clearStatusBusy()
                    }
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(f), function() {
                        this.window.close()
                    }, this)
                }
            },
            scope: this
        })
    },
    onOKBtnClick: function() {
        if (!this.panel.getForm().isValid()) {
            this.window.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return
        }
        if (!this.panel.getForm().isDirty()) {
            this.window.close();
            return
        }
        var a = this.panel.getForm().getValues();
        a.beep_on_task_start_end = (a.beep_on_task_start_end === "true");
        a.log_rotate_count = parseInt(a.log_rotate_count, 10);
        this.window.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_global_setting",
            params: a,
            callback: function(d, b, c) {
                if (d) {
                    this.window.hasRepo = true;
                    this.window.close()
                } else {
                    this.window.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(b))
                }
            },
            scope: this
        })
    },
    onCancelBtnClick: function() {
        this.window.close()
    },
    init: function() {
        this.control({
            "configureWindow OKBtn": {
                click: this.onOKBtnClick
            },
            "configureWindow cancelBtn": {
                click: this.onCancelBtnClick
            }
        });
        this.window = this.getViewport();
        this.panel = this.componentQuery("configurePanel", this.window);
        this.loadSetting()
    }
});
Ext.define("SYNO.SDS.USBCopy.View.LogWindow.LogWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "logWindow",
            title: _USBCOPY_STR("log", "log"),
            cls: "syno-usbcopy",
            resizable: false,
            layout: "fit",
            width: 860,
            height: 530,
            padding: "0px 20px 0px 20px",
            items: [new SYNO.SDS.USBCopy.View.LogWindow.LogPanel({
                owner: this
            })],
            fbar: {
                xtype: "statusbar",
                defaultText: "&nbsp",
                statusAlign: "left",
                buttonAlign: "left",
                items: [{}, {
                    text: _T("common", "close"),
                    xtype: "syno_button",
                    btnStyle: "gray",
                    itemId: "closeBtn"
                }]
            }
        };
        return Ext.apply(a, b)
    }
});
Ext.define("SYNO.SDS.USBCopy.View.LogWindow.LogPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(c) {
        this.pageSize = 200;
        this.logDescIDList = SYNO.SDS.USBCopy.GetListFromObject(SYNO.SDS.USBCopy.DESC_ID);
        var d = this.createStore();
        this.searchPanel = new SYNO.SDS.USBCopy.Model.SearchPanel({
            itemId: "search_panel",
            cls: "syno-usbcopy-search-panel",
            renderTo: Ext.getBody(),
            shadow: false,
            hidden: true,
            owner: this
        });
        this.findField = new SYNO.SDS.USBCopy.Model.AdvancedSearchField({
            itemId: "advanced_search_field",
            iconStyle: "filter",
            owner: this
        });
        this.findField.searchPanel = this.searchPanel;
        var b = new Ext.Toolbar({
            owner: this,
            itemId: "tool_bar",
            items: ["->", this.findField]
        });
        var e = new SYNO.ux.PagingToolbar({
            store: d,
            pageSize: this.pageSize,
            displayInfo: true
        });
        var a = {
            itemId: "logPanel",
            tbar: b,
            cls: "syno-usbcopy-log-panel",
            store: d,
            enableHdMenu: false,
            colModel: this.createColumnModel(c),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: false
            }),
            bbar: e
        };
        return Ext.apply(a, c)
    },
    createColumnModel: function(c) {
        var b = [{
            header: _USBCOPY_STR("log", "log_type"),
            dataIndex: "log_type",
            width: 100,
            sortable: true,
            id: "type",
            align: "left",
            renderer: (function(k, g, d, f, i, e) {
                var h = d.data;
                var j;
                if (h.log_type === SYNO.SDS.USBCopy.LOG_TYPE.INFO_TYPE) {
                    j = _USBCOPY_STR("log", "info_type");
                    j = '<span class="info">' + j + "</span>"
                } else {
                    if (h.log_type === SYNO.SDS.USBCopy.LOG_TYPE.ERROR_TYPE) {
                        j = _USBCOPY_STR("log", "error_type");
                        j = '<span class="error">' + j + "</span>"
                    } else {
                        if (h.log_type === SYNO.SDS.USBCopy.LOG_TYPE.WARN_TYPE) {
                            j = _USBCOPY_STR("log", "warn_type");
                            j = '<span class="warn">' + j + "</span>"
                        }
                    }
                }
                return j
            }).createDelegate(this)
        }, {
            header: _USBCOPY_STR("log", "log_description"),
            dataIndex: "description_id",
            width: 300,
            id: "description",
            sortable: true,
            align: "left",
            renderer: (function(k, g, d, f, i, e) {
                var h = d.data;
                var j = this.getLogTemplate(h.description_id, h.description_parameter, h.error);
                if (g) {
                    g.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(j) + '"'
                }
                return j
            }).createDelegate(this)
        }, {
            header: _USBCOPY_STR("log", "log_timestamp"),
            dataIndex: "timestamp",
            id: "time",
            width: 200,
            sortable: true,
            align: "left",
            renderer: SYNO.SDS.USBCopy.RenderTimeFormat
        }];
        var a = new Ext.grid.ColumnModel({
            defaults: {
                sortable: false,
                menuDisabled: true
            },
            columns: b
        });
        return a
    },
    onBeforeStoreLoad: function(a, b) {
        a.removeAll()
    },
    createStore: function() {
        var a = new SYNO.API.JsonStore({
            api: SYNO.SDS.USBCopy.WebAPI,
            method: "get_log_list",
            version: 1,
            pruneModifiedRecords: true,
            autoLoad: false,
            fields: ["task_id", "log_type", "timestamp", "description_id", "description_parameter", "error"],
            totalProperty: "count",
            idProperty: "id",
            root: "log_list",
            baseParams: {
                offset: 0,
                limit: this.pageSize,
                log_filter: {
                    log_desc_id_list: this.logDescIDList
                }
            },
            appWindow: this,
            listeners: {
                scope: this,
                beforeload: this.onBeforeStoreLoad
            }
        });
        this.addManagedComponent(a);
        return a
    },
    getLogTemplate: function(a, f, d) {
        var c = JSON.parse(f);
        var e;
        var b;
        switch (a) {
            case SYNO.SDS.USBCopy.DESC_ID.TASK_CREATED:
                e = _USBCOPY_STR("log_template", "task_created");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_REMOVED:
                e = _USBCOPY_STR("log_template", "task_removed");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_ENABLED:
                e = _USBCOPY_STR("log_template", "task_enabled");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_DISABLED:
                e = _USBCOPY_STR("log_template", "task_disabled");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.SETTING_CHANGED_NAME:
                e = _USBCOPY_STR("log_template", "setting_changed_name");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>", '<span class = "task_name">' + c[1] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.SETTING_EDITED:
                e = _USBCOPY_STR("log_template", "setting_edited");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_START:
                e = _USBCOPY_STR("log_template", "task_start");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_FINISH:
                e = _USBCOPY_STR("log_template", "task_finish");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_ABORT:
                e = _USBCOPY_STR("log_template", "task_abort");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_ERROR:
                e = _USBCOPY_STR("log_template", "task_error");
                b = SYNO.SDS.USBCopy.GetTaskError(d);
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>", '<span class = "error_reason">' + b + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_VERSION_ROTATION:
                e = _USBCOPY_STR("log_template", "task_version_rotation");
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>", '<span class = "version_folder_name">' + c[1] + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.TASK_ERROR_PARTIALLY_SUCCESS:
                e = _USBCOPY_STR("log_template", "task_error_partially_success");
                b = SYNO.SDS.USBCopy.GetTaskError(d);
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>", '<span class = "error_reason">' + b + "</span>");
            case SYNO.SDS.USBCopy.DESC_ID.FILE_ERROR:
                e = _USBCOPY_STR("log_template", "file_error");
                b = SYNO.SDS.USBCopy.GetFileError(d);
                return String.format(e, '<span class = "task_name">' + c[0] + "</span>", '<span class = "file_base_name">' + c[1] + "</span>", '<span class = "error_reason">' + b + "</span>");
            default:
                e = _USBCOPY_STR("log_template", "unknown_error");
                return String.format(e)
        }
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.LogWindow.LogWindow", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.LogWindow.LogWindow",
    controllers: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a])
    },
    loadStore: function() {
        this.data_store.load()
    },
    onSearch: function(a, b) {
        this.data_store.baseParams = {
            offset: 0,
            limit: this.log_panel.pageSize,
            log_filter: b
        };
        this.loadStore()
    },
    onCloseBtnClick: function() {
        this.window.close()
    },
    init: function() {
        this.control({
            "logWindow closeBtn": {
                click: this.onCloseBtnClick
            }
        });
        this.window = this.getViewport();
        this.log_panel = this.componentQuery("logPanel", this.window);
        this.data_store = this.log_panel.getStore();
        this.find_field = this.log_panel.findField;
        this.search_panel = this.find_field.searchPanel;
        this.mon(this.search_panel, "search", this.onSearch, this);
        this.loadStore()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.TaskListPanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    taskListView: null,
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.isInitializing = true;
        this.owner.setStatusBusy();
        this.control({
            "mainPanel taskListPanel taskListView": {
                selectionchange: this.onSelectionChange,
                beforeclick: this.onBeforeClick
            },
            "mainPanel taskListPanel createBtn": {
                click: this.createTask
            },
            "mainPanel taskListPanel configureBtn": {
                click: this.openGlobalConfigWindow
            },
            "mainPanel taskListPanel logBtn": {
                click: this.openLogWindow
            }
        });
        this.taskListView = this.componentQuery("mainPanel taskListPanel taskListView");
        this.startPolling(true)
    },
    startPolling: function(a) {
        if (this.pollingID) {
            return
        }
        this.pollingID = this.pollReg({
            webapi: {
                api: SYNO.SDS.USBCopy.WebAPI,
                version: 1,
                method: "list"
            },
            interval: 5,
            immediate: a,
            status_callback: this.onPollingDone,
            scope: this
        })
    },
    stopPolling: function() {
        if (!this.pollingID) {
            return
        }
        this.pollUnreg(this.pollingID);
        this.pollingID = null
    },
    getSelectedId: function() {
        var a = this.taskListView.getSelectedItemIds();
        return Ext.isEmpty(a) ? undefined : a[0]
    },
    setNoTaskState: function() {
        this.app().getController("OverviewTab").setNAStatus();
        this.componentQuery("mainPanel taskTabPanel").setActiveTab("overviewTab");
        this.app().getController("TaskListPanel").createTask()
    },
    setDefaultTaskName: function(a) {
        if (a.default_device_port === "USB") {
            a.name = _USBCOPY_STR("common", "default_task_name_usb")
        } else {
            if (a.default_device_port === "SD_CARD") {
                a.name = _USBCOPY_STR("common", "default_task_name_sd")
            }
        }
    },
    setTaskIconDefaultName: function(a) {
        var c = a.tasks;
        var b;
        for (b = 0; b < c.length; b++) {
            if (c[b].is_default_task) {
                c[b].type_icon = "default";
                this.setDefaultTaskName(c[b])
            } else {
                c[b].type_icon = c[b].type
            }
        }
        return a
    },
    onPollingDone: function(d, b) {
        if (this.isInitializing) {
            if (d) {
                this.isInitializing = false;
                this.owner.clearStatusBusy()
            } else {
                this.stopPolling();
                if (b.code === SYNO.SDS.USBCopy.WEBAPI_UC_ERR_NO_REPO) {
                    this.openGlobalConfigWindow()
                } else {
                    this.owner.clearStatusBusy();
                    this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(b), function() {
                        this.componentQuery("appWindow").destroy()
                    }, this)
                }
                return
            }
        }
        if (!d) {
            return
        }
        var c = this.getSelectedId();
        this.taskListView.getStore().loadData(this.setTaskIconDefaultName(b));
        if (this.taskListView.getStore().getCount() > 0) {
            var a = this.taskListView.getStore().getById(c);
            this.taskListView.select(a ? a : 0)
        } else {
            this.setNoTaskState()
        }
    },
    onSelectionChange: function(c, b) {
        if (Ext.isEmpty(b)) {
            return
        }
        var a = c.getRecord(b[0]).json;
        this.app().getController("OverviewTab").onTaskRecordSet(a);
        this.app().getController("SettingTab").onTaskRecordSet(a);
        this.app().getController("TriggerTimeTab").onTaskRecordSet(a);
        this.app().getController("FilterTab").onTaskRecordSet(a.id)
    },
    onBeforeClick: function(e, d, c) {
        var f = e.getSelectedIndexes();
        if (!Ext.isEmpty(f) && f[0] === d) {
            return true
        }
        if (this.app().getController("SettingTab").isTabDirty()) {
            this.componentQuery("mainPanel taskTabPanel").setActiveTab("settingTab");
            this.owner.confirmLostChangePromise({
                save: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("SettingTab").onApplyButtonClick()
                    }.bind(this))
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("SettingTab").onResetButtonClick()
                    }.bind(this))
                },
                confirmText: _USBCOPY_STR("confirm", "confirm_lostchange_with_save")
            }, this, function b() {}, function a() {
                e.select(d)
            });
            return false
        }
        if (this.app().getController("TriggerTimeTab").isTabDirty()) {
            this.componentQuery("mainPanel taskTabPanel").setActiveTab("triggerTimeTab");
            this.owner.confirmLostChangePromise({
                save: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("TriggerTimeTab").onApplyButtonClick()
                    }.bind(this))
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("TriggerTimeTab").onResetButtonClick()
                    }.bind(this))
                },
                confirmText: _USBCOPY_STR("confirm", "confirm_lostchange_with_save")
            }, this, function b() {}, function a() {
                e.select(d)
            });
            return false
        }
        if (this.app().getController("FilterTab").isTabDirty()) {
            this.componentQuery("mainPanel taskTabPanel").setActiveTab("filterTab");
            this.owner.confirmLostChangePromise({
                save: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("FilterTab").onApplyButtonClick()
                    }.bind(this))
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        this.app().getController("FilterTab").onResetButtonClick()
                    }.bind(this))
                },
                confirmText: _USBCOPY_STR("confirm", "confirm_lostchange_with_save")
            }, this, function b() {}, function a() {
                e.select(d)
            });
            return false
        }
        return true
    },
    updateTask: function(a, c, b) {
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "get",
            params: {
                id: a
            },
            callback: function(h, f, g) {
                if (h) {
                    var d = this.taskListView.getStore().getById(a);
                    var e = f.task;
                    if (e.is_default_task) {
                        this.setDefaultTaskName(e)
                    }
                    d.set("name", e.name);
                    d.set("status", e.status);
                    Ext.apply(d.json, e)
                }
                if (c) {
                    c.call(b)
                }
            },
            scope: this
        })
    },
    listAndSelectTask: function(a, c, b) {
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "list",
            callback: function(g, e, f) {
                if (g) {
                    this.taskListView.getStore().loadData(this.setTaskIconDefaultName(e));
                    var d = this.taskListView.getStore().getById(a);
                    this.taskListView.select(d)
                }
                if (c) {
                    c.call(b)
                }
            },
            scope: this
        })
    },
    getTaskStatus: function(a) {
        return this.taskListView.getStore().getById(a).get("status")
    },
    setTaskStatus: function(b, a) {
        this.taskListView.getStore().getById(b).set("status", a)
    },
    createTask: function() {
        var a = this.createWidget(SYNO.SDS.USBCopy.Controller.Wizard.WizardWindow, {
            owner: this.owner
        });
        a.mon(a.getViewport(), "close", function() {
            if (this.taskListView.getStore().getCount() === 0) {
                this.componentQuery("appWindow").destroy();
                return
            }
            this.startPolling(false)
        }, this);
        this.stopPolling();
        a.getViewport().open()
    },
    openGlobalConfigWindow: function() {
        var b = this.createWidget(SYNO.SDS.USBCopy.Controller.ConfigureWindow.ConfigureWindow, {
            owner: this.owner
        });
        var a = b.getViewport();
        b.mon(a, "close", function() {
            if (!a.hasRepo) {
                this.componentQuery("appWindow").destroy();
                return
            }
            this.startPolling(false)
        }, this);
        this.stopPolling();
        a.open()
    },
    openLogWindow: function() {
        var b = this.createWidget(SYNO.SDS.USBCopy.Controller.LogWindow.LogWindow, {
            owner: this.owner
        });
        var a = b.getViewport();
        b.mon(a, "close", function() {
            this.startPolling(false)
        }, this);
        this.stopPolling();
        a.open()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.TaskTabPanel", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    setOverviewBackground: function() {
        this.tabPanel.getEl().setStyle("background-color", "#F4F8FA");
        this.tabPanel.getEl().setStyle("box-shadow", "0 -1px 0 0 rgba(228,230,234,0.95);")
    },
    setDefaultBackground: function() {
        this.tabPanel.getEl().setStyle("background-color", "#FFFFFF")
    },
    beforeTabChange: function(d, f, e) {
        var c;
        if (e.getItemId() === "overviewTab") {
            return true
        } else {
            if (e.getItemId() === "settingTab") {
                c = this.app().getController("SettingTab")
            } else {
                if (e.getItemId() === "triggerTimeTab") {
                    c = this.app().getController("TriggerTimeTab")
                } else {
                    if (e.getItemId() === "filterTab") {
                        c = this.app().getController("FilterTab")
                    }
                }
            }
        }
        if (c.isTabDirty()) {
            this.owner.confirmLostChangePromise({
                save: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        c.onApplyButtonClick()
                    }.bind(this))
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    return new Promise(function(h, g) {
                        this.owner.confirmLostChangeResolve = h;
                        c.onResetButtonClick()
                    }.bind(this))
                },
                confirmText: _USBCOPY_STR("confirm", "confirm_lostchange_with_save")
            }, this, function b() {}, function a() {
                d.setActiveTab(f.getItemId())
            });
            return false
        }
        return true
    },
    onTabChange: function(c, b, a) {
        if (b.itemId == "overviewTab") {
            this.setOverviewBackground()
        } else {
            this.setDefaultBackground()
        }
    },
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.tabPanel = this.componentQuery("mainPanel taskTabPanel");
        this.setOverviewBackground();
        this.control({
            "mainPanel taskTabPanel": {
                beforetabchange: this.beforeTabChange,
                tabchange: this.onTabChange
            }
        })
    }
});
Ext.define("SYNO.SDS.USBCopy.View.EnableTaskDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            itemId: "enableTaskDialog",
            width: 360,
            height: 180,
            title: _USBCOPY_STR("common", "app_name"),
            border: true,
            cls: "syno-usbcopy",
            bodyStyle: "padding: 8px 20px",
            items: [this.getDescriptionField(), this.getDestinationFolderField()],
            buttons: [{
                xtype: "syno_button",
                itemId: "btn_cancel",
                btnStyle: "grey",
                text: _T("common", "cancel")
            }, {
                xtype: "syno_button",
                itemId: "btn_apply",
                btnStyle: "blue",
                text: _T("common", "commit")
            }]
        };
        return Ext.apply(a, b)
    },
    getDescriptionField: function() {
        return {
            xtype: "syno_displayfield",
            value: _USBCOPY_STR("common", "desc_choose_destination_folder")
        }
    },
    getDestinationFolderField: function() {
        return {
            xtype: "syno_compositefield",
            itemId: "destinationFolderCompos",
            width: 334,
            items: [{
                xtype: "syno_textfield",
                itemId: "destinationFolderPath",
                name: "destination_path",
                width: 320,
                cls: "folderpath-textfield",
                allowBlank: false,
                readOnly: true
            }, {
                xtype: "syno_displayfield",
                itemId: "destinationBrowserButton",
                cls: "syno-usbcopy-folder-icon"
            }]
        }
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.EnableTaskDialog", {
    extend: "SYNO.SDS.USBCopy.core.Widget",
    viewport: "SYNO.SDS.USBCopy.View.EnableTaskDialog",
    controllers: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([a]);
        this.task = a.task
    },
    init: function() {
        this.control({
            btn_apply: {
                click: this.onApply
            },
            btn_cancel: {
                click: this.onCancel
            }
        });
        var b = this.componentQuery("enableTaskDialog destinationFolderCompos destinationFolderCompos destinationBrowserButton");
        b.mon(b.getEl(), "click", this.onDestinationBrowserButtonClick, this);
        var a = this.componentQuery("enableTaskDialog destinationFolderCompos destinationFolderPath");
        a.setValue(this.task.destination_path)
    },
    onDestinationBrowserButtonClick: function() {
        var a = this.componentQuery("enableTaskDialog destinationFolderCompos destinationFolderPath");
        var b = SYNO.SDS.USBCopy.getFileChooserCfg(this.owner, a, "ds");
        var c = new SYNO.SDS.USBCopy.Component.FileChooser.Chooser(b);
        c.show()
    },
    onApply: function() {
        if (this.componentQuery("enableTaskDialog destinationFolderCompos destinationFolderPath").isValid() === false) {
            return
        }
        var a = {};
        Ext.apply(a, this.task);
        a.destination_path = this.componentQuery("enableTaskDialog destinationFolderCompos destinationFolderPath").getValue();
        var b = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_setting",
            params: {
                id: a.id,
                task_setting: a
            }
        };
        var d = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "enable",
            params: {
                id: a.id
            }
        };
        var c = [b, d];
        this.getViewport().setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: c
            },
            callback: function(j, f, i, h) {
                if (!j || f.has_fail) {
                    this.getViewport().clearStatusBusy();
                    var g = SYNO.API.Util.GetFirstError(f);
                    this.getViewport().getMsgBox().alert(_USBCOPY_STR("common", "app_name"), SYNO.SDS.USBCopy.GetErrorString(g))
                } else {
                    var e = this.app().mainApplication;
                    e.getController("TaskListPanel").updateTask(this.task.id, function() {
                        e.getController("OverviewTab").loadOverview();
                        this.getViewport().close()
                    }, this)
                }
            },
            scope: this
        })
    },
    onCancel: function() {
        this.getViewport().close()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.OverviewTab", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    overviewPanel: null,
    task: null,
    onTaskRecordSet: function(a) {
        this.task = a;
        if (!this.overviewPanel.hidden) {
            this.loadOverview()
        }
    },
    loadOverview: function() {
        this.setOverviewStatus(this.task.status, this.task.copy_file_path);
        var a = this.task.latest_finish_time;
        this.setInfo({
            name: this.task.name,
            type: SYNO.SDS.USBCopy.getTaskTypeDesc(this.task.type),
            source_path: {
                value: this.task.source_path,
                isLink: !this.task.source_path.startsWith("[USB]")
            },
            destination_path: {
                value: this.task.destination_path,
                isLink: !this.task.destination_path.startsWith("[USB]")
            },
            latest_finish_time: a === 0 ? "-" : SYNO.SDS.USBCopy.DateTimeFormatter(new Date(a * 1000), {
                type: "datetimesec"
            }),
            next_run_time: this.task.next_run_time
        });
        this.overviewPanel.doLayout()
    },
    onActivate: function() {
        this.loadOverview()
    },
    setNAStatus: function() {
        this.setOverviewStatus("na", "");
        this.setInfo({
            name: "-",
            type: "-",
            source_path: {
                value: "-",
                isLink: false
            },
            destination_path: {
                value: "-",
                isLink: false
            },
            latest_finish_time: "-",
            next_run_time: "N/A"
        })
    },
    disableAllButton: function() {
        var a = ["runButton", "cancelButton", "enableButton", "disableButton", "deleteButton"];
        var c, b, d;
        for (c = 0; c < a.length; c++) {
            d = a[c];
            b = this.componentQuery("overviewButtons " + d, this.overviewPanel);
            b.disable()
        }
    },
    showButton: function(b, e) {
        var a = ["runButton", "cancelButton", "enableButton", "disableButton", "deleteButton"];
        var d, c, f;
        for (d = 0; d < a.length; d++) {
            f = a[d];
            c = this.componentQuery("overviewButtons " + f, this.overviewPanel);
            if (-1 !== b.indexOf(f)) {
                if (e) {
                    c.disable()
                } else {
                    c.enable()
                }
                c.show()
            } else {
                c.hide()
            }
        }
        this.componentQuery("overviewButtons", this.overviewPanel).doLayout()
    },
    setOverviewStatus: function(b, e) {
        this.componentQuery("overviewIcon", this.overviewPanel).update({
            status: b
        });
        var d, g;
        var a = SYNO.SDS.USBCopy.GetFileBaseName(e);
        if (b === "failed") {
            d = _USBCOPY_STR("status", "title_" + b);
            g = SYNO.SDS.USBCopy.GetFailReason(this.task.error_code)
        } else {
            if (b === "shareDeleted") {
                d = _USBCOPY_STR("status", "title_share_unavailable");
                g = _USBCOPY_STR("status", "desc_share_deleted")
            } else {
                if (b === "unmounted") {
                    if (!this.task.is_usb_mounted) {
                        if (this.task.is_default_task) {
                            d = _USBCOPY_STR("status", "title_unmounted_default");
                            g = _USBCOPY_STR("status", "desc_unmounted_default")
                        } else {
                            d = _USBCOPY_STR("status", "title_unmounted");
                            g = _USBCOPY_STR("status", "desc_unmounted")
                        }
                    } else {
                        if (!this.task.is_ds_mounted) {
                            d = _USBCOPY_STR("status", "title_unmounted");
                            g = _USBCOPY_STR("status", "desc_failed_share_unmounted")
                        } else {
                            SYNO.Debug.warn("wrong status [unmounted]: is_usb_mounted && is_ds_mounted")
                        }
                    }
                } else {
                    if (b === "shareUnavailable") {
                        d = _USBCOPY_STR("status", "title_share_unavailable");
                        g = _USBCOPY_STR("status", "desc_share_unavailable")
                    } else {
                        if (b === "copying" && a !== "") {
                            d = _USBCOPY_STR("status", "title_" + b);
                            g = String.format(_USBCOPY_STR("status", "desc_copying_file_name"), a)
                        } else {
                            d = _USBCOPY_STR("status", "title_" + b);
                            g = _USBCOPY_STR("status", "desc_" + b)
                        }
                    }
                }
            }
        }
        this.componentQuery("overviewText", this.overviewPanel).update({
            status: b,
            status_title: d,
            status_desc: g
        });
        this.componentQuery("topContainer", this.overviewPanel).doLayout();
        if (e !== "") {
            var f = Ext.util.Format.htmlEncode(e);
            var c = Ext.get("update-desc");
            c.set({
                "ext:qtip": Ext.util.Format.htmlEncode(f)
            })
        }
        switch (b) {
            case "initial":
            case "successful":
                if (this.task.is_default_task) {
                    this.showButton(["runButton", "disableButton"])
                } else {
                    this.showButton(["runButton", "deleteButton"])
                }
                break;
            case "failed":
                if (this.task.is_default_task) {
                    if (this.task.is_task_runnable) {
                        this.showButton(["runButton", "disableButton"])
                    } else {
                        this.showButton(["disableButton"])
                    }
                } else {
                    if (this.task.is_task_runnable) {
                        this.showButton(["runButton", "deleteButton"])
                    } else {
                        this.showButton(["deleteButton"])
                    }
                }
                break;
            case "waiting":
            case "copying":
                if (this.task.is_default_task) {
                    this.showButton(["cancelButton", "disableButton"])
                } else {
                    this.showButton(["cancelButton", "deleteButton"])
                }
                break;
            case "disabled":
                this.showButton(["enableButton"]);
                break;
            case "unmounted":
            case "shareUnavailable":
            case "shareDeleted":
                if (this.task.is_default_task) {
                    this.showButton(["disableButton"])
                } else {
                    this.showButton(["deleteButton"])
                }
                break;
            case "canceling":
                if (this.task.is_default_task) {
                    this.showButton(["cancelButton", "disableButton"], true)
                } else {
                    this.showButton(["cancelButton", "deleteButton"], true)
                }
                break;
            case "na":
                this.showButton(["runButton", "deleteButton"], true);
                break
        }
    },
    setInfo: function(c) {
        var a = this.componentQuery("infoFieldset", this.overviewPanel);
        a.removeAll();
        this.addInfo(a, _USBCOPY_STR("common", "task_name"), c.name, false);
        this.addInfo(a, _USBCOPY_STR("common", "task_type"), c.type, false);
        this.addInfo(a, _USBCOPY_STR("common", "source_folder"), c.source_path.value, c.source_path.isLink);
        this.addInfo(a, _USBCOPY_STR("common", "destination_folder"), c.destination_path.value, c.destination_path.isLink);
        this.addInfo(a, _USBCOPY_STR("common", "latest_finish_time"), c.latest_finish_time, false);
        if (c.next_run_time !== "N/A") {
            var b = Date.parseDate(c.next_run_time, "Y-n-j G:i");
            if (!Ext.isDefined(b)) {
                return
            }
            this.addInfo(a, _USBCOPY_STR("common", "next_run_time"), SYNO.SDS.USBCopy.DateTimeFormatter(b, {
                type: "datetimesec"
            }), false)
        }
    },
    addInfo: function(a, b, f, e) {
        var c = Ext.util.Format.htmlEncode(f);
        var d = new SYNO.ux.DisplayField({
            xtype: "syno_displayfield",
            cls: e ? "usb-copy-hyperlink" : "usb-copy-summary-field",
            fieldLabel: b,
            value: c
        });
        a.add(d);
        a.doLayout();
        d.getEl().set({
            "ext:qtip": Ext.util.Format.htmlEncode(c)
        });
        if (e) {
            d.mon(d.getEl(), "click", function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                    opendir: f
                })
            }, this)
        }
    },
    sendUSBWebAPI: function(a) {
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: a.method,
            params: {
                id: this.task.id
            },
            callback: function(d, b, c) {
                if (d) {
                    a.onSuccess.call(this, b, c)
                } else {
                    a.onFail.call(this, b, c)
                }
            },
            scope: this
        })
    },
    onTaskRun: function() {
        this.owner.setStatusBusy({
            text: _USBCOPY_STR("common", "processing")
        });
        this.sendUSBWebAPI({
            method: "run",
            onSuccess: function() {
                this.setOverviewStatus("waiting", "");
                this.task.status = "waiting";
                this.app().getController("TaskListPanel").setTaskStatus(this.task.id, "waiting");
                this.owner.clearStatusBusy()
            },
            onFail: function(a) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(a))
            }
        })
    },
    onTaskCancel: function() {
        this.owner.setStatusBusy({
            text: _USBCOPY_STR("common", "processing")
        });
        this.sendUSBWebAPI({
            method: "cancel",
            onSuccess: function() {
                this.setOverviewStatus("canceling", "");
                this.task.status = "canceling";
                this.app().getController("TaskListPanel").setTaskStatus(this.task.id, "canceling");
                this.owner.clearStatusBusy()
            },
            onFail: function(a) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(a))
            }
        })
    },
    showDestPathChooser: function() {
        var a = this.createWidget(SYNO.SDS.USBCopy.Controller.EnableTaskDialog, {
            owner: this.owner,
            task: this.task
        });
        a.getViewport().open()
    },
    onTaskEnable: function() {
        if (this.task.destination_path === "") {
            this.showDestPathChooser();
            return
        }
        this.owner.setStatusBusy({
            text: _USBCOPY_STR("common", "processing")
        });
        this.sendUSBWebAPI({
            method: "enable",
            onSuccess: function() {
                this.app().getController("TaskListPanel").updateTask(this.task.id, function() {
                    this.loadOverview();
                    this.owner.clearStatusBusy()
                }, this)
            },
            onFail: function(a) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(a), function() {
                    if (a.code === SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_CONFLICT || a.code === SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_NOT_EXISTS) {
                        this.showDestPathChooser()
                    }
                }, this)
            }
        })
    },
    onTaskDisable: function() {
        this.owner.setStatusBusy({
            text: _USBCOPY_STR("common", "processing")
        });
        this.sendUSBWebAPI({
            method: "disable",
            onSuccess: function() {
                this.app().getController("TaskListPanel").updateTask(this.task.id, function() {
                    this.loadOverview();
                    this.owner.clearStatusBusy()
                }, this)
            },
            onFail: function(a) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(a))
            }
        })
    },
    doTaskDelete: function() {
        this.owner.setStatusBusy({
            text: _USBCOPY_STR("common", "processing")
        });
        var a = this.app().getController("TaskListPanel");
        this.sendUSBWebAPI({
            method: "delete",
            onSuccess: function() {
                var b = a.taskListView.getSelectedIndexes()[0];
                a.taskListView.getStore().removeAt(b);
                var c = a.taskListView.getStore().getCount();
                if (c > 0) {
                    a.taskListView.select(b < c ? b : c - 1);
                    this.owner.clearStatusBusy()
                } else {
                    this.owner.clearStatusBusy();
                    a.setNoTaskState()
                }
            },
            onFail: function(b) {
                this.owner.clearStatusBusy();
                this.owner.getMsgBox().alert("", SYNO.SDS.USBCopy.GetErrorString(b))
            }
        })
    },
    onTaskDelete: function() {
        this.owner.getMsgBox().confirmDelete(_USBCOPY_STR("app", "app_name"), _USBCOPY_STR("confirm", "delete_task"), function(a) {
            if (a === "yes") {
                this.doTaskDelete()
            }
        }, this)
    },
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.overviewPanel = this.componentQuery("mainPanel taskTabPanel overviewTab");
        this.control({
            "mainPanel taskTabPanel overviewTab": {
                activate: this.onActivate
            },
            "mainPanel taskTabPanel overviewTab overviewButtons runButton": {
                click: this.onTaskRun
            },
            "mainPanel taskTabPanel overviewTab overviewButtons cancelButton": {
                click: this.onTaskCancel
            },
            "mainPanel taskTabPanel overviewTab overviewButtons enableButton": {
                click: this.onTaskEnable
            },
            "mainPanel taskTabPanel overviewTab overviewButtons disableButton": {
                click: this.onTaskDisable
            },
            "mainPanel taskTabPanel overviewTab overviewButtons deleteButton": {
                click: this.onTaskDelete
            }
        });
        this.setNAStatus()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.SettingTab", {
    extend: "SYNO.SDS.USBCopy.Controller.BasicSettingPanel",
    previousLoadedTaskId: null,
    task: null,
    onTaskRecordSet: function(a) {
        this.task = a;
        this.taskType = a.type;
        if (!this.settingPanel.hidden) {
            if (this.previousLoadedTaskId === this.task.id) {
                if (this.shouldDisableDestPath() !== this.isDestPathDisabled()) {
                    this.onMountedSet();
                    this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel).reset()
                }
            } else {
                this.loadSetting();
                this.previousLoadedTaskId = this.task.id
            }
        }
    },
    setTaskSetting: function(b) {
        this.settingPanel.getForm().setValues(b);
        var a = this.componentQuery("taskNameDisplayField", this.settingPanel);
        a.setValue(b.name);
        a.originalValue = b.name
    },
    isDestPathDisabled: function() {
        return this.componentQuery("destinationFolderCompos", this.settingPanel).disabled
    },
    shouldDisableDestPath: function() {
        return (!this.task.is_usb_mounted && !SYNO.SDS.USBCopy.isImportType(this.task.type))
    },
    onMountedSet: function() {
        if (this.shouldDisableDestPath()) {
            this.componentQuery("destinationFolderCompos", this.settingPanel).disable();
            this.componentQuery("destinationFolderCompos destinationBrowserButton", this.settingPanel).hide()
        } else {
            this.componentQuery("destinationFolderCompos", this.settingPanel).enable();
            this.componentQuery("destinationFolderCompos destinationBrowserButton", this.settingPanel).show()
        }
    },
    loadSetting: function() {
        this.onMountedSet();
        this.componentQuery("importPhotoRemoveSrcFile", this.settingPanel).setVisible(false);
        this.setTaskSetting(this.task);
        if (this.task.is_default_task) {
            this.componentQuery("taskName", this.settingPanel).hide();
            this.componentQuery("taskNameDisplayField", this.settingPanel).show()
        } else {
            this.componentQuery("taskName", this.settingPanel).show();
            this.componentQuery("taskNameDisplayField", this.settingPanel).hide()
        }
        var a = this.settingPanel.rotation_setting;
        var b = this.componentQuery("copyStrategyCompositeField copyStrategy", this.settingPanel);
        if ("" === this.settingPanel.getForm().findField("destination_path").getValue()) {
            a.disable()
        } else {
            a.enable()
        }
        a.setVisible(false);
        if (b.getValue() === "versioning") {
            a.setVisible(true)
        }
        a.setPosition(b.getWidth() + 6, 0);
        var c = this.settingPanel.incremental_setting;
        c.setVisible(false);
        if (b.getValue() === "incremental") {
            c.setVisible(true)
        }
        c.setPosition(b.getWidth() + 6, 0)
    },
    onActivate: function() {
        this.loadSetting();
        this.previousLoadedTaskId = this.task.id
    },
    isTabDirty: function() {
        return this.settingPanel.getForm().isDirty()
    },
    affectCopyBehavior: function() {
        return this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel).isDirty()
    },
    onApplyButtonClick: function() {
        var b = this.settingPanel;
        if (!this.isTabDirty()) {
            b.setStatusError({
                text: _T("error", "nochange_subject"),
                clear: true
            });
            return false
        }
        if (!b.getForm().isValid()) {
            b.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        var a = this.app().getController("TaskListPanel").getTaskStatus(this.task.id);
        if ((a === "waiting" || a === "copying") && this.affectCopyBehavior()) {
            this.owner.getMsgBox().confirm(_USBCOPY_STR("app", "app_name"), _USBCOPY_STR("confirm", "abort_task"), function(c) {
                if (c === "yes") {
                    this.doSettingApply(b)
                }
            }, this);
            return false
        }
        this.doSettingApply(b)
    },
    doSettingApply: function(a) {
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        var b = this.getTaskSetting();
        b.id = this.task.id;
        b.type = this.task.type;
        b.enable_rotation = this.task.enable_rotation;
        b.rotation_policy = this.task.rotation_policy;
        b.max_version_count = this.task.max_version_count;
        b.remove_src_file = this.task.remove_src_file;
        b.not_keep_dir_structure = this.task.not_keep_dir_structure;
        b.smart_create_date_dir = this.task.smart_create_date_dir;
        b.rename_photo_video = this.task.rename_photo_video;
        b.conflict_policy = this.task.conflict_policy;
        var e = [];
        var c = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "cancel",
            params: {
                id: b.id
            }
        };
        var d = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_setting",
            params: {
                id: b.id,
                task_setting: b
            }
        };
        if (this.affectCopyBehavior()) {
            e = [c, d]
        } else {
            e = [d]
        }
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: e
            },
            callback: function(j, f, i, h) {
                if (j && !f.has_fail) {
                    Ext.apply(this.task, b);
                    this.app().getController("TaskListPanel").updateTask(this.task.id, function() {
                        this.loadSetting();
                        this.owner.clearStatusBusy();
                        a.setStatusOK({
                            text: _T("common", "setting_applied"),
                            clear: true
                        });
                        if (this.owner.confirmLostChangeResolve) {
                            this.owner.confirmLostChangeResolve()
                        }
                    }, this)
                } else {
                    this.owner.clearStatusBusy();
                    var g = SYNO.API.Util.GetFirstError(f);
                    this.owner.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), SYNO.SDS.USBCopy.GetErrorString(g))
                }
            },
            scope: this
        })
    },
    onResetButtonClick: function() {
        this.settingPanel.getForm().reset();
        this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel).validate();
        if (this.owner.confirmLostChangeResolve) {
            this.owner.confirmLostChangeResolve()
        }
    },
    onDestinationBrowserButtonClick: function() {
        if (SYNO.SDS.USBCopy.isImportType(this.taskType)) {
            return this.callParent()
        }
        var a = this.componentQuery("destinationFolderCompos destinationFolderPath", this.settingPanel);
        var b = SYNO.SDS.USBCopy.getFileChooserCfg(this.owner, a);
        var c = a.getValue().split("/")[1];
        Ext.apply(b, {
            treeFilter: function(f, e) {
                if (e.is_share) {
                    return e.text === c
                } else {
                    return true
                }
            },
            noShareCallBack: function(e) {
                e.getMsgBox().show({
                    title: e.title,
                    msg: _USBCOPY_STR("warning", "share_not_exists"),
                    width: 340,
                    buttons: Ext.MessageBox.OK,
                    scope: e,
                    fn: function(f) {
                        e.close()
                    }
                })
            },
            rootVisible: false
        });
        var d = new SYNO.SDS.USBCopy.Component.FileChooser.Chooser(b);
        d.show()
    },
    onRotationSetting: function() {
        if (!this.settingPanel.rotation_setting.disabled) {
            var a = this.createWidget(SYNO.SDS.USBCopy.Controller.RotationSettingWindow.RotationSettingWindow, {
                owner: this.owner,
                task: this.task
            });
            a.getViewport().open()
        }
        return
    },
    onIncrementalSetting: function() {
        var a = this.createWidget(SYNO.SDS.USBCopy.Controller.IncrementalSettingWindow.IncrementalSettingWindow, {
            owner: this.owner,
            task: this.task
        });
        a.getViewport().open();
        return
    },
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.settingPanel = this.componentQuery("mainPanel taskTabPanel settingTab");
        this.basicInit("mainPanel taskTabPanel settingTab ");
        this.control({
            "mainPanel taskTabPanel settingTab": {
                activate: this.onActivate,
                applyButtonClick: this.onApplyButtonClick,
                resetButtonClick: this.onResetButtonClick
            }
        });
        var a = this.settingPanel.rotation_setting;
        a.mon(a.getEl(), "click", this.onRotationSetting, this);
        var b = this.settingPanel.incremental_setting;
        b.mon(b.getEl(), "click", this.onIncrementalSetting, this);
        this.componentQuery("sourceFolderCompos", this.settingPanel).hide()
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.TriggerTimeTab", {
    extend: "SYNO.SDS.USBCopy.core.Controller",
    previousLoadedTaskId: null,
    originalSchedule: null,
    task: null,
    onTaskRecordSet: function(a) {
        this.task = a;
        if (!this.triggerTimePanel.hidden) {
            if (this.previousLoadedTaskId !== this.task.id) {
                this.loadTriggerTime();
                this.previousLoadedTaskId = this.task.id
            }
        }
    },
    isTabDirty: function() {
        if (this.previousLoadedTaskId === null) {
            return false
        }
        var b = ["runTaskWhenPlugInDevice", "ejectAfterTaskFinished", "enableSchedule"];
        var a, c;
        for (a = 0; a < b.length; a++) {
            c = this.componentQuery(b[a], this.triggerTimePanel);
            if (c.isDirty()) {
                return true
            }
        }
        if (Ext.encode(this.getScheduleValue()) !== this.originalSchedule) {
            return true
        }
        return false
    },
    onEnableScheduleCheck: function(b, a) {
        var c = this.componentQuery("synoSchedule", this.triggerTimePanel);
        if (a) {
            c.setDisabled(false);
            if (Ext.getCmp(c.per_week_id).getValue() === true) {
                Ext.getCmp(c.date_id).setDisabled(true);
                Ext.getCmp(c.repeat_id).setDisabled(true)
            } else {
                Ext.getCmp(c.week_name_id).setDisabled(true)
            }
        } else {
            c.setDisabled(true)
        }
    },
    getScheduleValue: function(c) {
        if (!c) {
            c = this.componentQuery("synoSchedule", this.triggerTimePanel)
        }
        var b = SYNO.SDS.USBCopy.getDefaultSchedule();
        var a = c.getData();
        return Ext.apply(b, a)
    },
    setTriggerTimeValues: function(b) {
        var c = this.componentQuery("runTaskWhenPlugInDevice", this.triggerTimePanel);
        var a = this.componentQuery("ejectAfterTaskFinished", this.triggerTimePanel);
        var d = this.componentQuery("enableSchedule", this.triggerTimePanel);
        var e = this.componentQuery("synoSchedule", this.triggerTimePanel);
        c.setValue(b.run_when_plug_in);
        c.originalValue = c.getValue();
        a.setValue(b.eject_when_task_done);
        a.originalValue = a.getValue();
        d.setValue(b.schedule_enabled);
        d.originalValue = d.getValue();
        e.setData(b.schedule_content);
        this.originalSchedule = Ext.encode(this.getScheduleValue(e))
    },
    setShowHideLayout: function() {
        var b = this.componentQuery("runTaskWhenPlugInDevice", this.triggerTimePanel);
        var c = this.componentQuery("enableSchedule", this.triggerTimePanel);
        var a = this.componentQuery("taskHelp", this.triggerTimePanel);
        var d = this.componentQuery("synoSchedule", this.triggerTimePanel);
        if (this.task.is_default_task) {
            b.hide();
            if (this.task.default_device_port === "USB") {
                a.update({
                    title: _USBCOPY_STR("common", "default_task_trigger_time_title_usb"),
                    content: _USBCOPY_STR("common", "default_task_trigger_time_content_usb")
                })
            } else {
                if (this.task.default_device_port === "SD_CARD") {
                    a.update({
                        title: _USBCOPY_STR("common", "default_task_trigger_time_title_sd"),
                        content: _USBCOPY_STR("common", "default_task_trigger_time_content_sd")
                    })
                }
            }
            a.show();
            c.hide();
            d.hide()
        } else {
            b.show();
            a.hide();
            c.show();
            d.show()
        }
        this.triggerTimePanel.doLayout()
    },
    loadTriggerTime: function() {
        var a = {};
        a.run_when_plug_in = this.task.run_when_plug_in;
        a.eject_when_task_done = this.task.eject_when_task_done;
        a.schedule_enabled = false;
        a.schedule_content = SYNO.SDS.USBCopy.getDefaultSchedule();
        if (this.task.schedule_id === -1) {
            this.setTriggerTimeValues(a);
            this.setShowHideLayout()
        } else {
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Core.TaskScheduler",
                version: 2,
                method: "get",
                params: {
                    id: this.task.schedule_id
                },
                callback: function(d, b, c) {
                    if (d) {
                        a.schedule_enabled = b.enable;
                        a.schedule_content = b.schedule;
                        this.setTriggerTimeValues(a);
                        this.setShowHideLayout();
                        this.owner.clearStatusBusy()
                    } else {
                        this.setTriggerTimeValues(a);
                        this.setShowHideLayout();
                        this.owner.clearStatusBusy();
                        this.owner.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), _USBCOPY_STR("warning", "err_sys"))
                    }
                },
                scope: this
            })
        }
    },
    onActivate: function() {
        if (this.previousLoadedTaskId !== this.task.id) {
            this.loadTriggerTime();
            this.previousLoadedTaskId = this.task.id
        }
    },
    onApplyButtonClick: function(b) {
        if (!this.isTabDirty()) {
            this.triggerTimePanel.setStatusError({
                text: _T("error", "nochange_subject"),
                clear: true
            });
            return false
        }
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        var a = {};
        a.run_when_plug_in = this.componentQuery("runTaskWhenPlugInDevice", this.triggerTimePanel).getValue();
        a.eject_when_task_done = this.componentQuery("ejectAfterTaskFinished", this.triggerTimePanel).getValue();
        a.schedule_enabled = this.componentQuery("enableSchedule", this.triggerTimePanel).getValue();
        a.schedule_content = this.getScheduleValue();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_trigger_time",
            params: {
                id: this.task.id,
                trigger_time: a
            },
            callback: function(e, c, d) {
                console.log("onApplyButtonClick");
                if (e) {
                    this.task.schedule_id = c.schedule_id;
                    this.task.next_run_time = c.next_run_time;
                    this.task.run_when_plug_in = a.run_when_plug_in;
                    this.task.eject_when_task_done = a.eject_when_task_done;
                    this.setTriggerTimeValues(a);
                    this.owner.clearStatusBusy();
                    this.triggerTimePanel.setStatusOK({
                        text: _T("common", "setting_applied"),
                        clear: true
                    });
                    if (this.owner.confirmLostChangeResolve) {
                        this.owner.confirmLostChangeResolve()
                    }
                } else {
                    this.owner.clearStatusBusy();
                    this.owner.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), _USBCOPY_STR("warning", "err_sys"))
                }
            },
            scope: this
        })
    },
    onResetButtonClick: function(b) {
        var c = ["runTaskWhenPlugInDevice", "ejectAfterTaskFinished", "enableSchedule"];
        var a, d;
        for (a = 0; a < c.length; a++) {
            d = this.componentQuery(c[a], this.triggerTimePanel);
            d.setValue(d.originalValue)
        }
        var e = this.componentQuery("synoSchedule", this.triggerTimePanel);
        e.setData(Ext.decode(this.originalSchedule));
        if (this.owner.confirmLostChangeResolve) {
            this.owner.confirmLostChangeResolve()
        }
    },
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.triggerTimePanel = this.componentQuery("mainPanel taskTabPanel triggerTimeTab");
        this.control({
            "mainPanel taskTabPanel triggerTimeTab": {
                activate: this.onActivate
            },
            "mainPanel taskTabPanel triggerTimeTab enableSchedule": {
                check: this.onEnableScheduleCheck
            },
            "mainPanel taskTabPanel triggerTimeTab applyButton": {
                click: this.onApplyButtonClick
            },
            "mainPanel taskTabPanel triggerTimeTab resetButton": {
                click: this.onResetButtonClick
            }
        });
        var a = _USBCOPY_STR("common", "eject_after_task_finished_qtip") + "<br/>" + _USBCOPY_STR("common", "eject_when_each_tasks_done_qtip");
        this.triggerTimePanel.on("afterlayout", function() {
            SYNO.ux.AddTip(this.componentQuery("ejectAfterTaskFinished", this.triggerTimePanel).getEl(), a)
        }, this, {
            single: true
        })
    }
});
Ext.define("SYNO.SDS.USBCopy.Controller.FilterTab", {
    extend: "SYNO.SDS.USBCopy.Controller.BasicFilterPanel",
    previousLoadedTaskId: null,
    originalFilterList: null,
    onTaskRecordSet: function(a) {
        this.taskId = a;
        if (!this.filterPanel.hidden) {
            if (this.previousLoadedTaskId !== this.taskId) {
                this.componentQuery("customInoutCompos customExtension", this.filterPanel).reset();
                this.loadFilter();
                this.previousLoadedTaskId = this.taskId
            }
        }
    },
    getCategoryRule: function(a, c) {
        for (var b = 0; b < a.length; b++) {
            if (c === a[b].nodeId) {
                return a[b]
            }
        }
    },
    setCustomizedSubItems: function(a, c) {
        var d = this.getCategoryRule(a, "customized");
        var b;
        for (b = 0; b < c.extensions.length; b++) {
            d.extensionfilter.push({
                nodeId: c.extensions[b],
                isChecked: true
            })
        }
        for (b = 0; b < c.names.length; b++) {
            d.fileNamefilter.push({
                nodeId: c.names[b],
                isChecked: true
            })
        }
        return a
    },
    applyFilterValue: function(b, f, a) {
        var e, d;
        for (e = 0; e < b.length; e++) {
            for (d = 0; d < b[e].extensionfilter.length; d++) {
                var g = b[e].extensionfilter[d];
                if (-1 !== f.extensions.indexOf(g.nodeId)) {
                    g.isChecked = a
                } else {
                    g.isChecked = !a
                }
            }
            for (d = 0; d < b[e].fileNamefilter.length; d++) {
                var c = b[e].fileNamefilter[d];
                if (-1 !== f.names.indexOf(c.nodeId)) {
                    c.isChecked = a
                } else {
                    c.isChecked = !a
                }
            }
        }
    },
    convertFilterListToTree: function(b) {
        var a = SYNO.SDS.USBCopy.getDefaultFilterTree();
        this.setCustomizedSubItems(a, b.customized_list);
        var c = (-1 !== b.white_list.extensions.indexOf(this.othersSymbol));
        this.getCategoryRule(a, "others").isChecked = c;
        if (c) {
            this.applyFilterValue(a, b.black_list, false)
        } else {
            this.applyFilterValue(a, b.white_list, true)
        }
        return a
    },
    setFilterList: function(a) {
        this.setFilterTree(this.convertFilterListToTree(a))
    },
    loadFilter: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "get_filter",
            params: {
                id: this.taskId
            },
            callback: function(c, a, b) {
                if (c) {
                    this.setFilterList(a.task_filter);
                    this.originalFilterList = Ext.encode(this.getFilterList());
                    this.owner.clearStatusBusy()
                } else {
                    this.owner.clearStatusBusy();
                    this.owner.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), SYNO.SDS.USBCopy.GetErrorString(a))
                }
            },
            scope: this
        })
    },
    onActivate: function() {
        this.componentQuery("customInoutCompos customExtension", this.filterPanel).reset();
        if (this.previousLoadedTaskId !== this.taskId) {
            this.loadFilter();
            this.previousLoadedTaskId = this.taskId
        }
    },
    isTabDirty: function() {
        if (this.previousLoadedTaskId === null) {
            return false
        }
        var a = this.componentQuery("customInoutCompos customExtension", this.filterPanel);
        return a.isDirty() || (Ext.encode(this.getFilterList()) !== this.originalFilterList)
    },
    onApplyButtonClick: function() {
        var b = this.filterPanel;
        var c = this.componentQuery("customInoutCompos customExtension", this.filterPanel);
        if (c.isDirty()) {
            c.markInvalid(_USBCOPY_STR("warning", "click_add"));
            return false
        }
        if (Ext.encode(this.getFilterList()) === this.originalFilterList) {
            b.setStatusError({
                text: _T("error", "nochange_subject"),
                clear: true
            });
            return false
        }
        var a = this.app().getController("TaskListPanel").getTaskStatus(this.taskId);
        if ((a === "waiting" || a === "copying")) {
            this.owner.getMsgBox().confirm(_USBCOPY_STR("app", "app_name"), _USBCOPY_STR("confirm", "abort_task"), function(d) {
                if (d === "yes") {
                    this.doFilterApply(b)
                }
            }, this);
            return false
        }
        this.doFilterApply(b)
    },
    doFilterApply: function(a) {
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        var c = this.getFilterList();
        var d = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "cancel",
            params: {
                id: this.taskId
            }
        };
        var b = {
            api: SYNO.SDS.USBCopy.WebAPI,
            version: 1,
            method: "set_filter",
            params: {
                id: this.taskId,
                task_filter: c
            }
        };
        var e = [d, b];
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: e
            },
            callback: function(j, f, i, h) {
                if (j && !f.has_fail) {
                    this.originalFilterList = Ext.encode(c);
                    this.app().getController("TaskListPanel").updateTask(this.taskId, function() {
                        this.owner.clearStatusBusy();
                        a.setStatusOK({
                            text: _T("common", "setting_applied"),
                            clear: true
                        });
                        if (this.owner.confirmLostChangeResolve) {
                            this.owner.confirmLostChangeResolve()
                        }
                    }, this)
                } else {
                    this.owner.clearStatusBusy();
                    var g = SYNO.API.Util.GetFirstError(f);
                    this.owner.getMsgBox().alert(_USBCOPY_STR("common", "app_name"), SYNO.SDS.USBCopy.GetErrorString(g))
                }
            },
            scope: this
        })
    },
    onResetButtonClick: function() {
        this.componentQuery("customInoutCompos customExtension", this.filterPanel).reset();
        this.setFilterList(Ext.decode(this.originalFilterList));
        if (this.owner.confirmLostChangeResolve) {
            this.owner.confirmLostChangeResolve()
        }
    },
    init: function() {
        this.owner = this.componentQuery("appWindow");
        this.filterPanel = this.componentQuery("mainPanel taskTabPanel filterTab");
        this.basicInit("mainPanel taskTabPanel filterTab ");
        this.control({
            "mainPanel taskTabPanel filterTab": {
                activate: this.onActivate,
                applyButtonClick: this.onApplyButtonClick,
                resetButtonClick: this.onResetButtonClick
            }
        })
    }
});
Ext.ns("SYNO.SDS.USBCopy");
SYNO.SDS.USBCopy.Util = {};
SYNO.SDS.USBCopy.WebAPI = "SYNO.USBCopy";
SYNO.SDS.USBCopy.WinWidth = 900;
SYNO.SDS.USBCopy.WinHeight = 550;
SYNO.SDS.USBCopy.MinWidth = 900;
SYNO.SDS.USBCopy.MinHeight = 550;
SYNO.SDS.USBCopy.MinLogCount = 5;
SYNO.SDS.USBCopy.MaxLogCount = 100000;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_GENERIC = 401;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_PARAMETER_INVALID = 402;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_USB_ALREADY_EXIST = 403;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_NO_REPO = 404;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INITIALIZING = 405;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UPGRADING = 406;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_MOVING_REPO = 407;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INVALID_VOLUME = 408;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_NOT_ENOUGH_VOLUME_SPACE = 409;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_CONFLICT = 410;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UNKNOWN_DEVICE = 411;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_NOT_EXISTS = 413;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INVALID_PATH = 414;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UPGRADE_FAILED = 415;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_FOLDER_NOT_EXISTS = 416;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_FOLDER_UNMOUNTED = 417;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_NOT_AVAILABLE = 418;
SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SOURCE_PATH_NOT_EXISTS = 419;
SYNO.SDS.USBCopy.ROTATION_OLDEST_VERSION = "oldest_version";
SYNO.SDS.USBCopy.ROTATION_SMART_RECYCLE = "smart_recycle";
SYNO.SDS.USBCopy.LOG_TYPE = {
    INFO_TYPE: 1,
    ERROR_TYPE: 2,
    WARN_TYPE: 4,
    ALL_TYPE: 7
};
SYNO.SDS.USBCopy.DESC_ID = {
    TASK_CREATED: 0,
    TASK_REMOVED: 1,
    TASK_ENABLED: 2,
    TASK_DISABLED: 3,
    SETTING_CHANGED_NAME: 10,
    SETTING_EDITED: 11,
    TASK_START: 100,
    TASK_FINISH: 101,
    TASK_ABORT: 102,
    TASK_ERROR: 103,
    TASK_VERSION_ROTATION: 104,
    TASK_ERROR_PARTIALLY_SUCCESS: 105,
    FILE_ERROR: 1000
};
SYNO.SDS.USBCopy.ERROR = {
    ERR_INT: -1,
    ERR_INVAL: -4,
    ERR_PERMISS: -9,
    ERR_FILE_OP: -10,
    ERR_FILE_SIZE_TOO_LARGE: -11,
    ERR_FILE_NAME_NOT_SUPPORT: -12,
    ERR_SHARE_UNMOUNT: -13,
    ERR_RESUME_FAILED: -14,
    ERR_SRC_FILE_MISS: -15,
    ERR_DST_FILE_EXISTS: -16,
    ERR_DST_CONFLICT: -17,
    ERR_DST_TYPE_CONFLICT: -18,
    ERR_DST_SPACE_FULL: -19,
    ERR_DST_ROOT_FOLDER_MISS: -20,
    ERR_DST_PARENT_FOLDER_MISS: -21,
    ERR_SRC_ROOT_FOLDER_MISS: -22,
    ERR_VERSION_FOLDER_CONFLICT: -24
};
var _USBCOPY_STR = function(b, a) {
    return _TT("SYNO.SDS.USBCopy.Application", b, a)
};
SYNO.SDS.USBCopy.GetErrorString = function(a) {
    switch (a.code) {
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_USB_ALREADY_EXIST:
            return String.format(_USBCOPY_STR("warning", "usb_already_exist"), a.errors.usb_share_name);
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INITIALIZING:
            return _USBCOPY_STR("warning", "initializing");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UPGRADING:
            return _USBCOPY_STR("warning", "upgrading");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_MOVING_REPO:
            return _USBCOPY_STR("warning", "moving_repo");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INVALID_VOLUME:
            return _USBCOPY_STR("warning", "invalid_volume");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_NOT_ENOUGH_VOLUME_SPACE:
            return _USBCOPY_STR("warning", "not_enough_volume_space");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_CONFLICT:
            return _USBCOPY_STR("warning", "dest_path_duplicated");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UNKNOWN_DEVICE:
            return _USBCOPY_STR("warning", "err_uuid");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_DEST_PATH_NOT_EXISTS:
            return _USBCOPY_STR("warning", "dest_path_not_exists");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_INVALID_PATH:
            return _USBCOPY_STR("warning", "err_folder_invalid");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_UPGRADE_FAILED:
            return _USBCOPY_STR("warning", "err_upgrade_failed");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_FOLDER_NOT_EXISTS:
            return _USBCOPY_STR("warning", "err_share_not_exists");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_FOLDER_UNMOUNTED:
            return _USBCOPY_STR("warning", "err_share_unmount");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SHARE_NOT_AVAILABLE:
            return _USBCOPY_STR("warning", "err_share_not_available");
        case SYNO.SDS.USBCopy.WEBAPI_UC_ERR_SOURCE_PATH_NOT_EXISTS:
            return _USBCOPY_STR("warning", "src_path_not_exists");
        default:
            return _USBCOPY_STR("warning", "err_sys")
    }
};
SYNO.SDS.USBCopy.GetFailReason = function(a) {
    switch (a) {
        case SYNO.SDS.USBCopy.ERROR.ERR_INT:
            return _USBCOPY_STR("status", "desc_failed_cancel");
        case SYNO.SDS.USBCopy.ERROR.ERR_SHARE_UNMOUNT:
            return _USBCOPY_STR("status", "desc_failed_share_unmounted");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_SPACE_FULL:
            return _USBCOPY_STR("status", "desc_failed_out_of_space");
        case SYNO.SDS.USBCopy.ERROR.ERR_SRC_ROOT_FOLDER_MISS:
            return _USBCOPY_STR("status", "desc_failed_src_root_folder_miss");
        case SYNO.SDS.USBCopy.ERROR.ERR_VERSION_FOLDER_CONFLICT:
            return _USBCOPY_STR("status", "desc_failed_folder_conflict");
        default:
            return _USBCOPY_STR("status", "desc_failed")
    }
};
SYNO.SDS.USBCopy.GetTaskError = function(a) {
    switch (a) {
        case SYNO.SDS.USBCopy.ERROR.ERR_SRC_ROOT_FOLDER_MISS:
            return _USBCOPY_STR("log_err_reason", "src_root_folder_miss");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_SPACE_FULL:
            return _USBCOPY_STR("log_err_reason", "dst_space_full");
        case SYNO.SDS.USBCopy.ERROR.ERR_VERSION_FOLDER_CONFLICT:
            return _USBCOPY_STR("log_err_reason", "dst_version_folder_conflict");
        default:
            return _USBCOPY_STR("log_err_reason", "task_error")
    }
};
SYNO.SDS.USBCopy.GetFileError = function(a) {
    switch (a) {
        case SYNO.SDS.USBCopy.ERROR.ERR_INT:
            return _USBCOPY_STR("log_err_reason", "cancel");
        case SYNO.SDS.USBCopy.ERROR.ERR_INVAL:
            return _USBCOPY_STR("log_err_reason", "invalid_parameter");
        case SYNO.SDS.USBCopy.ERROR.ERR_PERMISS:
            return _USBCOPY_STR("log_err_reason", "permission_error");
        case SYNO.SDS.USBCopy.ERROR.ERR_FILE_OP:
            return _USBCOPY_STR("log_err_reason", "file_operation_error");
        case SYNO.SDS.USBCopy.ERROR.ERR_FILE_SIZE_TOO_LARGE:
            return _USBCOPY_STR("log_err_reason", "file_size_too_large");
        case SYNO.SDS.USBCopy.ERROR.ERR_FILE_NAME_NOT_SUPPORT:
            return _USBCOPY_STR("log_err_reason", "file_name_not_support");
        case SYNO.SDS.USBCopy.ERROR.ERR_SHARE_UNMOUNT:
            return _USBCOPY_STR("log_err_reason", "share_unmount");
        case SYNO.SDS.USBCopy.ERROR.ERR_SRC_FILE_MISS:
            return _USBCOPY_STR("log_err_reason", "src_file_miss");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_FILE_EXISTS:
            return _USBCOPY_STR("log_err_reason", "dst_file_exists");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_CONFLICT:
            return _USBCOPY_STR("log_err_reason", "dst_conflict");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_TYPE_CONFLICT:
            return _USBCOPY_STR("log_err_reason", "dst_type_conflict");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_SPACE_FULL:
            return _USBCOPY_STR("log_err_reason", "dst_space_full");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_ROOT_FOLDER_MISS:
            return _USBCOPY_STR("log_err_reason", "dst_root_folder_miss");
        case SYNO.SDS.USBCopy.ERROR.ERR_DST_PARENT_FOLDER_MISS:
            return _USBCOPY_STR("log_err_reason", "dst_parent_folder_miss");
        case SYNO.SDS.USBCopy.ERROR.ERR_SRC_ROOT_FOLDER_MISS:
            return _USBCOPY_STR("log_err_reason", "src_root_folder_miss");
        default:
            return _USBCOPY_STR("log_err_reason", "file_error")
    }
};
SYNO.SDS.USBCopy.GetListFromObject = function(a) {
    var c = [];
    for (var b in a) {
        if (a.hasOwnProperty(b)) {
            c.push(a[b])
        }
    }
    return c
};
SYNO.SDS.USBCopy.RenderTimeFormat = function(d, c, a) {
    var b, f;
    if (Ext.isDate(d)) {
        b = d
    } else {
        if (d == parseInt(d, 10)) {
            b = new Date(1000 * d)
        } else {
            var e = Date.parse(d);
            if (!isNaN(e)) {
                b = new Date(e)
            } else {
                return d
            }
        }
    }
    f = SYNO.SDS.USBCopy.DateTimeFormatter(b, {
        type: a
    });
    if (c) {
        c.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(f) + '"'
    }
    return f
};
SYNO.SDS.USBCopy.DateTimeFormatter = SYNO.SDS.DateTimeFormatter;
SYNO.SDS.USBCopy.GetFileBaseName = function(b) {
    var a = b;
    var c = b.lastIndexOf("/");
    if (c !== -1) {
        a = a.substring(c + 1)
    }
    return a
};
SYNO.SDS.USBCopy.getTaskTypeDesc = function(a) {
    switch (a) {
        case "import_general":
            return _USBCOPY_STR("type", "desc_import_general");
        case "export_general":
            return _USBCOPY_STR("type", "desc_export_general");
        case "import_photo":
            return _USBCOPY_STR("type", "desc_import_photo")
    }
};
SYNO.SDS.USBCopy.isImportType = function(a) {
    switch (a) {
        case "import_general":
        case "import_photo":
            return true;
        case "export_general":
            return false
    }
};
SYNO.SDS.USBCopy.builtInExtensions = [{
    nodeLevel: "category",
    nodeId: "music",
    iconCls: "syno-usbcopy-selective-file-category-icon-music",
    extensions: ["aac", "aif", "aifc", "aiff", "ape", "au", "cdda", "dff", "dsf", "eaac", "flac", "kar", "l16", "m3u", "m4a", "m4b", "m4p", "mid", "midi", "mp1", "mp2", "mp3", "mpc", "mpga", "ogg", "pcm", "pls", "ra", "ram", "snd", "tta", "vqf", "wav", "wma"]
}, {
    nodeLevel: "category",
    nodeId: "video",
    iconCls: "syno-usbcopy-selective-file-category-icon-video",
    extensions: ["3g2", "3gp", "aaf", "amr", "ani", "asf", "asx", "avi", "dat", "dif", "divx", "dv", "dvr-ms", "f4v", "flv", "ifo", "m1v", "m2t", "m2ts", "m2v", "m4u", "m4v", "mkv", "mov", "movie", "mp4", "mpe", "mpeg", "mpeg1", "mpeg2", "mpeg4", "mpg", "mts", "mxf", "mxu", "ogm", "ogv", "qt", "qtx", "rec", "rm", "rmvb", "swf", "tp", "trp", "ts", "vob", "webm", "wmv", "wmv9", "wmx", "xvid"]
}, {
    nodeLevel: "category",
    nodeId: "image",
    iconCls: "syno-usbcopy-selective-file-category-icon-image",
    extensions: ["3fr", "ari", "arw", "bay", "bmp", "cap", "cgm", "cr2", "crw", "dcr", "dcs", "djv", "djvu", "dng", "drf", "eip", "erf", "fff", "gif", "ico", "ief", "iff", "iiq", "ilbm", "jp2", "jpe", "jpeg", "jpg", "k25", "kdc", "lbm", "mac", "mef", "mng", "mos", "mrw", "nef", "nrw", "obm", "orf", "pbm", "pct", "pcx", "pef", "pgm", "pic", "pict", "png", "pnm", "pnt", "pntg", "ppm", "psd", "ptx", "pxn", "qti", "qtif", "r3d", "raf", "ras", "raw", "rgb", "rw2", "rwl", "rwz", "sr2", "srf", "srw", "svg", "tga", "tif", "tiff", "ufo", "wbmp", "x3f", "xbm", "xpm", "xwd"]
}, {
    nodeLevel: "category",
    nodeId: "document",
    iconCls: "syno-usbcopy-selective-file-category-icon-document",
    extensions: ["doc", "docx", "epub", "htm", "html", "key", "mobi", "numbers", "odp", "ods", "odt", "pages", "pdf", "pps", "ppsx", "ppt", "pptx", "prc", "txt", "xls", "xlsx"]
}, {
    nodeLevel: "category",
    nodeId: "others",
    iconCls: "syno-usbcopy-selective-file-category-icon-others",
    extensions: []
}, {
    nodeLevel: "category",
    nodeId: "customized",
    iconCls: "syno-usbcopy-selective-file-category-icon-customized",
    extensions: []
}];
SYNO.SDS.USBCopy.getDefaultStatusByTaskType = function(a, b) {
    if (a === "import_photo") {
        return (b === "image" || b === "video")
    } else {
        if (a === "import_general" || a === "export_general") {
            return b !== "customized"
        }
    }
};
SYNO.SDS.USBCopy.getDefaultFilterTree = function(b) {
    var e = [];
    for (var d = 0; d < SYNO.SDS.USBCopy.builtInExtensions.length; d++) {
        var f = SYNO.SDS.USBCopy.builtInExtensions[d];
        var a = {
            nodeId: f.nodeId,
            isChecked: SYNO.SDS.USBCopy.getDefaultStatusByTaskType(b, f.nodeId),
            extensionfilter: [],
            fileNamefilter: []
        };
        for (var c = 0; c < f.extensions.length; c++) {
            a.extensionfilter.push({
                nodeId: f.extensions[c],
                isChecked: SYNO.SDS.USBCopy.getDefaultStatusByTaskType(b, f.nodeId)
            })
        }
        e.push(a)
    }
    return e
};
SYNO.SDS.USBCopy.getWidthOfString = function(d) {
    var e = document.createElement("canvas");
    if (!(e.getContext && e.getContext("2d"))) {
        return (d.length) * 6
    }
    var a = e.getContext("2d");
    var b = a.measureText(d).width;
    if (Ext.isOpera) {
        b = b
    } else {
        if (Ext.isFirefox) {
            b = b * (1.15)
        } else {
            if (Ext.isSafari) {
                b = b * (1.15)
            } else {
                if (Ext.isChrome) {
                    b = b
                } else {
                    if (Ext.isIE) {
                        b = b * (1.15)
                    } else {
                        b = b * (1.15)
                    }
                }
            }
        }
    }
    return b
};
SYNO.SDS.USBCopy.getlabelStyle = function(b, c) {
    var a = "";
    if (SYNO.SDS.USBCopy.getWidthOfString(b) > c) {
        a = a + "height:28px; top:-4px; line-height:18px;"
    }
    return a
};
SYNO.SDS.USBCopy.getFileChooserCfg = function(b, a, d) {
    var c = {
        owner: b,
        title: _T("common", "choose"),
        folderToolbar: true,
        gotoPath: a.getValue(),
        usage: {
            type: "chooseDir"
        },
        listeners: {
            choose: function(f, e) {
                if (!a.disabled) {
                    a.setValue(e.path)
                }
                f.close()
            }
        }
    };
    if (d === "ds") {
        Ext.apply(c, {
            treeFilter: function(f, e) {
                if (e.is_share) {
                    return !(e.external_dev_type === "USB" || e.external_dev_type === "SDCARD")
                } else {
                    return true
                }
            },
            noShareCallBack: function(e) {
                e.getMsgBox().show({
                    title: e.title,
                    msg: _USBCOPY_STR("confirm", "no_ds_share"),
                    width: 340,
                    buttons: Ext.MessageBox.OKCANCEL,
                    scope: e,
                    fn: function(f) {
                        e.close();
                        if ("ok" === f) {
                            SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", Ext.apply({}, {
                                fn: "SYNO.SDS.AdminCenter.Share.Main"
                            }, e.findAppWindow().openConfig))
                        }
                    }
                })
            }
        })
    } else {
        if (d === "usb") {
            Ext.apply(c, {
                treeFilter: function(f, e) {
                    if (e.is_share) {
                        return e.external_dev_type === "USB" || e.external_dev_type === "SDCARD"
                    } else {
                        return true
                    }
                },
                noShareCallBack: function(e) {
                    e.getMsgBox().show({
                        title: e.title,
                        msg: _USBCOPY_STR("warning", "no_usb_share"),
                        width: 340,
                        buttons: Ext.MessageBox.OK,
                        scope: e,
                        fn: function(f) {
                            e.close()
                        }
                    })
                }
            })
        }
    }
    return c
};
SYNO.SDS.USBCopy.ParseTreeNode = function(a, c) {
    var b;
    if ("fm_root" === c.id) {
        b = Ext.apply(a, {
            id: "/" + a.name,
            spath: "/" + a.name,
            path: a.vol_path + "/" + a.name,
            text: a.name,
            qtip: a.name,
            is_share: true,
            leaf: false,
            draggable: false
        })
    } else {
        b = {
            id: a.path,
            leaf: false,
            draggable: false,
            gid: a.additional.owner.gid,
            uid: a.additional.owner.uid,
            spath: a.path,
            path: a.additional.real_path,
            qtip: a.name,
            text: a.name,
            mountType: a.additional.mount_point_type,
            is_snapshot: a.is_snapshot,
            type: c.attributes.type,
            children: a.children
        }
    }
    return b
};
SYNO.SDS.USBCopy.getDefaultSchedule = function() {
    return {
        date_type: 0,
        week_day: "0,1,2,3,4,5,6",
        date: new Date().format("Y/m/d"),
        repeat_date: 0,
        hour: 0,
        minute: 0,
        repeat_hour: 0,
        last_work_hour: 0
    }
};
SYNO.SDS.USBCopy.createTimeItemStore = function(e) {
    var a = [];
    var c = {
        hour: 24,
        min: 60
    };
    if (e in c) {
        for (var d = 0; d < c[e]; d++) {
            a.push([d, String.leftPad(String(d), 2, "0")])
        }
        var b = new Ext.data.SimpleStore({
            id: 0,
            fields: ["value", "display"],
            data: a
        });
        return b
    }
    return null
};
Ext.define("SYNO.SDS.USBCopy.Application", {
    extend: "SYNO.SDS.USBCopy.core.App",
    appWindowName: "SYNO.SDS.USBCopy.View.MainWindow",
    controllers: ["SYNO.SDS.USBCopy.Controller.TaskListPanel", "SYNO.SDS.USBCopy.Controller.TaskTabPanel", "SYNO.SDS.USBCopy.Controller.OverviewTab", "SYNO.SDS.USBCopy.Controller.SettingTab", "SYNO.SDS.USBCopy.Controller.TriggerTimeTab", "SYNO.SDS.USBCopy.Controller.FilterTab"]
});
