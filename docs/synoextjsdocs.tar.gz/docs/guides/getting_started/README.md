# AppInstance guide

This guide gives information on writing DSM Application 

## Usage 

The AppInstance class must be used

## Application screen

{@img application.png Alt application screen}


## Application sample


    @example
	// Namespace definition
	Ext.ns("SYNOCOMMUNITY.SimpleExtJSApp");

	// Application definition
	Ext.define("SYNOCOMMUNITY.SimpleExtJSApp.AppInstance", {
    	extend: "SYNO.SDS.AppInstance",
    	appWindowName: "SYNOCOMMUNITY.SimpleExtJSApp.AppWindow",
    	constructor: function() {
        	this.callParent(arguments)
    	}
	});


