# Calling DSM API

This guide gives information on how to call DSM API

## Usage 

The usage of a DSM API is possible via an Ajax.request call to the corresponding desired API and method 



## Example

The below code retrieve from the Core.System API the CPU clock and temperature : 

    @example
    onAPIClick: function() {
        var t = this.getBaseURL({
            api: "SYNO.Core.System",
            method: "info",
            version: 3
        });
        Ext.Ajax.request({
            url: t,
            method: 'GET',
            timeout: 60000,
            headers: {
                'Content-Type': 'application/json'
            },
            success: function(response) {
                var data = Ext.decode(response.responseText).data;
                var cpu_clock = data.cpu_clock_speed;
                var temp = data.sys_temp;
                window.alert('API called : cpu clock speed = ' + cpu_clock + ' and temperature = ' + temp);
            },
            failure: function(response) {
                window.alert('Request Failed.');

            }
        });



